package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MapEntryLite;
import com.google.protobuf.MapFieldLite;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import com.google.protobuf.WireFormat;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import livekit.LivekitModels;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitRtc {

    /* JADX INFO: renamed from: livekit.LivekitRtc$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AddTrackRequest extends GeneratedMessageLite<AddTrackRequest, Builder> implements AddTrackRequestOrBuilder {
        public static final int AUDIO_FEATURES_FIELD_NUMBER = 17;
        public static final int BACKUP_CODEC_POLICY_FIELD_NUMBER = 16;
        public static final int CID_FIELD_NUMBER = 1;
        private static final AddTrackRequest DEFAULT_INSTANCE;
        public static final int DISABLE_DTX_FIELD_NUMBER = 7;
        public static final int DISABLE_RED_FIELD_NUMBER = 13;
        public static final int ENCRYPTION_FIELD_NUMBER = 14;
        public static final int HEIGHT_FIELD_NUMBER = 5;
        public static final int LAYERS_FIELD_NUMBER = 9;
        public static final int MUTED_FIELD_NUMBER = 6;
        public static final int NAME_FIELD_NUMBER = 2;
        private static volatile Parser<AddTrackRequest> PARSER = null;
        public static final int SID_FIELD_NUMBER = 11;
        public static final int SIMULCAST_CODECS_FIELD_NUMBER = 10;
        public static final int SOURCE_FIELD_NUMBER = 8;
        public static final int STEREO_FIELD_NUMBER = 12;
        public static final int STREAM_FIELD_NUMBER = 15;
        public static final int TYPE_FIELD_NUMBER = 3;
        public static final int WIDTH_FIELD_NUMBER = 4;
        private static final Internal.ListAdapter.Converter<Integer, LivekitModels.AudioTrackFeature> audioFeatures_converter_ = new Internal.ListAdapter.Converter<Integer, LivekitModels.AudioTrackFeature>() { // from class: livekit.LivekitRtc.AddTrackRequest.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public LivekitModels.AudioTrackFeature convert(Integer num) {
                LivekitModels.AudioTrackFeature audioTrackFeatureB = LivekitModels.AudioTrackFeature.b(num.intValue());
                return audioTrackFeatureB == null ? LivekitModels.AudioTrackFeature.i : audioTrackFeatureB;
            }
        };
        private int audioFeaturesMemoizedSerializedSize;
        private Internal.IntList audioFeatures_;
        private int backupCodecPolicy_;
        private String cid_;
        private boolean disableDtx_;
        private boolean disableRed_;
        private int encryption_;
        private int height_;
        private Internal.ProtobufList<LivekitModels.VideoLayer> layers_;
        private boolean muted_;
        private String name_;
        private String sid_;
        private Internal.ProtobufList<SimulcastCodec> simulcastCodecs_;
        private int source_;
        private boolean stereo_;
        private String stream_;
        private int type_;
        private int width_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AddTrackRequest, Builder> implements AddTrackRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(Iterable iterable) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).addAllAudioFeatures(iterable);
                return this;
            }

            public Builder B(Iterable iterable) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).addAllLayers(iterable);
                return this;
            }

            public Builder C(SimulcastCodec simulcastCodec) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).addSimulcastCodecs(simulcastCodec);
                return this;
            }

            public Builder D() {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).clearStream();
                return this;
            }

            public LivekitModels.TrackSource E() {
                return ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).getSource();
            }

            public Builder F(String str) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setCid(str);
                return this;
            }

            public Builder G(boolean z) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setDisableDtx(z);
                return this;
            }

            public Builder H(boolean z) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setDisableRed(z);
                return this;
            }

            public Builder I(LivekitModels.Encryption.Type type) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setEncryption(type);
                return this;
            }

            public Builder J(int i) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setHeight(i);
                return this;
            }

            public Builder K(boolean z) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setMuted(z);
                return this;
            }

            public Builder L(String str) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setName(str);
                return this;
            }

            public Builder M(String str) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setSid(str);
                return this;
            }

            public Builder N(LivekitModels.TrackSource trackSource) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setSource(trackSource);
                return this;
            }

            public Builder O(String str) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setStream(str);
                return this;
            }

            public Builder P(LivekitModels.TrackType trackType) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setType(trackType);
                return this;
            }

            public Builder Q(int i) {
                q();
                ((AddTrackRequest) ((GeneratedMessageLite.Builder) this).b).setWidth(i);
                return this;
            }

            private Builder() {
                super(AddTrackRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            AddTrackRequest addTrackRequest = new AddTrackRequest();
            DEFAULT_INSTANCE = addTrackRequest;
            GeneratedMessageLite.registerDefaultInstance(AddTrackRequest.class, addTrackRequest);
        }

        private AddTrackRequest() {
            String strA = ap.a(1734521617);
            this.cid_ = strA;
            this.name_ = strA;
            this.layers_ = GeneratedMessageLite.emptyProtobufList();
            this.simulcastCodecs_ = GeneratedMessageLite.emptyProtobufList();
            this.sid_ = strA;
            this.stream_ = strA;
            this.audioFeatures_ = GeneratedMessageLite.emptyIntList();
        }

        private void addAllAudioFeatures(Iterable<? extends LivekitModels.AudioTrackFeature> iterable) {
            ensureAudioFeaturesIsMutable();
            Iterator<? extends LivekitModels.AudioTrackFeature> it = iterable.iterator();
            while (it.hasNext()) {
                this.audioFeatures_.addInt(it.next().getNumber());
            }
        }

        private void addAllAudioFeaturesValue(Iterable<Integer> iterable) {
            ensureAudioFeaturesIsMutable();
            Iterator<Integer> it = iterable.iterator();
            while (it.hasNext()) {
                this.audioFeatures_.addInt(it.next().intValue());
            }
        }

        private void addAllLayers(Iterable<? extends LivekitModels.VideoLayer> iterable) {
            ensureLayersIsMutable();
            AbstractMessageLite.addAll(iterable, this.layers_);
        }

        private void addAllSimulcastCodecs(Iterable<? extends SimulcastCodec> iterable) {
            ensureSimulcastCodecsIsMutable();
            AbstractMessageLite.addAll(iterable, this.simulcastCodecs_);
        }

        private void addAudioFeatures(LivekitModels.AudioTrackFeature audioTrackFeature) {
            audioTrackFeature.getClass();
            ensureAudioFeaturesIsMutable();
            this.audioFeatures_.addInt(audioTrackFeature.getNumber());
        }

        private void addAudioFeaturesValue(int i) {
            ensureAudioFeaturesIsMutable();
            this.audioFeatures_.addInt(i);
        }

        private void addLayers(LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(videoLayer);
        }

        private void addSimulcastCodecs(SimulcastCodec simulcastCodec) {
            simulcastCodec.getClass();
            ensureSimulcastCodecsIsMutable();
            this.simulcastCodecs_.add(simulcastCodec);
        }

        private void clearAudioFeatures() {
            this.audioFeatures_ = GeneratedMessageLite.emptyIntList();
        }

        private void clearBackupCodecPolicy() {
            this.backupCodecPolicy_ = 0;
        }

        private void clearCid() {
            this.cid_ = getDefaultInstance().getCid();
        }

        private void clearDisableDtx() {
            this.disableDtx_ = false;
        }

        private void clearDisableRed() {
            this.disableRed_ = false;
        }

        private void clearEncryption() {
            this.encryption_ = 0;
        }

        private void clearHeight() {
            this.height_ = 0;
        }

        private void clearLayers() {
            this.layers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearMuted() {
            this.muted_ = false;
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearSid() {
            this.sid_ = getDefaultInstance().getSid();
        }

        private void clearSimulcastCodecs() {
            this.simulcastCodecs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSource() {
            this.source_ = 0;
        }

        private void clearStereo() {
            this.stereo_ = false;
        }

        private void clearStream() {
            this.stream_ = getDefaultInstance().getStream();
        }

        private void clearType() {
            this.type_ = 0;
        }

        private void clearWidth() {
            this.width_ = 0;
        }

        private void ensureAudioFeaturesIsMutable() {
            Internal.IntList intList = this.audioFeatures_;
            if (intList.isModifiable()) {
                return;
            }
            this.audioFeatures_ = GeneratedMessageLite.mutableCopy(intList);
        }

        private void ensureLayersIsMutable() {
            Internal.ProtobufList<LivekitModels.VideoLayer> protobufList = this.layers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.layers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSimulcastCodecsIsMutable() {
            Internal.ProtobufList<SimulcastCodec> protobufList = this.simulcastCodecs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.simulcastCodecs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static AddTrackRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AddTrackRequest parseDelimitedFrom(InputStream inputStream) {
            return (AddTrackRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AddTrackRequest parseFrom(ByteBuffer byteBuffer) {
            return (AddTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AddTrackRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeLayers(int i) {
            ensureLayersIsMutable();
            this.layers_.remove(i);
        }

        private void removeSimulcastCodecs(int i) {
            ensureSimulcastCodecsIsMutable();
            this.simulcastCodecs_.remove(i);
        }

        private void setAudioFeatures(int i, LivekitModels.AudioTrackFeature audioTrackFeature) {
            audioTrackFeature.getClass();
            ensureAudioFeaturesIsMutable();
            this.audioFeatures_.setInt(i, audioTrackFeature.getNumber());
        }

        private void setAudioFeaturesValue(int i, int i2) {
            ensureAudioFeaturesIsMutable();
            this.audioFeatures_.setInt(i, i2);
        }

        private void setBackupCodecPolicy(LivekitModels.BackupCodecPolicy backupCodecPolicy) {
            this.backupCodecPolicy_ = backupCodecPolicy.getNumber();
        }

        private void setBackupCodecPolicyValue(int i) {
            this.backupCodecPolicy_ = i;
        }

        private void setCid(String str) {
            str.getClass();
            this.cid_ = str;
        }

        private void setCidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.cid_ = byteString.L();
        }

        private void setDisableDtx(boolean z) {
            this.disableDtx_ = z;
        }

        private void setDisableRed(boolean z) {
            this.disableRed_ = z;
        }

        private void setEncryption(LivekitModels.Encryption.Type type) {
            this.encryption_ = type.getNumber();
        }

        private void setEncryptionValue(int i) {
            this.encryption_ = i;
        }

        private void setHeight(int i) {
            this.height_ = i;
        }

        private void setLayers(int i, LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.set(i, videoLayer);
        }

        private void setMuted(boolean z) {
            this.muted_ = z;
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setSid(String str) {
            str.getClass();
            this.sid_ = str;
        }

        private void setSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sid_ = byteString.L();
        }

        private void setSimulcastCodecs(int i, SimulcastCodec simulcastCodec) {
            simulcastCodec.getClass();
            ensureSimulcastCodecsIsMutable();
            this.simulcastCodecs_.set(i, simulcastCodec);
        }

        private void setSource(LivekitModels.TrackSource trackSource) {
            this.source_ = trackSource.getNumber();
        }

        private void setSourceValue(int i) {
            this.source_ = i;
        }

        private void setStereo(boolean z) {
            this.stereo_ = z;
        }

        private void setStream(String str) {
            str.getClass();
            this.stream_ = str;
        }

        private void setStreamBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.stream_ = byteString.L();
        }

        private void setType(LivekitModels.TrackType trackType) {
            this.type_ = trackType.getNumber();
        }

        private void setTypeValue(int i) {
            this.type_ = i;
        }

        private void setWidth(int i) {
            this.width_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new AddTrackRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0011\u0000\u0000\u0001\u0011\u0011\u0000\u0003\u0000\u0001Ȉ\u0002Ȉ\u0003\f\u0004\u000b\u0005\u000b\u0006\u0007\u0007\u0007\b\f\t\u001b\n\u001b\u000bȈ\f\u0007\r\u0007\u000e\f\u000fȈ\u0010\f\u0011,", new Object[]{"cid_", "name_", "type_", "width_", "height_", "muted_", "disableDtx_", "source_", "layers_", LivekitModels.VideoLayer.class, "simulcastCodecs_", SimulcastCodec.class, "sid_", "stereo_", "disableRed_", "encryption_", "stream_", "backupCodecPolicy_", "audioFeatures_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AddTrackRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AddTrackRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.AudioTrackFeature getAudioFeatures(int i) {
            LivekitModels.AudioTrackFeature audioTrackFeatureB = LivekitModels.AudioTrackFeature.b(this.audioFeatures_.getInt(i));
            return audioTrackFeatureB == null ? LivekitModels.AudioTrackFeature.i : audioTrackFeatureB;
        }

        public int getAudioFeaturesCount() {
            return this.audioFeatures_.size();
        }

        public List<LivekitModels.AudioTrackFeature> getAudioFeaturesList() {
            return new Internal.ListAdapter(this.audioFeatures_, audioFeatures_converter_);
        }

        public int getAudioFeaturesValue(int i) {
            return this.audioFeatures_.getInt(i);
        }

        public List<Integer> getAudioFeaturesValueList() {
            return this.audioFeatures_;
        }

        public LivekitModels.BackupCodecPolicy getBackupCodecPolicy() {
            LivekitModels.BackupCodecPolicy backupCodecPolicyB = LivekitModels.BackupCodecPolicy.b(this.backupCodecPolicy_);
            return backupCodecPolicyB == null ? LivekitModels.BackupCodecPolicy.e : backupCodecPolicyB;
        }

        public int getBackupCodecPolicyValue() {
            return this.backupCodecPolicy_;
        }

        public String getCid() {
            return this.cid_;
        }

        public ByteString getCidBytes() {
            return ByteString.n(this.cid_);
        }

        @Deprecated
        public boolean getDisableDtx() {
            return this.disableDtx_;
        }

        public boolean getDisableRed() {
            return this.disableRed_;
        }

        public LivekitModels.Encryption.Type getEncryption() {
            LivekitModels.Encryption.Type typeB = LivekitModels.Encryption.Type.b(this.encryption_);
            return typeB == null ? LivekitModels.Encryption.Type.e : typeB;
        }

        public int getEncryptionValue() {
            return this.encryption_;
        }

        public int getHeight() {
            return this.height_;
        }

        public LivekitModels.VideoLayer getLayers(int i) {
            return (LivekitModels.VideoLayer) this.layers_.get(i);
        }

        public int getLayersCount() {
            return this.layers_.size();
        }

        public List<LivekitModels.VideoLayer> getLayersList() {
            return this.layers_;
        }

        public LivekitModels.VideoLayerOrBuilder getLayersOrBuilder(int i) {
            return (LivekitModels.VideoLayerOrBuilder) this.layers_.get(i);
        }

        public List<? extends LivekitModels.VideoLayerOrBuilder> getLayersOrBuilderList() {
            return this.layers_;
        }

        public boolean getMuted() {
            return this.muted_;
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getSid() {
            return this.sid_;
        }

        public ByteString getSidBytes() {
            return ByteString.n(this.sid_);
        }

        public SimulcastCodec getSimulcastCodecs(int i) {
            return (SimulcastCodec) this.simulcastCodecs_.get(i);
        }

        public int getSimulcastCodecsCount() {
            return this.simulcastCodecs_.size();
        }

        public List<SimulcastCodec> getSimulcastCodecsList() {
            return this.simulcastCodecs_;
        }

        public SimulcastCodecOrBuilder getSimulcastCodecsOrBuilder(int i) {
            return (SimulcastCodecOrBuilder) this.simulcastCodecs_.get(i);
        }

        public List<? extends SimulcastCodecOrBuilder> getSimulcastCodecsOrBuilderList() {
            return this.simulcastCodecs_;
        }

        public LivekitModels.TrackSource getSource() {
            LivekitModels.TrackSource trackSourceB = LivekitModels.TrackSource.b(this.source_);
            return trackSourceB == null ? LivekitModels.TrackSource.g : trackSourceB;
        }

        public int getSourceValue() {
            return this.source_;
        }

        @Deprecated
        public boolean getStereo() {
            return this.stereo_;
        }

        public String getStream() {
            return this.stream_;
        }

        public ByteString getStreamBytes() {
            return ByteString.n(this.stream_);
        }

        public LivekitModels.TrackType getType() {
            LivekitModels.TrackType trackTypeB = LivekitModels.TrackType.b(this.type_);
            return trackTypeB == null ? LivekitModels.TrackType.e : trackTypeB;
        }

        public int getTypeValue() {
            return this.type_;
        }

        public int getWidth() {
            return this.width_;
        }

        public static Builder newBuilder(AddTrackRequest addTrackRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(addTrackRequest);
        }

        public static AddTrackRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AddTrackRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AddTrackRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AddTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AddTrackRequest parseFrom(ByteString byteString) {
            return (AddTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addLayers(int i, LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(i, videoLayer);
        }

        private void addSimulcastCodecs(int i, SimulcastCodec simulcastCodec) {
            simulcastCodec.getClass();
            ensureSimulcastCodecsIsMutable();
            this.simulcastCodecs_.add(i, simulcastCodec);
        }

        public static AddTrackRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AddTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AddTrackRequest parseFrom(byte[] bArr) {
            return (AddTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AddTrackRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AddTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AddTrackRequest parseFrom(InputStream inputStream) {
            return (AddTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AddTrackRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AddTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AddTrackRequest parseFrom(CodedInputStream codedInputStream) {
            return (AddTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AddTrackRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AddTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AddTrackRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum CandidateProtocol implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<CandidateProtocol>() { // from class: livekit.LivekitRtc.CandidateProtocol.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public CandidateProtocol findValueByNumber(int i) {
                return CandidateProtocol.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class CandidateProtocolVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new CandidateProtocolVerifier();

            private CandidateProtocolVerifier() {
            }

            public boolean isInRange(int i) {
                return CandidateProtocol.b(i) != null;
            }
        }

        CandidateProtocol(int i) {
            this.a = i;
        }

        public static CandidateProtocol b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ConnectionQualityInfo extends GeneratedMessageLite<ConnectionQualityInfo, Builder> implements ConnectionQualityInfoOrBuilder {
        private static final ConnectionQualityInfo DEFAULT_INSTANCE;
        private static volatile Parser<ConnectionQualityInfo> PARSER = null;
        public static final int PARTICIPANT_SID_FIELD_NUMBER = 1;
        public static final int QUALITY_FIELD_NUMBER = 2;
        public static final int SCORE_FIELD_NUMBER = 3;
        private String participantSid_ = ap.a(2061219162);
        private int quality_;
        private float score_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ConnectionQualityInfo, Builder> implements ConnectionQualityInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ConnectionQualityInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            ConnectionQualityInfo connectionQualityInfo = new ConnectionQualityInfo();
            DEFAULT_INSTANCE = connectionQualityInfo;
            GeneratedMessageLite.registerDefaultInstance(ConnectionQualityInfo.class, connectionQualityInfo);
        }

        private ConnectionQualityInfo() {
        }

        private void clearParticipantSid() {
            this.participantSid_ = getDefaultInstance().getParticipantSid();
        }

        private void clearQuality() {
            this.quality_ = 0;
        }

        private void clearScore() {
            this.score_ = 0.0f;
        }

        public static ConnectionQualityInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ConnectionQualityInfo parseDelimitedFrom(InputStream inputStream) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ConnectionQualityInfo parseFrom(ByteBuffer byteBuffer) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ConnectionQualityInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setParticipantSid(String str) {
            str.getClass();
            this.participantSid_ = str;
        }

        private void setParticipantSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantSid_ = byteString.L();
        }

        private void setQuality(LivekitModels.ConnectionQuality connectionQuality) {
            this.quality_ = connectionQuality.getNumber();
        }

        private void setQualityValue(int i) {
            this.quality_ = i;
        }

        private void setScore(float f) {
            this.score_ = f;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ConnectionQualityInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002\f\u0003\u0001", new Object[]{"participantSid_", "quality_", "score_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ConnectionQualityInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ConnectionQualityInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getParticipantSid() {
            return this.participantSid_;
        }

        public ByteString getParticipantSidBytes() {
            return ByteString.n(this.participantSid_);
        }

        public LivekitModels.ConnectionQuality getQuality() {
            LivekitModels.ConnectionQuality connectionQualityB = LivekitModels.ConnectionQuality.b(this.quality_);
            return connectionQualityB == null ? LivekitModels.ConnectionQuality.f : connectionQualityB;
        }

        public int getQualityValue() {
            return this.quality_;
        }

        public float getScore() {
            return this.score_;
        }

        public static Builder newBuilder(ConnectionQualityInfo connectionQualityInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(connectionQualityInfo);
        }

        public static ConnectionQualityInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ConnectionQualityInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ConnectionQualityInfo parseFrom(ByteString byteString) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ConnectionQualityInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ConnectionQualityInfo parseFrom(byte[] bArr) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ConnectionQualityInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ConnectionQualityInfo parseFrom(InputStream inputStream) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ConnectionQualityInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ConnectionQualityInfo parseFrom(CodedInputStream codedInputStream) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ConnectionQualityInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ConnectionQualityInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ConnectionQualityUpdate extends GeneratedMessageLite<ConnectionQualityUpdate, Builder> implements ConnectionQualityUpdateOrBuilder {
        private static final ConnectionQualityUpdate DEFAULT_INSTANCE;
        private static volatile Parser<ConnectionQualityUpdate> PARSER = null;
        public static final int UPDATES_FIELD_NUMBER = 1;
        private Internal.ProtobufList<ConnectionQualityInfo> updates_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ConnectionQualityUpdate, Builder> implements ConnectionQualityUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ConnectionQualityUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            ConnectionQualityUpdate connectionQualityUpdate = new ConnectionQualityUpdate();
            DEFAULT_INSTANCE = connectionQualityUpdate;
            GeneratedMessageLite.registerDefaultInstance(ConnectionQualityUpdate.class, connectionQualityUpdate);
        }

        private ConnectionQualityUpdate() {
        }

        private void addAllUpdates(Iterable<? extends ConnectionQualityInfo> iterable) {
            ensureUpdatesIsMutable();
            AbstractMessageLite.addAll(iterable, this.updates_);
        }

        private void addUpdates(ConnectionQualityInfo connectionQualityInfo) {
            connectionQualityInfo.getClass();
            ensureUpdatesIsMutable();
            this.updates_.add(connectionQualityInfo);
        }

        private void clearUpdates() {
            this.updates_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureUpdatesIsMutable() {
            Internal.ProtobufList<ConnectionQualityInfo> protobufList = this.updates_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.updates_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ConnectionQualityUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ConnectionQualityUpdate parseDelimitedFrom(InputStream inputStream) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ConnectionQualityUpdate parseFrom(ByteBuffer byteBuffer) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ConnectionQualityUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeUpdates(int i) {
            ensureUpdatesIsMutable();
            this.updates_.remove(i);
        }

        private void setUpdates(int i, ConnectionQualityInfo connectionQualityInfo) {
            connectionQualityInfo.getClass();
            ensureUpdatesIsMutable();
            this.updates_.set(i, connectionQualityInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ConnectionQualityUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1240948696), ConnectionQualityInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ConnectionQualityUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ConnectionQualityUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public ConnectionQualityInfo getUpdates(int i) {
            return (ConnectionQualityInfo) this.updates_.get(i);
        }

        public int getUpdatesCount() {
            return this.updates_.size();
        }

        public List<ConnectionQualityInfo> getUpdatesList() {
            return this.updates_;
        }

        public ConnectionQualityInfoOrBuilder getUpdatesOrBuilder(int i) {
            return (ConnectionQualityInfoOrBuilder) this.updates_.get(i);
        }

        public List<? extends ConnectionQualityInfoOrBuilder> getUpdatesOrBuilderList() {
            return this.updates_;
        }

        public static Builder newBuilder(ConnectionQualityUpdate connectionQualityUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(connectionQualityUpdate);
        }

        public static ConnectionQualityUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ConnectionQualityUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ConnectionQualityUpdate parseFrom(ByteString byteString) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addUpdates(int i, ConnectionQualityInfo connectionQualityInfo) {
            connectionQualityInfo.getClass();
            ensureUpdatesIsMutable();
            this.updates_.add(i, connectionQualityInfo);
        }

        public static ConnectionQualityUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ConnectionQualityUpdate parseFrom(byte[] bArr) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ConnectionQualityUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ConnectionQualityUpdate parseFrom(InputStream inputStream) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ConnectionQualityUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ConnectionQualityUpdate parseFrom(CodedInputStream codedInputStream) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ConnectionQualityUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ConnectionQualityUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ConnectionSettings extends GeneratedMessageLite<ConnectionSettings, Builder> implements ConnectionSettingsOrBuilder {
        public static final int ADAPTIVE_STREAM_FIELD_NUMBER = 2;
        public static final int AUTO_SUBSCRIBE_FIELD_NUMBER = 1;
        private static final ConnectionSettings DEFAULT_INSTANCE;
        public static final int DISABLE_ICE_LITE_FIELD_NUMBER = 4;
        private static volatile Parser<ConnectionSettings> PARSER = null;
        public static final int SUBSCRIBER_ALLOW_PAUSE_FIELD_NUMBER = 3;
        private boolean adaptiveStream_;
        private boolean autoSubscribe_;
        private int bitField0_;
        private boolean disableIceLite_;
        private boolean subscriberAllowPause_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ConnectionSettings, Builder> implements ConnectionSettingsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ConnectionSettings.DEFAULT_INSTANCE);
            }
        }

        static {
            ConnectionSettings connectionSettings = new ConnectionSettings();
            DEFAULT_INSTANCE = connectionSettings;
            GeneratedMessageLite.registerDefaultInstance(ConnectionSettings.class, connectionSettings);
        }

        private ConnectionSettings() {
        }

        private void clearAdaptiveStream() {
            this.adaptiveStream_ = false;
        }

        private void clearAutoSubscribe() {
            this.autoSubscribe_ = false;
        }

        private void clearDisableIceLite() {
            this.disableIceLite_ = false;
        }

        private void clearSubscriberAllowPause() {
            this.bitField0_ &= -2;
            this.subscriberAllowPause_ = false;
        }

        public static ConnectionSettings getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ConnectionSettings parseDelimitedFrom(InputStream inputStream) {
            return (ConnectionSettings) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ConnectionSettings parseFrom(ByteBuffer byteBuffer) {
            return (ConnectionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ConnectionSettings> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAdaptiveStream(boolean z) {
            this.adaptiveStream_ = z;
        }

        private void setAutoSubscribe(boolean z) {
            this.autoSubscribe_ = z;
        }

        private void setDisableIceLite(boolean z) {
            this.disableIceLite_ = z;
        }

        private void setSubscriberAllowPause(boolean z) {
            this.bitField0_ |= 1;
            this.subscriberAllowPause_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ConnectionSettings();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0001\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u0007\u0002\u0007\u0003ဇ\u0000\u0004\u0007", new Object[]{ap.a(427522953), ap.a(2082327118), ap.a(1532963142), ap.a(69560406), ap.a(25497514)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ConnectionSettings> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ConnectionSettings.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getAdaptiveStream() {
            return this.adaptiveStream_;
        }

        public boolean getAutoSubscribe() {
            return this.autoSubscribe_;
        }

        public boolean getDisableIceLite() {
            return this.disableIceLite_;
        }

        public boolean getSubscriberAllowPause() {
            return this.subscriberAllowPause_;
        }

        public boolean hasSubscriberAllowPause() {
            return (this.bitField0_ & 1) != 0;
        }

        public static Builder newBuilder(ConnectionSettings connectionSettings) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(connectionSettings);
        }

        public static ConnectionSettings parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionSettings) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ConnectionSettings parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ConnectionSettings parseFrom(ByteString byteString) {
            return (ConnectionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ConnectionSettings parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ConnectionSettings parseFrom(byte[] bArr) {
            return (ConnectionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ConnectionSettings parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ConnectionSettings parseFrom(InputStream inputStream) {
            return (ConnectionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ConnectionSettings parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ConnectionSettings parseFrom(CodedInputStream codedInputStream) {
            return (ConnectionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ConnectionSettings parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ConnectionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ConnectionSettingsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DataChannelInfo extends GeneratedMessageLite<DataChannelInfo, Builder> implements DataChannelInfoOrBuilder {
        private static final DataChannelInfo DEFAULT_INSTANCE;
        public static final int ID_FIELD_NUMBER = 2;
        public static final int LABEL_FIELD_NUMBER = 1;
        private static volatile Parser<DataChannelInfo> PARSER = null;
        public static final int TARGET_FIELD_NUMBER = 3;
        private int id_;
        private String label_ = ap.a(447623339);
        private int target_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DataChannelInfo, Builder> implements DataChannelInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(int i) {
                q();
                ((DataChannelInfo) ((GeneratedMessageLite.Builder) this).b).setId(i);
                return this;
            }

            public Builder B(String str) {
                q();
                ((DataChannelInfo) ((GeneratedMessageLite.Builder) this).b).setLabel(str);
                return this;
            }

            private Builder() {
                super(DataChannelInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            DataChannelInfo dataChannelInfo = new DataChannelInfo();
            DEFAULT_INSTANCE = dataChannelInfo;
            GeneratedMessageLite.registerDefaultInstance(DataChannelInfo.class, dataChannelInfo);
        }

        private DataChannelInfo() {
        }

        private void clearId() {
            this.id_ = 0;
        }

        private void clearLabel() {
            this.label_ = getDefaultInstance().getLabel();
        }

        private void clearTarget() {
            this.target_ = 0;
        }

        public static DataChannelInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DataChannelInfo parseDelimitedFrom(InputStream inputStream) {
            return (DataChannelInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DataChannelInfo parseFrom(ByteBuffer byteBuffer) {
            return (DataChannelInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DataChannelInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setId(int i) {
            this.id_ = i;
        }

        private void setLabel(String str) {
            str.getClass();
            this.label_ = str;
        }

        private void setLabelBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.label_ = byteString.L();
        }

        private void setTarget(SignalTarget signalTarget) {
            this.target_ = signalTarget.getNumber();
        }

        private void setTargetValue(int i) {
            this.target_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DataChannelInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002\u000b\u0003\f", new Object[]{"label_", "id_", "target_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DataChannelInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DataChannelInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getId() {
            return this.id_;
        }

        public String getLabel() {
            return this.label_;
        }

        public ByteString getLabelBytes() {
            return ByteString.n(this.label_);
        }

        public SignalTarget getTarget() {
            SignalTarget signalTargetB = SignalTarget.b(this.target_);
            return signalTargetB == null ? SignalTarget.d : signalTargetB;
        }

        public int getTargetValue() {
            return this.target_;
        }

        public static Builder newBuilder(DataChannelInfo dataChannelInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(dataChannelInfo);
        }

        public static DataChannelInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DataChannelInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DataChannelInfo parseFrom(ByteString byteString) {
            return (DataChannelInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DataChannelInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DataChannelInfo parseFrom(byte[] bArr) {
            return (DataChannelInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DataChannelInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DataChannelInfo parseFrom(InputStream inputStream) {
            return (DataChannelInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DataChannelInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DataChannelInfo parseFrom(CodedInputStream codedInputStream) {
            return (DataChannelInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DataChannelInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DataChannelInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DataChannelReceiveState extends GeneratedMessageLite<DataChannelReceiveState, Builder> implements DataChannelReceiveStateOrBuilder {
        private static final DataChannelReceiveState DEFAULT_INSTANCE;
        public static final int LAST_SEQ_FIELD_NUMBER = 2;
        private static volatile Parser<DataChannelReceiveState> PARSER = null;
        public static final int PUBLISHER_SID_FIELD_NUMBER = 1;
        private int lastSeq_;
        private String publisherSid_ = ap.a(1457225664);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DataChannelReceiveState, Builder> implements DataChannelReceiveStateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(int i) {
                q();
                ((DataChannelReceiveState) ((GeneratedMessageLite.Builder) this).b).setLastSeq(i);
                return this;
            }

            public Builder B(String str) {
                q();
                ((DataChannelReceiveState) ((GeneratedMessageLite.Builder) this).b).setPublisherSid(str);
                return this;
            }

            private Builder() {
                super(DataChannelReceiveState.DEFAULT_INSTANCE);
            }
        }

        static {
            DataChannelReceiveState dataChannelReceiveState = new DataChannelReceiveState();
            DEFAULT_INSTANCE = dataChannelReceiveState;
            GeneratedMessageLite.registerDefaultInstance(DataChannelReceiveState.class, dataChannelReceiveState);
        }

        private DataChannelReceiveState() {
        }

        private void clearLastSeq() {
            this.lastSeq_ = 0;
        }

        private void clearPublisherSid() {
            this.publisherSid_ = getDefaultInstance().getPublisherSid();
        }

        public static DataChannelReceiveState getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DataChannelReceiveState parseDelimitedFrom(InputStream inputStream) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DataChannelReceiveState parseFrom(ByteBuffer byteBuffer) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DataChannelReceiveState> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setLastSeq(int i) {
            this.lastSeq_ = i;
        }

        private void setPublisherSid(String str) {
            str.getClass();
            this.publisherSid_ = str;
        }

        private void setPublisherSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.publisherSid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DataChannelReceiveState();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002\u000b", new Object[]{"publisherSid_", "lastSeq_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DataChannelReceiveState> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DataChannelReceiveState.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getLastSeq() {
            return this.lastSeq_;
        }

        public String getPublisherSid() {
            return this.publisherSid_;
        }

        public ByteString getPublisherSidBytes() {
            return ByteString.n(this.publisherSid_);
        }

        public static Builder newBuilder(DataChannelReceiveState dataChannelReceiveState) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(dataChannelReceiveState);
        }

        public static DataChannelReceiveState parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DataChannelReceiveState parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DataChannelReceiveState parseFrom(ByteString byteString) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DataChannelReceiveState parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DataChannelReceiveState parseFrom(byte[] bArr) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DataChannelReceiveState parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DataChannelReceiveState parseFrom(InputStream inputStream) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DataChannelReceiveState parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DataChannelReceiveState parseFrom(CodedInputStream codedInputStream) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DataChannelReceiveState parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataChannelReceiveState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DataChannelReceiveStateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ICEServer extends GeneratedMessageLite<ICEServer, Builder> implements ICEServerOrBuilder {
        public static final int CREDENTIAL_FIELD_NUMBER = 3;
        private static final ICEServer DEFAULT_INSTANCE;
        private static volatile Parser<ICEServer> PARSER = null;
        public static final int URLS_FIELD_NUMBER = 1;
        public static final int USERNAME_FIELD_NUMBER = 2;
        private String credential_;
        private Internal.ProtobufList<String> urls_ = GeneratedMessageLite.emptyProtobufList();
        private String username_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ICEServer, Builder> implements ICEServerOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ICEServer.DEFAULT_INSTANCE);
            }
        }

        static {
            ICEServer iCEServer = new ICEServer();
            DEFAULT_INSTANCE = iCEServer;
            GeneratedMessageLite.registerDefaultInstance(ICEServer.class, iCEServer);
        }

        private ICEServer() {
            String strA = ap.a(979036731);
            this.username_ = strA;
            this.credential_ = strA;
        }

        private void addAllUrls(Iterable<String> iterable) {
            ensureUrlsIsMutable();
            AbstractMessageLite.addAll(iterable, this.urls_);
        }

        private void addUrls(String str) {
            str.getClass();
            ensureUrlsIsMutable();
            this.urls_.add(str);
        }

        private void addUrlsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureUrlsIsMutable();
            this.urls_.add(byteString.L());
        }

        private void clearCredential() {
            this.credential_ = getDefaultInstance().getCredential();
        }

        private void clearUrls() {
            this.urls_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearUsername() {
            this.username_ = getDefaultInstance().getUsername();
        }

        private void ensureUrlsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.urls_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.urls_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ICEServer getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ICEServer parseDelimitedFrom(InputStream inputStream) {
            return (ICEServer) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ICEServer parseFrom(ByteBuffer byteBuffer) {
            return (ICEServer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ICEServer> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCredential(String str) {
            str.getClass();
            this.credential_ = str;
        }

        private void setCredentialBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.credential_ = byteString.L();
        }

        private void setUrls(int i, String str) {
            str.getClass();
            ensureUrlsIsMutable();
            this.urls_.set(i, str);
        }

        private void setUsername(String str) {
            str.getClass();
            this.username_ = str;
        }

        private void setUsernameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.username_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ICEServer();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0001\u0000\u0001Ț\u0002Ȉ\u0003Ȉ", new Object[]{"urls_", "username_", "credential_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ICEServer> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ICEServer.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getCredential() {
            return this.credential_;
        }

        public ByteString getCredentialBytes() {
            return ByteString.n(this.credential_);
        }

        public String getUrls(int i) {
            return (String) this.urls_.get(i);
        }

        public ByteString getUrlsBytes(int i) {
            return ByteString.n((String) this.urls_.get(i));
        }

        public int getUrlsCount() {
            return this.urls_.size();
        }

        public List<String> getUrlsList() {
            return this.urls_;
        }

        public String getUsername() {
            return this.username_;
        }

        public ByteString getUsernameBytes() {
            return ByteString.n(this.username_);
        }

        public static Builder newBuilder(ICEServer iCEServer) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(iCEServer);
        }

        public static ICEServer parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEServer) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ICEServer parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEServer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ICEServer parseFrom(ByteString byteString) {
            return (ICEServer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ICEServer parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEServer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ICEServer parseFrom(byte[] bArr) {
            return (ICEServer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ICEServer parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEServer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ICEServer parseFrom(InputStream inputStream) {
            return (ICEServer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ICEServer parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEServer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ICEServer parseFrom(CodedInputStream codedInputStream) {
            return (ICEServer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ICEServer parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEServer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ICEServerOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class JoinRequest extends GeneratedMessageLite<JoinRequest, Builder> implements JoinRequestOrBuilder {
        public static final int ADD_TRACK_REQUESTS_FIELD_NUMBER = 5;
        public static final int CLIENT_INFO_FIELD_NUMBER = 1;
        public static final int CONNECTION_SETTINGS_FIELD_NUMBER = 2;
        private static final JoinRequest DEFAULT_INSTANCE;
        public static final int METADATA_FIELD_NUMBER = 3;
        private static volatile Parser<JoinRequest> PARSER = null;
        public static final int PARTICIPANT_ATTRIBUTES_FIELD_NUMBER = 4;
        public static final int PARTICIPANT_SID_FIELD_NUMBER = 9;
        public static final int PUBLISHER_OFFER_FIELD_NUMBER = 6;
        public static final int RECONNECT_FIELD_NUMBER = 7;
        public static final int RECONNECT_REASON_FIELD_NUMBER = 8;
        public static final int SYNC_STATE_FIELD_NUMBER = 10;
        private Internal.ProtobufList<AddTrackRequest> addTrackRequests_;
        private LivekitModels.ClientInfo clientInfo_;
        private ConnectionSettings connectionSettings_;
        private String metadata_;
        private MapFieldLite<String, String> participantAttributes_ = MapFieldLite.f();
        private String participantSid_;
        private SessionDescription publisherOffer_;
        private int reconnectReason_;
        private boolean reconnect_;
        private SyncState syncState_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<JoinRequest, Builder> implements JoinRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(JoinRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class ParticipantAttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(1843848996);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private ParticipantAttributesDefaultEntryHolder() {
            }
        }

        static {
            JoinRequest joinRequest = new JoinRequest();
            DEFAULT_INSTANCE = joinRequest;
            GeneratedMessageLite.registerDefaultInstance(JoinRequest.class, joinRequest);
        }

        private JoinRequest() {
            String strA = ap.a(1877652042);
            this.metadata_ = strA;
            this.addTrackRequests_ = GeneratedMessageLite.emptyProtobufList();
            this.participantSid_ = strA;
        }

        private void addAddTrackRequests(AddTrackRequest addTrackRequest) {
            addTrackRequest.getClass();
            ensureAddTrackRequestsIsMutable();
            this.addTrackRequests_.add(addTrackRequest);
        }

        private void addAllAddTrackRequests(Iterable<? extends AddTrackRequest> iterable) {
            ensureAddTrackRequestsIsMutable();
            AbstractMessageLite.addAll(iterable, this.addTrackRequests_);
        }

        private void clearAddTrackRequests() {
            this.addTrackRequests_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearClientInfo() {
            this.clientInfo_ = null;
        }

        private void clearConnectionSettings() {
            this.connectionSettings_ = null;
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearParticipantSid() {
            this.participantSid_ = getDefaultInstance().getParticipantSid();
        }

        private void clearPublisherOffer() {
            this.publisherOffer_ = null;
        }

        private void clearReconnect() {
            this.reconnect_ = false;
        }

        private void clearReconnectReason() {
            this.reconnectReason_ = 0;
        }

        private void clearSyncState() {
            this.syncState_ = null;
        }

        private void ensureAddTrackRequestsIsMutable() {
            Internal.ProtobufList<AddTrackRequest> protobufList = this.addTrackRequests_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.addTrackRequests_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static JoinRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableParticipantAttributesMap() {
            return internalGetMutableParticipantAttributes();
        }

        private MapFieldLite<String, String> internalGetMutableParticipantAttributes() {
            if (!this.participantAttributes_.k()) {
                this.participantAttributes_ = this.participantAttributes_.n();
            }
            return this.participantAttributes_;
        }

        private MapFieldLite<String, String> internalGetParticipantAttributes() {
            return this.participantAttributes_;
        }

        private void mergeClientInfo(LivekitModels.ClientInfo clientInfo) {
            clientInfo.getClass();
            LivekitModels.ClientInfo clientInfo2 = this.clientInfo_;
            if (clientInfo2 == null || clientInfo2 == LivekitModels.ClientInfo.getDefaultInstance()) {
                this.clientInfo_ = clientInfo;
            } else {
                this.clientInfo_ = (LivekitModels.ClientInfo) ((LivekitModels.ClientInfo.Builder) LivekitModels.ClientInfo.newBuilder(this.clientInfo_).v(clientInfo)).o();
            }
        }

        private void mergeConnectionSettings(ConnectionSettings connectionSettings) {
            connectionSettings.getClass();
            ConnectionSettings connectionSettings2 = this.connectionSettings_;
            if (connectionSettings2 == null || connectionSettings2 == ConnectionSettings.getDefaultInstance()) {
                this.connectionSettings_ = connectionSettings;
            } else {
                this.connectionSettings_ = (ConnectionSettings) ((ConnectionSettings.Builder) ConnectionSettings.newBuilder(this.connectionSettings_).v(connectionSettings)).o();
            }
        }

        private void mergePublisherOffer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            SessionDescription sessionDescription2 = this.publisherOffer_;
            if (sessionDescription2 == null || sessionDescription2 == SessionDescription.getDefaultInstance()) {
                this.publisherOffer_ = sessionDescription;
            } else {
                this.publisherOffer_ = (SessionDescription) ((SessionDescription.Builder) SessionDescription.newBuilder(this.publisherOffer_).v(sessionDescription)).o();
            }
        }

        private void mergeSyncState(SyncState syncState) {
            syncState.getClass();
            SyncState syncState2 = this.syncState_;
            if (syncState2 == null || syncState2 == SyncState.getDefaultInstance()) {
                this.syncState_ = syncState;
            } else {
                this.syncState_ = (SyncState) ((SyncState.Builder) SyncState.newBuilder(this.syncState_).v(syncState)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static JoinRequest parseDelimitedFrom(InputStream inputStream) {
            return (JoinRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static JoinRequest parseFrom(ByteBuffer byteBuffer) {
            return (JoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<JoinRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeAddTrackRequests(int i) {
            ensureAddTrackRequestsIsMutable();
            this.addTrackRequests_.remove(i);
        }

        private void setAddTrackRequests(int i, AddTrackRequest addTrackRequest) {
            addTrackRequest.getClass();
            ensureAddTrackRequestsIsMutable();
            this.addTrackRequests_.set(i, addTrackRequest);
        }

        private void setClientInfo(LivekitModels.ClientInfo clientInfo) {
            clientInfo.getClass();
            this.clientInfo_ = clientInfo;
        }

        private void setConnectionSettings(ConnectionSettings connectionSettings) {
            connectionSettings.getClass();
            this.connectionSettings_ = connectionSettings;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setParticipantSid(String str) {
            str.getClass();
            this.participantSid_ = str;
        }

        private void setParticipantSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantSid_ = byteString.L();
        }

        private void setPublisherOffer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            this.publisherOffer_ = sessionDescription;
        }

        private void setReconnect(boolean z) {
            this.reconnect_ = z;
        }

        private void setReconnectReason(LivekitModels.ReconnectReason reconnectReason) {
            this.reconnectReason_ = reconnectReason.getNumber();
        }

        private void setReconnectReasonValue(int i) {
            this.reconnectReason_ = i;
        }

        private void setSyncState(SyncState syncState) {
            syncState.getClass();
            this.syncState_ = syncState;
        }

        public boolean containsParticipantAttributes(String str) {
            str.getClass();
            return internalGetParticipantAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new JoinRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\n\u0000\u0000\u0001\n\n\u0001\u0001\u0000\u0001\t\u0002\t\u0003Ȉ\u00042\u0005\u001b\u0006\t\u0007\u0007\b\f\tȈ\n\t", new Object[]{"clientInfo_", "connectionSettings_", "metadata_", "participantAttributes_", ParticipantAttributesDefaultEntryHolder.a, "addTrackRequests_", AddTrackRequest.class, "publisherOffer_", "reconnect_", "reconnectReason_", "participantSid_", "syncState_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<JoinRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (JoinRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AddTrackRequest getAddTrackRequests(int i) {
            return (AddTrackRequest) this.addTrackRequests_.get(i);
        }

        public int getAddTrackRequestsCount() {
            return this.addTrackRequests_.size();
        }

        public List<AddTrackRequest> getAddTrackRequestsList() {
            return this.addTrackRequests_;
        }

        public AddTrackRequestOrBuilder getAddTrackRequestsOrBuilder(int i) {
            return (AddTrackRequestOrBuilder) this.addTrackRequests_.get(i);
        }

        public List<? extends AddTrackRequestOrBuilder> getAddTrackRequestsOrBuilderList() {
            return this.addTrackRequests_;
        }

        public LivekitModels.ClientInfo getClientInfo() {
            LivekitModels.ClientInfo clientInfo = this.clientInfo_;
            return clientInfo == null ? LivekitModels.ClientInfo.getDefaultInstance() : clientInfo;
        }

        public ConnectionSettings getConnectionSettings() {
            ConnectionSettings connectionSettings = this.connectionSettings_;
            return connectionSettings == null ? ConnectionSettings.getDefaultInstance() : connectionSettings;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        @Deprecated
        public Map<String, String> getParticipantAttributes() {
            return getParticipantAttributesMap();
        }

        public int getParticipantAttributesCount() {
            return internalGetParticipantAttributes().size();
        }

        public Map<String, String> getParticipantAttributesMap() {
            return Collections.unmodifiableMap(internalGetParticipantAttributes());
        }

        public String getParticipantAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetParticipantAttributes = internalGetParticipantAttributes();
            return mapFieldLiteInternalGetParticipantAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetParticipantAttributes.get(str) : str2;
        }

        public String getParticipantAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetParticipantAttributes = internalGetParticipantAttributes();
            if (mapFieldLiteInternalGetParticipantAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetParticipantAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getParticipantSid() {
            return this.participantSid_;
        }

        public ByteString getParticipantSidBytes() {
            return ByteString.n(this.participantSid_);
        }

        public SessionDescription getPublisherOffer() {
            SessionDescription sessionDescription = this.publisherOffer_;
            return sessionDescription == null ? SessionDescription.getDefaultInstance() : sessionDescription;
        }

        public boolean getReconnect() {
            return this.reconnect_;
        }

        public LivekitModels.ReconnectReason getReconnectReason() {
            LivekitModels.ReconnectReason reconnectReasonB = LivekitModels.ReconnectReason.b(this.reconnectReason_);
            return reconnectReasonB == null ? LivekitModels.ReconnectReason.g : reconnectReasonB;
        }

        public int getReconnectReasonValue() {
            return this.reconnectReason_;
        }

        public SyncState getSyncState() {
            SyncState syncState = this.syncState_;
            return syncState == null ? SyncState.getDefaultInstance() : syncState;
        }

        public boolean hasClientInfo() {
            return this.clientInfo_ != null;
        }

        public boolean hasConnectionSettings() {
            return this.connectionSettings_ != null;
        }

        public boolean hasPublisherOffer() {
            return this.publisherOffer_ != null;
        }

        public boolean hasSyncState() {
            return this.syncState_ != null;
        }

        public static Builder newBuilder(JoinRequest joinRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(joinRequest);
        }

        public static JoinRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static JoinRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static JoinRequest parseFrom(ByteString byteString) {
            return (JoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addAddTrackRequests(int i, AddTrackRequest addTrackRequest) {
            addTrackRequest.getClass();
            ensureAddTrackRequestsIsMutable();
            this.addTrackRequests_.add(i, addTrackRequest);
        }

        public static JoinRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static JoinRequest parseFrom(byte[] bArr) {
            return (JoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static JoinRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static JoinRequest parseFrom(InputStream inputStream) {
            return (JoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static JoinRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static JoinRequest parseFrom(CodedInputStream codedInputStream) {
            return (JoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static JoinRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface JoinRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class JoinResponse extends GeneratedMessageLite<JoinResponse, Builder> implements JoinResponseOrBuilder {
        public static final int ALTERNATIVE_URL_FIELD_NUMBER = 7;
        public static final int CLIENT_CONFIGURATION_FIELD_NUMBER = 8;
        private static final JoinResponse DEFAULT_INSTANCE;
        public static final int ENABLED_PUBLISH_CODECS_FIELD_NUMBER = 14;
        public static final int FAST_PUBLISH_FIELD_NUMBER = 15;
        public static final int ICE_SERVERS_FIELD_NUMBER = 5;
        public static final int OTHER_PARTICIPANTS_FIELD_NUMBER = 3;
        private static volatile Parser<JoinResponse> PARSER = null;
        public static final int PARTICIPANT_FIELD_NUMBER = 2;
        public static final int PING_INTERVAL_FIELD_NUMBER = 11;
        public static final int PING_TIMEOUT_FIELD_NUMBER = 10;
        public static final int ROOM_FIELD_NUMBER = 1;
        public static final int SERVER_INFO_FIELD_NUMBER = 12;
        public static final int SERVER_REGION_FIELD_NUMBER = 9;
        public static final int SERVER_VERSION_FIELD_NUMBER = 4;
        public static final int SIF_TRAILER_FIELD_NUMBER = 13;
        public static final int SUBSCRIBER_PRIMARY_FIELD_NUMBER = 6;
        private String alternativeUrl_;
        private LivekitModels.ClientConfiguration clientConfiguration_;
        private Internal.ProtobufList<LivekitModels.Codec> enabledPublishCodecs_;
        private boolean fastPublish_;
        private Internal.ProtobufList<ICEServer> iceServers_;
        private Internal.ProtobufList<LivekitModels.ParticipantInfo> otherParticipants_ = GeneratedMessageLite.emptyProtobufList();
        private LivekitModels.ParticipantInfo participant_;
        private int pingInterval_;
        private int pingTimeout_;
        private LivekitModels.Room room_;
        private LivekitModels.ServerInfo serverInfo_;
        private String serverRegion_;
        private String serverVersion_;
        private ByteString sifTrailer_;
        private boolean subscriberPrimary_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<JoinResponse, Builder> implements JoinResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(JoinResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            JoinResponse joinResponse = new JoinResponse();
            DEFAULT_INSTANCE = joinResponse;
            GeneratedMessageLite.registerDefaultInstance(JoinResponse.class, joinResponse);
        }

        private JoinResponse() {
            String strA = ap.a(1055776228);
            this.serverVersion_ = strA;
            this.iceServers_ = GeneratedMessageLite.emptyProtobufList();
            this.alternativeUrl_ = strA;
            this.serverRegion_ = strA;
            this.sifTrailer_ = ByteString.b;
            this.enabledPublishCodecs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllEnabledPublishCodecs(Iterable<? extends LivekitModels.Codec> iterable) {
            ensureEnabledPublishCodecsIsMutable();
            AbstractMessageLite.addAll(iterable, this.enabledPublishCodecs_);
        }

        private void addAllIceServers(Iterable<? extends ICEServer> iterable) {
            ensureIceServersIsMutable();
            AbstractMessageLite.addAll(iterable, this.iceServers_);
        }

        private void addAllOtherParticipants(Iterable<? extends LivekitModels.ParticipantInfo> iterable) {
            ensureOtherParticipantsIsMutable();
            AbstractMessageLite.addAll(iterable, this.otherParticipants_);
        }

        private void addEnabledPublishCodecs(LivekitModels.Codec codec) {
            codec.getClass();
            ensureEnabledPublishCodecsIsMutable();
            this.enabledPublishCodecs_.add(codec);
        }

        private void addIceServers(ICEServer iCEServer) {
            iCEServer.getClass();
            ensureIceServersIsMutable();
            this.iceServers_.add(iCEServer);
        }

        private void addOtherParticipants(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureOtherParticipantsIsMutable();
            this.otherParticipants_.add(participantInfo);
        }

        private void clearAlternativeUrl() {
            this.alternativeUrl_ = getDefaultInstance().getAlternativeUrl();
        }

        private void clearClientConfiguration() {
            this.clientConfiguration_ = null;
        }

        private void clearEnabledPublishCodecs() {
            this.enabledPublishCodecs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearFastPublish() {
            this.fastPublish_ = false;
        }

        private void clearIceServers() {
            this.iceServers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearOtherParticipants() {
            this.otherParticipants_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearParticipant() {
            this.participant_ = null;
        }

        private void clearPingInterval() {
            this.pingInterval_ = 0;
        }

        private void clearPingTimeout() {
            this.pingTimeout_ = 0;
        }

        private void clearRoom() {
            this.room_ = null;
        }

        private void clearServerInfo() {
            this.serverInfo_ = null;
        }

        private void clearServerRegion() {
            this.serverRegion_ = getDefaultInstance().getServerRegion();
        }

        private void clearServerVersion() {
            this.serverVersion_ = getDefaultInstance().getServerVersion();
        }

        private void clearSifTrailer() {
            this.sifTrailer_ = getDefaultInstance().getSifTrailer();
        }

        private void clearSubscriberPrimary() {
            this.subscriberPrimary_ = false;
        }

        private void ensureEnabledPublishCodecsIsMutable() {
            Internal.ProtobufList<LivekitModels.Codec> protobufList = this.enabledPublishCodecs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.enabledPublishCodecs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureIceServersIsMutable() {
            Internal.ProtobufList<ICEServer> protobufList = this.iceServers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.iceServers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureOtherParticipantsIsMutable() {
            Internal.ProtobufList<LivekitModels.ParticipantInfo> protobufList = this.otherParticipants_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.otherParticipants_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static JoinResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeClientConfiguration(LivekitModels.ClientConfiguration clientConfiguration) {
            clientConfiguration.getClass();
            LivekitModels.ClientConfiguration clientConfiguration2 = this.clientConfiguration_;
            if (clientConfiguration2 == null || clientConfiguration2 == LivekitModels.ClientConfiguration.getDefaultInstance()) {
                this.clientConfiguration_ = clientConfiguration;
            } else {
                this.clientConfiguration_ = (LivekitModels.ClientConfiguration) ((LivekitModels.ClientConfiguration.Builder) LivekitModels.ClientConfiguration.newBuilder(this.clientConfiguration_).v(clientConfiguration)).o();
            }
        }

        private void mergeParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            LivekitModels.ParticipantInfo participantInfo2 = this.participant_;
            if (participantInfo2 == null || participantInfo2 == LivekitModels.ParticipantInfo.getDefaultInstance()) {
                this.participant_ = participantInfo;
            } else {
                this.participant_ = (LivekitModels.ParticipantInfo) ((LivekitModels.ParticipantInfo.Builder) LivekitModels.ParticipantInfo.newBuilder(this.participant_).v(participantInfo)).o();
            }
        }

        private void mergeRoom(LivekitModels.Room room) {
            room.getClass();
            LivekitModels.Room room2 = this.room_;
            if (room2 == null || room2 == LivekitModels.Room.getDefaultInstance()) {
                this.room_ = room;
            } else {
                this.room_ = (LivekitModels.Room) ((LivekitModels.Room.Builder) LivekitModels.Room.newBuilder(this.room_).v(room)).o();
            }
        }

        private void mergeServerInfo(LivekitModels.ServerInfo serverInfo) {
            serverInfo.getClass();
            LivekitModels.ServerInfo serverInfo2 = this.serverInfo_;
            if (serverInfo2 == null || serverInfo2 == LivekitModels.ServerInfo.getDefaultInstance()) {
                this.serverInfo_ = serverInfo;
            } else {
                this.serverInfo_ = (LivekitModels.ServerInfo) ((LivekitModels.ServerInfo.Builder) LivekitModels.ServerInfo.newBuilder(this.serverInfo_).v(serverInfo)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static JoinResponse parseDelimitedFrom(InputStream inputStream) {
            return (JoinResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static JoinResponse parseFrom(ByteBuffer byteBuffer) {
            return (JoinResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<JoinResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeEnabledPublishCodecs(int i) {
            ensureEnabledPublishCodecsIsMutable();
            this.enabledPublishCodecs_.remove(i);
        }

        private void removeIceServers(int i) {
            ensureIceServersIsMutable();
            this.iceServers_.remove(i);
        }

        private void removeOtherParticipants(int i) {
            ensureOtherParticipantsIsMutable();
            this.otherParticipants_.remove(i);
        }

        private void setAlternativeUrl(String str) {
            str.getClass();
            this.alternativeUrl_ = str;
        }

        private void setAlternativeUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.alternativeUrl_ = byteString.L();
        }

        private void setClientConfiguration(LivekitModels.ClientConfiguration clientConfiguration) {
            clientConfiguration.getClass();
            this.clientConfiguration_ = clientConfiguration;
        }

        private void setEnabledPublishCodecs(int i, LivekitModels.Codec codec) {
            codec.getClass();
            ensureEnabledPublishCodecsIsMutable();
            this.enabledPublishCodecs_.set(i, codec);
        }

        private void setFastPublish(boolean z) {
            this.fastPublish_ = z;
        }

        private void setIceServers(int i, ICEServer iCEServer) {
            iCEServer.getClass();
            ensureIceServersIsMutable();
            this.iceServers_.set(i, iCEServer);
        }

        private void setOtherParticipants(int i, LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureOtherParticipantsIsMutable();
            this.otherParticipants_.set(i, participantInfo);
        }

        private void setParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            this.participant_ = participantInfo;
        }

        private void setPingInterval(int i) {
            this.pingInterval_ = i;
        }

        private void setPingTimeout(int i) {
            this.pingTimeout_ = i;
        }

        private void setRoom(LivekitModels.Room room) {
            room.getClass();
            this.room_ = room;
        }

        private void setServerInfo(LivekitModels.ServerInfo serverInfo) {
            serverInfo.getClass();
            this.serverInfo_ = serverInfo;
        }

        private void setServerRegion(String str) {
            str.getClass();
            this.serverRegion_ = str;
        }

        private void setServerRegionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.serverRegion_ = byteString.L();
        }

        private void setServerVersion(String str) {
            str.getClass();
            this.serverVersion_ = str;
        }

        private void setServerVersionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.serverVersion_ = byteString.L();
        }

        private void setSifTrailer(ByteString byteString) {
            byteString.getClass();
            this.sifTrailer_ = byteString;
        }

        private void setSubscriberPrimary(boolean z) {
            this.subscriberPrimary_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new JoinResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000f\u0000\u0000\u0001\u000f\u000f\u0000\u0003\u0000\u0001\t\u0002\t\u0003\u001b\u0004Ȉ\u0005\u001b\u0006\u0007\u0007Ȉ\b\t\tȈ\n\u0004\u000b\u0004\f\t\r\n\u000e\u001b\u000f\u0007", new Object[]{"room_", "participant_", "otherParticipants_", LivekitModels.ParticipantInfo.class, "serverVersion_", "iceServers_", ICEServer.class, "subscriberPrimary_", "alternativeUrl_", "clientConfiguration_", "serverRegion_", "pingTimeout_", "pingInterval_", "serverInfo_", "sifTrailer_", "enabledPublishCodecs_", LivekitModels.Codec.class, "fastPublish_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<JoinResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (JoinResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAlternativeUrl() {
            return this.alternativeUrl_;
        }

        public ByteString getAlternativeUrlBytes() {
            return ByteString.n(this.alternativeUrl_);
        }

        public LivekitModels.ClientConfiguration getClientConfiguration() {
            LivekitModels.ClientConfiguration clientConfiguration = this.clientConfiguration_;
            return clientConfiguration == null ? LivekitModels.ClientConfiguration.getDefaultInstance() : clientConfiguration;
        }

        public LivekitModels.Codec getEnabledPublishCodecs(int i) {
            return (LivekitModels.Codec) this.enabledPublishCodecs_.get(i);
        }

        public int getEnabledPublishCodecsCount() {
            return this.enabledPublishCodecs_.size();
        }

        public List<LivekitModels.Codec> getEnabledPublishCodecsList() {
            return this.enabledPublishCodecs_;
        }

        public LivekitModels.CodecOrBuilder getEnabledPublishCodecsOrBuilder(int i) {
            return (LivekitModels.CodecOrBuilder) this.enabledPublishCodecs_.get(i);
        }

        public List<? extends LivekitModels.CodecOrBuilder> getEnabledPublishCodecsOrBuilderList() {
            return this.enabledPublishCodecs_;
        }

        public boolean getFastPublish() {
            return this.fastPublish_;
        }

        public ICEServer getIceServers(int i) {
            return (ICEServer) this.iceServers_.get(i);
        }

        public int getIceServersCount() {
            return this.iceServers_.size();
        }

        public List<ICEServer> getIceServersList() {
            return this.iceServers_;
        }

        public ICEServerOrBuilder getIceServersOrBuilder(int i) {
            return (ICEServerOrBuilder) this.iceServers_.get(i);
        }

        public List<? extends ICEServerOrBuilder> getIceServersOrBuilderList() {
            return this.iceServers_;
        }

        public LivekitModels.ParticipantInfo getOtherParticipants(int i) {
            return (LivekitModels.ParticipantInfo) this.otherParticipants_.get(i);
        }

        public int getOtherParticipantsCount() {
            return this.otherParticipants_.size();
        }

        public List<LivekitModels.ParticipantInfo> getOtherParticipantsList() {
            return this.otherParticipants_;
        }

        public LivekitModels.ParticipantInfoOrBuilder getOtherParticipantsOrBuilder(int i) {
            return (LivekitModels.ParticipantInfoOrBuilder) this.otherParticipants_.get(i);
        }

        public List<? extends LivekitModels.ParticipantInfoOrBuilder> getOtherParticipantsOrBuilderList() {
            return this.otherParticipants_;
        }

        public LivekitModels.ParticipantInfo getParticipant() {
            LivekitModels.ParticipantInfo participantInfo = this.participant_;
            return participantInfo == null ? LivekitModels.ParticipantInfo.getDefaultInstance() : participantInfo;
        }

        public int getPingInterval() {
            return this.pingInterval_;
        }

        public int getPingTimeout() {
            return this.pingTimeout_;
        }

        public LivekitModels.Room getRoom() {
            LivekitModels.Room room = this.room_;
            return room == null ? LivekitModels.Room.getDefaultInstance() : room;
        }

        public LivekitModels.ServerInfo getServerInfo() {
            LivekitModels.ServerInfo serverInfo = this.serverInfo_;
            return serverInfo == null ? LivekitModels.ServerInfo.getDefaultInstance() : serverInfo;
        }

        public String getServerRegion() {
            return this.serverRegion_;
        }

        public ByteString getServerRegionBytes() {
            return ByteString.n(this.serverRegion_);
        }

        public String getServerVersion() {
            return this.serverVersion_;
        }

        public ByteString getServerVersionBytes() {
            return ByteString.n(this.serverVersion_);
        }

        public ByteString getSifTrailer() {
            return this.sifTrailer_;
        }

        public boolean getSubscriberPrimary() {
            return this.subscriberPrimary_;
        }

        public boolean hasClientConfiguration() {
            return this.clientConfiguration_ != null;
        }

        public boolean hasParticipant() {
            return this.participant_ != null;
        }

        public boolean hasRoom() {
            return this.room_ != null;
        }

        public boolean hasServerInfo() {
            return this.serverInfo_ != null;
        }

        public static Builder newBuilder(JoinResponse joinResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(joinResponse);
        }

        public static JoinResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static JoinResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static JoinResponse parseFrom(ByteString byteString) {
            return (JoinResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addEnabledPublishCodecs(int i, LivekitModels.Codec codec) {
            codec.getClass();
            ensureEnabledPublishCodecsIsMutable();
            this.enabledPublishCodecs_.add(i, codec);
        }

        private void addIceServers(int i, ICEServer iCEServer) {
            iCEServer.getClass();
            ensureIceServersIsMutable();
            this.iceServers_.add(i, iCEServer);
        }

        private void addOtherParticipants(int i, LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureOtherParticipantsIsMutable();
            this.otherParticipants_.add(i, participantInfo);
        }

        public static JoinResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static JoinResponse parseFrom(byte[] bArr) {
            return (JoinResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static JoinResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static JoinResponse parseFrom(InputStream inputStream) {
            return (JoinResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static JoinResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static JoinResponse parseFrom(CodedInputStream codedInputStream) {
            return (JoinResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static JoinResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JoinResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface JoinResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class LeaveRequest extends GeneratedMessageLite<LeaveRequest, Builder> implements LeaveRequestOrBuilder {
        public static final int ACTION_FIELD_NUMBER = 3;
        public static final int CAN_RECONNECT_FIELD_NUMBER = 1;
        private static final LeaveRequest DEFAULT_INSTANCE;
        private static volatile Parser<LeaveRequest> PARSER = null;
        public static final int REASON_FIELD_NUMBER = 2;
        public static final int REGIONS_FIELD_NUMBER = 4;
        private int action_;
        private boolean canReconnect_;
        private int reason_;
        private RegionSettings regions_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum Action implements Internal.EnumLite {
            b(0),
            c(1),
            d(2),
            e(-1);

            private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<Action>() { // from class: livekit.LivekitRtc.LeaveRequest.Action.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public Action findValueByNumber(int i) {
                    return Action.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class ActionVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new ActionVerifier();

                private ActionVerifier() {
                }

                public boolean isInRange(int i) {
                    return Action.b(i) != null;
                }
            }

            Action(int i) {
                this.a = i;
            }

            public static Action b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i == 1) {
                    return c;
                }
                if (i != 2) {
                    return null;
                }
                return d;
            }

            public final int getNumber() {
                if (this != e) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<LeaveRequest, Builder> implements LeaveRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(Action action) {
                q();
                ((LeaveRequest) ((GeneratedMessageLite.Builder) this).b).setAction(action);
                return this;
            }

            public Builder B(LivekitModels.DisconnectReason disconnectReason) {
                q();
                ((LeaveRequest) ((GeneratedMessageLite.Builder) this).b).setReason(disconnectReason);
                return this;
            }

            private Builder() {
                super(LeaveRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            LeaveRequest leaveRequest = new LeaveRequest();
            DEFAULT_INSTANCE = leaveRequest;
            GeneratedMessageLite.registerDefaultInstance(LeaveRequest.class, leaveRequest);
        }

        private LeaveRequest() {
        }

        private void clearAction() {
            this.action_ = 0;
        }

        private void clearCanReconnect() {
            this.canReconnect_ = false;
        }

        private void clearReason() {
            this.reason_ = 0;
        }

        private void clearRegions() {
            this.regions_ = null;
        }

        public static LeaveRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeRegions(RegionSettings regionSettings) {
            regionSettings.getClass();
            RegionSettings regionSettings2 = this.regions_;
            if (regionSettings2 == null || regionSettings2 == RegionSettings.getDefaultInstance()) {
                this.regions_ = regionSettings;
            } else {
                this.regions_ = (RegionSettings) ((RegionSettings.Builder) RegionSettings.newBuilder(this.regions_).v(regionSettings)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static LeaveRequest parseDelimitedFrom(InputStream inputStream) {
            return (LeaveRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static LeaveRequest parseFrom(ByteBuffer byteBuffer) {
            return (LeaveRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<LeaveRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAction(Action action) {
            this.action_ = action.getNumber();
        }

        private void setActionValue(int i) {
            this.action_ = i;
        }

        private void setCanReconnect(boolean z) {
            this.canReconnect_ = z;
        }

        private void setReason(LivekitModels.DisconnectReason disconnectReason) {
            this.reason_ = disconnectReason.getNumber();
        }

        private void setReasonValue(int i) {
            this.reason_ = i;
        }

        private void setRegions(RegionSettings regionSettings) {
            regionSettings.getClass();
            this.regions_ = regionSettings;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new LeaveRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u0007\u0002\f\u0003\f\u0004\t", new Object[]{ap.a(715950275), ap.a(1961971662), ap.a(48442201), ap.a(1089557226)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<LeaveRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (LeaveRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Action getAction() {
            Action actionB = Action.b(this.action_);
            return actionB == null ? Action.e : actionB;
        }

        public int getActionValue() {
            return this.action_;
        }

        public boolean getCanReconnect() {
            return this.canReconnect_;
        }

        public LivekitModels.DisconnectReason getReason() {
            LivekitModels.DisconnectReason disconnectReasonB = LivekitModels.DisconnectReason.b(this.reason_);
            return disconnectReasonB == null ? LivekitModels.DisconnectReason.r : disconnectReasonB;
        }

        public int getReasonValue() {
            return this.reason_;
        }

        public RegionSettings getRegions() {
            RegionSettings regionSettings = this.regions_;
            return regionSettings == null ? RegionSettings.getDefaultInstance() : regionSettings;
        }

        public boolean hasRegions() {
            return this.regions_ != null;
        }

        public static Builder newBuilder(LeaveRequest leaveRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(leaveRequest);
        }

        public static LeaveRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (LeaveRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static LeaveRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (LeaveRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static LeaveRequest parseFrom(ByteString byteString) {
            return (LeaveRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static LeaveRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (LeaveRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static LeaveRequest parseFrom(byte[] bArr) {
            return (LeaveRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static LeaveRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (LeaveRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static LeaveRequest parseFrom(InputStream inputStream) {
            return (LeaveRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static LeaveRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (LeaveRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static LeaveRequest parseFrom(CodedInputStream codedInputStream) {
            return (LeaveRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static LeaveRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (LeaveRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface LeaveRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class MediaSectionsRequirement extends GeneratedMessageLite<MediaSectionsRequirement, Builder> implements MediaSectionsRequirementOrBuilder {
        private static final MediaSectionsRequirement DEFAULT_INSTANCE;
        public static final int NUM_AUDIOS_FIELD_NUMBER = 1;
        public static final int NUM_VIDEOS_FIELD_NUMBER = 2;
        private static volatile Parser<MediaSectionsRequirement> PARSER;
        private int numAudios_;
        private int numVideos_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<MediaSectionsRequirement, Builder> implements MediaSectionsRequirementOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(MediaSectionsRequirement.DEFAULT_INSTANCE);
            }
        }

        static {
            MediaSectionsRequirement mediaSectionsRequirement = new MediaSectionsRequirement();
            DEFAULT_INSTANCE = mediaSectionsRequirement;
            GeneratedMessageLite.registerDefaultInstance(MediaSectionsRequirement.class, mediaSectionsRequirement);
        }

        private MediaSectionsRequirement() {
        }

        private void clearNumAudios() {
            this.numAudios_ = 0;
        }

        private void clearNumVideos() {
            this.numVideos_ = 0;
        }

        public static MediaSectionsRequirement getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static MediaSectionsRequirement parseDelimitedFrom(InputStream inputStream) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MediaSectionsRequirement parseFrom(ByteBuffer byteBuffer) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<MediaSectionsRequirement> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setNumAudios(int i) {
            this.numAudios_ = i;
        }

        private void setNumVideos(int i) {
            this.numVideos_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new MediaSectionsRequirement();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u000b\u0002\u000b", new Object[]{ap.a(778154959), ap.a(1400828633)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<MediaSectionsRequirement> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (MediaSectionsRequirement.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getNumAudios() {
            return this.numAudios_;
        }

        public int getNumVideos() {
            return this.numVideos_;
        }

        public static Builder newBuilder(MediaSectionsRequirement mediaSectionsRequirement) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(mediaSectionsRequirement);
        }

        public static MediaSectionsRequirement parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MediaSectionsRequirement parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static MediaSectionsRequirement parseFrom(ByteString byteString) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static MediaSectionsRequirement parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static MediaSectionsRequirement parseFrom(byte[] bArr) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static MediaSectionsRequirement parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static MediaSectionsRequirement parseFrom(InputStream inputStream) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MediaSectionsRequirement parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MediaSectionsRequirement parseFrom(CodedInputStream codedInputStream) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static MediaSectionsRequirement parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MediaSectionsRequirement) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface MediaSectionsRequirementOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class MuteTrackRequest extends GeneratedMessageLite<MuteTrackRequest, Builder> implements MuteTrackRequestOrBuilder {
        private static final MuteTrackRequest DEFAULT_INSTANCE;
        public static final int MUTED_FIELD_NUMBER = 2;
        private static volatile Parser<MuteTrackRequest> PARSER = null;
        public static final int SID_FIELD_NUMBER = 1;
        private boolean muted_;
        private String sid_ = ap.a(1677643716);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<MuteTrackRequest, Builder> implements MuteTrackRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(boolean z) {
                q();
                ((MuteTrackRequest) ((GeneratedMessageLite.Builder) this).b).setMuted(z);
                return this;
            }

            public Builder B(String str) {
                q();
                ((MuteTrackRequest) ((GeneratedMessageLite.Builder) this).b).setSid(str);
                return this;
            }

            private Builder() {
                super(MuteTrackRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            MuteTrackRequest muteTrackRequest = new MuteTrackRequest();
            DEFAULT_INSTANCE = muteTrackRequest;
            GeneratedMessageLite.registerDefaultInstance(MuteTrackRequest.class, muteTrackRequest);
        }

        private MuteTrackRequest() {
        }

        private void clearMuted() {
            this.muted_ = false;
        }

        private void clearSid() {
            this.sid_ = getDefaultInstance().getSid();
        }

        public static MuteTrackRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static MuteTrackRequest parseDelimitedFrom(InputStream inputStream) {
            return (MuteTrackRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MuteTrackRequest parseFrom(ByteBuffer byteBuffer) {
            return (MuteTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<MuteTrackRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setMuted(boolean z) {
            this.muted_ = z;
        }

        private void setSid(String str) {
            str.getClass();
            this.sid_ = str;
        }

        private void setSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new MuteTrackRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002\u0007", new Object[]{"sid_", "muted_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<MuteTrackRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (MuteTrackRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getMuted() {
            return this.muted_;
        }

        public String getSid() {
            return this.sid_;
        }

        public ByteString getSidBytes() {
            return ByteString.n(this.sid_);
        }

        public static Builder newBuilder(MuteTrackRequest muteTrackRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(muteTrackRequest);
        }

        public static MuteTrackRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteTrackRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MuteTrackRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static MuteTrackRequest parseFrom(ByteString byteString) {
            return (MuteTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static MuteTrackRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static MuteTrackRequest parseFrom(byte[] bArr) {
            return (MuteTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static MuteTrackRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static MuteTrackRequest parseFrom(InputStream inputStream) {
            return (MuteTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MuteTrackRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MuteTrackRequest parseFrom(CodedInputStream codedInputStream) {
            return (MuteTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static MuteTrackRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface MuteTrackRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ParticipantUpdate extends GeneratedMessageLite<ParticipantUpdate, Builder> implements ParticipantUpdateOrBuilder {
        private static final ParticipantUpdate DEFAULT_INSTANCE;
        private static volatile Parser<ParticipantUpdate> PARSER = null;
        public static final int PARTICIPANTS_FIELD_NUMBER = 1;
        private Internal.ProtobufList<LivekitModels.ParticipantInfo> participants_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ParticipantUpdate, Builder> implements ParticipantUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ParticipantUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            ParticipantUpdate participantUpdate = new ParticipantUpdate();
            DEFAULT_INSTANCE = participantUpdate;
            GeneratedMessageLite.registerDefaultInstance(ParticipantUpdate.class, participantUpdate);
        }

        private ParticipantUpdate() {
        }

        private void addAllParticipants(Iterable<? extends LivekitModels.ParticipantInfo> iterable) {
            ensureParticipantsIsMutable();
            AbstractMessageLite.addAll(iterable, this.participants_);
        }

        private void addParticipants(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureParticipantsIsMutable();
            this.participants_.add(participantInfo);
        }

        private void clearParticipants() {
            this.participants_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureParticipantsIsMutable() {
            Internal.ProtobufList<LivekitModels.ParticipantInfo> protobufList = this.participants_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.participants_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ParticipantUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ParticipantUpdate parseDelimitedFrom(InputStream inputStream) {
            return (ParticipantUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ParticipantUpdate parseFrom(ByteBuffer byteBuffer) {
            return (ParticipantUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ParticipantUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeParticipants(int i) {
            ensureParticipantsIsMutable();
            this.participants_.remove(i);
        }

        private void setParticipants(int i, LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureParticipantsIsMutable();
            this.participants_.set(i, participantInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ParticipantUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1733626634), LivekitModels.ParticipantInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ParticipantUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ParticipantUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.ParticipantInfo getParticipants(int i) {
            return (LivekitModels.ParticipantInfo) this.participants_.get(i);
        }

        public int getParticipantsCount() {
            return this.participants_.size();
        }

        public List<LivekitModels.ParticipantInfo> getParticipantsList() {
            return this.participants_;
        }

        public LivekitModels.ParticipantInfoOrBuilder getParticipantsOrBuilder(int i) {
            return (LivekitModels.ParticipantInfoOrBuilder) this.participants_.get(i);
        }

        public List<? extends LivekitModels.ParticipantInfoOrBuilder> getParticipantsOrBuilderList() {
            return this.participants_;
        }

        public static Builder newBuilder(ParticipantUpdate participantUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(participantUpdate);
        }

        public static ParticipantUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ParticipantUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ParticipantUpdate parseFrom(ByteString byteString) {
            return (ParticipantUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addParticipants(int i, LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureParticipantsIsMutable();
            this.participants_.add(i, participantInfo);
        }

        public static ParticipantUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ParticipantUpdate parseFrom(byte[] bArr) {
            return (ParticipantUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ParticipantUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ParticipantUpdate parseFrom(InputStream inputStream) {
            return (ParticipantUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ParticipantUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ParticipantUpdate parseFrom(CodedInputStream codedInputStream) {
            return (ParticipantUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ParticipantUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ParticipantUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class Ping extends GeneratedMessageLite<Ping, Builder> implements PingOrBuilder {
        private static final Ping DEFAULT_INSTANCE;
        private static volatile Parser<Ping> PARSER = null;
        public static final int RTT_FIELD_NUMBER = 2;
        public static final int TIMESTAMP_FIELD_NUMBER = 1;
        private long rtt_;
        private long timestamp_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<Ping, Builder> implements PingOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(long j) {
                q();
                ((Ping) ((GeneratedMessageLite.Builder) this).b).setRtt(j);
                return this;
            }

            public Builder B(long j) {
                q();
                ((Ping) ((GeneratedMessageLite.Builder) this).b).setTimestamp(j);
                return this;
            }

            private Builder() {
                super(Ping.DEFAULT_INSTANCE);
            }
        }

        static {
            Ping ping = new Ping();
            DEFAULT_INSTANCE = ping;
            GeneratedMessageLite.registerDefaultInstance(Ping.class, ping);
        }

        private Ping() {
        }

        private void clearRtt() {
            this.rtt_ = 0L;
        }

        private void clearTimestamp() {
            this.timestamp_ = 0L;
        }

        public static Ping getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static Ping parseDelimitedFrom(InputStream inputStream) {
            return (Ping) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Ping parseFrom(ByteBuffer byteBuffer) {
            return (Ping) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<Ping> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setRtt(long j) {
            this.rtt_ = j;
        }

        private void setTimestamp(long j) {
            this.timestamp_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new Ping();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0002\u0002\u0002", new Object[]{ap.a(658827265), ap.a(466041974)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<Ping> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (Ping.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getRtt() {
            return this.rtt_;
        }

        public long getTimestamp() {
            return this.timestamp_;
        }

        public static Builder newBuilder(Ping ping) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(ping);
        }

        public static Ping parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Ping) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Ping parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (Ping) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static Ping parseFrom(ByteString byteString) {
            return (Ping) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static Ping parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (Ping) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static Ping parseFrom(byte[] bArr) {
            return (Ping) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static Ping parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (Ping) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static Ping parseFrom(InputStream inputStream) {
            return (Ping) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Ping parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Ping) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Ping parseFrom(CodedInputStream codedInputStream) {
            return (Ping) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static Ping parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Ping) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface PingOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class Pong extends GeneratedMessageLite<Pong, Builder> implements PongOrBuilder {
        private static final Pong DEFAULT_INSTANCE;
        public static final int LAST_PING_TIMESTAMP_FIELD_NUMBER = 1;
        private static volatile Parser<Pong> PARSER = null;
        public static final int TIMESTAMP_FIELD_NUMBER = 2;
        private long lastPingTimestamp_;
        private long timestamp_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<Pong, Builder> implements PongOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(Pong.DEFAULT_INSTANCE);
            }
        }

        static {
            Pong pong = new Pong();
            DEFAULT_INSTANCE = pong;
            GeneratedMessageLite.registerDefaultInstance(Pong.class, pong);
        }

        private Pong() {
        }

        private void clearLastPingTimestamp() {
            this.lastPingTimestamp_ = 0L;
        }

        private void clearTimestamp() {
            this.timestamp_ = 0L;
        }

        public static Pong getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static Pong parseDelimitedFrom(InputStream inputStream) {
            return (Pong) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Pong parseFrom(ByteBuffer byteBuffer) {
            return (Pong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<Pong> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setLastPingTimestamp(long j) {
            this.lastPingTimestamp_ = j;
        }

        private void setTimestamp(long j) {
            this.timestamp_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new Pong();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0002\u0002\u0002", new Object[]{ap.a(1461164297), ap.a(1224852602)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<Pong> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (Pong.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getLastPingTimestamp() {
            return this.lastPingTimestamp_;
        }

        public long getTimestamp() {
            return this.timestamp_;
        }

        public static Builder newBuilder(Pong pong) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(pong);
        }

        public static Pong parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Pong) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Pong parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (Pong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static Pong parseFrom(ByteString byteString) {
            return (Pong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static Pong parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (Pong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static Pong parseFrom(byte[] bArr) {
            return (Pong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static Pong parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (Pong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static Pong parseFrom(InputStream inputStream) {
            return (Pong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Pong parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Pong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Pong parseFrom(CodedInputStream codedInputStream) {
            return (Pong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static Pong parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Pong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface PongOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ReconnectResponse extends GeneratedMessageLite<ReconnectResponse, Builder> implements ReconnectResponseOrBuilder {
        public static final int CLIENT_CONFIGURATION_FIELD_NUMBER = 2;
        private static final ReconnectResponse DEFAULT_INSTANCE;
        public static final int ICE_SERVERS_FIELD_NUMBER = 1;
        public static final int LAST_MESSAGE_SEQ_FIELD_NUMBER = 4;
        private static volatile Parser<ReconnectResponse> PARSER = null;
        public static final int SERVER_INFO_FIELD_NUMBER = 3;
        private LivekitModels.ClientConfiguration clientConfiguration_;
        private Internal.ProtobufList<ICEServer> iceServers_ = GeneratedMessageLite.emptyProtobufList();
        private int lastMessageSeq_;
        private LivekitModels.ServerInfo serverInfo_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ReconnectResponse, Builder> implements ReconnectResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ReconnectResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ReconnectResponse reconnectResponse = new ReconnectResponse();
            DEFAULT_INSTANCE = reconnectResponse;
            GeneratedMessageLite.registerDefaultInstance(ReconnectResponse.class, reconnectResponse);
        }

        private ReconnectResponse() {
        }

        private void addAllIceServers(Iterable<? extends ICEServer> iterable) {
            ensureIceServersIsMutable();
            AbstractMessageLite.addAll(iterable, this.iceServers_);
        }

        private void addIceServers(ICEServer iCEServer) {
            iCEServer.getClass();
            ensureIceServersIsMutable();
            this.iceServers_.add(iCEServer);
        }

        private void clearClientConfiguration() {
            this.clientConfiguration_ = null;
        }

        private void clearIceServers() {
            this.iceServers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearLastMessageSeq() {
            this.lastMessageSeq_ = 0;
        }

        private void clearServerInfo() {
            this.serverInfo_ = null;
        }

        private void ensureIceServersIsMutable() {
            Internal.ProtobufList<ICEServer> protobufList = this.iceServers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.iceServers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ReconnectResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeClientConfiguration(LivekitModels.ClientConfiguration clientConfiguration) {
            clientConfiguration.getClass();
            LivekitModels.ClientConfiguration clientConfiguration2 = this.clientConfiguration_;
            if (clientConfiguration2 == null || clientConfiguration2 == LivekitModels.ClientConfiguration.getDefaultInstance()) {
                this.clientConfiguration_ = clientConfiguration;
            } else {
                this.clientConfiguration_ = (LivekitModels.ClientConfiguration) ((LivekitModels.ClientConfiguration.Builder) LivekitModels.ClientConfiguration.newBuilder(this.clientConfiguration_).v(clientConfiguration)).o();
            }
        }

        private void mergeServerInfo(LivekitModels.ServerInfo serverInfo) {
            serverInfo.getClass();
            LivekitModels.ServerInfo serverInfo2 = this.serverInfo_;
            if (serverInfo2 == null || serverInfo2 == LivekitModels.ServerInfo.getDefaultInstance()) {
                this.serverInfo_ = serverInfo;
            } else {
                this.serverInfo_ = (LivekitModels.ServerInfo) ((LivekitModels.ServerInfo.Builder) LivekitModels.ServerInfo.newBuilder(this.serverInfo_).v(serverInfo)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ReconnectResponse parseDelimitedFrom(InputStream inputStream) {
            return (ReconnectResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ReconnectResponse parseFrom(ByteBuffer byteBuffer) {
            return (ReconnectResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ReconnectResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeIceServers(int i) {
            ensureIceServersIsMutable();
            this.iceServers_.remove(i);
        }

        private void setClientConfiguration(LivekitModels.ClientConfiguration clientConfiguration) {
            clientConfiguration.getClass();
            this.clientConfiguration_ = clientConfiguration;
        }

        private void setIceServers(int i, ICEServer iCEServer) {
            iCEServer.getClass();
            ensureIceServersIsMutable();
            this.iceServers_.set(i, iCEServer);
        }

        private void setLastMessageSeq(int i) {
            this.lastMessageSeq_ = i;
        }

        private void setServerInfo(LivekitModels.ServerInfo serverInfo) {
            serverInfo.getClass();
            this.serverInfo_ = serverInfo;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ReconnectResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0001\u0000\u0001\u001b\u0002\t\u0003\t\u0004\u000b", new Object[]{ap.a(169597894), ICEServer.class, ap.a(45469190), ap.a(741508075), ap.a(1930331979)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ReconnectResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ReconnectResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.ClientConfiguration getClientConfiguration() {
            LivekitModels.ClientConfiguration clientConfiguration = this.clientConfiguration_;
            return clientConfiguration == null ? LivekitModels.ClientConfiguration.getDefaultInstance() : clientConfiguration;
        }

        public ICEServer getIceServers(int i) {
            return (ICEServer) this.iceServers_.get(i);
        }

        public int getIceServersCount() {
            return this.iceServers_.size();
        }

        public List<ICEServer> getIceServersList() {
            return this.iceServers_;
        }

        public ICEServerOrBuilder getIceServersOrBuilder(int i) {
            return (ICEServerOrBuilder) this.iceServers_.get(i);
        }

        public List<? extends ICEServerOrBuilder> getIceServersOrBuilderList() {
            return this.iceServers_;
        }

        public int getLastMessageSeq() {
            return this.lastMessageSeq_;
        }

        public LivekitModels.ServerInfo getServerInfo() {
            LivekitModels.ServerInfo serverInfo = this.serverInfo_;
            return serverInfo == null ? LivekitModels.ServerInfo.getDefaultInstance() : serverInfo;
        }

        public boolean hasClientConfiguration() {
            return this.clientConfiguration_ != null;
        }

        public boolean hasServerInfo() {
            return this.serverInfo_ != null;
        }

        public static Builder newBuilder(ReconnectResponse reconnectResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(reconnectResponse);
        }

        public static ReconnectResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReconnectResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ReconnectResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ReconnectResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ReconnectResponse parseFrom(ByteString byteString) {
            return (ReconnectResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addIceServers(int i, ICEServer iCEServer) {
            iCEServer.getClass();
            ensureIceServersIsMutable();
            this.iceServers_.add(i, iCEServer);
        }

        public static ReconnectResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ReconnectResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ReconnectResponse parseFrom(byte[] bArr) {
            return (ReconnectResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ReconnectResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ReconnectResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ReconnectResponse parseFrom(InputStream inputStream) {
            return (ReconnectResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ReconnectResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReconnectResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ReconnectResponse parseFrom(CodedInputStream codedInputStream) {
            return (ReconnectResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ReconnectResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReconnectResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ReconnectResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RegionInfo extends GeneratedMessageLite<RegionInfo, Builder> implements RegionInfoOrBuilder {
        private static final RegionInfo DEFAULT_INSTANCE;
        public static final int DISTANCE_FIELD_NUMBER = 3;
        private static volatile Parser<RegionInfo> PARSER = null;
        public static final int REGION_FIELD_NUMBER = 1;
        public static final int URL_FIELD_NUMBER = 2;
        private long distance_;
        private String region_;
        private String url_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RegionInfo, Builder> implements RegionInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RegionInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            RegionInfo regionInfo = new RegionInfo();
            DEFAULT_INSTANCE = regionInfo;
            GeneratedMessageLite.registerDefaultInstance(RegionInfo.class, regionInfo);
        }

        private RegionInfo() {
            String strA = ap.a(1669604816);
            this.region_ = strA;
            this.url_ = strA;
        }

        private void clearDistance() {
            this.distance_ = 0L;
        }

        private void clearRegion() {
            this.region_ = getDefaultInstance().getRegion();
        }

        private void clearUrl() {
            this.url_ = getDefaultInstance().getUrl();
        }

        public static RegionInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RegionInfo parseDelimitedFrom(InputStream inputStream) {
            return (RegionInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RegionInfo parseFrom(ByteBuffer byteBuffer) {
            return (RegionInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RegionInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDistance(long j) {
            this.distance_ = j;
        }

        private void setRegion(String str) {
            str.getClass();
            this.region_ = str;
        }

        private void setRegionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.region_ = byteString.L();
        }

        private void setUrl(String str) {
            str.getClass();
            this.url_ = str;
        }

        private void setUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.url_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RegionInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\u0002", new Object[]{"region_", "url_", "distance_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RegionInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RegionInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getDistance() {
            return this.distance_;
        }

        public String getRegion() {
            return this.region_;
        }

        public ByteString getRegionBytes() {
            return ByteString.n(this.region_);
        }

        public String getUrl() {
            return this.url_;
        }

        public ByteString getUrlBytes() {
            return ByteString.n(this.url_);
        }

        public static Builder newBuilder(RegionInfo regionInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(regionInfo);
        }

        public static RegionInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RegionInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RegionInfo parseFrom(ByteString byteString) {
            return (RegionInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RegionInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RegionInfo parseFrom(byte[] bArr) {
            return (RegionInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RegionInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RegionInfo parseFrom(InputStream inputStream) {
            return (RegionInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RegionInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RegionInfo parseFrom(CodedInputStream codedInputStream) {
            return (RegionInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RegionInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RegionInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RegionSettings extends GeneratedMessageLite<RegionSettings, Builder> implements RegionSettingsOrBuilder {
        private static final RegionSettings DEFAULT_INSTANCE;
        private static volatile Parser<RegionSettings> PARSER = null;
        public static final int REGIONS_FIELD_NUMBER = 1;
        private Internal.ProtobufList<RegionInfo> regions_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RegionSettings, Builder> implements RegionSettingsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RegionSettings.DEFAULT_INSTANCE);
            }
        }

        static {
            RegionSettings regionSettings = new RegionSettings();
            DEFAULT_INSTANCE = regionSettings;
            GeneratedMessageLite.registerDefaultInstance(RegionSettings.class, regionSettings);
        }

        private RegionSettings() {
        }

        private void addAllRegions(Iterable<? extends RegionInfo> iterable) {
            ensureRegionsIsMutable();
            AbstractMessageLite.addAll(iterable, this.regions_);
        }

        private void addRegions(RegionInfo regionInfo) {
            regionInfo.getClass();
            ensureRegionsIsMutable();
            this.regions_.add(regionInfo);
        }

        private void clearRegions() {
            this.regions_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureRegionsIsMutable() {
            Internal.ProtobufList<RegionInfo> protobufList = this.regions_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.regions_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static RegionSettings getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RegionSettings parseDelimitedFrom(InputStream inputStream) {
            return (RegionSettings) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RegionSettings parseFrom(ByteBuffer byteBuffer) {
            return (RegionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RegionSettings> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeRegions(int i) {
            ensureRegionsIsMutable();
            this.regions_.remove(i);
        }

        private void setRegions(int i, RegionInfo regionInfo) {
            regionInfo.getClass();
            ensureRegionsIsMutable();
            this.regions_.set(i, regionInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RegionSettings();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(766642893), RegionInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RegionSettings> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RegionSettings.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public RegionInfo getRegions(int i) {
            return (RegionInfo) this.regions_.get(i);
        }

        public int getRegionsCount() {
            return this.regions_.size();
        }

        public List<RegionInfo> getRegionsList() {
            return this.regions_;
        }

        public RegionInfoOrBuilder getRegionsOrBuilder(int i) {
            return (RegionInfoOrBuilder) this.regions_.get(i);
        }

        public List<? extends RegionInfoOrBuilder> getRegionsOrBuilderList() {
            return this.regions_;
        }

        public static Builder newBuilder(RegionSettings regionSettings) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(regionSettings);
        }

        public static RegionSettings parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionSettings) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RegionSettings parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RegionSettings parseFrom(ByteString byteString) {
            return (RegionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addRegions(int i, RegionInfo regionInfo) {
            regionInfo.getClass();
            ensureRegionsIsMutable();
            this.regions_.add(i, regionInfo);
        }

        public static RegionSettings parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RegionSettings parseFrom(byte[] bArr) {
            return (RegionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RegionSettings parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RegionSettings parseFrom(InputStream inputStream) {
            return (RegionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RegionSettings parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RegionSettings parseFrom(CodedInputStream codedInputStream) {
            return (RegionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RegionSettings parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegionSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RegionSettingsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RequestResponse extends GeneratedMessageLite<RequestResponse, Builder> implements RequestResponseOrBuilder {
        public static final int ADD_TRACK_FIELD_NUMBER = 5;
        private static final RequestResponse DEFAULT_INSTANCE;
        public static final int MESSAGE_FIELD_NUMBER = 3;
        public static final int MUTE_FIELD_NUMBER = 6;
        private static volatile Parser<RequestResponse> PARSER = null;
        public static final int REASON_FIELD_NUMBER = 2;
        public static final int REQUEST_ID_FIELD_NUMBER = 1;
        public static final int TRICKLE_FIELD_NUMBER = 4;
        public static final int UPDATE_AUDIO_TRACK_FIELD_NUMBER = 8;
        public static final int UPDATE_METADATA_FIELD_NUMBER = 7;
        public static final int UPDATE_VIDEO_TRACK_FIELD_NUMBER = 9;
        private int reason_;
        private int requestId_;
        private Object request_;
        private int requestCase_ = 0;
        private String message_ = ap.a(1520048815);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RequestResponse, Builder> implements RequestResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RequestResponse.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum Reason implements Internal.EnumLite {
            b(0),
            c(1),
            d(2),
            e(3),
            f(4),
            g(5),
            h(6),
            i(-1);

            private static final Internal.EnumLiteMap j = new Internal.EnumLiteMap<Reason>() { // from class: livekit.LivekitRtc.RequestResponse.Reason.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public Reason findValueByNumber(int i2) {
                    return Reason.b(i2);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class ReasonVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new ReasonVerifier();

                private ReasonVerifier() {
                }

                public boolean isInRange(int i) {
                    return Reason.b(i) != null;
                }
            }

            Reason(int i2) {
                this.a = i2;
            }

            public static Reason b(int i2) {
                switch (i2) {
                    case 0:
                        return b;
                    case 1:
                        return c;
                    case 2:
                        return d;
                    case 3:
                        return e;
                    case 4:
                        return f;
                    case 5:
                        return g;
                    case 6:
                        return h;
                    default:
                        return null;
                }
            }

            public final int getNumber() {
                if (this != i) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum RequestCase {
            b(4),
            c(5),
            d(6),
            e(7),
            f(8),
            g(9),
            h(0);

            private final int a;

            RequestCase(int i2) {
                this.a = i2;
            }

            public static RequestCase b(int i2) {
                if (i2 == 0) {
                    return h;
                }
                switch (i2) {
                    case 4:
                        return b;
                    case 5:
                        return c;
                    case 6:
                        return d;
                    case 7:
                        return e;
                    case 8:
                        return f;
                    case 9:
                        return g;
                    default:
                        return null;
                }
            }
        }

        static {
            RequestResponse requestResponse = new RequestResponse();
            DEFAULT_INSTANCE = requestResponse;
            GeneratedMessageLite.registerDefaultInstance(RequestResponse.class, requestResponse);
        }

        private RequestResponse() {
        }

        private void clearAddTrack() {
            if (this.requestCase_ == 5) {
                this.requestCase_ = 0;
                this.request_ = null;
            }
        }

        private void clearMessage() {
            this.message_ = getDefaultInstance().getMessage();
        }

        private void clearMute() {
            if (this.requestCase_ == 6) {
                this.requestCase_ = 0;
                this.request_ = null;
            }
        }

        private void clearReason() {
            this.reason_ = 0;
        }

        private void clearRequest() {
            this.requestCase_ = 0;
            this.request_ = null;
        }

        private void clearRequestId() {
            this.requestId_ = 0;
        }

        private void clearTrickle() {
            if (this.requestCase_ == 4) {
                this.requestCase_ = 0;
                this.request_ = null;
            }
        }

        private void clearUpdateAudioTrack() {
            if (this.requestCase_ == 8) {
                this.requestCase_ = 0;
                this.request_ = null;
            }
        }

        private void clearUpdateMetadata() {
            if (this.requestCase_ == 7) {
                this.requestCase_ = 0;
                this.request_ = null;
            }
        }

        private void clearUpdateVideoTrack() {
            if (this.requestCase_ == 9) {
                this.requestCase_ = 0;
                this.request_ = null;
            }
        }

        public static RequestResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAddTrack(AddTrackRequest addTrackRequest) {
            addTrackRequest.getClass();
            if (this.requestCase_ != 5 || this.request_ == AddTrackRequest.getDefaultInstance()) {
                this.request_ = addTrackRequest;
            } else {
                this.request_ = ((AddTrackRequest.Builder) AddTrackRequest.newBuilder((AddTrackRequest) this.request_).v(addTrackRequest)).o();
            }
            this.requestCase_ = 5;
        }

        private void mergeMute(MuteTrackRequest muteTrackRequest) {
            muteTrackRequest.getClass();
            if (this.requestCase_ != 6 || this.request_ == MuteTrackRequest.getDefaultInstance()) {
                this.request_ = muteTrackRequest;
            } else {
                this.request_ = ((MuteTrackRequest.Builder) MuteTrackRequest.newBuilder((MuteTrackRequest) this.request_).v(muteTrackRequest)).o();
            }
            this.requestCase_ = 6;
        }

        private void mergeTrickle(TrickleRequest trickleRequest) {
            trickleRequest.getClass();
            if (this.requestCase_ != 4 || this.request_ == TrickleRequest.getDefaultInstance()) {
                this.request_ = trickleRequest;
            } else {
                this.request_ = ((TrickleRequest.Builder) TrickleRequest.newBuilder((TrickleRequest) this.request_).v(trickleRequest)).o();
            }
            this.requestCase_ = 4;
        }

        private void mergeUpdateAudioTrack(UpdateLocalAudioTrack updateLocalAudioTrack) {
            updateLocalAudioTrack.getClass();
            if (this.requestCase_ != 8 || this.request_ == UpdateLocalAudioTrack.getDefaultInstance()) {
                this.request_ = updateLocalAudioTrack;
            } else {
                this.request_ = ((UpdateLocalAudioTrack.Builder) UpdateLocalAudioTrack.newBuilder((UpdateLocalAudioTrack) this.request_).v(updateLocalAudioTrack)).o();
            }
            this.requestCase_ = 8;
        }

        private void mergeUpdateMetadata(UpdateParticipantMetadata updateParticipantMetadata) {
            updateParticipantMetadata.getClass();
            if (this.requestCase_ != 7 || this.request_ == UpdateParticipantMetadata.getDefaultInstance()) {
                this.request_ = updateParticipantMetadata;
            } else {
                this.request_ = ((UpdateParticipantMetadata.Builder) UpdateParticipantMetadata.newBuilder((UpdateParticipantMetadata) this.request_).v(updateParticipantMetadata)).o();
            }
            this.requestCase_ = 7;
        }

        private void mergeUpdateVideoTrack(UpdateLocalVideoTrack updateLocalVideoTrack) {
            updateLocalVideoTrack.getClass();
            if (this.requestCase_ != 9 || this.request_ == UpdateLocalVideoTrack.getDefaultInstance()) {
                this.request_ = updateLocalVideoTrack;
            } else {
                this.request_ = ((UpdateLocalVideoTrack.Builder) UpdateLocalVideoTrack.newBuilder((UpdateLocalVideoTrack) this.request_).v(updateLocalVideoTrack)).o();
            }
            this.requestCase_ = 9;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RequestResponse parseDelimitedFrom(InputStream inputStream) {
            return (RequestResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RequestResponse parseFrom(ByteBuffer byteBuffer) {
            return (RequestResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RequestResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAddTrack(AddTrackRequest addTrackRequest) {
            addTrackRequest.getClass();
            this.request_ = addTrackRequest;
            this.requestCase_ = 5;
        }

        private void setMessage(String str) {
            str.getClass();
            this.message_ = str;
        }

        private void setMessageBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.message_ = byteString.L();
        }

        private void setMute(MuteTrackRequest muteTrackRequest) {
            muteTrackRequest.getClass();
            this.request_ = muteTrackRequest;
            this.requestCase_ = 6;
        }

        private void setReason(Reason reason) {
            this.reason_ = reason.getNumber();
        }

        private void setReasonValue(int i) {
            this.reason_ = i;
        }

        private void setRequestId(int i) {
            this.requestId_ = i;
        }

        private void setTrickle(TrickleRequest trickleRequest) {
            trickleRequest.getClass();
            this.request_ = trickleRequest;
            this.requestCase_ = 4;
        }

        private void setUpdateAudioTrack(UpdateLocalAudioTrack updateLocalAudioTrack) {
            updateLocalAudioTrack.getClass();
            this.request_ = updateLocalAudioTrack;
            this.requestCase_ = 8;
        }

        private void setUpdateMetadata(UpdateParticipantMetadata updateParticipantMetadata) {
            updateParticipantMetadata.getClass();
            this.request_ = updateParticipantMetadata;
            this.requestCase_ = 7;
        }

        private void setUpdateVideoTrack(UpdateLocalVideoTrack updateLocalVideoTrack) {
            updateLocalVideoTrack.getClass();
            this.request_ = updateLocalVideoTrack;
            this.requestCase_ = 9;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RequestResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\t\u0001\u0000\u0001\t\t\u0000\u0000\u0000\u0001\u000b\u0002\f\u0003Ȉ\u0004<\u0000\u0005<\u0000\u0006<\u0000\u0007<\u0000\b<\u0000\t<\u0000", new Object[]{"request_", "requestCase_", "requestId_", "reason_", "message_", TrickleRequest.class, AddTrackRequest.class, MuteTrackRequest.class, UpdateParticipantMetadata.class, UpdateLocalAudioTrack.class, UpdateLocalVideoTrack.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RequestResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RequestResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AddTrackRequest getAddTrack() {
            return this.requestCase_ == 5 ? (AddTrackRequest) this.request_ : AddTrackRequest.getDefaultInstance();
        }

        public String getMessage() {
            return this.message_;
        }

        public ByteString getMessageBytes() {
            return ByteString.n(this.message_);
        }

        public MuteTrackRequest getMute() {
            return this.requestCase_ == 6 ? (MuteTrackRequest) this.request_ : MuteTrackRequest.getDefaultInstance();
        }

        public Reason getReason() {
            Reason reasonB = Reason.b(this.reason_);
            return reasonB == null ? Reason.i : reasonB;
        }

        public int getReasonValue() {
            return this.reason_;
        }

        public RequestCase getRequestCase() {
            return RequestCase.b(this.requestCase_);
        }

        public int getRequestId() {
            return this.requestId_;
        }

        public TrickleRequest getTrickle() {
            return this.requestCase_ == 4 ? (TrickleRequest) this.request_ : TrickleRequest.getDefaultInstance();
        }

        public UpdateLocalAudioTrack getUpdateAudioTrack() {
            return this.requestCase_ == 8 ? (UpdateLocalAudioTrack) this.request_ : UpdateLocalAudioTrack.getDefaultInstance();
        }

        public UpdateParticipantMetadata getUpdateMetadata() {
            return this.requestCase_ == 7 ? (UpdateParticipantMetadata) this.request_ : UpdateParticipantMetadata.getDefaultInstance();
        }

        public UpdateLocalVideoTrack getUpdateVideoTrack() {
            return this.requestCase_ == 9 ? (UpdateLocalVideoTrack) this.request_ : UpdateLocalVideoTrack.getDefaultInstance();
        }

        public boolean hasAddTrack() {
            return this.requestCase_ == 5;
        }

        public boolean hasMute() {
            return this.requestCase_ == 6;
        }

        public boolean hasTrickle() {
            return this.requestCase_ == 4;
        }

        public boolean hasUpdateAudioTrack() {
            return this.requestCase_ == 8;
        }

        public boolean hasUpdateMetadata() {
            return this.requestCase_ == 7;
        }

        public boolean hasUpdateVideoTrack() {
            return this.requestCase_ == 9;
        }

        public static Builder newBuilder(RequestResponse requestResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(requestResponse);
        }

        public static RequestResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RequestResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RequestResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RequestResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RequestResponse parseFrom(ByteString byteString) {
            return (RequestResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RequestResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RequestResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RequestResponse parseFrom(byte[] bArr) {
            return (RequestResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RequestResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RequestResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RequestResponse parseFrom(InputStream inputStream) {
            return (RequestResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RequestResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RequestResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RequestResponse parseFrom(CodedInputStream codedInputStream) {
            return (RequestResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RequestResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RequestResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RequestResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RoomMovedResponse extends GeneratedMessageLite<RoomMovedResponse, Builder> implements RoomMovedResponseOrBuilder {
        private static final RoomMovedResponse DEFAULT_INSTANCE;
        public static final int OTHER_PARTICIPANTS_FIELD_NUMBER = 4;
        private static volatile Parser<RoomMovedResponse> PARSER = null;
        public static final int PARTICIPANT_FIELD_NUMBER = 3;
        public static final int ROOM_FIELD_NUMBER = 1;
        public static final int TOKEN_FIELD_NUMBER = 2;
        private LivekitModels.ParticipantInfo participant_;
        private LivekitModels.Room room_;
        private String token_ = ap.a(806703491);
        private Internal.ProtobufList<LivekitModels.ParticipantInfo> otherParticipants_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RoomMovedResponse, Builder> implements RoomMovedResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RoomMovedResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            RoomMovedResponse roomMovedResponse = new RoomMovedResponse();
            DEFAULT_INSTANCE = roomMovedResponse;
            GeneratedMessageLite.registerDefaultInstance(RoomMovedResponse.class, roomMovedResponse);
        }

        private RoomMovedResponse() {
        }

        private void addAllOtherParticipants(Iterable<? extends LivekitModels.ParticipantInfo> iterable) {
            ensureOtherParticipantsIsMutable();
            AbstractMessageLite.addAll(iterable, this.otherParticipants_);
        }

        private void addOtherParticipants(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureOtherParticipantsIsMutable();
            this.otherParticipants_.add(participantInfo);
        }

        private void clearOtherParticipants() {
            this.otherParticipants_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearParticipant() {
            this.participant_ = null;
        }

        private void clearRoom() {
            this.room_ = null;
        }

        private void clearToken() {
            this.token_ = getDefaultInstance().getToken();
        }

        private void ensureOtherParticipantsIsMutable() {
            Internal.ProtobufList<LivekitModels.ParticipantInfo> protobufList = this.otherParticipants_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.otherParticipants_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static RoomMovedResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            LivekitModels.ParticipantInfo participantInfo2 = this.participant_;
            if (participantInfo2 == null || participantInfo2 == LivekitModels.ParticipantInfo.getDefaultInstance()) {
                this.participant_ = participantInfo;
            } else {
                this.participant_ = (LivekitModels.ParticipantInfo) ((LivekitModels.ParticipantInfo.Builder) LivekitModels.ParticipantInfo.newBuilder(this.participant_).v(participantInfo)).o();
            }
        }

        private void mergeRoom(LivekitModels.Room room) {
            room.getClass();
            LivekitModels.Room room2 = this.room_;
            if (room2 == null || room2 == LivekitModels.Room.getDefaultInstance()) {
                this.room_ = room;
            } else {
                this.room_ = (LivekitModels.Room) ((LivekitModels.Room.Builder) LivekitModels.Room.newBuilder(this.room_).v(room)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RoomMovedResponse parseDelimitedFrom(InputStream inputStream) {
            return (RoomMovedResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomMovedResponse parseFrom(ByteBuffer byteBuffer) {
            return (RoomMovedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RoomMovedResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeOtherParticipants(int i) {
            ensureOtherParticipantsIsMutable();
            this.otherParticipants_.remove(i);
        }

        private void setOtherParticipants(int i, LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureOtherParticipantsIsMutable();
            this.otherParticipants_.set(i, participantInfo);
        }

        private void setParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            this.participant_ = participantInfo;
        }

        private void setRoom(LivekitModels.Room room) {
            room.getClass();
            this.room_ = room;
        }

        private void setToken(String str) {
            str.getClass();
            this.token_ = str;
        }

        private void setTokenBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.token_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RoomMovedResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0001\u0000\u0001\t\u0002Ȉ\u0003\t\u0004\u001b", new Object[]{"room_", "token_", "participant_", "otherParticipants_", LivekitModels.ParticipantInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RoomMovedResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RoomMovedResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.ParticipantInfo getOtherParticipants(int i) {
            return (LivekitModels.ParticipantInfo) this.otherParticipants_.get(i);
        }

        public int getOtherParticipantsCount() {
            return this.otherParticipants_.size();
        }

        public List<LivekitModels.ParticipantInfo> getOtherParticipantsList() {
            return this.otherParticipants_;
        }

        public LivekitModels.ParticipantInfoOrBuilder getOtherParticipantsOrBuilder(int i) {
            return (LivekitModels.ParticipantInfoOrBuilder) this.otherParticipants_.get(i);
        }

        public List<? extends LivekitModels.ParticipantInfoOrBuilder> getOtherParticipantsOrBuilderList() {
            return this.otherParticipants_;
        }

        public LivekitModels.ParticipantInfo getParticipant() {
            LivekitModels.ParticipantInfo participantInfo = this.participant_;
            return participantInfo == null ? LivekitModels.ParticipantInfo.getDefaultInstance() : participantInfo;
        }

        public LivekitModels.Room getRoom() {
            LivekitModels.Room room = this.room_;
            return room == null ? LivekitModels.Room.getDefaultInstance() : room;
        }

        public String getToken() {
            return this.token_;
        }

        public ByteString getTokenBytes() {
            return ByteString.n(this.token_);
        }

        public boolean hasParticipant() {
            return this.participant_ != null;
        }

        public boolean hasRoom() {
            return this.room_ != null;
        }

        public static Builder newBuilder(RoomMovedResponse roomMovedResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(roomMovedResponse);
        }

        public static RoomMovedResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomMovedResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomMovedResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomMovedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RoomMovedResponse parseFrom(ByteString byteString) {
            return (RoomMovedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addOtherParticipants(int i, LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureOtherParticipantsIsMutable();
            this.otherParticipants_.add(i, participantInfo);
        }

        public static RoomMovedResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomMovedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RoomMovedResponse parseFrom(byte[] bArr) {
            return (RoomMovedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RoomMovedResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomMovedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RoomMovedResponse parseFrom(InputStream inputStream) {
            return (RoomMovedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomMovedResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomMovedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomMovedResponse parseFrom(CodedInputStream codedInputStream) {
            return (RoomMovedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RoomMovedResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomMovedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RoomMovedResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RoomUpdate extends GeneratedMessageLite<RoomUpdate, Builder> implements RoomUpdateOrBuilder {
        private static final RoomUpdate DEFAULT_INSTANCE;
        private static volatile Parser<RoomUpdate> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 1;
        private LivekitModels.Room room_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RoomUpdate, Builder> implements RoomUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RoomUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            RoomUpdate roomUpdate = new RoomUpdate();
            DEFAULT_INSTANCE = roomUpdate;
            GeneratedMessageLite.registerDefaultInstance(RoomUpdate.class, roomUpdate);
        }

        private RoomUpdate() {
        }

        private void clearRoom() {
            this.room_ = null;
        }

        public static RoomUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeRoom(LivekitModels.Room room) {
            room.getClass();
            LivekitModels.Room room2 = this.room_;
            if (room2 == null || room2 == LivekitModels.Room.getDefaultInstance()) {
                this.room_ = room;
            } else {
                this.room_ = (LivekitModels.Room) ((LivekitModels.Room.Builder) LivekitModels.Room.newBuilder(this.room_).v(room)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RoomUpdate parseDelimitedFrom(InputStream inputStream) {
            return (RoomUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomUpdate parseFrom(ByteBuffer byteBuffer) {
            return (RoomUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RoomUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setRoom(LivekitModels.Room room) {
            room.getClass();
            this.room_ = room;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RoomUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\t", new Object[]{ap.a(314416244)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RoomUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RoomUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.Room getRoom() {
            LivekitModels.Room room = this.room_;
            return room == null ? LivekitModels.Room.getDefaultInstance() : room;
        }

        public boolean hasRoom() {
            return this.room_ != null;
        }

        public static Builder newBuilder(RoomUpdate roomUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(roomUpdate);
        }

        public static RoomUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RoomUpdate parseFrom(ByteString byteString) {
            return (RoomUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RoomUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RoomUpdate parseFrom(byte[] bArr) {
            return (RoomUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RoomUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RoomUpdate parseFrom(InputStream inputStream) {
            return (RoomUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomUpdate parseFrom(CodedInputStream codedInputStream) {
            return (RoomUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RoomUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RoomUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SessionDescription extends GeneratedMessageLite<SessionDescription, Builder> implements SessionDescriptionOrBuilder {
        private static final SessionDescription DEFAULT_INSTANCE;
        public static final int ID_FIELD_NUMBER = 3;
        private static volatile Parser<SessionDescription> PARSER = null;
        public static final int SDP_FIELD_NUMBER = 2;
        public static final int TYPE_FIELD_NUMBER = 1;
        private int id_;
        private String sdp_;
        private String type_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SessionDescription, Builder> implements SessionDescriptionOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A() {
                q();
                ((SessionDescription) ((GeneratedMessageLite.Builder) this).b).clearId();
                return this;
            }

            public Builder B(int i) {
                q();
                ((SessionDescription) ((GeneratedMessageLite.Builder) this).b).setId(i);
                return this;
            }

            public Builder C(String str) {
                q();
                ((SessionDescription) ((GeneratedMessageLite.Builder) this).b).setSdp(str);
                return this;
            }

            public Builder D(String str) {
                q();
                ((SessionDescription) ((GeneratedMessageLite.Builder) this).b).setType(str);
                return this;
            }

            private Builder() {
                super(SessionDescription.DEFAULT_INSTANCE);
            }
        }

        static {
            SessionDescription sessionDescription = new SessionDescription();
            DEFAULT_INSTANCE = sessionDescription;
            GeneratedMessageLite.registerDefaultInstance(SessionDescription.class, sessionDescription);
        }

        private SessionDescription() {
            String strA = ap.a(764301424);
            this.type_ = strA;
            this.sdp_ = strA;
        }

        private void clearId() {
            this.id_ = 0;
        }

        private void clearSdp() {
            this.sdp_ = getDefaultInstance().getSdp();
        }

        private void clearType() {
            this.type_ = getDefaultInstance().getType();
        }

        public static SessionDescription getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SessionDescription parseDelimitedFrom(InputStream inputStream) {
            return (SessionDescription) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SessionDescription parseFrom(ByteBuffer byteBuffer) {
            return (SessionDescription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SessionDescription> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setId(int i) {
            this.id_ = i;
        }

        private void setSdp(String str) {
            str.getClass();
            this.sdp_ = str;
        }

        private void setSdpBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sdp_ = byteString.L();
        }

        private void setType(String str) {
            str.getClass();
            this.type_ = str;
        }

        private void setTypeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.type_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SessionDescription();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\u000b", new Object[]{"type_", "sdp_", "id_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SessionDescription> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SessionDescription.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getId() {
            return this.id_;
        }

        public String getSdp() {
            return this.sdp_;
        }

        public ByteString getSdpBytes() {
            return ByteString.n(this.sdp_);
        }

        public String getType() {
            return this.type_;
        }

        public ByteString getTypeBytes() {
            return ByteString.n(this.type_);
        }

        public static Builder newBuilder(SessionDescription sessionDescription) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sessionDescription);
        }

        public static SessionDescription parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SessionDescription) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SessionDescription parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SessionDescription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SessionDescription parseFrom(ByteString byteString) {
            return (SessionDescription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SessionDescription parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SessionDescription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SessionDescription parseFrom(byte[] bArr) {
            return (SessionDescription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SessionDescription parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SessionDescription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SessionDescription parseFrom(InputStream inputStream) {
            return (SessionDescription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SessionDescription parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SessionDescription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SessionDescription parseFrom(CodedInputStream codedInputStream) {
            return (SessionDescription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SessionDescription parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SessionDescription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SessionDescriptionOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SignalRequest extends GeneratedMessageLite<SignalRequest, Builder> implements SignalRequestOrBuilder {
        public static final int ADD_TRACK_FIELD_NUMBER = 4;
        public static final int ANSWER_FIELD_NUMBER = 2;
        private static final SignalRequest DEFAULT_INSTANCE;
        public static final int LEAVE_FIELD_NUMBER = 8;
        public static final int MUTE_FIELD_NUMBER = 5;
        public static final int OFFER_FIELD_NUMBER = 1;
        private static volatile Parser<SignalRequest> PARSER = null;
        public static final int PING_FIELD_NUMBER = 14;
        public static final int PING_REQ_FIELD_NUMBER = 16;
        public static final int SIMULATE_FIELD_NUMBER = 13;
        public static final int SUBSCRIPTION_FIELD_NUMBER = 6;
        public static final int SUBSCRIPTION_PERMISSION_FIELD_NUMBER = 11;
        public static final int SYNC_STATE_FIELD_NUMBER = 12;
        public static final int TRACK_SETTING_FIELD_NUMBER = 7;
        public static final int TRICKLE_FIELD_NUMBER = 3;
        public static final int UPDATE_AUDIO_TRACK_FIELD_NUMBER = 17;
        public static final int UPDATE_LAYERS_FIELD_NUMBER = 10;
        public static final int UPDATE_METADATA_FIELD_NUMBER = 15;
        public static final int UPDATE_VIDEO_TRACK_FIELD_NUMBER = 18;
        private int messageCase_ = 0;
        private Object message_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SignalRequest, Builder> implements SignalRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(AddTrackRequest.Builder builder) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setAddTrack((AddTrackRequest) builder.n());
                return this;
            }

            public Builder B(SessionDescription sessionDescription) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setAnswer(sessionDescription);
                return this;
            }

            public Builder C(LeaveRequest leaveRequest) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setLeave(leaveRequest);
                return this;
            }

            public Builder D(MuteTrackRequest muteTrackRequest) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setMute(muteTrackRequest);
                return this;
            }

            public Builder E(SessionDescription sessionDescription) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setOffer(sessionDescription);
                return this;
            }

            public Builder F(long j) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setPing(j);
                return this;
            }

            public Builder G(Ping ping) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setPingReq(ping);
                return this;
            }

            public Builder H(UpdateSubscription.Builder builder) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setSubscription((UpdateSubscription) builder.n());
                return this;
            }

            public Builder I(SyncState syncState) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setSyncState(syncState);
                return this;
            }

            public Builder J(UpdateTrackSettings.Builder builder) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setTrackSetting((UpdateTrackSettings) builder.n());
                return this;
            }

            public Builder K(TrickleRequest trickleRequest) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setTrickle(trickleRequest);
                return this;
            }

            public Builder L(UpdateLocalAudioTrack updateLocalAudioTrack) {
                q();
                ((SignalRequest) ((GeneratedMessageLite.Builder) this).b).setUpdateAudioTrack(updateLocalAudioTrack);
                return this;
            }

            private Builder() {
                super(SignalRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum MessageCase {
            b(1),
            c(2),
            d(3),
            e(4),
            f(5),
            g(6),
            h(7),
            i(8),
            j(10),
            k(11),
            l(12),
            m(13),
            n(14),
            o(15),
            p(16),
            q(17),
            r(18),
            s(0);

            private final int a;

            MessageCase(int i2) {
                this.a = i2;
            }

            public static MessageCase b(int i2) {
                switch (i2) {
                    case 0:
                        return s;
                    case 1:
                        return b;
                    case 2:
                        return c;
                    case 3:
                        return d;
                    case 4:
                        return e;
                    case 5:
                        return f;
                    case 6:
                        return g;
                    case 7:
                        return h;
                    case 8:
                        return i;
                    case 9:
                    default:
                        return null;
                    case 10:
                        return j;
                    case 11:
                        return k;
                    case 12:
                        return l;
                    case 13:
                        return m;
                    case 14:
                        return n;
                    case 15:
                        return o;
                    case 16:
                        return p;
                    case 17:
                        return q;
                    case 18:
                        return r;
                }
            }
        }

        static {
            SignalRequest signalRequest = new SignalRequest();
            DEFAULT_INSTANCE = signalRequest;
            GeneratedMessageLite.registerDefaultInstance(SignalRequest.class, signalRequest);
        }

        private SignalRequest() {
        }

        private void clearAddTrack() {
            if (this.messageCase_ == 4) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearAnswer() {
            if (this.messageCase_ == 2) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearLeave() {
            if (this.messageCase_ == 8) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearMessage() {
            this.messageCase_ = 0;
            this.message_ = null;
        }

        private void clearMute() {
            if (this.messageCase_ == 5) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearOffer() {
            if (this.messageCase_ == 1) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearPing() {
            if (this.messageCase_ == 14) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearPingReq() {
            if (this.messageCase_ == 16) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearSimulate() {
            if (this.messageCase_ == 13) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearSubscription() {
            if (this.messageCase_ == 6) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearSubscriptionPermission() {
            if (this.messageCase_ == 11) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearSyncState() {
            if (this.messageCase_ == 12) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearTrackSetting() {
            if (this.messageCase_ == 7) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearTrickle() {
            if (this.messageCase_ == 3) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearUpdateAudioTrack() {
            if (this.messageCase_ == 17) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearUpdateLayers() {
            if (this.messageCase_ == 10) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearUpdateMetadata() {
            if (this.messageCase_ == 15) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearUpdateVideoTrack() {
            if (this.messageCase_ == 18) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        public static SignalRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAddTrack(AddTrackRequest addTrackRequest) {
            addTrackRequest.getClass();
            if (this.messageCase_ != 4 || this.message_ == AddTrackRequest.getDefaultInstance()) {
                this.message_ = addTrackRequest;
            } else {
                this.message_ = ((AddTrackRequest.Builder) AddTrackRequest.newBuilder((AddTrackRequest) this.message_).v(addTrackRequest)).o();
            }
            this.messageCase_ = 4;
        }

        private void mergeAnswer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            if (this.messageCase_ != 2 || this.message_ == SessionDescription.getDefaultInstance()) {
                this.message_ = sessionDescription;
            } else {
                this.message_ = ((SessionDescription.Builder) SessionDescription.newBuilder((SessionDescription) this.message_).v(sessionDescription)).o();
            }
            this.messageCase_ = 2;
        }

        private void mergeLeave(LeaveRequest leaveRequest) {
            leaveRequest.getClass();
            if (this.messageCase_ != 8 || this.message_ == LeaveRequest.getDefaultInstance()) {
                this.message_ = leaveRequest;
            } else {
                this.message_ = ((LeaveRequest.Builder) LeaveRequest.newBuilder((LeaveRequest) this.message_).v(leaveRequest)).o();
            }
            this.messageCase_ = 8;
        }

        private void mergeMute(MuteTrackRequest muteTrackRequest) {
            muteTrackRequest.getClass();
            if (this.messageCase_ != 5 || this.message_ == MuteTrackRequest.getDefaultInstance()) {
                this.message_ = muteTrackRequest;
            } else {
                this.message_ = ((MuteTrackRequest.Builder) MuteTrackRequest.newBuilder((MuteTrackRequest) this.message_).v(muteTrackRequest)).o();
            }
            this.messageCase_ = 5;
        }

        private void mergeOffer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            if (this.messageCase_ != 1 || this.message_ == SessionDescription.getDefaultInstance()) {
                this.message_ = sessionDescription;
            } else {
                this.message_ = ((SessionDescription.Builder) SessionDescription.newBuilder((SessionDescription) this.message_).v(sessionDescription)).o();
            }
            this.messageCase_ = 1;
        }

        private void mergePingReq(Ping ping) {
            ping.getClass();
            if (this.messageCase_ != 16 || this.message_ == Ping.getDefaultInstance()) {
                this.message_ = ping;
            } else {
                this.message_ = ((Ping.Builder) Ping.newBuilder((Ping) this.message_).v(ping)).o();
            }
            this.messageCase_ = 16;
        }

        private void mergeSimulate(SimulateScenario simulateScenario) {
            simulateScenario.getClass();
            if (this.messageCase_ != 13 || this.message_ == SimulateScenario.getDefaultInstance()) {
                this.message_ = simulateScenario;
            } else {
                this.message_ = ((SimulateScenario.Builder) SimulateScenario.newBuilder((SimulateScenario) this.message_).v(simulateScenario)).o();
            }
            this.messageCase_ = 13;
        }

        private void mergeSubscription(UpdateSubscription updateSubscription) {
            updateSubscription.getClass();
            if (this.messageCase_ != 6 || this.message_ == UpdateSubscription.getDefaultInstance()) {
                this.message_ = updateSubscription;
            } else {
                this.message_ = ((UpdateSubscription.Builder) UpdateSubscription.newBuilder((UpdateSubscription) this.message_).v(updateSubscription)).o();
            }
            this.messageCase_ = 6;
        }

        private void mergeSubscriptionPermission(SubscriptionPermission subscriptionPermission) {
            subscriptionPermission.getClass();
            if (this.messageCase_ != 11 || this.message_ == SubscriptionPermission.getDefaultInstance()) {
                this.message_ = subscriptionPermission;
            } else {
                this.message_ = ((SubscriptionPermission.Builder) SubscriptionPermission.newBuilder((SubscriptionPermission) this.message_).v(subscriptionPermission)).o();
            }
            this.messageCase_ = 11;
        }

        private void mergeSyncState(SyncState syncState) {
            syncState.getClass();
            if (this.messageCase_ != 12 || this.message_ == SyncState.getDefaultInstance()) {
                this.message_ = syncState;
            } else {
                this.message_ = ((SyncState.Builder) SyncState.newBuilder((SyncState) this.message_).v(syncState)).o();
            }
            this.messageCase_ = 12;
        }

        private void mergeTrackSetting(UpdateTrackSettings updateTrackSettings) {
            updateTrackSettings.getClass();
            if (this.messageCase_ != 7 || this.message_ == UpdateTrackSettings.getDefaultInstance()) {
                this.message_ = updateTrackSettings;
            } else {
                this.message_ = ((UpdateTrackSettings.Builder) UpdateTrackSettings.newBuilder((UpdateTrackSettings) this.message_).v(updateTrackSettings)).o();
            }
            this.messageCase_ = 7;
        }

        private void mergeTrickle(TrickleRequest trickleRequest) {
            trickleRequest.getClass();
            if (this.messageCase_ != 3 || this.message_ == TrickleRequest.getDefaultInstance()) {
                this.message_ = trickleRequest;
            } else {
                this.message_ = ((TrickleRequest.Builder) TrickleRequest.newBuilder((TrickleRequest) this.message_).v(trickleRequest)).o();
            }
            this.messageCase_ = 3;
        }

        private void mergeUpdateAudioTrack(UpdateLocalAudioTrack updateLocalAudioTrack) {
            updateLocalAudioTrack.getClass();
            if (this.messageCase_ != 17 || this.message_ == UpdateLocalAudioTrack.getDefaultInstance()) {
                this.message_ = updateLocalAudioTrack;
            } else {
                this.message_ = ((UpdateLocalAudioTrack.Builder) UpdateLocalAudioTrack.newBuilder((UpdateLocalAudioTrack) this.message_).v(updateLocalAudioTrack)).o();
            }
            this.messageCase_ = 17;
        }

        private void mergeUpdateLayers(UpdateVideoLayers updateVideoLayers) {
            updateVideoLayers.getClass();
            if (this.messageCase_ != 10 || this.message_ == UpdateVideoLayers.getDefaultInstance()) {
                this.message_ = updateVideoLayers;
            } else {
                this.message_ = ((UpdateVideoLayers.Builder) UpdateVideoLayers.newBuilder((UpdateVideoLayers) this.message_).v(updateVideoLayers)).o();
            }
            this.messageCase_ = 10;
        }

        private void mergeUpdateMetadata(UpdateParticipantMetadata updateParticipantMetadata) {
            updateParticipantMetadata.getClass();
            if (this.messageCase_ != 15 || this.message_ == UpdateParticipantMetadata.getDefaultInstance()) {
                this.message_ = updateParticipantMetadata;
            } else {
                this.message_ = ((UpdateParticipantMetadata.Builder) UpdateParticipantMetadata.newBuilder((UpdateParticipantMetadata) this.message_).v(updateParticipantMetadata)).o();
            }
            this.messageCase_ = 15;
        }

        private void mergeUpdateVideoTrack(UpdateLocalVideoTrack updateLocalVideoTrack) {
            updateLocalVideoTrack.getClass();
            if (this.messageCase_ != 18 || this.message_ == UpdateLocalVideoTrack.getDefaultInstance()) {
                this.message_ = updateLocalVideoTrack;
            } else {
                this.message_ = ((UpdateLocalVideoTrack.Builder) UpdateLocalVideoTrack.newBuilder((UpdateLocalVideoTrack) this.message_).v(updateLocalVideoTrack)).o();
            }
            this.messageCase_ = 18;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SignalRequest parseDelimitedFrom(InputStream inputStream) {
            return (SignalRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SignalRequest parseFrom(ByteBuffer byteBuffer) {
            return (SignalRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SignalRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAddTrack(AddTrackRequest addTrackRequest) {
            addTrackRequest.getClass();
            this.message_ = addTrackRequest;
            this.messageCase_ = 4;
        }

        private void setAnswer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            this.message_ = sessionDescription;
            this.messageCase_ = 2;
        }

        private void setLeave(LeaveRequest leaveRequest) {
            leaveRequest.getClass();
            this.message_ = leaveRequest;
            this.messageCase_ = 8;
        }

        private void setMute(MuteTrackRequest muteTrackRequest) {
            muteTrackRequest.getClass();
            this.message_ = muteTrackRequest;
            this.messageCase_ = 5;
        }

        private void setOffer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            this.message_ = sessionDescription;
            this.messageCase_ = 1;
        }

        private void setPing(long j) {
            this.messageCase_ = 14;
            this.message_ = Long.valueOf(j);
        }

        private void setPingReq(Ping ping) {
            ping.getClass();
            this.message_ = ping;
            this.messageCase_ = 16;
        }

        private void setSimulate(SimulateScenario simulateScenario) {
            simulateScenario.getClass();
            this.message_ = simulateScenario;
            this.messageCase_ = 13;
        }

        private void setSubscription(UpdateSubscription updateSubscription) {
            updateSubscription.getClass();
            this.message_ = updateSubscription;
            this.messageCase_ = 6;
        }

        private void setSubscriptionPermission(SubscriptionPermission subscriptionPermission) {
            subscriptionPermission.getClass();
            this.message_ = subscriptionPermission;
            this.messageCase_ = 11;
        }

        private void setSyncState(SyncState syncState) {
            syncState.getClass();
            this.message_ = syncState;
            this.messageCase_ = 12;
        }

        private void setTrackSetting(UpdateTrackSettings updateTrackSettings) {
            updateTrackSettings.getClass();
            this.message_ = updateTrackSettings;
            this.messageCase_ = 7;
        }

        private void setTrickle(TrickleRequest trickleRequest) {
            trickleRequest.getClass();
            this.message_ = trickleRequest;
            this.messageCase_ = 3;
        }

        private void setUpdateAudioTrack(UpdateLocalAudioTrack updateLocalAudioTrack) {
            updateLocalAudioTrack.getClass();
            this.message_ = updateLocalAudioTrack;
            this.messageCase_ = 17;
        }

        private void setUpdateLayers(UpdateVideoLayers updateVideoLayers) {
            updateVideoLayers.getClass();
            this.message_ = updateVideoLayers;
            this.messageCase_ = 10;
        }

        private void setUpdateMetadata(UpdateParticipantMetadata updateParticipantMetadata) {
            updateParticipantMetadata.getClass();
            this.message_ = updateParticipantMetadata;
            this.messageCase_ = 15;
        }

        private void setUpdateVideoTrack(UpdateLocalVideoTrack updateLocalVideoTrack) {
            updateLocalVideoTrack.getClass();
            this.message_ = updateLocalVideoTrack;
            this.messageCase_ = 18;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new SignalRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0011\u0001\u0000\u0001\u0012\u0011\u0000\u0000\u0000\u0001<\u0000\u0002<\u0000\u0003<\u0000\u0004<\u0000\u0005<\u0000\u0006<\u0000\u0007<\u0000\b<\u0000\n<\u0000\u000b<\u0000\f<\u0000\r<\u0000\u000e5\u0000\u000f<\u0000\u0010<\u0000\u0011<\u0000\u0012<\u0000", new Object[]{ap.a(1974686856), ap.a(1855384046), SessionDescription.class, SessionDescription.class, TrickleRequest.class, AddTrackRequest.class, MuteTrackRequest.class, UpdateSubscription.class, UpdateTrackSettings.class, LeaveRequest.class, UpdateVideoLayers.class, SubscriptionPermission.class, SyncState.class, SimulateScenario.class, UpdateParticipantMetadata.class, Ping.class, UpdateLocalAudioTrack.class, UpdateLocalVideoTrack.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SignalRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SignalRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AddTrackRequest getAddTrack() {
            return this.messageCase_ == 4 ? (AddTrackRequest) this.message_ : AddTrackRequest.getDefaultInstance();
        }

        public SessionDescription getAnswer() {
            return this.messageCase_ == 2 ? (SessionDescription) this.message_ : SessionDescription.getDefaultInstance();
        }

        public LeaveRequest getLeave() {
            return this.messageCase_ == 8 ? (LeaveRequest) this.message_ : LeaveRequest.getDefaultInstance();
        }

        public MessageCase getMessageCase() {
            return MessageCase.b(this.messageCase_);
        }

        public MuteTrackRequest getMute() {
            return this.messageCase_ == 5 ? (MuteTrackRequest) this.message_ : MuteTrackRequest.getDefaultInstance();
        }

        public SessionDescription getOffer() {
            return this.messageCase_ == 1 ? (SessionDescription) this.message_ : SessionDescription.getDefaultInstance();
        }

        public long getPing() {
            if (this.messageCase_ == 14) {
                return ((Long) this.message_).longValue();
            }
            return 0L;
        }

        public Ping getPingReq() {
            return this.messageCase_ == 16 ? (Ping) this.message_ : Ping.getDefaultInstance();
        }

        public SimulateScenario getSimulate() {
            return this.messageCase_ == 13 ? (SimulateScenario) this.message_ : SimulateScenario.getDefaultInstance();
        }

        public UpdateSubscription getSubscription() {
            return this.messageCase_ == 6 ? (UpdateSubscription) this.message_ : UpdateSubscription.getDefaultInstance();
        }

        public SubscriptionPermission getSubscriptionPermission() {
            return this.messageCase_ == 11 ? (SubscriptionPermission) this.message_ : SubscriptionPermission.getDefaultInstance();
        }

        public SyncState getSyncState() {
            return this.messageCase_ == 12 ? (SyncState) this.message_ : SyncState.getDefaultInstance();
        }

        public UpdateTrackSettings getTrackSetting() {
            return this.messageCase_ == 7 ? (UpdateTrackSettings) this.message_ : UpdateTrackSettings.getDefaultInstance();
        }

        public TrickleRequest getTrickle() {
            return this.messageCase_ == 3 ? (TrickleRequest) this.message_ : TrickleRequest.getDefaultInstance();
        }

        public UpdateLocalAudioTrack getUpdateAudioTrack() {
            return this.messageCase_ == 17 ? (UpdateLocalAudioTrack) this.message_ : UpdateLocalAudioTrack.getDefaultInstance();
        }

        @Deprecated
        public UpdateVideoLayers getUpdateLayers() {
            return this.messageCase_ == 10 ? (UpdateVideoLayers) this.message_ : UpdateVideoLayers.getDefaultInstance();
        }

        public UpdateParticipantMetadata getUpdateMetadata() {
            return this.messageCase_ == 15 ? (UpdateParticipantMetadata) this.message_ : UpdateParticipantMetadata.getDefaultInstance();
        }

        public UpdateLocalVideoTrack getUpdateVideoTrack() {
            return this.messageCase_ == 18 ? (UpdateLocalVideoTrack) this.message_ : UpdateLocalVideoTrack.getDefaultInstance();
        }

        public boolean hasAddTrack() {
            return this.messageCase_ == 4;
        }

        public boolean hasAnswer() {
            return this.messageCase_ == 2;
        }

        public boolean hasLeave() {
            return this.messageCase_ == 8;
        }

        public boolean hasMute() {
            return this.messageCase_ == 5;
        }

        public boolean hasOffer() {
            return this.messageCase_ == 1;
        }

        public boolean hasPing() {
            return this.messageCase_ == 14;
        }

        public boolean hasPingReq() {
            return this.messageCase_ == 16;
        }

        public boolean hasSimulate() {
            return this.messageCase_ == 13;
        }

        public boolean hasSubscription() {
            return this.messageCase_ == 6;
        }

        public boolean hasSubscriptionPermission() {
            return this.messageCase_ == 11;
        }

        public boolean hasSyncState() {
            return this.messageCase_ == 12;
        }

        public boolean hasTrackSetting() {
            return this.messageCase_ == 7;
        }

        public boolean hasTrickle() {
            return this.messageCase_ == 3;
        }

        public boolean hasUpdateAudioTrack() {
            return this.messageCase_ == 17;
        }

        @Deprecated
        public boolean hasUpdateLayers() {
            return this.messageCase_ == 10;
        }

        public boolean hasUpdateMetadata() {
            return this.messageCase_ == 15;
        }

        public boolean hasUpdateVideoTrack() {
            return this.messageCase_ == 18;
        }

        public static Builder newBuilder(SignalRequest signalRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(signalRequest);
        }

        public static SignalRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SignalRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SignalRequest parseFrom(ByteString byteString) {
            return (SignalRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SignalRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SignalRequest parseFrom(byte[] bArr) {
            return (SignalRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SignalRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SignalRequest parseFrom(InputStream inputStream) {
            return (SignalRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SignalRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SignalRequest parseFrom(CodedInputStream codedInputStream) {
            return (SignalRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SignalRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SignalRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SignalResponse extends GeneratedMessageLite<SignalResponse, Builder> implements SignalResponseOrBuilder {
        public static final int ANSWER_FIELD_NUMBER = 2;
        public static final int CONNECTION_QUALITY_FIELD_NUMBER = 12;
        private static final SignalResponse DEFAULT_INSTANCE;
        public static final int JOIN_FIELD_NUMBER = 1;
        public static final int LEAVE_FIELD_NUMBER = 8;
        public static final int MEDIA_SECTIONS_REQUIREMENT_FIELD_NUMBER = 25;
        public static final int MUTE_FIELD_NUMBER = 9;
        public static final int OFFER_FIELD_NUMBER = 3;
        private static volatile Parser<SignalResponse> PARSER = null;
        public static final int PONG_FIELD_NUMBER = 18;
        public static final int PONG_RESP_FIELD_NUMBER = 20;
        public static final int RECONNECT_FIELD_NUMBER = 19;
        public static final int REFRESH_TOKEN_FIELD_NUMBER = 16;
        public static final int REQUEST_RESPONSE_FIELD_NUMBER = 22;
        public static final int ROOM_MOVED_FIELD_NUMBER = 24;
        public static final int ROOM_UPDATE_FIELD_NUMBER = 11;
        public static final int SPEAKERS_CHANGED_FIELD_NUMBER = 10;
        public static final int STREAM_STATE_UPDATE_FIELD_NUMBER = 13;
        public static final int SUBSCRIBED_AUDIO_CODEC_UPDATE_FIELD_NUMBER = 26;
        public static final int SUBSCRIBED_QUALITY_UPDATE_FIELD_NUMBER = 14;
        public static final int SUBSCRIPTION_PERMISSION_UPDATE_FIELD_NUMBER = 15;
        public static final int SUBSCRIPTION_RESPONSE_FIELD_NUMBER = 21;
        public static final int TRACK_PUBLISHED_FIELD_NUMBER = 6;
        public static final int TRACK_SUBSCRIBED_FIELD_NUMBER = 23;
        public static final int TRACK_UNPUBLISHED_FIELD_NUMBER = 17;
        public static final int TRICKLE_FIELD_NUMBER = 4;
        public static final int UPDATE_FIELD_NUMBER = 5;
        private int messageCase_ = 0;
        private Object message_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SignalResponse, Builder> implements SignalResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SignalResponse.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum MessageCase {
            b(1),
            c(2),
            d(3),
            e(4),
            f(5),
            g(6),
            h(8),
            i(9),
            j(10),
            k(11),
            l(12),
            m(13),
            n(14),
            o(15),
            p(16),
            q(17),
            r(18),
            s(19),
            t(20),
            u(21),
            v(22),
            w(23),
            x(24),
            y(25),
            z(26),
            A(0);

            private final int a;

            MessageCase(int i2) {
                this.a = i2;
            }

            public static MessageCase b(int i2) {
                switch (i2) {
                    case 0:
                        return A;
                    case 1:
                        return b;
                    case 2:
                        return c;
                    case 3:
                        return d;
                    case 4:
                        return e;
                    case 5:
                        return f;
                    case 6:
                        return g;
                    case 7:
                    default:
                        return null;
                    case 8:
                        return h;
                    case 9:
                        return i;
                    case 10:
                        return j;
                    case 11:
                        return k;
                    case 12:
                        return l;
                    case 13:
                        return m;
                    case 14:
                        return n;
                    case 15:
                        return o;
                    case 16:
                        return p;
                    case 17:
                        return q;
                    case 18:
                        return r;
                    case 19:
                        return s;
                    case 20:
                        return t;
                    case 21:
                        return u;
                    case 22:
                        return v;
                    case 23:
                        return w;
                    case 24:
                        return x;
                    case 25:
                        return y;
                    case 26:
                        return z;
                }
            }
        }

        static {
            SignalResponse signalResponse = new SignalResponse();
            DEFAULT_INSTANCE = signalResponse;
            GeneratedMessageLite.registerDefaultInstance(SignalResponse.class, signalResponse);
        }

        private SignalResponse() {
        }

        private void clearAnswer() {
            if (this.messageCase_ == 2) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearConnectionQuality() {
            if (this.messageCase_ == 12) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearJoin() {
            if (this.messageCase_ == 1) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearLeave() {
            if (this.messageCase_ == 8) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearMediaSectionsRequirement() {
            if (this.messageCase_ == 25) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearMessage() {
            this.messageCase_ = 0;
            this.message_ = null;
        }

        private void clearMute() {
            if (this.messageCase_ == 9) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearOffer() {
            if (this.messageCase_ == 3) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearPong() {
            if (this.messageCase_ == 18) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearPongResp() {
            if (this.messageCase_ == 20) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearReconnect() {
            if (this.messageCase_ == 19) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearRefreshToken() {
            if (this.messageCase_ == 16) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearRequestResponse() {
            if (this.messageCase_ == 22) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearRoomMoved() {
            if (this.messageCase_ == 24) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearRoomUpdate() {
            if (this.messageCase_ == 11) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearSpeakersChanged() {
            if (this.messageCase_ == 10) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearStreamStateUpdate() {
            if (this.messageCase_ == 13) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearSubscribedAudioCodecUpdate() {
            if (this.messageCase_ == 26) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearSubscribedQualityUpdate() {
            if (this.messageCase_ == 14) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearSubscriptionPermissionUpdate() {
            if (this.messageCase_ == 15) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearSubscriptionResponse() {
            if (this.messageCase_ == 21) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearTrackPublished() {
            if (this.messageCase_ == 6) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearTrackSubscribed() {
            if (this.messageCase_ == 23) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearTrackUnpublished() {
            if (this.messageCase_ == 17) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearTrickle() {
            if (this.messageCase_ == 4) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearUpdate() {
            if (this.messageCase_ == 5) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        public static SignalResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAnswer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            if (this.messageCase_ != 2 || this.message_ == SessionDescription.getDefaultInstance()) {
                this.message_ = sessionDescription;
            } else {
                this.message_ = ((SessionDescription.Builder) SessionDescription.newBuilder((SessionDescription) this.message_).v(sessionDescription)).o();
            }
            this.messageCase_ = 2;
        }

        private void mergeConnectionQuality(ConnectionQualityUpdate connectionQualityUpdate) {
            connectionQualityUpdate.getClass();
            if (this.messageCase_ != 12 || this.message_ == ConnectionQualityUpdate.getDefaultInstance()) {
                this.message_ = connectionQualityUpdate;
            } else {
                this.message_ = ((ConnectionQualityUpdate.Builder) ConnectionQualityUpdate.newBuilder((ConnectionQualityUpdate) this.message_).v(connectionQualityUpdate)).o();
            }
            this.messageCase_ = 12;
        }

        private void mergeJoin(JoinResponse joinResponse) {
            joinResponse.getClass();
            if (this.messageCase_ != 1 || this.message_ == JoinResponse.getDefaultInstance()) {
                this.message_ = joinResponse;
            } else {
                this.message_ = ((JoinResponse.Builder) JoinResponse.newBuilder((JoinResponse) this.message_).v(joinResponse)).o();
            }
            this.messageCase_ = 1;
        }

        private void mergeLeave(LeaveRequest leaveRequest) {
            leaveRequest.getClass();
            if (this.messageCase_ != 8 || this.message_ == LeaveRequest.getDefaultInstance()) {
                this.message_ = leaveRequest;
            } else {
                this.message_ = ((LeaveRequest.Builder) LeaveRequest.newBuilder((LeaveRequest) this.message_).v(leaveRequest)).o();
            }
            this.messageCase_ = 8;
        }

        private void mergeMediaSectionsRequirement(MediaSectionsRequirement mediaSectionsRequirement) {
            mediaSectionsRequirement.getClass();
            if (this.messageCase_ != 25 || this.message_ == MediaSectionsRequirement.getDefaultInstance()) {
                this.message_ = mediaSectionsRequirement;
            } else {
                this.message_ = ((MediaSectionsRequirement.Builder) MediaSectionsRequirement.newBuilder((MediaSectionsRequirement) this.message_).v(mediaSectionsRequirement)).o();
            }
            this.messageCase_ = 25;
        }

        private void mergeMute(MuteTrackRequest muteTrackRequest) {
            muteTrackRequest.getClass();
            if (this.messageCase_ != 9 || this.message_ == MuteTrackRequest.getDefaultInstance()) {
                this.message_ = muteTrackRequest;
            } else {
                this.message_ = ((MuteTrackRequest.Builder) MuteTrackRequest.newBuilder((MuteTrackRequest) this.message_).v(muteTrackRequest)).o();
            }
            this.messageCase_ = 9;
        }

        private void mergeOffer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            if (this.messageCase_ != 3 || this.message_ == SessionDescription.getDefaultInstance()) {
                this.message_ = sessionDescription;
            } else {
                this.message_ = ((SessionDescription.Builder) SessionDescription.newBuilder((SessionDescription) this.message_).v(sessionDescription)).o();
            }
            this.messageCase_ = 3;
        }

        private void mergePongResp(Pong pong) {
            pong.getClass();
            if (this.messageCase_ != 20 || this.message_ == Pong.getDefaultInstance()) {
                this.message_ = pong;
            } else {
                this.message_ = ((Pong.Builder) Pong.newBuilder((Pong) this.message_).v(pong)).o();
            }
            this.messageCase_ = 20;
        }

        private void mergeReconnect(ReconnectResponse reconnectResponse) {
            reconnectResponse.getClass();
            if (this.messageCase_ != 19 || this.message_ == ReconnectResponse.getDefaultInstance()) {
                this.message_ = reconnectResponse;
            } else {
                this.message_ = ((ReconnectResponse.Builder) ReconnectResponse.newBuilder((ReconnectResponse) this.message_).v(reconnectResponse)).o();
            }
            this.messageCase_ = 19;
        }

        private void mergeRequestResponse(RequestResponse requestResponse) {
            requestResponse.getClass();
            if (this.messageCase_ != 22 || this.message_ == RequestResponse.getDefaultInstance()) {
                this.message_ = requestResponse;
            } else {
                this.message_ = ((RequestResponse.Builder) RequestResponse.newBuilder((RequestResponse) this.message_).v(requestResponse)).o();
            }
            this.messageCase_ = 22;
        }

        private void mergeRoomMoved(RoomMovedResponse roomMovedResponse) {
            roomMovedResponse.getClass();
            if (this.messageCase_ != 24 || this.message_ == RoomMovedResponse.getDefaultInstance()) {
                this.message_ = roomMovedResponse;
            } else {
                this.message_ = ((RoomMovedResponse.Builder) RoomMovedResponse.newBuilder((RoomMovedResponse) this.message_).v(roomMovedResponse)).o();
            }
            this.messageCase_ = 24;
        }

        private void mergeRoomUpdate(RoomUpdate roomUpdate) {
            roomUpdate.getClass();
            if (this.messageCase_ != 11 || this.message_ == RoomUpdate.getDefaultInstance()) {
                this.message_ = roomUpdate;
            } else {
                this.message_ = ((RoomUpdate.Builder) RoomUpdate.newBuilder((RoomUpdate) this.message_).v(roomUpdate)).o();
            }
            this.messageCase_ = 11;
        }

        private void mergeSpeakersChanged(SpeakersChanged speakersChanged) {
            speakersChanged.getClass();
            if (this.messageCase_ != 10 || this.message_ == SpeakersChanged.getDefaultInstance()) {
                this.message_ = speakersChanged;
            } else {
                this.message_ = ((SpeakersChanged.Builder) SpeakersChanged.newBuilder((SpeakersChanged) this.message_).v(speakersChanged)).o();
            }
            this.messageCase_ = 10;
        }

        private void mergeStreamStateUpdate(StreamStateUpdate streamStateUpdate) {
            streamStateUpdate.getClass();
            if (this.messageCase_ != 13 || this.message_ == StreamStateUpdate.getDefaultInstance()) {
                this.message_ = streamStateUpdate;
            } else {
                this.message_ = ((StreamStateUpdate.Builder) StreamStateUpdate.newBuilder((StreamStateUpdate) this.message_).v(streamStateUpdate)).o();
            }
            this.messageCase_ = 13;
        }

        private void mergeSubscribedAudioCodecUpdate(SubscribedAudioCodecUpdate subscribedAudioCodecUpdate) {
            subscribedAudioCodecUpdate.getClass();
            if (this.messageCase_ != 26 || this.message_ == SubscribedAudioCodecUpdate.getDefaultInstance()) {
                this.message_ = subscribedAudioCodecUpdate;
            } else {
                this.message_ = ((SubscribedAudioCodecUpdate.Builder) SubscribedAudioCodecUpdate.newBuilder((SubscribedAudioCodecUpdate) this.message_).v(subscribedAudioCodecUpdate)).o();
            }
            this.messageCase_ = 26;
        }

        private void mergeSubscribedQualityUpdate(SubscribedQualityUpdate subscribedQualityUpdate) {
            subscribedQualityUpdate.getClass();
            if (this.messageCase_ != 14 || this.message_ == SubscribedQualityUpdate.getDefaultInstance()) {
                this.message_ = subscribedQualityUpdate;
            } else {
                this.message_ = ((SubscribedQualityUpdate.Builder) SubscribedQualityUpdate.newBuilder((SubscribedQualityUpdate) this.message_).v(subscribedQualityUpdate)).o();
            }
            this.messageCase_ = 14;
        }

        private void mergeSubscriptionPermissionUpdate(SubscriptionPermissionUpdate subscriptionPermissionUpdate) {
            subscriptionPermissionUpdate.getClass();
            if (this.messageCase_ != 15 || this.message_ == SubscriptionPermissionUpdate.getDefaultInstance()) {
                this.message_ = subscriptionPermissionUpdate;
            } else {
                this.message_ = ((SubscriptionPermissionUpdate.Builder) SubscriptionPermissionUpdate.newBuilder((SubscriptionPermissionUpdate) this.message_).v(subscriptionPermissionUpdate)).o();
            }
            this.messageCase_ = 15;
        }

        private void mergeSubscriptionResponse(SubscriptionResponse subscriptionResponse) {
            subscriptionResponse.getClass();
            if (this.messageCase_ != 21 || this.message_ == SubscriptionResponse.getDefaultInstance()) {
                this.message_ = subscriptionResponse;
            } else {
                this.message_ = ((SubscriptionResponse.Builder) SubscriptionResponse.newBuilder((SubscriptionResponse) this.message_).v(subscriptionResponse)).o();
            }
            this.messageCase_ = 21;
        }

        private void mergeTrackPublished(TrackPublishedResponse trackPublishedResponse) {
            trackPublishedResponse.getClass();
            if (this.messageCase_ != 6 || this.message_ == TrackPublishedResponse.getDefaultInstance()) {
                this.message_ = trackPublishedResponse;
            } else {
                this.message_ = ((TrackPublishedResponse.Builder) TrackPublishedResponse.newBuilder((TrackPublishedResponse) this.message_).v(trackPublishedResponse)).o();
            }
            this.messageCase_ = 6;
        }

        private void mergeTrackSubscribed(TrackSubscribed trackSubscribed) {
            trackSubscribed.getClass();
            if (this.messageCase_ != 23 || this.message_ == TrackSubscribed.getDefaultInstance()) {
                this.message_ = trackSubscribed;
            } else {
                this.message_ = ((TrackSubscribed.Builder) TrackSubscribed.newBuilder((TrackSubscribed) this.message_).v(trackSubscribed)).o();
            }
            this.messageCase_ = 23;
        }

        private void mergeTrackUnpublished(TrackUnpublishedResponse trackUnpublishedResponse) {
            trackUnpublishedResponse.getClass();
            if (this.messageCase_ != 17 || this.message_ == TrackUnpublishedResponse.getDefaultInstance()) {
                this.message_ = trackUnpublishedResponse;
            } else {
                this.message_ = ((TrackUnpublishedResponse.Builder) TrackUnpublishedResponse.newBuilder((TrackUnpublishedResponse) this.message_).v(trackUnpublishedResponse)).o();
            }
            this.messageCase_ = 17;
        }

        private void mergeTrickle(TrickleRequest trickleRequest) {
            trickleRequest.getClass();
            if (this.messageCase_ != 4 || this.message_ == TrickleRequest.getDefaultInstance()) {
                this.message_ = trickleRequest;
            } else {
                this.message_ = ((TrickleRequest.Builder) TrickleRequest.newBuilder((TrickleRequest) this.message_).v(trickleRequest)).o();
            }
            this.messageCase_ = 4;
        }

        private void mergeUpdate(ParticipantUpdate participantUpdate) {
            participantUpdate.getClass();
            if (this.messageCase_ != 5 || this.message_ == ParticipantUpdate.getDefaultInstance()) {
                this.message_ = participantUpdate;
            } else {
                this.message_ = ((ParticipantUpdate.Builder) ParticipantUpdate.newBuilder((ParticipantUpdate) this.message_).v(participantUpdate)).o();
            }
            this.messageCase_ = 5;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SignalResponse parseDelimitedFrom(InputStream inputStream) {
            return (SignalResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SignalResponse parseFrom(ByteBuffer byteBuffer) {
            return (SignalResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SignalResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAnswer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            this.message_ = sessionDescription;
            this.messageCase_ = 2;
        }

        private void setConnectionQuality(ConnectionQualityUpdate connectionQualityUpdate) {
            connectionQualityUpdate.getClass();
            this.message_ = connectionQualityUpdate;
            this.messageCase_ = 12;
        }

        private void setJoin(JoinResponse joinResponse) {
            joinResponse.getClass();
            this.message_ = joinResponse;
            this.messageCase_ = 1;
        }

        private void setLeave(LeaveRequest leaveRequest) {
            leaveRequest.getClass();
            this.message_ = leaveRequest;
            this.messageCase_ = 8;
        }

        private void setMediaSectionsRequirement(MediaSectionsRequirement mediaSectionsRequirement) {
            mediaSectionsRequirement.getClass();
            this.message_ = mediaSectionsRequirement;
            this.messageCase_ = 25;
        }

        private void setMute(MuteTrackRequest muteTrackRequest) {
            muteTrackRequest.getClass();
            this.message_ = muteTrackRequest;
            this.messageCase_ = 9;
        }

        private void setOffer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            this.message_ = sessionDescription;
            this.messageCase_ = 3;
        }

        private void setPong(long j) {
            this.messageCase_ = 18;
            this.message_ = Long.valueOf(j);
        }

        private void setPongResp(Pong pong) {
            pong.getClass();
            this.message_ = pong;
            this.messageCase_ = 20;
        }

        private void setReconnect(ReconnectResponse reconnectResponse) {
            reconnectResponse.getClass();
            this.message_ = reconnectResponse;
            this.messageCase_ = 19;
        }

        private void setRefreshToken(String str) {
            str.getClass();
            this.messageCase_ = 16;
            this.message_ = str;
        }

        private void setRefreshTokenBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.message_ = byteString.L();
            this.messageCase_ = 16;
        }

        private void setRequestResponse(RequestResponse requestResponse) {
            requestResponse.getClass();
            this.message_ = requestResponse;
            this.messageCase_ = 22;
        }

        private void setRoomMoved(RoomMovedResponse roomMovedResponse) {
            roomMovedResponse.getClass();
            this.message_ = roomMovedResponse;
            this.messageCase_ = 24;
        }

        private void setRoomUpdate(RoomUpdate roomUpdate) {
            roomUpdate.getClass();
            this.message_ = roomUpdate;
            this.messageCase_ = 11;
        }

        private void setSpeakersChanged(SpeakersChanged speakersChanged) {
            speakersChanged.getClass();
            this.message_ = speakersChanged;
            this.messageCase_ = 10;
        }

        private void setStreamStateUpdate(StreamStateUpdate streamStateUpdate) {
            streamStateUpdate.getClass();
            this.message_ = streamStateUpdate;
            this.messageCase_ = 13;
        }

        private void setSubscribedAudioCodecUpdate(SubscribedAudioCodecUpdate subscribedAudioCodecUpdate) {
            subscribedAudioCodecUpdate.getClass();
            this.message_ = subscribedAudioCodecUpdate;
            this.messageCase_ = 26;
        }

        private void setSubscribedQualityUpdate(SubscribedQualityUpdate subscribedQualityUpdate) {
            subscribedQualityUpdate.getClass();
            this.message_ = subscribedQualityUpdate;
            this.messageCase_ = 14;
        }

        private void setSubscriptionPermissionUpdate(SubscriptionPermissionUpdate subscriptionPermissionUpdate) {
            subscriptionPermissionUpdate.getClass();
            this.message_ = subscriptionPermissionUpdate;
            this.messageCase_ = 15;
        }

        private void setSubscriptionResponse(SubscriptionResponse subscriptionResponse) {
            subscriptionResponse.getClass();
            this.message_ = subscriptionResponse;
            this.messageCase_ = 21;
        }

        private void setTrackPublished(TrackPublishedResponse trackPublishedResponse) {
            trackPublishedResponse.getClass();
            this.message_ = trackPublishedResponse;
            this.messageCase_ = 6;
        }

        private void setTrackSubscribed(TrackSubscribed trackSubscribed) {
            trackSubscribed.getClass();
            this.message_ = trackSubscribed;
            this.messageCase_ = 23;
        }

        private void setTrackUnpublished(TrackUnpublishedResponse trackUnpublishedResponse) {
            trackUnpublishedResponse.getClass();
            this.message_ = trackUnpublishedResponse;
            this.messageCase_ = 17;
        }

        private void setTrickle(TrickleRequest trickleRequest) {
            trickleRequest.getClass();
            this.message_ = trickleRequest;
            this.messageCase_ = 4;
        }

        private void setUpdate(ParticipantUpdate participantUpdate) {
            participantUpdate.getClass();
            this.message_ = participantUpdate;
            this.messageCase_ = 5;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new SignalResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0019\u0001\u0000\u0001\u001a\u0019\u0000\u0000\u0000\u0001<\u0000\u0002<\u0000\u0003<\u0000\u0004<\u0000\u0005<\u0000\u0006<\u0000\b<\u0000\t<\u0000\n<\u0000\u000b<\u0000\f<\u0000\r<\u0000\u000e<\u0000\u000f<\u0000\u0010Ȼ\u0000\u0011<\u0000\u00125\u0000\u0013<\u0000\u0014<\u0000\u0015<\u0000\u0016<\u0000\u0017<\u0000\u0018<\u0000\u0019<\u0000\u001a<\u0000", new Object[]{ap.a(753298321), ap.a(30954478), JoinResponse.class, SessionDescription.class, SessionDescription.class, TrickleRequest.class, ParticipantUpdate.class, TrackPublishedResponse.class, LeaveRequest.class, MuteTrackRequest.class, SpeakersChanged.class, RoomUpdate.class, ConnectionQualityUpdate.class, StreamStateUpdate.class, SubscribedQualityUpdate.class, SubscriptionPermissionUpdate.class, TrackUnpublishedResponse.class, ReconnectResponse.class, Pong.class, SubscriptionResponse.class, RequestResponse.class, TrackSubscribed.class, RoomMovedResponse.class, MediaSectionsRequirement.class, SubscribedAudioCodecUpdate.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SignalResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SignalResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SessionDescription getAnswer() {
            return this.messageCase_ == 2 ? (SessionDescription) this.message_ : SessionDescription.getDefaultInstance();
        }

        public ConnectionQualityUpdate getConnectionQuality() {
            return this.messageCase_ == 12 ? (ConnectionQualityUpdate) this.message_ : ConnectionQualityUpdate.getDefaultInstance();
        }

        public JoinResponse getJoin() {
            return this.messageCase_ == 1 ? (JoinResponse) this.message_ : JoinResponse.getDefaultInstance();
        }

        public LeaveRequest getLeave() {
            return this.messageCase_ == 8 ? (LeaveRequest) this.message_ : LeaveRequest.getDefaultInstance();
        }

        public MediaSectionsRequirement getMediaSectionsRequirement() {
            return this.messageCase_ == 25 ? (MediaSectionsRequirement) this.message_ : MediaSectionsRequirement.getDefaultInstance();
        }

        public MessageCase getMessageCase() {
            return MessageCase.b(this.messageCase_);
        }

        public MuteTrackRequest getMute() {
            return this.messageCase_ == 9 ? (MuteTrackRequest) this.message_ : MuteTrackRequest.getDefaultInstance();
        }

        public SessionDescription getOffer() {
            return this.messageCase_ == 3 ? (SessionDescription) this.message_ : SessionDescription.getDefaultInstance();
        }

        public long getPong() {
            if (this.messageCase_ == 18) {
                return ((Long) this.message_).longValue();
            }
            return 0L;
        }

        public Pong getPongResp() {
            return this.messageCase_ == 20 ? (Pong) this.message_ : Pong.getDefaultInstance();
        }

        public ReconnectResponse getReconnect() {
            return this.messageCase_ == 19 ? (ReconnectResponse) this.message_ : ReconnectResponse.getDefaultInstance();
        }

        public String getRefreshToken() {
            return this.messageCase_ == 16 ? (String) this.message_ : StringUtils.EMPTY;
        }

        public ByteString getRefreshTokenBytes() {
            return ByteString.n(this.messageCase_ == 16 ? (String) this.message_ : StringUtils.EMPTY);
        }

        public RequestResponse getRequestResponse() {
            return this.messageCase_ == 22 ? (RequestResponse) this.message_ : RequestResponse.getDefaultInstance();
        }

        public RoomMovedResponse getRoomMoved() {
            return this.messageCase_ == 24 ? (RoomMovedResponse) this.message_ : RoomMovedResponse.getDefaultInstance();
        }

        public RoomUpdate getRoomUpdate() {
            return this.messageCase_ == 11 ? (RoomUpdate) this.message_ : RoomUpdate.getDefaultInstance();
        }

        public SpeakersChanged getSpeakersChanged() {
            return this.messageCase_ == 10 ? (SpeakersChanged) this.message_ : SpeakersChanged.getDefaultInstance();
        }

        public StreamStateUpdate getStreamStateUpdate() {
            return this.messageCase_ == 13 ? (StreamStateUpdate) this.message_ : StreamStateUpdate.getDefaultInstance();
        }

        public SubscribedAudioCodecUpdate getSubscribedAudioCodecUpdate() {
            return this.messageCase_ == 26 ? (SubscribedAudioCodecUpdate) this.message_ : SubscribedAudioCodecUpdate.getDefaultInstance();
        }

        public SubscribedQualityUpdate getSubscribedQualityUpdate() {
            return this.messageCase_ == 14 ? (SubscribedQualityUpdate) this.message_ : SubscribedQualityUpdate.getDefaultInstance();
        }

        public SubscriptionPermissionUpdate getSubscriptionPermissionUpdate() {
            return this.messageCase_ == 15 ? (SubscriptionPermissionUpdate) this.message_ : SubscriptionPermissionUpdate.getDefaultInstance();
        }

        public SubscriptionResponse getSubscriptionResponse() {
            return this.messageCase_ == 21 ? (SubscriptionResponse) this.message_ : SubscriptionResponse.getDefaultInstance();
        }

        public TrackPublishedResponse getTrackPublished() {
            return this.messageCase_ == 6 ? (TrackPublishedResponse) this.message_ : TrackPublishedResponse.getDefaultInstance();
        }

        public TrackSubscribed getTrackSubscribed() {
            return this.messageCase_ == 23 ? (TrackSubscribed) this.message_ : TrackSubscribed.getDefaultInstance();
        }

        public TrackUnpublishedResponse getTrackUnpublished() {
            return this.messageCase_ == 17 ? (TrackUnpublishedResponse) this.message_ : TrackUnpublishedResponse.getDefaultInstance();
        }

        public TrickleRequest getTrickle() {
            return this.messageCase_ == 4 ? (TrickleRequest) this.message_ : TrickleRequest.getDefaultInstance();
        }

        public ParticipantUpdate getUpdate() {
            return this.messageCase_ == 5 ? (ParticipantUpdate) this.message_ : ParticipantUpdate.getDefaultInstance();
        }

        public boolean hasAnswer() {
            return this.messageCase_ == 2;
        }

        public boolean hasConnectionQuality() {
            return this.messageCase_ == 12;
        }

        public boolean hasJoin() {
            return this.messageCase_ == 1;
        }

        public boolean hasLeave() {
            return this.messageCase_ == 8;
        }

        public boolean hasMediaSectionsRequirement() {
            return this.messageCase_ == 25;
        }

        public boolean hasMute() {
            return this.messageCase_ == 9;
        }

        public boolean hasOffer() {
            return this.messageCase_ == 3;
        }

        public boolean hasPong() {
            return this.messageCase_ == 18;
        }

        public boolean hasPongResp() {
            return this.messageCase_ == 20;
        }

        public boolean hasReconnect() {
            return this.messageCase_ == 19;
        }

        public boolean hasRefreshToken() {
            return this.messageCase_ == 16;
        }

        public boolean hasRequestResponse() {
            return this.messageCase_ == 22;
        }

        public boolean hasRoomMoved() {
            return this.messageCase_ == 24;
        }

        public boolean hasRoomUpdate() {
            return this.messageCase_ == 11;
        }

        public boolean hasSpeakersChanged() {
            return this.messageCase_ == 10;
        }

        public boolean hasStreamStateUpdate() {
            return this.messageCase_ == 13;
        }

        public boolean hasSubscribedAudioCodecUpdate() {
            return this.messageCase_ == 26;
        }

        public boolean hasSubscribedQualityUpdate() {
            return this.messageCase_ == 14;
        }

        public boolean hasSubscriptionPermissionUpdate() {
            return this.messageCase_ == 15;
        }

        public boolean hasSubscriptionResponse() {
            return this.messageCase_ == 21;
        }

        public boolean hasTrackPublished() {
            return this.messageCase_ == 6;
        }

        public boolean hasTrackSubscribed() {
            return this.messageCase_ == 23;
        }

        public boolean hasTrackUnpublished() {
            return this.messageCase_ == 17;
        }

        public boolean hasTrickle() {
            return this.messageCase_ == 4;
        }

        public boolean hasUpdate() {
            return this.messageCase_ == 5;
        }

        public static Builder newBuilder(SignalResponse signalResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(signalResponse);
        }

        public static SignalResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SignalResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SignalResponse parseFrom(ByteString byteString) {
            return (SignalResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SignalResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SignalResponse parseFrom(byte[] bArr) {
            return (SignalResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SignalResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SignalResponse parseFrom(InputStream inputStream) {
            return (SignalResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SignalResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SignalResponse parseFrom(CodedInputStream codedInputStream) {
            return (SignalResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SignalResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SignalResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SignalResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SignalTarget implements Internal.EnumLite {
        b(0),
        c(1),
        d(-1);

        private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<SignalTarget>() { // from class: livekit.LivekitRtc.SignalTarget.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SignalTarget findValueByNumber(int i) {
                return SignalTarget.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SignalTargetVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SignalTargetVerifier();

            private SignalTargetVerifier() {
            }

            public boolean isInRange(int i) {
                return SignalTarget.b(i) != null;
            }
        }

        SignalTarget(int i) {
            this.a = i;
        }

        public static SignalTarget b(int i) {
            if (i == 0) {
                return b;
            }
            if (i != 1) {
                return null;
            }
            return c;
        }

        public final int getNumber() {
            if (this != d) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SimulateScenario extends GeneratedMessageLite<SimulateScenario, Builder> implements SimulateScenarioOrBuilder {
        private static final SimulateScenario DEFAULT_INSTANCE;
        public static final int DISCONNECT_SIGNAL_ON_RESUME_FIELD_NUMBER = 7;
        public static final int DISCONNECT_SIGNAL_ON_RESUME_NO_MESSAGES_FIELD_NUMBER = 8;
        public static final int LEAVE_REQUEST_FULL_RECONNECT_FIELD_NUMBER = 9;
        public static final int MIGRATION_FIELD_NUMBER = 3;
        public static final int NODE_FAILURE_FIELD_NUMBER = 2;
        private static volatile Parser<SimulateScenario> PARSER = null;
        public static final int SERVER_LEAVE_FIELD_NUMBER = 4;
        public static final int SPEAKER_UPDATE_FIELD_NUMBER = 1;
        public static final int SUBSCRIBER_BANDWIDTH_FIELD_NUMBER = 6;
        public static final int SWITCH_CANDIDATE_PROTOCOL_FIELD_NUMBER = 5;
        private int scenarioCase_ = 0;
        private Object scenario_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SimulateScenario, Builder> implements SimulateScenarioOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SimulateScenario.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum ScenarioCase {
            b(1),
            c(2),
            d(3),
            e(4),
            f(5),
            g(6),
            h(7),
            i(8),
            j(9),
            k(0);

            private final int a;

            ScenarioCase(int i2) {
                this.a = i2;
            }

            public static ScenarioCase b(int i2) {
                switch (i2) {
                    case 0:
                        return k;
                    case 1:
                        return b;
                    case 2:
                        return c;
                    case 3:
                        return d;
                    case 4:
                        return e;
                    case 5:
                        return f;
                    case 6:
                        return g;
                    case 7:
                        return h;
                    case 8:
                        return i;
                    case 9:
                        return j;
                    default:
                        return null;
                }
            }
        }

        static {
            SimulateScenario simulateScenario = new SimulateScenario();
            DEFAULT_INSTANCE = simulateScenario;
            GeneratedMessageLite.registerDefaultInstance(SimulateScenario.class, simulateScenario);
        }

        private SimulateScenario() {
        }

        private void clearDisconnectSignalOnResume() {
            if (this.scenarioCase_ == 7) {
                this.scenarioCase_ = 0;
                this.scenario_ = null;
            }
        }

        private void clearDisconnectSignalOnResumeNoMessages() {
            if (this.scenarioCase_ == 8) {
                this.scenarioCase_ = 0;
                this.scenario_ = null;
            }
        }

        private void clearLeaveRequestFullReconnect() {
            if (this.scenarioCase_ == 9) {
                this.scenarioCase_ = 0;
                this.scenario_ = null;
            }
        }

        private void clearMigration() {
            if (this.scenarioCase_ == 3) {
                this.scenarioCase_ = 0;
                this.scenario_ = null;
            }
        }

        private void clearNodeFailure() {
            if (this.scenarioCase_ == 2) {
                this.scenarioCase_ = 0;
                this.scenario_ = null;
            }
        }

        private void clearScenario() {
            this.scenarioCase_ = 0;
            this.scenario_ = null;
        }

        private void clearServerLeave() {
            if (this.scenarioCase_ == 4) {
                this.scenarioCase_ = 0;
                this.scenario_ = null;
            }
        }

        private void clearSpeakerUpdate() {
            if (this.scenarioCase_ == 1) {
                this.scenarioCase_ = 0;
                this.scenario_ = null;
            }
        }

        private void clearSubscriberBandwidth() {
            if (this.scenarioCase_ == 6) {
                this.scenarioCase_ = 0;
                this.scenario_ = null;
            }
        }

        private void clearSwitchCandidateProtocol() {
            if (this.scenarioCase_ == 5) {
                this.scenarioCase_ = 0;
                this.scenario_ = null;
            }
        }

        public static SimulateScenario getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SimulateScenario parseDelimitedFrom(InputStream inputStream) {
            return (SimulateScenario) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SimulateScenario parseFrom(ByteBuffer byteBuffer) {
            return (SimulateScenario) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SimulateScenario> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDisconnectSignalOnResume(boolean z) {
            this.scenarioCase_ = 7;
            this.scenario_ = Boolean.valueOf(z);
        }

        private void setDisconnectSignalOnResumeNoMessages(boolean z) {
            this.scenarioCase_ = 8;
            this.scenario_ = Boolean.valueOf(z);
        }

        private void setLeaveRequestFullReconnect(boolean z) {
            this.scenarioCase_ = 9;
            this.scenario_ = Boolean.valueOf(z);
        }

        private void setMigration(boolean z) {
            this.scenarioCase_ = 3;
            this.scenario_ = Boolean.valueOf(z);
        }

        private void setNodeFailure(boolean z) {
            this.scenarioCase_ = 2;
            this.scenario_ = Boolean.valueOf(z);
        }

        private void setServerLeave(boolean z) {
            this.scenarioCase_ = 4;
            this.scenario_ = Boolean.valueOf(z);
        }

        private void setSpeakerUpdate(int i) {
            this.scenarioCase_ = 1;
            this.scenario_ = Integer.valueOf(i);
        }

        private void setSubscriberBandwidth(long j) {
            this.scenarioCase_ = 6;
            this.scenario_ = Long.valueOf(j);
        }

        private void setSwitchCandidateProtocol(CandidateProtocol candidateProtocol) {
            this.scenario_ = Integer.valueOf(candidateProtocol.getNumber());
            this.scenarioCase_ = 5;
        }

        private void setSwitchCandidateProtocolValue(int i) {
            this.scenarioCase_ = 5;
            this.scenario_ = Integer.valueOf(i);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SimulateScenario();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\t\u0001\u0000\u0001\t\t\u0000\u0000\u0000\u00017\u0000\u0002:\u0000\u0003:\u0000\u0004:\u0000\u0005?\u0000\u00065\u0000\u0007:\u0000\b:\u0000\t:\u0000", new Object[]{ap.a(1336419469), ap.a(145410641)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SimulateScenario> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SimulateScenario.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getDisconnectSignalOnResume() {
            if (this.scenarioCase_ == 7) {
                return ((Boolean) this.scenario_).booleanValue();
            }
            return false;
        }

        public boolean getDisconnectSignalOnResumeNoMessages() {
            if (this.scenarioCase_ == 8) {
                return ((Boolean) this.scenario_).booleanValue();
            }
            return false;
        }

        public boolean getLeaveRequestFullReconnect() {
            if (this.scenarioCase_ == 9) {
                return ((Boolean) this.scenario_).booleanValue();
            }
            return false;
        }

        public boolean getMigration() {
            if (this.scenarioCase_ == 3) {
                return ((Boolean) this.scenario_).booleanValue();
            }
            return false;
        }

        public boolean getNodeFailure() {
            if (this.scenarioCase_ == 2) {
                return ((Boolean) this.scenario_).booleanValue();
            }
            return false;
        }

        public ScenarioCase getScenarioCase() {
            return ScenarioCase.b(this.scenarioCase_);
        }

        public boolean getServerLeave() {
            if (this.scenarioCase_ == 4) {
                return ((Boolean) this.scenario_).booleanValue();
            }
            return false;
        }

        public int getSpeakerUpdate() {
            if (this.scenarioCase_ == 1) {
                return ((Integer) this.scenario_).intValue();
            }
            return 0;
        }

        public long getSubscriberBandwidth() {
            if (this.scenarioCase_ == 6) {
                return ((Long) this.scenario_).longValue();
            }
            return 0L;
        }

        public CandidateProtocol getSwitchCandidateProtocol() {
            if (this.scenarioCase_ != 5) {
                return CandidateProtocol.b;
            }
            CandidateProtocol candidateProtocolB = CandidateProtocol.b(((Integer) this.scenario_).intValue());
            return candidateProtocolB == null ? CandidateProtocol.e : candidateProtocolB;
        }

        public int getSwitchCandidateProtocolValue() {
            if (this.scenarioCase_ == 5) {
                return ((Integer) this.scenario_).intValue();
            }
            return 0;
        }

        public boolean hasDisconnectSignalOnResume() {
            return this.scenarioCase_ == 7;
        }

        public boolean hasDisconnectSignalOnResumeNoMessages() {
            return this.scenarioCase_ == 8;
        }

        public boolean hasLeaveRequestFullReconnect() {
            return this.scenarioCase_ == 9;
        }

        public boolean hasMigration() {
            return this.scenarioCase_ == 3;
        }

        public boolean hasNodeFailure() {
            return this.scenarioCase_ == 2;
        }

        public boolean hasServerLeave() {
            return this.scenarioCase_ == 4;
        }

        public boolean hasSpeakerUpdate() {
            return this.scenarioCase_ == 1;
        }

        public boolean hasSubscriberBandwidth() {
            return this.scenarioCase_ == 6;
        }

        public boolean hasSwitchCandidateProtocol() {
            return this.scenarioCase_ == 5;
        }

        public static Builder newBuilder(SimulateScenario simulateScenario) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(simulateScenario);
        }

        public static SimulateScenario parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateScenario) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SimulateScenario parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateScenario) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SimulateScenario parseFrom(ByteString byteString) {
            return (SimulateScenario) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SimulateScenario parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateScenario) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SimulateScenario parseFrom(byte[] bArr) {
            return (SimulateScenario) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SimulateScenario parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateScenario) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SimulateScenario parseFrom(InputStream inputStream) {
            return (SimulateScenario) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SimulateScenario parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateScenario) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SimulateScenario parseFrom(CodedInputStream codedInputStream) {
            return (SimulateScenario) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SimulateScenario parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateScenario) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SimulateScenarioOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SimulcastCodec extends GeneratedMessageLite<SimulcastCodec, Builder> implements SimulcastCodecOrBuilder {
        public static final int CID_FIELD_NUMBER = 2;
        public static final int CODEC_FIELD_NUMBER = 1;
        private static final SimulcastCodec DEFAULT_INSTANCE;
        public static final int LAYERS_FIELD_NUMBER = 4;
        private static volatile Parser<SimulcastCodec> PARSER = null;
        public static final int VIDEO_LAYER_MODE_FIELD_NUMBER = 5;
        private String cid_;
        private String codec_;
        private Internal.ProtobufList<LivekitModels.VideoLayer> layers_;
        private int videoLayerMode_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SimulcastCodec, Builder> implements SimulcastCodecOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(String str) {
                q();
                ((SimulcastCodec) ((GeneratedMessageLite.Builder) this).b).setCid(str);
                return this;
            }

            public Builder B(String str) {
                q();
                ((SimulcastCodec) ((GeneratedMessageLite.Builder) this).b).setCodec(str);
                return this;
            }

            private Builder() {
                super(SimulcastCodec.DEFAULT_INSTANCE);
            }
        }

        static {
            SimulcastCodec simulcastCodec = new SimulcastCodec();
            DEFAULT_INSTANCE = simulcastCodec;
            GeneratedMessageLite.registerDefaultInstance(SimulcastCodec.class, simulcastCodec);
        }

        private SimulcastCodec() {
            String strA = ap.a(207314971);
            this.codec_ = strA;
            this.cid_ = strA;
            this.layers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllLayers(Iterable<? extends LivekitModels.VideoLayer> iterable) {
            ensureLayersIsMutable();
            AbstractMessageLite.addAll(iterable, this.layers_);
        }

        private void addLayers(LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(videoLayer);
        }

        private void clearCid() {
            this.cid_ = getDefaultInstance().getCid();
        }

        private void clearCodec() {
            this.codec_ = getDefaultInstance().getCodec();
        }

        private void clearLayers() {
            this.layers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearVideoLayerMode() {
            this.videoLayerMode_ = 0;
        }

        private void ensureLayersIsMutable() {
            Internal.ProtobufList<LivekitModels.VideoLayer> protobufList = this.layers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.layers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SimulcastCodec getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SimulcastCodec parseDelimitedFrom(InputStream inputStream) {
            return (SimulcastCodec) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SimulcastCodec parseFrom(ByteBuffer byteBuffer) {
            return (SimulcastCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SimulcastCodec> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeLayers(int i) {
            ensureLayersIsMutable();
            this.layers_.remove(i);
        }

        private void setCid(String str) {
            str.getClass();
            this.cid_ = str;
        }

        private void setCidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.cid_ = byteString.L();
        }

        private void setCodec(String str) {
            str.getClass();
            this.codec_ = str;
        }

        private void setCodecBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.codec_ = byteString.L();
        }

        private void setLayers(int i, LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.set(i, videoLayer);
        }

        private void setVideoLayerMode(LivekitModels.VideoLayer.Mode mode) {
            this.videoLayerMode_ = mode.getNumber();
        }

        private void setVideoLayerModeValue(int i) {
            this.videoLayerMode_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SimulcastCodec();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0005\u0004\u0000\u0001\u0000\u0001Ȉ\u0002Ȉ\u0004\u001b\u0005\f", new Object[]{"codec_", "cid_", "layers_", LivekitModels.VideoLayer.class, "videoLayerMode_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SimulcastCodec> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SimulcastCodec.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getCid() {
            return this.cid_;
        }

        public ByteString getCidBytes() {
            return ByteString.n(this.cid_);
        }

        public String getCodec() {
            return this.codec_;
        }

        public ByteString getCodecBytes() {
            return ByteString.n(this.codec_);
        }

        public LivekitModels.VideoLayer getLayers(int i) {
            return (LivekitModels.VideoLayer) this.layers_.get(i);
        }

        public int getLayersCount() {
            return this.layers_.size();
        }

        public List<LivekitModels.VideoLayer> getLayersList() {
            return this.layers_;
        }

        public LivekitModels.VideoLayerOrBuilder getLayersOrBuilder(int i) {
            return (LivekitModels.VideoLayerOrBuilder) this.layers_.get(i);
        }

        public List<? extends LivekitModels.VideoLayerOrBuilder> getLayersOrBuilderList() {
            return this.layers_;
        }

        public LivekitModels.VideoLayer.Mode getVideoLayerMode() {
            LivekitModels.VideoLayer.Mode modeB = LivekitModels.VideoLayer.Mode.b(this.videoLayerMode_);
            return modeB == null ? LivekitModels.VideoLayer.Mode.f : modeB;
        }

        public int getVideoLayerModeValue() {
            return this.videoLayerMode_;
        }

        public static Builder newBuilder(SimulcastCodec simulcastCodec) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(simulcastCodec);
        }

        public static SimulcastCodec parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodec) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SimulcastCodec parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SimulcastCodec parseFrom(ByteString byteString) {
            return (SimulcastCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addLayers(int i, LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(i, videoLayer);
        }

        public static SimulcastCodec parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SimulcastCodec parseFrom(byte[] bArr) {
            return (SimulcastCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SimulcastCodec parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SimulcastCodec parseFrom(InputStream inputStream) {
            return (SimulcastCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SimulcastCodec parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SimulcastCodec parseFrom(CodedInputStream codedInputStream) {
            return (SimulcastCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SimulcastCodec parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SimulcastCodecOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SpeakersChanged extends GeneratedMessageLite<SpeakersChanged, Builder> implements SpeakersChangedOrBuilder {
        private static final SpeakersChanged DEFAULT_INSTANCE;
        private static volatile Parser<SpeakersChanged> PARSER = null;
        public static final int SPEAKERS_FIELD_NUMBER = 1;
        private Internal.ProtobufList<LivekitModels.SpeakerInfo> speakers_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SpeakersChanged, Builder> implements SpeakersChangedOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SpeakersChanged.DEFAULT_INSTANCE);
            }
        }

        static {
            SpeakersChanged speakersChanged = new SpeakersChanged();
            DEFAULT_INSTANCE = speakersChanged;
            GeneratedMessageLite.registerDefaultInstance(SpeakersChanged.class, speakersChanged);
        }

        private SpeakersChanged() {
        }

        private void addAllSpeakers(Iterable<? extends LivekitModels.SpeakerInfo> iterable) {
            ensureSpeakersIsMutable();
            AbstractMessageLite.addAll(iterable, this.speakers_);
        }

        private void addSpeakers(LivekitModels.SpeakerInfo speakerInfo) {
            speakerInfo.getClass();
            ensureSpeakersIsMutable();
            this.speakers_.add(speakerInfo);
        }

        private void clearSpeakers() {
            this.speakers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureSpeakersIsMutable() {
            Internal.ProtobufList<LivekitModels.SpeakerInfo> protobufList = this.speakers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.speakers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SpeakersChanged getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SpeakersChanged parseDelimitedFrom(InputStream inputStream) {
            return (SpeakersChanged) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SpeakersChanged parseFrom(ByteBuffer byteBuffer) {
            return (SpeakersChanged) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SpeakersChanged> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSpeakers(int i) {
            ensureSpeakersIsMutable();
            this.speakers_.remove(i);
        }

        private void setSpeakers(int i, LivekitModels.SpeakerInfo speakerInfo) {
            speakerInfo.getClass();
            ensureSpeakersIsMutable();
            this.speakers_.set(i, speakerInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SpeakersChanged();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(910565669), LivekitModels.SpeakerInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SpeakersChanged> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SpeakersChanged.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.SpeakerInfo getSpeakers(int i) {
            return (LivekitModels.SpeakerInfo) this.speakers_.get(i);
        }

        public int getSpeakersCount() {
            return this.speakers_.size();
        }

        public List<LivekitModels.SpeakerInfo> getSpeakersList() {
            return this.speakers_;
        }

        public LivekitModels.SpeakerInfoOrBuilder getSpeakersOrBuilder(int i) {
            return (LivekitModels.SpeakerInfoOrBuilder) this.speakers_.get(i);
        }

        public List<? extends LivekitModels.SpeakerInfoOrBuilder> getSpeakersOrBuilderList() {
            return this.speakers_;
        }

        public static Builder newBuilder(SpeakersChanged speakersChanged) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(speakersChanged);
        }

        public static SpeakersChanged parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakersChanged) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SpeakersChanged parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakersChanged) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SpeakersChanged parseFrom(ByteString byteString) {
            return (SpeakersChanged) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSpeakers(int i, LivekitModels.SpeakerInfo speakerInfo) {
            speakerInfo.getClass();
            ensureSpeakersIsMutable();
            this.speakers_.add(i, speakerInfo);
        }

        public static SpeakersChanged parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakersChanged) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SpeakersChanged parseFrom(byte[] bArr) {
            return (SpeakersChanged) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SpeakersChanged parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakersChanged) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SpeakersChanged parseFrom(InputStream inputStream) {
            return (SpeakersChanged) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SpeakersChanged parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakersChanged) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SpeakersChanged parseFrom(CodedInputStream codedInputStream) {
            return (SpeakersChanged) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SpeakersChanged parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakersChanged) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SpeakersChangedOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum StreamState implements Internal.EnumLite {
        b(0),
        c(1),
        d(-1);

        private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<StreamState>() { // from class: livekit.LivekitRtc.StreamState.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public StreamState findValueByNumber(int i) {
                return StreamState.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class StreamStateVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new StreamStateVerifier();

            private StreamStateVerifier() {
            }

            public boolean isInRange(int i) {
                return StreamState.b(i) != null;
            }
        }

        StreamState(int i) {
            this.a = i;
        }

        public static StreamState b(int i) {
            if (i == 0) {
                return b;
            }
            if (i != 1) {
                return null;
            }
            return c;
        }

        public final int getNumber() {
            if (this != d) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class StreamStateInfo extends GeneratedMessageLite<StreamStateInfo, Builder> implements StreamStateInfoOrBuilder {
        private static final StreamStateInfo DEFAULT_INSTANCE;
        private static volatile Parser<StreamStateInfo> PARSER = null;
        public static final int PARTICIPANT_SID_FIELD_NUMBER = 1;
        public static final int STATE_FIELD_NUMBER = 3;
        public static final int TRACK_SID_FIELD_NUMBER = 2;
        private String participantSid_;
        private int state_;
        private String trackSid_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<StreamStateInfo, Builder> implements StreamStateInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(StreamStateInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            StreamStateInfo streamStateInfo = new StreamStateInfo();
            DEFAULT_INSTANCE = streamStateInfo;
            GeneratedMessageLite.registerDefaultInstance(StreamStateInfo.class, streamStateInfo);
        }

        private StreamStateInfo() {
            String strA = ap.a(1480529734);
            this.participantSid_ = strA;
            this.trackSid_ = strA;
        }

        private void clearParticipantSid() {
            this.participantSid_ = getDefaultInstance().getParticipantSid();
        }

        private void clearState() {
            this.state_ = 0;
        }

        private void clearTrackSid() {
            this.trackSid_ = getDefaultInstance().getTrackSid();
        }

        public static StreamStateInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static StreamStateInfo parseDelimitedFrom(InputStream inputStream) {
            return (StreamStateInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StreamStateInfo parseFrom(ByteBuffer byteBuffer) {
            return (StreamStateInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<StreamStateInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setParticipantSid(String str) {
            str.getClass();
            this.participantSid_ = str;
        }

        private void setParticipantSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantSid_ = byteString.L();
        }

        private void setState(StreamState streamState) {
            this.state_ = streamState.getNumber();
        }

        private void setStateValue(int i) {
            this.state_ = i;
        }

        private void setTrackSid(String str) {
            str.getClass();
            this.trackSid_ = str;
        }

        private void setTrackSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackSid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new StreamStateInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\f", new Object[]{"participantSid_", "trackSid_", "state_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<StreamStateInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (StreamStateInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getParticipantSid() {
            return this.participantSid_;
        }

        public ByteString getParticipantSidBytes() {
            return ByteString.n(this.participantSid_);
        }

        public StreamState getState() {
            StreamState streamStateB = StreamState.b(this.state_);
            return streamStateB == null ? StreamState.d : streamStateB;
        }

        public int getStateValue() {
            return this.state_;
        }

        public String getTrackSid() {
            return this.trackSid_;
        }

        public ByteString getTrackSidBytes() {
            return ByteString.n(this.trackSid_);
        }

        public static Builder newBuilder(StreamStateInfo streamStateInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(streamStateInfo);
        }

        public static StreamStateInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StreamStateInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static StreamStateInfo parseFrom(ByteString byteString) {
            return (StreamStateInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static StreamStateInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static StreamStateInfo parseFrom(byte[] bArr) {
            return (StreamStateInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static StreamStateInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static StreamStateInfo parseFrom(InputStream inputStream) {
            return (StreamStateInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StreamStateInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StreamStateInfo parseFrom(CodedInputStream codedInputStream) {
            return (StreamStateInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static StreamStateInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface StreamStateInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class StreamStateUpdate extends GeneratedMessageLite<StreamStateUpdate, Builder> implements StreamStateUpdateOrBuilder {
        private static final StreamStateUpdate DEFAULT_INSTANCE;
        private static volatile Parser<StreamStateUpdate> PARSER = null;
        public static final int STREAM_STATES_FIELD_NUMBER = 1;
        private Internal.ProtobufList<StreamStateInfo> streamStates_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<StreamStateUpdate, Builder> implements StreamStateUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(StreamStateUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            StreamStateUpdate streamStateUpdate = new StreamStateUpdate();
            DEFAULT_INSTANCE = streamStateUpdate;
            GeneratedMessageLite.registerDefaultInstance(StreamStateUpdate.class, streamStateUpdate);
        }

        private StreamStateUpdate() {
        }

        private void addAllStreamStates(Iterable<? extends StreamStateInfo> iterable) {
            ensureStreamStatesIsMutable();
            AbstractMessageLite.addAll(iterable, this.streamStates_);
        }

        private void addStreamStates(StreamStateInfo streamStateInfo) {
            streamStateInfo.getClass();
            ensureStreamStatesIsMutable();
            this.streamStates_.add(streamStateInfo);
        }

        private void clearStreamStates() {
            this.streamStates_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureStreamStatesIsMutable() {
            Internal.ProtobufList<StreamStateInfo> protobufList = this.streamStates_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.streamStates_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static StreamStateUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static StreamStateUpdate parseDelimitedFrom(InputStream inputStream) {
            return (StreamStateUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StreamStateUpdate parseFrom(ByteBuffer byteBuffer) {
            return (StreamStateUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<StreamStateUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeStreamStates(int i) {
            ensureStreamStatesIsMutable();
            this.streamStates_.remove(i);
        }

        private void setStreamStates(int i, StreamStateInfo streamStateInfo) {
            streamStateInfo.getClass();
            ensureStreamStatesIsMutable();
            this.streamStates_.set(i, streamStateInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new StreamStateUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(71185550), StreamStateInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<StreamStateUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (StreamStateUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public StreamStateInfo getStreamStates(int i) {
            return (StreamStateInfo) this.streamStates_.get(i);
        }

        public int getStreamStatesCount() {
            return this.streamStates_.size();
        }

        public List<StreamStateInfo> getStreamStatesList() {
            return this.streamStates_;
        }

        public StreamStateInfoOrBuilder getStreamStatesOrBuilder(int i) {
            return (StreamStateInfoOrBuilder) this.streamStates_.get(i);
        }

        public List<? extends StreamStateInfoOrBuilder> getStreamStatesOrBuilderList() {
            return this.streamStates_;
        }

        public static Builder newBuilder(StreamStateUpdate streamStateUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(streamStateUpdate);
        }

        public static StreamStateUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StreamStateUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static StreamStateUpdate parseFrom(ByteString byteString) {
            return (StreamStateUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addStreamStates(int i, StreamStateInfo streamStateInfo) {
            streamStateInfo.getClass();
            ensureStreamStatesIsMutable();
            this.streamStates_.add(i, streamStateInfo);
        }

        public static StreamStateUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static StreamStateUpdate parseFrom(byte[] bArr) {
            return (StreamStateUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static StreamStateUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static StreamStateUpdate parseFrom(InputStream inputStream) {
            return (StreamStateUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StreamStateUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StreamStateUpdate parseFrom(CodedInputStream codedInputStream) {
            return (StreamStateUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static StreamStateUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamStateUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface StreamStateUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SubscribedAudioCodecUpdate extends GeneratedMessageLite<SubscribedAudioCodecUpdate, Builder> implements SubscribedAudioCodecUpdateOrBuilder {
        private static final SubscribedAudioCodecUpdate DEFAULT_INSTANCE;
        private static volatile Parser<SubscribedAudioCodecUpdate> PARSER = null;
        public static final int SUBSCRIBED_AUDIO_CODECS_FIELD_NUMBER = 2;
        public static final int TRACK_SID_FIELD_NUMBER = 1;
        private String trackSid_ = ap.a(132435231);
        private Internal.ProtobufList<LivekitModels.SubscribedAudioCodec> subscribedAudioCodecs_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SubscribedAudioCodecUpdate, Builder> implements SubscribedAudioCodecUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SubscribedAudioCodecUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            SubscribedAudioCodecUpdate subscribedAudioCodecUpdate = new SubscribedAudioCodecUpdate();
            DEFAULT_INSTANCE = subscribedAudioCodecUpdate;
            GeneratedMessageLite.registerDefaultInstance(SubscribedAudioCodecUpdate.class, subscribedAudioCodecUpdate);
        }

        private SubscribedAudioCodecUpdate() {
        }

        private void addAllSubscribedAudioCodecs(Iterable<? extends LivekitModels.SubscribedAudioCodec> iterable) {
            ensureSubscribedAudioCodecsIsMutable();
            AbstractMessageLite.addAll(iterable, this.subscribedAudioCodecs_);
        }

        private void addSubscribedAudioCodecs(LivekitModels.SubscribedAudioCodec subscribedAudioCodec) {
            subscribedAudioCodec.getClass();
            ensureSubscribedAudioCodecsIsMutable();
            this.subscribedAudioCodecs_.add(subscribedAudioCodec);
        }

        private void clearSubscribedAudioCodecs() {
            this.subscribedAudioCodecs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearTrackSid() {
            this.trackSid_ = getDefaultInstance().getTrackSid();
        }

        private void ensureSubscribedAudioCodecsIsMutable() {
            Internal.ProtobufList<LivekitModels.SubscribedAudioCodec> protobufList = this.subscribedAudioCodecs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.subscribedAudioCodecs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SubscribedAudioCodecUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SubscribedAudioCodecUpdate parseDelimitedFrom(InputStream inputStream) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscribedAudioCodecUpdate parseFrom(ByteBuffer byteBuffer) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SubscribedAudioCodecUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSubscribedAudioCodecs(int i) {
            ensureSubscribedAudioCodecsIsMutable();
            this.subscribedAudioCodecs_.remove(i);
        }

        private void setSubscribedAudioCodecs(int i, LivekitModels.SubscribedAudioCodec subscribedAudioCodec) {
            subscribedAudioCodec.getClass();
            ensureSubscribedAudioCodecsIsMutable();
            this.subscribedAudioCodecs_.set(i, subscribedAudioCodec);
        }

        private void setTrackSid(String str) {
            str.getClass();
            this.trackSid_ = str;
        }

        private void setTrackSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackSid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SubscribedAudioCodecUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001Ȉ\u0002\u001b", new Object[]{"trackSid_", "subscribedAudioCodecs_", LivekitModels.SubscribedAudioCodec.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SubscribedAudioCodecUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SubscribedAudioCodecUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.SubscribedAudioCodec getSubscribedAudioCodecs(int i) {
            return (LivekitModels.SubscribedAudioCodec) this.subscribedAudioCodecs_.get(i);
        }

        public int getSubscribedAudioCodecsCount() {
            return this.subscribedAudioCodecs_.size();
        }

        public List<LivekitModels.SubscribedAudioCodec> getSubscribedAudioCodecsList() {
            return this.subscribedAudioCodecs_;
        }

        public LivekitModels.SubscribedAudioCodecOrBuilder getSubscribedAudioCodecsOrBuilder(int i) {
            return (LivekitModels.SubscribedAudioCodecOrBuilder) this.subscribedAudioCodecs_.get(i);
        }

        public List<? extends LivekitModels.SubscribedAudioCodecOrBuilder> getSubscribedAudioCodecsOrBuilderList() {
            return this.subscribedAudioCodecs_;
        }

        public String getTrackSid() {
            return this.trackSid_;
        }

        public ByteString getTrackSidBytes() {
            return ByteString.n(this.trackSid_);
        }

        public static Builder newBuilder(SubscribedAudioCodecUpdate subscribedAudioCodecUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(subscribedAudioCodecUpdate);
        }

        public static SubscribedAudioCodecUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscribedAudioCodecUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SubscribedAudioCodecUpdate parseFrom(ByteString byteString) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSubscribedAudioCodecs(int i, LivekitModels.SubscribedAudioCodec subscribedAudioCodec) {
            subscribedAudioCodec.getClass();
            ensureSubscribedAudioCodecsIsMutable();
            this.subscribedAudioCodecs_.add(i, subscribedAudioCodec);
        }

        public static SubscribedAudioCodecUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SubscribedAudioCodecUpdate parseFrom(byte[] bArr) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SubscribedAudioCodecUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SubscribedAudioCodecUpdate parseFrom(InputStream inputStream) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscribedAudioCodecUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscribedAudioCodecUpdate parseFrom(CodedInputStream codedInputStream) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SubscribedAudioCodecUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodecUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SubscribedAudioCodecUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SubscribedCodec extends GeneratedMessageLite<SubscribedCodec, Builder> implements SubscribedCodecOrBuilder {
        public static final int CODEC_FIELD_NUMBER = 1;
        private static final SubscribedCodec DEFAULT_INSTANCE;
        private static volatile Parser<SubscribedCodec> PARSER = null;
        public static final int QUALITIES_FIELD_NUMBER = 2;
        private String codec_ = ap.a(677380628);
        private Internal.ProtobufList<SubscribedQuality> qualities_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SubscribedCodec, Builder> implements SubscribedCodecOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SubscribedCodec.DEFAULT_INSTANCE);
            }
        }

        static {
            SubscribedCodec subscribedCodec = new SubscribedCodec();
            DEFAULT_INSTANCE = subscribedCodec;
            GeneratedMessageLite.registerDefaultInstance(SubscribedCodec.class, subscribedCodec);
        }

        private SubscribedCodec() {
        }

        private void addAllQualities(Iterable<? extends SubscribedQuality> iterable) {
            ensureQualitiesIsMutable();
            AbstractMessageLite.addAll(iterable, this.qualities_);
        }

        private void addQualities(SubscribedQuality subscribedQuality) {
            subscribedQuality.getClass();
            ensureQualitiesIsMutable();
            this.qualities_.add(subscribedQuality);
        }

        private void clearCodec() {
            this.codec_ = getDefaultInstance().getCodec();
        }

        private void clearQualities() {
            this.qualities_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureQualitiesIsMutable() {
            Internal.ProtobufList<SubscribedQuality> protobufList = this.qualities_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.qualities_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SubscribedCodec getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SubscribedCodec parseDelimitedFrom(InputStream inputStream) {
            return (SubscribedCodec) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscribedCodec parseFrom(ByteBuffer byteBuffer) {
            return (SubscribedCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SubscribedCodec> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeQualities(int i) {
            ensureQualitiesIsMutable();
            this.qualities_.remove(i);
        }

        private void setCodec(String str) {
            str.getClass();
            this.codec_ = str;
        }

        private void setCodecBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.codec_ = byteString.L();
        }

        private void setQualities(int i, SubscribedQuality subscribedQuality) {
            subscribedQuality.getClass();
            ensureQualitiesIsMutable();
            this.qualities_.set(i, subscribedQuality);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SubscribedCodec();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001Ȉ\u0002\u001b", new Object[]{"codec_", "qualities_", SubscribedQuality.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SubscribedCodec> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SubscribedCodec.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getCodec() {
            return this.codec_;
        }

        public ByteString getCodecBytes() {
            return ByteString.n(this.codec_);
        }

        public SubscribedQuality getQualities(int i) {
            return (SubscribedQuality) this.qualities_.get(i);
        }

        public int getQualitiesCount() {
            return this.qualities_.size();
        }

        public List<SubscribedQuality> getQualitiesList() {
            return this.qualities_;
        }

        public SubscribedQualityOrBuilder getQualitiesOrBuilder(int i) {
            return (SubscribedQualityOrBuilder) this.qualities_.get(i);
        }

        public List<? extends SubscribedQualityOrBuilder> getQualitiesOrBuilderList() {
            return this.qualities_;
        }

        public static Builder newBuilder(SubscribedCodec subscribedCodec) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(subscribedCodec);
        }

        public static SubscribedCodec parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedCodec) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscribedCodec parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SubscribedCodec parseFrom(ByteString byteString) {
            return (SubscribedCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addQualities(int i, SubscribedQuality subscribedQuality) {
            subscribedQuality.getClass();
            ensureQualitiesIsMutable();
            this.qualities_.add(i, subscribedQuality);
        }

        public static SubscribedCodec parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SubscribedCodec parseFrom(byte[] bArr) {
            return (SubscribedCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SubscribedCodec parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SubscribedCodec parseFrom(InputStream inputStream) {
            return (SubscribedCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscribedCodec parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscribedCodec parseFrom(CodedInputStream codedInputStream) {
            return (SubscribedCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SubscribedCodec parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SubscribedCodecOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SubscribedQuality extends GeneratedMessageLite<SubscribedQuality, Builder> implements SubscribedQualityOrBuilder {
        private static final SubscribedQuality DEFAULT_INSTANCE;
        public static final int ENABLED_FIELD_NUMBER = 2;
        private static volatile Parser<SubscribedQuality> PARSER = null;
        public static final int QUALITY_FIELD_NUMBER = 1;
        private boolean enabled_;
        private int quality_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SubscribedQuality, Builder> implements SubscribedQualityOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SubscribedQuality.DEFAULT_INSTANCE);
            }
        }

        static {
            SubscribedQuality subscribedQuality = new SubscribedQuality();
            DEFAULT_INSTANCE = subscribedQuality;
            GeneratedMessageLite.registerDefaultInstance(SubscribedQuality.class, subscribedQuality);
        }

        private SubscribedQuality() {
        }

        private void clearEnabled() {
            this.enabled_ = false;
        }

        private void clearQuality() {
            this.quality_ = 0;
        }

        public static SubscribedQuality getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SubscribedQuality parseDelimitedFrom(InputStream inputStream) {
            return (SubscribedQuality) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscribedQuality parseFrom(ByteBuffer byteBuffer) {
            return (SubscribedQuality) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SubscribedQuality> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setEnabled(boolean z) {
            this.enabled_ = z;
        }

        private void setQuality(LivekitModels.VideoQuality videoQuality) {
            this.quality_ = videoQuality.getNumber();
        }

        private void setQualityValue(int i) {
            this.quality_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SubscribedQuality();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\f\u0002\u0007", new Object[]{ap.a(1072831123), ap.a(1047279228)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SubscribedQuality> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SubscribedQuality.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getEnabled() {
            return this.enabled_;
        }

        public LivekitModels.VideoQuality getQuality() {
            LivekitModels.VideoQuality videoQualityB = LivekitModels.VideoQuality.b(this.quality_);
            return videoQualityB == null ? LivekitModels.VideoQuality.f : videoQualityB;
        }

        public int getQualityValue() {
            return this.quality_;
        }

        public static Builder newBuilder(SubscribedQuality subscribedQuality) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(subscribedQuality);
        }

        public static SubscribedQuality parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQuality) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscribedQuality parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQuality) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SubscribedQuality parseFrom(ByteString byteString) {
            return (SubscribedQuality) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SubscribedQuality parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQuality) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SubscribedQuality parseFrom(byte[] bArr) {
            return (SubscribedQuality) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SubscribedQuality parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQuality) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SubscribedQuality parseFrom(InputStream inputStream) {
            return (SubscribedQuality) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscribedQuality parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQuality) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscribedQuality parseFrom(CodedInputStream codedInputStream) {
            return (SubscribedQuality) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SubscribedQuality parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQuality) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SubscribedQualityOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SubscribedQualityUpdate extends GeneratedMessageLite<SubscribedQualityUpdate, Builder> implements SubscribedQualityUpdateOrBuilder {
        private static final SubscribedQualityUpdate DEFAULT_INSTANCE;
        private static volatile Parser<SubscribedQualityUpdate> PARSER = null;
        public static final int SUBSCRIBED_CODECS_FIELD_NUMBER = 3;
        public static final int SUBSCRIBED_QUALITIES_FIELD_NUMBER = 2;
        public static final int TRACK_SID_FIELD_NUMBER = 1;
        private String trackSid_ = ap.a(262328265);
        private Internal.ProtobufList<SubscribedQuality> subscribedQualities_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<SubscribedCodec> subscribedCodecs_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SubscribedQualityUpdate, Builder> implements SubscribedQualityUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SubscribedQualityUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            SubscribedQualityUpdate subscribedQualityUpdate = new SubscribedQualityUpdate();
            DEFAULT_INSTANCE = subscribedQualityUpdate;
            GeneratedMessageLite.registerDefaultInstance(SubscribedQualityUpdate.class, subscribedQualityUpdate);
        }

        private SubscribedQualityUpdate() {
        }

        private void addAllSubscribedCodecs(Iterable<? extends SubscribedCodec> iterable) {
            ensureSubscribedCodecsIsMutable();
            AbstractMessageLite.addAll(iterable, this.subscribedCodecs_);
        }

        private void addAllSubscribedQualities(Iterable<? extends SubscribedQuality> iterable) {
            ensureSubscribedQualitiesIsMutable();
            AbstractMessageLite.addAll(iterable, this.subscribedQualities_);
        }

        private void addSubscribedCodecs(SubscribedCodec subscribedCodec) {
            subscribedCodec.getClass();
            ensureSubscribedCodecsIsMutable();
            this.subscribedCodecs_.add(subscribedCodec);
        }

        private void addSubscribedQualities(SubscribedQuality subscribedQuality) {
            subscribedQuality.getClass();
            ensureSubscribedQualitiesIsMutable();
            this.subscribedQualities_.add(subscribedQuality);
        }

        private void clearSubscribedCodecs() {
            this.subscribedCodecs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSubscribedQualities() {
            this.subscribedQualities_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearTrackSid() {
            this.trackSid_ = getDefaultInstance().getTrackSid();
        }

        private void ensureSubscribedCodecsIsMutable() {
            Internal.ProtobufList<SubscribedCodec> protobufList = this.subscribedCodecs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.subscribedCodecs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSubscribedQualitiesIsMutable() {
            Internal.ProtobufList<SubscribedQuality> protobufList = this.subscribedQualities_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.subscribedQualities_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SubscribedQualityUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SubscribedQualityUpdate parseDelimitedFrom(InputStream inputStream) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscribedQualityUpdate parseFrom(ByteBuffer byteBuffer) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SubscribedQualityUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSubscribedCodecs(int i) {
            ensureSubscribedCodecsIsMutable();
            this.subscribedCodecs_.remove(i);
        }

        private void removeSubscribedQualities(int i) {
            ensureSubscribedQualitiesIsMutable();
            this.subscribedQualities_.remove(i);
        }

        private void setSubscribedCodecs(int i, SubscribedCodec subscribedCodec) {
            subscribedCodec.getClass();
            ensureSubscribedCodecsIsMutable();
            this.subscribedCodecs_.set(i, subscribedCodec);
        }

        private void setSubscribedQualities(int i, SubscribedQuality subscribedQuality) {
            subscribedQuality.getClass();
            ensureSubscribedQualitiesIsMutable();
            this.subscribedQualities_.set(i, subscribedQuality);
        }

        private void setTrackSid(String str) {
            str.getClass();
            this.trackSid_ = str;
        }

        private void setTrackSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackSid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SubscribedQualityUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0002\u0000\u0001Ȉ\u0002\u001b\u0003\u001b", new Object[]{"trackSid_", "subscribedQualities_", SubscribedQuality.class, "subscribedCodecs_", SubscribedCodec.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SubscribedQualityUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SubscribedQualityUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SubscribedCodec getSubscribedCodecs(int i) {
            return (SubscribedCodec) this.subscribedCodecs_.get(i);
        }

        public int getSubscribedCodecsCount() {
            return this.subscribedCodecs_.size();
        }

        public List<SubscribedCodec> getSubscribedCodecsList() {
            return this.subscribedCodecs_;
        }

        public SubscribedCodecOrBuilder getSubscribedCodecsOrBuilder(int i) {
            return (SubscribedCodecOrBuilder) this.subscribedCodecs_.get(i);
        }

        public List<? extends SubscribedCodecOrBuilder> getSubscribedCodecsOrBuilderList() {
            return this.subscribedCodecs_;
        }

        @Deprecated
        public SubscribedQuality getSubscribedQualities(int i) {
            return (SubscribedQuality) this.subscribedQualities_.get(i);
        }

        @Deprecated
        public int getSubscribedQualitiesCount() {
            return this.subscribedQualities_.size();
        }

        @Deprecated
        public List<SubscribedQuality> getSubscribedQualitiesList() {
            return this.subscribedQualities_;
        }

        @Deprecated
        public SubscribedQualityOrBuilder getSubscribedQualitiesOrBuilder(int i) {
            return (SubscribedQualityOrBuilder) this.subscribedQualities_.get(i);
        }

        @Deprecated
        public List<? extends SubscribedQualityOrBuilder> getSubscribedQualitiesOrBuilderList() {
            return this.subscribedQualities_;
        }

        public String getTrackSid() {
            return this.trackSid_;
        }

        public ByteString getTrackSidBytes() {
            return ByteString.n(this.trackSid_);
        }

        public static Builder newBuilder(SubscribedQualityUpdate subscribedQualityUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(subscribedQualityUpdate);
        }

        public static SubscribedQualityUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscribedQualityUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SubscribedQualityUpdate parseFrom(ByteString byteString) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSubscribedCodecs(int i, SubscribedCodec subscribedCodec) {
            subscribedCodec.getClass();
            ensureSubscribedCodecsIsMutable();
            this.subscribedCodecs_.add(i, subscribedCodec);
        }

        private void addSubscribedQualities(int i, SubscribedQuality subscribedQuality) {
            subscribedQuality.getClass();
            ensureSubscribedQualitiesIsMutable();
            this.subscribedQualities_.add(i, subscribedQuality);
        }

        public static SubscribedQualityUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SubscribedQualityUpdate parseFrom(byte[] bArr) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SubscribedQualityUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SubscribedQualityUpdate parseFrom(InputStream inputStream) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscribedQualityUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscribedQualityUpdate parseFrom(CodedInputStream codedInputStream) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SubscribedQualityUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedQualityUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SubscribedQualityUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SubscriptionPermission extends GeneratedMessageLite<SubscriptionPermission, Builder> implements SubscriptionPermissionOrBuilder {
        public static final int ALL_PARTICIPANTS_FIELD_NUMBER = 1;
        private static final SubscriptionPermission DEFAULT_INSTANCE;
        private static volatile Parser<SubscriptionPermission> PARSER = null;
        public static final int TRACK_PERMISSIONS_FIELD_NUMBER = 2;
        private boolean allParticipants_;
        private Internal.ProtobufList<TrackPermission> trackPermissions_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SubscriptionPermission, Builder> implements SubscriptionPermissionOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SubscriptionPermission.DEFAULT_INSTANCE);
            }
        }

        static {
            SubscriptionPermission subscriptionPermission = new SubscriptionPermission();
            DEFAULT_INSTANCE = subscriptionPermission;
            GeneratedMessageLite.registerDefaultInstance(SubscriptionPermission.class, subscriptionPermission);
        }

        private SubscriptionPermission() {
        }

        private void addAllTrackPermissions(Iterable<? extends TrackPermission> iterable) {
            ensureTrackPermissionsIsMutable();
            AbstractMessageLite.addAll(iterable, this.trackPermissions_);
        }

        private void addTrackPermissions(TrackPermission trackPermission) {
            trackPermission.getClass();
            ensureTrackPermissionsIsMutable();
            this.trackPermissions_.add(trackPermission);
        }

        private void clearAllParticipants() {
            this.allParticipants_ = false;
        }

        private void clearTrackPermissions() {
            this.trackPermissions_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureTrackPermissionsIsMutable() {
            Internal.ProtobufList<TrackPermission> protobufList = this.trackPermissions_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trackPermissions_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SubscriptionPermission getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SubscriptionPermission parseDelimitedFrom(InputStream inputStream) {
            return (SubscriptionPermission) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscriptionPermission parseFrom(ByteBuffer byteBuffer) {
            return (SubscriptionPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SubscriptionPermission> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeTrackPermissions(int i) {
            ensureTrackPermissionsIsMutable();
            this.trackPermissions_.remove(i);
        }

        private void setAllParticipants(boolean z) {
            this.allParticipants_ = z;
        }

        private void setTrackPermissions(int i, TrackPermission trackPermission) {
            trackPermission.getClass();
            ensureTrackPermissionsIsMutable();
            this.trackPermissions_.set(i, trackPermission);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SubscriptionPermission();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u0007\u0002\u001b", new Object[]{ap.a(1252039124), ap.a(799488034), TrackPermission.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SubscriptionPermission> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SubscriptionPermission.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getAllParticipants() {
            return this.allParticipants_;
        }

        public TrackPermission getTrackPermissions(int i) {
            return (TrackPermission) this.trackPermissions_.get(i);
        }

        public int getTrackPermissionsCount() {
            return this.trackPermissions_.size();
        }

        public List<TrackPermission> getTrackPermissionsList() {
            return this.trackPermissions_;
        }

        public TrackPermissionOrBuilder getTrackPermissionsOrBuilder(int i) {
            return (TrackPermissionOrBuilder) this.trackPermissions_.get(i);
        }

        public List<? extends TrackPermissionOrBuilder> getTrackPermissionsOrBuilderList() {
            return this.trackPermissions_;
        }

        public static Builder newBuilder(SubscriptionPermission subscriptionPermission) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(subscriptionPermission);
        }

        public static SubscriptionPermission parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermission) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscriptionPermission parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SubscriptionPermission parseFrom(ByteString byteString) {
            return (SubscriptionPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addTrackPermissions(int i, TrackPermission trackPermission) {
            trackPermission.getClass();
            ensureTrackPermissionsIsMutable();
            this.trackPermissions_.add(i, trackPermission);
        }

        public static SubscriptionPermission parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SubscriptionPermission parseFrom(byte[] bArr) {
            return (SubscriptionPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SubscriptionPermission parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SubscriptionPermission parseFrom(InputStream inputStream) {
            return (SubscriptionPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscriptionPermission parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscriptionPermission parseFrom(CodedInputStream codedInputStream) {
            return (SubscriptionPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SubscriptionPermission parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SubscriptionPermissionOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SubscriptionPermissionUpdate extends GeneratedMessageLite<SubscriptionPermissionUpdate, Builder> implements SubscriptionPermissionUpdateOrBuilder {
        public static final int ALLOWED_FIELD_NUMBER = 3;
        private static final SubscriptionPermissionUpdate DEFAULT_INSTANCE;
        private static volatile Parser<SubscriptionPermissionUpdate> PARSER = null;
        public static final int PARTICIPANT_SID_FIELD_NUMBER = 1;
        public static final int TRACK_SID_FIELD_NUMBER = 2;
        private boolean allowed_;
        private String participantSid_;
        private String trackSid_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SubscriptionPermissionUpdate, Builder> implements SubscriptionPermissionUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SubscriptionPermissionUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            SubscriptionPermissionUpdate subscriptionPermissionUpdate = new SubscriptionPermissionUpdate();
            DEFAULT_INSTANCE = subscriptionPermissionUpdate;
            GeneratedMessageLite.registerDefaultInstance(SubscriptionPermissionUpdate.class, subscriptionPermissionUpdate);
        }

        private SubscriptionPermissionUpdate() {
            String strA = ap.a(394360282);
            this.participantSid_ = strA;
            this.trackSid_ = strA;
        }

        private void clearAllowed() {
            this.allowed_ = false;
        }

        private void clearParticipantSid() {
            this.participantSid_ = getDefaultInstance().getParticipantSid();
        }

        private void clearTrackSid() {
            this.trackSid_ = getDefaultInstance().getTrackSid();
        }

        public static SubscriptionPermissionUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SubscriptionPermissionUpdate parseDelimitedFrom(InputStream inputStream) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscriptionPermissionUpdate parseFrom(ByteBuffer byteBuffer) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SubscriptionPermissionUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAllowed(boolean z) {
            this.allowed_ = z;
        }

        private void setParticipantSid(String str) {
            str.getClass();
            this.participantSid_ = str;
        }

        private void setParticipantSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantSid_ = byteString.L();
        }

        private void setTrackSid(String str) {
            str.getClass();
            this.trackSid_ = str;
        }

        private void setTrackSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackSid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SubscriptionPermissionUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\u0007", new Object[]{"participantSid_", "trackSid_", "allowed_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SubscriptionPermissionUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SubscriptionPermissionUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getAllowed() {
            return this.allowed_;
        }

        public String getParticipantSid() {
            return this.participantSid_;
        }

        public ByteString getParticipantSidBytes() {
            return ByteString.n(this.participantSid_);
        }

        public String getTrackSid() {
            return this.trackSid_;
        }

        public ByteString getTrackSidBytes() {
            return ByteString.n(this.trackSid_);
        }

        public static Builder newBuilder(SubscriptionPermissionUpdate subscriptionPermissionUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(subscriptionPermissionUpdate);
        }

        public static SubscriptionPermissionUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscriptionPermissionUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SubscriptionPermissionUpdate parseFrom(ByteString byteString) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SubscriptionPermissionUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SubscriptionPermissionUpdate parseFrom(byte[] bArr) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SubscriptionPermissionUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SubscriptionPermissionUpdate parseFrom(InputStream inputStream) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscriptionPermissionUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscriptionPermissionUpdate parseFrom(CodedInputStream codedInputStream) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SubscriptionPermissionUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionPermissionUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SubscriptionPermissionUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SubscriptionResponse extends GeneratedMessageLite<SubscriptionResponse, Builder> implements SubscriptionResponseOrBuilder {
        private static final SubscriptionResponse DEFAULT_INSTANCE;
        public static final int ERR_FIELD_NUMBER = 2;
        private static volatile Parser<SubscriptionResponse> PARSER = null;
        public static final int TRACK_SID_FIELD_NUMBER = 1;
        private int err_;
        private String trackSid_ = ap.a(1671418436);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SubscriptionResponse, Builder> implements SubscriptionResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SubscriptionResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            SubscriptionResponse subscriptionResponse = new SubscriptionResponse();
            DEFAULT_INSTANCE = subscriptionResponse;
            GeneratedMessageLite.registerDefaultInstance(SubscriptionResponse.class, subscriptionResponse);
        }

        private SubscriptionResponse() {
        }

        private void clearErr() {
            this.err_ = 0;
        }

        private void clearTrackSid() {
            this.trackSid_ = getDefaultInstance().getTrackSid();
        }

        public static SubscriptionResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SubscriptionResponse parseDelimitedFrom(InputStream inputStream) {
            return (SubscriptionResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscriptionResponse parseFrom(ByteBuffer byteBuffer) {
            return (SubscriptionResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SubscriptionResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setErr(LivekitModels.SubscriptionError subscriptionError) {
            this.err_ = subscriptionError.getNumber();
        }

        private void setErrValue(int i) {
            this.err_ = i;
        }

        private void setTrackSid(String str) {
            str.getClass();
            this.trackSid_ = str;
        }

        private void setTrackSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackSid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SubscriptionResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002\f", new Object[]{"trackSid_", "err_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SubscriptionResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SubscriptionResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.SubscriptionError getErr() {
            LivekitModels.SubscriptionError subscriptionErrorB = LivekitModels.SubscriptionError.b(this.err_);
            return subscriptionErrorB == null ? LivekitModels.SubscriptionError.e : subscriptionErrorB;
        }

        public int getErrValue() {
            return this.err_;
        }

        public String getTrackSid() {
            return this.trackSid_;
        }

        public ByteString getTrackSidBytes() {
            return ByteString.n(this.trackSid_);
        }

        public static Builder newBuilder(SubscriptionResponse subscriptionResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(subscriptionResponse);
        }

        public static SubscriptionResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscriptionResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SubscriptionResponse parseFrom(ByteString byteString) {
            return (SubscriptionResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SubscriptionResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SubscriptionResponse parseFrom(byte[] bArr) {
            return (SubscriptionResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SubscriptionResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SubscriptionResponse parseFrom(InputStream inputStream) {
            return (SubscriptionResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscriptionResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscriptionResponse parseFrom(CodedInputStream codedInputStream) {
            return (SubscriptionResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SubscriptionResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscriptionResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SubscriptionResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SyncState extends GeneratedMessageLite<SyncState, Builder> implements SyncStateOrBuilder {
        public static final int ANSWER_FIELD_NUMBER = 1;
        public static final int DATACHANNEL_RECEIVE_STATES_FIELD_NUMBER = 7;
        public static final int DATA_CHANNELS_FIELD_NUMBER = 4;
        private static final SyncState DEFAULT_INSTANCE;
        public static final int OFFER_FIELD_NUMBER = 5;
        private static volatile Parser<SyncState> PARSER = null;
        public static final int PUBLISH_TRACKS_FIELD_NUMBER = 3;
        public static final int SUBSCRIPTION_FIELD_NUMBER = 2;
        public static final int TRACK_SIDS_DISABLED_FIELD_NUMBER = 6;
        private SessionDescription answer_;
        private SessionDescription offer_;
        private UpdateSubscription subscription_;
        private Internal.ProtobufList<TrackPublishedResponse> publishTracks_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<DataChannelInfo> dataChannels_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<String> trackSidsDisabled_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<DataChannelReceiveState> datachannelReceiveStates_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SyncState, Builder> implements SyncStateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(Iterable iterable) {
                q();
                ((SyncState) ((GeneratedMessageLite.Builder) this).b).addAllDataChannels(iterable);
                return this;
            }

            public Builder B(Iterable iterable) {
                q();
                ((SyncState) ((GeneratedMessageLite.Builder) this).b).addAllDatachannelReceiveStates(iterable);
                return this;
            }

            public Builder C(Iterable iterable) {
                q();
                ((SyncState) ((GeneratedMessageLite.Builder) this).b).addAllPublishTracks(iterable);
                return this;
            }

            public Builder D(SessionDescription sessionDescription) {
                q();
                ((SyncState) ((GeneratedMessageLite.Builder) this).b).setAnswer(sessionDescription);
                return this;
            }

            public Builder E(SessionDescription sessionDescription) {
                q();
                ((SyncState) ((GeneratedMessageLite.Builder) this).b).setOffer(sessionDescription);
                return this;
            }

            public Builder F(UpdateSubscription updateSubscription) {
                q();
                ((SyncState) ((GeneratedMessageLite.Builder) this).b).setSubscription(updateSubscription);
                return this;
            }

            private Builder() {
                super(SyncState.DEFAULT_INSTANCE);
            }
        }

        static {
            SyncState syncState = new SyncState();
            DEFAULT_INSTANCE = syncState;
            GeneratedMessageLite.registerDefaultInstance(SyncState.class, syncState);
        }

        private SyncState() {
        }

        private void addAllDataChannels(Iterable<? extends DataChannelInfo> iterable) {
            ensureDataChannelsIsMutable();
            AbstractMessageLite.addAll(iterable, this.dataChannels_);
        }

        private void addAllDatachannelReceiveStates(Iterable<? extends DataChannelReceiveState> iterable) {
            ensureDatachannelReceiveStatesIsMutable();
            AbstractMessageLite.addAll(iterable, this.datachannelReceiveStates_);
        }

        private void addAllPublishTracks(Iterable<? extends TrackPublishedResponse> iterable) {
            ensurePublishTracksIsMutable();
            AbstractMessageLite.addAll(iterable, this.publishTracks_);
        }

        private void addAllTrackSidsDisabled(Iterable<String> iterable) {
            ensureTrackSidsDisabledIsMutable();
            AbstractMessageLite.addAll(iterable, this.trackSidsDisabled_);
        }

        private void addDataChannels(DataChannelInfo dataChannelInfo) {
            dataChannelInfo.getClass();
            ensureDataChannelsIsMutable();
            this.dataChannels_.add(dataChannelInfo);
        }

        private void addDatachannelReceiveStates(DataChannelReceiveState dataChannelReceiveState) {
            dataChannelReceiveState.getClass();
            ensureDatachannelReceiveStatesIsMutable();
            this.datachannelReceiveStates_.add(dataChannelReceiveState);
        }

        private void addPublishTracks(TrackPublishedResponse trackPublishedResponse) {
            trackPublishedResponse.getClass();
            ensurePublishTracksIsMutable();
            this.publishTracks_.add(trackPublishedResponse);
        }

        private void addTrackSidsDisabled(String str) {
            str.getClass();
            ensureTrackSidsDisabledIsMutable();
            this.trackSidsDisabled_.add(str);
        }

        private void addTrackSidsDisabledBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureTrackSidsDisabledIsMutable();
            this.trackSidsDisabled_.add(byteString.L());
        }

        private void clearAnswer() {
            this.answer_ = null;
        }

        private void clearDataChannels() {
            this.dataChannels_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearDatachannelReceiveStates() {
            this.datachannelReceiveStates_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearOffer() {
            this.offer_ = null;
        }

        private void clearPublishTracks() {
            this.publishTracks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSubscription() {
            this.subscription_ = null;
        }

        private void clearTrackSidsDisabled() {
            this.trackSidsDisabled_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureDataChannelsIsMutable() {
            Internal.ProtobufList<DataChannelInfo> protobufList = this.dataChannels_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.dataChannels_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureDatachannelReceiveStatesIsMutable() {
            Internal.ProtobufList<DataChannelReceiveState> protobufList = this.datachannelReceiveStates_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.datachannelReceiveStates_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensurePublishTracksIsMutable() {
            Internal.ProtobufList<TrackPublishedResponse> protobufList = this.publishTracks_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.publishTracks_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureTrackSidsDisabledIsMutable() {
            Internal.ProtobufList<String> protobufList = this.trackSidsDisabled_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trackSidsDisabled_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SyncState getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAnswer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            SessionDescription sessionDescription2 = this.answer_;
            if (sessionDescription2 == null || sessionDescription2 == SessionDescription.getDefaultInstance()) {
                this.answer_ = sessionDescription;
            } else {
                this.answer_ = (SessionDescription) ((SessionDescription.Builder) SessionDescription.newBuilder(this.answer_).v(sessionDescription)).o();
            }
        }

        private void mergeOffer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            SessionDescription sessionDescription2 = this.offer_;
            if (sessionDescription2 == null || sessionDescription2 == SessionDescription.getDefaultInstance()) {
                this.offer_ = sessionDescription;
            } else {
                this.offer_ = (SessionDescription) ((SessionDescription.Builder) SessionDescription.newBuilder(this.offer_).v(sessionDescription)).o();
            }
        }

        private void mergeSubscription(UpdateSubscription updateSubscription) {
            updateSubscription.getClass();
            UpdateSubscription updateSubscription2 = this.subscription_;
            if (updateSubscription2 == null || updateSubscription2 == UpdateSubscription.getDefaultInstance()) {
                this.subscription_ = updateSubscription;
            } else {
                this.subscription_ = (UpdateSubscription) ((UpdateSubscription.Builder) UpdateSubscription.newBuilder(this.subscription_).v(updateSubscription)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SyncState parseDelimitedFrom(InputStream inputStream) {
            return (SyncState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SyncState parseFrom(ByteBuffer byteBuffer) {
            return (SyncState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SyncState> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeDataChannels(int i) {
            ensureDataChannelsIsMutable();
            this.dataChannels_.remove(i);
        }

        private void removeDatachannelReceiveStates(int i) {
            ensureDatachannelReceiveStatesIsMutable();
            this.datachannelReceiveStates_.remove(i);
        }

        private void removePublishTracks(int i) {
            ensurePublishTracksIsMutable();
            this.publishTracks_.remove(i);
        }

        private void setAnswer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            this.answer_ = sessionDescription;
        }

        private void setDataChannels(int i, DataChannelInfo dataChannelInfo) {
            dataChannelInfo.getClass();
            ensureDataChannelsIsMutable();
            this.dataChannels_.set(i, dataChannelInfo);
        }

        private void setDatachannelReceiveStates(int i, DataChannelReceiveState dataChannelReceiveState) {
            dataChannelReceiveState.getClass();
            ensureDatachannelReceiveStatesIsMutable();
            this.datachannelReceiveStates_.set(i, dataChannelReceiveState);
        }

        private void setOffer(SessionDescription sessionDescription) {
            sessionDescription.getClass();
            this.offer_ = sessionDescription;
        }

        private void setPublishTracks(int i, TrackPublishedResponse trackPublishedResponse) {
            trackPublishedResponse.getClass();
            ensurePublishTracksIsMutable();
            this.publishTracks_.set(i, trackPublishedResponse);
        }

        private void setSubscription(UpdateSubscription updateSubscription) {
            updateSubscription.getClass();
            this.subscription_ = updateSubscription;
        }

        private void setTrackSidsDisabled(int i, String str) {
            str.getClass();
            ensureTrackSidsDisabledIsMutable();
            this.trackSidsDisabled_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SyncState();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0000\u0000\u0001\u0007\u0007\u0000\u0004\u0000\u0001\t\u0002\t\u0003\u001b\u0004\u001b\u0005\t\u0006Ț\u0007\u001b", new Object[]{ap.a(55391797), ap.a(347845338), ap.a(1302462374), TrackPublishedResponse.class, ap.a(485215944), DataChannelInfo.class, ap.a(422485243), ap.a(985372608), ap.a(998721607), DataChannelReceiveState.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SyncState> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SyncState.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SessionDescription getAnswer() {
            SessionDescription sessionDescription = this.answer_;
            return sessionDescription == null ? SessionDescription.getDefaultInstance() : sessionDescription;
        }

        public DataChannelInfo getDataChannels(int i) {
            return (DataChannelInfo) this.dataChannels_.get(i);
        }

        public int getDataChannelsCount() {
            return this.dataChannels_.size();
        }

        public List<DataChannelInfo> getDataChannelsList() {
            return this.dataChannels_;
        }

        public DataChannelInfoOrBuilder getDataChannelsOrBuilder(int i) {
            return (DataChannelInfoOrBuilder) this.dataChannels_.get(i);
        }

        public List<? extends DataChannelInfoOrBuilder> getDataChannelsOrBuilderList() {
            return this.dataChannels_;
        }

        public DataChannelReceiveState getDatachannelReceiveStates(int i) {
            return (DataChannelReceiveState) this.datachannelReceiveStates_.get(i);
        }

        public int getDatachannelReceiveStatesCount() {
            return this.datachannelReceiveStates_.size();
        }

        public List<DataChannelReceiveState> getDatachannelReceiveStatesList() {
            return this.datachannelReceiveStates_;
        }

        public DataChannelReceiveStateOrBuilder getDatachannelReceiveStatesOrBuilder(int i) {
            return (DataChannelReceiveStateOrBuilder) this.datachannelReceiveStates_.get(i);
        }

        public List<? extends DataChannelReceiveStateOrBuilder> getDatachannelReceiveStatesOrBuilderList() {
            return this.datachannelReceiveStates_;
        }

        public SessionDescription getOffer() {
            SessionDescription sessionDescription = this.offer_;
            return sessionDescription == null ? SessionDescription.getDefaultInstance() : sessionDescription;
        }

        public TrackPublishedResponse getPublishTracks(int i) {
            return (TrackPublishedResponse) this.publishTracks_.get(i);
        }

        public int getPublishTracksCount() {
            return this.publishTracks_.size();
        }

        public List<TrackPublishedResponse> getPublishTracksList() {
            return this.publishTracks_;
        }

        public TrackPublishedResponseOrBuilder getPublishTracksOrBuilder(int i) {
            return (TrackPublishedResponseOrBuilder) this.publishTracks_.get(i);
        }

        public List<? extends TrackPublishedResponseOrBuilder> getPublishTracksOrBuilderList() {
            return this.publishTracks_;
        }

        public UpdateSubscription getSubscription() {
            UpdateSubscription updateSubscription = this.subscription_;
            return updateSubscription == null ? UpdateSubscription.getDefaultInstance() : updateSubscription;
        }

        public String getTrackSidsDisabled(int i) {
            return (String) this.trackSidsDisabled_.get(i);
        }

        public ByteString getTrackSidsDisabledBytes(int i) {
            return ByteString.n((String) this.trackSidsDisabled_.get(i));
        }

        public int getTrackSidsDisabledCount() {
            return this.trackSidsDisabled_.size();
        }

        public List<String> getTrackSidsDisabledList() {
            return this.trackSidsDisabled_;
        }

        public boolean hasAnswer() {
            return this.answer_ != null;
        }

        public boolean hasOffer() {
            return this.offer_ != null;
        }

        public boolean hasSubscription() {
            return this.subscription_ != null;
        }

        public static Builder newBuilder(SyncState syncState) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(syncState);
        }

        public static SyncState parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SyncState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SyncState parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SyncState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SyncState parseFrom(ByteString byteString) {
            return (SyncState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addDataChannels(int i, DataChannelInfo dataChannelInfo) {
            dataChannelInfo.getClass();
            ensureDataChannelsIsMutable();
            this.dataChannels_.add(i, dataChannelInfo);
        }

        private void addDatachannelReceiveStates(int i, DataChannelReceiveState dataChannelReceiveState) {
            dataChannelReceiveState.getClass();
            ensureDatachannelReceiveStatesIsMutable();
            this.datachannelReceiveStates_.add(i, dataChannelReceiveState);
        }

        private void addPublishTracks(int i, TrackPublishedResponse trackPublishedResponse) {
            trackPublishedResponse.getClass();
            ensurePublishTracksIsMutable();
            this.publishTracks_.add(i, trackPublishedResponse);
        }

        public static SyncState parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SyncState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SyncState parseFrom(byte[] bArr) {
            return (SyncState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SyncState parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SyncState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SyncState parseFrom(InputStream inputStream) {
            return (SyncState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SyncState parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SyncState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SyncState parseFrom(CodedInputStream codedInputStream) {
            return (SyncState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SyncState parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SyncState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SyncStateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TrackPermission extends GeneratedMessageLite<TrackPermission, Builder> implements TrackPermissionOrBuilder {
        public static final int ALL_TRACKS_FIELD_NUMBER = 2;
        private static final TrackPermission DEFAULT_INSTANCE;
        private static volatile Parser<TrackPermission> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 4;
        public static final int PARTICIPANT_SID_FIELD_NUMBER = 1;
        public static final int TRACK_SIDS_FIELD_NUMBER = 3;
        private boolean allTracks_;
        private String participantIdentity_;
        private String participantSid_;
        private Internal.ProtobufList<String> trackSids_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TrackPermission, Builder> implements TrackPermissionOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TrackPermission.DEFAULT_INSTANCE);
            }
        }

        static {
            TrackPermission trackPermission = new TrackPermission();
            DEFAULT_INSTANCE = trackPermission;
            GeneratedMessageLite.registerDefaultInstance(TrackPermission.class, trackPermission);
        }

        private TrackPermission() {
            String strA = ap.a(12372928);
            this.participantSid_ = strA;
            this.trackSids_ = GeneratedMessageLite.emptyProtobufList();
            this.participantIdentity_ = strA;
        }

        private void addAllTrackSids(Iterable<String> iterable) {
            ensureTrackSidsIsMutable();
            AbstractMessageLite.addAll(iterable, this.trackSids_);
        }

        private void addTrackSids(String str) {
            str.getClass();
            ensureTrackSidsIsMutable();
            this.trackSids_.add(str);
        }

        private void addTrackSidsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureTrackSidsIsMutable();
            this.trackSids_.add(byteString.L());
        }

        private void clearAllTracks() {
            this.allTracks_ = false;
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearParticipantSid() {
            this.participantSid_ = getDefaultInstance().getParticipantSid();
        }

        private void clearTrackSids() {
            this.trackSids_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureTrackSidsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.trackSids_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trackSids_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static TrackPermission getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TrackPermission parseDelimitedFrom(InputStream inputStream) {
            return (TrackPermission) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackPermission parseFrom(ByteBuffer byteBuffer) {
            return (TrackPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TrackPermission> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAllTracks(boolean z) {
            this.allTracks_ = z;
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setParticipantSid(String str) {
            str.getClass();
            this.participantSid_ = str;
        }

        private void setParticipantSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantSid_ = byteString.L();
        }

        private void setTrackSids(int i, String str) {
            str.getClass();
            ensureTrackSidsIsMutable();
            this.trackSids_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TrackPermission();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0001\u0000\u0001Ȉ\u0002\u0007\u0003Ț\u0004Ȉ", new Object[]{"participantSid_", "allTracks_", "trackSids_", "participantIdentity_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TrackPermission> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TrackPermission.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getAllTracks() {
            return this.allTracks_;
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getParticipantSid() {
            return this.participantSid_;
        }

        public ByteString getParticipantSidBytes() {
            return ByteString.n(this.participantSid_);
        }

        public String getTrackSids(int i) {
            return (String) this.trackSids_.get(i);
        }

        public ByteString getTrackSidsBytes(int i) {
            return ByteString.n((String) this.trackSids_.get(i));
        }

        public int getTrackSidsCount() {
            return this.trackSids_.size();
        }

        public List<String> getTrackSidsList() {
            return this.trackSids_;
        }

        public static Builder newBuilder(TrackPermission trackPermission) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(trackPermission);
        }

        public static TrackPermission parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPermission) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackPermission parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TrackPermission parseFrom(ByteString byteString) {
            return (TrackPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TrackPermission parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TrackPermission parseFrom(byte[] bArr) {
            return (TrackPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TrackPermission parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TrackPermission parseFrom(InputStream inputStream) {
            return (TrackPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackPermission parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackPermission parseFrom(CodedInputStream codedInputStream) {
            return (TrackPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TrackPermission parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TrackPermissionOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TrackPublishedResponse extends GeneratedMessageLite<TrackPublishedResponse, Builder> implements TrackPublishedResponseOrBuilder {
        public static final int CID_FIELD_NUMBER = 1;
        private static final TrackPublishedResponse DEFAULT_INSTANCE;
        private static volatile Parser<TrackPublishedResponse> PARSER = null;
        public static final int TRACK_FIELD_NUMBER = 2;
        private String cid_ = ap.a(2067191130);
        private LivekitModels.TrackInfo track_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TrackPublishedResponse, Builder> implements TrackPublishedResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(String str) {
                q();
                ((TrackPublishedResponse) ((GeneratedMessageLite.Builder) this).b).setCid(str);
                return this;
            }

            public Builder B(LivekitModels.TrackInfo trackInfo) {
                q();
                ((TrackPublishedResponse) ((GeneratedMessageLite.Builder) this).b).setTrack(trackInfo);
                return this;
            }

            private Builder() {
                super(TrackPublishedResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            TrackPublishedResponse trackPublishedResponse = new TrackPublishedResponse();
            DEFAULT_INSTANCE = trackPublishedResponse;
            GeneratedMessageLite.registerDefaultInstance(TrackPublishedResponse.class, trackPublishedResponse);
        }

        private TrackPublishedResponse() {
        }

        private void clearCid() {
            this.cid_ = getDefaultInstance().getCid();
        }

        private void clearTrack() {
            this.track_ = null;
        }

        public static TrackPublishedResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeTrack(LivekitModels.TrackInfo trackInfo) {
            trackInfo.getClass();
            LivekitModels.TrackInfo trackInfo2 = this.track_;
            if (trackInfo2 == null || trackInfo2 == LivekitModels.TrackInfo.getDefaultInstance()) {
                this.track_ = trackInfo;
            } else {
                this.track_ = (LivekitModels.TrackInfo) ((LivekitModels.TrackInfo.Builder) LivekitModels.TrackInfo.newBuilder(this.track_).v(trackInfo)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TrackPublishedResponse parseDelimitedFrom(InputStream inputStream) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackPublishedResponse parseFrom(ByteBuffer byteBuffer) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TrackPublishedResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCid(String str) {
            str.getClass();
            this.cid_ = str;
        }

        private void setCidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.cid_ = byteString.L();
        }

        private void setTrack(LivekitModels.TrackInfo trackInfo) {
            trackInfo.getClass();
            this.track_ = trackInfo;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TrackPublishedResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002\t", new Object[]{"cid_", "track_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TrackPublishedResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TrackPublishedResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getCid() {
            return this.cid_;
        }

        public ByteString getCidBytes() {
            return ByteString.n(this.cid_);
        }

        public LivekitModels.TrackInfo getTrack() {
            LivekitModels.TrackInfo trackInfo = this.track_;
            return trackInfo == null ? LivekitModels.TrackInfo.getDefaultInstance() : trackInfo;
        }

        public boolean hasTrack() {
            return this.track_ != null;
        }

        public static Builder newBuilder(TrackPublishedResponse trackPublishedResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(trackPublishedResponse);
        }

        public static TrackPublishedResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackPublishedResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TrackPublishedResponse parseFrom(ByteString byteString) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TrackPublishedResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TrackPublishedResponse parseFrom(byte[] bArr) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TrackPublishedResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TrackPublishedResponse parseFrom(InputStream inputStream) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackPublishedResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackPublishedResponse parseFrom(CodedInputStream codedInputStream) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TrackPublishedResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackPublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TrackPublishedResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TrackSubscribed extends GeneratedMessageLite<TrackSubscribed, Builder> implements TrackSubscribedOrBuilder {
        private static final TrackSubscribed DEFAULT_INSTANCE;
        private static volatile Parser<TrackSubscribed> PARSER = null;
        public static final int TRACK_SID_FIELD_NUMBER = 1;
        private String trackSid_ = ap.a(1330578427);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TrackSubscribed, Builder> implements TrackSubscribedOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TrackSubscribed.DEFAULT_INSTANCE);
            }
        }

        static {
            TrackSubscribed trackSubscribed = new TrackSubscribed();
            DEFAULT_INSTANCE = trackSubscribed;
            GeneratedMessageLite.registerDefaultInstance(TrackSubscribed.class, trackSubscribed);
        }

        private TrackSubscribed() {
        }

        private void clearTrackSid() {
            this.trackSid_ = getDefaultInstance().getTrackSid();
        }

        public static TrackSubscribed getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TrackSubscribed parseDelimitedFrom(InputStream inputStream) {
            return (TrackSubscribed) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackSubscribed parseFrom(ByteBuffer byteBuffer) {
            return (TrackSubscribed) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TrackSubscribed> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setTrackSid(String str) {
            str.getClass();
            this.trackSid_ = str;
        }

        private void setTrackSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackSid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TrackSubscribed();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"trackSid_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TrackSubscribed> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TrackSubscribed.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getTrackSid() {
            return this.trackSid_;
        }

        public ByteString getTrackSidBytes() {
            return ByteString.n(this.trackSid_);
        }

        public static Builder newBuilder(TrackSubscribed trackSubscribed) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(trackSubscribed);
        }

        public static TrackSubscribed parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackSubscribed) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackSubscribed parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackSubscribed) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TrackSubscribed parseFrom(ByteString byteString) {
            return (TrackSubscribed) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TrackSubscribed parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackSubscribed) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TrackSubscribed parseFrom(byte[] bArr) {
            return (TrackSubscribed) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TrackSubscribed parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackSubscribed) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TrackSubscribed parseFrom(InputStream inputStream) {
            return (TrackSubscribed) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackSubscribed parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackSubscribed) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackSubscribed parseFrom(CodedInputStream codedInputStream) {
            return (TrackSubscribed) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TrackSubscribed parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackSubscribed) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TrackSubscribedOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TrackUnpublishedResponse extends GeneratedMessageLite<TrackUnpublishedResponse, Builder> implements TrackUnpublishedResponseOrBuilder {
        private static final TrackUnpublishedResponse DEFAULT_INSTANCE;
        private static volatile Parser<TrackUnpublishedResponse> PARSER = null;
        public static final int TRACK_SID_FIELD_NUMBER = 1;
        private String trackSid_ = ap.a(1297717118);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TrackUnpublishedResponse, Builder> implements TrackUnpublishedResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TrackUnpublishedResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            TrackUnpublishedResponse trackUnpublishedResponse = new TrackUnpublishedResponse();
            DEFAULT_INSTANCE = trackUnpublishedResponse;
            GeneratedMessageLite.registerDefaultInstance(TrackUnpublishedResponse.class, trackUnpublishedResponse);
        }

        private TrackUnpublishedResponse() {
        }

        private void clearTrackSid() {
            this.trackSid_ = getDefaultInstance().getTrackSid();
        }

        public static TrackUnpublishedResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TrackUnpublishedResponse parseDelimitedFrom(InputStream inputStream) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackUnpublishedResponse parseFrom(ByteBuffer byteBuffer) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TrackUnpublishedResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setTrackSid(String str) {
            str.getClass();
            this.trackSid_ = str;
        }

        private void setTrackSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackSid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TrackUnpublishedResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"trackSid_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TrackUnpublishedResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TrackUnpublishedResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getTrackSid() {
            return this.trackSid_;
        }

        public ByteString getTrackSidBytes() {
            return ByteString.n(this.trackSid_);
        }

        public static Builder newBuilder(TrackUnpublishedResponse trackUnpublishedResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(trackUnpublishedResponse);
        }

        public static TrackUnpublishedResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackUnpublishedResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TrackUnpublishedResponse parseFrom(ByteString byteString) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TrackUnpublishedResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TrackUnpublishedResponse parseFrom(byte[] bArr) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TrackUnpublishedResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TrackUnpublishedResponse parseFrom(InputStream inputStream) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackUnpublishedResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackUnpublishedResponse parseFrom(CodedInputStream codedInputStream) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TrackUnpublishedResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackUnpublishedResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TrackUnpublishedResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TrickleRequest extends GeneratedMessageLite<TrickleRequest, Builder> implements TrickleRequestOrBuilder {
        public static final int CANDIDATEINIT_FIELD_NUMBER = 1;
        private static final TrickleRequest DEFAULT_INSTANCE;
        public static final int FINAL_FIELD_NUMBER = 3;
        private static volatile Parser<TrickleRequest> PARSER = null;
        public static final int TARGET_FIELD_NUMBER = 2;
        private String candidateInit_ = ap.a(571575543);
        private boolean final_;
        private int target_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TrickleRequest, Builder> implements TrickleRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(String str) {
                q();
                ((TrickleRequest) ((GeneratedMessageLite.Builder) this).b).setCandidateInit(str);
                return this;
            }

            public Builder B(SignalTarget signalTarget) {
                q();
                ((TrickleRequest) ((GeneratedMessageLite.Builder) this).b).setTarget(signalTarget);
                return this;
            }

            private Builder() {
                super(TrickleRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            TrickleRequest trickleRequest = new TrickleRequest();
            DEFAULT_INSTANCE = trickleRequest;
            GeneratedMessageLite.registerDefaultInstance(TrickleRequest.class, trickleRequest);
        }

        private TrickleRequest() {
        }

        private void clearCandidateInit() {
            this.candidateInit_ = getDefaultInstance().getCandidateInit();
        }

        private void clearFinal() {
            this.final_ = false;
        }

        private void clearTarget() {
            this.target_ = 0;
        }

        public static TrickleRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TrickleRequest parseDelimitedFrom(InputStream inputStream) {
            return (TrickleRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrickleRequest parseFrom(ByteBuffer byteBuffer) {
            return (TrickleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TrickleRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCandidateInit(String str) {
            str.getClass();
            this.candidateInit_ = str;
        }

        private void setCandidateInitBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.candidateInit_ = byteString.L();
        }

        private void setFinal(boolean z) {
            this.final_ = z;
        }

        private void setTarget(SignalTarget signalTarget) {
            this.target_ = signalTarget.getNumber();
        }

        private void setTargetValue(int i) {
            this.target_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TrickleRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002\f\u0003\u0007", new Object[]{"candidateInit_", "target_", "final_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TrickleRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TrickleRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getCandidateInit() {
            return this.candidateInit_;
        }

        public ByteString getCandidateInitBytes() {
            return ByteString.n(this.candidateInit_);
        }

        public boolean getFinal() {
            return this.final_;
        }

        public SignalTarget getTarget() {
            SignalTarget signalTargetB = SignalTarget.b(this.target_);
            return signalTargetB == null ? SignalTarget.d : signalTargetB;
        }

        public int getTargetValue() {
            return this.target_;
        }

        public static Builder newBuilder(TrickleRequest trickleRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(trickleRequest);
        }

        public static TrickleRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrickleRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrickleRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TrickleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TrickleRequest parseFrom(ByteString byteString) {
            return (TrickleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TrickleRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TrickleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TrickleRequest parseFrom(byte[] bArr) {
            return (TrickleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TrickleRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TrickleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TrickleRequest parseFrom(InputStream inputStream) {
            return (TrickleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrickleRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrickleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrickleRequest parseFrom(CodedInputStream codedInputStream) {
            return (TrickleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TrickleRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrickleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TrickleRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateLocalAudioTrack extends GeneratedMessageLite<UpdateLocalAudioTrack, Builder> implements UpdateLocalAudioTrackOrBuilder {
        private static final UpdateLocalAudioTrack DEFAULT_INSTANCE;
        public static final int FEATURES_FIELD_NUMBER = 2;
        private static volatile Parser<UpdateLocalAudioTrack> PARSER = null;
        public static final int TRACK_SID_FIELD_NUMBER = 1;
        private static final Internal.ListAdapter.Converter<Integer, LivekitModels.AudioTrackFeature> features_converter_ = new Internal.ListAdapter.Converter<Integer, LivekitModels.AudioTrackFeature>() { // from class: livekit.LivekitRtc.UpdateLocalAudioTrack.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public LivekitModels.AudioTrackFeature convert(Integer num) {
                LivekitModels.AudioTrackFeature audioTrackFeatureB = LivekitModels.AudioTrackFeature.b(num.intValue());
                return audioTrackFeatureB == null ? LivekitModels.AudioTrackFeature.i : audioTrackFeatureB;
            }
        };
        private int featuresMemoizedSerializedSize;
        private String trackSid_ = ap.a(1057822111);
        private Internal.IntList features_ = GeneratedMessageLite.emptyIntList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateLocalAudioTrack, Builder> implements UpdateLocalAudioTrackOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(Iterable iterable) {
                q();
                ((UpdateLocalAudioTrack) ((GeneratedMessageLite.Builder) this).b).addAllFeatures(iterable);
                return this;
            }

            public Builder B(String str) {
                q();
                ((UpdateLocalAudioTrack) ((GeneratedMessageLite.Builder) this).b).setTrackSid(str);
                return this;
            }

            private Builder() {
                super(UpdateLocalAudioTrack.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateLocalAudioTrack updateLocalAudioTrack = new UpdateLocalAudioTrack();
            DEFAULT_INSTANCE = updateLocalAudioTrack;
            GeneratedMessageLite.registerDefaultInstance(UpdateLocalAudioTrack.class, updateLocalAudioTrack);
        }

        private UpdateLocalAudioTrack() {
        }

        private void addAllFeatures(Iterable<? extends LivekitModels.AudioTrackFeature> iterable) {
            ensureFeaturesIsMutable();
            Iterator<? extends LivekitModels.AudioTrackFeature> it = iterable.iterator();
            while (it.hasNext()) {
                this.features_.addInt(it.next().getNumber());
            }
        }

        private void addAllFeaturesValue(Iterable<Integer> iterable) {
            ensureFeaturesIsMutable();
            Iterator<Integer> it = iterable.iterator();
            while (it.hasNext()) {
                this.features_.addInt(it.next().intValue());
            }
        }

        private void addFeatures(LivekitModels.AudioTrackFeature audioTrackFeature) {
            audioTrackFeature.getClass();
            ensureFeaturesIsMutable();
            this.features_.addInt(audioTrackFeature.getNumber());
        }

        private void addFeaturesValue(int i) {
            ensureFeaturesIsMutable();
            this.features_.addInt(i);
        }

        private void clearFeatures() {
            this.features_ = GeneratedMessageLite.emptyIntList();
        }

        private void clearTrackSid() {
            this.trackSid_ = getDefaultInstance().getTrackSid();
        }

        private void ensureFeaturesIsMutable() {
            Internal.IntList intList = this.features_;
            if (intList.isModifiable()) {
                return;
            }
            this.features_ = GeneratedMessageLite.mutableCopy(intList);
        }

        public static UpdateLocalAudioTrack getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateLocalAudioTrack parseDelimitedFrom(InputStream inputStream) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateLocalAudioTrack parseFrom(ByteBuffer byteBuffer) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateLocalAudioTrack> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setFeatures(int i, LivekitModels.AudioTrackFeature audioTrackFeature) {
            audioTrackFeature.getClass();
            ensureFeaturesIsMutable();
            this.features_.setInt(i, audioTrackFeature.getNumber());
        }

        private void setFeaturesValue(int i, int i2) {
            ensureFeaturesIsMutable();
            this.features_.setInt(i, i2);
        }

        private void setTrackSid(String str) {
            str.getClass();
            this.trackSid_ = str;
        }

        private void setTrackSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackSid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateLocalAudioTrack();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001Ȉ\u0002,", new Object[]{"trackSid_", "features_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateLocalAudioTrack> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateLocalAudioTrack.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.AudioTrackFeature getFeatures(int i) {
            LivekitModels.AudioTrackFeature audioTrackFeatureB = LivekitModels.AudioTrackFeature.b(this.features_.getInt(i));
            return audioTrackFeatureB == null ? LivekitModels.AudioTrackFeature.i : audioTrackFeatureB;
        }

        public int getFeaturesCount() {
            return this.features_.size();
        }

        public List<LivekitModels.AudioTrackFeature> getFeaturesList() {
            return new Internal.ListAdapter(this.features_, features_converter_);
        }

        public int getFeaturesValue(int i) {
            return this.features_.getInt(i);
        }

        public List<Integer> getFeaturesValueList() {
            return this.features_;
        }

        public String getTrackSid() {
            return this.trackSid_;
        }

        public ByteString getTrackSidBytes() {
            return ByteString.n(this.trackSid_);
        }

        public static Builder newBuilder(UpdateLocalAudioTrack updateLocalAudioTrack) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateLocalAudioTrack);
        }

        public static UpdateLocalAudioTrack parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateLocalAudioTrack parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateLocalAudioTrack parseFrom(ByteString byteString) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateLocalAudioTrack parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateLocalAudioTrack parseFrom(byte[] bArr) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateLocalAudioTrack parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateLocalAudioTrack parseFrom(InputStream inputStream) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateLocalAudioTrack parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateLocalAudioTrack parseFrom(CodedInputStream codedInputStream) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateLocalAudioTrack parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalAudioTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateLocalAudioTrackOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateLocalVideoTrack extends GeneratedMessageLite<UpdateLocalVideoTrack, Builder> implements UpdateLocalVideoTrackOrBuilder {
        private static final UpdateLocalVideoTrack DEFAULT_INSTANCE;
        public static final int HEIGHT_FIELD_NUMBER = 3;
        private static volatile Parser<UpdateLocalVideoTrack> PARSER = null;
        public static final int TRACK_SID_FIELD_NUMBER = 1;
        public static final int WIDTH_FIELD_NUMBER = 2;
        private int height_;
        private String trackSid_ = ap.a(1870723538);
        private int width_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateLocalVideoTrack, Builder> implements UpdateLocalVideoTrackOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateLocalVideoTrack.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateLocalVideoTrack updateLocalVideoTrack = new UpdateLocalVideoTrack();
            DEFAULT_INSTANCE = updateLocalVideoTrack;
            GeneratedMessageLite.registerDefaultInstance(UpdateLocalVideoTrack.class, updateLocalVideoTrack);
        }

        private UpdateLocalVideoTrack() {
        }

        private void clearHeight() {
            this.height_ = 0;
        }

        private void clearTrackSid() {
            this.trackSid_ = getDefaultInstance().getTrackSid();
        }

        private void clearWidth() {
            this.width_ = 0;
        }

        public static UpdateLocalVideoTrack getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateLocalVideoTrack parseDelimitedFrom(InputStream inputStream) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateLocalVideoTrack parseFrom(ByteBuffer byteBuffer) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateLocalVideoTrack> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setHeight(int i) {
            this.height_ = i;
        }

        private void setTrackSid(String str) {
            str.getClass();
            this.trackSid_ = str;
        }

        private void setTrackSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackSid_ = byteString.L();
        }

        private void setWidth(int i) {
            this.width_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateLocalVideoTrack();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002\u000b\u0003\u000b", new Object[]{"trackSid_", "width_", "height_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateLocalVideoTrack> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateLocalVideoTrack.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getHeight() {
            return this.height_;
        }

        public String getTrackSid() {
            return this.trackSid_;
        }

        public ByteString getTrackSidBytes() {
            return ByteString.n(this.trackSid_);
        }

        public int getWidth() {
            return this.width_;
        }

        public static Builder newBuilder(UpdateLocalVideoTrack updateLocalVideoTrack) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateLocalVideoTrack);
        }

        public static UpdateLocalVideoTrack parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateLocalVideoTrack parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateLocalVideoTrack parseFrom(ByteString byteString) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateLocalVideoTrack parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateLocalVideoTrack parseFrom(byte[] bArr) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateLocalVideoTrack parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateLocalVideoTrack parseFrom(InputStream inputStream) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateLocalVideoTrack parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateLocalVideoTrack parseFrom(CodedInputStream codedInputStream) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateLocalVideoTrack parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLocalVideoTrack) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateLocalVideoTrackOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateParticipantMetadata extends GeneratedMessageLite<UpdateParticipantMetadata, Builder> implements UpdateParticipantMetadataOrBuilder {
        public static final int ATTRIBUTES_FIELD_NUMBER = 3;
        private static final UpdateParticipantMetadata DEFAULT_INSTANCE;
        public static final int METADATA_FIELD_NUMBER = 1;
        public static final int NAME_FIELD_NUMBER = 2;
        private static volatile Parser<UpdateParticipantMetadata> PARSER = null;
        public static final int REQUEST_ID_FIELD_NUMBER = 4;
        private MapFieldLite<String, String> attributes_ = MapFieldLite.f();
        private String metadata_;
        private String name_;
        private int requestId_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(1247181264);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private AttributesDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateParticipantMetadata, Builder> implements UpdateParticipantMetadataOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateParticipantMetadata.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateParticipantMetadata updateParticipantMetadata = new UpdateParticipantMetadata();
            DEFAULT_INSTANCE = updateParticipantMetadata;
            GeneratedMessageLite.registerDefaultInstance(UpdateParticipantMetadata.class, updateParticipantMetadata);
        }

        private UpdateParticipantMetadata() {
            String strA = ap.a(114475096);
            this.metadata_ = strA;
            this.name_ = strA;
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearRequestId() {
            this.requestId_ = 0;
        }

        public static UpdateParticipantMetadata getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableAttributesMap() {
            return internalGetMutableAttributes();
        }

        private MapFieldLite<String, String> internalGetAttributes() {
            return this.attributes_;
        }

        private MapFieldLite<String, String> internalGetMutableAttributes() {
            if (!this.attributes_.k()) {
                this.attributes_ = this.attributes_.n();
            }
            return this.attributes_;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateParticipantMetadata parseDelimitedFrom(InputStream inputStream) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateParticipantMetadata parseFrom(ByteBuffer byteBuffer) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateParticipantMetadata> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setRequestId(int i) {
            this.requestId_ = i;
        }

        public boolean containsAttributes(String str) {
            str.getClass();
            return internalGetAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateParticipantMetadata();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0001\u0000\u0000\u0001Ȉ\u0002Ȉ\u00032\u0004\u000b", new Object[]{"metadata_", "name_", "attributes_", AttributesDefaultEntryHolder.a, "requestId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateParticipantMetadata> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateParticipantMetadata.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public Map<String, String> getAttributes() {
            return getAttributesMap();
        }

        public int getAttributesCount() {
            return internalGetAttributes().size();
        }

        public Map<String, String> getAttributesMap() {
            return Collections.unmodifiableMap(internalGetAttributes());
        }

        public String getAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            return mapFieldLiteInternalGetAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetAttributes.get(str) : str2;
        }

        public String getAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            if (mapFieldLiteInternalGetAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public int getRequestId() {
            return this.requestId_;
        }

        public static Builder newBuilder(UpdateParticipantMetadata updateParticipantMetadata) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateParticipantMetadata);
        }

        public static UpdateParticipantMetadata parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateParticipantMetadata parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateParticipantMetadata parseFrom(ByteString byteString) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateParticipantMetadata parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateParticipantMetadata parseFrom(byte[] bArr) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateParticipantMetadata parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateParticipantMetadata parseFrom(InputStream inputStream) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateParticipantMetadata parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateParticipantMetadata parseFrom(CodedInputStream codedInputStream) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateParticipantMetadata parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantMetadata) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateParticipantMetadataOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateSubscription extends GeneratedMessageLite<UpdateSubscription, Builder> implements UpdateSubscriptionOrBuilder {
        private static final UpdateSubscription DEFAULT_INSTANCE;
        private static volatile Parser<UpdateSubscription> PARSER = null;
        public static final int PARTICIPANT_TRACKS_FIELD_NUMBER = 3;
        public static final int SUBSCRIBE_FIELD_NUMBER = 2;
        public static final int TRACK_SIDS_FIELD_NUMBER = 1;
        private boolean subscribe_;
        private Internal.ProtobufList<String> trackSids_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<LivekitModels.ParticipantTracks> participantTracks_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateSubscription, Builder> implements UpdateSubscriptionOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(Iterable iterable) {
                q();
                ((UpdateSubscription) ((GeneratedMessageLite.Builder) this).b).addAllParticipantTracks(iterable);
                return this;
            }

            public Builder B(Iterable iterable) {
                q();
                ((UpdateSubscription) ((GeneratedMessageLite.Builder) this).b).addAllTrackSids(iterable);
                return this;
            }

            public Builder C(boolean z) {
                q();
                ((UpdateSubscription) ((GeneratedMessageLite.Builder) this).b).setSubscribe(z);
                return this;
            }

            private Builder() {
                super(UpdateSubscription.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateSubscription updateSubscription = new UpdateSubscription();
            DEFAULT_INSTANCE = updateSubscription;
            GeneratedMessageLite.registerDefaultInstance(UpdateSubscription.class, updateSubscription);
        }

        private UpdateSubscription() {
        }

        private void addAllParticipantTracks(Iterable<? extends LivekitModels.ParticipantTracks> iterable) {
            ensureParticipantTracksIsMutable();
            AbstractMessageLite.addAll(iterable, this.participantTracks_);
        }

        private void addAllTrackSids(Iterable<String> iterable) {
            ensureTrackSidsIsMutable();
            AbstractMessageLite.addAll(iterable, this.trackSids_);
        }

        private void addParticipantTracks(LivekitModels.ParticipantTracks participantTracks) {
            participantTracks.getClass();
            ensureParticipantTracksIsMutable();
            this.participantTracks_.add(participantTracks);
        }

        private void addTrackSids(String str) {
            str.getClass();
            ensureTrackSidsIsMutable();
            this.trackSids_.add(str);
        }

        private void addTrackSidsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureTrackSidsIsMutable();
            this.trackSids_.add(byteString.L());
        }

        private void clearParticipantTracks() {
            this.participantTracks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSubscribe() {
            this.subscribe_ = false;
        }

        private void clearTrackSids() {
            this.trackSids_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureParticipantTracksIsMutable() {
            Internal.ProtobufList<LivekitModels.ParticipantTracks> protobufList = this.participantTracks_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.participantTracks_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureTrackSidsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.trackSids_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trackSids_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static UpdateSubscription getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateSubscription parseDelimitedFrom(InputStream inputStream) {
            return (UpdateSubscription) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSubscription parseFrom(ByteBuffer byteBuffer) {
            return (UpdateSubscription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateSubscription> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeParticipantTracks(int i) {
            ensureParticipantTracksIsMutable();
            this.participantTracks_.remove(i);
        }

        private void setParticipantTracks(int i, LivekitModels.ParticipantTracks participantTracks) {
            participantTracks.getClass();
            ensureParticipantTracksIsMutable();
            this.participantTracks_.set(i, participantTracks);
        }

        private void setSubscribe(boolean z) {
            this.subscribe_ = z;
        }

        private void setTrackSids(int i, String str) {
            str.getClass();
            ensureTrackSidsIsMutable();
            this.trackSids_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateSubscription();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0002\u0000\u0001Ț\u0002\u0007\u0003\u001b", new Object[]{ap.a(85041090), ap.a(572390499), ap.a(469515992), LivekitModels.ParticipantTracks.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateSubscription> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateSubscription.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.ParticipantTracks getParticipantTracks(int i) {
            return (LivekitModels.ParticipantTracks) this.participantTracks_.get(i);
        }

        public int getParticipantTracksCount() {
            return this.participantTracks_.size();
        }

        public List<LivekitModels.ParticipantTracks> getParticipantTracksList() {
            return this.participantTracks_;
        }

        public LivekitModels.ParticipantTracksOrBuilder getParticipantTracksOrBuilder(int i) {
            return (LivekitModels.ParticipantTracksOrBuilder) this.participantTracks_.get(i);
        }

        public List<? extends LivekitModels.ParticipantTracksOrBuilder> getParticipantTracksOrBuilderList() {
            return this.participantTracks_;
        }

        public boolean getSubscribe() {
            return this.subscribe_;
        }

        public String getTrackSids(int i) {
            return (String) this.trackSids_.get(i);
        }

        public ByteString getTrackSidsBytes(int i) {
            return ByteString.n((String) this.trackSids_.get(i));
        }

        public int getTrackSidsCount() {
            return this.trackSids_.size();
        }

        public List<String> getTrackSidsList() {
            return this.trackSids_;
        }

        public static Builder newBuilder(UpdateSubscription updateSubscription) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateSubscription);
        }

        public static UpdateSubscription parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscription) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSubscription parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateSubscription parseFrom(ByteString byteString) {
            return (UpdateSubscription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addParticipantTracks(int i, LivekitModels.ParticipantTracks participantTracks) {
            participantTracks.getClass();
            ensureParticipantTracksIsMutable();
            this.participantTracks_.add(i, participantTracks);
        }

        public static UpdateSubscription parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateSubscription parseFrom(byte[] bArr) {
            return (UpdateSubscription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateSubscription parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateSubscription parseFrom(InputStream inputStream) {
            return (UpdateSubscription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSubscription parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSubscription parseFrom(CodedInputStream codedInputStream) {
            return (UpdateSubscription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateSubscription parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateSubscriptionOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateTrackSettings extends GeneratedMessageLite<UpdateTrackSettings, Builder> implements UpdateTrackSettingsOrBuilder {
        private static final UpdateTrackSettings DEFAULT_INSTANCE;
        public static final int DISABLED_FIELD_NUMBER = 3;
        public static final int FPS_FIELD_NUMBER = 7;
        public static final int HEIGHT_FIELD_NUMBER = 6;
        private static volatile Parser<UpdateTrackSettings> PARSER = null;
        public static final int PRIORITY_FIELD_NUMBER = 8;
        public static final int QUALITY_FIELD_NUMBER = 4;
        public static final int TRACK_SIDS_FIELD_NUMBER = 1;
        public static final int WIDTH_FIELD_NUMBER = 5;
        private boolean disabled_;
        private int fps_;
        private int height_;
        private int priority_;
        private int quality_;
        private Internal.ProtobufList<String> trackSids_ = GeneratedMessageLite.emptyProtobufList();
        private int width_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateTrackSettings, Builder> implements UpdateTrackSettingsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(String str) {
                q();
                ((UpdateTrackSettings) ((GeneratedMessageLite.Builder) this).b).addTrackSids(str);
                return this;
            }

            public Builder B(boolean z) {
                q();
                ((UpdateTrackSettings) ((GeneratedMessageLite.Builder) this).b).setDisabled(z);
                return this;
            }

            public Builder C(int i) {
                q();
                ((UpdateTrackSettings) ((GeneratedMessageLite.Builder) this).b).setFps(i);
                return this;
            }

            public Builder D(int i) {
                q();
                ((UpdateTrackSettings) ((GeneratedMessageLite.Builder) this).b).setHeight(i);
                return this;
            }

            public Builder E(LivekitModels.VideoQuality videoQuality) {
                q();
                ((UpdateTrackSettings) ((GeneratedMessageLite.Builder) this).b).setQuality(videoQuality);
                return this;
            }

            public Builder F(int i) {
                q();
                ((UpdateTrackSettings) ((GeneratedMessageLite.Builder) this).b).setWidth(i);
                return this;
            }

            private Builder() {
                super(UpdateTrackSettings.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateTrackSettings updateTrackSettings = new UpdateTrackSettings();
            DEFAULT_INSTANCE = updateTrackSettings;
            GeneratedMessageLite.registerDefaultInstance(UpdateTrackSettings.class, updateTrackSettings);
        }

        private UpdateTrackSettings() {
        }

        private void addAllTrackSids(Iterable<String> iterable) {
            ensureTrackSidsIsMutable();
            AbstractMessageLite.addAll(iterable, this.trackSids_);
        }

        private void addTrackSids(String str) {
            str.getClass();
            ensureTrackSidsIsMutable();
            this.trackSids_.add(str);
        }

        private void addTrackSidsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureTrackSidsIsMutable();
            this.trackSids_.add(byteString.L());
        }

        private void clearDisabled() {
            this.disabled_ = false;
        }

        private void clearFps() {
            this.fps_ = 0;
        }

        private void clearHeight() {
            this.height_ = 0;
        }

        private void clearPriority() {
            this.priority_ = 0;
        }

        private void clearQuality() {
            this.quality_ = 0;
        }

        private void clearTrackSids() {
            this.trackSids_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearWidth() {
            this.width_ = 0;
        }

        private void ensureTrackSidsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.trackSids_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trackSids_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static UpdateTrackSettings getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateTrackSettings parseDelimitedFrom(InputStream inputStream) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateTrackSettings parseFrom(ByteBuffer byteBuffer) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateTrackSettings> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDisabled(boolean z) {
            this.disabled_ = z;
        }

        private void setFps(int i) {
            this.fps_ = i;
        }

        private void setHeight(int i) {
            this.height_ = i;
        }

        private void setPriority(int i) {
            this.priority_ = i;
        }

        private void setQuality(LivekitModels.VideoQuality videoQuality) {
            this.quality_ = videoQuality.getNumber();
        }

        private void setQualityValue(int i) {
            this.quality_ = i;
        }

        private void setTrackSids(int i, String str) {
            str.getClass();
            ensureTrackSidsIsMutable();
            this.trackSids_.set(i, str);
        }

        private void setWidth(int i) {
            this.width_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateTrackSettings();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0000\u0000\u0001\b\u0007\u0000\u0001\u0000\u0001Ț\u0003\u0007\u0004\f\u0005\u000b\u0006\u000b\u0007\u000b\b\u000b", new Object[]{ap.a(1972029778), ap.a(1506642989), ap.a(1919117501), ap.a(684235992), ap.a(452605073), ap.a(754305805), ap.a(524331071)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateTrackSettings> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateTrackSettings.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getDisabled() {
            return this.disabled_;
        }

        public int getFps() {
            return this.fps_;
        }

        public int getHeight() {
            return this.height_;
        }

        public int getPriority() {
            return this.priority_;
        }

        public LivekitModels.VideoQuality getQuality() {
            LivekitModels.VideoQuality videoQualityB = LivekitModels.VideoQuality.b(this.quality_);
            return videoQualityB == null ? LivekitModels.VideoQuality.f : videoQualityB;
        }

        public int getQualityValue() {
            return this.quality_;
        }

        public String getTrackSids(int i) {
            return (String) this.trackSids_.get(i);
        }

        public ByteString getTrackSidsBytes(int i) {
            return ByteString.n((String) this.trackSids_.get(i));
        }

        public int getTrackSidsCount() {
            return this.trackSids_.size();
        }

        public List<String> getTrackSidsList() {
            return this.trackSids_;
        }

        public int getWidth() {
            return this.width_;
        }

        public static Builder newBuilder(UpdateTrackSettings updateTrackSettings) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateTrackSettings);
        }

        public static UpdateTrackSettings parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateTrackSettings parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateTrackSettings parseFrom(ByteString byteString) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateTrackSettings parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateTrackSettings parseFrom(byte[] bArr) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateTrackSettings parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateTrackSettings parseFrom(InputStream inputStream) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateTrackSettings parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateTrackSettings parseFrom(CodedInputStream codedInputStream) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateTrackSettings parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateTrackSettings) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateTrackSettingsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public static final class UpdateVideoLayers extends GeneratedMessageLite<UpdateVideoLayers, Builder> implements UpdateVideoLayersOrBuilder {
        private static final UpdateVideoLayers DEFAULT_INSTANCE;
        public static final int LAYERS_FIELD_NUMBER = 2;
        private static volatile Parser<UpdateVideoLayers> PARSER = null;
        public static final int TRACK_SID_FIELD_NUMBER = 1;
        private String trackSid_ = ap.a(588727025);
        private Internal.ProtobufList<LivekitModels.VideoLayer> layers_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateVideoLayers, Builder> implements UpdateVideoLayersOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateVideoLayers.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateVideoLayers updateVideoLayers = new UpdateVideoLayers();
            DEFAULT_INSTANCE = updateVideoLayers;
            GeneratedMessageLite.registerDefaultInstance(UpdateVideoLayers.class, updateVideoLayers);
        }

        private UpdateVideoLayers() {
        }

        private void addAllLayers(Iterable<? extends LivekitModels.VideoLayer> iterable) {
            ensureLayersIsMutable();
            AbstractMessageLite.addAll(iterable, this.layers_);
        }

        private void addLayers(LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(videoLayer);
        }

        private void clearLayers() {
            this.layers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearTrackSid() {
            this.trackSid_ = getDefaultInstance().getTrackSid();
        }

        private void ensureLayersIsMutable() {
            Internal.ProtobufList<LivekitModels.VideoLayer> protobufList = this.layers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.layers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static UpdateVideoLayers getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateVideoLayers parseDelimitedFrom(InputStream inputStream) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateVideoLayers parseFrom(ByteBuffer byteBuffer) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateVideoLayers> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeLayers(int i) {
            ensureLayersIsMutable();
            this.layers_.remove(i);
        }

        private void setLayers(int i, LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.set(i, videoLayer);
        }

        private void setTrackSid(String str) {
            str.getClass();
            this.trackSid_ = str;
        }

        private void setTrackSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackSid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateVideoLayers();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001Ȉ\u0002\u001b", new Object[]{"trackSid_", "layers_", LivekitModels.VideoLayer.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateVideoLayers> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateVideoLayers.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.VideoLayer getLayers(int i) {
            return (LivekitModels.VideoLayer) this.layers_.get(i);
        }

        public int getLayersCount() {
            return this.layers_.size();
        }

        public List<LivekitModels.VideoLayer> getLayersList() {
            return this.layers_;
        }

        public LivekitModels.VideoLayerOrBuilder getLayersOrBuilder(int i) {
            return (LivekitModels.VideoLayerOrBuilder) this.layers_.get(i);
        }

        public List<? extends LivekitModels.VideoLayerOrBuilder> getLayersOrBuilderList() {
            return this.layers_;
        }

        public String getTrackSid() {
            return this.trackSid_;
        }

        public ByteString getTrackSidBytes() {
            return ByteString.n(this.trackSid_);
        }

        public static Builder newBuilder(UpdateVideoLayers updateVideoLayers) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateVideoLayers);
        }

        public static UpdateVideoLayers parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateVideoLayers parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateVideoLayers parseFrom(ByteString byteString) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addLayers(int i, LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(i, videoLayer);
        }

        public static UpdateVideoLayers parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateVideoLayers parseFrom(byte[] bArr) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateVideoLayers parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateVideoLayers parseFrom(InputStream inputStream) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateVideoLayers parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateVideoLayers parseFrom(CodedInputStream codedInputStream) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateVideoLayers parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateVideoLayers) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public interface UpdateVideoLayersOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class WrappedJoinRequest extends GeneratedMessageLite<WrappedJoinRequest, Builder> implements WrappedJoinRequestOrBuilder {
        public static final int COMPRESSION_FIELD_NUMBER = 1;
        private static final WrappedJoinRequest DEFAULT_INSTANCE;
        public static final int JOIN_REQUEST_FIELD_NUMBER = 2;
        private static volatile Parser<WrappedJoinRequest> PARSER;
        private int compression_;
        private ByteString joinRequest_ = ByteString.b;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<WrappedJoinRequest, Builder> implements WrappedJoinRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(WrappedJoinRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum Compression implements Internal.EnumLite {
            b(0),
            c(1),
            d(-1);

            private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<Compression>() { // from class: livekit.LivekitRtc.WrappedJoinRequest.Compression.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public Compression findValueByNumber(int i) {
                    return Compression.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class CompressionVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new CompressionVerifier();

                private CompressionVerifier() {
                }

                public boolean isInRange(int i) {
                    return Compression.b(i) != null;
                }
            }

            Compression(int i) {
                this.a = i;
            }

            public static Compression b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i != 1) {
                    return null;
                }
                return c;
            }

            public final int getNumber() {
                if (this != d) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        static {
            WrappedJoinRequest wrappedJoinRequest = new WrappedJoinRequest();
            DEFAULT_INSTANCE = wrappedJoinRequest;
            GeneratedMessageLite.registerDefaultInstance(WrappedJoinRequest.class, wrappedJoinRequest);
        }

        private WrappedJoinRequest() {
        }

        private void clearCompression() {
            this.compression_ = 0;
        }

        private void clearJoinRequest() {
            this.joinRequest_ = getDefaultInstance().getJoinRequest();
        }

        public static WrappedJoinRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static WrappedJoinRequest parseDelimitedFrom(InputStream inputStream) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WrappedJoinRequest parseFrom(ByteBuffer byteBuffer) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<WrappedJoinRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCompression(Compression compression) {
            this.compression_ = compression.getNumber();
        }

        private void setCompressionValue(int i) {
            this.compression_ = i;
        }

        private void setJoinRequest(ByteString byteString) {
            byteString.getClass();
            this.joinRequest_ = byteString;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new WrappedJoinRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\f\u0002\n", new Object[]{ap.a(1242402230), ap.a(334655192)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<WrappedJoinRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (WrappedJoinRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Compression getCompression() {
            Compression compressionB = Compression.b(this.compression_);
            return compressionB == null ? Compression.d : compressionB;
        }

        public int getCompressionValue() {
            return this.compression_;
        }

        public ByteString getJoinRequest() {
            return this.joinRequest_;
        }

        public static Builder newBuilder(WrappedJoinRequest wrappedJoinRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(wrappedJoinRequest);
        }

        public static WrappedJoinRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WrappedJoinRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static WrappedJoinRequest parseFrom(ByteString byteString) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static WrappedJoinRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static WrappedJoinRequest parseFrom(byte[] bArr) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static WrappedJoinRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static WrappedJoinRequest parseFrom(InputStream inputStream) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WrappedJoinRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WrappedJoinRequest parseFrom(CodedInputStream codedInputStream) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static WrappedJoinRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WrappedJoinRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface WrappedJoinRequestOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitRtc() {
    }
}