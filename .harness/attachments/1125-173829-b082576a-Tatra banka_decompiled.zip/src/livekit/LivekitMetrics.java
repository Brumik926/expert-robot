package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import com.google.protobuf.Timestamp;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitMetrics {

    /* JADX INFO: renamed from: livekit.LivekitMetrics$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class EventMetric extends GeneratedMessageLite<EventMetric, Builder> implements EventMetricOrBuilder {
        private static final EventMetric DEFAULT_INSTANCE;
        public static final int END_TIMESTAMP_MS_FIELD_NUMBER = 5;
        public static final int LABEL_FIELD_NUMBER = 1;
        public static final int METADATA_FIELD_NUMBER = 8;
        public static final int NORMALIZED_END_TIMESTAMP_FIELD_NUMBER = 7;
        public static final int NORMALIZED_START_TIMESTAMP_FIELD_NUMBER = 6;
        private static volatile Parser<EventMetric> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 2;
        public static final int RID_FIELD_NUMBER = 9;
        public static final int START_TIMESTAMP_MS_FIELD_NUMBER = 4;
        public static final int TRACK_SID_FIELD_NUMBER = 3;
        private int bitField0_;
        private long endTimestampMs_;
        private int label_;
        private String metadata_ = ap.a(1037300423);
        private Timestamp normalizedEndTimestamp_;
        private Timestamp normalizedStartTimestamp_;
        private int participantIdentity_;
        private int rid_;
        private long startTimestampMs_;
        private int trackSid_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<EventMetric, Builder> implements EventMetricOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(EventMetric.DEFAULT_INSTANCE);
            }
        }

        static {
            EventMetric eventMetric = new EventMetric();
            DEFAULT_INSTANCE = eventMetric;
            GeneratedMessageLite.registerDefaultInstance(EventMetric.class, eventMetric);
        }

        private EventMetric() {
        }

        private void clearEndTimestampMs() {
            this.bitField0_ &= -2;
            this.endTimestampMs_ = 0L;
        }

        private void clearLabel() {
            this.label_ = 0;
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearNormalizedEndTimestamp() {
            this.normalizedEndTimestamp_ = null;
            this.bitField0_ &= -3;
        }

        private void clearNormalizedStartTimestamp() {
            this.normalizedStartTimestamp_ = null;
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = 0;
        }

        private void clearRid() {
            this.rid_ = 0;
        }

        private void clearStartTimestampMs() {
            this.startTimestampMs_ = 0L;
        }

        private void clearTrackSid() {
            this.trackSid_ = 0;
        }

        public static EventMetric getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeNormalizedEndTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.normalizedEndTimestamp_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.normalizedEndTimestamp_ = timestamp;
            } else {
                this.normalizedEndTimestamp_ = Timestamp.newBuilder(this.normalizedEndTimestamp_).v(timestamp).o();
            }
            this.bitField0_ |= 2;
        }

        private void mergeNormalizedStartTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.normalizedStartTimestamp_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.normalizedStartTimestamp_ = timestamp;
            } else {
                this.normalizedStartTimestamp_ = Timestamp.newBuilder(this.normalizedStartTimestamp_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static EventMetric parseDelimitedFrom(InputStream inputStream) {
            return (EventMetric) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EventMetric parseFrom(ByteBuffer byteBuffer) {
            return (EventMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<EventMetric> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setEndTimestampMs(long j) {
            this.bitField0_ |= 1;
            this.endTimestampMs_ = j;
        }

        private void setLabel(int i) {
            this.label_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setNormalizedEndTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            this.normalizedEndTimestamp_ = timestamp;
            this.bitField0_ |= 2;
        }

        private void setNormalizedStartTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            this.normalizedStartTimestamp_ = timestamp;
        }

        private void setParticipantIdentity(int i) {
            this.participantIdentity_ = i;
        }

        private void setRid(int i) {
            this.rid_ = i;
        }

        private void setStartTimestampMs(long j) {
            this.startTimestampMs_ = j;
        }

        private void setTrackSid(int i) {
            this.trackSid_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new EventMetric();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\t\u0000\u0001\u0001\t\t\u0000\u0000\u0000\u0001\u000b\u0002\u000b\u0003\u000b\u0004\u0002\u0005ဂ\u0000\u0006\t\u0007ဉ\u0001\bȈ\t\u000b", new Object[]{"bitField0_", "label_", "participantIdentity_", "trackSid_", "startTimestampMs_", "endTimestampMs_", "normalizedStartTimestamp_", "normalizedEndTimestamp_", "metadata_", "rid_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<EventMetric> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (EventMetric.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getEndTimestampMs() {
            return this.endTimestampMs_;
        }

        public int getLabel() {
            return this.label_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public Timestamp getNormalizedEndTimestamp() {
            Timestamp timestamp = this.normalizedEndTimestamp_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public Timestamp getNormalizedStartTimestamp() {
            Timestamp timestamp = this.normalizedStartTimestamp_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public int getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public int getRid() {
            return this.rid_;
        }

        public long getStartTimestampMs() {
            return this.startTimestampMs_;
        }

        public int getTrackSid() {
            return this.trackSid_;
        }

        public boolean hasEndTimestampMs() {
            return (this.bitField0_ & 1) != 0;
        }

        public boolean hasNormalizedEndTimestamp() {
            return (this.bitField0_ & 2) != 0;
        }

        public boolean hasNormalizedStartTimestamp() {
            return this.normalizedStartTimestamp_ != null;
        }

        public static Builder newBuilder(EventMetric eventMetric) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(eventMetric);
        }

        public static EventMetric parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EventMetric) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EventMetric parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (EventMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static EventMetric parseFrom(ByteString byteString) {
            return (EventMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static EventMetric parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (EventMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static EventMetric parseFrom(byte[] bArr) {
            return (EventMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static EventMetric parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (EventMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static EventMetric parseFrom(InputStream inputStream) {
            return (EventMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EventMetric parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EventMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EventMetric parseFrom(CodedInputStream codedInputStream) {
            return (EventMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static EventMetric parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EventMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface EventMetricOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum MetricLabel implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(4),
        g(5),
        h(6),
        i(7),
        j(8),
        k(9),
        l(10),
        m(11),
        n(12),
        o(13),
        p(14),
        q(15),
        r(16),
        s(17),
        t(18),
        u(19),
        v(4096),
        w(-1);

        private static final Internal.EnumLiteMap x = new Internal.EnumLiteMap<MetricLabel>() { // from class: livekit.LivekitMetrics.MetricLabel.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public MetricLabel findValueByNumber(int i2) {
                return MetricLabel.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class MetricLabelVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new MetricLabelVerifier();

            private MetricLabelVerifier() {
            }

            public boolean isInRange(int i) {
                return MetricLabel.b(i) != null;
            }
        }

        MetricLabel(int i2) {
            this.a = i2;
        }

        public static MetricLabel b(int i2) {
            if (i2 == 4096) {
                return v;
            }
            switch (i2) {
                case 0:
                    return b;
                case 1:
                    return c;
                case 2:
                    return d;
                case 3:
                    return e;
                case 4:
                    return f;
                case 5:
                    return g;
                case 6:
                    return h;
                case 7:
                    return i;
                case 8:
                    return j;
                case 9:
                    return k;
                case 10:
                    return l;
                case 11:
                    return m;
                case 12:
                    return n;
                case 13:
                    return o;
                case 14:
                    return p;
                case 15:
                    return q;
                case 16:
                    return r;
                case 17:
                    return s;
                case 18:
                    return t;
                case 19:
                    return u;
                default:
                    return null;
            }
        }

        public final int getNumber() {
            if (this != w) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class MetricSample extends GeneratedMessageLite<MetricSample, Builder> implements MetricSampleOrBuilder {
        private static final MetricSample DEFAULT_INSTANCE;
        public static final int NORMALIZED_TIMESTAMP_FIELD_NUMBER = 2;
        private static volatile Parser<MetricSample> PARSER = null;
        public static final int TIMESTAMP_MS_FIELD_NUMBER = 1;
        public static final int VALUE_FIELD_NUMBER = 3;
        private Timestamp normalizedTimestamp_;
        private long timestampMs_;
        private float value_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<MetricSample, Builder> implements MetricSampleOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(long j) {
                q();
                ((MetricSample) ((GeneratedMessageLite.Builder) this).b).setTimestampMs(j);
                return this;
            }

            public Builder B(float f) {
                q();
                ((MetricSample) ((GeneratedMessageLite.Builder) this).b).setValue(f);
                return this;
            }

            private Builder() {
                super(MetricSample.DEFAULT_INSTANCE);
            }
        }

        static {
            MetricSample metricSample = new MetricSample();
            DEFAULT_INSTANCE = metricSample;
            GeneratedMessageLite.registerDefaultInstance(MetricSample.class, metricSample);
        }

        private MetricSample() {
        }

        private void clearNormalizedTimestamp() {
            this.normalizedTimestamp_ = null;
        }

        private void clearTimestampMs() {
            this.timestampMs_ = 0L;
        }

        private void clearValue() {
            this.value_ = 0.0f;
        }

        public static MetricSample getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeNormalizedTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.normalizedTimestamp_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.normalizedTimestamp_ = timestamp;
            } else {
                this.normalizedTimestamp_ = Timestamp.newBuilder(this.normalizedTimestamp_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static MetricSample parseDelimitedFrom(InputStream inputStream) {
            return (MetricSample) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MetricSample parseFrom(ByteBuffer byteBuffer) {
            return (MetricSample) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<MetricSample> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setNormalizedTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            this.normalizedTimestamp_ = timestamp;
        }

        private void setTimestampMs(long j) {
            this.timestampMs_ = j;
        }

        private void setValue(float f) {
            this.value_ = f;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new MetricSample();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u0002\u0002\t\u0003\u0001", new Object[]{ap.a(1168177379), ap.a(1064361780), ap.a(1880455371)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<MetricSample> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (MetricSample.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Timestamp getNormalizedTimestamp() {
            Timestamp timestamp = this.normalizedTimestamp_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public long getTimestampMs() {
            return this.timestampMs_;
        }

        public float getValue() {
            return this.value_;
        }

        public boolean hasNormalizedTimestamp() {
            return this.normalizedTimestamp_ != null;
        }

        public static Builder newBuilder(MetricSample metricSample) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(metricSample);
        }

        public static MetricSample parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricSample) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MetricSample parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricSample) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static MetricSample parseFrom(ByteString byteString) {
            return (MetricSample) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static MetricSample parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricSample) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static MetricSample parseFrom(byte[] bArr) {
            return (MetricSample) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static MetricSample parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricSample) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static MetricSample parseFrom(InputStream inputStream) {
            return (MetricSample) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MetricSample parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricSample) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MetricSample parseFrom(CodedInputStream codedInputStream) {
            return (MetricSample) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static MetricSample parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricSample) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface MetricSampleOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class MetricsBatch extends GeneratedMessageLite<MetricsBatch, Builder> implements MetricsBatchOrBuilder {
        private static final MetricsBatch DEFAULT_INSTANCE;
        public static final int EVENTS_FIELD_NUMBER = 5;
        public static final int NORMALIZED_TIMESTAMP_FIELD_NUMBER = 2;
        private static volatile Parser<MetricsBatch> PARSER = null;
        public static final int STR_DATA_FIELD_NUMBER = 3;
        public static final int TIMESTAMP_MS_FIELD_NUMBER = 1;
        public static final int TIME_SERIES_FIELD_NUMBER = 4;
        private Timestamp normalizedTimestamp_;
        private long timestampMs_;
        private Internal.ProtobufList<String> strData_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<TimeSeriesMetric> timeSeries_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<EventMetric> events_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<MetricsBatch, Builder> implements MetricsBatchOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(Iterable iterable) {
                q();
                ((MetricsBatch) ((GeneratedMessageLite.Builder) this).b).addAllStrData(iterable);
                return this;
            }

            public Builder B(Iterable iterable) {
                q();
                ((MetricsBatch) ((GeneratedMessageLite.Builder) this).b).addAllTimeSeries(iterable);
                return this;
            }

            public Builder C(long j) {
                q();
                ((MetricsBatch) ((GeneratedMessageLite.Builder) this).b).setTimestampMs(j);
                return this;
            }

            private Builder() {
                super(MetricsBatch.DEFAULT_INSTANCE);
            }
        }

        static {
            MetricsBatch metricsBatch = new MetricsBatch();
            DEFAULT_INSTANCE = metricsBatch;
            GeneratedMessageLite.registerDefaultInstance(MetricsBatch.class, metricsBatch);
        }

        private MetricsBatch() {
        }

        private void addAllEvents(Iterable<? extends EventMetric> iterable) {
            ensureEventsIsMutable();
            AbstractMessageLite.addAll(iterable, this.events_);
        }

        private void addAllStrData(Iterable<String> iterable) {
            ensureStrDataIsMutable();
            AbstractMessageLite.addAll(iterable, this.strData_);
        }

        private void addAllTimeSeries(Iterable<? extends TimeSeriesMetric> iterable) {
            ensureTimeSeriesIsMutable();
            AbstractMessageLite.addAll(iterable, this.timeSeries_);
        }

        private void addEvents(EventMetric eventMetric) {
            eventMetric.getClass();
            ensureEventsIsMutable();
            this.events_.add(eventMetric);
        }

        private void addStrData(String str) {
            str.getClass();
            ensureStrDataIsMutable();
            this.strData_.add(str);
        }

        private void addStrDataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureStrDataIsMutable();
            this.strData_.add(byteString.L());
        }

        private void addTimeSeries(TimeSeriesMetric timeSeriesMetric) {
            timeSeriesMetric.getClass();
            ensureTimeSeriesIsMutable();
            this.timeSeries_.add(timeSeriesMetric);
        }

        private void clearEvents() {
            this.events_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearNormalizedTimestamp() {
            this.normalizedTimestamp_ = null;
        }

        private void clearStrData() {
            this.strData_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearTimeSeries() {
            this.timeSeries_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearTimestampMs() {
            this.timestampMs_ = 0L;
        }

        private void ensureEventsIsMutable() {
            Internal.ProtobufList<EventMetric> protobufList = this.events_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.events_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureStrDataIsMutable() {
            Internal.ProtobufList<String> protobufList = this.strData_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.strData_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureTimeSeriesIsMutable() {
            Internal.ProtobufList<TimeSeriesMetric> protobufList = this.timeSeries_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.timeSeries_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static MetricsBatch getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeNormalizedTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.normalizedTimestamp_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.normalizedTimestamp_ = timestamp;
            } else {
                this.normalizedTimestamp_ = Timestamp.newBuilder(this.normalizedTimestamp_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static MetricsBatch parseDelimitedFrom(InputStream inputStream) {
            return (MetricsBatch) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MetricsBatch parseFrom(ByteBuffer byteBuffer) {
            return (MetricsBatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<MetricsBatch> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeEvents(int i) {
            ensureEventsIsMutable();
            this.events_.remove(i);
        }

        private void removeTimeSeries(int i) {
            ensureTimeSeriesIsMutable();
            this.timeSeries_.remove(i);
        }

        private void setEvents(int i, EventMetric eventMetric) {
            eventMetric.getClass();
            ensureEventsIsMutable();
            this.events_.set(i, eventMetric);
        }

        private void setNormalizedTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            this.normalizedTimestamp_ = timestamp;
        }

        private void setStrData(int i, String str) {
            str.getClass();
            ensureStrDataIsMutable();
            this.strData_.set(i, str);
        }

        private void setTimeSeries(int i, TimeSeriesMetric timeSeriesMetric) {
            timeSeriesMetric.getClass();
            ensureTimeSeriesIsMutable();
            this.timeSeries_.set(i, timeSeriesMetric);
        }

        private void setTimestampMs(long j) {
            this.timestampMs_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new MetricsBatch();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0003\u0000\u0001\u0002\u0002\t\u0003Ț\u0004\u001b\u0005\u001b", new Object[]{ap.a(1118660398), ap.a(1283640752), ap.a(1339790792), ap.a(272008135), TimeSeriesMetric.class, ap.a(1926060225), EventMetric.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<MetricsBatch> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (MetricsBatch.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public EventMetric getEvents(int i) {
            return (EventMetric) this.events_.get(i);
        }

        public int getEventsCount() {
            return this.events_.size();
        }

        public List<EventMetric> getEventsList() {
            return this.events_;
        }

        public EventMetricOrBuilder getEventsOrBuilder(int i) {
            return (EventMetricOrBuilder) this.events_.get(i);
        }

        public List<? extends EventMetricOrBuilder> getEventsOrBuilderList() {
            return this.events_;
        }

        public Timestamp getNormalizedTimestamp() {
            Timestamp timestamp = this.normalizedTimestamp_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public String getStrData(int i) {
            return (String) this.strData_.get(i);
        }

        public ByteString getStrDataBytes(int i) {
            return ByteString.n((String) this.strData_.get(i));
        }

        public int getStrDataCount() {
            return this.strData_.size();
        }

        public List<String> getStrDataList() {
            return this.strData_;
        }

        public TimeSeriesMetric getTimeSeries(int i) {
            return (TimeSeriesMetric) this.timeSeries_.get(i);
        }

        public int getTimeSeriesCount() {
            return this.timeSeries_.size();
        }

        public List<TimeSeriesMetric> getTimeSeriesList() {
            return this.timeSeries_;
        }

        public TimeSeriesMetricOrBuilder getTimeSeriesOrBuilder(int i) {
            return (TimeSeriesMetricOrBuilder) this.timeSeries_.get(i);
        }

        public List<? extends TimeSeriesMetricOrBuilder> getTimeSeriesOrBuilderList() {
            return this.timeSeries_;
        }

        public long getTimestampMs() {
            return this.timestampMs_;
        }

        public boolean hasNormalizedTimestamp() {
            return this.normalizedTimestamp_ != null;
        }

        public static Builder newBuilder(MetricsBatch metricsBatch) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(metricsBatch);
        }

        public static MetricsBatch parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsBatch) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MetricsBatch parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsBatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static MetricsBatch parseFrom(ByteString byteString) {
            return (MetricsBatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addEvents(int i, EventMetric eventMetric) {
            eventMetric.getClass();
            ensureEventsIsMutable();
            this.events_.add(i, eventMetric);
        }

        private void addTimeSeries(int i, TimeSeriesMetric timeSeriesMetric) {
            timeSeriesMetric.getClass();
            ensureTimeSeriesIsMutable();
            this.timeSeries_.add(i, timeSeriesMetric);
        }

        public static MetricsBatch parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsBatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static MetricsBatch parseFrom(byte[] bArr) {
            return (MetricsBatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static MetricsBatch parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsBatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static MetricsBatch parseFrom(InputStream inputStream) {
            return (MetricsBatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MetricsBatch parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsBatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MetricsBatch parseFrom(CodedInputStream codedInputStream) {
            return (MetricsBatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static MetricsBatch parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsBatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface MetricsBatchOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class MetricsRecordingHeader extends GeneratedMessageLite<MetricsRecordingHeader, Builder> implements MetricsRecordingHeaderOrBuilder {
        private static final MetricsRecordingHeader DEFAULT_INSTANCE;
        public static final int ENABLE_USER_DATA_TRAINING_FIELD_NUMBER = 2;
        private static volatile Parser<MetricsRecordingHeader> PARSER = null;
        public static final int ROOM_ID_FIELD_NUMBER = 1;
        private int bitField0_;
        private boolean enableUserDataTraining_;
        private String roomId_ = ap.a(1902135221);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<MetricsRecordingHeader, Builder> implements MetricsRecordingHeaderOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(MetricsRecordingHeader.DEFAULT_INSTANCE);
            }
        }

        static {
            MetricsRecordingHeader metricsRecordingHeader = new MetricsRecordingHeader();
            DEFAULT_INSTANCE = metricsRecordingHeader;
            GeneratedMessageLite.registerDefaultInstance(MetricsRecordingHeader.class, metricsRecordingHeader);
        }

        private MetricsRecordingHeader() {
        }

        private void clearEnableUserDataTraining() {
            this.bitField0_ &= -2;
            this.enableUserDataTraining_ = false;
        }

        private void clearRoomId() {
            this.roomId_ = getDefaultInstance().getRoomId();
        }

        public static MetricsRecordingHeader getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static MetricsRecordingHeader parseDelimitedFrom(InputStream inputStream) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MetricsRecordingHeader parseFrom(ByteBuffer byteBuffer) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<MetricsRecordingHeader> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setEnableUserDataTraining(boolean z) {
            this.bitField0_ |= 1;
            this.enableUserDataTraining_ = z;
        }

        private void setRoomId(String str) {
            str.getClass();
            this.roomId_ = str;
        }

        private void setRoomIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new MetricsRecordingHeader();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0001\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002ဇ\u0000", new Object[]{"bitField0_", "roomId_", "enableUserDataTraining_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<MetricsRecordingHeader> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (MetricsRecordingHeader.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getEnableUserDataTraining() {
            return this.enableUserDataTraining_;
        }

        public String getRoomId() {
            return this.roomId_;
        }

        public ByteString getRoomIdBytes() {
            return ByteString.n(this.roomId_);
        }

        public boolean hasEnableUserDataTraining() {
            return (this.bitField0_ & 1) != 0;
        }

        public static Builder newBuilder(MetricsRecordingHeader metricsRecordingHeader) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(metricsRecordingHeader);
        }

        public static MetricsRecordingHeader parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MetricsRecordingHeader parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static MetricsRecordingHeader parseFrom(ByteString byteString) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static MetricsRecordingHeader parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static MetricsRecordingHeader parseFrom(byte[] bArr) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static MetricsRecordingHeader parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static MetricsRecordingHeader parseFrom(InputStream inputStream) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MetricsRecordingHeader parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MetricsRecordingHeader parseFrom(CodedInputStream codedInputStream) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static MetricsRecordingHeader parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MetricsRecordingHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface MetricsRecordingHeaderOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TimeSeriesMetric extends GeneratedMessageLite<TimeSeriesMetric, Builder> implements TimeSeriesMetricOrBuilder {
        private static final TimeSeriesMetric DEFAULT_INSTANCE;
        public static final int LABEL_FIELD_NUMBER = 1;
        private static volatile Parser<TimeSeriesMetric> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 2;
        public static final int RID_FIELD_NUMBER = 5;
        public static final int SAMPLES_FIELD_NUMBER = 4;
        public static final int TRACK_SID_FIELD_NUMBER = 3;
        private int label_;
        private int participantIdentity_;
        private int rid_;
        private Internal.ProtobufList<MetricSample> samples_ = GeneratedMessageLite.emptyProtobufList();
        private int trackSid_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TimeSeriesMetric, Builder> implements TimeSeriesMetricOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(Iterable iterable) {
                q();
                ((TimeSeriesMetric) ((GeneratedMessageLite.Builder) this).b).addAllSamples(iterable);
                return this;
            }

            public Builder B(int i) {
                q();
                ((TimeSeriesMetric) ((GeneratedMessageLite.Builder) this).b).setLabel(i);
                return this;
            }

            public Builder C(int i) {
                q();
                ((TimeSeriesMetric) ((GeneratedMessageLite.Builder) this).b).setParticipantIdentity(i);
                return this;
            }

            public Builder D(int i) {
                q();
                ((TimeSeriesMetric) ((GeneratedMessageLite.Builder) this).b).setRid(i);
                return this;
            }

            public Builder E(int i) {
                q();
                ((TimeSeriesMetric) ((GeneratedMessageLite.Builder) this).b).setTrackSid(i);
                return this;
            }

            private Builder() {
                super(TimeSeriesMetric.DEFAULT_INSTANCE);
            }
        }

        static {
            TimeSeriesMetric timeSeriesMetric = new TimeSeriesMetric();
            DEFAULT_INSTANCE = timeSeriesMetric;
            GeneratedMessageLite.registerDefaultInstance(TimeSeriesMetric.class, timeSeriesMetric);
        }

        private TimeSeriesMetric() {
        }

        private void addAllSamples(Iterable<? extends MetricSample> iterable) {
            ensureSamplesIsMutable();
            AbstractMessageLite.addAll(iterable, this.samples_);
        }

        private void addSamples(MetricSample metricSample) {
            metricSample.getClass();
            ensureSamplesIsMutable();
            this.samples_.add(metricSample);
        }

        private void clearLabel() {
            this.label_ = 0;
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = 0;
        }

        private void clearRid() {
            this.rid_ = 0;
        }

        private void clearSamples() {
            this.samples_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearTrackSid() {
            this.trackSid_ = 0;
        }

        private void ensureSamplesIsMutable() {
            Internal.ProtobufList<MetricSample> protobufList = this.samples_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.samples_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static TimeSeriesMetric getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TimeSeriesMetric parseDelimitedFrom(InputStream inputStream) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TimeSeriesMetric parseFrom(ByteBuffer byteBuffer) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TimeSeriesMetric> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSamples(int i) {
            ensureSamplesIsMutable();
            this.samples_.remove(i);
        }

        private void setLabel(int i) {
            this.label_ = i;
        }

        private void setParticipantIdentity(int i) {
            this.participantIdentity_ = i;
        }

        private void setRid(int i) {
            this.rid_ = i;
        }

        private void setSamples(int i, MetricSample metricSample) {
            metricSample.getClass();
            ensureSamplesIsMutable();
            this.samples_.set(i, metricSample);
        }

        private void setTrackSid(int i) {
            this.trackSid_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TimeSeriesMetric();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0001\u0000\u0001\u000b\u0002\u000b\u0003\u000b\u0004\u001b\u0005\u000b", new Object[]{ap.a(1235672100), ap.a(1861201801), ap.a(474893191), ap.a(2001810453), MetricSample.class, ap.a(24141636)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TimeSeriesMetric> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TimeSeriesMetric.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getLabel() {
            return this.label_;
        }

        public int getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public int getRid() {
            return this.rid_;
        }

        public MetricSample getSamples(int i) {
            return (MetricSample) this.samples_.get(i);
        }

        public int getSamplesCount() {
            return this.samples_.size();
        }

        public List<MetricSample> getSamplesList() {
            return this.samples_;
        }

        public MetricSampleOrBuilder getSamplesOrBuilder(int i) {
            return (MetricSampleOrBuilder) this.samples_.get(i);
        }

        public List<? extends MetricSampleOrBuilder> getSamplesOrBuilderList() {
            return this.samples_;
        }

        public int getTrackSid() {
            return this.trackSid_;
        }

        public static Builder newBuilder(TimeSeriesMetric timeSeriesMetric) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(timeSeriesMetric);
        }

        public static TimeSeriesMetric parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TimeSeriesMetric parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TimeSeriesMetric parseFrom(ByteString byteString) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSamples(int i, MetricSample metricSample) {
            metricSample.getClass();
            ensureSamplesIsMutable();
            this.samples_.add(i, metricSample);
        }

        public static TimeSeriesMetric parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TimeSeriesMetric parseFrom(byte[] bArr) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TimeSeriesMetric parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TimeSeriesMetric parseFrom(InputStream inputStream) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TimeSeriesMetric parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TimeSeriesMetric parseFrom(CodedInputStream codedInputStream) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TimeSeriesMetric parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeSeriesMetric) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TimeSeriesMetricOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitMetrics() {
    }
}