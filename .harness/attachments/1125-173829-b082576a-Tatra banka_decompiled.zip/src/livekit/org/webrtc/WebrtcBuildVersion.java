package livekit.org.webrtc;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public interface WebrtcBuildVersion {
    public static final String maint_version = "0";
    public static final String webrtc_branch = "M137";
    public static final String webrtc_commit = "11";
    public static final String webrtc_revision = "624fa1dce239af785fc5fa9ca3b21b9250d3f835";
}