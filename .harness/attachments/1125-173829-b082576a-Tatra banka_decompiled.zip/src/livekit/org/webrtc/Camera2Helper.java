package livekit.org.webrtc;

import android.hardware.camera2.CameraManager;
import h.ap;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import livekit.org.webrtc.CameraEnumerationAndroid;
import org.apache.tika.utils.StringUtils;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0000\u0018\u0000 \u00032\u00020\u0001:\u0001\u0003B\u0005¢\u0006\u0002\u0010\u0002¨\u0006\u0004"}, d2 = {"Llivekit/org/webrtc/Camera2Helper;", StringUtils.EMPTY, "()V", "Companion", "livekit-android-sdk_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class Camera2Helper {

    @NotNull
    public static final Companion Companion = new Companion(null);

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\b\u0002¢\u0006\u0002\u0010\u0002J(\u0010\u0003\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\b2\u0006\u0010\t\u001a\u00020\n2\u0006\u0010\u000b\u001a\u00020\nJ \u0010\f\u001a\n\u0012\u0004\u0012\u00020\u000e\u0018\u00010\r2\u0006\u0010\u0005\u001a\u00020\u00062\b\u0010\u0007\u001a\u0004\u0018\u00010\b¨\u0006\u000f"}, d2 = {"Llivekit/org/webrtc/Camera2Helper$Companion;", StringUtils.EMPTY, "()V", "findClosestCaptureFormat", "Llivekit/org/webrtc/Size;", "cameraManager", "Landroid/hardware/camera2/CameraManager;", "cameraId", StringUtils.EMPTY, "width", StringUtils.EMPTY, "height", "getSupportedFormats", StringUtils.EMPTY, "Llivekit/org/webrtc/CameraEnumerationAndroid$CaptureFormat;", "livekit-android-sdk_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nCamera2Helper.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Camera2Helper.kt\nlivekit/org/webrtc/Camera2Helper$Companion\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,50:1\n1549#2:51\n1620#2,3:52\n*S KotlinDebug\n*F\n+ 1 Camera2Helper.kt\nlivekit/org/webrtc/Camera2Helper$Companion\n*L\n44#1:51\n44#1:52,3\n*E\n"})
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        @NotNull
        public final Size findClosestCaptureFormat(@NotNull CameraManager cameraManager, @Nullable String str, int i, int i2) {
            List listEmptyList;
            Intrinsics.checkNotNullParameter(cameraManager, ap.a(419890940));
            List<CameraEnumerationAndroid.CaptureFormat> supportedFormats = getSupportedFormats(cameraManager, str);
            if (supportedFormats != null) {
                List<CameraEnumerationAndroid.CaptureFormat> list = supportedFormats;
                listEmptyList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
                for (CameraEnumerationAndroid.CaptureFormat captureFormat : list) {
                    listEmptyList.add(new Size(captureFormat.width, captureFormat.height));
                }
            } else {
                listEmptyList = CollectionsKt.emptyList();
            }
            Size closestSupportedSize = CameraEnumerationAndroid.getClosestSupportedSize(listEmptyList, i, i2);
            Intrinsics.checkNotNullExpressionValue(closestSupportedSize, ap.a(693691178));
            return closestSupportedSize;
        }

        @Nullable
        public final List<CameraEnumerationAndroid.CaptureFormat> getSupportedFormats(@NotNull CameraManager cameraManager, @Nullable String str) {
            Intrinsics.checkNotNullParameter(cameraManager, "cameraManager");
            return Camera2Enumerator.getSupportedFormats(cameraManager, str);
        }

        private Companion() {
        }
    }
}