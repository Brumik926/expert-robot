package livekit.org.webrtc;

import h.ap;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class DataPacketCryptor {
    private long nativePtr;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static class EncryptedPacket {
        public final byte[] iv;
        public final int keyIndex;
        public final byte[] payload;

        @CalledByNative("EncryptedPacket")
        public EncryptedPacket(byte[] bArr, byte[] bArr2, int i) {
            this.payload = bArr;
            this.iv = bArr2;
            this.keyIndex = i;
        }
    }

    @CalledByNative
    public DataPacketCryptor(long j) {
        this.nativePtr = j;
    }

    private void checkDataPacketCryptorExists() {
        if (this.nativePtr == 0) {
            throw new IllegalStateException(ap.a(1575283751));
        }
    }

    private static native byte[] nativeDecrypt(long j, String str, int i, byte[] bArr, byte[] bArr2);

    private static native EncryptedPacket nativeEncrypt(long j, String str, int i, byte[] bArr);

    public byte[] decrypt(String str, EncryptedPacket encryptedPacket) {
        checkDataPacketCryptorExists();
        return nativeDecrypt(this.nativePtr, str, encryptedPacket.keyIndex, encryptedPacket.payload, encryptedPacket.iv);
    }

    public void dispose() {
        checkDataPacketCryptorExists();
        JniCommon.nativeReleaseRef(this.nativePtr);
        this.nativePtr = 0L;
    }

    public EncryptedPacket encrypt(String str, int i, byte[] bArr) {
        checkDataPacketCryptorExists();
        return nativeEncrypt(this.nativePtr, str, i, bArr);
    }

    public long getNativeDataPacketCryptor() {
        return this.nativePtr;
    }
}