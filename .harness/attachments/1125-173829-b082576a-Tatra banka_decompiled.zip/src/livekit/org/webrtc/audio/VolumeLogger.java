package livekit.org.webrtc.audio;

import android.media.AudioManager;
import androidx.annotation.Nullable;
import h.ap;
import java.util.Timer;
import java.util.TimerTask;
import livekit.org.webrtc.Logging;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
class VolumeLogger {
    private static final String TAG = "VolumeLogger";
    private static final String THREAD_NAME = "WebRtcVolumeLevelLoggerThread";
    private static final int TIMER_PERIOD_IN_SECONDS = 30;
    private final AudioManager audioManager;

    @Nullable
    private Timer timer;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    private class LogVolumeTask extends TimerTask {
        private final int maxRingVolume;
        private final int maxVoiceCallVolume;

        LogVolumeTask(int i, int i2) {
            this.maxRingVolume = i;
            this.maxVoiceCallVolume = i2;
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            int mode = VolumeLogger.this.audioManager.getMode();
            String strA = ap.a(856569108);
            String strA2 = ap.a(1698058785);
            String strA3 = ap.a(1206001134);
            if (mode == 1) {
                Logging.d(strA3, ap.a(412765596) + VolumeLogger.this.audioManager.getStreamVolume(2) + strA2 + this.maxRingVolume + strA);
                return;
            }
            if (mode == 3) {
                Logging.d(strA3, ap.a(1963793839) + VolumeLogger.this.audioManager.getStreamVolume(0) + strA2 + this.maxVoiceCallVolume + strA);
            }
        }
    }

    public VolumeLogger(AudioManager audioManager) {
        this.audioManager = audioManager;
    }

    public void start() {
        String str = ap.a(75303532) + WebRtcAudioUtils.getThreadInfo();
        String strA = ap.a(825364290);
        Logging.d(strA, str);
        if (this.timer != null) {
            return;
        }
        Logging.d(strA, ap.a(1983597752) + WebRtcAudioUtils.modeToString(this.audioManager.getMode()));
        Timer timer = new Timer(ap.a(594106326));
        this.timer = timer;
        timer.schedule(new LogVolumeTask(this.audioManager.getStreamMaxVolume(2), this.audioManager.getStreamMaxVolume(0)), 0L, 30000L);
    }

    public void stop() {
        Logging.d(TAG, "stop" + WebRtcAudioUtils.getThreadInfo());
        Timer timer = this.timer;
        if (timer != null) {
            timer.cancel();
            this.timer = null;
        }
    }
}