package livekit.org.webrtc.audio;

import android.media.AudioTrack;
import h.ap;
import livekit.org.webrtc.Logging;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
class LowLatencyAudioBufferManager {
    private static final String TAG = "LowLatencyAudioBufferManager";
    private int prevUnderrunCount = 0;
    private int ticksUntilNextDecrease = 10;
    private boolean keepLoweringBufferSize = true;
    private int bufferIncreaseCounter = 0;

    public void maybeAdjustBufferSize(AudioTrack audioTrack) {
        int underrunCount = audioTrack.getUnderrunCount();
        int i = this.prevUnderrunCount;
        String strA = ap.a(1693527176);
        String strA2 = ap.a(240693144);
        if (underrunCount > i) {
            if (this.bufferIncreaseCounter < 5) {
                int bufferSizeInFrames = audioTrack.getBufferSizeInFrames();
                int playbackRate = (audioTrack.getPlaybackRate() / 100) + bufferSizeInFrames;
                Logging.d(strA2, ap.a(1806722133) + bufferSizeInFrames + strA + playbackRate);
                audioTrack.setBufferSizeInFrames(playbackRate);
                this.bufferIncreaseCounter = this.bufferIncreaseCounter + 1;
            }
            this.keepLoweringBufferSize = false;
            this.prevUnderrunCount = underrunCount;
            this.ticksUntilNextDecrease = 10;
            return;
        }
        if (this.keepLoweringBufferSize) {
            int i2 = this.ticksUntilNextDecrease - 1;
            this.ticksUntilNextDecrease = i2;
            if (i2 <= 0) {
                int playbackRate2 = audioTrack.getPlaybackRate() / 100;
                int bufferSizeInFrames2 = audioTrack.getBufferSizeInFrames();
                int iMax = Math.max(playbackRate2, bufferSizeInFrames2 - playbackRate2);
                if (iMax != bufferSizeInFrames2) {
                    Logging.d(strA2, ap.a(1464087602) + bufferSizeInFrames2 + strA + iMax);
                    audioTrack.setBufferSizeInFrames(iMax);
                }
                this.ticksUntilNextDecrease = 10;
            }
        }
    }
}