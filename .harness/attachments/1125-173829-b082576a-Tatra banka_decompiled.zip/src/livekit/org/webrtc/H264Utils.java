package livekit.org.webrtc;

import h.ap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
class H264Utils {
    public static VideoCodecInfo DEFAULT_H264_BASELINE_PROFILE_CODEC = null;
    public static VideoCodecInfo DEFAULT_H264_HIGH_PROFILE_CODEC = null;
    public static final String H264_CONSTRAINED_BASELINE_3_1 = "42e01f";
    public static final String H264_CONSTRAINED_HIGH_3_1 = "640c1f";
    public static final String H264_FMTP_LEVEL_ASYMMETRY_ALLOWED = "level-asymmetry-allowed";
    public static final String H264_FMTP_PACKETIZATION_MODE = "packetization-mode";
    public static final String H264_FMTP_PROFILE_LEVEL_ID = "profile-level-id";
    public static final String H264_LEVEL_3_1 = "1f";
    public static final String H264_PROFILE_CONSTRAINED_BASELINE = "42e0";
    public static final String H264_PROFILE_CONSTRAINED_HIGH = "640c";

    static {
        Map<String, String> defaultH264Params = getDefaultH264Params(false);
        ArrayList arrayList = new ArrayList();
        String strA = ap.a(1754631471);
        DEFAULT_H264_BASELINE_PROFILE_CODEC = new VideoCodecInfo(strA, defaultH264Params, arrayList);
        DEFAULT_H264_HIGH_PROFILE_CODEC = new VideoCodecInfo(strA, getDefaultH264Params(true), new ArrayList());
    }

    H264Utils() {
    }

    public static Map<String, String> getDefaultH264Params(boolean z) {
        HashMap map = new HashMap();
        map.put("level-asymmetry-allowed", "1");
        map.put("packetization-mode", "1");
        map.put("profile-level-id", z ? "640c1f" : "42e01f");
        return map;
    }

    public static boolean isSameH264Profile(Map<String, String> map, Map<String, String> map2) {
        return nativeIsSameH264Profile(map, map2);
    }

    private static native boolean nativeIsSameH264Profile(Map<String, String> map, Map<String, String> map2);
}