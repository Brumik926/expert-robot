package livekit.org.webrtc;

import h.ap;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
enum VideoCodecMimeType {
    VP8(ap.a(665045071)),
    VP9(ap.a(282920307)),
    H264(ap.a(798126632)),
    AV1(ap.a(825296575)),
    H265(ap.a(446306600));

    private final String mimeType;

    VideoCodecMimeType(String str) {
        this.mimeType = str;
    }

    String mimeType() {
        return this.mimeType;
    }
}