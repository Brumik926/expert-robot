package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.Any;
import com.google.protobuf.AnyOrBuilder;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.Duration;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MapEntryLite;
import com.google.protobuf.MapFieldLite;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import com.google.protobuf.WireFormat;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import livekit.LivekitModels;
import livekit.LivekitRoom;
import org.apache.tika.pipes.PipesConfigBase;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitSip {

    /* JADX INFO: renamed from: livekit.LivekitSip$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class CreateSIPDispatchRuleRequest extends GeneratedMessageLite<CreateSIPDispatchRuleRequest, Builder> implements CreateSIPDispatchRuleRequestOrBuilder {
        public static final int ATTRIBUTES_FIELD_NUMBER = 7;
        private static final CreateSIPDispatchRuleRequest DEFAULT_INSTANCE;
        public static final int DISPATCH_RULE_FIELD_NUMBER = 10;
        public static final int HIDE_PHONE_NUMBER_FIELD_NUMBER = 3;
        public static final int INBOUND_NUMBERS_FIELD_NUMBER = 6;
        public static final int METADATA_FIELD_NUMBER = 5;
        public static final int NAME_FIELD_NUMBER = 4;
        private static volatile Parser<CreateSIPDispatchRuleRequest> PARSER = null;
        public static final int ROOM_CONFIG_FIELD_NUMBER = 9;
        public static final int ROOM_PRESET_FIELD_NUMBER = 8;
        public static final int RULE_FIELD_NUMBER = 1;
        public static final int TRUNK_IDS_FIELD_NUMBER = 2;
        private SIPDispatchRuleInfo dispatchRule_;
        private boolean hidePhoneNumber_;
        private String metadata_;
        private String name_;
        private LivekitRoom.RoomConfiguration roomConfig_;
        private String roomPreset_;
        private SIPDispatchRule rule_;
        private MapFieldLite<String, String> attributes_ = MapFieldLite.f();
        private Internal.ProtobufList<String> trunkIds_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<String> inboundNumbers_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(957790044);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private AttributesDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<CreateSIPDispatchRuleRequest, Builder> implements CreateSIPDispatchRuleRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(CreateSIPDispatchRuleRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            CreateSIPDispatchRuleRequest createSIPDispatchRuleRequest = new CreateSIPDispatchRuleRequest();
            DEFAULT_INSTANCE = createSIPDispatchRuleRequest;
            GeneratedMessageLite.registerDefaultInstance(CreateSIPDispatchRuleRequest.class, createSIPDispatchRuleRequest);
        }

        private CreateSIPDispatchRuleRequest() {
            String strA = ap.a(1324050787);
            this.name_ = strA;
            this.metadata_ = strA;
            this.roomPreset_ = strA;
        }

        private void addAllInboundNumbers(Iterable<String> iterable) {
            ensureInboundNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.inboundNumbers_);
        }

        private void addAllTrunkIds(Iterable<String> iterable) {
            ensureTrunkIdsIsMutable();
            AbstractMessageLite.addAll(iterable, this.trunkIds_);
        }

        private void addInboundNumbers(String str) {
            str.getClass();
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.add(str);
        }

        private void addInboundNumbersBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.add(byteString.L());
        }

        private void addTrunkIds(String str) {
            str.getClass();
            ensureTrunkIdsIsMutable();
            this.trunkIds_.add(str);
        }

        private void addTrunkIdsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureTrunkIdsIsMutable();
            this.trunkIds_.add(byteString.L());
        }

        private void clearDispatchRule() {
            this.dispatchRule_ = null;
        }

        private void clearHidePhoneNumber() {
            this.hidePhoneNumber_ = false;
        }

        private void clearInboundNumbers() {
            this.inboundNumbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearRoomConfig() {
            this.roomConfig_ = null;
        }

        private void clearRoomPreset() {
            this.roomPreset_ = getDefaultInstance().getRoomPreset();
        }

        private void clearRule() {
            this.rule_ = null;
        }

        private void clearTrunkIds() {
            this.trunkIds_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureInboundNumbersIsMutable() {
            Internal.ProtobufList<String> protobufList = this.inboundNumbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.inboundNumbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureTrunkIdsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.trunkIds_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trunkIds_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static CreateSIPDispatchRuleRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableAttributesMap() {
            return internalGetMutableAttributes();
        }

        private MapFieldLite<String, String> internalGetAttributes() {
            return this.attributes_;
        }

        private MapFieldLite<String, String> internalGetMutableAttributes() {
            if (!this.attributes_.k()) {
                this.attributes_ = this.attributes_.n();
            }
            return this.attributes_;
        }

        private void mergeDispatchRule(SIPDispatchRuleInfo sIPDispatchRuleInfo) {
            sIPDispatchRuleInfo.getClass();
            SIPDispatchRuleInfo sIPDispatchRuleInfo2 = this.dispatchRule_;
            if (sIPDispatchRuleInfo2 == null || sIPDispatchRuleInfo2 == SIPDispatchRuleInfo.getDefaultInstance()) {
                this.dispatchRule_ = sIPDispatchRuleInfo;
            } else {
                this.dispatchRule_ = (SIPDispatchRuleInfo) ((SIPDispatchRuleInfo.Builder) SIPDispatchRuleInfo.newBuilder(this.dispatchRule_).v(sIPDispatchRuleInfo)).o();
            }
        }

        private void mergeRoomConfig(LivekitRoom.RoomConfiguration roomConfiguration) {
            roomConfiguration.getClass();
            LivekitRoom.RoomConfiguration roomConfiguration2 = this.roomConfig_;
            if (roomConfiguration2 == null || roomConfiguration2 == LivekitRoom.RoomConfiguration.getDefaultInstance()) {
                this.roomConfig_ = roomConfiguration;
            } else {
                this.roomConfig_ = (LivekitRoom.RoomConfiguration) ((LivekitRoom.RoomConfiguration.Builder) LivekitRoom.RoomConfiguration.newBuilder(this.roomConfig_).v(roomConfiguration)).o();
            }
        }

        private void mergeRule(SIPDispatchRule sIPDispatchRule) {
            sIPDispatchRule.getClass();
            SIPDispatchRule sIPDispatchRule2 = this.rule_;
            if (sIPDispatchRule2 == null || sIPDispatchRule2 == SIPDispatchRule.getDefaultInstance()) {
                this.rule_ = sIPDispatchRule;
            } else {
                this.rule_ = (SIPDispatchRule) ((SIPDispatchRule.Builder) SIPDispatchRule.newBuilder(this.rule_).v(sIPDispatchRule)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static CreateSIPDispatchRuleRequest parseDelimitedFrom(InputStream inputStream) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateSIPDispatchRuleRequest parseFrom(ByteBuffer byteBuffer) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<CreateSIPDispatchRuleRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDispatchRule(SIPDispatchRuleInfo sIPDispatchRuleInfo) {
            sIPDispatchRuleInfo.getClass();
            this.dispatchRule_ = sIPDispatchRuleInfo;
        }

        private void setHidePhoneNumber(boolean z) {
            this.hidePhoneNumber_ = z;
        }

        private void setInboundNumbers(int i, String str) {
            str.getClass();
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.set(i, str);
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setRoomConfig(LivekitRoom.RoomConfiguration roomConfiguration) {
            roomConfiguration.getClass();
            this.roomConfig_ = roomConfiguration;
        }

        private void setRoomPreset(String str) {
            str.getClass();
            this.roomPreset_ = str;
        }

        private void setRoomPresetBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomPreset_ = byteString.L();
        }

        private void setRule(SIPDispatchRule sIPDispatchRule) {
            sIPDispatchRule.getClass();
            this.rule_ = sIPDispatchRule;
        }

        private void setTrunkIds(int i, String str) {
            str.getClass();
            ensureTrunkIdsIsMutable();
            this.trunkIds_.set(i, str);
        }

        @Deprecated
        public boolean containsAttributes(String str) {
            str.getClass();
            return internalGetAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new CreateSIPDispatchRuleRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\n\u0000\u0000\u0001\n\n\u0001\u0002\u0000\u0001\t\u0002Ț\u0003\u0007\u0004Ȉ\u0005Ȉ\u0006Ț\u00072\bȈ\t\t\n\t", new Object[]{"rule_", "trunkIds_", "hidePhoneNumber_", "name_", "metadata_", "inboundNumbers_", "attributes_", AttributesDefaultEntryHolder.a, "roomPreset_", "roomConfig_", "dispatchRule_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<CreateSIPDispatchRuleRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (CreateSIPDispatchRuleRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public Map<String, String> getAttributes() {
            return getAttributesMap();
        }

        @Deprecated
        public int getAttributesCount() {
            return internalGetAttributes().size();
        }

        @Deprecated
        public Map<String, String> getAttributesMap() {
            return Collections.unmodifiableMap(internalGetAttributes());
        }

        @Deprecated
        public String getAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            return mapFieldLiteInternalGetAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetAttributes.get(str) : str2;
        }

        @Deprecated
        public String getAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            if (mapFieldLiteInternalGetAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public SIPDispatchRuleInfo getDispatchRule() {
            SIPDispatchRuleInfo sIPDispatchRuleInfo = this.dispatchRule_;
            return sIPDispatchRuleInfo == null ? SIPDispatchRuleInfo.getDefaultInstance() : sIPDispatchRuleInfo;
        }

        @Deprecated
        public boolean getHidePhoneNumber() {
            return this.hidePhoneNumber_;
        }

        @Deprecated
        public String getInboundNumbers(int i) {
            return (String) this.inboundNumbers_.get(i);
        }

        @Deprecated
        public ByteString getInboundNumbersBytes(int i) {
            return ByteString.n((String) this.inboundNumbers_.get(i));
        }

        @Deprecated
        public int getInboundNumbersCount() {
            return this.inboundNumbers_.size();
        }

        @Deprecated
        public List<String> getInboundNumbersList() {
            return this.inboundNumbers_;
        }

        @Deprecated
        public String getMetadata() {
            return this.metadata_;
        }

        @Deprecated
        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        @Deprecated
        public String getName() {
            return this.name_;
        }

        @Deprecated
        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        @Deprecated
        public LivekitRoom.RoomConfiguration getRoomConfig() {
            LivekitRoom.RoomConfiguration roomConfiguration = this.roomConfig_;
            return roomConfiguration == null ? LivekitRoom.RoomConfiguration.getDefaultInstance() : roomConfiguration;
        }

        @Deprecated
        public String getRoomPreset() {
            return this.roomPreset_;
        }

        @Deprecated
        public ByteString getRoomPresetBytes() {
            return ByteString.n(this.roomPreset_);
        }

        @Deprecated
        public SIPDispatchRule getRule() {
            SIPDispatchRule sIPDispatchRule = this.rule_;
            return sIPDispatchRule == null ? SIPDispatchRule.getDefaultInstance() : sIPDispatchRule;
        }

        @Deprecated
        public String getTrunkIds(int i) {
            return (String) this.trunkIds_.get(i);
        }

        @Deprecated
        public ByteString getTrunkIdsBytes(int i) {
            return ByteString.n((String) this.trunkIds_.get(i));
        }

        @Deprecated
        public int getTrunkIdsCount() {
            return this.trunkIds_.size();
        }

        @Deprecated
        public List<String> getTrunkIdsList() {
            return this.trunkIds_;
        }

        public boolean hasDispatchRule() {
            return this.dispatchRule_ != null;
        }

        @Deprecated
        public boolean hasRoomConfig() {
            return this.roomConfig_ != null;
        }

        @Deprecated
        public boolean hasRule() {
            return this.rule_ != null;
        }

        public static Builder newBuilder(CreateSIPDispatchRuleRequest createSIPDispatchRuleRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(createSIPDispatchRuleRequest);
        }

        public static CreateSIPDispatchRuleRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateSIPDispatchRuleRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static CreateSIPDispatchRuleRequest parseFrom(ByteString byteString) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static CreateSIPDispatchRuleRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static CreateSIPDispatchRuleRequest parseFrom(byte[] bArr) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static CreateSIPDispatchRuleRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static CreateSIPDispatchRuleRequest parseFrom(InputStream inputStream) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateSIPDispatchRuleRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateSIPDispatchRuleRequest parseFrom(CodedInputStream codedInputStream) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static CreateSIPDispatchRuleRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface CreateSIPDispatchRuleRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class CreateSIPInboundTrunkRequest extends GeneratedMessageLite<CreateSIPInboundTrunkRequest, Builder> implements CreateSIPInboundTrunkRequestOrBuilder {
        private static final CreateSIPInboundTrunkRequest DEFAULT_INSTANCE;
        private static volatile Parser<CreateSIPInboundTrunkRequest> PARSER = null;
        public static final int TRUNK_FIELD_NUMBER = 1;
        private SIPInboundTrunkInfo trunk_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<CreateSIPInboundTrunkRequest, Builder> implements CreateSIPInboundTrunkRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(CreateSIPInboundTrunkRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            CreateSIPInboundTrunkRequest createSIPInboundTrunkRequest = new CreateSIPInboundTrunkRequest();
            DEFAULT_INSTANCE = createSIPInboundTrunkRequest;
            GeneratedMessageLite.registerDefaultInstance(CreateSIPInboundTrunkRequest.class, createSIPInboundTrunkRequest);
        }

        private CreateSIPInboundTrunkRequest() {
        }

        private void clearTrunk() {
            this.trunk_ = null;
        }

        public static CreateSIPInboundTrunkRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeTrunk(SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            sIPInboundTrunkInfo.getClass();
            SIPInboundTrunkInfo sIPInboundTrunkInfo2 = this.trunk_;
            if (sIPInboundTrunkInfo2 == null || sIPInboundTrunkInfo2 == SIPInboundTrunkInfo.getDefaultInstance()) {
                this.trunk_ = sIPInboundTrunkInfo;
            } else {
                this.trunk_ = (SIPInboundTrunkInfo) ((SIPInboundTrunkInfo.Builder) SIPInboundTrunkInfo.newBuilder(this.trunk_).v(sIPInboundTrunkInfo)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static CreateSIPInboundTrunkRequest parseDelimitedFrom(InputStream inputStream) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateSIPInboundTrunkRequest parseFrom(ByteBuffer byteBuffer) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<CreateSIPInboundTrunkRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setTrunk(SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            sIPInboundTrunkInfo.getClass();
            this.trunk_ = sIPInboundTrunkInfo;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new CreateSIPInboundTrunkRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\t", new Object[]{ap.a(1504841309)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<CreateSIPInboundTrunkRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (CreateSIPInboundTrunkRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SIPInboundTrunkInfo getTrunk() {
            SIPInboundTrunkInfo sIPInboundTrunkInfo = this.trunk_;
            return sIPInboundTrunkInfo == null ? SIPInboundTrunkInfo.getDefaultInstance() : sIPInboundTrunkInfo;
        }

        public boolean hasTrunk() {
            return this.trunk_ != null;
        }

        public static Builder newBuilder(CreateSIPInboundTrunkRequest createSIPInboundTrunkRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(createSIPInboundTrunkRequest);
        }

        public static CreateSIPInboundTrunkRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateSIPInboundTrunkRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static CreateSIPInboundTrunkRequest parseFrom(ByteString byteString) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static CreateSIPInboundTrunkRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static CreateSIPInboundTrunkRequest parseFrom(byte[] bArr) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static CreateSIPInboundTrunkRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static CreateSIPInboundTrunkRequest parseFrom(InputStream inputStream) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateSIPInboundTrunkRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateSIPInboundTrunkRequest parseFrom(CodedInputStream codedInputStream) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static CreateSIPInboundTrunkRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface CreateSIPInboundTrunkRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class CreateSIPOutboundTrunkRequest extends GeneratedMessageLite<CreateSIPOutboundTrunkRequest, Builder> implements CreateSIPOutboundTrunkRequestOrBuilder {
        private static final CreateSIPOutboundTrunkRequest DEFAULT_INSTANCE;
        private static volatile Parser<CreateSIPOutboundTrunkRequest> PARSER = null;
        public static final int TRUNK_FIELD_NUMBER = 1;
        private SIPOutboundTrunkInfo trunk_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<CreateSIPOutboundTrunkRequest, Builder> implements CreateSIPOutboundTrunkRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(CreateSIPOutboundTrunkRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            CreateSIPOutboundTrunkRequest createSIPOutboundTrunkRequest = new CreateSIPOutboundTrunkRequest();
            DEFAULT_INSTANCE = createSIPOutboundTrunkRequest;
            GeneratedMessageLite.registerDefaultInstance(CreateSIPOutboundTrunkRequest.class, createSIPOutboundTrunkRequest);
        }

        private CreateSIPOutboundTrunkRequest() {
        }

        private void clearTrunk() {
            this.trunk_ = null;
        }

        public static CreateSIPOutboundTrunkRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeTrunk(SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            sIPOutboundTrunkInfo.getClass();
            SIPOutboundTrunkInfo sIPOutboundTrunkInfo2 = this.trunk_;
            if (sIPOutboundTrunkInfo2 == null || sIPOutboundTrunkInfo2 == SIPOutboundTrunkInfo.getDefaultInstance()) {
                this.trunk_ = sIPOutboundTrunkInfo;
            } else {
                this.trunk_ = (SIPOutboundTrunkInfo) ((SIPOutboundTrunkInfo.Builder) SIPOutboundTrunkInfo.newBuilder(this.trunk_).v(sIPOutboundTrunkInfo)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static CreateSIPOutboundTrunkRequest parseDelimitedFrom(InputStream inputStream) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateSIPOutboundTrunkRequest parseFrom(ByteBuffer byteBuffer) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<CreateSIPOutboundTrunkRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setTrunk(SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            sIPOutboundTrunkInfo.getClass();
            this.trunk_ = sIPOutboundTrunkInfo;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new CreateSIPOutboundTrunkRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\t", new Object[]{ap.a(875436920)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<CreateSIPOutboundTrunkRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (CreateSIPOutboundTrunkRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SIPOutboundTrunkInfo getTrunk() {
            SIPOutboundTrunkInfo sIPOutboundTrunkInfo = this.trunk_;
            return sIPOutboundTrunkInfo == null ? SIPOutboundTrunkInfo.getDefaultInstance() : sIPOutboundTrunkInfo;
        }

        public boolean hasTrunk() {
            return this.trunk_ != null;
        }

        public static Builder newBuilder(CreateSIPOutboundTrunkRequest createSIPOutboundTrunkRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(createSIPOutboundTrunkRequest);
        }

        public static CreateSIPOutboundTrunkRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateSIPOutboundTrunkRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static CreateSIPOutboundTrunkRequest parseFrom(ByteString byteString) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static CreateSIPOutboundTrunkRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static CreateSIPOutboundTrunkRequest parseFrom(byte[] bArr) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static CreateSIPOutboundTrunkRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static CreateSIPOutboundTrunkRequest parseFrom(InputStream inputStream) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateSIPOutboundTrunkRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateSIPOutboundTrunkRequest parseFrom(CodedInputStream codedInputStream) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static CreateSIPOutboundTrunkRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface CreateSIPOutboundTrunkRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class CreateSIPParticipantRequest extends GeneratedMessageLite<CreateSIPParticipantRequest, Builder> implements CreateSIPParticipantRequestOrBuilder {
        private static final CreateSIPParticipantRequest DEFAULT_INSTANCE;
        public static final int DISPLAY_NAME_FIELD_NUMBER = 21;
        public static final int DTMF_FIELD_NUMBER = 5;
        public static final int HEADERS_FIELD_NUMBER = 16;
        public static final int HIDE_PHONE_NUMBER_FIELD_NUMBER = 10;
        public static final int INCLUDE_HEADERS_FIELD_NUMBER = 17;
        public static final int KRISP_ENABLED_FIELD_NUMBER = 14;
        public static final int MAX_CALL_DURATION_FIELD_NUMBER = 12;
        public static final int MEDIA_ENCRYPTION_FIELD_NUMBER = 18;
        private static volatile Parser<CreateSIPParticipantRequest> PARSER = null;
        public static final int PARTICIPANT_ATTRIBUTES_FIELD_NUMBER = 9;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 4;
        public static final int PARTICIPANT_METADATA_FIELD_NUMBER = 8;
        public static final int PARTICIPANT_NAME_FIELD_NUMBER = 7;
        public static final int PLAY_DIALTONE_FIELD_NUMBER = 13;
        public static final int PLAY_RINGTONE_FIELD_NUMBER = 6;
        public static final int RINGING_TIMEOUT_FIELD_NUMBER = 11;
        public static final int ROOM_NAME_FIELD_NUMBER = 3;
        public static final int SIP_CALL_TO_FIELD_NUMBER = 2;
        public static final int SIP_NUMBER_FIELD_NUMBER = 15;
        public static final int SIP_TRUNK_ID_FIELD_NUMBER = 1;
        public static final int TRUNK_FIELD_NUMBER = 20;
        public static final int WAIT_UNTIL_ANSWERED_FIELD_NUMBER = 19;
        private int bitField0_;
        private String displayName_;
        private String dtmf_;
        private boolean hidePhoneNumber_;
        private int includeHeaders_;
        private boolean krispEnabled_;
        private Duration maxCallDuration_;
        private int mediaEncryption_;
        private String participantIdentity_;
        private String participantMetadata_;
        private String participantName_;
        private boolean playDialtone_;
        private boolean playRingtone_;
        private Duration ringingTimeout_;
        private String roomName_;
        private String sipCallTo_;
        private String sipNumber_;
        private String sipTrunkId_;
        private SIPOutboundConfig trunk_;
        private boolean waitUntilAnswered_;
        private MapFieldLite<String, String> participantAttributes_ = MapFieldLite.f();
        private MapFieldLite<String, String> headers_ = MapFieldLite.f();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<CreateSIPParticipantRequest, Builder> implements CreateSIPParticipantRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(CreateSIPParticipantRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class HeadersDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(932743681);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private HeadersDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class ParticipantAttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(1525271643);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private ParticipantAttributesDefaultEntryHolder() {
            }
        }

        static {
            CreateSIPParticipantRequest createSIPParticipantRequest = new CreateSIPParticipantRequest();
            DEFAULT_INSTANCE = createSIPParticipantRequest;
            GeneratedMessageLite.registerDefaultInstance(CreateSIPParticipantRequest.class, createSIPParticipantRequest);
        }

        private CreateSIPParticipantRequest() {
            String strA = ap.a(80517869);
            this.sipTrunkId_ = strA;
            this.sipCallTo_ = strA;
            this.sipNumber_ = strA;
            this.roomName_ = strA;
            this.participantIdentity_ = strA;
            this.participantName_ = strA;
            this.participantMetadata_ = strA;
            this.dtmf_ = strA;
            this.displayName_ = strA;
        }

        private void clearDisplayName() {
            this.bitField0_ &= -2;
            this.displayName_ = getDefaultInstance().getDisplayName();
        }

        private void clearDtmf() {
            this.dtmf_ = getDefaultInstance().getDtmf();
        }

        private void clearHidePhoneNumber() {
            this.hidePhoneNumber_ = false;
        }

        private void clearIncludeHeaders() {
            this.includeHeaders_ = 0;
        }

        private void clearKrispEnabled() {
            this.krispEnabled_ = false;
        }

        private void clearMaxCallDuration() {
            this.maxCallDuration_ = null;
        }

        private void clearMediaEncryption() {
            this.mediaEncryption_ = 0;
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearParticipantMetadata() {
            this.participantMetadata_ = getDefaultInstance().getParticipantMetadata();
        }

        private void clearParticipantName() {
            this.participantName_ = getDefaultInstance().getParticipantName();
        }

        private void clearPlayDialtone() {
            this.playDialtone_ = false;
        }

        private void clearPlayRingtone() {
            this.playRingtone_ = false;
        }

        private void clearRingingTimeout() {
            this.ringingTimeout_ = null;
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearSipCallTo() {
            this.sipCallTo_ = getDefaultInstance().getSipCallTo();
        }

        private void clearSipNumber() {
            this.sipNumber_ = getDefaultInstance().getSipNumber();
        }

        private void clearSipTrunkId() {
            this.sipTrunkId_ = getDefaultInstance().getSipTrunkId();
        }

        private void clearTrunk() {
            this.trunk_ = null;
        }

        private void clearWaitUntilAnswered() {
            this.waitUntilAnswered_ = false;
        }

        public static CreateSIPParticipantRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableHeadersMap() {
            return internalGetMutableHeaders();
        }

        private Map<String, String> getMutableParticipantAttributesMap() {
            return internalGetMutableParticipantAttributes();
        }

        private MapFieldLite<String, String> internalGetHeaders() {
            return this.headers_;
        }

        private MapFieldLite<String, String> internalGetMutableHeaders() {
            if (!this.headers_.k()) {
                this.headers_ = this.headers_.n();
            }
            return this.headers_;
        }

        private MapFieldLite<String, String> internalGetMutableParticipantAttributes() {
            if (!this.participantAttributes_.k()) {
                this.participantAttributes_ = this.participantAttributes_.n();
            }
            return this.participantAttributes_;
        }

        private MapFieldLite<String, String> internalGetParticipantAttributes() {
            return this.participantAttributes_;
        }

        private void mergeMaxCallDuration(Duration duration) {
            duration.getClass();
            Duration duration2 = this.maxCallDuration_;
            if (duration2 == null || duration2 == Duration.getDefaultInstance()) {
                this.maxCallDuration_ = duration;
            } else {
                this.maxCallDuration_ = Duration.newBuilder(this.maxCallDuration_).v(duration).o();
            }
        }

        private void mergeRingingTimeout(Duration duration) {
            duration.getClass();
            Duration duration2 = this.ringingTimeout_;
            if (duration2 == null || duration2 == Duration.getDefaultInstance()) {
                this.ringingTimeout_ = duration;
            } else {
                this.ringingTimeout_ = Duration.newBuilder(this.ringingTimeout_).v(duration).o();
            }
        }

        private void mergeTrunk(SIPOutboundConfig sIPOutboundConfig) {
            sIPOutboundConfig.getClass();
            SIPOutboundConfig sIPOutboundConfig2 = this.trunk_;
            if (sIPOutboundConfig2 == null || sIPOutboundConfig2 == SIPOutboundConfig.getDefaultInstance()) {
                this.trunk_ = sIPOutboundConfig;
            } else {
                this.trunk_ = (SIPOutboundConfig) ((SIPOutboundConfig.Builder) SIPOutboundConfig.newBuilder(this.trunk_).v(sIPOutboundConfig)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static CreateSIPParticipantRequest parseDelimitedFrom(InputStream inputStream) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateSIPParticipantRequest parseFrom(ByteBuffer byteBuffer) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<CreateSIPParticipantRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDisplayName(String str) {
            str.getClass();
            this.bitField0_ |= 1;
            this.displayName_ = str;
        }

        private void setDisplayNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.displayName_ = byteString.L();
            this.bitField0_ |= 1;
        }

        private void setDtmf(String str) {
            str.getClass();
            this.dtmf_ = str;
        }

        private void setDtmfBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.dtmf_ = byteString.L();
        }

        private void setHidePhoneNumber(boolean z) {
            this.hidePhoneNumber_ = z;
        }

        private void setIncludeHeaders(SIPHeaderOptions sIPHeaderOptions) {
            this.includeHeaders_ = sIPHeaderOptions.getNumber();
        }

        private void setIncludeHeadersValue(int i) {
            this.includeHeaders_ = i;
        }

        private void setKrispEnabled(boolean z) {
            this.krispEnabled_ = z;
        }

        private void setMaxCallDuration(Duration duration) {
            duration.getClass();
            this.maxCallDuration_ = duration;
        }

        private void setMediaEncryption(SIPMediaEncryption sIPMediaEncryption) {
            this.mediaEncryption_ = sIPMediaEncryption.getNumber();
        }

        private void setMediaEncryptionValue(int i) {
            this.mediaEncryption_ = i;
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setParticipantMetadata(String str) {
            str.getClass();
            this.participantMetadata_ = str;
        }

        private void setParticipantMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantMetadata_ = byteString.L();
        }

        private void setParticipantName(String str) {
            str.getClass();
            this.participantName_ = str;
        }

        private void setParticipantNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantName_ = byteString.L();
        }

        private void setPlayDialtone(boolean z) {
            this.playDialtone_ = z;
        }

        private void setPlayRingtone(boolean z) {
            this.playRingtone_ = z;
        }

        private void setRingingTimeout(Duration duration) {
            duration.getClass();
            this.ringingTimeout_ = duration;
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setSipCallTo(String str) {
            str.getClass();
            this.sipCallTo_ = str;
        }

        private void setSipCallToBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipCallTo_ = byteString.L();
        }

        private void setSipNumber(String str) {
            str.getClass();
            this.sipNumber_ = str;
        }

        private void setSipNumberBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipNumber_ = byteString.L();
        }

        private void setSipTrunkId(String str) {
            str.getClass();
            this.sipTrunkId_ = str;
        }

        private void setSipTrunkIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipTrunkId_ = byteString.L();
        }

        private void setTrunk(SIPOutboundConfig sIPOutboundConfig) {
            sIPOutboundConfig.getClass();
            this.trunk_ = sIPOutboundConfig;
        }

        private void setWaitUntilAnswered(boolean z) {
            this.waitUntilAnswered_ = z;
        }

        public boolean containsHeaders(String str) {
            str.getClass();
            return internalGetHeaders().containsKey(str);
        }

        public boolean containsParticipantAttributes(String str) {
            str.getClass();
            return internalGetParticipantAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new CreateSIPParticipantRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0015\u0000\u0001\u0001\u0015\u0015\u0002\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005Ȉ\u0006\u0007\u0007Ȉ\bȈ\t2\n\u0007\u000b\t\f\t\r\u0007\u000e\u0007\u000fȈ\u00102\u0011\f\u0012\f\u0013\u0007\u0014\t\u0015ለ\u0000", new Object[]{"bitField0_", "sipTrunkId_", "sipCallTo_", "roomName_", "participantIdentity_", "dtmf_", "playRingtone_", "participantName_", "participantMetadata_", "participantAttributes_", ParticipantAttributesDefaultEntryHolder.a, "hidePhoneNumber_", "ringingTimeout_", "maxCallDuration_", "playDialtone_", "krispEnabled_", "sipNumber_", "headers_", HeadersDefaultEntryHolder.a, "includeHeaders_", "mediaEncryption_", "waitUntilAnswered_", "trunk_", "displayName_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<CreateSIPParticipantRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (CreateSIPParticipantRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getDisplayName() {
            return this.displayName_;
        }

        public ByteString getDisplayNameBytes() {
            return ByteString.n(this.displayName_);
        }

        public String getDtmf() {
            return this.dtmf_;
        }

        public ByteString getDtmfBytes() {
            return ByteString.n(this.dtmf_);
        }

        @Deprecated
        public Map<String, String> getHeaders() {
            return getHeadersMap();
        }

        public int getHeadersCount() {
            return internalGetHeaders().size();
        }

        public Map<String, String> getHeadersMap() {
            return Collections.unmodifiableMap(internalGetHeaders());
        }

        public String getHeadersOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeaders = internalGetHeaders();
            return mapFieldLiteInternalGetHeaders.containsKey(str) ? (String) mapFieldLiteInternalGetHeaders.get(str) : str2;
        }

        public String getHeadersOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeaders = internalGetHeaders();
            if (mapFieldLiteInternalGetHeaders.containsKey(str)) {
                return (String) mapFieldLiteInternalGetHeaders.get(str);
            }
            throw new IllegalArgumentException();
        }

        public boolean getHidePhoneNumber() {
            return this.hidePhoneNumber_;
        }

        public SIPHeaderOptions getIncludeHeaders() {
            SIPHeaderOptions sIPHeaderOptionsB = SIPHeaderOptions.b(this.includeHeaders_);
            return sIPHeaderOptionsB == null ? SIPHeaderOptions.e : sIPHeaderOptionsB;
        }

        public int getIncludeHeadersValue() {
            return this.includeHeaders_;
        }

        public boolean getKrispEnabled() {
            return this.krispEnabled_;
        }

        public Duration getMaxCallDuration() {
            Duration duration = this.maxCallDuration_;
            return duration == null ? Duration.getDefaultInstance() : duration;
        }

        public SIPMediaEncryption getMediaEncryption() {
            SIPMediaEncryption sIPMediaEncryptionB = SIPMediaEncryption.b(this.mediaEncryption_);
            return sIPMediaEncryptionB == null ? SIPMediaEncryption.e : sIPMediaEncryptionB;
        }

        public int getMediaEncryptionValue() {
            return this.mediaEncryption_;
        }

        @Deprecated
        public Map<String, String> getParticipantAttributes() {
            return getParticipantAttributesMap();
        }

        public int getParticipantAttributesCount() {
            return internalGetParticipantAttributes().size();
        }

        public Map<String, String> getParticipantAttributesMap() {
            return Collections.unmodifiableMap(internalGetParticipantAttributes());
        }

        public String getParticipantAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetParticipantAttributes = internalGetParticipantAttributes();
            return mapFieldLiteInternalGetParticipantAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetParticipantAttributes.get(str) : str2;
        }

        public String getParticipantAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetParticipantAttributes = internalGetParticipantAttributes();
            if (mapFieldLiteInternalGetParticipantAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetParticipantAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getParticipantMetadata() {
            return this.participantMetadata_;
        }

        public ByteString getParticipantMetadataBytes() {
            return ByteString.n(this.participantMetadata_);
        }

        public String getParticipantName() {
            return this.participantName_;
        }

        public ByteString getParticipantNameBytes() {
            return ByteString.n(this.participantName_);
        }

        public boolean getPlayDialtone() {
            return this.playDialtone_;
        }

        @Deprecated
        public boolean getPlayRingtone() {
            return this.playRingtone_;
        }

        public Duration getRingingTimeout() {
            Duration duration = this.ringingTimeout_;
            return duration == null ? Duration.getDefaultInstance() : duration;
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public String getSipCallTo() {
            return this.sipCallTo_;
        }

        public ByteString getSipCallToBytes() {
            return ByteString.n(this.sipCallTo_);
        }

        public String getSipNumber() {
            return this.sipNumber_;
        }

        public ByteString getSipNumberBytes() {
            return ByteString.n(this.sipNumber_);
        }

        public String getSipTrunkId() {
            return this.sipTrunkId_;
        }

        public ByteString getSipTrunkIdBytes() {
            return ByteString.n(this.sipTrunkId_);
        }

        public SIPOutboundConfig getTrunk() {
            SIPOutboundConfig sIPOutboundConfig = this.trunk_;
            return sIPOutboundConfig == null ? SIPOutboundConfig.getDefaultInstance() : sIPOutboundConfig;
        }

        public boolean getWaitUntilAnswered() {
            return this.waitUntilAnswered_;
        }

        public boolean hasDisplayName() {
            return (this.bitField0_ & 1) != 0;
        }

        public boolean hasMaxCallDuration() {
            return this.maxCallDuration_ != null;
        }

        public boolean hasRingingTimeout() {
            return this.ringingTimeout_ != null;
        }

        public boolean hasTrunk() {
            return this.trunk_ != null;
        }

        public static Builder newBuilder(CreateSIPParticipantRequest createSIPParticipantRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(createSIPParticipantRequest);
        }

        public static CreateSIPParticipantRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateSIPParticipantRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static CreateSIPParticipantRequest parseFrom(ByteString byteString) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static CreateSIPParticipantRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static CreateSIPParticipantRequest parseFrom(byte[] bArr) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static CreateSIPParticipantRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static CreateSIPParticipantRequest parseFrom(InputStream inputStream) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateSIPParticipantRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateSIPParticipantRequest parseFrom(CodedInputStream codedInputStream) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static CreateSIPParticipantRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface CreateSIPParticipantRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public static final class CreateSIPTrunkRequest extends GeneratedMessageLite<CreateSIPTrunkRequest, Builder> implements CreateSIPTrunkRequestOrBuilder {
        private static final CreateSIPTrunkRequest DEFAULT_INSTANCE;
        public static final int INBOUND_ADDRESSES_FIELD_NUMBER = 1;
        public static final int INBOUND_NUMBERS_FIELD_NUMBER = 9;
        public static final int INBOUND_NUMBERS_REGEX_FIELD_NUMBER = 4;
        public static final int INBOUND_PASSWORD_FIELD_NUMBER = 6;
        public static final int INBOUND_USERNAME_FIELD_NUMBER = 5;
        public static final int METADATA_FIELD_NUMBER = 11;
        public static final int NAME_FIELD_NUMBER = 10;
        public static final int OUTBOUND_ADDRESS_FIELD_NUMBER = 2;
        public static final int OUTBOUND_NUMBER_FIELD_NUMBER = 3;
        public static final int OUTBOUND_PASSWORD_FIELD_NUMBER = 8;
        public static final int OUTBOUND_USERNAME_FIELD_NUMBER = 7;
        private static volatile Parser<CreateSIPTrunkRequest> PARSER;
        private Internal.ProtobufList<String> inboundAddresses_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<String> inboundNumbersRegex_;
        private Internal.ProtobufList<String> inboundNumbers_;
        private String inboundPassword_;
        private String inboundUsername_;
        private String metadata_;
        private String name_;
        private String outboundAddress_;
        private String outboundNumber_;
        private String outboundPassword_;
        private String outboundUsername_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<CreateSIPTrunkRequest, Builder> implements CreateSIPTrunkRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(CreateSIPTrunkRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            CreateSIPTrunkRequest createSIPTrunkRequest = new CreateSIPTrunkRequest();
            DEFAULT_INSTANCE = createSIPTrunkRequest;
            GeneratedMessageLite.registerDefaultInstance(CreateSIPTrunkRequest.class, createSIPTrunkRequest);
        }

        private CreateSIPTrunkRequest() {
            String strA = ap.a(1594347572);
            this.outboundAddress_ = strA;
            this.outboundNumber_ = strA;
            this.inboundNumbersRegex_ = GeneratedMessageLite.emptyProtobufList();
            this.inboundNumbers_ = GeneratedMessageLite.emptyProtobufList();
            this.inboundUsername_ = strA;
            this.inboundPassword_ = strA;
            this.outboundUsername_ = strA;
            this.outboundPassword_ = strA;
            this.name_ = strA;
            this.metadata_ = strA;
        }

        private void addAllInboundAddresses(Iterable<String> iterable) {
            ensureInboundAddressesIsMutable();
            AbstractMessageLite.addAll(iterable, this.inboundAddresses_);
        }

        private void addAllInboundNumbers(Iterable<String> iterable) {
            ensureInboundNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.inboundNumbers_);
        }

        private void addAllInboundNumbersRegex(Iterable<String> iterable) {
            ensureInboundNumbersRegexIsMutable();
            AbstractMessageLite.addAll(iterable, this.inboundNumbersRegex_);
        }

        private void addInboundAddresses(String str) {
            str.getClass();
            ensureInboundAddressesIsMutable();
            this.inboundAddresses_.add(str);
        }

        private void addInboundAddressesBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureInboundAddressesIsMutable();
            this.inboundAddresses_.add(byteString.L());
        }

        private void addInboundNumbers(String str) {
            str.getClass();
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.add(str);
        }

        private void addInboundNumbersBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.add(byteString.L());
        }

        private void addInboundNumbersRegex(String str) {
            str.getClass();
            ensureInboundNumbersRegexIsMutable();
            this.inboundNumbersRegex_.add(str);
        }

        private void addInboundNumbersRegexBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureInboundNumbersRegexIsMutable();
            this.inboundNumbersRegex_.add(byteString.L());
        }

        private void clearInboundAddresses() {
            this.inboundAddresses_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearInboundNumbers() {
            this.inboundNumbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearInboundNumbersRegex() {
            this.inboundNumbersRegex_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearInboundPassword() {
            this.inboundPassword_ = getDefaultInstance().getInboundPassword();
        }

        private void clearInboundUsername() {
            this.inboundUsername_ = getDefaultInstance().getInboundUsername();
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearOutboundAddress() {
            this.outboundAddress_ = getDefaultInstance().getOutboundAddress();
        }

        private void clearOutboundNumber() {
            this.outboundNumber_ = getDefaultInstance().getOutboundNumber();
        }

        private void clearOutboundPassword() {
            this.outboundPassword_ = getDefaultInstance().getOutboundPassword();
        }

        private void clearOutboundUsername() {
            this.outboundUsername_ = getDefaultInstance().getOutboundUsername();
        }

        private void ensureInboundAddressesIsMutable() {
            Internal.ProtobufList<String> protobufList = this.inboundAddresses_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.inboundAddresses_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureInboundNumbersIsMutable() {
            Internal.ProtobufList<String> protobufList = this.inboundNumbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.inboundNumbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureInboundNumbersRegexIsMutable() {
            Internal.ProtobufList<String> protobufList = this.inboundNumbersRegex_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.inboundNumbersRegex_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static CreateSIPTrunkRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static CreateSIPTrunkRequest parseDelimitedFrom(InputStream inputStream) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateSIPTrunkRequest parseFrom(ByteBuffer byteBuffer) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<CreateSIPTrunkRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setInboundAddresses(int i, String str) {
            str.getClass();
            ensureInboundAddressesIsMutable();
            this.inboundAddresses_.set(i, str);
        }

        private void setInboundNumbers(int i, String str) {
            str.getClass();
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.set(i, str);
        }

        private void setInboundNumbersRegex(int i, String str) {
            str.getClass();
            ensureInboundNumbersRegexIsMutable();
            this.inboundNumbersRegex_.set(i, str);
        }

        private void setInboundPassword(String str) {
            str.getClass();
            this.inboundPassword_ = str;
        }

        private void setInboundPasswordBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.inboundPassword_ = byteString.L();
        }

        private void setInboundUsername(String str) {
            str.getClass();
            this.inboundUsername_ = str;
        }

        private void setInboundUsernameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.inboundUsername_ = byteString.L();
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setOutboundAddress(String str) {
            str.getClass();
            this.outboundAddress_ = str;
        }

        private void setOutboundAddressBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.outboundAddress_ = byteString.L();
        }

        private void setOutboundNumber(String str) {
            str.getClass();
            this.outboundNumber_ = str;
        }

        private void setOutboundNumberBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.outboundNumber_ = byteString.L();
        }

        private void setOutboundPassword(String str) {
            str.getClass();
            this.outboundPassword_ = str;
        }

        private void setOutboundPasswordBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.outboundPassword_ = byteString.L();
        }

        private void setOutboundUsername(String str) {
            str.getClass();
            this.outboundUsername_ = str;
        }

        private void setOutboundUsernameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.outboundUsername_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new CreateSIPTrunkRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000b\u0000\u0000\u0001\u000b\u000b\u0000\u0003\u0000\u0001Ț\u0002Ȉ\u0003Ȉ\u0004Ț\u0005Ȉ\u0006Ȉ\u0007Ȉ\bȈ\tȚ\nȈ\u000bȈ", new Object[]{"inboundAddresses_", "outboundAddress_", "outboundNumber_", "inboundNumbersRegex_", "inboundUsername_", "inboundPassword_", "outboundUsername_", "outboundPassword_", "inboundNumbers_", "name_", "metadata_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<CreateSIPTrunkRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (CreateSIPTrunkRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getInboundAddresses(int i) {
            return (String) this.inboundAddresses_.get(i);
        }

        public ByteString getInboundAddressesBytes(int i) {
            return ByteString.n((String) this.inboundAddresses_.get(i));
        }

        public int getInboundAddressesCount() {
            return this.inboundAddresses_.size();
        }

        public List<String> getInboundAddressesList() {
            return this.inboundAddresses_;
        }

        public String getInboundNumbers(int i) {
            return (String) this.inboundNumbers_.get(i);
        }

        public ByteString getInboundNumbersBytes(int i) {
            return ByteString.n((String) this.inboundNumbers_.get(i));
        }

        public int getInboundNumbersCount() {
            return this.inboundNumbers_.size();
        }

        public List<String> getInboundNumbersList() {
            return this.inboundNumbers_;
        }

        @Deprecated
        public String getInboundNumbersRegex(int i) {
            return (String) this.inboundNumbersRegex_.get(i);
        }

        @Deprecated
        public ByteString getInboundNumbersRegexBytes(int i) {
            return ByteString.n((String) this.inboundNumbersRegex_.get(i));
        }

        @Deprecated
        public int getInboundNumbersRegexCount() {
            return this.inboundNumbersRegex_.size();
        }

        @Deprecated
        public List<String> getInboundNumbersRegexList() {
            return this.inboundNumbersRegex_;
        }

        public String getInboundPassword() {
            return this.inboundPassword_;
        }

        public ByteString getInboundPasswordBytes() {
            return ByteString.n(this.inboundPassword_);
        }

        public String getInboundUsername() {
            return this.inboundUsername_;
        }

        public ByteString getInboundUsernameBytes() {
            return ByteString.n(this.inboundUsername_);
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getOutboundAddress() {
            return this.outboundAddress_;
        }

        public ByteString getOutboundAddressBytes() {
            return ByteString.n(this.outboundAddress_);
        }

        public String getOutboundNumber() {
            return this.outboundNumber_;
        }

        public ByteString getOutboundNumberBytes() {
            return ByteString.n(this.outboundNumber_);
        }

        public String getOutboundPassword() {
            return this.outboundPassword_;
        }

        public ByteString getOutboundPasswordBytes() {
            return ByteString.n(this.outboundPassword_);
        }

        public String getOutboundUsername() {
            return this.outboundUsername_;
        }

        public ByteString getOutboundUsernameBytes() {
            return ByteString.n(this.outboundUsername_);
        }

        public static Builder newBuilder(CreateSIPTrunkRequest createSIPTrunkRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(createSIPTrunkRequest);
        }

        public static CreateSIPTrunkRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateSIPTrunkRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static CreateSIPTrunkRequest parseFrom(ByteString byteString) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static CreateSIPTrunkRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static CreateSIPTrunkRequest parseFrom(byte[] bArr) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static CreateSIPTrunkRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static CreateSIPTrunkRequest parseFrom(InputStream inputStream) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateSIPTrunkRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateSIPTrunkRequest parseFrom(CodedInputStream codedInputStream) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static CreateSIPTrunkRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public interface CreateSIPTrunkRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DeleteSIPDispatchRuleRequest extends GeneratedMessageLite<DeleteSIPDispatchRuleRequest, Builder> implements DeleteSIPDispatchRuleRequestOrBuilder {
        private static final DeleteSIPDispatchRuleRequest DEFAULT_INSTANCE;
        private static volatile Parser<DeleteSIPDispatchRuleRequest> PARSER = null;
        public static final int SIP_DISPATCH_RULE_ID_FIELD_NUMBER = 1;
        private String sipDispatchRuleId_ = ap.a(260411685);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DeleteSIPDispatchRuleRequest, Builder> implements DeleteSIPDispatchRuleRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DeleteSIPDispatchRuleRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            DeleteSIPDispatchRuleRequest deleteSIPDispatchRuleRequest = new DeleteSIPDispatchRuleRequest();
            DEFAULT_INSTANCE = deleteSIPDispatchRuleRequest;
            GeneratedMessageLite.registerDefaultInstance(DeleteSIPDispatchRuleRequest.class, deleteSIPDispatchRuleRequest);
        }

        private DeleteSIPDispatchRuleRequest() {
        }

        private void clearSipDispatchRuleId() {
            this.sipDispatchRuleId_ = getDefaultInstance().getSipDispatchRuleId();
        }

        public static DeleteSIPDispatchRuleRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DeleteSIPDispatchRuleRequest parseDelimitedFrom(InputStream inputStream) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteSIPDispatchRuleRequest parseFrom(ByteBuffer byteBuffer) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DeleteSIPDispatchRuleRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setSipDispatchRuleId(String str) {
            str.getClass();
            this.sipDispatchRuleId_ = str;
        }

        private void setSipDispatchRuleIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipDispatchRuleId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DeleteSIPDispatchRuleRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"sipDispatchRuleId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DeleteSIPDispatchRuleRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DeleteSIPDispatchRuleRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getSipDispatchRuleId() {
            return this.sipDispatchRuleId_;
        }

        public ByteString getSipDispatchRuleIdBytes() {
            return ByteString.n(this.sipDispatchRuleId_);
        }

        public static Builder newBuilder(DeleteSIPDispatchRuleRequest deleteSIPDispatchRuleRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(deleteSIPDispatchRuleRequest);
        }

        public static DeleteSIPDispatchRuleRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteSIPDispatchRuleRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DeleteSIPDispatchRuleRequest parseFrom(ByteString byteString) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DeleteSIPDispatchRuleRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DeleteSIPDispatchRuleRequest parseFrom(byte[] bArr) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DeleteSIPDispatchRuleRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DeleteSIPDispatchRuleRequest parseFrom(InputStream inputStream) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteSIPDispatchRuleRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteSIPDispatchRuleRequest parseFrom(CodedInputStream codedInputStream) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DeleteSIPDispatchRuleRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DeleteSIPDispatchRuleRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DeleteSIPTrunkRequest extends GeneratedMessageLite<DeleteSIPTrunkRequest, Builder> implements DeleteSIPTrunkRequestOrBuilder {
        private static final DeleteSIPTrunkRequest DEFAULT_INSTANCE;
        private static volatile Parser<DeleteSIPTrunkRequest> PARSER = null;
        public static final int SIP_TRUNK_ID_FIELD_NUMBER = 1;
        private String sipTrunkId_ = ap.a(416202443);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DeleteSIPTrunkRequest, Builder> implements DeleteSIPTrunkRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DeleteSIPTrunkRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            DeleteSIPTrunkRequest deleteSIPTrunkRequest = new DeleteSIPTrunkRequest();
            DEFAULT_INSTANCE = deleteSIPTrunkRequest;
            GeneratedMessageLite.registerDefaultInstance(DeleteSIPTrunkRequest.class, deleteSIPTrunkRequest);
        }

        private DeleteSIPTrunkRequest() {
        }

        private void clearSipTrunkId() {
            this.sipTrunkId_ = getDefaultInstance().getSipTrunkId();
        }

        public static DeleteSIPTrunkRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DeleteSIPTrunkRequest parseDelimitedFrom(InputStream inputStream) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteSIPTrunkRequest parseFrom(ByteBuffer byteBuffer) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DeleteSIPTrunkRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setSipTrunkId(String str) {
            str.getClass();
            this.sipTrunkId_ = str;
        }

        private void setSipTrunkIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipTrunkId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DeleteSIPTrunkRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"sipTrunkId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DeleteSIPTrunkRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DeleteSIPTrunkRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getSipTrunkId() {
            return this.sipTrunkId_;
        }

        public ByteString getSipTrunkIdBytes() {
            return ByteString.n(this.sipTrunkId_);
        }

        public static Builder newBuilder(DeleteSIPTrunkRequest deleteSIPTrunkRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(deleteSIPTrunkRequest);
        }

        public static DeleteSIPTrunkRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteSIPTrunkRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DeleteSIPTrunkRequest parseFrom(ByteString byteString) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DeleteSIPTrunkRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DeleteSIPTrunkRequest parseFrom(byte[] bArr) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DeleteSIPTrunkRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DeleteSIPTrunkRequest parseFrom(InputStream inputStream) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteSIPTrunkRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteSIPTrunkRequest parseFrom(CodedInputStream codedInputStream) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DeleteSIPTrunkRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DeleteSIPTrunkRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class GetSIPInboundTrunkRequest extends GeneratedMessageLite<GetSIPInboundTrunkRequest, Builder> implements GetSIPInboundTrunkRequestOrBuilder {
        private static final GetSIPInboundTrunkRequest DEFAULT_INSTANCE;
        private static volatile Parser<GetSIPInboundTrunkRequest> PARSER = null;
        public static final int SIP_TRUNK_ID_FIELD_NUMBER = 1;
        private String sipTrunkId_ = ap.a(1373389369);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<GetSIPInboundTrunkRequest, Builder> implements GetSIPInboundTrunkRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(GetSIPInboundTrunkRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            GetSIPInboundTrunkRequest getSIPInboundTrunkRequest = new GetSIPInboundTrunkRequest();
            DEFAULT_INSTANCE = getSIPInboundTrunkRequest;
            GeneratedMessageLite.registerDefaultInstance(GetSIPInboundTrunkRequest.class, getSIPInboundTrunkRequest);
        }

        private GetSIPInboundTrunkRequest() {
        }

        private void clearSipTrunkId() {
            this.sipTrunkId_ = getDefaultInstance().getSipTrunkId();
        }

        public static GetSIPInboundTrunkRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static GetSIPInboundTrunkRequest parseDelimitedFrom(InputStream inputStream) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetSIPInboundTrunkRequest parseFrom(ByteBuffer byteBuffer) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<GetSIPInboundTrunkRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setSipTrunkId(String str) {
            str.getClass();
            this.sipTrunkId_ = str;
        }

        private void setSipTrunkIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipTrunkId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new GetSIPInboundTrunkRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"sipTrunkId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<GetSIPInboundTrunkRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (GetSIPInboundTrunkRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getSipTrunkId() {
            return this.sipTrunkId_;
        }

        public ByteString getSipTrunkIdBytes() {
            return ByteString.n(this.sipTrunkId_);
        }

        public static Builder newBuilder(GetSIPInboundTrunkRequest getSIPInboundTrunkRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(getSIPInboundTrunkRequest);
        }

        public static GetSIPInboundTrunkRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetSIPInboundTrunkRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static GetSIPInboundTrunkRequest parseFrom(ByteString byteString) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static GetSIPInboundTrunkRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static GetSIPInboundTrunkRequest parseFrom(byte[] bArr) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static GetSIPInboundTrunkRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static GetSIPInboundTrunkRequest parseFrom(InputStream inputStream) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetSIPInboundTrunkRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetSIPInboundTrunkRequest parseFrom(CodedInputStream codedInputStream) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static GetSIPInboundTrunkRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface GetSIPInboundTrunkRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class GetSIPInboundTrunkResponse extends GeneratedMessageLite<GetSIPInboundTrunkResponse, Builder> implements GetSIPInboundTrunkResponseOrBuilder {
        private static final GetSIPInboundTrunkResponse DEFAULT_INSTANCE;
        private static volatile Parser<GetSIPInboundTrunkResponse> PARSER = null;
        public static final int TRUNK_FIELD_NUMBER = 1;
        private SIPInboundTrunkInfo trunk_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<GetSIPInboundTrunkResponse, Builder> implements GetSIPInboundTrunkResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(GetSIPInboundTrunkResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            GetSIPInboundTrunkResponse getSIPInboundTrunkResponse = new GetSIPInboundTrunkResponse();
            DEFAULT_INSTANCE = getSIPInboundTrunkResponse;
            GeneratedMessageLite.registerDefaultInstance(GetSIPInboundTrunkResponse.class, getSIPInboundTrunkResponse);
        }

        private GetSIPInboundTrunkResponse() {
        }

        private void clearTrunk() {
            this.trunk_ = null;
        }

        public static GetSIPInboundTrunkResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeTrunk(SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            sIPInboundTrunkInfo.getClass();
            SIPInboundTrunkInfo sIPInboundTrunkInfo2 = this.trunk_;
            if (sIPInboundTrunkInfo2 == null || sIPInboundTrunkInfo2 == SIPInboundTrunkInfo.getDefaultInstance()) {
                this.trunk_ = sIPInboundTrunkInfo;
            } else {
                this.trunk_ = (SIPInboundTrunkInfo) ((SIPInboundTrunkInfo.Builder) SIPInboundTrunkInfo.newBuilder(this.trunk_).v(sIPInboundTrunkInfo)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static GetSIPInboundTrunkResponse parseDelimitedFrom(InputStream inputStream) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetSIPInboundTrunkResponse parseFrom(ByteBuffer byteBuffer) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<GetSIPInboundTrunkResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setTrunk(SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            sIPInboundTrunkInfo.getClass();
            this.trunk_ = sIPInboundTrunkInfo;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new GetSIPInboundTrunkResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\t", new Object[]{ap.a(3451820)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<GetSIPInboundTrunkResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (GetSIPInboundTrunkResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SIPInboundTrunkInfo getTrunk() {
            SIPInboundTrunkInfo sIPInboundTrunkInfo = this.trunk_;
            return sIPInboundTrunkInfo == null ? SIPInboundTrunkInfo.getDefaultInstance() : sIPInboundTrunkInfo;
        }

        public boolean hasTrunk() {
            return this.trunk_ != null;
        }

        public static Builder newBuilder(GetSIPInboundTrunkResponse getSIPInboundTrunkResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(getSIPInboundTrunkResponse);
        }

        public static GetSIPInboundTrunkResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetSIPInboundTrunkResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static GetSIPInboundTrunkResponse parseFrom(ByteString byteString) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static GetSIPInboundTrunkResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static GetSIPInboundTrunkResponse parseFrom(byte[] bArr) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static GetSIPInboundTrunkResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static GetSIPInboundTrunkResponse parseFrom(InputStream inputStream) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetSIPInboundTrunkResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetSIPInboundTrunkResponse parseFrom(CodedInputStream codedInputStream) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static GetSIPInboundTrunkResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface GetSIPInboundTrunkResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class GetSIPOutboundTrunkRequest extends GeneratedMessageLite<GetSIPOutboundTrunkRequest, Builder> implements GetSIPOutboundTrunkRequestOrBuilder {
        private static final GetSIPOutboundTrunkRequest DEFAULT_INSTANCE;
        private static volatile Parser<GetSIPOutboundTrunkRequest> PARSER = null;
        public static final int SIP_TRUNK_ID_FIELD_NUMBER = 1;
        private String sipTrunkId_ = ap.a(1592073865);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<GetSIPOutboundTrunkRequest, Builder> implements GetSIPOutboundTrunkRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(GetSIPOutboundTrunkRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            GetSIPOutboundTrunkRequest getSIPOutboundTrunkRequest = new GetSIPOutboundTrunkRequest();
            DEFAULT_INSTANCE = getSIPOutboundTrunkRequest;
            GeneratedMessageLite.registerDefaultInstance(GetSIPOutboundTrunkRequest.class, getSIPOutboundTrunkRequest);
        }

        private GetSIPOutboundTrunkRequest() {
        }

        private void clearSipTrunkId() {
            this.sipTrunkId_ = getDefaultInstance().getSipTrunkId();
        }

        public static GetSIPOutboundTrunkRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static GetSIPOutboundTrunkRequest parseDelimitedFrom(InputStream inputStream) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetSIPOutboundTrunkRequest parseFrom(ByteBuffer byteBuffer) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<GetSIPOutboundTrunkRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setSipTrunkId(String str) {
            str.getClass();
            this.sipTrunkId_ = str;
        }

        private void setSipTrunkIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipTrunkId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new GetSIPOutboundTrunkRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"sipTrunkId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<GetSIPOutboundTrunkRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (GetSIPOutboundTrunkRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getSipTrunkId() {
            return this.sipTrunkId_;
        }

        public ByteString getSipTrunkIdBytes() {
            return ByteString.n(this.sipTrunkId_);
        }

        public static Builder newBuilder(GetSIPOutboundTrunkRequest getSIPOutboundTrunkRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(getSIPOutboundTrunkRequest);
        }

        public static GetSIPOutboundTrunkRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetSIPOutboundTrunkRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static GetSIPOutboundTrunkRequest parseFrom(ByteString byteString) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static GetSIPOutboundTrunkRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static GetSIPOutboundTrunkRequest parseFrom(byte[] bArr) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static GetSIPOutboundTrunkRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static GetSIPOutboundTrunkRequest parseFrom(InputStream inputStream) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetSIPOutboundTrunkRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetSIPOutboundTrunkRequest parseFrom(CodedInputStream codedInputStream) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static GetSIPOutboundTrunkRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface GetSIPOutboundTrunkRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class GetSIPOutboundTrunkResponse extends GeneratedMessageLite<GetSIPOutboundTrunkResponse, Builder> implements GetSIPOutboundTrunkResponseOrBuilder {
        private static final GetSIPOutboundTrunkResponse DEFAULT_INSTANCE;
        private static volatile Parser<GetSIPOutboundTrunkResponse> PARSER = null;
        public static final int TRUNK_FIELD_NUMBER = 1;
        private SIPOutboundTrunkInfo trunk_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<GetSIPOutboundTrunkResponse, Builder> implements GetSIPOutboundTrunkResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(GetSIPOutboundTrunkResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            GetSIPOutboundTrunkResponse getSIPOutboundTrunkResponse = new GetSIPOutboundTrunkResponse();
            DEFAULT_INSTANCE = getSIPOutboundTrunkResponse;
            GeneratedMessageLite.registerDefaultInstance(GetSIPOutboundTrunkResponse.class, getSIPOutboundTrunkResponse);
        }

        private GetSIPOutboundTrunkResponse() {
        }

        private void clearTrunk() {
            this.trunk_ = null;
        }

        public static GetSIPOutboundTrunkResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeTrunk(SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            sIPOutboundTrunkInfo.getClass();
            SIPOutboundTrunkInfo sIPOutboundTrunkInfo2 = this.trunk_;
            if (sIPOutboundTrunkInfo2 == null || sIPOutboundTrunkInfo2 == SIPOutboundTrunkInfo.getDefaultInstance()) {
                this.trunk_ = sIPOutboundTrunkInfo;
            } else {
                this.trunk_ = (SIPOutboundTrunkInfo) ((SIPOutboundTrunkInfo.Builder) SIPOutboundTrunkInfo.newBuilder(this.trunk_).v(sIPOutboundTrunkInfo)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static GetSIPOutboundTrunkResponse parseDelimitedFrom(InputStream inputStream) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetSIPOutboundTrunkResponse parseFrom(ByteBuffer byteBuffer) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<GetSIPOutboundTrunkResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setTrunk(SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            sIPOutboundTrunkInfo.getClass();
            this.trunk_ = sIPOutboundTrunkInfo;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new GetSIPOutboundTrunkResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\t", new Object[]{ap.a(829848839)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<GetSIPOutboundTrunkResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (GetSIPOutboundTrunkResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SIPOutboundTrunkInfo getTrunk() {
            SIPOutboundTrunkInfo sIPOutboundTrunkInfo = this.trunk_;
            return sIPOutboundTrunkInfo == null ? SIPOutboundTrunkInfo.getDefaultInstance() : sIPOutboundTrunkInfo;
        }

        public boolean hasTrunk() {
            return this.trunk_ != null;
        }

        public static Builder newBuilder(GetSIPOutboundTrunkResponse getSIPOutboundTrunkResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(getSIPOutboundTrunkResponse);
        }

        public static GetSIPOutboundTrunkResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetSIPOutboundTrunkResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static GetSIPOutboundTrunkResponse parseFrom(ByteString byteString) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static GetSIPOutboundTrunkResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static GetSIPOutboundTrunkResponse parseFrom(byte[] bArr) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static GetSIPOutboundTrunkResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static GetSIPOutboundTrunkResponse parseFrom(InputStream inputStream) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetSIPOutboundTrunkResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetSIPOutboundTrunkResponse parseFrom(CodedInputStream codedInputStream) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static GetSIPOutboundTrunkResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface GetSIPOutboundTrunkResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListSIPDispatchRuleRequest extends GeneratedMessageLite<ListSIPDispatchRuleRequest, Builder> implements ListSIPDispatchRuleRequestOrBuilder {
        private static final ListSIPDispatchRuleRequest DEFAULT_INSTANCE;
        public static final int DISPATCH_RULE_IDS_FIELD_NUMBER = 1;
        public static final int PAGE_FIELD_NUMBER = 3;
        private static volatile Parser<ListSIPDispatchRuleRequest> PARSER = null;
        public static final int TRUNK_IDS_FIELD_NUMBER = 2;
        private LivekitModels.Pagination page_;
        private Internal.ProtobufList<String> dispatchRuleIds_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<String> trunkIds_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListSIPDispatchRuleRequest, Builder> implements ListSIPDispatchRuleRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListSIPDispatchRuleRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListSIPDispatchRuleRequest listSIPDispatchRuleRequest = new ListSIPDispatchRuleRequest();
            DEFAULT_INSTANCE = listSIPDispatchRuleRequest;
            GeneratedMessageLite.registerDefaultInstance(ListSIPDispatchRuleRequest.class, listSIPDispatchRuleRequest);
        }

        private ListSIPDispatchRuleRequest() {
        }

        private void addAllDispatchRuleIds(Iterable<String> iterable) {
            ensureDispatchRuleIdsIsMutable();
            AbstractMessageLite.addAll(iterable, this.dispatchRuleIds_);
        }

        private void addAllTrunkIds(Iterable<String> iterable) {
            ensureTrunkIdsIsMutable();
            AbstractMessageLite.addAll(iterable, this.trunkIds_);
        }

        private void addDispatchRuleIds(String str) {
            str.getClass();
            ensureDispatchRuleIdsIsMutable();
            this.dispatchRuleIds_.add(str);
        }

        private void addDispatchRuleIdsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureDispatchRuleIdsIsMutable();
            this.dispatchRuleIds_.add(byteString.L());
        }

        private void addTrunkIds(String str) {
            str.getClass();
            ensureTrunkIdsIsMutable();
            this.trunkIds_.add(str);
        }

        private void addTrunkIdsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureTrunkIdsIsMutable();
            this.trunkIds_.add(byteString.L());
        }

        private void clearDispatchRuleIds() {
            this.dispatchRuleIds_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearPage() {
            this.page_ = null;
        }

        private void clearTrunkIds() {
            this.trunkIds_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureDispatchRuleIdsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.dispatchRuleIds_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.dispatchRuleIds_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureTrunkIdsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.trunkIds_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trunkIds_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListSIPDispatchRuleRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergePage(LivekitModels.Pagination pagination) {
            pagination.getClass();
            LivekitModels.Pagination pagination2 = this.page_;
            if (pagination2 == null || pagination2 == LivekitModels.Pagination.getDefaultInstance()) {
                this.page_ = pagination;
            } else {
                this.page_ = (LivekitModels.Pagination) ((LivekitModels.Pagination.Builder) LivekitModels.Pagination.newBuilder(this.page_).v(pagination)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListSIPDispatchRuleRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPDispatchRuleRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListSIPDispatchRuleRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDispatchRuleIds(int i, String str) {
            str.getClass();
            ensureDispatchRuleIdsIsMutable();
            this.dispatchRuleIds_.set(i, str);
        }

        private void setPage(LivekitModels.Pagination pagination) {
            pagination.getClass();
            this.page_ = pagination;
        }

        private void setTrunkIds(int i, String str) {
            str.getClass();
            ensureTrunkIdsIsMutable();
            this.trunkIds_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListSIPDispatchRuleRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0002\u0000\u0001Ț\u0002Ț\u0003\t", new Object[]{ap.a(216080407), ap.a(795160389), ap.a(2012069273)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListSIPDispatchRuleRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListSIPDispatchRuleRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getDispatchRuleIds(int i) {
            return (String) this.dispatchRuleIds_.get(i);
        }

        public ByteString getDispatchRuleIdsBytes(int i) {
            return ByteString.n((String) this.dispatchRuleIds_.get(i));
        }

        public int getDispatchRuleIdsCount() {
            return this.dispatchRuleIds_.size();
        }

        public List<String> getDispatchRuleIdsList() {
            return this.dispatchRuleIds_;
        }

        public LivekitModels.Pagination getPage() {
            LivekitModels.Pagination pagination = this.page_;
            return pagination == null ? LivekitModels.Pagination.getDefaultInstance() : pagination;
        }

        public String getTrunkIds(int i) {
            return (String) this.trunkIds_.get(i);
        }

        public ByteString getTrunkIdsBytes(int i) {
            return ByteString.n((String) this.trunkIds_.get(i));
        }

        public int getTrunkIdsCount() {
            return this.trunkIds_.size();
        }

        public List<String> getTrunkIdsList() {
            return this.trunkIds_;
        }

        public boolean hasPage() {
            return this.page_ != null;
        }

        public static Builder newBuilder(ListSIPDispatchRuleRequest listSIPDispatchRuleRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listSIPDispatchRuleRequest);
        }

        public static ListSIPDispatchRuleRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPDispatchRuleRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListSIPDispatchRuleRequest parseFrom(ByteString byteString) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListSIPDispatchRuleRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListSIPDispatchRuleRequest parseFrom(byte[] bArr) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListSIPDispatchRuleRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListSIPDispatchRuleRequest parseFrom(InputStream inputStream) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPDispatchRuleRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPDispatchRuleRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListSIPDispatchRuleRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListSIPDispatchRuleRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListSIPDispatchRuleResponse extends GeneratedMessageLite<ListSIPDispatchRuleResponse, Builder> implements ListSIPDispatchRuleResponseOrBuilder {
        private static final ListSIPDispatchRuleResponse DEFAULT_INSTANCE;
        public static final int ITEMS_FIELD_NUMBER = 1;
        private static volatile Parser<ListSIPDispatchRuleResponse> PARSER;
        private Internal.ProtobufList<SIPDispatchRuleInfo> items_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListSIPDispatchRuleResponse, Builder> implements ListSIPDispatchRuleResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListSIPDispatchRuleResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListSIPDispatchRuleResponse listSIPDispatchRuleResponse = new ListSIPDispatchRuleResponse();
            DEFAULT_INSTANCE = listSIPDispatchRuleResponse;
            GeneratedMessageLite.registerDefaultInstance(ListSIPDispatchRuleResponse.class, listSIPDispatchRuleResponse);
        }

        private ListSIPDispatchRuleResponse() {
        }

        private void addAllItems(Iterable<? extends SIPDispatchRuleInfo> iterable) {
            ensureItemsIsMutable();
            AbstractMessageLite.addAll(iterable, this.items_);
        }

        private void addItems(SIPDispatchRuleInfo sIPDispatchRuleInfo) {
            sIPDispatchRuleInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(sIPDispatchRuleInfo);
        }

        private void clearItems() {
            this.items_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureItemsIsMutable() {
            Internal.ProtobufList<SIPDispatchRuleInfo> protobufList = this.items_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.items_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListSIPDispatchRuleResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListSIPDispatchRuleResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPDispatchRuleResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListSIPDispatchRuleResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeItems(int i) {
            ensureItemsIsMutable();
            this.items_.remove(i);
        }

        private void setItems(int i, SIPDispatchRuleInfo sIPDispatchRuleInfo) {
            sIPDispatchRuleInfo.getClass();
            ensureItemsIsMutable();
            this.items_.set(i, sIPDispatchRuleInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListSIPDispatchRuleResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1247467408), SIPDispatchRuleInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListSIPDispatchRuleResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListSIPDispatchRuleResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SIPDispatchRuleInfo getItems(int i) {
            return (SIPDispatchRuleInfo) this.items_.get(i);
        }

        public int getItemsCount() {
            return this.items_.size();
        }

        public List<SIPDispatchRuleInfo> getItemsList() {
            return this.items_;
        }

        public SIPDispatchRuleInfoOrBuilder getItemsOrBuilder(int i) {
            return (SIPDispatchRuleInfoOrBuilder) this.items_.get(i);
        }

        public List<? extends SIPDispatchRuleInfoOrBuilder> getItemsOrBuilderList() {
            return this.items_;
        }

        public static Builder newBuilder(ListSIPDispatchRuleResponse listSIPDispatchRuleResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listSIPDispatchRuleResponse);
        }

        public static ListSIPDispatchRuleResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPDispatchRuleResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListSIPDispatchRuleResponse parseFrom(ByteString byteString) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addItems(int i, SIPDispatchRuleInfo sIPDispatchRuleInfo) {
            sIPDispatchRuleInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(i, sIPDispatchRuleInfo);
        }

        public static ListSIPDispatchRuleResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListSIPDispatchRuleResponse parseFrom(byte[] bArr) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListSIPDispatchRuleResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListSIPDispatchRuleResponse parseFrom(InputStream inputStream) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPDispatchRuleResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPDispatchRuleResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListSIPDispatchRuleResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPDispatchRuleResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListSIPDispatchRuleResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListSIPInboundTrunkRequest extends GeneratedMessageLite<ListSIPInboundTrunkRequest, Builder> implements ListSIPInboundTrunkRequestOrBuilder {
        private static final ListSIPInboundTrunkRequest DEFAULT_INSTANCE;
        public static final int NUMBERS_FIELD_NUMBER = 2;
        public static final int PAGE_FIELD_NUMBER = 3;
        private static volatile Parser<ListSIPInboundTrunkRequest> PARSER = null;
        public static final int TRUNK_IDS_FIELD_NUMBER = 1;
        private LivekitModels.Pagination page_;
        private Internal.ProtobufList<String> trunkIds_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<String> numbers_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListSIPInboundTrunkRequest, Builder> implements ListSIPInboundTrunkRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListSIPInboundTrunkRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListSIPInboundTrunkRequest listSIPInboundTrunkRequest = new ListSIPInboundTrunkRequest();
            DEFAULT_INSTANCE = listSIPInboundTrunkRequest;
            GeneratedMessageLite.registerDefaultInstance(ListSIPInboundTrunkRequest.class, listSIPInboundTrunkRequest);
        }

        private ListSIPInboundTrunkRequest() {
        }

        private void addAllNumbers(Iterable<String> iterable) {
            ensureNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.numbers_);
        }

        private void addAllTrunkIds(Iterable<String> iterable) {
            ensureTrunkIdsIsMutable();
            AbstractMessageLite.addAll(iterable, this.trunkIds_);
        }

        private void addNumbers(String str) {
            str.getClass();
            ensureNumbersIsMutable();
            this.numbers_.add(str);
        }

        private void addNumbersBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureNumbersIsMutable();
            this.numbers_.add(byteString.L());
        }

        private void addTrunkIds(String str) {
            str.getClass();
            ensureTrunkIdsIsMutable();
            this.trunkIds_.add(str);
        }

        private void addTrunkIdsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureTrunkIdsIsMutable();
            this.trunkIds_.add(byteString.L());
        }

        private void clearNumbers() {
            this.numbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearPage() {
            this.page_ = null;
        }

        private void clearTrunkIds() {
            this.trunkIds_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureNumbersIsMutable() {
            Internal.ProtobufList<String> protobufList = this.numbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.numbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureTrunkIdsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.trunkIds_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trunkIds_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListSIPInboundTrunkRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergePage(LivekitModels.Pagination pagination) {
            pagination.getClass();
            LivekitModels.Pagination pagination2 = this.page_;
            if (pagination2 == null || pagination2 == LivekitModels.Pagination.getDefaultInstance()) {
                this.page_ = pagination;
            } else {
                this.page_ = (LivekitModels.Pagination) ((LivekitModels.Pagination.Builder) LivekitModels.Pagination.newBuilder(this.page_).v(pagination)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListSIPInboundTrunkRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPInboundTrunkRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListSIPInboundTrunkRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setNumbers(int i, String str) {
            str.getClass();
            ensureNumbersIsMutable();
            this.numbers_.set(i, str);
        }

        private void setPage(LivekitModels.Pagination pagination) {
            pagination.getClass();
            this.page_ = pagination;
        }

        private void setTrunkIds(int i, String str) {
            str.getClass();
            ensureTrunkIdsIsMutable();
            this.trunkIds_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListSIPInboundTrunkRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0002\u0000\u0001Ț\u0002Ț\u0003\t", new Object[]{ap.a(1344384796), ap.a(707628296), ap.a(131873274)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListSIPInboundTrunkRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListSIPInboundTrunkRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getNumbers(int i) {
            return (String) this.numbers_.get(i);
        }

        public ByteString getNumbersBytes(int i) {
            return ByteString.n((String) this.numbers_.get(i));
        }

        public int getNumbersCount() {
            return this.numbers_.size();
        }

        public List<String> getNumbersList() {
            return this.numbers_;
        }

        public LivekitModels.Pagination getPage() {
            LivekitModels.Pagination pagination = this.page_;
            return pagination == null ? LivekitModels.Pagination.getDefaultInstance() : pagination;
        }

        public String getTrunkIds(int i) {
            return (String) this.trunkIds_.get(i);
        }

        public ByteString getTrunkIdsBytes(int i) {
            return ByteString.n((String) this.trunkIds_.get(i));
        }

        public int getTrunkIdsCount() {
            return this.trunkIds_.size();
        }

        public List<String> getTrunkIdsList() {
            return this.trunkIds_;
        }

        public boolean hasPage() {
            return this.page_ != null;
        }

        public static Builder newBuilder(ListSIPInboundTrunkRequest listSIPInboundTrunkRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listSIPInboundTrunkRequest);
        }

        public static ListSIPInboundTrunkRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPInboundTrunkRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListSIPInboundTrunkRequest parseFrom(ByteString byteString) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListSIPInboundTrunkRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListSIPInboundTrunkRequest parseFrom(byte[] bArr) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListSIPInboundTrunkRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListSIPInboundTrunkRequest parseFrom(InputStream inputStream) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPInboundTrunkRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPInboundTrunkRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListSIPInboundTrunkRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListSIPInboundTrunkRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListSIPInboundTrunkResponse extends GeneratedMessageLite<ListSIPInboundTrunkResponse, Builder> implements ListSIPInboundTrunkResponseOrBuilder {
        private static final ListSIPInboundTrunkResponse DEFAULT_INSTANCE;
        public static final int ITEMS_FIELD_NUMBER = 1;
        private static volatile Parser<ListSIPInboundTrunkResponse> PARSER;
        private Internal.ProtobufList<SIPInboundTrunkInfo> items_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListSIPInboundTrunkResponse, Builder> implements ListSIPInboundTrunkResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListSIPInboundTrunkResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListSIPInboundTrunkResponse listSIPInboundTrunkResponse = new ListSIPInboundTrunkResponse();
            DEFAULT_INSTANCE = listSIPInboundTrunkResponse;
            GeneratedMessageLite.registerDefaultInstance(ListSIPInboundTrunkResponse.class, listSIPInboundTrunkResponse);
        }

        private ListSIPInboundTrunkResponse() {
        }

        private void addAllItems(Iterable<? extends SIPInboundTrunkInfo> iterable) {
            ensureItemsIsMutable();
            AbstractMessageLite.addAll(iterable, this.items_);
        }

        private void addItems(SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            sIPInboundTrunkInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(sIPInboundTrunkInfo);
        }

        private void clearItems() {
            this.items_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureItemsIsMutable() {
            Internal.ProtobufList<SIPInboundTrunkInfo> protobufList = this.items_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.items_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListSIPInboundTrunkResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListSIPInboundTrunkResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPInboundTrunkResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListSIPInboundTrunkResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeItems(int i) {
            ensureItemsIsMutable();
            this.items_.remove(i);
        }

        private void setItems(int i, SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            sIPInboundTrunkInfo.getClass();
            ensureItemsIsMutable();
            this.items_.set(i, sIPInboundTrunkInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListSIPInboundTrunkResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1338044240), SIPInboundTrunkInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListSIPInboundTrunkResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListSIPInboundTrunkResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SIPInboundTrunkInfo getItems(int i) {
            return (SIPInboundTrunkInfo) this.items_.get(i);
        }

        public int getItemsCount() {
            return this.items_.size();
        }

        public List<SIPInboundTrunkInfo> getItemsList() {
            return this.items_;
        }

        public SIPInboundTrunkInfoOrBuilder getItemsOrBuilder(int i) {
            return (SIPInboundTrunkInfoOrBuilder) this.items_.get(i);
        }

        public List<? extends SIPInboundTrunkInfoOrBuilder> getItemsOrBuilderList() {
            return this.items_;
        }

        public static Builder newBuilder(ListSIPInboundTrunkResponse listSIPInboundTrunkResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listSIPInboundTrunkResponse);
        }

        public static ListSIPInboundTrunkResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPInboundTrunkResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListSIPInboundTrunkResponse parseFrom(ByteString byteString) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addItems(int i, SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            sIPInboundTrunkInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(i, sIPInboundTrunkInfo);
        }

        public static ListSIPInboundTrunkResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListSIPInboundTrunkResponse parseFrom(byte[] bArr) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListSIPInboundTrunkResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListSIPInboundTrunkResponse parseFrom(InputStream inputStream) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPInboundTrunkResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPInboundTrunkResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListSIPInboundTrunkResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPInboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListSIPInboundTrunkResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListSIPOutboundTrunkRequest extends GeneratedMessageLite<ListSIPOutboundTrunkRequest, Builder> implements ListSIPOutboundTrunkRequestOrBuilder {
        private static final ListSIPOutboundTrunkRequest DEFAULT_INSTANCE;
        public static final int NUMBERS_FIELD_NUMBER = 2;
        public static final int PAGE_FIELD_NUMBER = 3;
        private static volatile Parser<ListSIPOutboundTrunkRequest> PARSER = null;
        public static final int TRUNK_IDS_FIELD_NUMBER = 1;
        private LivekitModels.Pagination page_;
        private Internal.ProtobufList<String> trunkIds_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<String> numbers_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListSIPOutboundTrunkRequest, Builder> implements ListSIPOutboundTrunkRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListSIPOutboundTrunkRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListSIPOutboundTrunkRequest listSIPOutboundTrunkRequest = new ListSIPOutboundTrunkRequest();
            DEFAULT_INSTANCE = listSIPOutboundTrunkRequest;
            GeneratedMessageLite.registerDefaultInstance(ListSIPOutboundTrunkRequest.class, listSIPOutboundTrunkRequest);
        }

        private ListSIPOutboundTrunkRequest() {
        }

        private void addAllNumbers(Iterable<String> iterable) {
            ensureNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.numbers_);
        }

        private void addAllTrunkIds(Iterable<String> iterable) {
            ensureTrunkIdsIsMutable();
            AbstractMessageLite.addAll(iterable, this.trunkIds_);
        }

        private void addNumbers(String str) {
            str.getClass();
            ensureNumbersIsMutable();
            this.numbers_.add(str);
        }

        private void addNumbersBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureNumbersIsMutable();
            this.numbers_.add(byteString.L());
        }

        private void addTrunkIds(String str) {
            str.getClass();
            ensureTrunkIdsIsMutable();
            this.trunkIds_.add(str);
        }

        private void addTrunkIdsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureTrunkIdsIsMutable();
            this.trunkIds_.add(byteString.L());
        }

        private void clearNumbers() {
            this.numbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearPage() {
            this.page_ = null;
        }

        private void clearTrunkIds() {
            this.trunkIds_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureNumbersIsMutable() {
            Internal.ProtobufList<String> protobufList = this.numbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.numbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureTrunkIdsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.trunkIds_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trunkIds_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListSIPOutboundTrunkRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergePage(LivekitModels.Pagination pagination) {
            pagination.getClass();
            LivekitModels.Pagination pagination2 = this.page_;
            if (pagination2 == null || pagination2 == LivekitModels.Pagination.getDefaultInstance()) {
                this.page_ = pagination;
            } else {
                this.page_ = (LivekitModels.Pagination) ((LivekitModels.Pagination.Builder) LivekitModels.Pagination.newBuilder(this.page_).v(pagination)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListSIPOutboundTrunkRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPOutboundTrunkRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListSIPOutboundTrunkRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setNumbers(int i, String str) {
            str.getClass();
            ensureNumbersIsMutable();
            this.numbers_.set(i, str);
        }

        private void setPage(LivekitModels.Pagination pagination) {
            pagination.getClass();
            this.page_ = pagination;
        }

        private void setTrunkIds(int i, String str) {
            str.getClass();
            ensureTrunkIdsIsMutable();
            this.trunkIds_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListSIPOutboundTrunkRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0002\u0000\u0001Ț\u0002Ț\u0003\t", new Object[]{ap.a(1340029830), ap.a(596100190), ap.a(1676353458)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListSIPOutboundTrunkRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListSIPOutboundTrunkRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getNumbers(int i) {
            return (String) this.numbers_.get(i);
        }

        public ByteString getNumbersBytes(int i) {
            return ByteString.n((String) this.numbers_.get(i));
        }

        public int getNumbersCount() {
            return this.numbers_.size();
        }

        public List<String> getNumbersList() {
            return this.numbers_;
        }

        public LivekitModels.Pagination getPage() {
            LivekitModels.Pagination pagination = this.page_;
            return pagination == null ? LivekitModels.Pagination.getDefaultInstance() : pagination;
        }

        public String getTrunkIds(int i) {
            return (String) this.trunkIds_.get(i);
        }

        public ByteString getTrunkIdsBytes(int i) {
            return ByteString.n((String) this.trunkIds_.get(i));
        }

        public int getTrunkIdsCount() {
            return this.trunkIds_.size();
        }

        public List<String> getTrunkIdsList() {
            return this.trunkIds_;
        }

        public boolean hasPage() {
            return this.page_ != null;
        }

        public static Builder newBuilder(ListSIPOutboundTrunkRequest listSIPOutboundTrunkRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listSIPOutboundTrunkRequest);
        }

        public static ListSIPOutboundTrunkRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPOutboundTrunkRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListSIPOutboundTrunkRequest parseFrom(ByteString byteString) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListSIPOutboundTrunkRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListSIPOutboundTrunkRequest parseFrom(byte[] bArr) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListSIPOutboundTrunkRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListSIPOutboundTrunkRequest parseFrom(InputStream inputStream) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPOutboundTrunkRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPOutboundTrunkRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListSIPOutboundTrunkRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListSIPOutboundTrunkRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListSIPOutboundTrunkResponse extends GeneratedMessageLite<ListSIPOutboundTrunkResponse, Builder> implements ListSIPOutboundTrunkResponseOrBuilder {
        private static final ListSIPOutboundTrunkResponse DEFAULT_INSTANCE;
        public static final int ITEMS_FIELD_NUMBER = 1;
        private static volatile Parser<ListSIPOutboundTrunkResponse> PARSER;
        private Internal.ProtobufList<SIPOutboundTrunkInfo> items_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListSIPOutboundTrunkResponse, Builder> implements ListSIPOutboundTrunkResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListSIPOutboundTrunkResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListSIPOutboundTrunkResponse listSIPOutboundTrunkResponse = new ListSIPOutboundTrunkResponse();
            DEFAULT_INSTANCE = listSIPOutboundTrunkResponse;
            GeneratedMessageLite.registerDefaultInstance(ListSIPOutboundTrunkResponse.class, listSIPOutboundTrunkResponse);
        }

        private ListSIPOutboundTrunkResponse() {
        }

        private void addAllItems(Iterable<? extends SIPOutboundTrunkInfo> iterable) {
            ensureItemsIsMutable();
            AbstractMessageLite.addAll(iterable, this.items_);
        }

        private void addItems(SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            sIPOutboundTrunkInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(sIPOutboundTrunkInfo);
        }

        private void clearItems() {
            this.items_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureItemsIsMutable() {
            Internal.ProtobufList<SIPOutboundTrunkInfo> protobufList = this.items_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.items_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListSIPOutboundTrunkResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListSIPOutboundTrunkResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPOutboundTrunkResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListSIPOutboundTrunkResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeItems(int i) {
            ensureItemsIsMutable();
            this.items_.remove(i);
        }

        private void setItems(int i, SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            sIPOutboundTrunkInfo.getClass();
            ensureItemsIsMutable();
            this.items_.set(i, sIPOutboundTrunkInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListSIPOutboundTrunkResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(217957324), SIPOutboundTrunkInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListSIPOutboundTrunkResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListSIPOutboundTrunkResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SIPOutboundTrunkInfo getItems(int i) {
            return (SIPOutboundTrunkInfo) this.items_.get(i);
        }

        public int getItemsCount() {
            return this.items_.size();
        }

        public List<SIPOutboundTrunkInfo> getItemsList() {
            return this.items_;
        }

        public SIPOutboundTrunkInfoOrBuilder getItemsOrBuilder(int i) {
            return (SIPOutboundTrunkInfoOrBuilder) this.items_.get(i);
        }

        public List<? extends SIPOutboundTrunkInfoOrBuilder> getItemsOrBuilderList() {
            return this.items_;
        }

        public static Builder newBuilder(ListSIPOutboundTrunkResponse listSIPOutboundTrunkResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listSIPOutboundTrunkResponse);
        }

        public static ListSIPOutboundTrunkResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPOutboundTrunkResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListSIPOutboundTrunkResponse parseFrom(ByteString byteString) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addItems(int i, SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            sIPOutboundTrunkInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(i, sIPOutboundTrunkInfo);
        }

        public static ListSIPOutboundTrunkResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListSIPOutboundTrunkResponse parseFrom(byte[] bArr) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListSIPOutboundTrunkResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListSIPOutboundTrunkResponse parseFrom(InputStream inputStream) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPOutboundTrunkResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPOutboundTrunkResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListSIPOutboundTrunkResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPOutboundTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListSIPOutboundTrunkResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public static final class ListSIPTrunkRequest extends GeneratedMessageLite<ListSIPTrunkRequest, Builder> implements ListSIPTrunkRequestOrBuilder {
        private static final ListSIPTrunkRequest DEFAULT_INSTANCE;
        public static final int PAGE_FIELD_NUMBER = 1;
        private static volatile Parser<ListSIPTrunkRequest> PARSER;
        private LivekitModels.Pagination page_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListSIPTrunkRequest, Builder> implements ListSIPTrunkRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListSIPTrunkRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListSIPTrunkRequest listSIPTrunkRequest = new ListSIPTrunkRequest();
            DEFAULT_INSTANCE = listSIPTrunkRequest;
            GeneratedMessageLite.registerDefaultInstance(ListSIPTrunkRequest.class, listSIPTrunkRequest);
        }

        private ListSIPTrunkRequest() {
        }

        private void clearPage() {
            this.page_ = null;
        }

        public static ListSIPTrunkRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergePage(LivekitModels.Pagination pagination) {
            pagination.getClass();
            LivekitModels.Pagination pagination2 = this.page_;
            if (pagination2 == null || pagination2 == LivekitModels.Pagination.getDefaultInstance()) {
                this.page_ = pagination;
            } else {
                this.page_ = (LivekitModels.Pagination) ((LivekitModels.Pagination.Builder) LivekitModels.Pagination.newBuilder(this.page_).v(pagination)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListSIPTrunkRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPTrunkRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListSIPTrunkRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setPage(LivekitModels.Pagination pagination) {
            pagination.getClass();
            this.page_ = pagination;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListSIPTrunkRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\t", new Object[]{ap.a(411821081)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListSIPTrunkRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListSIPTrunkRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.Pagination getPage() {
            LivekitModels.Pagination pagination = this.page_;
            return pagination == null ? LivekitModels.Pagination.getDefaultInstance() : pagination;
        }

        public boolean hasPage() {
            return this.page_ != null;
        }

        public static Builder newBuilder(ListSIPTrunkRequest listSIPTrunkRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listSIPTrunkRequest);
        }

        public static ListSIPTrunkRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPTrunkRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListSIPTrunkRequest parseFrom(ByteString byteString) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListSIPTrunkRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListSIPTrunkRequest parseFrom(byte[] bArr) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListSIPTrunkRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListSIPTrunkRequest parseFrom(InputStream inputStream) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPTrunkRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPTrunkRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListSIPTrunkRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public interface ListSIPTrunkRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public static final class ListSIPTrunkResponse extends GeneratedMessageLite<ListSIPTrunkResponse, Builder> implements ListSIPTrunkResponseOrBuilder {
        private static final ListSIPTrunkResponse DEFAULT_INSTANCE;
        public static final int ITEMS_FIELD_NUMBER = 1;
        private static volatile Parser<ListSIPTrunkResponse> PARSER;
        private Internal.ProtobufList<SIPTrunkInfo> items_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListSIPTrunkResponse, Builder> implements ListSIPTrunkResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListSIPTrunkResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListSIPTrunkResponse listSIPTrunkResponse = new ListSIPTrunkResponse();
            DEFAULT_INSTANCE = listSIPTrunkResponse;
            GeneratedMessageLite.registerDefaultInstance(ListSIPTrunkResponse.class, listSIPTrunkResponse);
        }

        private ListSIPTrunkResponse() {
        }

        private void addAllItems(Iterable<? extends SIPTrunkInfo> iterable) {
            ensureItemsIsMutable();
            AbstractMessageLite.addAll(iterable, this.items_);
        }

        private void addItems(SIPTrunkInfo sIPTrunkInfo) {
            sIPTrunkInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(sIPTrunkInfo);
        }

        private void clearItems() {
            this.items_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureItemsIsMutable() {
            Internal.ProtobufList<SIPTrunkInfo> protobufList = this.items_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.items_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListSIPTrunkResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListSIPTrunkResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPTrunkResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListSIPTrunkResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeItems(int i) {
            ensureItemsIsMutable();
            this.items_.remove(i);
        }

        private void setItems(int i, SIPTrunkInfo sIPTrunkInfo) {
            sIPTrunkInfo.getClass();
            ensureItemsIsMutable();
            this.items_.set(i, sIPTrunkInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListSIPTrunkResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1540134665), SIPTrunkInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListSIPTrunkResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListSIPTrunkResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SIPTrunkInfo getItems(int i) {
            return (SIPTrunkInfo) this.items_.get(i);
        }

        public int getItemsCount() {
            return this.items_.size();
        }

        public List<SIPTrunkInfo> getItemsList() {
            return this.items_;
        }

        public SIPTrunkInfoOrBuilder getItemsOrBuilder(int i) {
            return (SIPTrunkInfoOrBuilder) this.items_.get(i);
        }

        public List<? extends SIPTrunkInfoOrBuilder> getItemsOrBuilderList() {
            return this.items_;
        }

        public static Builder newBuilder(ListSIPTrunkResponse listSIPTrunkResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listSIPTrunkResponse);
        }

        public static ListSIPTrunkResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPTrunkResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListSIPTrunkResponse parseFrom(ByteString byteString) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addItems(int i, SIPTrunkInfo sIPTrunkInfo) {
            sIPTrunkInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(i, sIPTrunkInfo);
        }

        public static ListSIPTrunkResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListSIPTrunkResponse parseFrom(byte[] bArr) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListSIPTrunkResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListSIPTrunkResponse parseFrom(InputStream inputStream) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListSIPTrunkResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListSIPTrunkResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListSIPTrunkResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListSIPTrunkResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public interface ListSIPTrunkResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SIPCallDirection implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<SIPCallDirection>() { // from class: livekit.LivekitSip.SIPCallDirection.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SIPCallDirection findValueByNumber(int i) {
                return SIPCallDirection.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SIPCallDirectionVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SIPCallDirectionVerifier();

            private SIPCallDirectionVerifier() {
            }

            public boolean isInRange(int i) {
                return SIPCallDirection.b(i) != null;
            }
        }

        SIPCallDirection(int i) {
            this.a = i;
        }

        public static SIPCallDirection b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPCallInfo extends GeneratedMessageLite<SIPCallInfo, Builder> implements SIPCallInfoOrBuilder {
        public static final int AUDIO_CODEC_FIELD_NUMBER = 20;
        public static final int CALL_CONTEXT_FIELD_NUMBER = 26;
        public static final int CALL_DIRECTION_FIELD_NUMBER = 15;
        public static final int CALL_ID_FIELD_NUMBER = 1;
        public static final int CALL_STATUS_CODE_FIELD_NUMBER = 19;
        public static final int CALL_STATUS_FIELD_NUMBER = 8;
        public static final int CREATED_AT_FIELD_NUMBER = 9;
        public static final int CREATED_AT_NS_FIELD_NUMBER = 22;
        private static final SIPCallInfo DEFAULT_INSTANCE;
        public static final int DISCONNECT_REASON_FIELD_NUMBER = 12;
        public static final int DISPATCH_RULE_ID_FIELD_NUMBER = 16;
        public static final int ENABLED_FEATURES_FIELD_NUMBER = 14;
        public static final int ENDED_AT_FIELD_NUMBER = 11;
        public static final int ENDED_AT_NS_FIELD_NUMBER = 24;
        public static final int ERROR_FIELD_NUMBER = 13;
        public static final int FROM_URI_FIELD_NUMBER = 6;
        public static final int MEDIA_ENCRYPTION_FIELD_NUMBER = 21;
        private static volatile Parser<SIPCallInfo> PARSER = null;
        public static final int PARTICIPANT_ATTRIBUTES_FIELD_NUMBER = 18;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 5;
        public static final int PCAP_FILE_LINK_FIELD_NUMBER = 25;
        public static final int REGION_FIELD_NUMBER = 17;
        public static final int ROOM_ID_FIELD_NUMBER = 4;
        public static final int ROOM_NAME_FIELD_NUMBER = 3;
        public static final int STARTED_AT_FIELD_NUMBER = 10;
        public static final int STARTED_AT_NS_FIELD_NUMBER = 23;
        public static final int TO_URI_FIELD_NUMBER = 7;
        public static final int TRUNK_ID_FIELD_NUMBER = 2;
        private static final Internal.ListAdapter.Converter<Integer, SIPFeature> enabledFeatures_converter_ = new Internal.ListAdapter.Converter<Integer, SIPFeature>() { // from class: livekit.LivekitSip.SIPCallInfo.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SIPFeature convert(Integer num) {
                SIPFeature sIPFeatureB = SIPFeature.b(num.intValue());
                return sIPFeatureB == null ? SIPFeature.d : sIPFeatureB;
            }
        };
        private String audioCodec_;
        private Internal.ProtobufList<Any> callContext_;
        private int callDirection_;
        private String callId_;
        private SIPStatus callStatusCode_;
        private int callStatus_;
        private long createdAtNs_;
        private long createdAt_;
        private int disconnectReason_;
        private String dispatchRuleId_;
        private int enabledFeaturesMemoizedSerializedSize;
        private Internal.IntList enabledFeatures_;
        private long endedAtNs_;
        private long endedAt_;
        private String error_;
        private SIPUri fromUri_;
        private String mediaEncryption_;
        private MapFieldLite<String, String> participantAttributes_ = MapFieldLite.f();
        private String participantIdentity_;
        private String pcapFileLink_;
        private String region_;
        private String roomId_;
        private String roomName_;
        private long startedAtNs_;
        private long startedAt_;
        private SIPUri toUri_;
        private String trunkId_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPCallInfo, Builder> implements SIPCallInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPCallInfo.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class ParticipantAttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(1085438112);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private ParticipantAttributesDefaultEntryHolder() {
            }
        }

        static {
            SIPCallInfo sIPCallInfo = new SIPCallInfo();
            DEFAULT_INSTANCE = sIPCallInfo;
            GeneratedMessageLite.registerDefaultInstance(SIPCallInfo.class, sIPCallInfo);
        }

        private SIPCallInfo() {
            String strA = ap.a(679124616);
            this.callId_ = strA;
            this.trunkId_ = strA;
            this.dispatchRuleId_ = strA;
            this.region_ = strA;
            this.roomName_ = strA;
            this.roomId_ = strA;
            this.participantIdentity_ = strA;
            this.enabledFeatures_ = GeneratedMessageLite.emptyIntList();
            this.error_ = strA;
            this.audioCodec_ = strA;
            this.mediaEncryption_ = strA;
            this.pcapFileLink_ = strA;
            this.callContext_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllCallContext(Iterable<? extends Any> iterable) {
            ensureCallContextIsMutable();
            AbstractMessageLite.addAll(iterable, this.callContext_);
        }

        private void addAllEnabledFeatures(Iterable<? extends SIPFeature> iterable) {
            ensureEnabledFeaturesIsMutable();
            Iterator<? extends SIPFeature> it = iterable.iterator();
            while (it.hasNext()) {
                this.enabledFeatures_.addInt(it.next().getNumber());
            }
        }

        private void addAllEnabledFeaturesValue(Iterable<Integer> iterable) {
            ensureEnabledFeaturesIsMutable();
            Iterator<Integer> it = iterable.iterator();
            while (it.hasNext()) {
                this.enabledFeatures_.addInt(it.next().intValue());
            }
        }

        private void addCallContext(Any any) {
            any.getClass();
            ensureCallContextIsMutable();
            this.callContext_.add(any);
        }

        private void addEnabledFeatures(SIPFeature sIPFeature) {
            sIPFeature.getClass();
            ensureEnabledFeaturesIsMutable();
            this.enabledFeatures_.addInt(sIPFeature.getNumber());
        }

        private void addEnabledFeaturesValue(int i) {
            ensureEnabledFeaturesIsMutable();
            this.enabledFeatures_.addInt(i);
        }

        private void clearAudioCodec() {
            this.audioCodec_ = getDefaultInstance().getAudioCodec();
        }

        private void clearCallContext() {
            this.callContext_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearCallDirection() {
            this.callDirection_ = 0;
        }

        private void clearCallId() {
            this.callId_ = getDefaultInstance().getCallId();
        }

        private void clearCallStatus() {
            this.callStatus_ = 0;
        }

        private void clearCallStatusCode() {
            this.callStatusCode_ = null;
        }

        private void clearCreatedAt() {
            this.createdAt_ = 0L;
        }

        private void clearCreatedAtNs() {
            this.createdAtNs_ = 0L;
        }

        private void clearDisconnectReason() {
            this.disconnectReason_ = 0;
        }

        private void clearDispatchRuleId() {
            this.dispatchRuleId_ = getDefaultInstance().getDispatchRuleId();
        }

        private void clearEnabledFeatures() {
            this.enabledFeatures_ = GeneratedMessageLite.emptyIntList();
        }

        private void clearEndedAt() {
            this.endedAt_ = 0L;
        }

        private void clearEndedAtNs() {
            this.endedAtNs_ = 0L;
        }

        private void clearError() {
            this.error_ = getDefaultInstance().getError();
        }

        private void clearFromUri() {
            this.fromUri_ = null;
        }

        private void clearMediaEncryption() {
            this.mediaEncryption_ = getDefaultInstance().getMediaEncryption();
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearPcapFileLink() {
            this.pcapFileLink_ = getDefaultInstance().getPcapFileLink();
        }

        private void clearRegion() {
            this.region_ = getDefaultInstance().getRegion();
        }

        private void clearRoomId() {
            this.roomId_ = getDefaultInstance().getRoomId();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearStartedAt() {
            this.startedAt_ = 0L;
        }

        private void clearStartedAtNs() {
            this.startedAtNs_ = 0L;
        }

        private void clearToUri() {
            this.toUri_ = null;
        }

        private void clearTrunkId() {
            this.trunkId_ = getDefaultInstance().getTrunkId();
        }

        private void ensureCallContextIsMutable() {
            Internal.ProtobufList<Any> protobufList = this.callContext_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.callContext_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureEnabledFeaturesIsMutable() {
            Internal.IntList intList = this.enabledFeatures_;
            if (intList.isModifiable()) {
                return;
            }
            this.enabledFeatures_ = GeneratedMessageLite.mutableCopy(intList);
        }

        public static SIPCallInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableParticipantAttributesMap() {
            return internalGetMutableParticipantAttributes();
        }

        private MapFieldLite<String, String> internalGetMutableParticipantAttributes() {
            if (!this.participantAttributes_.k()) {
                this.participantAttributes_ = this.participantAttributes_.n();
            }
            return this.participantAttributes_;
        }

        private MapFieldLite<String, String> internalGetParticipantAttributes() {
            return this.participantAttributes_;
        }

        private void mergeCallStatusCode(SIPStatus sIPStatus) {
            sIPStatus.getClass();
            SIPStatus sIPStatus2 = this.callStatusCode_;
            if (sIPStatus2 == null || sIPStatus2 == SIPStatus.getDefaultInstance()) {
                this.callStatusCode_ = sIPStatus;
            } else {
                this.callStatusCode_ = (SIPStatus) ((SIPStatus.Builder) SIPStatus.newBuilder(this.callStatusCode_).v(sIPStatus)).o();
            }
        }

        private void mergeFromUri(SIPUri sIPUri) {
            sIPUri.getClass();
            SIPUri sIPUri2 = this.fromUri_;
            if (sIPUri2 == null || sIPUri2 == SIPUri.getDefaultInstance()) {
                this.fromUri_ = sIPUri;
            } else {
                this.fromUri_ = (SIPUri) ((SIPUri.Builder) SIPUri.newBuilder(this.fromUri_).v(sIPUri)).o();
            }
        }

        private void mergeToUri(SIPUri sIPUri) {
            sIPUri.getClass();
            SIPUri sIPUri2 = this.toUri_;
            if (sIPUri2 == null || sIPUri2 == SIPUri.getDefaultInstance()) {
                this.toUri_ = sIPUri;
            } else {
                this.toUri_ = (SIPUri) ((SIPUri.Builder) SIPUri.newBuilder(this.toUri_).v(sIPUri)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPCallInfo parseDelimitedFrom(InputStream inputStream) {
            return (SIPCallInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPCallInfo parseFrom(ByteBuffer byteBuffer) {
            return (SIPCallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPCallInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeCallContext(int i) {
            ensureCallContextIsMutable();
            this.callContext_.remove(i);
        }

        private void setAudioCodec(String str) {
            str.getClass();
            this.audioCodec_ = str;
        }

        private void setAudioCodecBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.audioCodec_ = byteString.L();
        }

        private void setCallContext(int i, Any any) {
            any.getClass();
            ensureCallContextIsMutable();
            this.callContext_.set(i, any);
        }

        private void setCallDirection(SIPCallDirection sIPCallDirection) {
            this.callDirection_ = sIPCallDirection.getNumber();
        }

        private void setCallDirectionValue(int i) {
            this.callDirection_ = i;
        }

        private void setCallId(String str) {
            str.getClass();
            this.callId_ = str;
        }

        private void setCallIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.callId_ = byteString.L();
        }

        private void setCallStatus(SIPCallStatus sIPCallStatus) {
            this.callStatus_ = sIPCallStatus.getNumber();
        }

        private void setCallStatusCode(SIPStatus sIPStatus) {
            sIPStatus.getClass();
            this.callStatusCode_ = sIPStatus;
        }

        private void setCallStatusValue(int i) {
            this.callStatus_ = i;
        }

        private void setCreatedAt(long j) {
            this.createdAt_ = j;
        }

        private void setCreatedAtNs(long j) {
            this.createdAtNs_ = j;
        }

        private void setDisconnectReason(LivekitModels.DisconnectReason disconnectReason) {
            this.disconnectReason_ = disconnectReason.getNumber();
        }

        private void setDisconnectReasonValue(int i) {
            this.disconnectReason_ = i;
        }

        private void setDispatchRuleId(String str) {
            str.getClass();
            this.dispatchRuleId_ = str;
        }

        private void setDispatchRuleIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.dispatchRuleId_ = byteString.L();
        }

        private void setEnabledFeatures(int i, SIPFeature sIPFeature) {
            sIPFeature.getClass();
            ensureEnabledFeaturesIsMutable();
            this.enabledFeatures_.setInt(i, sIPFeature.getNumber());
        }

        private void setEnabledFeaturesValue(int i, int i2) {
            ensureEnabledFeaturesIsMutable();
            this.enabledFeatures_.setInt(i, i2);
        }

        private void setEndedAt(long j) {
            this.endedAt_ = j;
        }

        private void setEndedAtNs(long j) {
            this.endedAtNs_ = j;
        }

        private void setError(String str) {
            str.getClass();
            this.error_ = str;
        }

        private void setErrorBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.error_ = byteString.L();
        }

        private void setFromUri(SIPUri sIPUri) {
            sIPUri.getClass();
            this.fromUri_ = sIPUri;
        }

        private void setMediaEncryption(String str) {
            str.getClass();
            this.mediaEncryption_ = str;
        }

        private void setMediaEncryptionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.mediaEncryption_ = byteString.L();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setPcapFileLink(String str) {
            str.getClass();
            this.pcapFileLink_ = str;
        }

        private void setPcapFileLinkBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.pcapFileLink_ = byteString.L();
        }

        private void setRegion(String str) {
            str.getClass();
            this.region_ = str;
        }

        private void setRegionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.region_ = byteString.L();
        }

        private void setRoomId(String str) {
            str.getClass();
            this.roomId_ = str;
        }

        private void setRoomIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomId_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setStartedAt(long j) {
            this.startedAt_ = j;
        }

        private void setStartedAtNs(long j) {
            this.startedAtNs_ = j;
        }

        private void setToUri(SIPUri sIPUri) {
            sIPUri.getClass();
            this.toUri_ = sIPUri;
        }

        private void setTrunkId(String str) {
            str.getClass();
            this.trunkId_ = str;
        }

        private void setTrunkIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trunkId_ = byteString.L();
        }

        public boolean containsParticipantAttributes(String str) {
            str.getClass();
            return internalGetParticipantAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new SIPCallInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u001a\u0000\u0000\u0001\u001a\u001a\u0001\u0002\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005Ȉ\u0006\t\u0007\t\b\f\t\u0002\n\u0002\u000b\u0002\f\f\rȈ\u000e,\u000f\f\u0010Ȉ\u0011Ȉ\u00122\u0013\t\u0014Ȉ\u0015Ȉ\u0016\u0002\u0017\u0002\u0018\u0002\u0019Ȉ\u001a\u001b", new Object[]{"callId_", "trunkId_", "roomName_", "roomId_", "participantIdentity_", "fromUri_", "toUri_", "callStatus_", "createdAt_", "startedAt_", "endedAt_", "disconnectReason_", "error_", "enabledFeatures_", "callDirection_", "dispatchRuleId_", "region_", "participantAttributes_", ParticipantAttributesDefaultEntryHolder.a, "callStatusCode_", "audioCodec_", "mediaEncryption_", "createdAtNs_", "startedAtNs_", "endedAtNs_", "pcapFileLink_", "callContext_", Any.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPCallInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPCallInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAudioCodec() {
            return this.audioCodec_;
        }

        public ByteString getAudioCodecBytes() {
            return ByteString.n(this.audioCodec_);
        }

        public Any getCallContext(int i) {
            return (Any) this.callContext_.get(i);
        }

        public int getCallContextCount() {
            return this.callContext_.size();
        }

        public List<Any> getCallContextList() {
            return this.callContext_;
        }

        public AnyOrBuilder getCallContextOrBuilder(int i) {
            return (AnyOrBuilder) this.callContext_.get(i);
        }

        public List<? extends AnyOrBuilder> getCallContextOrBuilderList() {
            return this.callContext_;
        }

        public SIPCallDirection getCallDirection() {
            SIPCallDirection sIPCallDirectionB = SIPCallDirection.b(this.callDirection_);
            return sIPCallDirectionB == null ? SIPCallDirection.e : sIPCallDirectionB;
        }

        public int getCallDirectionValue() {
            return this.callDirection_;
        }

        public String getCallId() {
            return this.callId_;
        }

        public ByteString getCallIdBytes() {
            return ByteString.n(this.callId_);
        }

        public SIPCallStatus getCallStatus() {
            SIPCallStatus sIPCallStatusB = SIPCallStatus.b(this.callStatus_);
            return sIPCallStatusB == null ? SIPCallStatus.g : sIPCallStatusB;
        }

        public SIPStatus getCallStatusCode() {
            SIPStatus sIPStatus = this.callStatusCode_;
            return sIPStatus == null ? SIPStatus.getDefaultInstance() : sIPStatus;
        }

        public int getCallStatusValue() {
            return this.callStatus_;
        }

        @Deprecated
        public long getCreatedAt() {
            return this.createdAt_;
        }

        public long getCreatedAtNs() {
            return this.createdAtNs_;
        }

        public LivekitModels.DisconnectReason getDisconnectReason() {
            LivekitModels.DisconnectReason disconnectReasonB = LivekitModels.DisconnectReason.b(this.disconnectReason_);
            return disconnectReasonB == null ? LivekitModels.DisconnectReason.r : disconnectReasonB;
        }

        public int getDisconnectReasonValue() {
            return this.disconnectReason_;
        }

        public String getDispatchRuleId() {
            return this.dispatchRuleId_;
        }

        public ByteString getDispatchRuleIdBytes() {
            return ByteString.n(this.dispatchRuleId_);
        }

        public SIPFeature getEnabledFeatures(int i) {
            SIPFeature sIPFeatureB = SIPFeature.b(this.enabledFeatures_.getInt(i));
            return sIPFeatureB == null ? SIPFeature.d : sIPFeatureB;
        }

        public int getEnabledFeaturesCount() {
            return this.enabledFeatures_.size();
        }

        public List<SIPFeature> getEnabledFeaturesList() {
            return new Internal.ListAdapter(this.enabledFeatures_, enabledFeatures_converter_);
        }

        public int getEnabledFeaturesValue(int i) {
            return this.enabledFeatures_.getInt(i);
        }

        public List<Integer> getEnabledFeaturesValueList() {
            return this.enabledFeatures_;
        }

        @Deprecated
        public long getEndedAt() {
            return this.endedAt_;
        }

        public long getEndedAtNs() {
            return this.endedAtNs_;
        }

        public String getError() {
            return this.error_;
        }

        public ByteString getErrorBytes() {
            return ByteString.n(this.error_);
        }

        public SIPUri getFromUri() {
            SIPUri sIPUri = this.fromUri_;
            return sIPUri == null ? SIPUri.getDefaultInstance() : sIPUri;
        }

        public String getMediaEncryption() {
            return this.mediaEncryption_;
        }

        public ByteString getMediaEncryptionBytes() {
            return ByteString.n(this.mediaEncryption_);
        }

        @Deprecated
        public Map<String, String> getParticipantAttributes() {
            return getParticipantAttributesMap();
        }

        public int getParticipantAttributesCount() {
            return internalGetParticipantAttributes().size();
        }

        public Map<String, String> getParticipantAttributesMap() {
            return Collections.unmodifiableMap(internalGetParticipantAttributes());
        }

        public String getParticipantAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetParticipantAttributes = internalGetParticipantAttributes();
            return mapFieldLiteInternalGetParticipantAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetParticipantAttributes.get(str) : str2;
        }

        public String getParticipantAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetParticipantAttributes = internalGetParticipantAttributes();
            if (mapFieldLiteInternalGetParticipantAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetParticipantAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getPcapFileLink() {
            return this.pcapFileLink_;
        }

        public ByteString getPcapFileLinkBytes() {
            return ByteString.n(this.pcapFileLink_);
        }

        public String getRegion() {
            return this.region_;
        }

        public ByteString getRegionBytes() {
            return ByteString.n(this.region_);
        }

        public String getRoomId() {
            return this.roomId_;
        }

        public ByteString getRoomIdBytes() {
            return ByteString.n(this.roomId_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        @Deprecated
        public long getStartedAt() {
            return this.startedAt_;
        }

        public long getStartedAtNs() {
            return this.startedAtNs_;
        }

        public SIPUri getToUri() {
            SIPUri sIPUri = this.toUri_;
            return sIPUri == null ? SIPUri.getDefaultInstance() : sIPUri;
        }

        public String getTrunkId() {
            return this.trunkId_;
        }

        public ByteString getTrunkIdBytes() {
            return ByteString.n(this.trunkId_);
        }

        public boolean hasCallStatusCode() {
            return this.callStatusCode_ != null;
        }

        public boolean hasFromUri() {
            return this.fromUri_ != null;
        }

        public boolean hasToUri() {
            return this.toUri_ != null;
        }

        public static Builder newBuilder(SIPCallInfo sIPCallInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPCallInfo);
        }

        public static SIPCallInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPCallInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPCallInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPCallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPCallInfo parseFrom(ByteString byteString) {
            return (SIPCallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addCallContext(int i, Any any) {
            any.getClass();
            ensureCallContextIsMutable();
            this.callContext_.add(i, any);
        }

        public static SIPCallInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPCallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPCallInfo parseFrom(byte[] bArr) {
            return (SIPCallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPCallInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPCallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPCallInfo parseFrom(InputStream inputStream) {
            return (SIPCallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPCallInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPCallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPCallInfo parseFrom(CodedInputStream codedInputStream) {
            return (SIPCallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPCallInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPCallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPCallInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SIPCallStatus implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(4),
        g(-1);

        private static final Internal.EnumLiteMap h = new Internal.EnumLiteMap<SIPCallStatus>() { // from class: livekit.LivekitSip.SIPCallStatus.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SIPCallStatus findValueByNumber(int i2) {
                return SIPCallStatus.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SIPCallStatusVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SIPCallStatusVerifier();

            private SIPCallStatusVerifier() {
            }

            public boolean isInRange(int i) {
                return SIPCallStatus.b(i) != null;
            }
        }

        SIPCallStatus(int i2) {
            this.a = i2;
        }

        public static SIPCallStatus b(int i2) {
            if (i2 == 0) {
                return b;
            }
            if (i2 == 1) {
                return c;
            }
            if (i2 == 2) {
                return d;
            }
            if (i2 == 3) {
                return e;
            }
            if (i2 != 4) {
                return null;
            }
            return f;
        }

        public final int getNumber() {
            if (this != g) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPDispatchRule extends GeneratedMessageLite<SIPDispatchRule, Builder> implements SIPDispatchRuleOrBuilder {
        private static final SIPDispatchRule DEFAULT_INSTANCE;
        public static final int DISPATCH_RULE_CALLEE_FIELD_NUMBER = 3;
        public static final int DISPATCH_RULE_DIRECT_FIELD_NUMBER = 1;
        public static final int DISPATCH_RULE_INDIVIDUAL_FIELD_NUMBER = 2;
        private static volatile Parser<SIPDispatchRule> PARSER;
        private int ruleCase_ = 0;
        private Object rule_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPDispatchRule, Builder> implements SIPDispatchRuleOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPDispatchRule.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum RuleCase {
            b(1),
            c(2),
            d(3),
            e(0);

            private final int a;

            RuleCase(int i) {
                this.a = i;
            }

            public static RuleCase b(int i) {
                if (i == 0) {
                    return e;
                }
                if (i == 1) {
                    return b;
                }
                if (i == 2) {
                    return c;
                }
                if (i != 3) {
                    return null;
                }
                return d;
            }
        }

        static {
            SIPDispatchRule sIPDispatchRule = new SIPDispatchRule();
            DEFAULT_INSTANCE = sIPDispatchRule;
            GeneratedMessageLite.registerDefaultInstance(SIPDispatchRule.class, sIPDispatchRule);
        }

        private SIPDispatchRule() {
        }

        private void clearDispatchRuleCallee() {
            if (this.ruleCase_ == 3) {
                this.ruleCase_ = 0;
                this.rule_ = null;
            }
        }

        private void clearDispatchRuleDirect() {
            if (this.ruleCase_ == 1) {
                this.ruleCase_ = 0;
                this.rule_ = null;
            }
        }

        private void clearDispatchRuleIndividual() {
            if (this.ruleCase_ == 2) {
                this.ruleCase_ = 0;
                this.rule_ = null;
            }
        }

        private void clearRule() {
            this.ruleCase_ = 0;
            this.rule_ = null;
        }

        public static SIPDispatchRule getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeDispatchRuleCallee(SIPDispatchRuleCallee sIPDispatchRuleCallee) {
            sIPDispatchRuleCallee.getClass();
            if (this.ruleCase_ != 3 || this.rule_ == SIPDispatchRuleCallee.getDefaultInstance()) {
                this.rule_ = sIPDispatchRuleCallee;
            } else {
                this.rule_ = ((SIPDispatchRuleCallee.Builder) SIPDispatchRuleCallee.newBuilder((SIPDispatchRuleCallee) this.rule_).v(sIPDispatchRuleCallee)).o();
            }
            this.ruleCase_ = 3;
        }

        private void mergeDispatchRuleDirect(SIPDispatchRuleDirect sIPDispatchRuleDirect) {
            sIPDispatchRuleDirect.getClass();
            if (this.ruleCase_ != 1 || this.rule_ == SIPDispatchRuleDirect.getDefaultInstance()) {
                this.rule_ = sIPDispatchRuleDirect;
            } else {
                this.rule_ = ((SIPDispatchRuleDirect.Builder) SIPDispatchRuleDirect.newBuilder((SIPDispatchRuleDirect) this.rule_).v(sIPDispatchRuleDirect)).o();
            }
            this.ruleCase_ = 1;
        }

        private void mergeDispatchRuleIndividual(SIPDispatchRuleIndividual sIPDispatchRuleIndividual) {
            sIPDispatchRuleIndividual.getClass();
            if (this.ruleCase_ != 2 || this.rule_ == SIPDispatchRuleIndividual.getDefaultInstance()) {
                this.rule_ = sIPDispatchRuleIndividual;
            } else {
                this.rule_ = ((SIPDispatchRuleIndividual.Builder) SIPDispatchRuleIndividual.newBuilder((SIPDispatchRuleIndividual) this.rule_).v(sIPDispatchRuleIndividual)).o();
            }
            this.ruleCase_ = 2;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPDispatchRule parseDelimitedFrom(InputStream inputStream) {
            return (SIPDispatchRule) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRule parseFrom(ByteBuffer byteBuffer) {
            return (SIPDispatchRule) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPDispatchRule> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDispatchRuleCallee(SIPDispatchRuleCallee sIPDispatchRuleCallee) {
            sIPDispatchRuleCallee.getClass();
            this.rule_ = sIPDispatchRuleCallee;
            this.ruleCase_ = 3;
        }

        private void setDispatchRuleDirect(SIPDispatchRuleDirect sIPDispatchRuleDirect) {
            sIPDispatchRuleDirect.getClass();
            this.rule_ = sIPDispatchRuleDirect;
            this.ruleCase_ = 1;
        }

        private void setDispatchRuleIndividual(SIPDispatchRuleIndividual sIPDispatchRuleIndividual) {
            sIPDispatchRuleIndividual.getClass();
            this.rule_ = sIPDispatchRuleIndividual;
            this.ruleCase_ = 2;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPDispatchRule();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0001\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001<\u0000\u0002<\u0000\u0003<\u0000", new Object[]{ap.a(1941073283), ap.a(1293698427), SIPDispatchRuleDirect.class, SIPDispatchRuleIndividual.class, SIPDispatchRuleCallee.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPDispatchRule> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPDispatchRule.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SIPDispatchRuleCallee getDispatchRuleCallee() {
            return this.ruleCase_ == 3 ? (SIPDispatchRuleCallee) this.rule_ : SIPDispatchRuleCallee.getDefaultInstance();
        }

        public SIPDispatchRuleDirect getDispatchRuleDirect() {
            return this.ruleCase_ == 1 ? (SIPDispatchRuleDirect) this.rule_ : SIPDispatchRuleDirect.getDefaultInstance();
        }

        public SIPDispatchRuleIndividual getDispatchRuleIndividual() {
            return this.ruleCase_ == 2 ? (SIPDispatchRuleIndividual) this.rule_ : SIPDispatchRuleIndividual.getDefaultInstance();
        }

        public RuleCase getRuleCase() {
            return RuleCase.b(this.ruleCase_);
        }

        public boolean hasDispatchRuleCallee() {
            return this.ruleCase_ == 3;
        }

        public boolean hasDispatchRuleDirect() {
            return this.ruleCase_ == 1;
        }

        public boolean hasDispatchRuleIndividual() {
            return this.ruleCase_ == 2;
        }

        public static Builder newBuilder(SIPDispatchRule sIPDispatchRule) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPDispatchRule);
        }

        public static SIPDispatchRule parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRule) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRule parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRule) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPDispatchRule parseFrom(ByteString byteString) {
            return (SIPDispatchRule) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPDispatchRule parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRule) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPDispatchRule parseFrom(byte[] bArr) {
            return (SIPDispatchRule) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPDispatchRule parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRule) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPDispatchRule parseFrom(InputStream inputStream) {
            return (SIPDispatchRule) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRule parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRule) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRule parseFrom(CodedInputStream codedInputStream) {
            return (SIPDispatchRule) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPDispatchRule parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRule) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPDispatchRuleCallee extends GeneratedMessageLite<SIPDispatchRuleCallee, Builder> implements SIPDispatchRuleCalleeOrBuilder {
        private static final SIPDispatchRuleCallee DEFAULT_INSTANCE;
        private static volatile Parser<SIPDispatchRuleCallee> PARSER = null;
        public static final int PIN_FIELD_NUMBER = 2;
        public static final int RANDOMIZE_FIELD_NUMBER = 3;
        public static final int ROOM_PREFIX_FIELD_NUMBER = 1;
        private String pin_;
        private boolean randomize_;
        private String roomPrefix_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPDispatchRuleCallee, Builder> implements SIPDispatchRuleCalleeOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPDispatchRuleCallee.DEFAULT_INSTANCE);
            }
        }

        static {
            SIPDispatchRuleCallee sIPDispatchRuleCallee = new SIPDispatchRuleCallee();
            DEFAULT_INSTANCE = sIPDispatchRuleCallee;
            GeneratedMessageLite.registerDefaultInstance(SIPDispatchRuleCallee.class, sIPDispatchRuleCallee);
        }

        private SIPDispatchRuleCallee() {
            String strA = ap.a(1567119718);
            this.roomPrefix_ = strA;
            this.pin_ = strA;
        }

        private void clearPin() {
            this.pin_ = getDefaultInstance().getPin();
        }

        private void clearRandomize() {
            this.randomize_ = false;
        }

        private void clearRoomPrefix() {
            this.roomPrefix_ = getDefaultInstance().getRoomPrefix();
        }

        public static SIPDispatchRuleCallee getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPDispatchRuleCallee parseDelimitedFrom(InputStream inputStream) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRuleCallee parseFrom(ByteBuffer byteBuffer) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPDispatchRuleCallee> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setPin(String str) {
            str.getClass();
            this.pin_ = str;
        }

        private void setPinBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.pin_ = byteString.L();
        }

        private void setRandomize(boolean z) {
            this.randomize_ = z;
        }

        private void setRoomPrefix(String str) {
            str.getClass();
            this.roomPrefix_ = str;
        }

        private void setRoomPrefixBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomPrefix_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPDispatchRuleCallee();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\u0007", new Object[]{"roomPrefix_", "pin_", "randomize_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPDispatchRuleCallee> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPDispatchRuleCallee.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getPin() {
            return this.pin_;
        }

        public ByteString getPinBytes() {
            return ByteString.n(this.pin_);
        }

        public boolean getRandomize() {
            return this.randomize_;
        }

        public String getRoomPrefix() {
            return this.roomPrefix_;
        }

        public ByteString getRoomPrefixBytes() {
            return ByteString.n(this.roomPrefix_);
        }

        public static Builder newBuilder(SIPDispatchRuleCallee sIPDispatchRuleCallee) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPDispatchRuleCallee);
        }

        public static SIPDispatchRuleCallee parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRuleCallee parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPDispatchRuleCallee parseFrom(ByteString byteString) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPDispatchRuleCallee parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPDispatchRuleCallee parseFrom(byte[] bArr) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPDispatchRuleCallee parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPDispatchRuleCallee parseFrom(InputStream inputStream) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRuleCallee parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRuleCallee parseFrom(CodedInputStream codedInputStream) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPDispatchRuleCallee parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleCallee) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPDispatchRuleCalleeOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPDispatchRuleDirect extends GeneratedMessageLite<SIPDispatchRuleDirect, Builder> implements SIPDispatchRuleDirectOrBuilder {
        private static final SIPDispatchRuleDirect DEFAULT_INSTANCE;
        private static volatile Parser<SIPDispatchRuleDirect> PARSER = null;
        public static final int PIN_FIELD_NUMBER = 2;
        public static final int ROOM_NAME_FIELD_NUMBER = 1;
        private String pin_;
        private String roomName_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPDispatchRuleDirect, Builder> implements SIPDispatchRuleDirectOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPDispatchRuleDirect.DEFAULT_INSTANCE);
            }
        }

        static {
            SIPDispatchRuleDirect sIPDispatchRuleDirect = new SIPDispatchRuleDirect();
            DEFAULT_INSTANCE = sIPDispatchRuleDirect;
            GeneratedMessageLite.registerDefaultInstance(SIPDispatchRuleDirect.class, sIPDispatchRuleDirect);
        }

        private SIPDispatchRuleDirect() {
            String strA = ap.a(1715174051);
            this.roomName_ = strA;
            this.pin_ = strA;
        }

        private void clearPin() {
            this.pin_ = getDefaultInstance().getPin();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        public static SIPDispatchRuleDirect getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPDispatchRuleDirect parseDelimitedFrom(InputStream inputStream) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRuleDirect parseFrom(ByteBuffer byteBuffer) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPDispatchRuleDirect> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setPin(String str) {
            str.getClass();
            this.pin_ = str;
        }

        private void setPinBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.pin_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPDispatchRuleDirect();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"roomName_", "pin_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPDispatchRuleDirect> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPDispatchRuleDirect.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getPin() {
            return this.pin_;
        }

        public ByteString getPinBytes() {
            return ByteString.n(this.pin_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public static Builder newBuilder(SIPDispatchRuleDirect sIPDispatchRuleDirect) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPDispatchRuleDirect);
        }

        public static SIPDispatchRuleDirect parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRuleDirect parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPDispatchRuleDirect parseFrom(ByteString byteString) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPDispatchRuleDirect parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPDispatchRuleDirect parseFrom(byte[] bArr) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPDispatchRuleDirect parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPDispatchRuleDirect parseFrom(InputStream inputStream) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRuleDirect parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRuleDirect parseFrom(CodedInputStream codedInputStream) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPDispatchRuleDirect parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleDirect) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPDispatchRuleDirectOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPDispatchRuleIndividual extends GeneratedMessageLite<SIPDispatchRuleIndividual, Builder> implements SIPDispatchRuleIndividualOrBuilder {
        private static final SIPDispatchRuleIndividual DEFAULT_INSTANCE;
        private static volatile Parser<SIPDispatchRuleIndividual> PARSER = null;
        public static final int PIN_FIELD_NUMBER = 2;
        public static final int ROOM_PREFIX_FIELD_NUMBER = 1;
        private String pin_;
        private String roomPrefix_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPDispatchRuleIndividual, Builder> implements SIPDispatchRuleIndividualOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPDispatchRuleIndividual.DEFAULT_INSTANCE);
            }
        }

        static {
            SIPDispatchRuleIndividual sIPDispatchRuleIndividual = new SIPDispatchRuleIndividual();
            DEFAULT_INSTANCE = sIPDispatchRuleIndividual;
            GeneratedMessageLite.registerDefaultInstance(SIPDispatchRuleIndividual.class, sIPDispatchRuleIndividual);
        }

        private SIPDispatchRuleIndividual() {
            String strA = ap.a(460919143);
            this.roomPrefix_ = strA;
            this.pin_ = strA;
        }

        private void clearPin() {
            this.pin_ = getDefaultInstance().getPin();
        }

        private void clearRoomPrefix() {
            this.roomPrefix_ = getDefaultInstance().getRoomPrefix();
        }

        public static SIPDispatchRuleIndividual getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPDispatchRuleIndividual parseDelimitedFrom(InputStream inputStream) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRuleIndividual parseFrom(ByteBuffer byteBuffer) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPDispatchRuleIndividual> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setPin(String str) {
            str.getClass();
            this.pin_ = str;
        }

        private void setPinBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.pin_ = byteString.L();
        }

        private void setRoomPrefix(String str) {
            str.getClass();
            this.roomPrefix_ = str;
        }

        private void setRoomPrefixBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomPrefix_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPDispatchRuleIndividual();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"roomPrefix_", "pin_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPDispatchRuleIndividual> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPDispatchRuleIndividual.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getPin() {
            return this.pin_;
        }

        public ByteString getPinBytes() {
            return ByteString.n(this.pin_);
        }

        public String getRoomPrefix() {
            return this.roomPrefix_;
        }

        public ByteString getRoomPrefixBytes() {
            return ByteString.n(this.roomPrefix_);
        }

        public static Builder newBuilder(SIPDispatchRuleIndividual sIPDispatchRuleIndividual) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPDispatchRuleIndividual);
        }

        public static SIPDispatchRuleIndividual parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRuleIndividual parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPDispatchRuleIndividual parseFrom(ByteString byteString) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPDispatchRuleIndividual parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPDispatchRuleIndividual parseFrom(byte[] bArr) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPDispatchRuleIndividual parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPDispatchRuleIndividual parseFrom(InputStream inputStream) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRuleIndividual parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRuleIndividual parseFrom(CodedInputStream codedInputStream) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPDispatchRuleIndividual parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleIndividual) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPDispatchRuleIndividualOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPDispatchRuleInfo extends GeneratedMessageLite<SIPDispatchRuleInfo, Builder> implements SIPDispatchRuleInfoOrBuilder {
        public static final int ATTRIBUTES_FIELD_NUMBER = 8;
        private static final SIPDispatchRuleInfo DEFAULT_INSTANCE;
        public static final int HIDE_PHONE_NUMBER_FIELD_NUMBER = 4;
        public static final int INBOUND_NUMBERS_FIELD_NUMBER = 7;
        public static final int KRISP_ENABLED_FIELD_NUMBER = 11;
        public static final int MEDIA_ENCRYPTION_FIELD_NUMBER = 12;
        public static final int METADATA_FIELD_NUMBER = 6;
        public static final int NAME_FIELD_NUMBER = 5;
        private static volatile Parser<SIPDispatchRuleInfo> PARSER = null;
        public static final int ROOM_CONFIG_FIELD_NUMBER = 10;
        public static final int ROOM_PRESET_FIELD_NUMBER = 9;
        public static final int RULE_FIELD_NUMBER = 2;
        public static final int SIP_DISPATCH_RULE_ID_FIELD_NUMBER = 1;
        public static final int TRUNK_IDS_FIELD_NUMBER = 3;
        private MapFieldLite<String, String> attributes_ = MapFieldLite.f();
        private boolean hidePhoneNumber_;
        private Internal.ProtobufList<String> inboundNumbers_;
        private boolean krispEnabled_;
        private int mediaEncryption_;
        private String metadata_;
        private String name_;
        private LivekitRoom.RoomConfiguration roomConfig_;
        private String roomPreset_;
        private SIPDispatchRule rule_;
        private String sipDispatchRuleId_;
        private Internal.ProtobufList<String> trunkIds_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(941318635);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private AttributesDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPDispatchRuleInfo, Builder> implements SIPDispatchRuleInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPDispatchRuleInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            SIPDispatchRuleInfo sIPDispatchRuleInfo = new SIPDispatchRuleInfo();
            DEFAULT_INSTANCE = sIPDispatchRuleInfo;
            GeneratedMessageLite.registerDefaultInstance(SIPDispatchRuleInfo.class, sIPDispatchRuleInfo);
        }

        private SIPDispatchRuleInfo() {
            String strA = ap.a(1335356592);
            this.sipDispatchRuleId_ = strA;
            this.trunkIds_ = GeneratedMessageLite.emptyProtobufList();
            this.inboundNumbers_ = GeneratedMessageLite.emptyProtobufList();
            this.name_ = strA;
            this.metadata_ = strA;
            this.roomPreset_ = strA;
        }

        private void addAllInboundNumbers(Iterable<String> iterable) {
            ensureInboundNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.inboundNumbers_);
        }

        private void addAllTrunkIds(Iterable<String> iterable) {
            ensureTrunkIdsIsMutable();
            AbstractMessageLite.addAll(iterable, this.trunkIds_);
        }

        private void addInboundNumbers(String str) {
            str.getClass();
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.add(str);
        }

        private void addInboundNumbersBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.add(byteString.L());
        }

        private void addTrunkIds(String str) {
            str.getClass();
            ensureTrunkIdsIsMutable();
            this.trunkIds_.add(str);
        }

        private void addTrunkIdsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureTrunkIdsIsMutable();
            this.trunkIds_.add(byteString.L());
        }

        private void clearHidePhoneNumber() {
            this.hidePhoneNumber_ = false;
        }

        private void clearInboundNumbers() {
            this.inboundNumbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearKrispEnabled() {
            this.krispEnabled_ = false;
        }

        private void clearMediaEncryption() {
            this.mediaEncryption_ = 0;
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearRoomConfig() {
            this.roomConfig_ = null;
        }

        private void clearRoomPreset() {
            this.roomPreset_ = getDefaultInstance().getRoomPreset();
        }

        private void clearRule() {
            this.rule_ = null;
        }

        private void clearSipDispatchRuleId() {
            this.sipDispatchRuleId_ = getDefaultInstance().getSipDispatchRuleId();
        }

        private void clearTrunkIds() {
            this.trunkIds_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureInboundNumbersIsMutable() {
            Internal.ProtobufList<String> protobufList = this.inboundNumbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.inboundNumbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureTrunkIdsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.trunkIds_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trunkIds_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SIPDispatchRuleInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableAttributesMap() {
            return internalGetMutableAttributes();
        }

        private MapFieldLite<String, String> internalGetAttributes() {
            return this.attributes_;
        }

        private MapFieldLite<String, String> internalGetMutableAttributes() {
            if (!this.attributes_.k()) {
                this.attributes_ = this.attributes_.n();
            }
            return this.attributes_;
        }

        private void mergeRoomConfig(LivekitRoom.RoomConfiguration roomConfiguration) {
            roomConfiguration.getClass();
            LivekitRoom.RoomConfiguration roomConfiguration2 = this.roomConfig_;
            if (roomConfiguration2 == null || roomConfiguration2 == LivekitRoom.RoomConfiguration.getDefaultInstance()) {
                this.roomConfig_ = roomConfiguration;
            } else {
                this.roomConfig_ = (LivekitRoom.RoomConfiguration) ((LivekitRoom.RoomConfiguration.Builder) LivekitRoom.RoomConfiguration.newBuilder(this.roomConfig_).v(roomConfiguration)).o();
            }
        }

        private void mergeRule(SIPDispatchRule sIPDispatchRule) {
            sIPDispatchRule.getClass();
            SIPDispatchRule sIPDispatchRule2 = this.rule_;
            if (sIPDispatchRule2 == null || sIPDispatchRule2 == SIPDispatchRule.getDefaultInstance()) {
                this.rule_ = sIPDispatchRule;
            } else {
                this.rule_ = (SIPDispatchRule) ((SIPDispatchRule.Builder) SIPDispatchRule.newBuilder(this.rule_).v(sIPDispatchRule)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPDispatchRuleInfo parseDelimitedFrom(InputStream inputStream) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRuleInfo parseFrom(ByteBuffer byteBuffer) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPDispatchRuleInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setHidePhoneNumber(boolean z) {
            this.hidePhoneNumber_ = z;
        }

        private void setInboundNumbers(int i, String str) {
            str.getClass();
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.set(i, str);
        }

        private void setKrispEnabled(boolean z) {
            this.krispEnabled_ = z;
        }

        private void setMediaEncryption(SIPMediaEncryption sIPMediaEncryption) {
            this.mediaEncryption_ = sIPMediaEncryption.getNumber();
        }

        private void setMediaEncryptionValue(int i) {
            this.mediaEncryption_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setRoomConfig(LivekitRoom.RoomConfiguration roomConfiguration) {
            roomConfiguration.getClass();
            this.roomConfig_ = roomConfiguration;
        }

        private void setRoomPreset(String str) {
            str.getClass();
            this.roomPreset_ = str;
        }

        private void setRoomPresetBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomPreset_ = byteString.L();
        }

        private void setRule(SIPDispatchRule sIPDispatchRule) {
            sIPDispatchRule.getClass();
            this.rule_ = sIPDispatchRule;
        }

        private void setSipDispatchRuleId(String str) {
            str.getClass();
            this.sipDispatchRuleId_ = str;
        }

        private void setSipDispatchRuleIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipDispatchRuleId_ = byteString.L();
        }

        private void setTrunkIds(int i, String str) {
            str.getClass();
            ensureTrunkIdsIsMutable();
            this.trunkIds_.set(i, str);
        }

        public boolean containsAttributes(String str) {
            str.getClass();
            return internalGetAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPDispatchRuleInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\f\u0000\u0000\u0001\f\f\u0001\u0002\u0000\u0001Ȉ\u0002\t\u0003Ț\u0004\u0007\u0005Ȉ\u0006Ȉ\u0007Ț\b2\tȈ\n\t\u000b\u0007\f\f", new Object[]{"sipDispatchRuleId_", "rule_", "trunkIds_", "hidePhoneNumber_", "name_", "metadata_", "inboundNumbers_", "attributes_", AttributesDefaultEntryHolder.a, "roomPreset_", "roomConfig_", "krispEnabled_", "mediaEncryption_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPDispatchRuleInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPDispatchRuleInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public Map<String, String> getAttributes() {
            return getAttributesMap();
        }

        public int getAttributesCount() {
            return internalGetAttributes().size();
        }

        public Map<String, String> getAttributesMap() {
            return Collections.unmodifiableMap(internalGetAttributes());
        }

        public String getAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            return mapFieldLiteInternalGetAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetAttributes.get(str) : str2;
        }

        public String getAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            if (mapFieldLiteInternalGetAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public boolean getHidePhoneNumber() {
            return this.hidePhoneNumber_;
        }

        public String getInboundNumbers(int i) {
            return (String) this.inboundNumbers_.get(i);
        }

        public ByteString getInboundNumbersBytes(int i) {
            return ByteString.n((String) this.inboundNumbers_.get(i));
        }

        public int getInboundNumbersCount() {
            return this.inboundNumbers_.size();
        }

        public List<String> getInboundNumbersList() {
            return this.inboundNumbers_;
        }

        public boolean getKrispEnabled() {
            return this.krispEnabled_;
        }

        public SIPMediaEncryption getMediaEncryption() {
            SIPMediaEncryption sIPMediaEncryptionB = SIPMediaEncryption.b(this.mediaEncryption_);
            return sIPMediaEncryptionB == null ? SIPMediaEncryption.e : sIPMediaEncryptionB;
        }

        public int getMediaEncryptionValue() {
            return this.mediaEncryption_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public LivekitRoom.RoomConfiguration getRoomConfig() {
            LivekitRoom.RoomConfiguration roomConfiguration = this.roomConfig_;
            return roomConfiguration == null ? LivekitRoom.RoomConfiguration.getDefaultInstance() : roomConfiguration;
        }

        public String getRoomPreset() {
            return this.roomPreset_;
        }

        public ByteString getRoomPresetBytes() {
            return ByteString.n(this.roomPreset_);
        }

        public SIPDispatchRule getRule() {
            SIPDispatchRule sIPDispatchRule = this.rule_;
            return sIPDispatchRule == null ? SIPDispatchRule.getDefaultInstance() : sIPDispatchRule;
        }

        public String getSipDispatchRuleId() {
            return this.sipDispatchRuleId_;
        }

        public ByteString getSipDispatchRuleIdBytes() {
            return ByteString.n(this.sipDispatchRuleId_);
        }

        public String getTrunkIds(int i) {
            return (String) this.trunkIds_.get(i);
        }

        public ByteString getTrunkIdsBytes(int i) {
            return ByteString.n((String) this.trunkIds_.get(i));
        }

        public int getTrunkIdsCount() {
            return this.trunkIds_.size();
        }

        public List<String> getTrunkIdsList() {
            return this.trunkIds_;
        }

        public boolean hasRoomConfig() {
            return this.roomConfig_ != null;
        }

        public boolean hasRule() {
            return this.rule_ != null;
        }

        public static Builder newBuilder(SIPDispatchRuleInfo sIPDispatchRuleInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPDispatchRuleInfo);
        }

        public static SIPDispatchRuleInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRuleInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPDispatchRuleInfo parseFrom(ByteString byteString) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPDispatchRuleInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPDispatchRuleInfo parseFrom(byte[] bArr) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPDispatchRuleInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPDispatchRuleInfo parseFrom(InputStream inputStream) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRuleInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRuleInfo parseFrom(CodedInputStream codedInputStream) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPDispatchRuleInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPDispatchRuleInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPDispatchRuleOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPDispatchRuleUpdate extends GeneratedMessageLite<SIPDispatchRuleUpdate, Builder> implements SIPDispatchRuleUpdateOrBuilder {
        public static final int ATTRIBUTES_FIELD_NUMBER = 5;
        private static final SIPDispatchRuleUpdate DEFAULT_INSTANCE;
        public static final int MEDIA_ENCRYPTION_FIELD_NUMBER = 6;
        public static final int METADATA_FIELD_NUMBER = 4;
        public static final int NAME_FIELD_NUMBER = 3;
        private static volatile Parser<SIPDispatchRuleUpdate> PARSER = null;
        public static final int RULE_FIELD_NUMBER = 2;
        public static final int TRUNK_IDS_FIELD_NUMBER = 1;
        private MapFieldLite<String, String> attributes_ = MapFieldLite.f();
        private int bitField0_;
        private int mediaEncryption_;
        private String metadata_;
        private String name_;
        private SIPDispatchRule rule_;
        private LivekitModels.ListUpdate trunkIds_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(1796083364);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private AttributesDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPDispatchRuleUpdate, Builder> implements SIPDispatchRuleUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPDispatchRuleUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            SIPDispatchRuleUpdate sIPDispatchRuleUpdate = new SIPDispatchRuleUpdate();
            DEFAULT_INSTANCE = sIPDispatchRuleUpdate;
            GeneratedMessageLite.registerDefaultInstance(SIPDispatchRuleUpdate.class, sIPDispatchRuleUpdate);
        }

        private SIPDispatchRuleUpdate() {
            String strA = ap.a(370778195);
            this.name_ = strA;
            this.metadata_ = strA;
        }

        private void clearMediaEncryption() {
            this.bitField0_ &= -5;
            this.mediaEncryption_ = 0;
        }

        private void clearMetadata() {
            this.bitField0_ &= -3;
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.bitField0_ &= -2;
            this.name_ = getDefaultInstance().getName();
        }

        private void clearRule() {
            this.rule_ = null;
        }

        private void clearTrunkIds() {
            this.trunkIds_ = null;
        }

        public static SIPDispatchRuleUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableAttributesMap() {
            return internalGetMutableAttributes();
        }

        private MapFieldLite<String, String> internalGetAttributes() {
            return this.attributes_;
        }

        private MapFieldLite<String, String> internalGetMutableAttributes() {
            if (!this.attributes_.k()) {
                this.attributes_ = this.attributes_.n();
            }
            return this.attributes_;
        }

        private void mergeRule(SIPDispatchRule sIPDispatchRule) {
            sIPDispatchRule.getClass();
            SIPDispatchRule sIPDispatchRule2 = this.rule_;
            if (sIPDispatchRule2 == null || sIPDispatchRule2 == SIPDispatchRule.getDefaultInstance()) {
                this.rule_ = sIPDispatchRule;
            } else {
                this.rule_ = (SIPDispatchRule) ((SIPDispatchRule.Builder) SIPDispatchRule.newBuilder(this.rule_).v(sIPDispatchRule)).o();
            }
        }

        private void mergeTrunkIds(LivekitModels.ListUpdate listUpdate) {
            listUpdate.getClass();
            LivekitModels.ListUpdate listUpdate2 = this.trunkIds_;
            if (listUpdate2 == null || listUpdate2 == LivekitModels.ListUpdate.getDefaultInstance()) {
                this.trunkIds_ = listUpdate;
            } else {
                this.trunkIds_ = (LivekitModels.ListUpdate) ((LivekitModels.ListUpdate.Builder) LivekitModels.ListUpdate.newBuilder(this.trunkIds_).v(listUpdate)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPDispatchRuleUpdate parseDelimitedFrom(InputStream inputStream) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRuleUpdate parseFrom(ByteBuffer byteBuffer) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPDispatchRuleUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setMediaEncryption(SIPMediaEncryption sIPMediaEncryption) {
            this.mediaEncryption_ = sIPMediaEncryption.getNumber();
            this.bitField0_ |= 4;
        }

        private void setMediaEncryptionValue(int i) {
            this.bitField0_ |= 4;
            this.mediaEncryption_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.bitField0_ |= 2;
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
            this.bitField0_ |= 2;
        }

        private void setName(String str) {
            str.getClass();
            this.bitField0_ |= 1;
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
            this.bitField0_ |= 1;
        }

        private void setRule(SIPDispatchRule sIPDispatchRule) {
            sIPDispatchRule.getClass();
            this.rule_ = sIPDispatchRule;
        }

        private void setTrunkIds(LivekitModels.ListUpdate listUpdate) {
            listUpdate.getClass();
            this.trunkIds_ = listUpdate;
        }

        public boolean containsAttributes(String str) {
            str.getClass();
            return internalGetAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPDispatchRuleUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0001\u0001\u0006\u0006\u0001\u0000\u0000\u0001\t\u0002\t\u0003ለ\u0000\u0004ለ\u0001\u00052\u0006ဌ\u0002", new Object[]{"bitField0_", "trunkIds_", "rule_", "name_", "metadata_", "attributes_", AttributesDefaultEntryHolder.a, "mediaEncryption_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPDispatchRuleUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPDispatchRuleUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public Map<String, String> getAttributes() {
            return getAttributesMap();
        }

        public int getAttributesCount() {
            return internalGetAttributes().size();
        }

        public Map<String, String> getAttributesMap() {
            return Collections.unmodifiableMap(internalGetAttributes());
        }

        public String getAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            return mapFieldLiteInternalGetAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetAttributes.get(str) : str2;
        }

        public String getAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            if (mapFieldLiteInternalGetAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public SIPMediaEncryption getMediaEncryption() {
            SIPMediaEncryption sIPMediaEncryptionB = SIPMediaEncryption.b(this.mediaEncryption_);
            return sIPMediaEncryptionB == null ? SIPMediaEncryption.e : sIPMediaEncryptionB;
        }

        public int getMediaEncryptionValue() {
            return this.mediaEncryption_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public SIPDispatchRule getRule() {
            SIPDispatchRule sIPDispatchRule = this.rule_;
            return sIPDispatchRule == null ? SIPDispatchRule.getDefaultInstance() : sIPDispatchRule;
        }

        public LivekitModels.ListUpdate getTrunkIds() {
            LivekitModels.ListUpdate listUpdate = this.trunkIds_;
            return listUpdate == null ? LivekitModels.ListUpdate.getDefaultInstance() : listUpdate;
        }

        public boolean hasMediaEncryption() {
            return (this.bitField0_ & 4) != 0;
        }

        public boolean hasMetadata() {
            return (this.bitField0_ & 2) != 0;
        }

        public boolean hasName() {
            return (this.bitField0_ & 1) != 0;
        }

        public boolean hasRule() {
            return this.rule_ != null;
        }

        public boolean hasTrunkIds() {
            return this.trunkIds_ != null;
        }

        public static Builder newBuilder(SIPDispatchRuleUpdate sIPDispatchRuleUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPDispatchRuleUpdate);
        }

        public static SIPDispatchRuleUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRuleUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPDispatchRuleUpdate parseFrom(ByteString byteString) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPDispatchRuleUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPDispatchRuleUpdate parseFrom(byte[] bArr) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPDispatchRuleUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPDispatchRuleUpdate parseFrom(InputStream inputStream) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPDispatchRuleUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPDispatchRuleUpdate parseFrom(CodedInputStream codedInputStream) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPDispatchRuleUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPDispatchRuleUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPDispatchRuleUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SIPFeature implements Internal.EnumLite {
        b(0),
        c(1),
        d(-1);

        private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<SIPFeature>() { // from class: livekit.LivekitSip.SIPFeature.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SIPFeature findValueByNumber(int i) {
                return SIPFeature.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SIPFeatureVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SIPFeatureVerifier();

            private SIPFeatureVerifier() {
            }

            public boolean isInRange(int i) {
                return SIPFeature.b(i) != null;
            }
        }

        SIPFeature(int i) {
            this.a = i;
        }

        public static SIPFeature b(int i) {
            if (i == 0) {
                return b;
            }
            if (i != 1) {
                return null;
            }
            return c;
        }

        public final int getNumber() {
            if (this != d) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SIPHeaderOptions implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<SIPHeaderOptions>() { // from class: livekit.LivekitSip.SIPHeaderOptions.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SIPHeaderOptions findValueByNumber(int i) {
                return SIPHeaderOptions.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SIPHeaderOptionsVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SIPHeaderOptionsVerifier();

            private SIPHeaderOptionsVerifier() {
            }

            public boolean isInRange(int i) {
                return SIPHeaderOptions.b(i) != null;
            }
        }

        SIPHeaderOptions(int i) {
            this.a = i;
        }

        public static SIPHeaderOptions b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPInboundTrunkInfo extends GeneratedMessageLite<SIPInboundTrunkInfo, Builder> implements SIPInboundTrunkInfoOrBuilder {
        public static final int ALLOWED_ADDRESSES_FIELD_NUMBER = 5;
        public static final int ALLOWED_NUMBERS_FIELD_NUMBER = 6;
        public static final int ATTRIBUTES_TO_HEADERS_FIELD_NUMBER = 14;
        public static final int AUTH_PASSWORD_FIELD_NUMBER = 8;
        public static final int AUTH_USERNAME_FIELD_NUMBER = 7;
        private static final SIPInboundTrunkInfo DEFAULT_INSTANCE;
        public static final int HEADERS_FIELD_NUMBER = 9;
        public static final int HEADERS_TO_ATTRIBUTES_FIELD_NUMBER = 10;
        public static final int INCLUDE_HEADERS_FIELD_NUMBER = 15;
        public static final int KRISP_ENABLED_FIELD_NUMBER = 13;
        public static final int MAX_CALL_DURATION_FIELD_NUMBER = 12;
        public static final int MEDIA_ENCRYPTION_FIELD_NUMBER = 16;
        public static final int METADATA_FIELD_NUMBER = 3;
        public static final int NAME_FIELD_NUMBER = 2;
        public static final int NUMBERS_FIELD_NUMBER = 4;
        private static volatile Parser<SIPInboundTrunkInfo> PARSER = null;
        public static final int RINGING_TIMEOUT_FIELD_NUMBER = 11;
        public static final int SIP_TRUNK_ID_FIELD_NUMBER = 1;
        private Internal.ProtobufList<String> allowedAddresses_;
        private Internal.ProtobufList<String> allowedNumbers_;
        private String authPassword_;
        private String authUsername_;
        private int includeHeaders_;
        private boolean krispEnabled_;
        private Duration maxCallDuration_;
        private int mediaEncryption_;
        private String metadata_;
        private String name_;
        private Internal.ProtobufList<String> numbers_;
        private Duration ringingTimeout_;
        private String sipTrunkId_;
        private MapFieldLite<String, String> headers_ = MapFieldLite.f();
        private MapFieldLite<String, String> headersToAttributes_ = MapFieldLite.f();
        private MapFieldLite<String, String> attributesToHeaders_ = MapFieldLite.f();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AttributesToHeadersDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(1550743939);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private AttributesToHeadersDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPInboundTrunkInfo, Builder> implements SIPInboundTrunkInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPInboundTrunkInfo.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class HeadersDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(1976994313);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private HeadersDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class HeadersToAttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(835283939);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private HeadersToAttributesDefaultEntryHolder() {
            }
        }

        static {
            SIPInboundTrunkInfo sIPInboundTrunkInfo = new SIPInboundTrunkInfo();
            DEFAULT_INSTANCE = sIPInboundTrunkInfo;
            GeneratedMessageLite.registerDefaultInstance(SIPInboundTrunkInfo.class, sIPInboundTrunkInfo);
        }

        private SIPInboundTrunkInfo() {
            String strA = ap.a(1006225074);
            this.sipTrunkId_ = strA;
            this.name_ = strA;
            this.metadata_ = strA;
            this.numbers_ = GeneratedMessageLite.emptyProtobufList();
            this.allowedAddresses_ = GeneratedMessageLite.emptyProtobufList();
            this.allowedNumbers_ = GeneratedMessageLite.emptyProtobufList();
            this.authUsername_ = strA;
            this.authPassword_ = strA;
        }

        private void addAllAllowedAddresses(Iterable<String> iterable) {
            ensureAllowedAddressesIsMutable();
            AbstractMessageLite.addAll(iterable, this.allowedAddresses_);
        }

        private void addAllAllowedNumbers(Iterable<String> iterable) {
            ensureAllowedNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.allowedNumbers_);
        }

        private void addAllNumbers(Iterable<String> iterable) {
            ensureNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.numbers_);
        }

        private void addAllowedAddresses(String str) {
            str.getClass();
            ensureAllowedAddressesIsMutable();
            this.allowedAddresses_.add(str);
        }

        private void addAllowedAddressesBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureAllowedAddressesIsMutable();
            this.allowedAddresses_.add(byteString.L());
        }

        private void addAllowedNumbers(String str) {
            str.getClass();
            ensureAllowedNumbersIsMutable();
            this.allowedNumbers_.add(str);
        }

        private void addAllowedNumbersBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureAllowedNumbersIsMutable();
            this.allowedNumbers_.add(byteString.L());
        }

        private void addNumbers(String str) {
            str.getClass();
            ensureNumbersIsMutable();
            this.numbers_.add(str);
        }

        private void addNumbersBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureNumbersIsMutable();
            this.numbers_.add(byteString.L());
        }

        private void clearAllowedAddresses() {
            this.allowedAddresses_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearAllowedNumbers() {
            this.allowedNumbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearAuthPassword() {
            this.authPassword_ = getDefaultInstance().getAuthPassword();
        }

        private void clearAuthUsername() {
            this.authUsername_ = getDefaultInstance().getAuthUsername();
        }

        private void clearIncludeHeaders() {
            this.includeHeaders_ = 0;
        }

        private void clearKrispEnabled() {
            this.krispEnabled_ = false;
        }

        private void clearMaxCallDuration() {
            this.maxCallDuration_ = null;
        }

        private void clearMediaEncryption() {
            this.mediaEncryption_ = 0;
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearNumbers() {
            this.numbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearRingingTimeout() {
            this.ringingTimeout_ = null;
        }

        private void clearSipTrunkId() {
            this.sipTrunkId_ = getDefaultInstance().getSipTrunkId();
        }

        private void ensureAllowedAddressesIsMutable() {
            Internal.ProtobufList<String> protobufList = this.allowedAddresses_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.allowedAddresses_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureAllowedNumbersIsMutable() {
            Internal.ProtobufList<String> protobufList = this.allowedNumbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.allowedNumbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureNumbersIsMutable() {
            Internal.ProtobufList<String> protobufList = this.numbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.numbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SIPInboundTrunkInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableAttributesToHeadersMap() {
            return internalGetMutableAttributesToHeaders();
        }

        private Map<String, String> getMutableHeadersMap() {
            return internalGetMutableHeaders();
        }

        private Map<String, String> getMutableHeadersToAttributesMap() {
            return internalGetMutableHeadersToAttributes();
        }

        private MapFieldLite<String, String> internalGetAttributesToHeaders() {
            return this.attributesToHeaders_;
        }

        private MapFieldLite<String, String> internalGetHeaders() {
            return this.headers_;
        }

        private MapFieldLite<String, String> internalGetHeadersToAttributes() {
            return this.headersToAttributes_;
        }

        private MapFieldLite<String, String> internalGetMutableAttributesToHeaders() {
            if (!this.attributesToHeaders_.k()) {
                this.attributesToHeaders_ = this.attributesToHeaders_.n();
            }
            return this.attributesToHeaders_;
        }

        private MapFieldLite<String, String> internalGetMutableHeaders() {
            if (!this.headers_.k()) {
                this.headers_ = this.headers_.n();
            }
            return this.headers_;
        }

        private MapFieldLite<String, String> internalGetMutableHeadersToAttributes() {
            if (!this.headersToAttributes_.k()) {
                this.headersToAttributes_ = this.headersToAttributes_.n();
            }
            return this.headersToAttributes_;
        }

        private void mergeMaxCallDuration(Duration duration) {
            duration.getClass();
            Duration duration2 = this.maxCallDuration_;
            if (duration2 == null || duration2 == Duration.getDefaultInstance()) {
                this.maxCallDuration_ = duration;
            } else {
                this.maxCallDuration_ = Duration.newBuilder(this.maxCallDuration_).v(duration).o();
            }
        }

        private void mergeRingingTimeout(Duration duration) {
            duration.getClass();
            Duration duration2 = this.ringingTimeout_;
            if (duration2 == null || duration2 == Duration.getDefaultInstance()) {
                this.ringingTimeout_ = duration;
            } else {
                this.ringingTimeout_ = Duration.newBuilder(this.ringingTimeout_).v(duration).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPInboundTrunkInfo parseDelimitedFrom(InputStream inputStream) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPInboundTrunkInfo parseFrom(ByteBuffer byteBuffer) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPInboundTrunkInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAllowedAddresses(int i, String str) {
            str.getClass();
            ensureAllowedAddressesIsMutable();
            this.allowedAddresses_.set(i, str);
        }

        private void setAllowedNumbers(int i, String str) {
            str.getClass();
            ensureAllowedNumbersIsMutable();
            this.allowedNumbers_.set(i, str);
        }

        private void setAuthPassword(String str) {
            str.getClass();
            this.authPassword_ = str;
        }

        private void setAuthPasswordBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.authPassword_ = byteString.L();
        }

        private void setAuthUsername(String str) {
            str.getClass();
            this.authUsername_ = str;
        }

        private void setAuthUsernameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.authUsername_ = byteString.L();
        }

        private void setIncludeHeaders(SIPHeaderOptions sIPHeaderOptions) {
            this.includeHeaders_ = sIPHeaderOptions.getNumber();
        }

        private void setIncludeHeadersValue(int i) {
            this.includeHeaders_ = i;
        }

        private void setKrispEnabled(boolean z) {
            this.krispEnabled_ = z;
        }

        private void setMaxCallDuration(Duration duration) {
            duration.getClass();
            this.maxCallDuration_ = duration;
        }

        private void setMediaEncryption(SIPMediaEncryption sIPMediaEncryption) {
            this.mediaEncryption_ = sIPMediaEncryption.getNumber();
        }

        private void setMediaEncryptionValue(int i) {
            this.mediaEncryption_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setNumbers(int i, String str) {
            str.getClass();
            ensureNumbersIsMutable();
            this.numbers_.set(i, str);
        }

        private void setRingingTimeout(Duration duration) {
            duration.getClass();
            this.ringingTimeout_ = duration;
        }

        private void setSipTrunkId(String str) {
            str.getClass();
            this.sipTrunkId_ = str;
        }

        private void setSipTrunkIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipTrunkId_ = byteString.L();
        }

        public boolean containsAttributesToHeaders(String str) {
            str.getClass();
            return internalGetAttributesToHeaders().containsKey(str);
        }

        public boolean containsHeaders(String str) {
            str.getClass();
            return internalGetHeaders().containsKey(str);
        }

        public boolean containsHeadersToAttributes(String str) {
            str.getClass();
            return internalGetHeadersToAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new SIPInboundTrunkInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0010\u0000\u0000\u0001\u0010\u0010\u0003\u0003\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ț\u0005Ț\u0006Ț\u0007Ȉ\bȈ\t2\n2\u000b\t\f\t\r\u0007\u000e2\u000f\f\u0010\f", new Object[]{"sipTrunkId_", "name_", "metadata_", "numbers_", "allowedAddresses_", "allowedNumbers_", "authUsername_", "authPassword_", "headers_", HeadersDefaultEntryHolder.a, "headersToAttributes_", HeadersToAttributesDefaultEntryHolder.a, "ringingTimeout_", "maxCallDuration_", "krispEnabled_", "attributesToHeaders_", AttributesToHeadersDefaultEntryHolder.a, "includeHeaders_", "mediaEncryption_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPInboundTrunkInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPInboundTrunkInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAllowedAddresses(int i) {
            return (String) this.allowedAddresses_.get(i);
        }

        public ByteString getAllowedAddressesBytes(int i) {
            return ByteString.n((String) this.allowedAddresses_.get(i));
        }

        public int getAllowedAddressesCount() {
            return this.allowedAddresses_.size();
        }

        public List<String> getAllowedAddressesList() {
            return this.allowedAddresses_;
        }

        public String getAllowedNumbers(int i) {
            return (String) this.allowedNumbers_.get(i);
        }

        public ByteString getAllowedNumbersBytes(int i) {
            return ByteString.n((String) this.allowedNumbers_.get(i));
        }

        public int getAllowedNumbersCount() {
            return this.allowedNumbers_.size();
        }

        public List<String> getAllowedNumbersList() {
            return this.allowedNumbers_;
        }

        @Deprecated
        public Map<String, String> getAttributesToHeaders() {
            return getAttributesToHeadersMap();
        }

        public int getAttributesToHeadersCount() {
            return internalGetAttributesToHeaders().size();
        }

        public Map<String, String> getAttributesToHeadersMap() {
            return Collections.unmodifiableMap(internalGetAttributesToHeaders());
        }

        public String getAttributesToHeadersOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributesToHeaders = internalGetAttributesToHeaders();
            return mapFieldLiteInternalGetAttributesToHeaders.containsKey(str) ? (String) mapFieldLiteInternalGetAttributesToHeaders.get(str) : str2;
        }

        public String getAttributesToHeadersOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributesToHeaders = internalGetAttributesToHeaders();
            if (mapFieldLiteInternalGetAttributesToHeaders.containsKey(str)) {
                return (String) mapFieldLiteInternalGetAttributesToHeaders.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getAuthPassword() {
            return this.authPassword_;
        }

        public ByteString getAuthPasswordBytes() {
            return ByteString.n(this.authPassword_);
        }

        public String getAuthUsername() {
            return this.authUsername_;
        }

        public ByteString getAuthUsernameBytes() {
            return ByteString.n(this.authUsername_);
        }

        @Deprecated
        public Map<String, String> getHeaders() {
            return getHeadersMap();
        }

        public int getHeadersCount() {
            return internalGetHeaders().size();
        }

        public Map<String, String> getHeadersMap() {
            return Collections.unmodifiableMap(internalGetHeaders());
        }

        public String getHeadersOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeaders = internalGetHeaders();
            return mapFieldLiteInternalGetHeaders.containsKey(str) ? (String) mapFieldLiteInternalGetHeaders.get(str) : str2;
        }

        public String getHeadersOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeaders = internalGetHeaders();
            if (mapFieldLiteInternalGetHeaders.containsKey(str)) {
                return (String) mapFieldLiteInternalGetHeaders.get(str);
            }
            throw new IllegalArgumentException();
        }

        @Deprecated
        public Map<String, String> getHeadersToAttributes() {
            return getHeadersToAttributesMap();
        }

        public int getHeadersToAttributesCount() {
            return internalGetHeadersToAttributes().size();
        }

        public Map<String, String> getHeadersToAttributesMap() {
            return Collections.unmodifiableMap(internalGetHeadersToAttributes());
        }

        public String getHeadersToAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeadersToAttributes = internalGetHeadersToAttributes();
            return mapFieldLiteInternalGetHeadersToAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetHeadersToAttributes.get(str) : str2;
        }

        public String getHeadersToAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeadersToAttributes = internalGetHeadersToAttributes();
            if (mapFieldLiteInternalGetHeadersToAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetHeadersToAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public SIPHeaderOptions getIncludeHeaders() {
            SIPHeaderOptions sIPHeaderOptionsB = SIPHeaderOptions.b(this.includeHeaders_);
            return sIPHeaderOptionsB == null ? SIPHeaderOptions.e : sIPHeaderOptionsB;
        }

        public int getIncludeHeadersValue() {
            return this.includeHeaders_;
        }

        public boolean getKrispEnabled() {
            return this.krispEnabled_;
        }

        public Duration getMaxCallDuration() {
            Duration duration = this.maxCallDuration_;
            return duration == null ? Duration.getDefaultInstance() : duration;
        }

        public SIPMediaEncryption getMediaEncryption() {
            SIPMediaEncryption sIPMediaEncryptionB = SIPMediaEncryption.b(this.mediaEncryption_);
            return sIPMediaEncryptionB == null ? SIPMediaEncryption.e : sIPMediaEncryptionB;
        }

        public int getMediaEncryptionValue() {
            return this.mediaEncryption_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getNumbers(int i) {
            return (String) this.numbers_.get(i);
        }

        public ByteString getNumbersBytes(int i) {
            return ByteString.n((String) this.numbers_.get(i));
        }

        public int getNumbersCount() {
            return this.numbers_.size();
        }

        public List<String> getNumbersList() {
            return this.numbers_;
        }

        public Duration getRingingTimeout() {
            Duration duration = this.ringingTimeout_;
            return duration == null ? Duration.getDefaultInstance() : duration;
        }

        public String getSipTrunkId() {
            return this.sipTrunkId_;
        }

        public ByteString getSipTrunkIdBytes() {
            return ByteString.n(this.sipTrunkId_);
        }

        public boolean hasMaxCallDuration() {
            return this.maxCallDuration_ != null;
        }

        public boolean hasRingingTimeout() {
            return this.ringingTimeout_ != null;
        }

        public static Builder newBuilder(SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPInboundTrunkInfo);
        }

        public static SIPInboundTrunkInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPInboundTrunkInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPInboundTrunkInfo parseFrom(ByteString byteString) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPInboundTrunkInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPInboundTrunkInfo parseFrom(byte[] bArr) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPInboundTrunkInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPInboundTrunkInfo parseFrom(InputStream inputStream) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPInboundTrunkInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPInboundTrunkInfo parseFrom(CodedInputStream codedInputStream) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPInboundTrunkInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPInboundTrunkInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPInboundTrunkUpdate extends GeneratedMessageLite<SIPInboundTrunkUpdate, Builder> implements SIPInboundTrunkUpdateOrBuilder {
        public static final int ALLOWED_ADDRESSES_FIELD_NUMBER = 2;
        public static final int ALLOWED_NUMBERS_FIELD_NUMBER = 3;
        public static final int AUTH_PASSWORD_FIELD_NUMBER = 5;
        public static final int AUTH_USERNAME_FIELD_NUMBER = 4;
        private static final SIPInboundTrunkUpdate DEFAULT_INSTANCE;
        public static final int MEDIA_ENCRYPTION_FIELD_NUMBER = 8;
        public static final int METADATA_FIELD_NUMBER = 7;
        public static final int NAME_FIELD_NUMBER = 6;
        public static final int NUMBERS_FIELD_NUMBER = 1;
        private static volatile Parser<SIPInboundTrunkUpdate> PARSER;
        private LivekitModels.ListUpdate allowedAddresses_;
        private LivekitModels.ListUpdate allowedNumbers_;
        private String authPassword_;
        private String authUsername_;
        private int bitField0_;
        private int mediaEncryption_;
        private String metadata_;
        private String name_;
        private LivekitModels.ListUpdate numbers_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPInboundTrunkUpdate, Builder> implements SIPInboundTrunkUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPInboundTrunkUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            SIPInboundTrunkUpdate sIPInboundTrunkUpdate = new SIPInboundTrunkUpdate();
            DEFAULT_INSTANCE = sIPInboundTrunkUpdate;
            GeneratedMessageLite.registerDefaultInstance(SIPInboundTrunkUpdate.class, sIPInboundTrunkUpdate);
        }

        private SIPInboundTrunkUpdate() {
            String strA = ap.a(1909582092);
            this.authUsername_ = strA;
            this.authPassword_ = strA;
            this.name_ = strA;
            this.metadata_ = strA;
        }

        private void clearAllowedAddresses() {
            this.allowedAddresses_ = null;
        }

        private void clearAllowedNumbers() {
            this.allowedNumbers_ = null;
        }

        private void clearAuthPassword() {
            this.bitField0_ &= -3;
            this.authPassword_ = getDefaultInstance().getAuthPassword();
        }

        private void clearAuthUsername() {
            this.bitField0_ &= -2;
            this.authUsername_ = getDefaultInstance().getAuthUsername();
        }

        private void clearMediaEncryption() {
            this.bitField0_ &= -17;
            this.mediaEncryption_ = 0;
        }

        private void clearMetadata() {
            this.bitField0_ &= -9;
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.bitField0_ &= -5;
            this.name_ = getDefaultInstance().getName();
        }

        private void clearNumbers() {
            this.numbers_ = null;
        }

        public static SIPInboundTrunkUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAllowedAddresses(LivekitModels.ListUpdate listUpdate) {
            listUpdate.getClass();
            LivekitModels.ListUpdate listUpdate2 = this.allowedAddresses_;
            if (listUpdate2 == null || listUpdate2 == LivekitModels.ListUpdate.getDefaultInstance()) {
                this.allowedAddresses_ = listUpdate;
            } else {
                this.allowedAddresses_ = (LivekitModels.ListUpdate) ((LivekitModels.ListUpdate.Builder) LivekitModels.ListUpdate.newBuilder(this.allowedAddresses_).v(listUpdate)).o();
            }
        }

        private void mergeAllowedNumbers(LivekitModels.ListUpdate listUpdate) {
            listUpdate.getClass();
            LivekitModels.ListUpdate listUpdate2 = this.allowedNumbers_;
            if (listUpdate2 == null || listUpdate2 == LivekitModels.ListUpdate.getDefaultInstance()) {
                this.allowedNumbers_ = listUpdate;
            } else {
                this.allowedNumbers_ = (LivekitModels.ListUpdate) ((LivekitModels.ListUpdate.Builder) LivekitModels.ListUpdate.newBuilder(this.allowedNumbers_).v(listUpdate)).o();
            }
        }

        private void mergeNumbers(LivekitModels.ListUpdate listUpdate) {
            listUpdate.getClass();
            LivekitModels.ListUpdate listUpdate2 = this.numbers_;
            if (listUpdate2 == null || listUpdate2 == LivekitModels.ListUpdate.getDefaultInstance()) {
                this.numbers_ = listUpdate;
            } else {
                this.numbers_ = (LivekitModels.ListUpdate) ((LivekitModels.ListUpdate.Builder) LivekitModels.ListUpdate.newBuilder(this.numbers_).v(listUpdate)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPInboundTrunkUpdate parseDelimitedFrom(InputStream inputStream) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPInboundTrunkUpdate parseFrom(ByteBuffer byteBuffer) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPInboundTrunkUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAllowedAddresses(LivekitModels.ListUpdate listUpdate) {
            listUpdate.getClass();
            this.allowedAddresses_ = listUpdate;
        }

        private void setAllowedNumbers(LivekitModels.ListUpdate listUpdate) {
            listUpdate.getClass();
            this.allowedNumbers_ = listUpdate;
        }

        private void setAuthPassword(String str) {
            str.getClass();
            this.bitField0_ |= 2;
            this.authPassword_ = str;
        }

        private void setAuthPasswordBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.authPassword_ = byteString.L();
            this.bitField0_ |= 2;
        }

        private void setAuthUsername(String str) {
            str.getClass();
            this.bitField0_ |= 1;
            this.authUsername_ = str;
        }

        private void setAuthUsernameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.authUsername_ = byteString.L();
            this.bitField0_ |= 1;
        }

        private void setMediaEncryption(SIPMediaEncryption sIPMediaEncryption) {
            this.mediaEncryption_ = sIPMediaEncryption.getNumber();
            this.bitField0_ |= 16;
        }

        private void setMediaEncryptionValue(int i) {
            this.bitField0_ |= 16;
            this.mediaEncryption_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.bitField0_ |= 8;
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
            this.bitField0_ |= 8;
        }

        private void setName(String str) {
            str.getClass();
            this.bitField0_ |= 4;
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
            this.bitField0_ |= 4;
        }

        private void setNumbers(LivekitModels.ListUpdate listUpdate) {
            listUpdate.getClass();
            this.numbers_ = listUpdate;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPInboundTrunkUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\b\u0000\u0001\u0001\b\b\u0000\u0000\u0000\u0001\t\u0002\t\u0003\t\u0004ለ\u0000\u0005ለ\u0001\u0006ለ\u0002\u0007ለ\u0003\bဌ\u0004", new Object[]{"bitField0_", "numbers_", "allowedAddresses_", "allowedNumbers_", "authUsername_", "authPassword_", "name_", "metadata_", "mediaEncryption_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPInboundTrunkUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPInboundTrunkUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.ListUpdate getAllowedAddresses() {
            LivekitModels.ListUpdate listUpdate = this.allowedAddresses_;
            return listUpdate == null ? LivekitModels.ListUpdate.getDefaultInstance() : listUpdate;
        }

        public LivekitModels.ListUpdate getAllowedNumbers() {
            LivekitModels.ListUpdate listUpdate = this.allowedNumbers_;
            return listUpdate == null ? LivekitModels.ListUpdate.getDefaultInstance() : listUpdate;
        }

        public String getAuthPassword() {
            return this.authPassword_;
        }

        public ByteString getAuthPasswordBytes() {
            return ByteString.n(this.authPassword_);
        }

        public String getAuthUsername() {
            return this.authUsername_;
        }

        public ByteString getAuthUsernameBytes() {
            return ByteString.n(this.authUsername_);
        }

        public SIPMediaEncryption getMediaEncryption() {
            SIPMediaEncryption sIPMediaEncryptionB = SIPMediaEncryption.b(this.mediaEncryption_);
            return sIPMediaEncryptionB == null ? SIPMediaEncryption.e : sIPMediaEncryptionB;
        }

        public int getMediaEncryptionValue() {
            return this.mediaEncryption_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public LivekitModels.ListUpdate getNumbers() {
            LivekitModels.ListUpdate listUpdate = this.numbers_;
            return listUpdate == null ? LivekitModels.ListUpdate.getDefaultInstance() : listUpdate;
        }

        public boolean hasAllowedAddresses() {
            return this.allowedAddresses_ != null;
        }

        public boolean hasAllowedNumbers() {
            return this.allowedNumbers_ != null;
        }

        public boolean hasAuthPassword() {
            return (this.bitField0_ & 2) != 0;
        }

        public boolean hasAuthUsername() {
            return (this.bitField0_ & 1) != 0;
        }

        public boolean hasMediaEncryption() {
            return (this.bitField0_ & 16) != 0;
        }

        public boolean hasMetadata() {
            return (this.bitField0_ & 8) != 0;
        }

        public boolean hasName() {
            return (this.bitField0_ & 4) != 0;
        }

        public boolean hasNumbers() {
            return this.numbers_ != null;
        }

        public static Builder newBuilder(SIPInboundTrunkUpdate sIPInboundTrunkUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPInboundTrunkUpdate);
        }

        public static SIPInboundTrunkUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPInboundTrunkUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPInboundTrunkUpdate parseFrom(ByteString byteString) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPInboundTrunkUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPInboundTrunkUpdate parseFrom(byte[] bArr) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPInboundTrunkUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPInboundTrunkUpdate parseFrom(InputStream inputStream) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPInboundTrunkUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPInboundTrunkUpdate parseFrom(CodedInputStream codedInputStream) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPInboundTrunkUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPInboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPInboundTrunkUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SIPMediaEncryption implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<SIPMediaEncryption>() { // from class: livekit.LivekitSip.SIPMediaEncryption.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SIPMediaEncryption findValueByNumber(int i) {
                return SIPMediaEncryption.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SIPMediaEncryptionVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SIPMediaEncryptionVerifier();

            private SIPMediaEncryptionVerifier() {
            }

            public boolean isInRange(int i) {
                return SIPMediaEncryption.b(i) != null;
            }
        }

        SIPMediaEncryption(int i) {
            this.a = i;
        }

        public static SIPMediaEncryption b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPOutboundConfig extends GeneratedMessageLite<SIPOutboundConfig, Builder> implements SIPOutboundConfigOrBuilder {
        public static final int ATTRIBUTES_TO_HEADERS_FIELD_NUMBER = 6;
        public static final int AUTH_PASSWORD_FIELD_NUMBER = 4;
        public static final int AUTH_USERNAME_FIELD_NUMBER = 3;
        private static final SIPOutboundConfig DEFAULT_INSTANCE;
        public static final int DESTINATION_COUNTRY_FIELD_NUMBER = 7;
        public static final int HEADERS_TO_ATTRIBUTES_FIELD_NUMBER = 5;
        public static final int HOSTNAME_FIELD_NUMBER = 1;
        private static volatile Parser<SIPOutboundConfig> PARSER = null;
        public static final int TRANSPORT_FIELD_NUMBER = 2;
        private String authPassword_;
        private String authUsername_;
        private String destinationCountry_;
        private String hostname_;
        private int transport_;
        private MapFieldLite<String, String> headersToAttributes_ = MapFieldLite.f();
        private MapFieldLite<String, String> attributesToHeaders_ = MapFieldLite.f();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AttributesToHeadersDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(730790931);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private AttributesToHeadersDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPOutboundConfig, Builder> implements SIPOutboundConfigOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPOutboundConfig.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class HeadersToAttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(433208785);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private HeadersToAttributesDefaultEntryHolder() {
            }
        }

        static {
            SIPOutboundConfig sIPOutboundConfig = new SIPOutboundConfig();
            DEFAULT_INSTANCE = sIPOutboundConfig;
            GeneratedMessageLite.registerDefaultInstance(SIPOutboundConfig.class, sIPOutboundConfig);
        }

        private SIPOutboundConfig() {
            String strA = ap.a(20406354);
            this.hostname_ = strA;
            this.destinationCountry_ = strA;
            this.authUsername_ = strA;
            this.authPassword_ = strA;
        }

        private void clearAuthPassword() {
            this.authPassword_ = getDefaultInstance().getAuthPassword();
        }

        private void clearAuthUsername() {
            this.authUsername_ = getDefaultInstance().getAuthUsername();
        }

        private void clearDestinationCountry() {
            this.destinationCountry_ = getDefaultInstance().getDestinationCountry();
        }

        private void clearHostname() {
            this.hostname_ = getDefaultInstance().getHostname();
        }

        private void clearTransport() {
            this.transport_ = 0;
        }

        public static SIPOutboundConfig getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableAttributesToHeadersMap() {
            return internalGetMutableAttributesToHeaders();
        }

        private Map<String, String> getMutableHeadersToAttributesMap() {
            return internalGetMutableHeadersToAttributes();
        }

        private MapFieldLite<String, String> internalGetAttributesToHeaders() {
            return this.attributesToHeaders_;
        }

        private MapFieldLite<String, String> internalGetHeadersToAttributes() {
            return this.headersToAttributes_;
        }

        private MapFieldLite<String, String> internalGetMutableAttributesToHeaders() {
            if (!this.attributesToHeaders_.k()) {
                this.attributesToHeaders_ = this.attributesToHeaders_.n();
            }
            return this.attributesToHeaders_;
        }

        private MapFieldLite<String, String> internalGetMutableHeadersToAttributes() {
            if (!this.headersToAttributes_.k()) {
                this.headersToAttributes_ = this.headersToAttributes_.n();
            }
            return this.headersToAttributes_;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPOutboundConfig parseDelimitedFrom(InputStream inputStream) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPOutboundConfig parseFrom(ByteBuffer byteBuffer) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPOutboundConfig> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAuthPassword(String str) {
            str.getClass();
            this.authPassword_ = str;
        }

        private void setAuthPasswordBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.authPassword_ = byteString.L();
        }

        private void setAuthUsername(String str) {
            str.getClass();
            this.authUsername_ = str;
        }

        private void setAuthUsernameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.authUsername_ = byteString.L();
        }

        private void setDestinationCountry(String str) {
            str.getClass();
            this.destinationCountry_ = str;
        }

        private void setDestinationCountryBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.destinationCountry_ = byteString.L();
        }

        private void setHostname(String str) {
            str.getClass();
            this.hostname_ = str;
        }

        private void setHostnameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.hostname_ = byteString.L();
        }

        private void setTransport(SIPTransport sIPTransport) {
            this.transport_ = sIPTransport.getNumber();
        }

        private void setTransportValue(int i) {
            this.transport_ = i;
        }

        public boolean containsAttributesToHeaders(String str) {
            str.getClass();
            return internalGetAttributesToHeaders().containsKey(str);
        }

        public boolean containsHeadersToAttributes(String str) {
            str.getClass();
            return internalGetHeadersToAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPOutboundConfig();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0000\u0000\u0001\u0007\u0007\u0002\u0000\u0000\u0001Ȉ\u0002\f\u0003Ȉ\u0004Ȉ\u00052\u00062\u0007Ȉ", new Object[]{"hostname_", "transport_", "authUsername_", "authPassword_", "headersToAttributes_", HeadersToAttributesDefaultEntryHolder.a, "attributesToHeaders_", AttributesToHeadersDefaultEntryHolder.a, "destinationCountry_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPOutboundConfig> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPOutboundConfig.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public Map<String, String> getAttributesToHeaders() {
            return getAttributesToHeadersMap();
        }

        public int getAttributesToHeadersCount() {
            return internalGetAttributesToHeaders().size();
        }

        public Map<String, String> getAttributesToHeadersMap() {
            return Collections.unmodifiableMap(internalGetAttributesToHeaders());
        }

        public String getAttributesToHeadersOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributesToHeaders = internalGetAttributesToHeaders();
            return mapFieldLiteInternalGetAttributesToHeaders.containsKey(str) ? (String) mapFieldLiteInternalGetAttributesToHeaders.get(str) : str2;
        }

        public String getAttributesToHeadersOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributesToHeaders = internalGetAttributesToHeaders();
            if (mapFieldLiteInternalGetAttributesToHeaders.containsKey(str)) {
                return (String) mapFieldLiteInternalGetAttributesToHeaders.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getAuthPassword() {
            return this.authPassword_;
        }

        public ByteString getAuthPasswordBytes() {
            return ByteString.n(this.authPassword_);
        }

        public String getAuthUsername() {
            return this.authUsername_;
        }

        public ByteString getAuthUsernameBytes() {
            return ByteString.n(this.authUsername_);
        }

        public String getDestinationCountry() {
            return this.destinationCountry_;
        }

        public ByteString getDestinationCountryBytes() {
            return ByteString.n(this.destinationCountry_);
        }

        @Deprecated
        public Map<String, String> getHeadersToAttributes() {
            return getHeadersToAttributesMap();
        }

        public int getHeadersToAttributesCount() {
            return internalGetHeadersToAttributes().size();
        }

        public Map<String, String> getHeadersToAttributesMap() {
            return Collections.unmodifiableMap(internalGetHeadersToAttributes());
        }

        public String getHeadersToAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeadersToAttributes = internalGetHeadersToAttributes();
            return mapFieldLiteInternalGetHeadersToAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetHeadersToAttributes.get(str) : str2;
        }

        public String getHeadersToAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeadersToAttributes = internalGetHeadersToAttributes();
            if (mapFieldLiteInternalGetHeadersToAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetHeadersToAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getHostname() {
            return this.hostname_;
        }

        public ByteString getHostnameBytes() {
            return ByteString.n(this.hostname_);
        }

        public SIPTransport getTransport() {
            SIPTransport sIPTransportB = SIPTransport.b(this.transport_);
            return sIPTransportB == null ? SIPTransport.f : sIPTransportB;
        }

        public int getTransportValue() {
            return this.transport_;
        }

        public static Builder newBuilder(SIPOutboundConfig sIPOutboundConfig) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPOutboundConfig);
        }

        public static SIPOutboundConfig parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPOutboundConfig parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPOutboundConfig parseFrom(ByteString byteString) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPOutboundConfig parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPOutboundConfig parseFrom(byte[] bArr) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPOutboundConfig parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPOutboundConfig parseFrom(InputStream inputStream) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPOutboundConfig parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPOutboundConfig parseFrom(CodedInputStream codedInputStream) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPOutboundConfig parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPOutboundConfigOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPOutboundTrunkInfo extends GeneratedMessageLite<SIPOutboundTrunkInfo, Builder> implements SIPOutboundTrunkInfoOrBuilder {
        public static final int ADDRESS_FIELD_NUMBER = 4;
        public static final int ATTRIBUTES_TO_HEADERS_FIELD_NUMBER = 11;
        public static final int AUTH_PASSWORD_FIELD_NUMBER = 8;
        public static final int AUTH_USERNAME_FIELD_NUMBER = 7;
        private static final SIPOutboundTrunkInfo DEFAULT_INSTANCE;
        public static final int DESTINATION_COUNTRY_FIELD_NUMBER = 14;
        public static final int HEADERS_FIELD_NUMBER = 9;
        public static final int HEADERS_TO_ATTRIBUTES_FIELD_NUMBER = 10;
        public static final int INCLUDE_HEADERS_FIELD_NUMBER = 12;
        public static final int MEDIA_ENCRYPTION_FIELD_NUMBER = 13;
        public static final int METADATA_FIELD_NUMBER = 3;
        public static final int NAME_FIELD_NUMBER = 2;
        public static final int NUMBERS_FIELD_NUMBER = 6;
        private static volatile Parser<SIPOutboundTrunkInfo> PARSER = null;
        public static final int SIP_TRUNK_ID_FIELD_NUMBER = 1;
        public static final int TRANSPORT_FIELD_NUMBER = 5;
        private String address_;
        private String authPassword_;
        private String authUsername_;
        private String destinationCountry_;
        private int includeHeaders_;
        private int mediaEncryption_;
        private String metadata_;
        private String name_;
        private Internal.ProtobufList<String> numbers_;
        private String sipTrunkId_;
        private int transport_;
        private MapFieldLite<String, String> headers_ = MapFieldLite.f();
        private MapFieldLite<String, String> headersToAttributes_ = MapFieldLite.f();
        private MapFieldLite<String, String> attributesToHeaders_ = MapFieldLite.f();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AttributesToHeadersDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(1189547117);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private AttributesToHeadersDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPOutboundTrunkInfo, Builder> implements SIPOutboundTrunkInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPOutboundTrunkInfo.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class HeadersDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(1380098277);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private HeadersDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class HeadersToAttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(2122321934);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private HeadersToAttributesDefaultEntryHolder() {
            }
        }

        static {
            SIPOutboundTrunkInfo sIPOutboundTrunkInfo = new SIPOutboundTrunkInfo();
            DEFAULT_INSTANCE = sIPOutboundTrunkInfo;
            GeneratedMessageLite.registerDefaultInstance(SIPOutboundTrunkInfo.class, sIPOutboundTrunkInfo);
        }

        private SIPOutboundTrunkInfo() {
            String strA = ap.a(465352390);
            this.sipTrunkId_ = strA;
            this.name_ = strA;
            this.metadata_ = strA;
            this.address_ = strA;
            this.destinationCountry_ = strA;
            this.numbers_ = GeneratedMessageLite.emptyProtobufList();
            this.authUsername_ = strA;
            this.authPassword_ = strA;
        }

        private void addAllNumbers(Iterable<String> iterable) {
            ensureNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.numbers_);
        }

        private void addNumbers(String str) {
            str.getClass();
            ensureNumbersIsMutable();
            this.numbers_.add(str);
        }

        private void addNumbersBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureNumbersIsMutable();
            this.numbers_.add(byteString.L());
        }

        private void clearAddress() {
            this.address_ = getDefaultInstance().getAddress();
        }

        private void clearAuthPassword() {
            this.authPassword_ = getDefaultInstance().getAuthPassword();
        }

        private void clearAuthUsername() {
            this.authUsername_ = getDefaultInstance().getAuthUsername();
        }

        private void clearDestinationCountry() {
            this.destinationCountry_ = getDefaultInstance().getDestinationCountry();
        }

        private void clearIncludeHeaders() {
            this.includeHeaders_ = 0;
        }

        private void clearMediaEncryption() {
            this.mediaEncryption_ = 0;
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearNumbers() {
            this.numbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSipTrunkId() {
            this.sipTrunkId_ = getDefaultInstance().getSipTrunkId();
        }

        private void clearTransport() {
            this.transport_ = 0;
        }

        private void ensureNumbersIsMutable() {
            Internal.ProtobufList<String> protobufList = this.numbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.numbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SIPOutboundTrunkInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableAttributesToHeadersMap() {
            return internalGetMutableAttributesToHeaders();
        }

        private Map<String, String> getMutableHeadersMap() {
            return internalGetMutableHeaders();
        }

        private Map<String, String> getMutableHeadersToAttributesMap() {
            return internalGetMutableHeadersToAttributes();
        }

        private MapFieldLite<String, String> internalGetAttributesToHeaders() {
            return this.attributesToHeaders_;
        }

        private MapFieldLite<String, String> internalGetHeaders() {
            return this.headers_;
        }

        private MapFieldLite<String, String> internalGetHeadersToAttributes() {
            return this.headersToAttributes_;
        }

        private MapFieldLite<String, String> internalGetMutableAttributesToHeaders() {
            if (!this.attributesToHeaders_.k()) {
                this.attributesToHeaders_ = this.attributesToHeaders_.n();
            }
            return this.attributesToHeaders_;
        }

        private MapFieldLite<String, String> internalGetMutableHeaders() {
            if (!this.headers_.k()) {
                this.headers_ = this.headers_.n();
            }
            return this.headers_;
        }

        private MapFieldLite<String, String> internalGetMutableHeadersToAttributes() {
            if (!this.headersToAttributes_.k()) {
                this.headersToAttributes_ = this.headersToAttributes_.n();
            }
            return this.headersToAttributes_;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPOutboundTrunkInfo parseDelimitedFrom(InputStream inputStream) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPOutboundTrunkInfo parseFrom(ByteBuffer byteBuffer) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPOutboundTrunkInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAddress(String str) {
            str.getClass();
            this.address_ = str;
        }

        private void setAddressBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.address_ = byteString.L();
        }

        private void setAuthPassword(String str) {
            str.getClass();
            this.authPassword_ = str;
        }

        private void setAuthPasswordBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.authPassword_ = byteString.L();
        }

        private void setAuthUsername(String str) {
            str.getClass();
            this.authUsername_ = str;
        }

        private void setAuthUsernameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.authUsername_ = byteString.L();
        }

        private void setDestinationCountry(String str) {
            str.getClass();
            this.destinationCountry_ = str;
        }

        private void setDestinationCountryBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.destinationCountry_ = byteString.L();
        }

        private void setIncludeHeaders(SIPHeaderOptions sIPHeaderOptions) {
            this.includeHeaders_ = sIPHeaderOptions.getNumber();
        }

        private void setIncludeHeadersValue(int i) {
            this.includeHeaders_ = i;
        }

        private void setMediaEncryption(SIPMediaEncryption sIPMediaEncryption) {
            this.mediaEncryption_ = sIPMediaEncryption.getNumber();
        }

        private void setMediaEncryptionValue(int i) {
            this.mediaEncryption_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setNumbers(int i, String str) {
            str.getClass();
            ensureNumbersIsMutable();
            this.numbers_.set(i, str);
        }

        private void setSipTrunkId(String str) {
            str.getClass();
            this.sipTrunkId_ = str;
        }

        private void setSipTrunkIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipTrunkId_ = byteString.L();
        }

        private void setTransport(SIPTransport sIPTransport) {
            this.transport_ = sIPTransport.getNumber();
        }

        private void setTransportValue(int i) {
            this.transport_ = i;
        }

        public boolean containsAttributesToHeaders(String str) {
            str.getClass();
            return internalGetAttributesToHeaders().containsKey(str);
        }

        public boolean containsHeaders(String str) {
            str.getClass();
            return internalGetHeaders().containsKey(str);
        }

        public boolean containsHeadersToAttributes(String str) {
            str.getClass();
            return internalGetHeadersToAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new SIPOutboundTrunkInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000e\u0000\u0000\u0001\u000e\u000e\u0003\u0001\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005\f\u0006Ț\u0007Ȉ\bȈ\t2\n2\u000b2\f\f\r\f\u000eȈ", new Object[]{"sipTrunkId_", "name_", "metadata_", "address_", "transport_", "numbers_", "authUsername_", "authPassword_", "headers_", HeadersDefaultEntryHolder.a, "headersToAttributes_", HeadersToAttributesDefaultEntryHolder.a, "attributesToHeaders_", AttributesToHeadersDefaultEntryHolder.a, "includeHeaders_", "mediaEncryption_", "destinationCountry_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPOutboundTrunkInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPOutboundTrunkInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAddress() {
            return this.address_;
        }

        public ByteString getAddressBytes() {
            return ByteString.n(this.address_);
        }

        @Deprecated
        public Map<String, String> getAttributesToHeaders() {
            return getAttributesToHeadersMap();
        }

        public int getAttributesToHeadersCount() {
            return internalGetAttributesToHeaders().size();
        }

        public Map<String, String> getAttributesToHeadersMap() {
            return Collections.unmodifiableMap(internalGetAttributesToHeaders());
        }

        public String getAttributesToHeadersOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributesToHeaders = internalGetAttributesToHeaders();
            return mapFieldLiteInternalGetAttributesToHeaders.containsKey(str) ? (String) mapFieldLiteInternalGetAttributesToHeaders.get(str) : str2;
        }

        public String getAttributesToHeadersOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributesToHeaders = internalGetAttributesToHeaders();
            if (mapFieldLiteInternalGetAttributesToHeaders.containsKey(str)) {
                return (String) mapFieldLiteInternalGetAttributesToHeaders.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getAuthPassword() {
            return this.authPassword_;
        }

        public ByteString getAuthPasswordBytes() {
            return ByteString.n(this.authPassword_);
        }

        public String getAuthUsername() {
            return this.authUsername_;
        }

        public ByteString getAuthUsernameBytes() {
            return ByteString.n(this.authUsername_);
        }

        public String getDestinationCountry() {
            return this.destinationCountry_;
        }

        public ByteString getDestinationCountryBytes() {
            return ByteString.n(this.destinationCountry_);
        }

        @Deprecated
        public Map<String, String> getHeaders() {
            return getHeadersMap();
        }

        public int getHeadersCount() {
            return internalGetHeaders().size();
        }

        public Map<String, String> getHeadersMap() {
            return Collections.unmodifiableMap(internalGetHeaders());
        }

        public String getHeadersOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeaders = internalGetHeaders();
            return mapFieldLiteInternalGetHeaders.containsKey(str) ? (String) mapFieldLiteInternalGetHeaders.get(str) : str2;
        }

        public String getHeadersOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeaders = internalGetHeaders();
            if (mapFieldLiteInternalGetHeaders.containsKey(str)) {
                return (String) mapFieldLiteInternalGetHeaders.get(str);
            }
            throw new IllegalArgumentException();
        }

        @Deprecated
        public Map<String, String> getHeadersToAttributes() {
            return getHeadersToAttributesMap();
        }

        public int getHeadersToAttributesCount() {
            return internalGetHeadersToAttributes().size();
        }

        public Map<String, String> getHeadersToAttributesMap() {
            return Collections.unmodifiableMap(internalGetHeadersToAttributes());
        }

        public String getHeadersToAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeadersToAttributes = internalGetHeadersToAttributes();
            return mapFieldLiteInternalGetHeadersToAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetHeadersToAttributes.get(str) : str2;
        }

        public String getHeadersToAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeadersToAttributes = internalGetHeadersToAttributes();
            if (mapFieldLiteInternalGetHeadersToAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetHeadersToAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public SIPHeaderOptions getIncludeHeaders() {
            SIPHeaderOptions sIPHeaderOptionsB = SIPHeaderOptions.b(this.includeHeaders_);
            return sIPHeaderOptionsB == null ? SIPHeaderOptions.e : sIPHeaderOptionsB;
        }

        public int getIncludeHeadersValue() {
            return this.includeHeaders_;
        }

        public SIPMediaEncryption getMediaEncryption() {
            SIPMediaEncryption sIPMediaEncryptionB = SIPMediaEncryption.b(this.mediaEncryption_);
            return sIPMediaEncryptionB == null ? SIPMediaEncryption.e : sIPMediaEncryptionB;
        }

        public int getMediaEncryptionValue() {
            return this.mediaEncryption_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getNumbers(int i) {
            return (String) this.numbers_.get(i);
        }

        public ByteString getNumbersBytes(int i) {
            return ByteString.n((String) this.numbers_.get(i));
        }

        public int getNumbersCount() {
            return this.numbers_.size();
        }

        public List<String> getNumbersList() {
            return this.numbers_;
        }

        public String getSipTrunkId() {
            return this.sipTrunkId_;
        }

        public ByteString getSipTrunkIdBytes() {
            return ByteString.n(this.sipTrunkId_);
        }

        public SIPTransport getTransport() {
            SIPTransport sIPTransportB = SIPTransport.b(this.transport_);
            return sIPTransportB == null ? SIPTransport.f : sIPTransportB;
        }

        public int getTransportValue() {
            return this.transport_;
        }

        public static Builder newBuilder(SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPOutboundTrunkInfo);
        }

        public static SIPOutboundTrunkInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPOutboundTrunkInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPOutboundTrunkInfo parseFrom(ByteString byteString) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPOutboundTrunkInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPOutboundTrunkInfo parseFrom(byte[] bArr) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPOutboundTrunkInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPOutboundTrunkInfo parseFrom(InputStream inputStream) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPOutboundTrunkInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPOutboundTrunkInfo parseFrom(CodedInputStream codedInputStream) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPOutboundTrunkInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPOutboundTrunkInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPOutboundTrunkUpdate extends GeneratedMessageLite<SIPOutboundTrunkUpdate, Builder> implements SIPOutboundTrunkUpdateOrBuilder {
        public static final int ADDRESS_FIELD_NUMBER = 1;
        public static final int AUTH_PASSWORD_FIELD_NUMBER = 5;
        public static final int AUTH_USERNAME_FIELD_NUMBER = 4;
        private static final SIPOutboundTrunkUpdate DEFAULT_INSTANCE;
        public static final int DESTINATION_COUNTRY_FIELD_NUMBER = 9;
        public static final int MEDIA_ENCRYPTION_FIELD_NUMBER = 8;
        public static final int METADATA_FIELD_NUMBER = 7;
        public static final int NAME_FIELD_NUMBER = 6;
        public static final int NUMBERS_FIELD_NUMBER = 3;
        private static volatile Parser<SIPOutboundTrunkUpdate> PARSER = null;
        public static final int TRANSPORT_FIELD_NUMBER = 2;
        private String address_;
        private String authPassword_;
        private String authUsername_;
        private int bitField0_;
        private String destinationCountry_;
        private int mediaEncryption_;
        private String metadata_;
        private String name_;
        private LivekitModels.ListUpdate numbers_;
        private int transport_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPOutboundTrunkUpdate, Builder> implements SIPOutboundTrunkUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPOutboundTrunkUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            SIPOutboundTrunkUpdate sIPOutboundTrunkUpdate = new SIPOutboundTrunkUpdate();
            DEFAULT_INSTANCE = sIPOutboundTrunkUpdate;
            GeneratedMessageLite.registerDefaultInstance(SIPOutboundTrunkUpdate.class, sIPOutboundTrunkUpdate);
        }

        private SIPOutboundTrunkUpdate() {
            String strA = ap.a(1022114594);
            this.address_ = strA;
            this.destinationCountry_ = strA;
            this.authUsername_ = strA;
            this.authPassword_ = strA;
            this.name_ = strA;
            this.metadata_ = strA;
        }

        private void clearAddress() {
            this.bitField0_ &= -2;
            this.address_ = getDefaultInstance().getAddress();
        }

        private void clearAuthPassword() {
            this.bitField0_ &= -17;
            this.authPassword_ = getDefaultInstance().getAuthPassword();
        }

        private void clearAuthUsername() {
            this.bitField0_ &= -9;
            this.authUsername_ = getDefaultInstance().getAuthUsername();
        }

        private void clearDestinationCountry() {
            this.bitField0_ &= -5;
            this.destinationCountry_ = getDefaultInstance().getDestinationCountry();
        }

        private void clearMediaEncryption() {
            this.bitField0_ &= -129;
            this.mediaEncryption_ = 0;
        }

        private void clearMetadata() {
            this.bitField0_ &= -65;
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.bitField0_ &= -33;
            this.name_ = getDefaultInstance().getName();
        }

        private void clearNumbers() {
            this.numbers_ = null;
        }

        private void clearTransport() {
            this.bitField0_ &= -3;
            this.transport_ = 0;
        }

        public static SIPOutboundTrunkUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeNumbers(LivekitModels.ListUpdate listUpdate) {
            listUpdate.getClass();
            LivekitModels.ListUpdate listUpdate2 = this.numbers_;
            if (listUpdate2 == null || listUpdate2 == LivekitModels.ListUpdate.getDefaultInstance()) {
                this.numbers_ = listUpdate;
            } else {
                this.numbers_ = (LivekitModels.ListUpdate) ((LivekitModels.ListUpdate.Builder) LivekitModels.ListUpdate.newBuilder(this.numbers_).v(listUpdate)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPOutboundTrunkUpdate parseDelimitedFrom(InputStream inputStream) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPOutboundTrunkUpdate parseFrom(ByteBuffer byteBuffer) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPOutboundTrunkUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAddress(String str) {
            str.getClass();
            this.bitField0_ |= 1;
            this.address_ = str;
        }

        private void setAddressBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.address_ = byteString.L();
            this.bitField0_ |= 1;
        }

        private void setAuthPassword(String str) {
            str.getClass();
            this.bitField0_ |= 16;
            this.authPassword_ = str;
        }

        private void setAuthPasswordBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.authPassword_ = byteString.L();
            this.bitField0_ |= 16;
        }

        private void setAuthUsername(String str) {
            str.getClass();
            this.bitField0_ |= 8;
            this.authUsername_ = str;
        }

        private void setAuthUsernameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.authUsername_ = byteString.L();
            this.bitField0_ |= 8;
        }

        private void setDestinationCountry(String str) {
            str.getClass();
            this.bitField0_ |= 4;
            this.destinationCountry_ = str;
        }

        private void setDestinationCountryBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.destinationCountry_ = byteString.L();
            this.bitField0_ |= 4;
        }

        private void setMediaEncryption(SIPMediaEncryption sIPMediaEncryption) {
            this.mediaEncryption_ = sIPMediaEncryption.getNumber();
            this.bitField0_ |= 128;
        }

        private void setMediaEncryptionValue(int i) {
            this.bitField0_ |= 128;
            this.mediaEncryption_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.bitField0_ |= 64;
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
            this.bitField0_ |= 64;
        }

        private void setName(String str) {
            str.getClass();
            this.bitField0_ |= 32;
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
            this.bitField0_ |= 32;
        }

        private void setNumbers(LivekitModels.ListUpdate listUpdate) {
            listUpdate.getClass();
            this.numbers_ = listUpdate;
        }

        private void setTransport(SIPTransport sIPTransport) {
            this.transport_ = sIPTransport.getNumber();
            this.bitField0_ |= 2;
        }

        private void setTransportValue(int i) {
            this.bitField0_ |= 2;
            this.transport_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPOutboundTrunkUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\t\u0000\u0001\u0001\t\t\u0000\u0000\u0000\u0001ለ\u0000\u0002ဌ\u0001\u0003\t\u0004ለ\u0003\u0005ለ\u0004\u0006ለ\u0005\u0007ለ\u0006\bဌ\u0007\tለ\u0002", new Object[]{"bitField0_", "address_", "transport_", "numbers_", "authUsername_", "authPassword_", "name_", "metadata_", "mediaEncryption_", "destinationCountry_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPOutboundTrunkUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPOutboundTrunkUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAddress() {
            return this.address_;
        }

        public ByteString getAddressBytes() {
            return ByteString.n(this.address_);
        }

        public String getAuthPassword() {
            return this.authPassword_;
        }

        public ByteString getAuthPasswordBytes() {
            return ByteString.n(this.authPassword_);
        }

        public String getAuthUsername() {
            return this.authUsername_;
        }

        public ByteString getAuthUsernameBytes() {
            return ByteString.n(this.authUsername_);
        }

        public String getDestinationCountry() {
            return this.destinationCountry_;
        }

        public ByteString getDestinationCountryBytes() {
            return ByteString.n(this.destinationCountry_);
        }

        public SIPMediaEncryption getMediaEncryption() {
            SIPMediaEncryption sIPMediaEncryptionB = SIPMediaEncryption.b(this.mediaEncryption_);
            return sIPMediaEncryptionB == null ? SIPMediaEncryption.e : sIPMediaEncryptionB;
        }

        public int getMediaEncryptionValue() {
            return this.mediaEncryption_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public LivekitModels.ListUpdate getNumbers() {
            LivekitModels.ListUpdate listUpdate = this.numbers_;
            return listUpdate == null ? LivekitModels.ListUpdate.getDefaultInstance() : listUpdate;
        }

        public SIPTransport getTransport() {
            SIPTransport sIPTransportB = SIPTransport.b(this.transport_);
            return sIPTransportB == null ? SIPTransport.f : sIPTransportB;
        }

        public int getTransportValue() {
            return this.transport_;
        }

        public boolean hasAddress() {
            return (this.bitField0_ & 1) != 0;
        }

        public boolean hasAuthPassword() {
            return (this.bitField0_ & 16) != 0;
        }

        public boolean hasAuthUsername() {
            return (this.bitField0_ & 8) != 0;
        }

        public boolean hasDestinationCountry() {
            return (this.bitField0_ & 4) != 0;
        }

        public boolean hasMediaEncryption() {
            return (this.bitField0_ & 128) != 0;
        }

        public boolean hasMetadata() {
            return (this.bitField0_ & 64) != 0;
        }

        public boolean hasName() {
            return (this.bitField0_ & 32) != 0;
        }

        public boolean hasNumbers() {
            return this.numbers_ != null;
        }

        public boolean hasTransport() {
            return (this.bitField0_ & 2) != 0;
        }

        public static Builder newBuilder(SIPOutboundTrunkUpdate sIPOutboundTrunkUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPOutboundTrunkUpdate);
        }

        public static SIPOutboundTrunkUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPOutboundTrunkUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPOutboundTrunkUpdate parseFrom(ByteString byteString) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPOutboundTrunkUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPOutboundTrunkUpdate parseFrom(byte[] bArr) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPOutboundTrunkUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPOutboundTrunkUpdate parseFrom(InputStream inputStream) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPOutboundTrunkUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPOutboundTrunkUpdate parseFrom(CodedInputStream codedInputStream) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPOutboundTrunkUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPOutboundTrunkUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPOutboundTrunkUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPParticipantInfo extends GeneratedMessageLite<SIPParticipantInfo, Builder> implements SIPParticipantInfoOrBuilder {
        private static final SIPParticipantInfo DEFAULT_INSTANCE;
        private static volatile Parser<SIPParticipantInfo> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 2;
        public static final int PARTICIPANT_ID_FIELD_NUMBER = 1;
        public static final int ROOM_NAME_FIELD_NUMBER = 3;
        public static final int SIP_CALL_ID_FIELD_NUMBER = 4;
        private String participantId_;
        private String participantIdentity_;
        private String roomName_;
        private String sipCallId_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPParticipantInfo, Builder> implements SIPParticipantInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPParticipantInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            SIPParticipantInfo sIPParticipantInfo = new SIPParticipantInfo();
            DEFAULT_INSTANCE = sIPParticipantInfo;
            GeneratedMessageLite.registerDefaultInstance(SIPParticipantInfo.class, sIPParticipantInfo);
        }

        private SIPParticipantInfo() {
            String strA = ap.a(530866588);
            this.participantId_ = strA;
            this.participantIdentity_ = strA;
            this.roomName_ = strA;
            this.sipCallId_ = strA;
        }

        private void clearParticipantId() {
            this.participantId_ = getDefaultInstance().getParticipantId();
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearSipCallId() {
            this.sipCallId_ = getDefaultInstance().getSipCallId();
        }

        public static SIPParticipantInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPParticipantInfo parseDelimitedFrom(InputStream inputStream) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPParticipantInfo parseFrom(ByteBuffer byteBuffer) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPParticipantInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setParticipantId(String str) {
            str.getClass();
            this.participantId_ = str;
        }

        private void setParticipantIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantId_ = byteString.L();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setSipCallId(String str) {
            str.getClass();
            this.sipCallId_ = str;
        }

        private void setSipCallIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipCallId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPParticipantInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ", new Object[]{"participantId_", "participantIdentity_", "roomName_", "sipCallId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPParticipantInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPParticipantInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getParticipantId() {
            return this.participantId_;
        }

        public ByteString getParticipantIdBytes() {
            return ByteString.n(this.participantId_);
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public String getSipCallId() {
            return this.sipCallId_;
        }

        public ByteString getSipCallIdBytes() {
            return ByteString.n(this.sipCallId_);
        }

        public static Builder newBuilder(SIPParticipantInfo sIPParticipantInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPParticipantInfo);
        }

        public static SIPParticipantInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPParticipantInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPParticipantInfo parseFrom(ByteString byteString) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPParticipantInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPParticipantInfo parseFrom(byte[] bArr) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPParticipantInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPParticipantInfo parseFrom(InputStream inputStream) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPParticipantInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPParticipantInfo parseFrom(CodedInputStream codedInputStream) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPParticipantInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPParticipantInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPStatus extends GeneratedMessageLite<SIPStatus, Builder> implements SIPStatusOrBuilder {
        public static final int CODE_FIELD_NUMBER = 1;
        private static final SIPStatus DEFAULT_INSTANCE;
        private static volatile Parser<SIPStatus> PARSER = null;
        public static final int STATUS_FIELD_NUMBER = 2;
        private int code_;
        private String status_ = ap.a(765978691);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPStatus, Builder> implements SIPStatusOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPStatus.DEFAULT_INSTANCE);
            }
        }

        static {
            SIPStatus sIPStatus = new SIPStatus();
            DEFAULT_INSTANCE = sIPStatus;
            GeneratedMessageLite.registerDefaultInstance(SIPStatus.class, sIPStatus);
        }

        private SIPStatus() {
        }

        private void clearCode() {
            this.code_ = 0;
        }

        private void clearStatus() {
            this.status_ = getDefaultInstance().getStatus();
        }

        public static SIPStatus getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPStatus parseDelimitedFrom(InputStream inputStream) {
            return (SIPStatus) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPStatus parseFrom(ByteBuffer byteBuffer) {
            return (SIPStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPStatus> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCode(SIPStatusCode sIPStatusCode) {
            this.code_ = sIPStatusCode.getNumber();
        }

        private void setCodeValue(int i) {
            this.code_ = i;
        }

        private void setStatus(String str) {
            str.getClass();
            this.status_ = str;
        }

        private void setStatusBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.status_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPStatus();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\f\u0002Ȉ", new Object[]{"code_", "status_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPStatus> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPStatus.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SIPStatusCode getCode() {
            SIPStatusCode sIPStatusCodeB = SIPStatusCode.b(this.code_);
            return sIPStatusCodeB == null ? SIPStatusCode.J0 : sIPStatusCodeB;
        }

        public int getCodeValue() {
            return this.code_;
        }

        public String getStatus() {
            return this.status_;
        }

        public ByteString getStatusBytes() {
            return ByteString.n(this.status_);
        }

        public static Builder newBuilder(SIPStatus sIPStatus) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPStatus);
        }

        public static SIPStatus parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPStatus) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPStatus parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPStatus parseFrom(ByteString byteString) {
            return (SIPStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPStatus parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPStatus parseFrom(byte[] bArr) {
            return (SIPStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPStatus parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPStatus parseFrom(InputStream inputStream) {
            return (SIPStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPStatus parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPStatus parseFrom(CodedInputStream codedInputStream) {
            return (SIPStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPStatus parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SIPStatusCode implements Internal.EnumLite {
        b(0),
        c(100),
        d(180),
        e(181),
        f(182),
        g(183),
        h(200),
        i(202),
        j(301),
        k(302),
        l(305),
        m(400),
        n(401),
        o(402),
        p(403),
        q(404),
        r(405),
        s(406),
        t(407),
        u(408),
        v(409),
        w(410),
        x(413),
        y(414),
        z(415),
        A(416),
        B(420),
        D(421),
        G(423),
        H(480),
        J(481),
        N(482),
        Y(483),
        Z(484),
        u0(485),
        v0(486),
        w0(487),
        x0(488),
        y0(500),
        z0(501),
        A0(502),
        B0(503),
        C0(504),
        D0(505),
        E0(513),
        F0(PipesConfigBase.DEFAULT_STALE_FETCHER_TIMEOUT_SECONDS),
        G0(603),
        H0(604),
        I0(606),
        J0(-1);

        private static final Internal.EnumLiteMap K0 = new Internal.EnumLiteMap<SIPStatusCode>() { // from class: livekit.LivekitSip.SIPStatusCode.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SIPStatusCode findValueByNumber(int i2) {
                return SIPStatusCode.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SIPStatusCodeVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SIPStatusCodeVerifier();

            private SIPStatusCodeVerifier() {
            }

            public boolean isInRange(int i) {
                return SIPStatusCode.b(i) != null;
            }
        }

        SIPStatusCode(int i2) {
            this.a = i2;
        }

        public static SIPStatusCode b(int i2) {
            if (i2 == 0) {
                return b;
            }
            if (i2 == 100) {
                return c;
            }
            if (i2 == 200) {
                return h;
            }
            if (i2 == 202) {
                return i;
            }
            if (i2 == 305) {
                return l;
            }
            if (i2 == 423) {
                return G;
            }
            if (i2 == 513) {
                return E0;
            }
            if (i2 == 600) {
                return F0;
            }
            if (i2 == 606) {
                return I0;
            }
            if (i2 == 301) {
                return j;
            }
            if (i2 == 302) {
                return k;
            }
            if (i2 == 420) {
                return B;
            }
            if (i2 == 421) {
                return D;
            }
            if (i2 == 603) {
                return G0;
            }
            if (i2 == 604) {
                return H0;
            }
            switch (i2) {
                case 180:
                    return d;
                case 181:
                    return e;
                case 182:
                    return f;
                case 183:
                    return g;
                default:
                    switch (i2) {
                        case 400:
                            return m;
                        case 401:
                            return n;
                        case 402:
                            return o;
                        case 403:
                            return p;
                        case 404:
                            return q;
                        case 405:
                            return r;
                        case 406:
                            return s;
                        case 407:
                            return t;
                        case 408:
                            return u;
                        case 409:
                            return v;
                        case 410:
                            return w;
                        default:
                            switch (i2) {
                                case 413:
                                    return x;
                                case 414:
                                    return y;
                                case 415:
                                    return z;
                                case 416:
                                    return A;
                                default:
                                    switch (i2) {
                                        case 480:
                                            return H;
                                        case 481:
                                            return J;
                                        case 482:
                                            return N;
                                        case 483:
                                            return Y;
                                        case 484:
                                            return Z;
                                        case 485:
                                            return u0;
                                        case 486:
                                            return v0;
                                        case 487:
                                            return w0;
                                        case 488:
                                            return x0;
                                        default:
                                            switch (i2) {
                                                case 500:
                                                    return y0;
                                                case 501:
                                                    return z0;
                                                case 502:
                                                    return A0;
                                                case 503:
                                                    return B0;
                                                case 504:
                                                    return C0;
                                                case 505:
                                                    return D0;
                                                default:
                                                    return null;
                                            }
                                    }
                            }
                    }
            }
        }

        public final int getNumber() {
            if (this != J0) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPStatusOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPTransferInfo extends GeneratedMessageLite<SIPTransferInfo, Builder> implements SIPTransferInfoOrBuilder {
        public static final int CALL_ID_FIELD_NUMBER = 2;
        private static final SIPTransferInfo DEFAULT_INSTANCE;
        public static final int ERROR_FIELD_NUMBER = 7;
        private static volatile Parser<SIPTransferInfo> PARSER = null;
        public static final int TRANSFER_COMPLETED_AT_NS_FIELD_NUMBER = 5;
        public static final int TRANSFER_ID_FIELD_NUMBER = 1;
        public static final int TRANSFER_INITIATED_AT_NS_FIELD_NUMBER = 4;
        public static final int TRANSFER_STATUS_CODE_FIELD_NUMBER = 8;
        public static final int TRANSFER_STATUS_FIELD_NUMBER = 6;
        public static final int TRANSFER_TO_FIELD_NUMBER = 3;
        private String callId_;
        private String error_;
        private long transferCompletedAtNs_;
        private String transferId_;
        private long transferInitiatedAtNs_;
        private SIPStatus transferStatusCode_;
        private int transferStatus_;
        private String transferTo_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPTransferInfo, Builder> implements SIPTransferInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPTransferInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            SIPTransferInfo sIPTransferInfo = new SIPTransferInfo();
            DEFAULT_INSTANCE = sIPTransferInfo;
            GeneratedMessageLite.registerDefaultInstance(SIPTransferInfo.class, sIPTransferInfo);
        }

        private SIPTransferInfo() {
            String strA = ap.a(1602881117);
            this.transferId_ = strA;
            this.callId_ = strA;
            this.transferTo_ = strA;
            this.error_ = strA;
        }

        private void clearCallId() {
            this.callId_ = getDefaultInstance().getCallId();
        }

        private void clearError() {
            this.error_ = getDefaultInstance().getError();
        }

        private void clearTransferCompletedAtNs() {
            this.transferCompletedAtNs_ = 0L;
        }

        private void clearTransferId() {
            this.transferId_ = getDefaultInstance().getTransferId();
        }

        private void clearTransferInitiatedAtNs() {
            this.transferInitiatedAtNs_ = 0L;
        }

        private void clearTransferStatus() {
            this.transferStatus_ = 0;
        }

        private void clearTransferStatusCode() {
            this.transferStatusCode_ = null;
        }

        private void clearTransferTo() {
            this.transferTo_ = getDefaultInstance().getTransferTo();
        }

        public static SIPTransferInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeTransferStatusCode(SIPStatus sIPStatus) {
            sIPStatus.getClass();
            SIPStatus sIPStatus2 = this.transferStatusCode_;
            if (sIPStatus2 == null || sIPStatus2 == SIPStatus.getDefaultInstance()) {
                this.transferStatusCode_ = sIPStatus;
            } else {
                this.transferStatusCode_ = (SIPStatus) ((SIPStatus.Builder) SIPStatus.newBuilder(this.transferStatusCode_).v(sIPStatus)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPTransferInfo parseDelimitedFrom(InputStream inputStream) {
            return (SIPTransferInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPTransferInfo parseFrom(ByteBuffer byteBuffer) {
            return (SIPTransferInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPTransferInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCallId(String str) {
            str.getClass();
            this.callId_ = str;
        }

        private void setCallIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.callId_ = byteString.L();
        }

        private void setError(String str) {
            str.getClass();
            this.error_ = str;
        }

        private void setErrorBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.error_ = byteString.L();
        }

        private void setTransferCompletedAtNs(long j) {
            this.transferCompletedAtNs_ = j;
        }

        private void setTransferId(String str) {
            str.getClass();
            this.transferId_ = str;
        }

        private void setTransferIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.transferId_ = byteString.L();
        }

        private void setTransferInitiatedAtNs(long j) {
            this.transferInitiatedAtNs_ = j;
        }

        private void setTransferStatus(SIPTransferStatus sIPTransferStatus) {
            this.transferStatus_ = sIPTransferStatus.getNumber();
        }

        private void setTransferStatusCode(SIPStatus sIPStatus) {
            sIPStatus.getClass();
            this.transferStatusCode_ = sIPStatus;
        }

        private void setTransferStatusValue(int i) {
            this.transferStatus_ = i;
        }

        private void setTransferTo(String str) {
            str.getClass();
            this.transferTo_ = str;
        }

        private void setTransferToBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.transferTo_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPTransferInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\b\u0000\u0000\u0001\b\b\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\u0002\u0005\u0002\u0006\f\u0007Ȉ\b\t", new Object[]{"transferId_", "callId_", "transferTo_", "transferInitiatedAtNs_", "transferCompletedAtNs_", "transferStatus_", "error_", "transferStatusCode_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPTransferInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPTransferInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getCallId() {
            return this.callId_;
        }

        public ByteString getCallIdBytes() {
            return ByteString.n(this.callId_);
        }

        public String getError() {
            return this.error_;
        }

        public ByteString getErrorBytes() {
            return ByteString.n(this.error_);
        }

        public long getTransferCompletedAtNs() {
            return this.transferCompletedAtNs_;
        }

        public String getTransferId() {
            return this.transferId_;
        }

        public ByteString getTransferIdBytes() {
            return ByteString.n(this.transferId_);
        }

        public long getTransferInitiatedAtNs() {
            return this.transferInitiatedAtNs_;
        }

        public SIPTransferStatus getTransferStatus() {
            SIPTransferStatus sIPTransferStatusB = SIPTransferStatus.b(this.transferStatus_);
            return sIPTransferStatusB == null ? SIPTransferStatus.e : sIPTransferStatusB;
        }

        public SIPStatus getTransferStatusCode() {
            SIPStatus sIPStatus = this.transferStatusCode_;
            return sIPStatus == null ? SIPStatus.getDefaultInstance() : sIPStatus;
        }

        public int getTransferStatusValue() {
            return this.transferStatus_;
        }

        public String getTransferTo() {
            return this.transferTo_;
        }

        public ByteString getTransferToBytes() {
            return ByteString.n(this.transferTo_);
        }

        public boolean hasTransferStatusCode() {
            return this.transferStatusCode_ != null;
        }

        public static Builder newBuilder(SIPTransferInfo sIPTransferInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPTransferInfo);
        }

        public static SIPTransferInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTransferInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPTransferInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTransferInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPTransferInfo parseFrom(ByteString byteString) {
            return (SIPTransferInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPTransferInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTransferInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPTransferInfo parseFrom(byte[] bArr) {
            return (SIPTransferInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPTransferInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTransferInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPTransferInfo parseFrom(InputStream inputStream) {
            return (SIPTransferInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPTransferInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTransferInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPTransferInfo parseFrom(CodedInputStream codedInputStream) {
            return (SIPTransferInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPTransferInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTransferInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPTransferInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SIPTransferStatus implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<SIPTransferStatus>() { // from class: livekit.LivekitSip.SIPTransferStatus.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SIPTransferStatus findValueByNumber(int i) {
                return SIPTransferStatus.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SIPTransferStatusVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SIPTransferStatusVerifier();

            private SIPTransferStatusVerifier() {
            }

            public boolean isInRange(int i) {
                return SIPTransferStatus.b(i) != null;
            }
        }

        SIPTransferStatus(int i) {
            this.a = i;
        }

        public static SIPTransferStatus b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SIPTransport implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(-1);

        private static final Internal.EnumLiteMap g = new Internal.EnumLiteMap<SIPTransport>() { // from class: livekit.LivekitSip.SIPTransport.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SIPTransport findValueByNumber(int i) {
                return SIPTransport.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SIPTransportVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SIPTransportVerifier();

            private SIPTransportVerifier() {
            }

            public boolean isInRange(int i) {
                return SIPTransport.b(i) != null;
            }
        }

        SIPTransport(int i) {
            this.a = i;
        }

        public static SIPTransport b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i == 2) {
                return d;
            }
            if (i != 3) {
                return null;
            }
            return e;
        }

        public final int getNumber() {
            if (this != f) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public static final class SIPTrunkInfo extends GeneratedMessageLite<SIPTrunkInfo, Builder> implements SIPTrunkInfoOrBuilder {
        private static final SIPTrunkInfo DEFAULT_INSTANCE;
        public static final int INBOUND_ADDRESSES_FIELD_NUMBER = 2;
        public static final int INBOUND_NUMBERS_FIELD_NUMBER = 10;
        public static final int INBOUND_NUMBERS_REGEX_FIELD_NUMBER = 5;
        public static final int INBOUND_PASSWORD_FIELD_NUMBER = 7;
        public static final int INBOUND_USERNAME_FIELD_NUMBER = 6;
        public static final int KIND_FIELD_NUMBER = 14;
        public static final int METADATA_FIELD_NUMBER = 12;
        public static final int NAME_FIELD_NUMBER = 11;
        public static final int OUTBOUND_ADDRESS_FIELD_NUMBER = 3;
        public static final int OUTBOUND_NUMBER_FIELD_NUMBER = 4;
        public static final int OUTBOUND_PASSWORD_FIELD_NUMBER = 9;
        public static final int OUTBOUND_USERNAME_FIELD_NUMBER = 8;
        private static volatile Parser<SIPTrunkInfo> PARSER = null;
        public static final int SIP_TRUNK_ID_FIELD_NUMBER = 1;
        public static final int TRANSPORT_FIELD_NUMBER = 13;
        private Internal.ProtobufList<String> inboundAddresses_;
        private Internal.ProtobufList<String> inboundNumbersRegex_;
        private Internal.ProtobufList<String> inboundNumbers_;
        private String inboundPassword_;
        private String inboundUsername_;
        private int kind_;
        private String metadata_;
        private String name_;
        private String outboundAddress_;
        private String outboundNumber_;
        private String outboundPassword_;
        private String outboundUsername_;
        private String sipTrunkId_;
        private int transport_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPTrunkInfo, Builder> implements SIPTrunkInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPTrunkInfo.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum TrunkKind implements Internal.EnumLite {
            b(0),
            c(1),
            d(2),
            e(-1);

            private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<TrunkKind>() { // from class: livekit.LivekitSip.SIPTrunkInfo.TrunkKind.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public TrunkKind findValueByNumber(int i) {
                    return TrunkKind.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class TrunkKindVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new TrunkKindVerifier();

                private TrunkKindVerifier() {
                }

                public boolean isInRange(int i) {
                    return TrunkKind.b(i) != null;
                }
            }

            TrunkKind(int i) {
                this.a = i;
            }

            public static TrunkKind b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i == 1) {
                    return c;
                }
                if (i != 2) {
                    return null;
                }
                return d;
            }

            public final int getNumber() {
                if (this != e) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        static {
            SIPTrunkInfo sIPTrunkInfo = new SIPTrunkInfo();
            DEFAULT_INSTANCE = sIPTrunkInfo;
            GeneratedMessageLite.registerDefaultInstance(SIPTrunkInfo.class, sIPTrunkInfo);
        }

        private SIPTrunkInfo() {
            String strA = ap.a(1854467614);
            this.sipTrunkId_ = strA;
            this.inboundAddresses_ = GeneratedMessageLite.emptyProtobufList();
            this.outboundAddress_ = strA;
            this.outboundNumber_ = strA;
            this.inboundNumbersRegex_ = GeneratedMessageLite.emptyProtobufList();
            this.inboundNumbers_ = GeneratedMessageLite.emptyProtobufList();
            this.inboundUsername_ = strA;
            this.inboundPassword_ = strA;
            this.outboundUsername_ = strA;
            this.outboundPassword_ = strA;
            this.name_ = strA;
            this.metadata_ = strA;
        }

        private void addAllInboundAddresses(Iterable<String> iterable) {
            ensureInboundAddressesIsMutable();
            AbstractMessageLite.addAll(iterable, this.inboundAddresses_);
        }

        private void addAllInboundNumbers(Iterable<String> iterable) {
            ensureInboundNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.inboundNumbers_);
        }

        private void addAllInboundNumbersRegex(Iterable<String> iterable) {
            ensureInboundNumbersRegexIsMutable();
            AbstractMessageLite.addAll(iterable, this.inboundNumbersRegex_);
        }

        private void addInboundAddresses(String str) {
            str.getClass();
            ensureInboundAddressesIsMutable();
            this.inboundAddresses_.add(str);
        }

        private void addInboundAddressesBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureInboundAddressesIsMutable();
            this.inboundAddresses_.add(byteString.L());
        }

        private void addInboundNumbers(String str) {
            str.getClass();
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.add(str);
        }

        private void addInboundNumbersBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.add(byteString.L());
        }

        private void addInboundNumbersRegex(String str) {
            str.getClass();
            ensureInboundNumbersRegexIsMutable();
            this.inboundNumbersRegex_.add(str);
        }

        private void addInboundNumbersRegexBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureInboundNumbersRegexIsMutable();
            this.inboundNumbersRegex_.add(byteString.L());
        }

        private void clearInboundAddresses() {
            this.inboundAddresses_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearInboundNumbers() {
            this.inboundNumbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearInboundNumbersRegex() {
            this.inboundNumbersRegex_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearInboundPassword() {
            this.inboundPassword_ = getDefaultInstance().getInboundPassword();
        }

        private void clearInboundUsername() {
            this.inboundUsername_ = getDefaultInstance().getInboundUsername();
        }

        private void clearKind() {
            this.kind_ = 0;
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearOutboundAddress() {
            this.outboundAddress_ = getDefaultInstance().getOutboundAddress();
        }

        private void clearOutboundNumber() {
            this.outboundNumber_ = getDefaultInstance().getOutboundNumber();
        }

        private void clearOutboundPassword() {
            this.outboundPassword_ = getDefaultInstance().getOutboundPassword();
        }

        private void clearOutboundUsername() {
            this.outboundUsername_ = getDefaultInstance().getOutboundUsername();
        }

        private void clearSipTrunkId() {
            this.sipTrunkId_ = getDefaultInstance().getSipTrunkId();
        }

        private void clearTransport() {
            this.transport_ = 0;
        }

        private void ensureInboundAddressesIsMutable() {
            Internal.ProtobufList<String> protobufList = this.inboundAddresses_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.inboundAddresses_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureInboundNumbersIsMutable() {
            Internal.ProtobufList<String> protobufList = this.inboundNumbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.inboundNumbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureInboundNumbersRegexIsMutable() {
            Internal.ProtobufList<String> protobufList = this.inboundNumbersRegex_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.inboundNumbersRegex_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SIPTrunkInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPTrunkInfo parseDelimitedFrom(InputStream inputStream) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPTrunkInfo parseFrom(ByteBuffer byteBuffer) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPTrunkInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setInboundAddresses(int i, String str) {
            str.getClass();
            ensureInboundAddressesIsMutable();
            this.inboundAddresses_.set(i, str);
        }

        private void setInboundNumbers(int i, String str) {
            str.getClass();
            ensureInboundNumbersIsMutable();
            this.inboundNumbers_.set(i, str);
        }

        private void setInboundNumbersRegex(int i, String str) {
            str.getClass();
            ensureInboundNumbersRegexIsMutable();
            this.inboundNumbersRegex_.set(i, str);
        }

        private void setInboundPassword(String str) {
            str.getClass();
            this.inboundPassword_ = str;
        }

        private void setInboundPasswordBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.inboundPassword_ = byteString.L();
        }

        private void setInboundUsername(String str) {
            str.getClass();
            this.inboundUsername_ = str;
        }

        private void setInboundUsernameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.inboundUsername_ = byteString.L();
        }

        private void setKind(TrunkKind trunkKind) {
            this.kind_ = trunkKind.getNumber();
        }

        private void setKindValue(int i) {
            this.kind_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setOutboundAddress(String str) {
            str.getClass();
            this.outboundAddress_ = str;
        }

        private void setOutboundAddressBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.outboundAddress_ = byteString.L();
        }

        private void setOutboundNumber(String str) {
            str.getClass();
            this.outboundNumber_ = str;
        }

        private void setOutboundNumberBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.outboundNumber_ = byteString.L();
        }

        private void setOutboundPassword(String str) {
            str.getClass();
            this.outboundPassword_ = str;
        }

        private void setOutboundPasswordBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.outboundPassword_ = byteString.L();
        }

        private void setOutboundUsername(String str) {
            str.getClass();
            this.outboundUsername_ = str;
        }

        private void setOutboundUsernameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.outboundUsername_ = byteString.L();
        }

        private void setSipTrunkId(String str) {
            str.getClass();
            this.sipTrunkId_ = str;
        }

        private void setSipTrunkIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipTrunkId_ = byteString.L();
        }

        private void setTransport(SIPTransport sIPTransport) {
            this.transport_ = sIPTransport.getNumber();
        }

        private void setTransportValue(int i) {
            this.transport_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new SIPTrunkInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000e\u0000\u0000\u0001\u000e\u000e\u0000\u0003\u0000\u0001Ȉ\u0002Ț\u0003Ȉ\u0004Ȉ\u0005Ț\u0006Ȉ\u0007Ȉ\bȈ\tȈ\nȚ\u000bȈ\fȈ\r\f\u000e\f", new Object[]{"sipTrunkId_", "inboundAddresses_", "outboundAddress_", "outboundNumber_", "inboundNumbersRegex_", "inboundUsername_", "inboundPassword_", "outboundUsername_", "outboundPassword_", "inboundNumbers_", "name_", "metadata_", "transport_", "kind_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPTrunkInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPTrunkInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getInboundAddresses(int i) {
            return (String) this.inboundAddresses_.get(i);
        }

        public ByteString getInboundAddressesBytes(int i) {
            return ByteString.n((String) this.inboundAddresses_.get(i));
        }

        public int getInboundAddressesCount() {
            return this.inboundAddresses_.size();
        }

        public List<String> getInboundAddressesList() {
            return this.inboundAddresses_;
        }

        public String getInboundNumbers(int i) {
            return (String) this.inboundNumbers_.get(i);
        }

        public ByteString getInboundNumbersBytes(int i) {
            return ByteString.n((String) this.inboundNumbers_.get(i));
        }

        public int getInboundNumbersCount() {
            return this.inboundNumbers_.size();
        }

        public List<String> getInboundNumbersList() {
            return this.inboundNumbers_;
        }

        @Deprecated
        public String getInboundNumbersRegex(int i) {
            return (String) this.inboundNumbersRegex_.get(i);
        }

        @Deprecated
        public ByteString getInboundNumbersRegexBytes(int i) {
            return ByteString.n((String) this.inboundNumbersRegex_.get(i));
        }

        @Deprecated
        public int getInboundNumbersRegexCount() {
            return this.inboundNumbersRegex_.size();
        }

        @Deprecated
        public List<String> getInboundNumbersRegexList() {
            return this.inboundNumbersRegex_;
        }

        public String getInboundPassword() {
            return this.inboundPassword_;
        }

        public ByteString getInboundPasswordBytes() {
            return ByteString.n(this.inboundPassword_);
        }

        public String getInboundUsername() {
            return this.inboundUsername_;
        }

        public ByteString getInboundUsernameBytes() {
            return ByteString.n(this.inboundUsername_);
        }

        public TrunkKind getKind() {
            TrunkKind trunkKindB = TrunkKind.b(this.kind_);
            return trunkKindB == null ? TrunkKind.e : trunkKindB;
        }

        public int getKindValue() {
            return this.kind_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getOutboundAddress() {
            return this.outboundAddress_;
        }

        public ByteString getOutboundAddressBytes() {
            return ByteString.n(this.outboundAddress_);
        }

        public String getOutboundNumber() {
            return this.outboundNumber_;
        }

        public ByteString getOutboundNumberBytes() {
            return ByteString.n(this.outboundNumber_);
        }

        public String getOutboundPassword() {
            return this.outboundPassword_;
        }

        public ByteString getOutboundPasswordBytes() {
            return ByteString.n(this.outboundPassword_);
        }

        public String getOutboundUsername() {
            return this.outboundUsername_;
        }

        public ByteString getOutboundUsernameBytes() {
            return ByteString.n(this.outboundUsername_);
        }

        public String getSipTrunkId() {
            return this.sipTrunkId_;
        }

        public ByteString getSipTrunkIdBytes() {
            return ByteString.n(this.sipTrunkId_);
        }

        public SIPTransport getTransport() {
            SIPTransport sIPTransportB = SIPTransport.b(this.transport_);
            return sIPTransportB == null ? SIPTransport.f : sIPTransportB;
        }

        public int getTransportValue() {
            return this.transport_;
        }

        public static Builder newBuilder(SIPTrunkInfo sIPTrunkInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPTrunkInfo);
        }

        public static SIPTrunkInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPTrunkInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPTrunkInfo parseFrom(ByteString byteString) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPTrunkInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPTrunkInfo parseFrom(byte[] bArr) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPTrunkInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPTrunkInfo parseFrom(InputStream inputStream) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPTrunkInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPTrunkInfo parseFrom(CodedInputStream codedInputStream) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPTrunkInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPTrunkInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public interface SIPTrunkInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SIPUri extends GeneratedMessageLite<SIPUri, Builder> implements SIPUriOrBuilder {
        private static final SIPUri DEFAULT_INSTANCE;
        public static final int HOST_FIELD_NUMBER = 2;
        public static final int IP_FIELD_NUMBER = 3;
        private static volatile Parser<SIPUri> PARSER = null;
        public static final int PORT_FIELD_NUMBER = 4;
        public static final int TRANSPORT_FIELD_NUMBER = 5;
        public static final int USER_FIELD_NUMBER = 1;
        private String host_;
        private String ip_;
        private int port_;
        private int transport_;
        private String user_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SIPUri, Builder> implements SIPUriOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SIPUri.DEFAULT_INSTANCE);
            }
        }

        static {
            SIPUri sIPUri = new SIPUri();
            DEFAULT_INSTANCE = sIPUri;
            GeneratedMessageLite.registerDefaultInstance(SIPUri.class, sIPUri);
        }

        private SIPUri() {
            String strA = ap.a(604709147);
            this.user_ = strA;
            this.host_ = strA;
            this.ip_ = strA;
        }

        private void clearHost() {
            this.host_ = getDefaultInstance().getHost();
        }

        private void clearIp() {
            this.ip_ = getDefaultInstance().getIp();
        }

        private void clearPort() {
            this.port_ = 0;
        }

        private void clearTransport() {
            this.transport_ = 0;
        }

        private void clearUser() {
            this.user_ = getDefaultInstance().getUser();
        }

        public static SIPUri getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SIPUri parseDelimitedFrom(InputStream inputStream) {
            return (SIPUri) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPUri parseFrom(ByteBuffer byteBuffer) {
            return (SIPUri) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SIPUri> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setHost(String str) {
            str.getClass();
            this.host_ = str;
        }

        private void setHostBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.host_ = byteString.L();
        }

        private void setIp(String str) {
            str.getClass();
            this.ip_ = str;
        }

        private void setIpBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.ip_ = byteString.L();
        }

        private void setPort(int i) {
            this.port_ = i;
        }

        private void setTransport(SIPTransport sIPTransport) {
            this.transport_ = sIPTransport.getNumber();
        }

        private void setTransportValue(int i) {
            this.transport_ = i;
        }

        private void setUser(String str) {
            str.getClass();
            this.user_ = str;
        }

        private void setUserBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.user_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SIPUri();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\u000b\u0005\f", new Object[]{"user_", "host_", "ip_", "port_", "transport_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SIPUri> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SIPUri.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getHost() {
            return this.host_;
        }

        public ByteString getHostBytes() {
            return ByteString.n(this.host_);
        }

        public String getIp() {
            return this.ip_;
        }

        public ByteString getIpBytes() {
            return ByteString.n(this.ip_);
        }

        public int getPort() {
            return this.port_;
        }

        public SIPTransport getTransport() {
            SIPTransport sIPTransportB = SIPTransport.b(this.transport_);
            return sIPTransportB == null ? SIPTransport.f : sIPTransportB;
        }

        public int getTransportValue() {
            return this.transport_;
        }

        public String getUser() {
            return this.user_;
        }

        public ByteString getUserBytes() {
            return ByteString.n(this.user_);
        }

        public static Builder newBuilder(SIPUri sIPUri) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sIPUri);
        }

        public static SIPUri parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPUri) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPUri parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPUri) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SIPUri parseFrom(ByteString byteString) {
            return (SIPUri) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SIPUri parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPUri) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SIPUri parseFrom(byte[] bArr) {
            return (SIPUri) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SIPUri parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPUri) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SIPUri parseFrom(InputStream inputStream) {
            return (SIPUri) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SIPUri parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPUri) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SIPUri parseFrom(CodedInputStream codedInputStream) {
            return (SIPUri) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SIPUri parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SIPUri) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SIPUriOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TransferSIPParticipantRequest extends GeneratedMessageLite<TransferSIPParticipantRequest, Builder> implements TransferSIPParticipantRequestOrBuilder {
        private static final TransferSIPParticipantRequest DEFAULT_INSTANCE;
        public static final int HEADERS_FIELD_NUMBER = 5;
        private static volatile Parser<TransferSIPParticipantRequest> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 1;
        public static final int PLAY_DIALTONE_FIELD_NUMBER = 4;
        public static final int RINGING_TIMEOUT_FIELD_NUMBER = 6;
        public static final int ROOM_NAME_FIELD_NUMBER = 2;
        public static final int TRANSFER_TO_FIELD_NUMBER = 3;
        private MapFieldLite<String, String> headers_ = MapFieldLite.f();
        private String participantIdentity_;
        private boolean playDialtone_;
        private Duration ringingTimeout_;
        private String roomName_;
        private String transferTo_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TransferSIPParticipantRequest, Builder> implements TransferSIPParticipantRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TransferSIPParticipantRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class HeadersDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(523668099);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private HeadersDefaultEntryHolder() {
            }
        }

        static {
            TransferSIPParticipantRequest transferSIPParticipantRequest = new TransferSIPParticipantRequest();
            DEFAULT_INSTANCE = transferSIPParticipantRequest;
            GeneratedMessageLite.registerDefaultInstance(TransferSIPParticipantRequest.class, transferSIPParticipantRequest);
        }

        private TransferSIPParticipantRequest() {
            String strA = ap.a(220262700);
            this.participantIdentity_ = strA;
            this.roomName_ = strA;
            this.transferTo_ = strA;
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearPlayDialtone() {
            this.playDialtone_ = false;
        }

        private void clearRingingTimeout() {
            this.ringingTimeout_ = null;
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearTransferTo() {
            this.transferTo_ = getDefaultInstance().getTransferTo();
        }

        public static TransferSIPParticipantRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableHeadersMap() {
            return internalGetMutableHeaders();
        }

        private MapFieldLite<String, String> internalGetHeaders() {
            return this.headers_;
        }

        private MapFieldLite<String, String> internalGetMutableHeaders() {
            if (!this.headers_.k()) {
                this.headers_ = this.headers_.n();
            }
            return this.headers_;
        }

        private void mergeRingingTimeout(Duration duration) {
            duration.getClass();
            Duration duration2 = this.ringingTimeout_;
            if (duration2 == null || duration2 == Duration.getDefaultInstance()) {
                this.ringingTimeout_ = duration;
            } else {
                this.ringingTimeout_ = Duration.newBuilder(this.ringingTimeout_).v(duration).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TransferSIPParticipantRequest parseDelimitedFrom(InputStream inputStream) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TransferSIPParticipantRequest parseFrom(ByteBuffer byteBuffer) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TransferSIPParticipantRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setPlayDialtone(boolean z) {
            this.playDialtone_ = z;
        }

        private void setRingingTimeout(Duration duration) {
            duration.getClass();
            this.ringingTimeout_ = duration;
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setTransferTo(String str) {
            str.getClass();
            this.transferTo_ = str;
        }

        private void setTransferToBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.transferTo_ = byteString.L();
        }

        public boolean containsHeaders(String str) {
            str.getClass();
            return internalGetHeaders().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TransferSIPParticipantRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0001\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\u0007\u00052\u0006\t", new Object[]{"participantIdentity_", "roomName_", "transferTo_", "playDialtone_", "headers_", HeadersDefaultEntryHolder.a, "ringingTimeout_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TransferSIPParticipantRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TransferSIPParticipantRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public Map<String, String> getHeaders() {
            return getHeadersMap();
        }

        public int getHeadersCount() {
            return internalGetHeaders().size();
        }

        public Map<String, String> getHeadersMap() {
            return Collections.unmodifiableMap(internalGetHeaders());
        }

        public String getHeadersOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeaders = internalGetHeaders();
            return mapFieldLiteInternalGetHeaders.containsKey(str) ? (String) mapFieldLiteInternalGetHeaders.get(str) : str2;
        }

        public String getHeadersOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetHeaders = internalGetHeaders();
            if (mapFieldLiteInternalGetHeaders.containsKey(str)) {
                return (String) mapFieldLiteInternalGetHeaders.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public boolean getPlayDialtone() {
            return this.playDialtone_;
        }

        public Duration getRingingTimeout() {
            Duration duration = this.ringingTimeout_;
            return duration == null ? Duration.getDefaultInstance() : duration;
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public String getTransferTo() {
            return this.transferTo_;
        }

        public ByteString getTransferToBytes() {
            return ByteString.n(this.transferTo_);
        }

        public boolean hasRingingTimeout() {
            return this.ringingTimeout_ != null;
        }

        public static Builder newBuilder(TransferSIPParticipantRequest transferSIPParticipantRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(transferSIPParticipantRequest);
        }

        public static TransferSIPParticipantRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TransferSIPParticipantRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TransferSIPParticipantRequest parseFrom(ByteString byteString) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TransferSIPParticipantRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TransferSIPParticipantRequest parseFrom(byte[] bArr) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TransferSIPParticipantRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TransferSIPParticipantRequest parseFrom(InputStream inputStream) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TransferSIPParticipantRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TransferSIPParticipantRequest parseFrom(CodedInputStream codedInputStream) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TransferSIPParticipantRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TransferSIPParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TransferSIPParticipantRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateSIPDispatchRuleRequest extends GeneratedMessageLite<UpdateSIPDispatchRuleRequest, Builder> implements UpdateSIPDispatchRuleRequestOrBuilder {
        private static final UpdateSIPDispatchRuleRequest DEFAULT_INSTANCE;
        private static volatile Parser<UpdateSIPDispatchRuleRequest> PARSER = null;
        public static final int REPLACE_FIELD_NUMBER = 2;
        public static final int SIP_DISPATCH_RULE_ID_FIELD_NUMBER = 1;
        public static final int UPDATE_FIELD_NUMBER = 3;
        private Object action_;
        private int actionCase_ = 0;
        private String sipDispatchRuleId_ = ap.a(1539006012);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum ActionCase {
            b(2),
            c(3),
            d(0);

            private final int a;

            ActionCase(int i) {
                this.a = i;
            }

            public static ActionCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 2) {
                    return b;
                }
                if (i != 3) {
                    return null;
                }
                return c;
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateSIPDispatchRuleRequest, Builder> implements UpdateSIPDispatchRuleRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateSIPDispatchRuleRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateSIPDispatchRuleRequest updateSIPDispatchRuleRequest = new UpdateSIPDispatchRuleRequest();
            DEFAULT_INSTANCE = updateSIPDispatchRuleRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdateSIPDispatchRuleRequest.class, updateSIPDispatchRuleRequest);
        }

        private UpdateSIPDispatchRuleRequest() {
        }

        private void clearAction() {
            this.actionCase_ = 0;
            this.action_ = null;
        }

        private void clearReplace() {
            if (this.actionCase_ == 2) {
                this.actionCase_ = 0;
                this.action_ = null;
            }
        }

        private void clearSipDispatchRuleId() {
            this.sipDispatchRuleId_ = getDefaultInstance().getSipDispatchRuleId();
        }

        private void clearUpdate() {
            if (this.actionCase_ == 3) {
                this.actionCase_ = 0;
                this.action_ = null;
            }
        }

        public static UpdateSIPDispatchRuleRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeReplace(SIPDispatchRuleInfo sIPDispatchRuleInfo) {
            sIPDispatchRuleInfo.getClass();
            if (this.actionCase_ != 2 || this.action_ == SIPDispatchRuleInfo.getDefaultInstance()) {
                this.action_ = sIPDispatchRuleInfo;
            } else {
                this.action_ = ((SIPDispatchRuleInfo.Builder) SIPDispatchRuleInfo.newBuilder((SIPDispatchRuleInfo) this.action_).v(sIPDispatchRuleInfo)).o();
            }
            this.actionCase_ = 2;
        }

        private void mergeUpdate(SIPDispatchRuleUpdate sIPDispatchRuleUpdate) {
            sIPDispatchRuleUpdate.getClass();
            if (this.actionCase_ != 3 || this.action_ == SIPDispatchRuleUpdate.getDefaultInstance()) {
                this.action_ = sIPDispatchRuleUpdate;
            } else {
                this.action_ = ((SIPDispatchRuleUpdate.Builder) SIPDispatchRuleUpdate.newBuilder((SIPDispatchRuleUpdate) this.action_).v(sIPDispatchRuleUpdate)).o();
            }
            this.actionCase_ = 3;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateSIPDispatchRuleRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSIPDispatchRuleRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateSIPDispatchRuleRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setReplace(SIPDispatchRuleInfo sIPDispatchRuleInfo) {
            sIPDispatchRuleInfo.getClass();
            this.action_ = sIPDispatchRuleInfo;
            this.actionCase_ = 2;
        }

        private void setSipDispatchRuleId(String str) {
            str.getClass();
            this.sipDispatchRuleId_ = str;
        }

        private void setSipDispatchRuleIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipDispatchRuleId_ = byteString.L();
        }

        private void setUpdate(SIPDispatchRuleUpdate sIPDispatchRuleUpdate) {
            sIPDispatchRuleUpdate.getClass();
            this.action_ = sIPDispatchRuleUpdate;
            this.actionCase_ = 3;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateSIPDispatchRuleRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0001\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002<\u0000\u0003<\u0000", new Object[]{"action_", "actionCase_", "sipDispatchRuleId_", SIPDispatchRuleInfo.class, SIPDispatchRuleUpdate.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateSIPDispatchRuleRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateSIPDispatchRuleRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public ActionCase getActionCase() {
            return ActionCase.b(this.actionCase_);
        }

        public SIPDispatchRuleInfo getReplace() {
            return this.actionCase_ == 2 ? (SIPDispatchRuleInfo) this.action_ : SIPDispatchRuleInfo.getDefaultInstance();
        }

        public String getSipDispatchRuleId() {
            return this.sipDispatchRuleId_;
        }

        public ByteString getSipDispatchRuleIdBytes() {
            return ByteString.n(this.sipDispatchRuleId_);
        }

        public SIPDispatchRuleUpdate getUpdate() {
            return this.actionCase_ == 3 ? (SIPDispatchRuleUpdate) this.action_ : SIPDispatchRuleUpdate.getDefaultInstance();
        }

        public boolean hasReplace() {
            return this.actionCase_ == 2;
        }

        public boolean hasUpdate() {
            return this.actionCase_ == 3;
        }

        public static Builder newBuilder(UpdateSIPDispatchRuleRequest updateSIPDispatchRuleRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateSIPDispatchRuleRequest);
        }

        public static UpdateSIPDispatchRuleRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSIPDispatchRuleRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateSIPDispatchRuleRequest parseFrom(ByteString byteString) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateSIPDispatchRuleRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateSIPDispatchRuleRequest parseFrom(byte[] bArr) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateSIPDispatchRuleRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateSIPDispatchRuleRequest parseFrom(InputStream inputStream) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSIPDispatchRuleRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSIPDispatchRuleRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateSIPDispatchRuleRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPDispatchRuleRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateSIPDispatchRuleRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateSIPInboundTrunkRequest extends GeneratedMessageLite<UpdateSIPInboundTrunkRequest, Builder> implements UpdateSIPInboundTrunkRequestOrBuilder {
        private static final UpdateSIPInboundTrunkRequest DEFAULT_INSTANCE;
        private static volatile Parser<UpdateSIPInboundTrunkRequest> PARSER = null;
        public static final int REPLACE_FIELD_NUMBER = 2;
        public static final int SIP_TRUNK_ID_FIELD_NUMBER = 1;
        public static final int UPDATE_FIELD_NUMBER = 3;
        private Object action_;
        private int actionCase_ = 0;
        private String sipTrunkId_ = ap.a(406995900);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum ActionCase {
            b(2),
            c(3),
            d(0);

            private final int a;

            ActionCase(int i) {
                this.a = i;
            }

            public static ActionCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 2) {
                    return b;
                }
                if (i != 3) {
                    return null;
                }
                return c;
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateSIPInboundTrunkRequest, Builder> implements UpdateSIPInboundTrunkRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateSIPInboundTrunkRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateSIPInboundTrunkRequest updateSIPInboundTrunkRequest = new UpdateSIPInboundTrunkRequest();
            DEFAULT_INSTANCE = updateSIPInboundTrunkRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdateSIPInboundTrunkRequest.class, updateSIPInboundTrunkRequest);
        }

        private UpdateSIPInboundTrunkRequest() {
        }

        private void clearAction() {
            this.actionCase_ = 0;
            this.action_ = null;
        }

        private void clearReplace() {
            if (this.actionCase_ == 2) {
                this.actionCase_ = 0;
                this.action_ = null;
            }
        }

        private void clearSipTrunkId() {
            this.sipTrunkId_ = getDefaultInstance().getSipTrunkId();
        }

        private void clearUpdate() {
            if (this.actionCase_ == 3) {
                this.actionCase_ = 0;
                this.action_ = null;
            }
        }

        public static UpdateSIPInboundTrunkRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeReplace(SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            sIPInboundTrunkInfo.getClass();
            if (this.actionCase_ != 2 || this.action_ == SIPInboundTrunkInfo.getDefaultInstance()) {
                this.action_ = sIPInboundTrunkInfo;
            } else {
                this.action_ = ((SIPInboundTrunkInfo.Builder) SIPInboundTrunkInfo.newBuilder((SIPInboundTrunkInfo) this.action_).v(sIPInboundTrunkInfo)).o();
            }
            this.actionCase_ = 2;
        }

        private void mergeUpdate(SIPInboundTrunkUpdate sIPInboundTrunkUpdate) {
            sIPInboundTrunkUpdate.getClass();
            if (this.actionCase_ != 3 || this.action_ == SIPInboundTrunkUpdate.getDefaultInstance()) {
                this.action_ = sIPInboundTrunkUpdate;
            } else {
                this.action_ = ((SIPInboundTrunkUpdate.Builder) SIPInboundTrunkUpdate.newBuilder((SIPInboundTrunkUpdate) this.action_).v(sIPInboundTrunkUpdate)).o();
            }
            this.actionCase_ = 3;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateSIPInboundTrunkRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSIPInboundTrunkRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateSIPInboundTrunkRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setReplace(SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            sIPInboundTrunkInfo.getClass();
            this.action_ = sIPInboundTrunkInfo;
            this.actionCase_ = 2;
        }

        private void setSipTrunkId(String str) {
            str.getClass();
            this.sipTrunkId_ = str;
        }

        private void setSipTrunkIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipTrunkId_ = byteString.L();
        }

        private void setUpdate(SIPInboundTrunkUpdate sIPInboundTrunkUpdate) {
            sIPInboundTrunkUpdate.getClass();
            this.action_ = sIPInboundTrunkUpdate;
            this.actionCase_ = 3;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateSIPInboundTrunkRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0001\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002<\u0000\u0003<\u0000", new Object[]{"action_", "actionCase_", "sipTrunkId_", SIPInboundTrunkInfo.class, SIPInboundTrunkUpdate.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateSIPInboundTrunkRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateSIPInboundTrunkRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public ActionCase getActionCase() {
            return ActionCase.b(this.actionCase_);
        }

        public SIPInboundTrunkInfo getReplace() {
            return this.actionCase_ == 2 ? (SIPInboundTrunkInfo) this.action_ : SIPInboundTrunkInfo.getDefaultInstance();
        }

        public String getSipTrunkId() {
            return this.sipTrunkId_;
        }

        public ByteString getSipTrunkIdBytes() {
            return ByteString.n(this.sipTrunkId_);
        }

        public SIPInboundTrunkUpdate getUpdate() {
            return this.actionCase_ == 3 ? (SIPInboundTrunkUpdate) this.action_ : SIPInboundTrunkUpdate.getDefaultInstance();
        }

        public boolean hasReplace() {
            return this.actionCase_ == 2;
        }

        public boolean hasUpdate() {
            return this.actionCase_ == 3;
        }

        public static Builder newBuilder(UpdateSIPInboundTrunkRequest updateSIPInboundTrunkRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateSIPInboundTrunkRequest);
        }

        public static UpdateSIPInboundTrunkRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSIPInboundTrunkRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateSIPInboundTrunkRequest parseFrom(ByteString byteString) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateSIPInboundTrunkRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateSIPInboundTrunkRequest parseFrom(byte[] bArr) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateSIPInboundTrunkRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateSIPInboundTrunkRequest parseFrom(InputStream inputStream) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSIPInboundTrunkRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSIPInboundTrunkRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateSIPInboundTrunkRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPInboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateSIPInboundTrunkRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateSIPOutboundTrunkRequest extends GeneratedMessageLite<UpdateSIPOutboundTrunkRequest, Builder> implements UpdateSIPOutboundTrunkRequestOrBuilder {
        private static final UpdateSIPOutboundTrunkRequest DEFAULT_INSTANCE;
        private static volatile Parser<UpdateSIPOutboundTrunkRequest> PARSER = null;
        public static final int REPLACE_FIELD_NUMBER = 2;
        public static final int SIP_TRUNK_ID_FIELD_NUMBER = 1;
        public static final int UPDATE_FIELD_NUMBER = 3;
        private Object action_;
        private int actionCase_ = 0;
        private String sipTrunkId_ = ap.a(1310022035);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum ActionCase {
            b(2),
            c(3),
            d(0);

            private final int a;

            ActionCase(int i) {
                this.a = i;
            }

            public static ActionCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 2) {
                    return b;
                }
                if (i != 3) {
                    return null;
                }
                return c;
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateSIPOutboundTrunkRequest, Builder> implements UpdateSIPOutboundTrunkRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateSIPOutboundTrunkRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateSIPOutboundTrunkRequest updateSIPOutboundTrunkRequest = new UpdateSIPOutboundTrunkRequest();
            DEFAULT_INSTANCE = updateSIPOutboundTrunkRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdateSIPOutboundTrunkRequest.class, updateSIPOutboundTrunkRequest);
        }

        private UpdateSIPOutboundTrunkRequest() {
        }

        private void clearAction() {
            this.actionCase_ = 0;
            this.action_ = null;
        }

        private void clearReplace() {
            if (this.actionCase_ == 2) {
                this.actionCase_ = 0;
                this.action_ = null;
            }
        }

        private void clearSipTrunkId() {
            this.sipTrunkId_ = getDefaultInstance().getSipTrunkId();
        }

        private void clearUpdate() {
            if (this.actionCase_ == 3) {
                this.actionCase_ = 0;
                this.action_ = null;
            }
        }

        public static UpdateSIPOutboundTrunkRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeReplace(SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            sIPOutboundTrunkInfo.getClass();
            if (this.actionCase_ != 2 || this.action_ == SIPOutboundTrunkInfo.getDefaultInstance()) {
                this.action_ = sIPOutboundTrunkInfo;
            } else {
                this.action_ = ((SIPOutboundTrunkInfo.Builder) SIPOutboundTrunkInfo.newBuilder((SIPOutboundTrunkInfo) this.action_).v(sIPOutboundTrunkInfo)).o();
            }
            this.actionCase_ = 2;
        }

        private void mergeUpdate(SIPOutboundTrunkUpdate sIPOutboundTrunkUpdate) {
            sIPOutboundTrunkUpdate.getClass();
            if (this.actionCase_ != 3 || this.action_ == SIPOutboundTrunkUpdate.getDefaultInstance()) {
                this.action_ = sIPOutboundTrunkUpdate;
            } else {
                this.action_ = ((SIPOutboundTrunkUpdate.Builder) SIPOutboundTrunkUpdate.newBuilder((SIPOutboundTrunkUpdate) this.action_).v(sIPOutboundTrunkUpdate)).o();
            }
            this.actionCase_ = 3;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateSIPOutboundTrunkRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSIPOutboundTrunkRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateSIPOutboundTrunkRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setReplace(SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            sIPOutboundTrunkInfo.getClass();
            this.action_ = sIPOutboundTrunkInfo;
            this.actionCase_ = 2;
        }

        private void setSipTrunkId(String str) {
            str.getClass();
            this.sipTrunkId_ = str;
        }

        private void setSipTrunkIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipTrunkId_ = byteString.L();
        }

        private void setUpdate(SIPOutboundTrunkUpdate sIPOutboundTrunkUpdate) {
            sIPOutboundTrunkUpdate.getClass();
            this.action_ = sIPOutboundTrunkUpdate;
            this.actionCase_ = 3;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateSIPOutboundTrunkRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0001\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002<\u0000\u0003<\u0000", new Object[]{"action_", "actionCase_", "sipTrunkId_", SIPOutboundTrunkInfo.class, SIPOutboundTrunkUpdate.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateSIPOutboundTrunkRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateSIPOutboundTrunkRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public ActionCase getActionCase() {
            return ActionCase.b(this.actionCase_);
        }

        public SIPOutboundTrunkInfo getReplace() {
            return this.actionCase_ == 2 ? (SIPOutboundTrunkInfo) this.action_ : SIPOutboundTrunkInfo.getDefaultInstance();
        }

        public String getSipTrunkId() {
            return this.sipTrunkId_;
        }

        public ByteString getSipTrunkIdBytes() {
            return ByteString.n(this.sipTrunkId_);
        }

        public SIPOutboundTrunkUpdate getUpdate() {
            return this.actionCase_ == 3 ? (SIPOutboundTrunkUpdate) this.action_ : SIPOutboundTrunkUpdate.getDefaultInstance();
        }

        public boolean hasReplace() {
            return this.actionCase_ == 2;
        }

        public boolean hasUpdate() {
            return this.actionCase_ == 3;
        }

        public static Builder newBuilder(UpdateSIPOutboundTrunkRequest updateSIPOutboundTrunkRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateSIPOutboundTrunkRequest);
        }

        public static UpdateSIPOutboundTrunkRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSIPOutboundTrunkRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateSIPOutboundTrunkRequest parseFrom(ByteString byteString) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateSIPOutboundTrunkRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateSIPOutboundTrunkRequest parseFrom(byte[] bArr) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateSIPOutboundTrunkRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateSIPOutboundTrunkRequest parseFrom(InputStream inputStream) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSIPOutboundTrunkRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSIPOutboundTrunkRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateSIPOutboundTrunkRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSIPOutboundTrunkRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateSIPOutboundTrunkRequestOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitSip() {
    }
}