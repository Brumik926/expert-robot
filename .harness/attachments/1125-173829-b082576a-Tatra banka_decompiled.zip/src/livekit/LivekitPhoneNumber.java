package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import com.google.protobuf.Timestamp;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;
import livekit.LivekitModels;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitPhoneNumber {

    /* JADX INFO: renamed from: livekit.LivekitPhoneNumber$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class GetPhoneNumberRequest extends GeneratedMessageLite<GetPhoneNumberRequest, Builder> implements GetPhoneNumberRequestOrBuilder {
        private static final GetPhoneNumberRequest DEFAULT_INSTANCE;
        public static final int ID_FIELD_NUMBER = 1;
        private static volatile Parser<GetPhoneNumberRequest> PARSER = null;
        public static final int PHONE_NUMBER_FIELD_NUMBER = 2;
        private String id_;
        private String phoneNumber_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<GetPhoneNumberRequest, Builder> implements GetPhoneNumberRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(GetPhoneNumberRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            GetPhoneNumberRequest getPhoneNumberRequest = new GetPhoneNumberRequest();
            DEFAULT_INSTANCE = getPhoneNumberRequest;
            GeneratedMessageLite.registerDefaultInstance(GetPhoneNumberRequest.class, getPhoneNumberRequest);
        }

        private GetPhoneNumberRequest() {
            String strA = ap.a(62998542);
            this.id_ = strA;
            this.phoneNumber_ = strA;
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearPhoneNumber() {
            this.phoneNumber_ = getDefaultInstance().getPhoneNumber();
        }

        public static GetPhoneNumberRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static GetPhoneNumberRequest parseDelimitedFrom(InputStream inputStream) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetPhoneNumberRequest parseFrom(ByteBuffer byteBuffer) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<GetPhoneNumberRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setPhoneNumber(String str) {
            str.getClass();
            this.phoneNumber_ = str;
        }

        private void setPhoneNumberBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.phoneNumber_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new GetPhoneNumberRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"id_", "phoneNumber_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<GetPhoneNumberRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (GetPhoneNumberRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public String getPhoneNumber() {
            return this.phoneNumber_;
        }

        public ByteString getPhoneNumberBytes() {
            return ByteString.n(this.phoneNumber_);
        }

        public static Builder newBuilder(GetPhoneNumberRequest getPhoneNumberRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(getPhoneNumberRequest);
        }

        public static GetPhoneNumberRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetPhoneNumberRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static GetPhoneNumberRequest parseFrom(ByteString byteString) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static GetPhoneNumberRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static GetPhoneNumberRequest parseFrom(byte[] bArr) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static GetPhoneNumberRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static GetPhoneNumberRequest parseFrom(InputStream inputStream) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetPhoneNumberRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetPhoneNumberRequest parseFrom(CodedInputStream codedInputStream) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static GetPhoneNumberRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface GetPhoneNumberRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class GetPhoneNumberResponse extends GeneratedMessageLite<GetPhoneNumberResponse, Builder> implements GetPhoneNumberResponseOrBuilder {
        private static final GetPhoneNumberResponse DEFAULT_INSTANCE;
        private static volatile Parser<GetPhoneNumberResponse> PARSER = null;
        public static final int PHONE_NUMBER_FIELD_NUMBER = 1;
        private PhoneNumber phoneNumber_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<GetPhoneNumberResponse, Builder> implements GetPhoneNumberResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(GetPhoneNumberResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            GetPhoneNumberResponse getPhoneNumberResponse = new GetPhoneNumberResponse();
            DEFAULT_INSTANCE = getPhoneNumberResponse;
            GeneratedMessageLite.registerDefaultInstance(GetPhoneNumberResponse.class, getPhoneNumberResponse);
        }

        private GetPhoneNumberResponse() {
        }

        private void clearPhoneNumber() {
            this.phoneNumber_ = null;
        }

        public static GetPhoneNumberResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergePhoneNumber(PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            PhoneNumber phoneNumber2 = this.phoneNumber_;
            if (phoneNumber2 == null || phoneNumber2 == PhoneNumber.getDefaultInstance()) {
                this.phoneNumber_ = phoneNumber;
            } else {
                this.phoneNumber_ = (PhoneNumber) ((PhoneNumber.Builder) PhoneNumber.newBuilder(this.phoneNumber_).v(phoneNumber)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static GetPhoneNumberResponse parseDelimitedFrom(InputStream inputStream) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetPhoneNumberResponse parseFrom(ByteBuffer byteBuffer) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<GetPhoneNumberResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setPhoneNumber(PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            this.phoneNumber_ = phoneNumber;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new GetPhoneNumberResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\t", new Object[]{ap.a(724472146)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<GetPhoneNumberResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (GetPhoneNumberResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public PhoneNumber getPhoneNumber() {
            PhoneNumber phoneNumber = this.phoneNumber_;
            return phoneNumber == null ? PhoneNumber.getDefaultInstance() : phoneNumber;
        }

        public boolean hasPhoneNumber() {
            return this.phoneNumber_ != null;
        }

        public static Builder newBuilder(GetPhoneNumberResponse getPhoneNumberResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(getPhoneNumberResponse);
        }

        public static GetPhoneNumberResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetPhoneNumberResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static GetPhoneNumberResponse parseFrom(ByteString byteString) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static GetPhoneNumberResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static GetPhoneNumberResponse parseFrom(byte[] bArr) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static GetPhoneNumberResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static GetPhoneNumberResponse parseFrom(InputStream inputStream) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GetPhoneNumberResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GetPhoneNumberResponse parseFrom(CodedInputStream codedInputStream) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static GetPhoneNumberResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GetPhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface GetPhoneNumberResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListPhoneNumbersRequest extends GeneratedMessageLite<ListPhoneNumbersRequest, Builder> implements ListPhoneNumbersRequestOrBuilder {
        private static final ListPhoneNumbersRequest DEFAULT_INSTANCE;
        public static final int LIMIT_FIELD_NUMBER = 1;
        public static final int PAGE_TOKEN_FIELD_NUMBER = 3;
        private static volatile Parser<ListPhoneNumbersRequest> PARSER = null;
        public static final int SIP_DISPATCH_RULE_ID_FIELD_NUMBER = 4;
        public static final int STATUS_FIELD_NUMBER = 2;
        private int limit_;
        private LivekitModels.TokenPagination pageToken_;
        private String sipDispatchRuleId_ = ap.a(75654106);
        private int status_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListPhoneNumbersRequest, Builder> implements ListPhoneNumbersRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListPhoneNumbersRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListPhoneNumbersRequest listPhoneNumbersRequest = new ListPhoneNumbersRequest();
            DEFAULT_INSTANCE = listPhoneNumbersRequest;
            GeneratedMessageLite.registerDefaultInstance(ListPhoneNumbersRequest.class, listPhoneNumbersRequest);
        }

        private ListPhoneNumbersRequest() {
        }

        private void clearLimit() {
            this.limit_ = 0;
        }

        private void clearPageToken() {
            this.pageToken_ = null;
        }

        private void clearSipDispatchRuleId() {
            this.sipDispatchRuleId_ = getDefaultInstance().getSipDispatchRuleId();
        }

        private void clearStatus() {
            this.status_ = 0;
        }

        public static ListPhoneNumbersRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergePageToken(LivekitModels.TokenPagination tokenPagination) {
            tokenPagination.getClass();
            LivekitModels.TokenPagination tokenPagination2 = this.pageToken_;
            if (tokenPagination2 == null || tokenPagination2 == LivekitModels.TokenPagination.getDefaultInstance()) {
                this.pageToken_ = tokenPagination;
            } else {
                this.pageToken_ = (LivekitModels.TokenPagination) ((LivekitModels.TokenPagination.Builder) LivekitModels.TokenPagination.newBuilder(this.pageToken_).v(tokenPagination)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListPhoneNumbersRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListPhoneNumbersRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListPhoneNumbersRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setLimit(int i) {
            this.limit_ = i;
        }

        private void setPageToken(LivekitModels.TokenPagination tokenPagination) {
            tokenPagination.getClass();
            this.pageToken_ = tokenPagination;
        }

        private void setSipDispatchRuleId(String str) {
            str.getClass();
            this.sipDispatchRuleId_ = str;
        }

        private void setSipDispatchRuleIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipDispatchRuleId_ = byteString.L();
        }

        private void setStatus(PhoneNumberStatus phoneNumberStatus) {
            this.status_ = phoneNumberStatus.getNumber();
        }

        private void setStatusValue(int i) {
            this.status_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListPhoneNumbersRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u0004\u0002\f\u0003\t\u0004Ȉ", new Object[]{"limit_", "status_", "pageToken_", "sipDispatchRuleId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListPhoneNumbersRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListPhoneNumbersRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getLimit() {
            return this.limit_;
        }

        public LivekitModels.TokenPagination getPageToken() {
            LivekitModels.TokenPagination tokenPagination = this.pageToken_;
            return tokenPagination == null ? LivekitModels.TokenPagination.getDefaultInstance() : tokenPagination;
        }

        public String getSipDispatchRuleId() {
            return this.sipDispatchRuleId_;
        }

        public ByteString getSipDispatchRuleIdBytes() {
            return ByteString.n(this.sipDispatchRuleId_);
        }

        public PhoneNumberStatus getStatus() {
            PhoneNumberStatus phoneNumberStatusB = PhoneNumberStatus.b(this.status_);
            return phoneNumberStatusB == null ? PhoneNumberStatus.f : phoneNumberStatusB;
        }

        public int getStatusValue() {
            return this.status_;
        }

        public boolean hasPageToken() {
            return this.pageToken_ != null;
        }

        public static Builder newBuilder(ListPhoneNumbersRequest listPhoneNumbersRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listPhoneNumbersRequest);
        }

        public static ListPhoneNumbersRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListPhoneNumbersRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListPhoneNumbersRequest parseFrom(ByteString byteString) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListPhoneNumbersRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListPhoneNumbersRequest parseFrom(byte[] bArr) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListPhoneNumbersRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListPhoneNumbersRequest parseFrom(InputStream inputStream) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListPhoneNumbersRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListPhoneNumbersRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListPhoneNumbersRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListPhoneNumbersRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListPhoneNumbersResponse extends GeneratedMessageLite<ListPhoneNumbersResponse, Builder> implements ListPhoneNumbersResponseOrBuilder {
        private static final ListPhoneNumbersResponse DEFAULT_INSTANCE;
        public static final int ITEMS_FIELD_NUMBER = 1;
        public static final int NEXT_PAGE_TOKEN_FIELD_NUMBER = 2;
        private static volatile Parser<ListPhoneNumbersResponse> PARSER = null;
        public static final int TOTAL_COUNT_FIELD_NUMBER = 3;
        private Internal.ProtobufList<PhoneNumber> items_ = GeneratedMessageLite.emptyProtobufList();
        private LivekitModels.TokenPagination nextPageToken_;
        private int totalCount_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListPhoneNumbersResponse, Builder> implements ListPhoneNumbersResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListPhoneNumbersResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListPhoneNumbersResponse listPhoneNumbersResponse = new ListPhoneNumbersResponse();
            DEFAULT_INSTANCE = listPhoneNumbersResponse;
            GeneratedMessageLite.registerDefaultInstance(ListPhoneNumbersResponse.class, listPhoneNumbersResponse);
        }

        private ListPhoneNumbersResponse() {
        }

        private void addAllItems(Iterable<? extends PhoneNumber> iterable) {
            ensureItemsIsMutable();
            AbstractMessageLite.addAll(iterable, this.items_);
        }

        private void addItems(PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            ensureItemsIsMutable();
            this.items_.add(phoneNumber);
        }

        private void clearItems() {
            this.items_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearNextPageToken() {
            this.nextPageToken_ = null;
        }

        private void clearTotalCount() {
            this.totalCount_ = 0;
        }

        private void ensureItemsIsMutable() {
            Internal.ProtobufList<PhoneNumber> protobufList = this.items_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.items_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListPhoneNumbersResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeNextPageToken(LivekitModels.TokenPagination tokenPagination) {
            tokenPagination.getClass();
            LivekitModels.TokenPagination tokenPagination2 = this.nextPageToken_;
            if (tokenPagination2 == null || tokenPagination2 == LivekitModels.TokenPagination.getDefaultInstance()) {
                this.nextPageToken_ = tokenPagination;
            } else {
                this.nextPageToken_ = (LivekitModels.TokenPagination) ((LivekitModels.TokenPagination.Builder) LivekitModels.TokenPagination.newBuilder(this.nextPageToken_).v(tokenPagination)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListPhoneNumbersResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListPhoneNumbersResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListPhoneNumbersResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeItems(int i) {
            ensureItemsIsMutable();
            this.items_.remove(i);
        }

        private void setItems(int i, PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            ensureItemsIsMutable();
            this.items_.set(i, phoneNumber);
        }

        private void setNextPageToken(LivekitModels.TokenPagination tokenPagination) {
            tokenPagination.getClass();
            this.nextPageToken_ = tokenPagination;
        }

        private void setTotalCount(int i) {
            this.totalCount_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListPhoneNumbersResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0001\u0000\u0001\u001b\u0002\t\u0003\u0004", new Object[]{ap.a(303308063), PhoneNumber.class, ap.a(2085580298), ap.a(213214728)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListPhoneNumbersResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListPhoneNumbersResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public PhoneNumber getItems(int i) {
            return (PhoneNumber) this.items_.get(i);
        }

        public int getItemsCount() {
            return this.items_.size();
        }

        public List<PhoneNumber> getItemsList() {
            return this.items_;
        }

        public PhoneNumberOrBuilder getItemsOrBuilder(int i) {
            return (PhoneNumberOrBuilder) this.items_.get(i);
        }

        public List<? extends PhoneNumberOrBuilder> getItemsOrBuilderList() {
            return this.items_;
        }

        public LivekitModels.TokenPagination getNextPageToken() {
            LivekitModels.TokenPagination tokenPagination = this.nextPageToken_;
            return tokenPagination == null ? LivekitModels.TokenPagination.getDefaultInstance() : tokenPagination;
        }

        public int getTotalCount() {
            return this.totalCount_;
        }

        public boolean hasNextPageToken() {
            return this.nextPageToken_ != null;
        }

        public static Builder newBuilder(ListPhoneNumbersResponse listPhoneNumbersResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listPhoneNumbersResponse);
        }

        public static ListPhoneNumbersResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListPhoneNumbersResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListPhoneNumbersResponse parseFrom(ByteString byteString) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addItems(int i, PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            ensureItemsIsMutable();
            this.items_.add(i, phoneNumber);
        }

        public static ListPhoneNumbersResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListPhoneNumbersResponse parseFrom(byte[] bArr) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListPhoneNumbersResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListPhoneNumbersResponse parseFrom(InputStream inputStream) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListPhoneNumbersResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListPhoneNumbersResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListPhoneNumbersResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListPhoneNumbersResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class PhoneNumber extends GeneratedMessageLite<PhoneNumber, Builder> implements PhoneNumberOrBuilder {
        public static final int AREA_CODE_FIELD_NUMBER = 4;
        public static final int ASSIGNED_AT_FIELD_NUMBER = 13;
        public static final int CAPABILITIES_FIELD_NUMBER = 11;
        public static final int COUNTRY_CODE_FIELD_NUMBER = 3;
        public static final int CREATED_AT_FIELD_NUMBER = 9;
        private static final PhoneNumber DEFAULT_INSTANCE;
        public static final int E164_FORMAT_FIELD_NUMBER = 2;
        public static final int ID_FIELD_NUMBER = 1;
        public static final int LOCALITY_FIELD_NUMBER = 6;
        public static final int NUMBER_TYPE_FIELD_NUMBER = 5;
        private static volatile Parser<PhoneNumber> PARSER = null;
        public static final int REGION_FIELD_NUMBER = 7;
        public static final int RELEASED_AT_FIELD_NUMBER = 14;
        public static final int SIP_DISPATCH_RULE_ID_FIELD_NUMBER = 15;
        public static final int SPAM_SCORE_FIELD_NUMBER = 8;
        public static final int STATUS_FIELD_NUMBER = 12;
        public static final int UPDATED_AT_FIELD_NUMBER = 10;
        private String areaCode_;
        private Timestamp assignedAt_;
        private Internal.ProtobufList<String> capabilities_;
        private String countryCode_;
        private Timestamp createdAt_;
        private String e164Format_;
        private String id_;
        private String locality_;
        private int numberType_;
        private String region_;
        private Timestamp releasedAt_;
        private String sipDispatchRuleId_;
        private double spamScore_;
        private int status_;
        private Timestamp updatedAt_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<PhoneNumber, Builder> implements PhoneNumberOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(PhoneNumber.DEFAULT_INSTANCE);
            }
        }

        static {
            PhoneNumber phoneNumber = new PhoneNumber();
            DEFAULT_INSTANCE = phoneNumber;
            GeneratedMessageLite.registerDefaultInstance(PhoneNumber.class, phoneNumber);
        }

        private PhoneNumber() {
            String strA = ap.a(334946414);
            this.id_ = strA;
            this.e164Format_ = strA;
            this.countryCode_ = strA;
            this.areaCode_ = strA;
            this.locality_ = strA;
            this.region_ = strA;
            this.capabilities_ = GeneratedMessageLite.emptyProtobufList();
            this.sipDispatchRuleId_ = strA;
        }

        private void addAllCapabilities(Iterable<String> iterable) {
            ensureCapabilitiesIsMutable();
            AbstractMessageLite.addAll(iterable, this.capabilities_);
        }

        private void addCapabilities(String str) {
            str.getClass();
            ensureCapabilitiesIsMutable();
            this.capabilities_.add(str);
        }

        private void addCapabilitiesBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureCapabilitiesIsMutable();
            this.capabilities_.add(byteString.L());
        }

        private void clearAreaCode() {
            this.areaCode_ = getDefaultInstance().getAreaCode();
        }

        private void clearAssignedAt() {
            this.assignedAt_ = null;
        }

        private void clearCapabilities() {
            this.capabilities_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearCountryCode() {
            this.countryCode_ = getDefaultInstance().getCountryCode();
        }

        private void clearCreatedAt() {
            this.createdAt_ = null;
        }

        private void clearE164Format() {
            this.e164Format_ = getDefaultInstance().getE164Format();
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearLocality() {
            this.locality_ = getDefaultInstance().getLocality();
        }

        private void clearNumberType() {
            this.numberType_ = 0;
        }

        private void clearRegion() {
            this.region_ = getDefaultInstance().getRegion();
        }

        private void clearReleasedAt() {
            this.releasedAt_ = null;
        }

        private void clearSipDispatchRuleId() {
            this.sipDispatchRuleId_ = getDefaultInstance().getSipDispatchRuleId();
        }

        private void clearSpamScore() {
            this.spamScore_ = 0.0d;
        }

        private void clearStatus() {
            this.status_ = 0;
        }

        private void clearUpdatedAt() {
            this.updatedAt_ = null;
        }

        private void ensureCapabilitiesIsMutable() {
            Internal.ProtobufList<String> protobufList = this.capabilities_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.capabilities_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static PhoneNumber getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAssignedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.assignedAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.assignedAt_ = timestamp;
            } else {
                this.assignedAt_ = Timestamp.newBuilder(this.assignedAt_).v(timestamp).o();
            }
        }

        private void mergeCreatedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.createdAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.createdAt_ = timestamp;
            } else {
                this.createdAt_ = Timestamp.newBuilder(this.createdAt_).v(timestamp).o();
            }
        }

        private void mergeReleasedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.releasedAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.releasedAt_ = timestamp;
            } else {
                this.releasedAt_ = Timestamp.newBuilder(this.releasedAt_).v(timestamp).o();
            }
        }

        private void mergeUpdatedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.updatedAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.updatedAt_ = timestamp;
            } else {
                this.updatedAt_ = Timestamp.newBuilder(this.updatedAt_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static PhoneNumber parseDelimitedFrom(InputStream inputStream) {
            return (PhoneNumber) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PhoneNumber parseFrom(ByteBuffer byteBuffer) {
            return (PhoneNumber) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<PhoneNumber> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAreaCode(String str) {
            str.getClass();
            this.areaCode_ = str;
        }

        private void setAreaCodeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.areaCode_ = byteString.L();
        }

        private void setAssignedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.assignedAt_ = timestamp;
        }

        private void setCapabilities(int i, String str) {
            str.getClass();
            ensureCapabilitiesIsMutable();
            this.capabilities_.set(i, str);
        }

        private void setCountryCode(String str) {
            str.getClass();
            this.countryCode_ = str;
        }

        private void setCountryCodeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.countryCode_ = byteString.L();
        }

        private void setCreatedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.createdAt_ = timestamp;
        }

        private void setE164Format(String str) {
            str.getClass();
            this.e164Format_ = str;
        }

        private void setE164FormatBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.e164Format_ = byteString.L();
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setLocality(String str) {
            str.getClass();
            this.locality_ = str;
        }

        private void setLocalityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.locality_ = byteString.L();
        }

        private void setNumberType(PhoneNumberType phoneNumberType) {
            this.numberType_ = phoneNumberType.getNumber();
        }

        private void setNumberTypeValue(int i) {
            this.numberType_ = i;
        }

        private void setRegion(String str) {
            str.getClass();
            this.region_ = str;
        }

        private void setRegionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.region_ = byteString.L();
        }

        private void setReleasedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.releasedAt_ = timestamp;
        }

        private void setSipDispatchRuleId(String str) {
            str.getClass();
            this.sipDispatchRuleId_ = str;
        }

        private void setSipDispatchRuleIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipDispatchRuleId_ = byteString.L();
        }

        private void setSpamScore(double d) {
            this.spamScore_ = d;
        }

        private void setStatus(PhoneNumberStatus phoneNumberStatus) {
            this.status_ = phoneNumberStatus.getNumber();
        }

        private void setStatusValue(int i) {
            this.status_ = i;
        }

        private void setUpdatedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.updatedAt_ = timestamp;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new PhoneNumber();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000f\u0000\u0000\u0001\u000f\u000f\u0000\u0001\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005\f\u0006Ȉ\u0007Ȉ\b\u0000\t\t\n\t\u000bȚ\f\f\r\t\u000e\t\u000fȈ", new Object[]{"id_", "e164Format_", "countryCode_", "areaCode_", "numberType_", "locality_", "region_", "spamScore_", "createdAt_", "updatedAt_", "capabilities_", "status_", "assignedAt_", "releasedAt_", "sipDispatchRuleId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<PhoneNumber> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (PhoneNumber.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAreaCode() {
            return this.areaCode_;
        }

        public ByteString getAreaCodeBytes() {
            return ByteString.n(this.areaCode_);
        }

        public Timestamp getAssignedAt() {
            Timestamp timestamp = this.assignedAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public String getCapabilities(int i) {
            return (String) this.capabilities_.get(i);
        }

        public ByteString getCapabilitiesBytes(int i) {
            return ByteString.n((String) this.capabilities_.get(i));
        }

        public int getCapabilitiesCount() {
            return this.capabilities_.size();
        }

        public List<String> getCapabilitiesList() {
            return this.capabilities_;
        }

        public String getCountryCode() {
            return this.countryCode_;
        }

        public ByteString getCountryCodeBytes() {
            return ByteString.n(this.countryCode_);
        }

        public Timestamp getCreatedAt() {
            Timestamp timestamp = this.createdAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public String getE164Format() {
            return this.e164Format_;
        }

        public ByteString getE164FormatBytes() {
            return ByteString.n(this.e164Format_);
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public String getLocality() {
            return this.locality_;
        }

        public ByteString getLocalityBytes() {
            return ByteString.n(this.locality_);
        }

        public PhoneNumberType getNumberType() {
            PhoneNumberType phoneNumberTypeB = PhoneNumberType.b(this.numberType_);
            return phoneNumberTypeB == null ? PhoneNumberType.f : phoneNumberTypeB;
        }

        public int getNumberTypeValue() {
            return this.numberType_;
        }

        public String getRegion() {
            return this.region_;
        }

        public ByteString getRegionBytes() {
            return ByteString.n(this.region_);
        }

        public Timestamp getReleasedAt() {
            Timestamp timestamp = this.releasedAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public String getSipDispatchRuleId() {
            return this.sipDispatchRuleId_;
        }

        public ByteString getSipDispatchRuleIdBytes() {
            return ByteString.n(this.sipDispatchRuleId_);
        }

        public double getSpamScore() {
            return this.spamScore_;
        }

        public PhoneNumberStatus getStatus() {
            PhoneNumberStatus phoneNumberStatusB = PhoneNumberStatus.b(this.status_);
            return phoneNumberStatusB == null ? PhoneNumberStatus.f : phoneNumberStatusB;
        }

        public int getStatusValue() {
            return this.status_;
        }

        public Timestamp getUpdatedAt() {
            Timestamp timestamp = this.updatedAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public boolean hasAssignedAt() {
            return this.assignedAt_ != null;
        }

        public boolean hasCreatedAt() {
            return this.createdAt_ != null;
        }

        public boolean hasReleasedAt() {
            return this.releasedAt_ != null;
        }

        public boolean hasUpdatedAt() {
            return this.updatedAt_ != null;
        }

        public static Builder newBuilder(PhoneNumber phoneNumber) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(phoneNumber);
        }

        public static PhoneNumber parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PhoneNumber) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PhoneNumber parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (PhoneNumber) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static PhoneNumber parseFrom(ByteString byteString) {
            return (PhoneNumber) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static PhoneNumber parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (PhoneNumber) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static PhoneNumber parseFrom(byte[] bArr) {
            return (PhoneNumber) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static PhoneNumber parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (PhoneNumber) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static PhoneNumber parseFrom(InputStream inputStream) {
            return (PhoneNumber) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PhoneNumber parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PhoneNumber) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PhoneNumber parseFrom(CodedInputStream codedInputStream) {
            return (PhoneNumber) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static PhoneNumber parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PhoneNumber) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface PhoneNumberOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum PhoneNumberStatus implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(-1);

        private static final Internal.EnumLiteMap g = new Internal.EnumLiteMap<PhoneNumberStatus>() { // from class: livekit.LivekitPhoneNumber.PhoneNumberStatus.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public PhoneNumberStatus findValueByNumber(int i) {
                return PhoneNumberStatus.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class PhoneNumberStatusVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new PhoneNumberStatusVerifier();

            private PhoneNumberStatusVerifier() {
            }

            public boolean isInRange(int i) {
                return PhoneNumberStatus.b(i) != null;
            }
        }

        PhoneNumberStatus(int i) {
            this.a = i;
        }

        public static PhoneNumberStatus b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i == 2) {
                return d;
            }
            if (i != 3) {
                return null;
            }
            return e;
        }

        public final int getNumber() {
            if (this != f) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum PhoneNumberType implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(-1);

        private static final Internal.EnumLiteMap g = new Internal.EnumLiteMap<PhoneNumberType>() { // from class: livekit.LivekitPhoneNumber.PhoneNumberType.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public PhoneNumberType findValueByNumber(int i) {
                return PhoneNumberType.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class PhoneNumberTypeVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new PhoneNumberTypeVerifier();

            private PhoneNumberTypeVerifier() {
            }

            public boolean isInRange(int i) {
                return PhoneNumberType.b(i) != null;
            }
        }

        PhoneNumberType(int i) {
            this.a = i;
        }

        public static PhoneNumberType b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i == 2) {
                return d;
            }
            if (i != 3) {
                return null;
            }
            return e;
        }

        public final int getNumber() {
            if (this != f) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class PurchasePhoneNumberRequest extends GeneratedMessageLite<PurchasePhoneNumberRequest, Builder> implements PurchasePhoneNumberRequestOrBuilder {
        private static final PurchasePhoneNumberRequest DEFAULT_INSTANCE;
        private static volatile Parser<PurchasePhoneNumberRequest> PARSER = null;
        public static final int PHONE_NUMBERS_FIELD_NUMBER = 1;
        public static final int SIP_DISPATCH_RULE_ID_FIELD_NUMBER = 2;
        private Internal.ProtobufList<String> phoneNumbers_ = GeneratedMessageLite.emptyProtobufList();
        private String sipDispatchRuleId_ = ap.a(1191464996);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<PurchasePhoneNumberRequest, Builder> implements PurchasePhoneNumberRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(PurchasePhoneNumberRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            PurchasePhoneNumberRequest purchasePhoneNumberRequest = new PurchasePhoneNumberRequest();
            DEFAULT_INSTANCE = purchasePhoneNumberRequest;
            GeneratedMessageLite.registerDefaultInstance(PurchasePhoneNumberRequest.class, purchasePhoneNumberRequest);
        }

        private PurchasePhoneNumberRequest() {
        }

        private void addAllPhoneNumbers(Iterable<String> iterable) {
            ensurePhoneNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.phoneNumbers_);
        }

        private void addPhoneNumbers(String str) {
            str.getClass();
            ensurePhoneNumbersIsMutable();
            this.phoneNumbers_.add(str);
        }

        private void addPhoneNumbersBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensurePhoneNumbersIsMutable();
            this.phoneNumbers_.add(byteString.L());
        }

        private void clearPhoneNumbers() {
            this.phoneNumbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSipDispatchRuleId() {
            this.sipDispatchRuleId_ = getDefaultInstance().getSipDispatchRuleId();
        }

        private void ensurePhoneNumbersIsMutable() {
            Internal.ProtobufList<String> protobufList = this.phoneNumbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.phoneNumbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static PurchasePhoneNumberRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static PurchasePhoneNumberRequest parseDelimitedFrom(InputStream inputStream) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PurchasePhoneNumberRequest parseFrom(ByteBuffer byteBuffer) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<PurchasePhoneNumberRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setPhoneNumbers(int i, String str) {
            str.getClass();
            ensurePhoneNumbersIsMutable();
            this.phoneNumbers_.set(i, str);
        }

        private void setSipDispatchRuleId(String str) {
            str.getClass();
            this.sipDispatchRuleId_ = str;
        }

        private void setSipDispatchRuleIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipDispatchRuleId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new PurchasePhoneNumberRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001Ț\u0002Ȉ", new Object[]{"phoneNumbers_", "sipDispatchRuleId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<PurchasePhoneNumberRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (PurchasePhoneNumberRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getPhoneNumbers(int i) {
            return (String) this.phoneNumbers_.get(i);
        }

        public ByteString getPhoneNumbersBytes(int i) {
            return ByteString.n((String) this.phoneNumbers_.get(i));
        }

        public int getPhoneNumbersCount() {
            return this.phoneNumbers_.size();
        }

        public List<String> getPhoneNumbersList() {
            return this.phoneNumbers_;
        }

        public String getSipDispatchRuleId() {
            return this.sipDispatchRuleId_;
        }

        public ByteString getSipDispatchRuleIdBytes() {
            return ByteString.n(this.sipDispatchRuleId_);
        }

        public static Builder newBuilder(PurchasePhoneNumberRequest purchasePhoneNumberRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(purchasePhoneNumberRequest);
        }

        public static PurchasePhoneNumberRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PurchasePhoneNumberRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static PurchasePhoneNumberRequest parseFrom(ByteString byteString) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static PurchasePhoneNumberRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static PurchasePhoneNumberRequest parseFrom(byte[] bArr) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static PurchasePhoneNumberRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static PurchasePhoneNumberRequest parseFrom(InputStream inputStream) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PurchasePhoneNumberRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PurchasePhoneNumberRequest parseFrom(CodedInputStream codedInputStream) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static PurchasePhoneNumberRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface PurchasePhoneNumberRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class PurchasePhoneNumberResponse extends GeneratedMessageLite<PurchasePhoneNumberResponse, Builder> implements PurchasePhoneNumberResponseOrBuilder {
        private static final PurchasePhoneNumberResponse DEFAULT_INSTANCE;
        private static volatile Parser<PurchasePhoneNumberResponse> PARSER = null;
        public static final int PHONE_NUMBERS_FIELD_NUMBER = 1;
        private Internal.ProtobufList<PhoneNumber> phoneNumbers_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<PurchasePhoneNumberResponse, Builder> implements PurchasePhoneNumberResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(PurchasePhoneNumberResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            PurchasePhoneNumberResponse purchasePhoneNumberResponse = new PurchasePhoneNumberResponse();
            DEFAULT_INSTANCE = purchasePhoneNumberResponse;
            GeneratedMessageLite.registerDefaultInstance(PurchasePhoneNumberResponse.class, purchasePhoneNumberResponse);
        }

        private PurchasePhoneNumberResponse() {
        }

        private void addAllPhoneNumbers(Iterable<? extends PhoneNumber> iterable) {
            ensurePhoneNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.phoneNumbers_);
        }

        private void addPhoneNumbers(PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            ensurePhoneNumbersIsMutable();
            this.phoneNumbers_.add(phoneNumber);
        }

        private void clearPhoneNumbers() {
            this.phoneNumbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensurePhoneNumbersIsMutable() {
            Internal.ProtobufList<PhoneNumber> protobufList = this.phoneNumbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.phoneNumbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static PurchasePhoneNumberResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static PurchasePhoneNumberResponse parseDelimitedFrom(InputStream inputStream) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PurchasePhoneNumberResponse parseFrom(ByteBuffer byteBuffer) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<PurchasePhoneNumberResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removePhoneNumbers(int i) {
            ensurePhoneNumbersIsMutable();
            this.phoneNumbers_.remove(i);
        }

        private void setPhoneNumbers(int i, PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            ensurePhoneNumbersIsMutable();
            this.phoneNumbers_.set(i, phoneNumber);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new PurchasePhoneNumberResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(673252909), PhoneNumber.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<PurchasePhoneNumberResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (PurchasePhoneNumberResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public PhoneNumber getPhoneNumbers(int i) {
            return (PhoneNumber) this.phoneNumbers_.get(i);
        }

        public int getPhoneNumbersCount() {
            return this.phoneNumbers_.size();
        }

        public List<PhoneNumber> getPhoneNumbersList() {
            return this.phoneNumbers_;
        }

        public PhoneNumberOrBuilder getPhoneNumbersOrBuilder(int i) {
            return (PhoneNumberOrBuilder) this.phoneNumbers_.get(i);
        }

        public List<? extends PhoneNumberOrBuilder> getPhoneNumbersOrBuilderList() {
            return this.phoneNumbers_;
        }

        public static Builder newBuilder(PurchasePhoneNumberResponse purchasePhoneNumberResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(purchasePhoneNumberResponse);
        }

        public static PurchasePhoneNumberResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PurchasePhoneNumberResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static PurchasePhoneNumberResponse parseFrom(ByteString byteString) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addPhoneNumbers(int i, PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            ensurePhoneNumbersIsMutable();
            this.phoneNumbers_.add(i, phoneNumber);
        }

        public static PurchasePhoneNumberResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static PurchasePhoneNumberResponse parseFrom(byte[] bArr) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static PurchasePhoneNumberResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static PurchasePhoneNumberResponse parseFrom(InputStream inputStream) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PurchasePhoneNumberResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PurchasePhoneNumberResponse parseFrom(CodedInputStream codedInputStream) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static PurchasePhoneNumberResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PurchasePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface PurchasePhoneNumberResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ReleasePhoneNumbersRequest extends GeneratedMessageLite<ReleasePhoneNumbersRequest, Builder> implements ReleasePhoneNumbersRequestOrBuilder {
        private static final ReleasePhoneNumbersRequest DEFAULT_INSTANCE;
        public static final int IDS_FIELD_NUMBER = 1;
        private static volatile Parser<ReleasePhoneNumbersRequest> PARSER = null;
        public static final int PHONE_NUMBERS_FIELD_NUMBER = 2;
        private Internal.ProtobufList<String> ids_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<String> phoneNumbers_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ReleasePhoneNumbersRequest, Builder> implements ReleasePhoneNumbersRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ReleasePhoneNumbersRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ReleasePhoneNumbersRequest releasePhoneNumbersRequest = new ReleasePhoneNumbersRequest();
            DEFAULT_INSTANCE = releasePhoneNumbersRequest;
            GeneratedMessageLite.registerDefaultInstance(ReleasePhoneNumbersRequest.class, releasePhoneNumbersRequest);
        }

        private ReleasePhoneNumbersRequest() {
        }

        private void addAllIds(Iterable<String> iterable) {
            ensureIdsIsMutable();
            AbstractMessageLite.addAll(iterable, this.ids_);
        }

        private void addAllPhoneNumbers(Iterable<String> iterable) {
            ensurePhoneNumbersIsMutable();
            AbstractMessageLite.addAll(iterable, this.phoneNumbers_);
        }

        private void addIds(String str) {
            str.getClass();
            ensureIdsIsMutable();
            this.ids_.add(str);
        }

        private void addIdsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureIdsIsMutable();
            this.ids_.add(byteString.L());
        }

        private void addPhoneNumbers(String str) {
            str.getClass();
            ensurePhoneNumbersIsMutable();
            this.phoneNumbers_.add(str);
        }

        private void addPhoneNumbersBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensurePhoneNumbersIsMutable();
            this.phoneNumbers_.add(byteString.L());
        }

        private void clearIds() {
            this.ids_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearPhoneNumbers() {
            this.phoneNumbers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureIdsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.ids_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.ids_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensurePhoneNumbersIsMutable() {
            Internal.ProtobufList<String> protobufList = this.phoneNumbers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.phoneNumbers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ReleasePhoneNumbersRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ReleasePhoneNumbersRequest parseDelimitedFrom(InputStream inputStream) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ReleasePhoneNumbersRequest parseFrom(ByteBuffer byteBuffer) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ReleasePhoneNumbersRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setIds(int i, String str) {
            str.getClass();
            ensureIdsIsMutable();
            this.ids_.set(i, str);
        }

        private void setPhoneNumbers(int i, String str) {
            str.getClass();
            ensurePhoneNumbersIsMutable();
            this.phoneNumbers_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ReleasePhoneNumbersRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0002\u0000\u0001Ț\u0002Ț", new Object[]{ap.a(975920211), ap.a(1034945600)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ReleasePhoneNumbersRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ReleasePhoneNumbersRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getIds(int i) {
            return (String) this.ids_.get(i);
        }

        public ByteString getIdsBytes(int i) {
            return ByteString.n((String) this.ids_.get(i));
        }

        public int getIdsCount() {
            return this.ids_.size();
        }

        public List<String> getIdsList() {
            return this.ids_;
        }

        public String getPhoneNumbers(int i) {
            return (String) this.phoneNumbers_.get(i);
        }

        public ByteString getPhoneNumbersBytes(int i) {
            return ByteString.n((String) this.phoneNumbers_.get(i));
        }

        public int getPhoneNumbersCount() {
            return this.phoneNumbers_.size();
        }

        public List<String> getPhoneNumbersList() {
            return this.phoneNumbers_;
        }

        public static Builder newBuilder(ReleasePhoneNumbersRequest releasePhoneNumbersRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(releasePhoneNumbersRequest);
        }

        public static ReleasePhoneNumbersRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ReleasePhoneNumbersRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ReleasePhoneNumbersRequest parseFrom(ByteString byteString) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ReleasePhoneNumbersRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ReleasePhoneNumbersRequest parseFrom(byte[] bArr) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ReleasePhoneNumbersRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ReleasePhoneNumbersRequest parseFrom(InputStream inputStream) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ReleasePhoneNumbersRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ReleasePhoneNumbersRequest parseFrom(CodedInputStream codedInputStream) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ReleasePhoneNumbersRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ReleasePhoneNumbersRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ReleasePhoneNumbersResponse extends GeneratedMessageLite<ReleasePhoneNumbersResponse, Builder> implements ReleasePhoneNumbersResponseOrBuilder {
        private static final ReleasePhoneNumbersResponse DEFAULT_INSTANCE;
        private static volatile Parser<ReleasePhoneNumbersResponse> PARSER;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ReleasePhoneNumbersResponse, Builder> implements ReleasePhoneNumbersResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ReleasePhoneNumbersResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ReleasePhoneNumbersResponse releasePhoneNumbersResponse = new ReleasePhoneNumbersResponse();
            DEFAULT_INSTANCE = releasePhoneNumbersResponse;
            GeneratedMessageLite.registerDefaultInstance(ReleasePhoneNumbersResponse.class, releasePhoneNumbersResponse);
        }

        private ReleasePhoneNumbersResponse() {
        }

        public static ReleasePhoneNumbersResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ReleasePhoneNumbersResponse parseDelimitedFrom(InputStream inputStream) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ReleasePhoneNumbersResponse parseFrom(ByteBuffer byteBuffer) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ReleasePhoneNumbersResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ReleasePhoneNumbersResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0000", (Object[]) null);
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ReleasePhoneNumbersResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ReleasePhoneNumbersResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public static Builder newBuilder(ReleasePhoneNumbersResponse releasePhoneNumbersResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(releasePhoneNumbersResponse);
        }

        public static ReleasePhoneNumbersResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ReleasePhoneNumbersResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ReleasePhoneNumbersResponse parseFrom(ByteString byteString) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ReleasePhoneNumbersResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ReleasePhoneNumbersResponse parseFrom(byte[] bArr) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ReleasePhoneNumbersResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ReleasePhoneNumbersResponse parseFrom(InputStream inputStream) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ReleasePhoneNumbersResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ReleasePhoneNumbersResponse parseFrom(CodedInputStream codedInputStream) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ReleasePhoneNumbersResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReleasePhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ReleasePhoneNumbersResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SearchPhoneNumbersRequest extends GeneratedMessageLite<SearchPhoneNumbersRequest, Builder> implements SearchPhoneNumbersRequestOrBuilder {
        public static final int AREA_CODE_FIELD_NUMBER = 2;
        public static final int COUNTRY_CODE_FIELD_NUMBER = 1;
        private static final SearchPhoneNumbersRequest DEFAULT_INSTANCE;
        public static final int LIMIT_FIELD_NUMBER = 3;
        public static final int PAGE_TOKEN_FIELD_NUMBER = 4;
        private static volatile Parser<SearchPhoneNumbersRequest> PARSER;
        private String areaCode_;
        private String countryCode_;
        private int limit_;
        private LivekitModels.TokenPagination pageToken_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SearchPhoneNumbersRequest, Builder> implements SearchPhoneNumbersRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SearchPhoneNumbersRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            SearchPhoneNumbersRequest searchPhoneNumbersRequest = new SearchPhoneNumbersRequest();
            DEFAULT_INSTANCE = searchPhoneNumbersRequest;
            GeneratedMessageLite.registerDefaultInstance(SearchPhoneNumbersRequest.class, searchPhoneNumbersRequest);
        }

        private SearchPhoneNumbersRequest() {
            String strA = ap.a(358561537);
            this.countryCode_ = strA;
            this.areaCode_ = strA;
        }

        private void clearAreaCode() {
            this.areaCode_ = getDefaultInstance().getAreaCode();
        }

        private void clearCountryCode() {
            this.countryCode_ = getDefaultInstance().getCountryCode();
        }

        private void clearLimit() {
            this.limit_ = 0;
        }

        private void clearPageToken() {
            this.pageToken_ = null;
        }

        public static SearchPhoneNumbersRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergePageToken(LivekitModels.TokenPagination tokenPagination) {
            tokenPagination.getClass();
            LivekitModels.TokenPagination tokenPagination2 = this.pageToken_;
            if (tokenPagination2 == null || tokenPagination2 == LivekitModels.TokenPagination.getDefaultInstance()) {
                this.pageToken_ = tokenPagination;
            } else {
                this.pageToken_ = (LivekitModels.TokenPagination) ((LivekitModels.TokenPagination.Builder) LivekitModels.TokenPagination.newBuilder(this.pageToken_).v(tokenPagination)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SearchPhoneNumbersRequest parseDelimitedFrom(InputStream inputStream) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SearchPhoneNumbersRequest parseFrom(ByteBuffer byteBuffer) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SearchPhoneNumbersRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAreaCode(String str) {
            str.getClass();
            this.areaCode_ = str;
        }

        private void setAreaCodeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.areaCode_ = byteString.L();
        }

        private void setCountryCode(String str) {
            str.getClass();
            this.countryCode_ = str;
        }

        private void setCountryCodeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.countryCode_ = byteString.L();
        }

        private void setLimit(int i) {
            this.limit_ = i;
        }

        private void setPageToken(LivekitModels.TokenPagination tokenPagination) {
            tokenPagination.getClass();
            this.pageToken_ = tokenPagination;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SearchPhoneNumbersRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\u0004\u0004\t", new Object[]{"countryCode_", "areaCode_", "limit_", "pageToken_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SearchPhoneNumbersRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SearchPhoneNumbersRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAreaCode() {
            return this.areaCode_;
        }

        public ByteString getAreaCodeBytes() {
            return ByteString.n(this.areaCode_);
        }

        public String getCountryCode() {
            return this.countryCode_;
        }

        public ByteString getCountryCodeBytes() {
            return ByteString.n(this.countryCode_);
        }

        public int getLimit() {
            return this.limit_;
        }

        public LivekitModels.TokenPagination getPageToken() {
            LivekitModels.TokenPagination tokenPagination = this.pageToken_;
            return tokenPagination == null ? LivekitModels.TokenPagination.getDefaultInstance() : tokenPagination;
        }

        public boolean hasPageToken() {
            return this.pageToken_ != null;
        }

        public static Builder newBuilder(SearchPhoneNumbersRequest searchPhoneNumbersRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(searchPhoneNumbersRequest);
        }

        public static SearchPhoneNumbersRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SearchPhoneNumbersRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SearchPhoneNumbersRequest parseFrom(ByteString byteString) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SearchPhoneNumbersRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SearchPhoneNumbersRequest parseFrom(byte[] bArr) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SearchPhoneNumbersRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SearchPhoneNumbersRequest parseFrom(InputStream inputStream) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SearchPhoneNumbersRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SearchPhoneNumbersRequest parseFrom(CodedInputStream codedInputStream) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SearchPhoneNumbersRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SearchPhoneNumbersRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SearchPhoneNumbersResponse extends GeneratedMessageLite<SearchPhoneNumbersResponse, Builder> implements SearchPhoneNumbersResponseOrBuilder {
        private static final SearchPhoneNumbersResponse DEFAULT_INSTANCE;
        public static final int ITEMS_FIELD_NUMBER = 1;
        public static final int NEXT_PAGE_TOKEN_FIELD_NUMBER = 2;
        private static volatile Parser<SearchPhoneNumbersResponse> PARSER;
        private Internal.ProtobufList<PhoneNumber> items_ = GeneratedMessageLite.emptyProtobufList();
        private LivekitModels.TokenPagination nextPageToken_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SearchPhoneNumbersResponse, Builder> implements SearchPhoneNumbersResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SearchPhoneNumbersResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            SearchPhoneNumbersResponse searchPhoneNumbersResponse = new SearchPhoneNumbersResponse();
            DEFAULT_INSTANCE = searchPhoneNumbersResponse;
            GeneratedMessageLite.registerDefaultInstance(SearchPhoneNumbersResponse.class, searchPhoneNumbersResponse);
        }

        private SearchPhoneNumbersResponse() {
        }

        private void addAllItems(Iterable<? extends PhoneNumber> iterable) {
            ensureItemsIsMutable();
            AbstractMessageLite.addAll(iterable, this.items_);
        }

        private void addItems(PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            ensureItemsIsMutable();
            this.items_.add(phoneNumber);
        }

        private void clearItems() {
            this.items_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearNextPageToken() {
            this.nextPageToken_ = null;
        }

        private void ensureItemsIsMutable() {
            Internal.ProtobufList<PhoneNumber> protobufList = this.items_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.items_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SearchPhoneNumbersResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeNextPageToken(LivekitModels.TokenPagination tokenPagination) {
            tokenPagination.getClass();
            LivekitModels.TokenPagination tokenPagination2 = this.nextPageToken_;
            if (tokenPagination2 == null || tokenPagination2 == LivekitModels.TokenPagination.getDefaultInstance()) {
                this.nextPageToken_ = tokenPagination;
            } else {
                this.nextPageToken_ = (LivekitModels.TokenPagination) ((LivekitModels.TokenPagination.Builder) LivekitModels.TokenPagination.newBuilder(this.nextPageToken_).v(tokenPagination)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SearchPhoneNumbersResponse parseDelimitedFrom(InputStream inputStream) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SearchPhoneNumbersResponse parseFrom(ByteBuffer byteBuffer) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SearchPhoneNumbersResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeItems(int i) {
            ensureItemsIsMutable();
            this.items_.remove(i);
        }

        private void setItems(int i, PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            ensureItemsIsMutable();
            this.items_.set(i, phoneNumber);
        }

        private void setNextPageToken(LivekitModels.TokenPagination tokenPagination) {
            tokenPagination.getClass();
            this.nextPageToken_ = tokenPagination;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SearchPhoneNumbersResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\u001b\u0002\t", new Object[]{ap.a(1425333124), PhoneNumber.class, ap.a(900660811)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SearchPhoneNumbersResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SearchPhoneNumbersResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public PhoneNumber getItems(int i) {
            return (PhoneNumber) this.items_.get(i);
        }

        public int getItemsCount() {
            return this.items_.size();
        }

        public List<PhoneNumber> getItemsList() {
            return this.items_;
        }

        public PhoneNumberOrBuilder getItemsOrBuilder(int i) {
            return (PhoneNumberOrBuilder) this.items_.get(i);
        }

        public List<? extends PhoneNumberOrBuilder> getItemsOrBuilderList() {
            return this.items_;
        }

        public LivekitModels.TokenPagination getNextPageToken() {
            LivekitModels.TokenPagination tokenPagination = this.nextPageToken_;
            return tokenPagination == null ? LivekitModels.TokenPagination.getDefaultInstance() : tokenPagination;
        }

        public boolean hasNextPageToken() {
            return this.nextPageToken_ != null;
        }

        public static Builder newBuilder(SearchPhoneNumbersResponse searchPhoneNumbersResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(searchPhoneNumbersResponse);
        }

        public static SearchPhoneNumbersResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SearchPhoneNumbersResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SearchPhoneNumbersResponse parseFrom(ByteString byteString) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addItems(int i, PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            ensureItemsIsMutable();
            this.items_.add(i, phoneNumber);
        }

        public static SearchPhoneNumbersResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SearchPhoneNumbersResponse parseFrom(byte[] bArr) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SearchPhoneNumbersResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SearchPhoneNumbersResponse parseFrom(InputStream inputStream) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SearchPhoneNumbersResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SearchPhoneNumbersResponse parseFrom(CodedInputStream codedInputStream) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SearchPhoneNumbersResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SearchPhoneNumbersResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SearchPhoneNumbersResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdatePhoneNumberRequest extends GeneratedMessageLite<UpdatePhoneNumberRequest, Builder> implements UpdatePhoneNumberRequestOrBuilder {
        private static final UpdatePhoneNumberRequest DEFAULT_INSTANCE;
        public static final int ID_FIELD_NUMBER = 1;
        private static volatile Parser<UpdatePhoneNumberRequest> PARSER = null;
        public static final int PHONE_NUMBER_FIELD_NUMBER = 2;
        public static final int SIP_DISPATCH_RULE_ID_FIELD_NUMBER = 3;
        private String id_;
        private String phoneNumber_;
        private String sipDispatchRuleId_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdatePhoneNumberRequest, Builder> implements UpdatePhoneNumberRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdatePhoneNumberRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdatePhoneNumberRequest updatePhoneNumberRequest = new UpdatePhoneNumberRequest();
            DEFAULT_INSTANCE = updatePhoneNumberRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdatePhoneNumberRequest.class, updatePhoneNumberRequest);
        }

        private UpdatePhoneNumberRequest() {
            String strA = ap.a(1086407942);
            this.id_ = strA;
            this.phoneNumber_ = strA;
            this.sipDispatchRuleId_ = strA;
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearPhoneNumber() {
            this.phoneNumber_ = getDefaultInstance().getPhoneNumber();
        }

        private void clearSipDispatchRuleId() {
            this.sipDispatchRuleId_ = getDefaultInstance().getSipDispatchRuleId();
        }

        public static UpdatePhoneNumberRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdatePhoneNumberRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdatePhoneNumberRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdatePhoneNumberRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setPhoneNumber(String str) {
            str.getClass();
            this.phoneNumber_ = str;
        }

        private void setPhoneNumberBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.phoneNumber_ = byteString.L();
        }

        private void setSipDispatchRuleId(String str) {
            str.getClass();
            this.sipDispatchRuleId_ = str;
        }

        private void setSipDispatchRuleIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipDispatchRuleId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdatePhoneNumberRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ", new Object[]{"id_", "phoneNumber_", "sipDispatchRuleId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdatePhoneNumberRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdatePhoneNumberRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public String getPhoneNumber() {
            return this.phoneNumber_;
        }

        public ByteString getPhoneNumberBytes() {
            return ByteString.n(this.phoneNumber_);
        }

        public String getSipDispatchRuleId() {
            return this.sipDispatchRuleId_;
        }

        public ByteString getSipDispatchRuleIdBytes() {
            return ByteString.n(this.sipDispatchRuleId_);
        }

        public static Builder newBuilder(UpdatePhoneNumberRequest updatePhoneNumberRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updatePhoneNumberRequest);
        }

        public static UpdatePhoneNumberRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdatePhoneNumberRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdatePhoneNumberRequest parseFrom(ByteString byteString) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdatePhoneNumberRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdatePhoneNumberRequest parseFrom(byte[] bArr) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdatePhoneNumberRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdatePhoneNumberRequest parseFrom(InputStream inputStream) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdatePhoneNumberRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdatePhoneNumberRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdatePhoneNumberRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdatePhoneNumberRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdatePhoneNumberResponse extends GeneratedMessageLite<UpdatePhoneNumberResponse, Builder> implements UpdatePhoneNumberResponseOrBuilder {
        private static final UpdatePhoneNumberResponse DEFAULT_INSTANCE;
        private static volatile Parser<UpdatePhoneNumberResponse> PARSER = null;
        public static final int PHONE_NUMBER_FIELD_NUMBER = 1;
        private PhoneNumber phoneNumber_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdatePhoneNumberResponse, Builder> implements UpdatePhoneNumberResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdatePhoneNumberResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdatePhoneNumberResponse updatePhoneNumberResponse = new UpdatePhoneNumberResponse();
            DEFAULT_INSTANCE = updatePhoneNumberResponse;
            GeneratedMessageLite.registerDefaultInstance(UpdatePhoneNumberResponse.class, updatePhoneNumberResponse);
        }

        private UpdatePhoneNumberResponse() {
        }

        private void clearPhoneNumber() {
            this.phoneNumber_ = null;
        }

        public static UpdatePhoneNumberResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergePhoneNumber(PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            PhoneNumber phoneNumber2 = this.phoneNumber_;
            if (phoneNumber2 == null || phoneNumber2 == PhoneNumber.getDefaultInstance()) {
                this.phoneNumber_ = phoneNumber;
            } else {
                this.phoneNumber_ = (PhoneNumber) ((PhoneNumber.Builder) PhoneNumber.newBuilder(this.phoneNumber_).v(phoneNumber)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdatePhoneNumberResponse parseDelimitedFrom(InputStream inputStream) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdatePhoneNumberResponse parseFrom(ByteBuffer byteBuffer) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdatePhoneNumberResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setPhoneNumber(PhoneNumber phoneNumber) {
            phoneNumber.getClass();
            this.phoneNumber_ = phoneNumber;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdatePhoneNumberResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\t", new Object[]{ap.a(1224900883)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdatePhoneNumberResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdatePhoneNumberResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public PhoneNumber getPhoneNumber() {
            PhoneNumber phoneNumber = this.phoneNumber_;
            return phoneNumber == null ? PhoneNumber.getDefaultInstance() : phoneNumber;
        }

        public boolean hasPhoneNumber() {
            return this.phoneNumber_ != null;
        }

        public static Builder newBuilder(UpdatePhoneNumberResponse updatePhoneNumberResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updatePhoneNumberResponse);
        }

        public static UpdatePhoneNumberResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdatePhoneNumberResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdatePhoneNumberResponse parseFrom(ByteString byteString) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdatePhoneNumberResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdatePhoneNumberResponse parseFrom(byte[] bArr) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdatePhoneNumberResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdatePhoneNumberResponse parseFrom(InputStream inputStream) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdatePhoneNumberResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdatePhoneNumberResponse parseFrom(CodedInputStream codedInputStream) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdatePhoneNumberResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdatePhoneNumberResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdatePhoneNumberResponseOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitPhoneNumber() {
    }
}