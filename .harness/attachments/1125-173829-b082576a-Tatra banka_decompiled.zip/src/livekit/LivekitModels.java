package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MapEntryLite;
import com.google.protobuf.MapFieldLite;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import com.google.protobuf.Timestamp;
import com.google.protobuf.WireFormat;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import livekit.LivekitMetrics;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitModels {

    /* JADX INFO: renamed from: livekit.LivekitModels$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public static final class ActiveSpeakerUpdate extends GeneratedMessageLite<ActiveSpeakerUpdate, Builder> implements ActiveSpeakerUpdateOrBuilder {
        private static final ActiveSpeakerUpdate DEFAULT_INSTANCE;
        private static volatile Parser<ActiveSpeakerUpdate> PARSER = null;
        public static final int SPEAKERS_FIELD_NUMBER = 1;
        private Internal.ProtobufList<SpeakerInfo> speakers_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ActiveSpeakerUpdate, Builder> implements ActiveSpeakerUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ActiveSpeakerUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            ActiveSpeakerUpdate activeSpeakerUpdate = new ActiveSpeakerUpdate();
            DEFAULT_INSTANCE = activeSpeakerUpdate;
            GeneratedMessageLite.registerDefaultInstance(ActiveSpeakerUpdate.class, activeSpeakerUpdate);
        }

        private ActiveSpeakerUpdate() {
        }

        private void addAllSpeakers(Iterable<? extends SpeakerInfo> iterable) {
            ensureSpeakersIsMutable();
            AbstractMessageLite.addAll(iterable, this.speakers_);
        }

        private void addSpeakers(SpeakerInfo speakerInfo) {
            speakerInfo.getClass();
            ensureSpeakersIsMutable();
            this.speakers_.add(speakerInfo);
        }

        private void clearSpeakers() {
            this.speakers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureSpeakersIsMutable() {
            Internal.ProtobufList<SpeakerInfo> protobufList = this.speakers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.speakers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ActiveSpeakerUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ActiveSpeakerUpdate parseDelimitedFrom(InputStream inputStream) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ActiveSpeakerUpdate parseFrom(ByteBuffer byteBuffer) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ActiveSpeakerUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSpeakers(int i) {
            ensureSpeakersIsMutable();
            this.speakers_.remove(i);
        }

        private void setSpeakers(int i, SpeakerInfo speakerInfo) {
            speakerInfo.getClass();
            ensureSpeakersIsMutable();
            this.speakers_.set(i, speakerInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ActiveSpeakerUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1700163281), SpeakerInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ActiveSpeakerUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ActiveSpeakerUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SpeakerInfo getSpeakers(int i) {
            return (SpeakerInfo) this.speakers_.get(i);
        }

        public int getSpeakersCount() {
            return this.speakers_.size();
        }

        public List<SpeakerInfo> getSpeakersList() {
            return this.speakers_;
        }

        public SpeakerInfoOrBuilder getSpeakersOrBuilder(int i) {
            return (SpeakerInfoOrBuilder) this.speakers_.get(i);
        }

        public List<? extends SpeakerInfoOrBuilder> getSpeakersOrBuilderList() {
            return this.speakers_;
        }

        public static Builder newBuilder(ActiveSpeakerUpdate activeSpeakerUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(activeSpeakerUpdate);
        }

        public static ActiveSpeakerUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ActiveSpeakerUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ActiveSpeakerUpdate parseFrom(ByteString byteString) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSpeakers(int i, SpeakerInfo speakerInfo) {
            speakerInfo.getClass();
            ensureSpeakersIsMutable();
            this.speakers_.add(i, speakerInfo);
        }

        public static ActiveSpeakerUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ActiveSpeakerUpdate parseFrom(byte[] bArr) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ActiveSpeakerUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ActiveSpeakerUpdate parseFrom(InputStream inputStream) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ActiveSpeakerUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ActiveSpeakerUpdate parseFrom(CodedInputStream codedInputStream) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ActiveSpeakerUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ActiveSpeakerUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public interface ActiveSpeakerUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum AudioCodec implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(-1);

        private static final Internal.EnumLiteMap g = new Internal.EnumLiteMap<AudioCodec>() { // from class: livekit.LivekitModels.AudioCodec.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public AudioCodec findValueByNumber(int i) {
                return AudioCodec.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AudioCodecVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new AudioCodecVerifier();

            private AudioCodecVerifier() {
            }

            public boolean isInRange(int i) {
                return AudioCodec.b(i) != null;
            }
        }

        AudioCodec(int i) {
            this.a = i;
        }

        public static AudioCodec b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i == 2) {
                return d;
            }
            if (i != 3) {
                return null;
            }
            return e;
        }

        public final int getNumber() {
            if (this != f) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum AudioTrackFeature implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(4),
        g(5),
        h(6),
        i(-1);

        private static final Internal.EnumLiteMap j = new Internal.EnumLiteMap<AudioTrackFeature>() { // from class: livekit.LivekitModels.AudioTrackFeature.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public AudioTrackFeature findValueByNumber(int i2) {
                return AudioTrackFeature.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AudioTrackFeatureVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new AudioTrackFeatureVerifier();

            private AudioTrackFeatureVerifier() {
            }

            public boolean isInRange(int i) {
                return AudioTrackFeature.b(i) != null;
            }
        }

        AudioTrackFeature(int i2) {
            this.a = i2;
        }

        public static AudioTrackFeature b(int i2) {
            switch (i2) {
                case 0:
                    return b;
                case 1:
                    return c;
                case 2:
                    return d;
                case 3:
                    return e;
                case 4:
                    return f;
                case 5:
                    return g;
                case 6:
                    return h;
                default:
                    return null;
            }
        }

        public final int getNumber() {
            if (this != i) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum BackupCodecPolicy implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<BackupCodecPolicy>() { // from class: livekit.LivekitModels.BackupCodecPolicy.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public BackupCodecPolicy findValueByNumber(int i) {
                return BackupCodecPolicy.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class BackupCodecPolicyVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new BackupCodecPolicyVerifier();

            private BackupCodecPolicyVerifier() {
            }

            public boolean isInRange(int i) {
                return BackupCodecPolicy.b(i) != null;
            }
        }

        BackupCodecPolicy(int i) {
            this.a = i;
        }

        public static BackupCodecPolicy b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ChatMessage extends GeneratedMessageLite<ChatMessage, Builder> implements ChatMessageOrBuilder {
        private static final ChatMessage DEFAULT_INSTANCE;
        public static final int DELETED_FIELD_NUMBER = 5;
        public static final int EDIT_TIMESTAMP_FIELD_NUMBER = 3;
        public static final int GENERATED_FIELD_NUMBER = 6;
        public static final int ID_FIELD_NUMBER = 1;
        public static final int MESSAGE_FIELD_NUMBER = 4;
        private static volatile Parser<ChatMessage> PARSER = null;
        public static final int TIMESTAMP_FIELD_NUMBER = 2;
        private int bitField0_;
        private boolean deleted_;
        private long editTimestamp_;
        private boolean generated_;
        private String id_;
        private String message_;
        private long timestamp_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ChatMessage, Builder> implements ChatMessageOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ChatMessage.DEFAULT_INSTANCE);
            }
        }

        static {
            ChatMessage chatMessage = new ChatMessage();
            DEFAULT_INSTANCE = chatMessage;
            GeneratedMessageLite.registerDefaultInstance(ChatMessage.class, chatMessage);
        }

        private ChatMessage() {
            String strA = ap.a(2032393329);
            this.id_ = strA;
            this.message_ = strA;
        }

        private void clearDeleted() {
            this.deleted_ = false;
        }

        private void clearEditTimestamp() {
            this.bitField0_ &= -2;
            this.editTimestamp_ = 0L;
        }

        private void clearGenerated() {
            this.generated_ = false;
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearMessage() {
            this.message_ = getDefaultInstance().getMessage();
        }

        private void clearTimestamp() {
            this.timestamp_ = 0L;
        }

        public static ChatMessage getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ChatMessage parseDelimitedFrom(InputStream inputStream) {
            return (ChatMessage) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ChatMessage parseFrom(ByteBuffer byteBuffer) {
            return (ChatMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ChatMessage> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDeleted(boolean z) {
            this.deleted_ = z;
        }

        private void setEditTimestamp(long j) {
            this.bitField0_ |= 1;
            this.editTimestamp_ = j;
        }

        private void setGenerated(boolean z) {
            this.generated_ = z;
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setMessage(String str) {
            str.getClass();
            this.message_ = str;
        }

        private void setMessageBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.message_ = byteString.L();
        }

        private void setTimestamp(long j) {
            this.timestamp_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ChatMessage();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0001\u0001\u0006\u0006\u0000\u0000\u0000\u0001Ȉ\u0002\u0002\u0003ဂ\u0000\u0004Ȉ\u0005\u0007\u0006\u0007", new Object[]{"bitField0_", "id_", "timestamp_", "editTimestamp_", "message_", "deleted_", "generated_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ChatMessage> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ChatMessage.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getDeleted() {
            return this.deleted_;
        }

        public long getEditTimestamp() {
            return this.editTimestamp_;
        }

        public boolean getGenerated() {
            return this.generated_;
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public String getMessage() {
            return this.message_;
        }

        public ByteString getMessageBytes() {
            return ByteString.n(this.message_);
        }

        public long getTimestamp() {
            return this.timestamp_;
        }

        public boolean hasEditTimestamp() {
            return (this.bitField0_ & 1) != 0;
        }

        public static Builder newBuilder(ChatMessage chatMessage) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(chatMessage);
        }

        public static ChatMessage parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ChatMessage) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ChatMessage parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ChatMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ChatMessage parseFrom(ByteString byteString) {
            return (ChatMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ChatMessage parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ChatMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ChatMessage parseFrom(byte[] bArr) {
            return (ChatMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ChatMessage parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ChatMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ChatMessage parseFrom(InputStream inputStream) {
            return (ChatMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ChatMessage parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ChatMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ChatMessage parseFrom(CodedInputStream codedInputStream) {
            return (ChatMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ChatMessage parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ChatMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ChatMessageOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum ClientConfigSetting implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<ClientConfigSetting>() { // from class: livekit.LivekitModels.ClientConfigSetting.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public ClientConfigSetting findValueByNumber(int i) {
                return ClientConfigSetting.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class ClientConfigSettingVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new ClientConfigSettingVerifier();

            private ClientConfigSettingVerifier() {
            }

            public boolean isInRange(int i) {
                return ClientConfigSetting.b(i) != null;
            }
        }

        ClientConfigSetting(int i) {
            this.a = i;
        }

        public static ClientConfigSetting b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ClientConfiguration extends GeneratedMessageLite<ClientConfiguration, Builder> implements ClientConfigurationOrBuilder {
        private static final ClientConfiguration DEFAULT_INSTANCE;
        public static final int DISABLED_CODECS_FIELD_NUMBER = 4;
        public static final int FORCE_RELAY_FIELD_NUMBER = 5;
        private static volatile Parser<ClientConfiguration> PARSER = null;
        public static final int RESUME_CONNECTION_FIELD_NUMBER = 3;
        public static final int SCREEN_FIELD_NUMBER = 2;
        public static final int VIDEO_FIELD_NUMBER = 1;
        private DisabledCodecs disabledCodecs_;
        private int forceRelay_;
        private int resumeConnection_;
        private VideoConfiguration screen_;
        private VideoConfiguration video_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ClientConfiguration, Builder> implements ClientConfigurationOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ClientConfiguration.DEFAULT_INSTANCE);
            }
        }

        static {
            ClientConfiguration clientConfiguration = new ClientConfiguration();
            DEFAULT_INSTANCE = clientConfiguration;
            GeneratedMessageLite.registerDefaultInstance(ClientConfiguration.class, clientConfiguration);
        }

        private ClientConfiguration() {
        }

        private void clearDisabledCodecs() {
            this.disabledCodecs_ = null;
        }

        private void clearForceRelay() {
            this.forceRelay_ = 0;
        }

        private void clearResumeConnection() {
            this.resumeConnection_ = 0;
        }

        private void clearScreen() {
            this.screen_ = null;
        }

        private void clearVideo() {
            this.video_ = null;
        }

        public static ClientConfiguration getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeDisabledCodecs(DisabledCodecs disabledCodecs) {
            disabledCodecs.getClass();
            DisabledCodecs disabledCodecs2 = this.disabledCodecs_;
            if (disabledCodecs2 == null || disabledCodecs2 == DisabledCodecs.getDefaultInstance()) {
                this.disabledCodecs_ = disabledCodecs;
            } else {
                this.disabledCodecs_ = (DisabledCodecs) ((DisabledCodecs.Builder) DisabledCodecs.newBuilder(this.disabledCodecs_).v(disabledCodecs)).o();
            }
        }

        private void mergeScreen(VideoConfiguration videoConfiguration) {
            videoConfiguration.getClass();
            VideoConfiguration videoConfiguration2 = this.screen_;
            if (videoConfiguration2 == null || videoConfiguration2 == VideoConfiguration.getDefaultInstance()) {
                this.screen_ = videoConfiguration;
            } else {
                this.screen_ = (VideoConfiguration) ((VideoConfiguration.Builder) VideoConfiguration.newBuilder(this.screen_).v(videoConfiguration)).o();
            }
        }

        private void mergeVideo(VideoConfiguration videoConfiguration) {
            videoConfiguration.getClass();
            VideoConfiguration videoConfiguration2 = this.video_;
            if (videoConfiguration2 == null || videoConfiguration2 == VideoConfiguration.getDefaultInstance()) {
                this.video_ = videoConfiguration;
            } else {
                this.video_ = (VideoConfiguration) ((VideoConfiguration.Builder) VideoConfiguration.newBuilder(this.video_).v(videoConfiguration)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ClientConfiguration parseDelimitedFrom(InputStream inputStream) {
            return (ClientConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ClientConfiguration parseFrom(ByteBuffer byteBuffer) {
            return (ClientConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ClientConfiguration> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDisabledCodecs(DisabledCodecs disabledCodecs) {
            disabledCodecs.getClass();
            this.disabledCodecs_ = disabledCodecs;
        }

        private void setForceRelay(ClientConfigSetting clientConfigSetting) {
            this.forceRelay_ = clientConfigSetting.getNumber();
        }

        private void setForceRelayValue(int i) {
            this.forceRelay_ = i;
        }

        private void setResumeConnection(ClientConfigSetting clientConfigSetting) {
            this.resumeConnection_ = clientConfigSetting.getNumber();
        }

        private void setResumeConnectionValue(int i) {
            this.resumeConnection_ = i;
        }

        private void setScreen(VideoConfiguration videoConfiguration) {
            videoConfiguration.getClass();
            this.screen_ = videoConfiguration;
        }

        private void setVideo(VideoConfiguration videoConfiguration) {
            videoConfiguration.getClass();
            this.video_ = videoConfiguration;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ClientConfiguration();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001\t\u0002\t\u0003\f\u0004\t\u0005\f", new Object[]{ap.a(210535488), ap.a(980145817), ap.a(1504353639), ap.a(1710704162), ap.a(686022561)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ClientConfiguration> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ClientConfiguration.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public DisabledCodecs getDisabledCodecs() {
            DisabledCodecs disabledCodecs = this.disabledCodecs_;
            return disabledCodecs == null ? DisabledCodecs.getDefaultInstance() : disabledCodecs;
        }

        public ClientConfigSetting getForceRelay() {
            ClientConfigSetting clientConfigSettingB = ClientConfigSetting.b(this.forceRelay_);
            return clientConfigSettingB == null ? ClientConfigSetting.e : clientConfigSettingB;
        }

        public int getForceRelayValue() {
            return this.forceRelay_;
        }

        public ClientConfigSetting getResumeConnection() {
            ClientConfigSetting clientConfigSettingB = ClientConfigSetting.b(this.resumeConnection_);
            return clientConfigSettingB == null ? ClientConfigSetting.e : clientConfigSettingB;
        }

        public int getResumeConnectionValue() {
            return this.resumeConnection_;
        }

        public VideoConfiguration getScreen() {
            VideoConfiguration videoConfiguration = this.screen_;
            return videoConfiguration == null ? VideoConfiguration.getDefaultInstance() : videoConfiguration;
        }

        public VideoConfiguration getVideo() {
            VideoConfiguration videoConfiguration = this.video_;
            return videoConfiguration == null ? VideoConfiguration.getDefaultInstance() : videoConfiguration;
        }

        public boolean hasDisabledCodecs() {
            return this.disabledCodecs_ != null;
        }

        public boolean hasScreen() {
            return this.screen_ != null;
        }

        public boolean hasVideo() {
            return this.video_ != null;
        }

        public static Builder newBuilder(ClientConfiguration clientConfiguration) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(clientConfiguration);
        }

        public static ClientConfiguration parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ClientConfiguration parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ClientConfiguration parseFrom(ByteString byteString) {
            return (ClientConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ClientConfiguration parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ClientConfiguration parseFrom(byte[] bArr) {
            return (ClientConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ClientConfiguration parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ClientConfiguration parseFrom(InputStream inputStream) {
            return (ClientConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ClientConfiguration parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ClientConfiguration parseFrom(CodedInputStream codedInputStream) {
            return (ClientConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ClientConfiguration parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ClientConfigurationOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ClientInfo extends GeneratedMessageLite<ClientInfo, Builder> implements ClientInfoOrBuilder {
        public static final int ADDRESS_FIELD_NUMBER = 9;
        public static final int BROWSER_FIELD_NUMBER = 7;
        public static final int BROWSER_VERSION_FIELD_NUMBER = 8;
        private static final ClientInfo DEFAULT_INSTANCE;
        public static final int DEVICE_MODEL_FIELD_NUMBER = 6;
        public static final int NETWORK_FIELD_NUMBER = 10;
        public static final int OS_FIELD_NUMBER = 4;
        public static final int OS_VERSION_FIELD_NUMBER = 5;
        public static final int OTHER_SDKS_FIELD_NUMBER = 11;
        private static volatile Parser<ClientInfo> PARSER = null;
        public static final int PROTOCOL_FIELD_NUMBER = 3;
        public static final int SDK_FIELD_NUMBER = 1;
        public static final int VERSION_FIELD_NUMBER = 2;
        private String address_;
        private String browserVersion_;
        private String browser_;
        private String deviceModel_;
        private String network_;
        private String osVersion_;
        private String os_;
        private String otherSdks_;
        private int protocol_;
        private int sdk_;
        private String version_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ClientInfo, Builder> implements ClientInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(String str) {
                q();
                ((ClientInfo) ((GeneratedMessageLite.Builder) this).b).setDeviceModel(str);
                return this;
            }

            public Builder B(String str) {
                q();
                ((ClientInfo) ((GeneratedMessageLite.Builder) this).b).setOs(str);
                return this;
            }

            public Builder C(String str) {
                q();
                ((ClientInfo) ((GeneratedMessageLite.Builder) this).b).setOsVersion(str);
                return this;
            }

            public Builder D(SDK sdk) {
                q();
                ((ClientInfo) ((GeneratedMessageLite.Builder) this).b).setSdk(sdk);
                return this;
            }

            public Builder E(String str) {
                q();
                ((ClientInfo) ((GeneratedMessageLite.Builder) this).b).setVersion(str);
                return this;
            }

            private Builder() {
                super(ClientInfo.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum SDK implements Internal.EnumLite {
            b(0),
            c(1),
            d(2),
            e(3),
            f(4),
            g(5),
            h(6),
            i(7),
            j(8),
            k(9),
            l(10),
            m(11),
            n(12),
            o(13),
            p(14),
            q(-1);

            private static final Internal.EnumLiteMap r = new Internal.EnumLiteMap<SDK>() { // from class: livekit.LivekitModels.ClientInfo.SDK.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public SDK findValueByNumber(int i2) {
                    return SDK.b(i2);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class SDKVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new SDKVerifier();

                private SDKVerifier() {
                }

                public boolean isInRange(int i) {
                    return SDK.b(i) != null;
                }
            }

            SDK(int i2) {
                this.a = i2;
            }

            public static SDK b(int i2) {
                switch (i2) {
                    case 0:
                        return b;
                    case 1:
                        return c;
                    case 2:
                        return d;
                    case 3:
                        return e;
                    case 4:
                        return f;
                    case 5:
                        return g;
                    case 6:
                        return h;
                    case 7:
                        return i;
                    case 8:
                        return j;
                    case 9:
                        return k;
                    case 10:
                        return l;
                    case 11:
                        return m;
                    case 12:
                        return n;
                    case 13:
                        return o;
                    case 14:
                        return p;
                    default:
                        return null;
                }
            }

            public final int getNumber() {
                if (this != q) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        static {
            ClientInfo clientInfo = new ClientInfo();
            DEFAULT_INSTANCE = clientInfo;
            GeneratedMessageLite.registerDefaultInstance(ClientInfo.class, clientInfo);
        }

        private ClientInfo() {
            String strA = ap.a(498779833);
            this.version_ = strA;
            this.os_ = strA;
            this.osVersion_ = strA;
            this.deviceModel_ = strA;
            this.browser_ = strA;
            this.browserVersion_ = strA;
            this.address_ = strA;
            this.network_ = strA;
            this.otherSdks_ = strA;
        }

        private void clearAddress() {
            this.address_ = getDefaultInstance().getAddress();
        }

        private void clearBrowser() {
            this.browser_ = getDefaultInstance().getBrowser();
        }

        private void clearBrowserVersion() {
            this.browserVersion_ = getDefaultInstance().getBrowserVersion();
        }

        private void clearDeviceModel() {
            this.deviceModel_ = getDefaultInstance().getDeviceModel();
        }

        private void clearNetwork() {
            this.network_ = getDefaultInstance().getNetwork();
        }

        private void clearOs() {
            this.os_ = getDefaultInstance().getOs();
        }

        private void clearOsVersion() {
            this.osVersion_ = getDefaultInstance().getOsVersion();
        }

        private void clearOtherSdks() {
            this.otherSdks_ = getDefaultInstance().getOtherSdks();
        }

        private void clearProtocol() {
            this.protocol_ = 0;
        }

        private void clearSdk() {
            this.sdk_ = 0;
        }

        private void clearVersion() {
            this.version_ = getDefaultInstance().getVersion();
        }

        public static ClientInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ClientInfo parseDelimitedFrom(InputStream inputStream) {
            return (ClientInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ClientInfo parseFrom(ByteBuffer byteBuffer) {
            return (ClientInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ClientInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAddress(String str) {
            str.getClass();
            this.address_ = str;
        }

        private void setAddressBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.address_ = byteString.L();
        }

        private void setBrowser(String str) {
            str.getClass();
            this.browser_ = str;
        }

        private void setBrowserBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.browser_ = byteString.L();
        }

        private void setBrowserVersion(String str) {
            str.getClass();
            this.browserVersion_ = str;
        }

        private void setBrowserVersionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.browserVersion_ = byteString.L();
        }

        private void setDeviceModel(String str) {
            str.getClass();
            this.deviceModel_ = str;
        }

        private void setDeviceModelBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.deviceModel_ = byteString.L();
        }

        private void setNetwork(String str) {
            str.getClass();
            this.network_ = str;
        }

        private void setNetworkBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.network_ = byteString.L();
        }

        private void setOs(String str) {
            str.getClass();
            this.os_ = str;
        }

        private void setOsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.os_ = byteString.L();
        }

        private void setOsVersion(String str) {
            str.getClass();
            this.osVersion_ = str;
        }

        private void setOsVersionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.osVersion_ = byteString.L();
        }

        private void setOtherSdks(String str) {
            str.getClass();
            this.otherSdks_ = str;
        }

        private void setOtherSdksBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.otherSdks_ = byteString.L();
        }

        private void setProtocol(int i) {
            this.protocol_ = i;
        }

        private void setSdk(SDK sdk) {
            this.sdk_ = sdk.getNumber();
        }

        private void setSdkValue(int i) {
            this.sdk_ = i;
        }

        private void setVersion(String str) {
            str.getClass();
            this.version_ = str;
        }

        private void setVersionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.version_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ClientInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000b\u0000\u0000\u0001\u000b\u000b\u0000\u0000\u0000\u0001\f\u0002Ȉ\u0003\u0004\u0004Ȉ\u0005Ȉ\u0006Ȉ\u0007Ȉ\bȈ\tȈ\nȈ\u000bȈ", new Object[]{"sdk_", "version_", "protocol_", "os_", "osVersion_", "deviceModel_", "browser_", "browserVersion_", "address_", "network_", "otherSdks_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ClientInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ClientInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAddress() {
            return this.address_;
        }

        public ByteString getAddressBytes() {
            return ByteString.n(this.address_);
        }

        public String getBrowser() {
            return this.browser_;
        }

        public ByteString getBrowserBytes() {
            return ByteString.n(this.browser_);
        }

        public String getBrowserVersion() {
            return this.browserVersion_;
        }

        public ByteString getBrowserVersionBytes() {
            return ByteString.n(this.browserVersion_);
        }

        public String getDeviceModel() {
            return this.deviceModel_;
        }

        public ByteString getDeviceModelBytes() {
            return ByteString.n(this.deviceModel_);
        }

        public String getNetwork() {
            return this.network_;
        }

        public ByteString getNetworkBytes() {
            return ByteString.n(this.network_);
        }

        public String getOs() {
            return this.os_;
        }

        public ByteString getOsBytes() {
            return ByteString.n(this.os_);
        }

        public String getOsVersion() {
            return this.osVersion_;
        }

        public ByteString getOsVersionBytes() {
            return ByteString.n(this.osVersion_);
        }

        public String getOtherSdks() {
            return this.otherSdks_;
        }

        public ByteString getOtherSdksBytes() {
            return ByteString.n(this.otherSdks_);
        }

        public int getProtocol() {
            return this.protocol_;
        }

        public SDK getSdk() {
            SDK sdkB = SDK.b(this.sdk_);
            return sdkB == null ? SDK.q : sdkB;
        }

        public int getSdkValue() {
            return this.sdk_;
        }

        public String getVersion() {
            return this.version_;
        }

        public ByteString getVersionBytes() {
            return ByteString.n(this.version_);
        }

        public static Builder newBuilder(ClientInfo clientInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(clientInfo);
        }

        public static ClientInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ClientInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ClientInfo parseFrom(ByteString byteString) {
            return (ClientInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ClientInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ClientInfo parseFrom(byte[] bArr) {
            return (ClientInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ClientInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ClientInfo parseFrom(InputStream inputStream) {
            return (ClientInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ClientInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ClientInfo parseFrom(CodedInputStream codedInputStream) {
            return (ClientInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ClientInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ClientInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class Codec extends GeneratedMessageLite<Codec, Builder> implements CodecOrBuilder {
        private static final Codec DEFAULT_INSTANCE;
        public static final int FMTP_LINE_FIELD_NUMBER = 2;
        public static final int MIME_FIELD_NUMBER = 1;
        private static volatile Parser<Codec> PARSER;
        private String fmtpLine_;
        private String mime_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<Codec, Builder> implements CodecOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(Codec.DEFAULT_INSTANCE);
            }
        }

        static {
            Codec codec = new Codec();
            DEFAULT_INSTANCE = codec;
            GeneratedMessageLite.registerDefaultInstance(Codec.class, codec);
        }

        private Codec() {
            String strA = ap.a(482079056);
            this.mime_ = strA;
            this.fmtpLine_ = strA;
        }

        private void clearFmtpLine() {
            this.fmtpLine_ = getDefaultInstance().getFmtpLine();
        }

        private void clearMime() {
            this.mime_ = getDefaultInstance().getMime();
        }

        public static Codec getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static Codec parseDelimitedFrom(InputStream inputStream) {
            return (Codec) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Codec parseFrom(ByteBuffer byteBuffer) {
            return (Codec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<Codec> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setFmtpLine(String str) {
            str.getClass();
            this.fmtpLine_ = str;
        }

        private void setFmtpLineBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.fmtpLine_ = byteString.L();
        }

        private void setMime(String str) {
            str.getClass();
            this.mime_ = str;
        }

        private void setMimeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.mime_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new Codec();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"mime_", "fmtpLine_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<Codec> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (Codec.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getFmtpLine() {
            return this.fmtpLine_;
        }

        public ByteString getFmtpLineBytes() {
            return ByteString.n(this.fmtpLine_);
        }

        public String getMime() {
            return this.mime_;
        }

        public ByteString getMimeBytes() {
            return ByteString.n(this.mime_);
        }

        public static Builder newBuilder(Codec codec) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(codec);
        }

        public static Codec parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Codec) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Codec parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (Codec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static Codec parseFrom(ByteString byteString) {
            return (Codec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static Codec parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (Codec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static Codec parseFrom(byte[] bArr) {
            return (Codec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static Codec parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (Codec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static Codec parseFrom(InputStream inputStream) {
            return (Codec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Codec parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Codec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Codec parseFrom(CodedInputStream codedInputStream) {
            return (Codec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static Codec parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Codec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface CodecOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum ConnectionQuality implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(-1);

        private static final Internal.EnumLiteMap g = new Internal.EnumLiteMap<ConnectionQuality>() { // from class: livekit.LivekitModels.ConnectionQuality.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public ConnectionQuality findValueByNumber(int i) {
                return ConnectionQuality.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class ConnectionQualityVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new ConnectionQualityVerifier();

            private ConnectionQualityVerifier() {
            }

            public boolean isInRange(int i) {
                return ConnectionQuality.b(i) != null;
            }
        }

        ConnectionQuality(int i) {
            this.a = i;
        }

        public static ConnectionQuality b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i == 2) {
                return d;
            }
            if (i != 3) {
                return null;
            }
            return e;
        }

        public final int getNumber() {
            if (this != f) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DataPacket extends GeneratedMessageLite<DataPacket, Builder> implements DataPacketOrBuilder {
        public static final int CHAT_MESSAGE_FIELD_NUMBER = 9;
        private static final DataPacket DEFAULT_INSTANCE;
        public static final int DESTINATION_IDENTITIES_FIELD_NUMBER = 5;
        public static final int ENCRYPTED_PACKET_FIELD_NUMBER = 18;
        public static final int KIND_FIELD_NUMBER = 1;
        public static final int METRICS_FIELD_NUMBER = 8;
        private static volatile Parser<DataPacket> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 4;
        public static final int PARTICIPANT_SID_FIELD_NUMBER = 17;
        public static final int RPC_ACK_FIELD_NUMBER = 11;
        public static final int RPC_REQUEST_FIELD_NUMBER = 10;
        public static final int RPC_RESPONSE_FIELD_NUMBER = 12;
        public static final int SEQUENCE_FIELD_NUMBER = 16;
        public static final int SIP_DTMF_FIELD_NUMBER = 6;
        public static final int SPEAKER_FIELD_NUMBER = 3;
        public static final int STREAM_CHUNK_FIELD_NUMBER = 14;
        public static final int STREAM_HEADER_FIELD_NUMBER = 13;
        public static final int STREAM_TRAILER_FIELD_NUMBER = 15;
        public static final int TRANSCRIPTION_FIELD_NUMBER = 7;
        public static final int USER_FIELD_NUMBER = 2;
        private Internal.ProtobufList<String> destinationIdentities_;
        private int kind_;
        private String participantIdentity_;
        private String participantSid_;
        private int sequence_;
        private int valueCase_ = 0;
        private Object value_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DataPacket, Builder> implements DataPacketOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(Iterable iterable) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).addAllDestinationIdentities(iterable);
                return this;
            }

            public Builder B(String str) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).addDestinationIdentities(str);
                return this;
            }

            public Builder C(ChatMessage chatMessage) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setChatMessage(chatMessage);
                return this;
            }

            public Builder D(EncryptedPacket encryptedPacket) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setEncryptedPacket(encryptedPacket);
                return this;
            }

            public Builder E(Kind kind) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setKind(kind);
                return this;
            }

            public Builder F(LivekitMetrics.MetricsBatch metricsBatch) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setMetrics(metricsBatch);
                return this;
            }

            public Builder G(RpcAck rpcAck) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setRpcAck(rpcAck);
                return this;
            }

            public Builder H(RpcRequest rpcRequest) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setRpcRequest(rpcRequest);
                return this;
            }

            public Builder I(RpcResponse rpcResponse) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setRpcResponse(rpcResponse);
                return this;
            }

            public Builder J(int i) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setSequence(i);
                return this;
            }

            public Builder K(SipDTMF sipDTMF) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setSipDtmf(sipDTMF);
                return this;
            }

            public Builder L(DataStream.Chunk chunk) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setStreamChunk(chunk);
                return this;
            }

            public Builder M(DataStream.Header header) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setStreamHeader(header);
                return this;
            }

            public Builder N(DataStream.Trailer trailer) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setStreamTrailer(trailer);
                return this;
            }

            public Builder O(UserPacket.Builder builder) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setUser((UserPacket) builder.n());
                return this;
            }

            public Builder P(UserPacket userPacket) {
                q();
                ((DataPacket) ((GeneratedMessageLite.Builder) this).b).setUser(userPacket);
                return this;
            }

            private Builder() {
                super(DataPacket.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum Kind implements Internal.EnumLite {
            b(0),
            c(1),
            d(-1);

            private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<Kind>() { // from class: livekit.LivekitModels.DataPacket.Kind.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public Kind findValueByNumber(int i) {
                    return Kind.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class KindVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new KindVerifier();

                private KindVerifier() {
                }

                public boolean isInRange(int i) {
                    return Kind.b(i) != null;
                }
            }

            Kind(int i) {
                this.a = i;
            }

            public static Kind b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i != 1) {
                    return null;
                }
                return c;
            }

            public final int getNumber() {
                if (this != d) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum ValueCase {
            b(2),
            c(3),
            d(6),
            e(7),
            f(8),
            g(9),
            h(10),
            i(11),
            j(12),
            k(13),
            l(14),
            m(15),
            n(18),
            o(0);

            private final int a;

            ValueCase(int i2) {
                this.a = i2;
            }

            public static ValueCase b(int i2) {
                if (i2 == 0) {
                    return o;
                }
                if (i2 == 18) {
                    return n;
                }
                if (i2 == 2) {
                    return b;
                }
                if (i2 == 3) {
                    return c;
                }
                switch (i2) {
                    case 6:
                        return d;
                    case 7:
                        return e;
                    case 8:
                        return f;
                    case 9:
                        return g;
                    case 10:
                        return h;
                    case 11:
                        return i;
                    case 12:
                        return j;
                    case 13:
                        return k;
                    case 14:
                        return l;
                    case 15:
                        return m;
                    default:
                        return null;
                }
            }
        }

        static {
            DataPacket dataPacket = new DataPacket();
            DEFAULT_INSTANCE = dataPacket;
            GeneratedMessageLite.registerDefaultInstance(DataPacket.class, dataPacket);
        }

        private DataPacket() {
            String strA = ap.a(2010202974);
            this.participantIdentity_ = strA;
            this.destinationIdentities_ = GeneratedMessageLite.emptyProtobufList();
            this.participantSid_ = strA;
        }

        private void addAllDestinationIdentities(Iterable<String> iterable) {
            ensureDestinationIdentitiesIsMutable();
            AbstractMessageLite.addAll(iterable, this.destinationIdentities_);
        }

        private void addDestinationIdentities(String str) {
            str.getClass();
            ensureDestinationIdentitiesIsMutable();
            this.destinationIdentities_.add(str);
        }

        private void addDestinationIdentitiesBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureDestinationIdentitiesIsMutable();
            this.destinationIdentities_.add(byteString.L());
        }

        private void clearChatMessage() {
            if (this.valueCase_ == 9) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearDestinationIdentities() {
            this.destinationIdentities_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearEncryptedPacket() {
            if (this.valueCase_ == 18) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearKind() {
            this.kind_ = 0;
        }

        private void clearMetrics() {
            if (this.valueCase_ == 8) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearParticipantSid() {
            this.participantSid_ = getDefaultInstance().getParticipantSid();
        }

        private void clearRpcAck() {
            if (this.valueCase_ == 11) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearRpcRequest() {
            if (this.valueCase_ == 10) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearRpcResponse() {
            if (this.valueCase_ == 12) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearSequence() {
            this.sequence_ = 0;
        }

        private void clearSipDtmf() {
            if (this.valueCase_ == 6) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearSpeaker() {
            if (this.valueCase_ == 3) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearStreamChunk() {
            if (this.valueCase_ == 14) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearStreamHeader() {
            if (this.valueCase_ == 13) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearStreamTrailer() {
            if (this.valueCase_ == 15) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearTranscription() {
            if (this.valueCase_ == 7) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearUser() {
            if (this.valueCase_ == 2) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearValue() {
            this.valueCase_ = 0;
            this.value_ = null;
        }

        private void ensureDestinationIdentitiesIsMutable() {
            Internal.ProtobufList<String> protobufList = this.destinationIdentities_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.destinationIdentities_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static DataPacket getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeChatMessage(ChatMessage chatMessage) {
            chatMessage.getClass();
            if (this.valueCase_ != 9 || this.value_ == ChatMessage.getDefaultInstance()) {
                this.value_ = chatMessage;
            } else {
                this.value_ = ((ChatMessage.Builder) ChatMessage.newBuilder((ChatMessage) this.value_).v(chatMessage)).o();
            }
            this.valueCase_ = 9;
        }

        private void mergeEncryptedPacket(EncryptedPacket encryptedPacket) {
            encryptedPacket.getClass();
            if (this.valueCase_ != 18 || this.value_ == EncryptedPacket.getDefaultInstance()) {
                this.value_ = encryptedPacket;
            } else {
                this.value_ = ((EncryptedPacket.Builder) EncryptedPacket.newBuilder((EncryptedPacket) this.value_).v(encryptedPacket)).o();
            }
            this.valueCase_ = 18;
        }

        private void mergeMetrics(LivekitMetrics.MetricsBatch metricsBatch) {
            metricsBatch.getClass();
            if (this.valueCase_ != 8 || this.value_ == LivekitMetrics.MetricsBatch.getDefaultInstance()) {
                this.value_ = metricsBatch;
            } else {
                this.value_ = ((LivekitMetrics.MetricsBatch.Builder) LivekitMetrics.MetricsBatch.newBuilder((LivekitMetrics.MetricsBatch) this.value_).v(metricsBatch)).o();
            }
            this.valueCase_ = 8;
        }

        private void mergeRpcAck(RpcAck rpcAck) {
            rpcAck.getClass();
            if (this.valueCase_ != 11 || this.value_ == RpcAck.getDefaultInstance()) {
                this.value_ = rpcAck;
            } else {
                this.value_ = ((RpcAck.Builder) RpcAck.newBuilder((RpcAck) this.value_).v(rpcAck)).o();
            }
            this.valueCase_ = 11;
        }

        private void mergeRpcRequest(RpcRequest rpcRequest) {
            rpcRequest.getClass();
            if (this.valueCase_ != 10 || this.value_ == RpcRequest.getDefaultInstance()) {
                this.value_ = rpcRequest;
            } else {
                this.value_ = ((RpcRequest.Builder) RpcRequest.newBuilder((RpcRequest) this.value_).v(rpcRequest)).o();
            }
            this.valueCase_ = 10;
        }

        private void mergeRpcResponse(RpcResponse rpcResponse) {
            rpcResponse.getClass();
            if (this.valueCase_ != 12 || this.value_ == RpcResponse.getDefaultInstance()) {
                this.value_ = rpcResponse;
            } else {
                this.value_ = ((RpcResponse.Builder) RpcResponse.newBuilder((RpcResponse) this.value_).v(rpcResponse)).o();
            }
            this.valueCase_ = 12;
        }

        private void mergeSipDtmf(SipDTMF sipDTMF) {
            sipDTMF.getClass();
            if (this.valueCase_ != 6 || this.value_ == SipDTMF.getDefaultInstance()) {
                this.value_ = sipDTMF;
            } else {
                this.value_ = ((SipDTMF.Builder) SipDTMF.newBuilder((SipDTMF) this.value_).v(sipDTMF)).o();
            }
            this.valueCase_ = 6;
        }

        private void mergeSpeaker(ActiveSpeakerUpdate activeSpeakerUpdate) {
            activeSpeakerUpdate.getClass();
            if (this.valueCase_ != 3 || this.value_ == ActiveSpeakerUpdate.getDefaultInstance()) {
                this.value_ = activeSpeakerUpdate;
            } else {
                this.value_ = ((ActiveSpeakerUpdate.Builder) ActiveSpeakerUpdate.newBuilder((ActiveSpeakerUpdate) this.value_).v(activeSpeakerUpdate)).o();
            }
            this.valueCase_ = 3;
        }

        private void mergeStreamChunk(DataStream.Chunk chunk) {
            chunk.getClass();
            if (this.valueCase_ != 14 || this.value_ == DataStream.Chunk.getDefaultInstance()) {
                this.value_ = chunk;
            } else {
                this.value_ = ((DataStream.Chunk.Builder) DataStream.Chunk.newBuilder((DataStream.Chunk) this.value_).v(chunk)).o();
            }
            this.valueCase_ = 14;
        }

        private void mergeStreamHeader(DataStream.Header header) {
            header.getClass();
            if (this.valueCase_ != 13 || this.value_ == DataStream.Header.getDefaultInstance()) {
                this.value_ = header;
            } else {
                this.value_ = ((DataStream.Header.Builder) DataStream.Header.newBuilder((DataStream.Header) this.value_).v(header)).o();
            }
            this.valueCase_ = 13;
        }

        private void mergeStreamTrailer(DataStream.Trailer trailer) {
            trailer.getClass();
            if (this.valueCase_ != 15 || this.value_ == DataStream.Trailer.getDefaultInstance()) {
                this.value_ = trailer;
            } else {
                this.value_ = ((DataStream.Trailer.Builder) DataStream.Trailer.newBuilder((DataStream.Trailer) this.value_).v(trailer)).o();
            }
            this.valueCase_ = 15;
        }

        private void mergeTranscription(Transcription transcription) {
            transcription.getClass();
            if (this.valueCase_ != 7 || this.value_ == Transcription.getDefaultInstance()) {
                this.value_ = transcription;
            } else {
                this.value_ = ((Transcription.Builder) Transcription.newBuilder((Transcription) this.value_).v(transcription)).o();
            }
            this.valueCase_ = 7;
        }

        private void mergeUser(UserPacket userPacket) {
            userPacket.getClass();
            if (this.valueCase_ != 2 || this.value_ == UserPacket.getDefaultInstance()) {
                this.value_ = userPacket;
            } else {
                this.value_ = ((UserPacket.Builder) UserPacket.newBuilder((UserPacket) this.value_).v(userPacket)).o();
            }
            this.valueCase_ = 2;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DataPacket parseDelimitedFrom(InputStream inputStream) {
            return (DataPacket) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DataPacket parseFrom(ByteBuffer byteBuffer) {
            return (DataPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DataPacket> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setChatMessage(ChatMessage chatMessage) {
            chatMessage.getClass();
            this.value_ = chatMessage;
            this.valueCase_ = 9;
        }

        private void setDestinationIdentities(int i, String str) {
            str.getClass();
            ensureDestinationIdentitiesIsMutable();
            this.destinationIdentities_.set(i, str);
        }

        private void setEncryptedPacket(EncryptedPacket encryptedPacket) {
            encryptedPacket.getClass();
            this.value_ = encryptedPacket;
            this.valueCase_ = 18;
        }

        private void setKind(Kind kind) {
            this.kind_ = kind.getNumber();
        }

        private void setKindValue(int i) {
            this.kind_ = i;
        }

        private void setMetrics(LivekitMetrics.MetricsBatch metricsBatch) {
            metricsBatch.getClass();
            this.value_ = metricsBatch;
            this.valueCase_ = 8;
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setParticipantSid(String str) {
            str.getClass();
            this.participantSid_ = str;
        }

        private void setParticipantSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantSid_ = byteString.L();
        }

        private void setRpcAck(RpcAck rpcAck) {
            rpcAck.getClass();
            this.value_ = rpcAck;
            this.valueCase_ = 11;
        }

        private void setRpcRequest(RpcRequest rpcRequest) {
            rpcRequest.getClass();
            this.value_ = rpcRequest;
            this.valueCase_ = 10;
        }

        private void setRpcResponse(RpcResponse rpcResponse) {
            rpcResponse.getClass();
            this.value_ = rpcResponse;
            this.valueCase_ = 12;
        }

        private void setSequence(int i) {
            this.sequence_ = i;
        }

        private void setSipDtmf(SipDTMF sipDTMF) {
            sipDTMF.getClass();
            this.value_ = sipDTMF;
            this.valueCase_ = 6;
        }

        private void setSpeaker(ActiveSpeakerUpdate activeSpeakerUpdate) {
            activeSpeakerUpdate.getClass();
            this.value_ = activeSpeakerUpdate;
            this.valueCase_ = 3;
        }

        private void setStreamChunk(DataStream.Chunk chunk) {
            chunk.getClass();
            this.value_ = chunk;
            this.valueCase_ = 14;
        }

        private void setStreamHeader(DataStream.Header header) {
            header.getClass();
            this.value_ = header;
            this.valueCase_ = 13;
        }

        private void setStreamTrailer(DataStream.Trailer trailer) {
            trailer.getClass();
            this.value_ = trailer;
            this.valueCase_ = 15;
        }

        private void setTranscription(Transcription transcription) {
            transcription.getClass();
            this.value_ = transcription;
            this.valueCase_ = 7;
        }

        private void setUser(UserPacket userPacket) {
            userPacket.getClass();
            this.value_ = userPacket;
            this.valueCase_ = 2;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new DataPacket();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0012\u0001\u0000\u0001\u0012\u0012\u0000\u0001\u0000\u0001\f\u0002<\u0000\u0003<\u0000\u0004Ȉ\u0005Ț\u0006<\u0000\u0007<\u0000\b<\u0000\t<\u0000\n<\u0000\u000b<\u0000\f<\u0000\r<\u0000\u000e<\u0000\u000f<\u0000\u0010\u000b\u0011Ȉ\u0012<\u0000", new Object[]{"value_", "valueCase_", "kind_", UserPacket.class, ActiveSpeakerUpdate.class, "participantIdentity_", "destinationIdentities_", SipDTMF.class, Transcription.class, LivekitMetrics.MetricsBatch.class, ChatMessage.class, RpcRequest.class, RpcAck.class, RpcResponse.class, DataStream.Header.class, DataStream.Chunk.class, DataStream.Trailer.class, "sequence_", "participantSid_", EncryptedPacket.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DataPacket> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DataPacket.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public ChatMessage getChatMessage() {
            return this.valueCase_ == 9 ? (ChatMessage) this.value_ : ChatMessage.getDefaultInstance();
        }

        public String getDestinationIdentities(int i) {
            return (String) this.destinationIdentities_.get(i);
        }

        public ByteString getDestinationIdentitiesBytes(int i) {
            return ByteString.n((String) this.destinationIdentities_.get(i));
        }

        public int getDestinationIdentitiesCount() {
            return this.destinationIdentities_.size();
        }

        public List<String> getDestinationIdentitiesList() {
            return this.destinationIdentities_;
        }

        public EncryptedPacket getEncryptedPacket() {
            return this.valueCase_ == 18 ? (EncryptedPacket) this.value_ : EncryptedPacket.getDefaultInstance();
        }

        @Deprecated
        public Kind getKind() {
            Kind kindB = Kind.b(this.kind_);
            return kindB == null ? Kind.d : kindB;
        }

        @Deprecated
        public int getKindValue() {
            return this.kind_;
        }

        public LivekitMetrics.MetricsBatch getMetrics() {
            return this.valueCase_ == 8 ? (LivekitMetrics.MetricsBatch) this.value_ : LivekitMetrics.MetricsBatch.getDefaultInstance();
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getParticipantSid() {
            return this.participantSid_;
        }

        public ByteString getParticipantSidBytes() {
            return ByteString.n(this.participantSid_);
        }

        public RpcAck getRpcAck() {
            return this.valueCase_ == 11 ? (RpcAck) this.value_ : RpcAck.getDefaultInstance();
        }

        public RpcRequest getRpcRequest() {
            return this.valueCase_ == 10 ? (RpcRequest) this.value_ : RpcRequest.getDefaultInstance();
        }

        public RpcResponse getRpcResponse() {
            return this.valueCase_ == 12 ? (RpcResponse) this.value_ : RpcResponse.getDefaultInstance();
        }

        public int getSequence() {
            return this.sequence_;
        }

        public SipDTMF getSipDtmf() {
            return this.valueCase_ == 6 ? (SipDTMF) this.value_ : SipDTMF.getDefaultInstance();
        }

        @Deprecated
        public ActiveSpeakerUpdate getSpeaker() {
            return this.valueCase_ == 3 ? (ActiveSpeakerUpdate) this.value_ : ActiveSpeakerUpdate.getDefaultInstance();
        }

        public DataStream.Chunk getStreamChunk() {
            return this.valueCase_ == 14 ? (DataStream.Chunk) this.value_ : DataStream.Chunk.getDefaultInstance();
        }

        public DataStream.Header getStreamHeader() {
            return this.valueCase_ == 13 ? (DataStream.Header) this.value_ : DataStream.Header.getDefaultInstance();
        }

        public DataStream.Trailer getStreamTrailer() {
            return this.valueCase_ == 15 ? (DataStream.Trailer) this.value_ : DataStream.Trailer.getDefaultInstance();
        }

        public Transcription getTranscription() {
            return this.valueCase_ == 7 ? (Transcription) this.value_ : Transcription.getDefaultInstance();
        }

        public UserPacket getUser() {
            return this.valueCase_ == 2 ? (UserPacket) this.value_ : UserPacket.getDefaultInstance();
        }

        public ValueCase getValueCase() {
            return ValueCase.b(this.valueCase_);
        }

        public boolean hasChatMessage() {
            return this.valueCase_ == 9;
        }

        public boolean hasEncryptedPacket() {
            return this.valueCase_ == 18;
        }

        public boolean hasMetrics() {
            return this.valueCase_ == 8;
        }

        public boolean hasRpcAck() {
            return this.valueCase_ == 11;
        }

        public boolean hasRpcRequest() {
            return this.valueCase_ == 10;
        }

        public boolean hasRpcResponse() {
            return this.valueCase_ == 12;
        }

        public boolean hasSipDtmf() {
            return this.valueCase_ == 6;
        }

        @Deprecated
        public boolean hasSpeaker() {
            return this.valueCase_ == 3;
        }

        public boolean hasStreamChunk() {
            return this.valueCase_ == 14;
        }

        public boolean hasStreamHeader() {
            return this.valueCase_ == 13;
        }

        public boolean hasStreamTrailer() {
            return this.valueCase_ == 15;
        }

        public boolean hasTranscription() {
            return this.valueCase_ == 7;
        }

        public boolean hasUser() {
            return this.valueCase_ == 2;
        }

        public static Builder newBuilder(DataPacket dataPacket) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(dataPacket);
        }

        public static DataPacket parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataPacket) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DataPacket parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DataPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DataPacket parseFrom(ByteString byteString) {
            return (DataPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DataPacket parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DataPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DataPacket parseFrom(byte[] bArr) {
            return (DataPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DataPacket parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DataPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DataPacket parseFrom(InputStream inputStream) {
            return (DataPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DataPacket parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DataPacket parseFrom(CodedInputStream codedInputStream) {
            return (DataPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DataPacket parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DataPacketOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DataStream extends GeneratedMessageLite<DataStream, Builder> implements DataStreamOrBuilder {
        private static final DataStream DEFAULT_INSTANCE;
        private static volatile Parser<DataStream> PARSER;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DataStream, Builder> implements DataStreamOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DataStream.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class ByteHeader extends GeneratedMessageLite<ByteHeader, Builder> implements ByteHeaderOrBuilder {
            private static final ByteHeader DEFAULT_INSTANCE;
            public static final int NAME_FIELD_NUMBER = 1;
            private static volatile Parser<ByteHeader> PARSER;
            private String name_ = ap.a(556690335);

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            public static final class Builder extends GeneratedMessageLite.Builder<ByteHeader, Builder> implements ByteHeaderOrBuilder {
                /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                    this();
                }

                public Builder A(String str) {
                    q();
                    ((ByteHeader) ((GeneratedMessageLite.Builder) this).b).setName(str);
                    return this;
                }

                public String getName() {
                    return ((ByteHeader) ((GeneratedMessageLite.Builder) this).b).getName();
                }

                private Builder() {
                    super(ByteHeader.DEFAULT_INSTANCE);
                }
            }

            static {
                ByteHeader byteHeader = new ByteHeader();
                DEFAULT_INSTANCE = byteHeader;
                GeneratedMessageLite.registerDefaultInstance(ByteHeader.class, byteHeader);
            }

            private ByteHeader() {
            }

            private void clearName() {
                this.name_ = getDefaultInstance().getName();
            }

            public static ByteHeader getDefaultInstance() {
                return DEFAULT_INSTANCE;
            }

            public static Builder newBuilder() {
                return (Builder) DEFAULT_INSTANCE.createBuilder();
            }

            public static ByteHeader parseDelimitedFrom(InputStream inputStream) {
                return (ByteHeader) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
            }

            public static ByteHeader parseFrom(ByteBuffer byteBuffer) {
                return (ByteHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
            }

            public static Parser<ByteHeader> parser() {
                return DEFAULT_INSTANCE.getParserForType();
            }

            private void setName(String str) {
                str.getClass();
                this.name_ = str;
            }

            private void setNameBytes(ByteString byteString) {
                AbstractMessageLite.checkByteStringIsUtf8(byteString);
                this.name_ = byteString.L();
            }

            protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
                GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
                int i = AnonymousClass1.a[methodToInvoke.ordinal()];
                AnonymousClass1 anonymousClass1 = null;
                switch (i) {
                    case 1:
                        return new ByteHeader();
                    case 2:
                        return new Builder(anonymousClass1);
                    case 3:
                        return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"name_"});
                    case 4:
                        return DEFAULT_INSTANCE;
                    case 5:
                        Parser<ByteHeader> parser = PARSER;
                        if (parser != null) {
                            return parser;
                        }
                        synchronized (ByteHeader.class) {
                            try {
                                defaultInstanceBasedParser = PARSER;
                                if (defaultInstanceBasedParser == null) {
                                    defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                    PARSER = defaultInstanceBasedParser;
                                }
                            } catch (Throwable th) {
                                throw th;
                            }
                            break;
                        }
                        return defaultInstanceBasedParser;
                    case 6:
                        return (byte) 1;
                    case 7:
                        return null;
                    default:
                        throw new UnsupportedOperationException();
                }
            }

            public String getName() {
                return this.name_;
            }

            public ByteString getNameBytes() {
                return ByteString.n(this.name_);
            }

            public static Builder newBuilder(ByteHeader byteHeader) {
                return (Builder) DEFAULT_INSTANCE.createBuilder(byteHeader);
            }

            public static ByteHeader parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (ByteHeader) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
            }

            public static ByteHeader parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
                return (ByteHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
            }

            public static ByteHeader parseFrom(ByteString byteString) {
                return (ByteHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
            }

            public static ByteHeader parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
                return (ByteHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
            }

            public static ByteHeader parseFrom(byte[] bArr) {
                return (ByteHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
            }

            public static ByteHeader parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
                return (ByteHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
            }

            public static ByteHeader parseFrom(InputStream inputStream) {
                return (ByteHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
            }

            public static ByteHeader parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (ByteHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
            }

            public static ByteHeader parseFrom(CodedInputStream codedInputStream) {
                return (ByteHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
            }

            public static ByteHeader parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (ByteHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public interface ByteHeaderOrBuilder extends MessageLiteOrBuilder {
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Chunk extends GeneratedMessageLite<Chunk, Builder> implements ChunkOrBuilder {
            public static final int CHUNK_INDEX_FIELD_NUMBER = 2;
            public static final int CONTENT_FIELD_NUMBER = 3;
            private static final Chunk DEFAULT_INSTANCE;
            public static final int IV_FIELD_NUMBER = 5;
            private static volatile Parser<Chunk> PARSER = null;
            public static final int STREAM_ID_FIELD_NUMBER = 1;
            public static final int VERSION_FIELD_NUMBER = 4;
            private int bitField0_;
            private long chunkIndex_;
            private ByteString content_;
            private ByteString iv_;
            private String streamId_ = ap.a(1039437636);
            private int version_;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            public static final class Builder extends GeneratedMessageLite.Builder<Chunk, Builder> implements ChunkOrBuilder {
                /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                    this();
                }

                public Builder A(long j) {
                    q();
                    ((Chunk) ((GeneratedMessageLite.Builder) this).b).setChunkIndex(j);
                    return this;
                }

                public Builder B(ByteString byteString) {
                    q();
                    ((Chunk) ((GeneratedMessageLite.Builder) this).b).setContent(byteString);
                    return this;
                }

                public Builder C(String str) {
                    q();
                    ((Chunk) ((GeneratedMessageLite.Builder) this).b).setStreamId(str);
                    return this;
                }

                private Builder() {
                    super(Chunk.DEFAULT_INSTANCE);
                }
            }

            static {
                Chunk chunk = new Chunk();
                DEFAULT_INSTANCE = chunk;
                GeneratedMessageLite.registerDefaultInstance(Chunk.class, chunk);
            }

            private Chunk() {
                ByteString byteString = ByteString.b;
                this.content_ = byteString;
                this.iv_ = byteString;
            }

            private void clearChunkIndex() {
                this.chunkIndex_ = 0L;
            }

            private void clearContent() {
                this.content_ = getDefaultInstance().getContent();
            }

            private void clearIv() {
                this.bitField0_ &= -2;
                this.iv_ = getDefaultInstance().getIv();
            }

            private void clearStreamId() {
                this.streamId_ = getDefaultInstance().getStreamId();
            }

            private void clearVersion() {
                this.version_ = 0;
            }

            public static Chunk getDefaultInstance() {
                return DEFAULT_INSTANCE;
            }

            public static Builder newBuilder() {
                return (Builder) DEFAULT_INSTANCE.createBuilder();
            }

            public static Chunk parseDelimitedFrom(InputStream inputStream) {
                return (Chunk) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
            }

            public static Chunk parseFrom(ByteBuffer byteBuffer) {
                return (Chunk) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
            }

            public static Parser<Chunk> parser() {
                return DEFAULT_INSTANCE.getParserForType();
            }

            private void setChunkIndex(long j) {
                this.chunkIndex_ = j;
            }

            private void setContent(ByteString byteString) {
                byteString.getClass();
                this.content_ = byteString;
            }

            private void setIv(ByteString byteString) {
                byteString.getClass();
                this.bitField0_ |= 1;
                this.iv_ = byteString;
            }

            private void setStreamId(String str) {
                str.getClass();
                this.streamId_ = str;
            }

            private void setStreamIdBytes(ByteString byteString) {
                AbstractMessageLite.checkByteStringIsUtf8(byteString);
                this.streamId_ = byteString.L();
            }

            private void setVersion(int i) {
                this.version_ = i;
            }

            protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
                GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
                int i = AnonymousClass1.a[methodToInvoke.ordinal()];
                AnonymousClass1 anonymousClass1 = null;
                switch (i) {
                    case 1:
                        return new Chunk();
                    case 2:
                        return new Builder(anonymousClass1);
                    case 3:
                        return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0001\u0001\u0005\u0005\u0000\u0000\u0000\u0001Ȉ\u0002\u0003\u0003\n\u0004\u0004\u0005ည\u0000", new Object[]{"bitField0_", "streamId_", "chunkIndex_", "content_", "version_", "iv_"});
                    case 4:
                        return DEFAULT_INSTANCE;
                    case 5:
                        Parser<Chunk> parser = PARSER;
                        if (parser != null) {
                            return parser;
                        }
                        synchronized (Chunk.class) {
                            try {
                                defaultInstanceBasedParser = PARSER;
                                if (defaultInstanceBasedParser == null) {
                                    defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                    PARSER = defaultInstanceBasedParser;
                                }
                            } catch (Throwable th) {
                                throw th;
                            }
                            break;
                        }
                        return defaultInstanceBasedParser;
                    case 6:
                        return (byte) 1;
                    case 7:
                        return null;
                    default:
                        throw new UnsupportedOperationException();
                }
            }

            public long getChunkIndex() {
                return this.chunkIndex_;
            }

            public ByteString getContent() {
                return this.content_;
            }

            @Deprecated
            public ByteString getIv() {
                return this.iv_;
            }

            public String getStreamId() {
                return this.streamId_;
            }

            public ByteString getStreamIdBytes() {
                return ByteString.n(this.streamId_);
            }

            public int getVersion() {
                return this.version_;
            }

            @Deprecated
            public boolean hasIv() {
                return (this.bitField0_ & 1) != 0;
            }

            public static Builder newBuilder(Chunk chunk) {
                return (Builder) DEFAULT_INSTANCE.createBuilder(chunk);
            }

            public static Chunk parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (Chunk) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
            }

            public static Chunk parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
                return (Chunk) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
            }

            public static Chunk parseFrom(ByteString byteString) {
                return (Chunk) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
            }

            public static Chunk parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
                return (Chunk) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
            }

            public static Chunk parseFrom(byte[] bArr) {
                return (Chunk) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
            }

            public static Chunk parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
                return (Chunk) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
            }

            public static Chunk parseFrom(InputStream inputStream) {
                return (Chunk) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
            }

            public static Chunk parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (Chunk) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
            }

            public static Chunk parseFrom(CodedInputStream codedInputStream) {
                return (Chunk) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
            }

            public static Chunk parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (Chunk) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public interface ChunkOrBuilder extends MessageLiteOrBuilder {
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Header extends GeneratedMessageLite<Header, Builder> implements HeaderOrBuilder {
            public static final int ATTRIBUTES_FIELD_NUMBER = 8;
            public static final int BYTE_HEADER_FIELD_NUMBER = 10;
            private static final Header DEFAULT_INSTANCE;
            public static final int ENCRYPTION_TYPE_FIELD_NUMBER = 7;
            public static final int MIME_TYPE_FIELD_NUMBER = 4;
            private static volatile Parser<Header> PARSER = null;
            public static final int STREAM_ID_FIELD_NUMBER = 1;
            public static final int TEXT_HEADER_FIELD_NUMBER = 9;
            public static final int TIMESTAMP_FIELD_NUMBER = 2;
            public static final int TOPIC_FIELD_NUMBER = 3;
            public static final int TOTAL_LENGTH_FIELD_NUMBER = 5;
            private int bitField0_;
            private Object contentHeader_;
            private int encryptionType_;
            private String mimeType_;
            private String streamId_;
            private long timestamp_;
            private String topic_;
            private long totalLength_;
            private int contentHeaderCase_ = 0;
            private MapFieldLite<String, String> attributes_ = MapFieldLite.f();

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class AttributesDefaultEntryHolder {
                static final MapEntryLite a;

                static {
                    WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                    String strA = ap.a(184500124);
                    a = MapEntryLite.d(fieldType, strA, fieldType, strA);
                }

                private AttributesDefaultEntryHolder() {
                }
            }

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            public static final class Builder extends GeneratedMessageLite.Builder<Header, Builder> implements HeaderOrBuilder {
                /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                    this();
                }

                public Builder A(Map map) {
                    q();
                    ((Header) ((GeneratedMessageLite.Builder) this).b).getMutableAttributesMap().putAll(map);
                    return this;
                }

                public Builder B(ByteHeader byteHeader) {
                    q();
                    ((Header) ((GeneratedMessageLite.Builder) this).b).setByteHeader(byteHeader);
                    return this;
                }

                public Builder C(String str) {
                    q();
                    ((Header) ((GeneratedMessageLite.Builder) this).b).setMimeType(str);
                    return this;
                }

                public Builder D(String str) {
                    q();
                    ((Header) ((GeneratedMessageLite.Builder) this).b).setStreamId(str);
                    return this;
                }

                public Builder E(TextHeader textHeader) {
                    q();
                    ((Header) ((GeneratedMessageLite.Builder) this).b).setTextHeader(textHeader);
                    return this;
                }

                public Builder F(long j) {
                    q();
                    ((Header) ((GeneratedMessageLite.Builder) this).b).setTimestamp(j);
                    return this;
                }

                public Builder G(String str) {
                    q();
                    ((Header) ((GeneratedMessageLite.Builder) this).b).setTopic(str);
                    return this;
                }

                public Builder H(long j) {
                    q();
                    ((Header) ((GeneratedMessageLite.Builder) this).b).setTotalLength(j);
                    return this;
                }

                private Builder() {
                    super(Header.DEFAULT_INSTANCE);
                }
            }

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            public enum ContentHeaderCase {
                b(9),
                c(10),
                d(0);

                private final int a;

                ContentHeaderCase(int i) {
                    this.a = i;
                }

                public static ContentHeaderCase b(int i) {
                    if (i == 0) {
                        return d;
                    }
                    if (i == 9) {
                        return b;
                    }
                    if (i != 10) {
                        return null;
                    }
                    return c;
                }
            }

            static {
                Header header = new Header();
                DEFAULT_INSTANCE = header;
                GeneratedMessageLite.registerDefaultInstance(Header.class, header);
            }

            private Header() {
                String strA = ap.a(843577978);
                this.streamId_ = strA;
                this.topic_ = strA;
                this.mimeType_ = strA;
            }

            private void clearByteHeader() {
                if (this.contentHeaderCase_ == 10) {
                    this.contentHeaderCase_ = 0;
                    this.contentHeader_ = null;
                }
            }

            private void clearContentHeader() {
                this.contentHeaderCase_ = 0;
                this.contentHeader_ = null;
            }

            private void clearEncryptionType() {
                this.encryptionType_ = 0;
            }

            private void clearMimeType() {
                this.mimeType_ = getDefaultInstance().getMimeType();
            }

            private void clearStreamId() {
                this.streamId_ = getDefaultInstance().getStreamId();
            }

            private void clearTextHeader() {
                if (this.contentHeaderCase_ == 9) {
                    this.contentHeaderCase_ = 0;
                    this.contentHeader_ = null;
                }
            }

            private void clearTimestamp() {
                this.timestamp_ = 0L;
            }

            private void clearTopic() {
                this.topic_ = getDefaultInstance().getTopic();
            }

            private void clearTotalLength() {
                this.bitField0_ &= -2;
                this.totalLength_ = 0L;
            }

            public static Header getDefaultInstance() {
                return DEFAULT_INSTANCE;
            }

            private Map<String, String> getMutableAttributesMap() {
                return internalGetMutableAttributes();
            }

            private MapFieldLite<String, String> internalGetAttributes() {
                return this.attributes_;
            }

            private MapFieldLite<String, String> internalGetMutableAttributes() {
                if (!this.attributes_.k()) {
                    this.attributes_ = this.attributes_.n();
                }
                return this.attributes_;
            }

            private void mergeByteHeader(ByteHeader byteHeader) {
                byteHeader.getClass();
                if (this.contentHeaderCase_ != 10 || this.contentHeader_ == ByteHeader.getDefaultInstance()) {
                    this.contentHeader_ = byteHeader;
                } else {
                    this.contentHeader_ = ((ByteHeader.Builder) ByteHeader.newBuilder((ByteHeader) this.contentHeader_).v(byteHeader)).o();
                }
                this.contentHeaderCase_ = 10;
            }

            private void mergeTextHeader(TextHeader textHeader) {
                textHeader.getClass();
                if (this.contentHeaderCase_ != 9 || this.contentHeader_ == TextHeader.getDefaultInstance()) {
                    this.contentHeader_ = textHeader;
                } else {
                    this.contentHeader_ = ((TextHeader.Builder) TextHeader.newBuilder((TextHeader) this.contentHeader_).v(textHeader)).o();
                }
                this.contentHeaderCase_ = 9;
            }

            public static Builder newBuilder() {
                return (Builder) DEFAULT_INSTANCE.createBuilder();
            }

            public static Header parseDelimitedFrom(InputStream inputStream) {
                return (Header) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
            }

            public static Header parseFrom(ByteBuffer byteBuffer) {
                return (Header) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
            }

            public static Parser<Header> parser() {
                return DEFAULT_INSTANCE.getParserForType();
            }

            private void setByteHeader(ByteHeader byteHeader) {
                byteHeader.getClass();
                this.contentHeader_ = byteHeader;
                this.contentHeaderCase_ = 10;
            }

            private void setEncryptionType(Encryption.Type type) {
                this.encryptionType_ = type.getNumber();
            }

            private void setEncryptionTypeValue(int i) {
                this.encryptionType_ = i;
            }

            private void setMimeType(String str) {
                str.getClass();
                this.mimeType_ = str;
            }

            private void setMimeTypeBytes(ByteString byteString) {
                AbstractMessageLite.checkByteStringIsUtf8(byteString);
                this.mimeType_ = byteString.L();
            }

            private void setStreamId(String str) {
                str.getClass();
                this.streamId_ = str;
            }

            private void setStreamIdBytes(ByteString byteString) {
                AbstractMessageLite.checkByteStringIsUtf8(byteString);
                this.streamId_ = byteString.L();
            }

            private void setTextHeader(TextHeader textHeader) {
                textHeader.getClass();
                this.contentHeader_ = textHeader;
                this.contentHeaderCase_ = 9;
            }

            private void setTimestamp(long j) {
                this.timestamp_ = j;
            }

            private void setTopic(String str) {
                str.getClass();
                this.topic_ = str;
            }

            private void setTopicBytes(ByteString byteString) {
                AbstractMessageLite.checkByteStringIsUtf8(byteString);
                this.topic_ = byteString.L();
            }

            private void setTotalLength(long j) {
                this.bitField0_ |= 1;
                this.totalLength_ = j;
            }

            public boolean containsAttributes(String str) {
                str.getClass();
                return internalGetAttributes().containsKey(str);
            }

            protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
                GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
                int i = AnonymousClass1.a[methodToInvoke.ordinal()];
                AnonymousClass1 anonymousClass1 = null;
                switch (i) {
                    case 1:
                        return new Header();
                    case 2:
                        return new Builder(anonymousClass1);
                    case 3:
                        return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\t\u0001\u0001\u0001\n\t\u0001\u0000\u0000\u0001Ȉ\u0002\u0002\u0003Ȉ\u0004Ȉ\u0005ဃ\u0000\u0007\f\b2\t<\u0000\n<\u0000", new Object[]{"contentHeader_", "contentHeaderCase_", "bitField0_", "streamId_", "timestamp_", "topic_", "mimeType_", "totalLength_", "encryptionType_", "attributes_", AttributesDefaultEntryHolder.a, TextHeader.class, ByteHeader.class});
                    case 4:
                        return DEFAULT_INSTANCE;
                    case 5:
                        Parser<Header> parser = PARSER;
                        if (parser != null) {
                            return parser;
                        }
                        synchronized (Header.class) {
                            try {
                                defaultInstanceBasedParser = PARSER;
                                if (defaultInstanceBasedParser == null) {
                                    defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                    PARSER = defaultInstanceBasedParser;
                                }
                            } catch (Throwable th) {
                                throw th;
                            }
                            break;
                        }
                        return defaultInstanceBasedParser;
                    case 6:
                        return (byte) 1;
                    case 7:
                        return null;
                    default:
                        throw new UnsupportedOperationException();
                }
            }

            @Deprecated
            public Map<String, String> getAttributes() {
                return getAttributesMap();
            }

            public int getAttributesCount() {
                return internalGetAttributes().size();
            }

            public Map<String, String> getAttributesMap() {
                return Collections.unmodifiableMap(internalGetAttributes());
            }

            public String getAttributesOrDefault(String str, String str2) {
                str.getClass();
                MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
                return mapFieldLiteInternalGetAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetAttributes.get(str) : str2;
            }

            public String getAttributesOrThrow(String str) {
                str.getClass();
                MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
                if (mapFieldLiteInternalGetAttributes.containsKey(str)) {
                    return (String) mapFieldLiteInternalGetAttributes.get(str);
                }
                throw new IllegalArgumentException();
            }

            public ByteHeader getByteHeader() {
                return this.contentHeaderCase_ == 10 ? (ByteHeader) this.contentHeader_ : ByteHeader.getDefaultInstance();
            }

            public ContentHeaderCase getContentHeaderCase() {
                return ContentHeaderCase.b(this.contentHeaderCase_);
            }

            @Deprecated
            public Encryption.Type getEncryptionType() {
                Encryption.Type typeB = Encryption.Type.b(this.encryptionType_);
                return typeB == null ? Encryption.Type.e : typeB;
            }

            @Deprecated
            public int getEncryptionTypeValue() {
                return this.encryptionType_;
            }

            public String getMimeType() {
                return this.mimeType_;
            }

            public ByteString getMimeTypeBytes() {
                return ByteString.n(this.mimeType_);
            }

            public String getStreamId() {
                return this.streamId_;
            }

            public ByteString getStreamIdBytes() {
                return ByteString.n(this.streamId_);
            }

            public TextHeader getTextHeader() {
                return this.contentHeaderCase_ == 9 ? (TextHeader) this.contentHeader_ : TextHeader.getDefaultInstance();
            }

            public long getTimestamp() {
                return this.timestamp_;
            }

            public String getTopic() {
                return this.topic_;
            }

            public ByteString getTopicBytes() {
                return ByteString.n(this.topic_);
            }

            public long getTotalLength() {
                return this.totalLength_;
            }

            public boolean hasByteHeader() {
                return this.contentHeaderCase_ == 10;
            }

            public boolean hasTextHeader() {
                return this.contentHeaderCase_ == 9;
            }

            public boolean hasTotalLength() {
                return (this.bitField0_ & 1) != 0;
            }

            public static Builder newBuilder(Header header) {
                return (Builder) DEFAULT_INSTANCE.createBuilder(header);
            }

            public static Header parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (Header) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
            }

            public static Header parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
                return (Header) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
            }

            public static Header parseFrom(ByteString byteString) {
                return (Header) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
            }

            public static Header parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
                return (Header) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
            }

            public static Header parseFrom(byte[] bArr) {
                return (Header) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
            }

            public static Header parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
                return (Header) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
            }

            public static Header parseFrom(InputStream inputStream) {
                return (Header) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
            }

            public static Header parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (Header) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
            }

            public static Header parseFrom(CodedInputStream codedInputStream) {
                return (Header) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
            }

            public static Header parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (Header) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public interface HeaderOrBuilder extends MessageLiteOrBuilder {
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OperationType implements Internal.EnumLite {
            b(0),
            c(1),
            d(2),
            e(3),
            f(-1);

            private static final Internal.EnumLiteMap g = new Internal.EnumLiteMap<OperationType>() { // from class: livekit.LivekitModels.DataStream.OperationType.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public OperationType findValueByNumber(int i) {
                    return OperationType.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class OperationTypeVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new OperationTypeVerifier();

                private OperationTypeVerifier() {
                }

                public boolean isInRange(int i) {
                    return OperationType.b(i) != null;
                }
            }

            OperationType(int i) {
                this.a = i;
            }

            public static OperationType b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i == 1) {
                    return c;
                }
                if (i == 2) {
                    return d;
                }
                if (i != 3) {
                    return null;
                }
                return e;
            }

            public final int getNumber() {
                if (this != f) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class TextHeader extends GeneratedMessageLite<TextHeader, Builder> implements TextHeaderOrBuilder {
            public static final int ATTACHED_STREAM_IDS_FIELD_NUMBER = 4;
            private static final TextHeader DEFAULT_INSTANCE;
            public static final int GENERATED_FIELD_NUMBER = 5;
            public static final int OPERATION_TYPE_FIELD_NUMBER = 1;
            private static volatile Parser<TextHeader> PARSER = null;
            public static final int REPLY_TO_STREAM_ID_FIELD_NUMBER = 3;
            public static final int VERSION_FIELD_NUMBER = 2;
            private boolean generated_;
            private int operationType_;
            private int version_;
            private String replyToStreamId_ = ap.a(2042874034);
            private Internal.ProtobufList<String> attachedStreamIds_ = GeneratedMessageLite.emptyProtobufList();

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            public static final class Builder extends GeneratedMessageLite.Builder<TextHeader, Builder> implements TextHeaderOrBuilder {
                /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                    this();
                }

                public Builder A(Iterable iterable) {
                    q();
                    ((TextHeader) ((GeneratedMessageLite.Builder) this).b).addAllAttachedStreamIds(iterable);
                    return this;
                }

                public Builder B(boolean z) {
                    q();
                    ((TextHeader) ((GeneratedMessageLite.Builder) this).b).setGenerated(z);
                    return this;
                }

                public Builder C(OperationType operationType) {
                    q();
                    ((TextHeader) ((GeneratedMessageLite.Builder) this).b).setOperationType(operationType);
                    return this;
                }

                public Builder D(String str) {
                    q();
                    ((TextHeader) ((GeneratedMessageLite.Builder) this).b).setReplyToStreamId(str);
                    return this;
                }

                public Builder E(int i) {
                    q();
                    ((TextHeader) ((GeneratedMessageLite.Builder) this).b).setVersion(i);
                    return this;
                }

                private Builder() {
                    super(TextHeader.DEFAULT_INSTANCE);
                }
            }

            static {
                TextHeader textHeader = new TextHeader();
                DEFAULT_INSTANCE = textHeader;
                GeneratedMessageLite.registerDefaultInstance(TextHeader.class, textHeader);
            }

            private TextHeader() {
            }

            private void addAllAttachedStreamIds(Iterable<String> iterable) {
                ensureAttachedStreamIdsIsMutable();
                AbstractMessageLite.addAll(iterable, this.attachedStreamIds_);
            }

            private void addAttachedStreamIds(String str) {
                str.getClass();
                ensureAttachedStreamIdsIsMutable();
                this.attachedStreamIds_.add(str);
            }

            private void addAttachedStreamIdsBytes(ByteString byteString) {
                AbstractMessageLite.checkByteStringIsUtf8(byteString);
                ensureAttachedStreamIdsIsMutable();
                this.attachedStreamIds_.add(byteString.L());
            }

            private void clearAttachedStreamIds() {
                this.attachedStreamIds_ = GeneratedMessageLite.emptyProtobufList();
            }

            private void clearGenerated() {
                this.generated_ = false;
            }

            private void clearOperationType() {
                this.operationType_ = 0;
            }

            private void clearReplyToStreamId() {
                this.replyToStreamId_ = getDefaultInstance().getReplyToStreamId();
            }

            private void clearVersion() {
                this.version_ = 0;
            }

            private void ensureAttachedStreamIdsIsMutable() {
                Internal.ProtobufList<String> protobufList = this.attachedStreamIds_;
                if (protobufList.isModifiable()) {
                    return;
                }
                this.attachedStreamIds_ = GeneratedMessageLite.mutableCopy(protobufList);
            }

            public static TextHeader getDefaultInstance() {
                return DEFAULT_INSTANCE;
            }

            public static Builder newBuilder() {
                return (Builder) DEFAULT_INSTANCE.createBuilder();
            }

            public static TextHeader parseDelimitedFrom(InputStream inputStream) {
                return (TextHeader) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
            }

            public static TextHeader parseFrom(ByteBuffer byteBuffer) {
                return (TextHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
            }

            public static Parser<TextHeader> parser() {
                return DEFAULT_INSTANCE.getParserForType();
            }

            private void setAttachedStreamIds(int i, String str) {
                str.getClass();
                ensureAttachedStreamIdsIsMutable();
                this.attachedStreamIds_.set(i, str);
            }

            private void setGenerated(boolean z) {
                this.generated_ = z;
            }

            private void setOperationType(OperationType operationType) {
                this.operationType_ = operationType.getNumber();
            }

            private void setOperationTypeValue(int i) {
                this.operationType_ = i;
            }

            private void setReplyToStreamId(String str) {
                str.getClass();
                this.replyToStreamId_ = str;
            }

            private void setReplyToStreamIdBytes(ByteString byteString) {
                AbstractMessageLite.checkByteStringIsUtf8(byteString);
                this.replyToStreamId_ = byteString.L();
            }

            private void setVersion(int i) {
                this.version_ = i;
            }

            protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
                GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
                int i = AnonymousClass1.a[methodToInvoke.ordinal()];
                AnonymousClass1 anonymousClass1 = null;
                switch (i) {
                    case 1:
                        return new TextHeader();
                    case 2:
                        return new Builder(anonymousClass1);
                    case 3:
                        return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0001\u0000\u0001\f\u0002\u0004\u0003Ȉ\u0004Ț\u0005\u0007", new Object[]{"operationType_", "version_", "replyToStreamId_", "attachedStreamIds_", "generated_"});
                    case 4:
                        return DEFAULT_INSTANCE;
                    case 5:
                        Parser<TextHeader> parser = PARSER;
                        if (parser != null) {
                            return parser;
                        }
                        synchronized (TextHeader.class) {
                            try {
                                defaultInstanceBasedParser = PARSER;
                                if (defaultInstanceBasedParser == null) {
                                    defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                    PARSER = defaultInstanceBasedParser;
                                }
                            } catch (Throwable th) {
                                throw th;
                            }
                            break;
                        }
                        return defaultInstanceBasedParser;
                    case 6:
                        return (byte) 1;
                    case 7:
                        return null;
                    default:
                        throw new UnsupportedOperationException();
                }
            }

            public String getAttachedStreamIds(int i) {
                return (String) this.attachedStreamIds_.get(i);
            }

            public ByteString getAttachedStreamIdsBytes(int i) {
                return ByteString.n((String) this.attachedStreamIds_.get(i));
            }

            public int getAttachedStreamIdsCount() {
                return this.attachedStreamIds_.size();
            }

            public List<String> getAttachedStreamIdsList() {
                return this.attachedStreamIds_;
            }

            public boolean getGenerated() {
                return this.generated_;
            }

            public OperationType getOperationType() {
                OperationType operationTypeB = OperationType.b(this.operationType_);
                return operationTypeB == null ? OperationType.f : operationTypeB;
            }

            public int getOperationTypeValue() {
                return this.operationType_;
            }

            public String getReplyToStreamId() {
                return this.replyToStreamId_;
            }

            public ByteString getReplyToStreamIdBytes() {
                return ByteString.n(this.replyToStreamId_);
            }

            public int getVersion() {
                return this.version_;
            }

            public static Builder newBuilder(TextHeader textHeader) {
                return (Builder) DEFAULT_INSTANCE.createBuilder(textHeader);
            }

            public static TextHeader parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (TextHeader) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
            }

            public static TextHeader parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
                return (TextHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
            }

            public static TextHeader parseFrom(ByteString byteString) {
                return (TextHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
            }

            public static TextHeader parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
                return (TextHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
            }

            public static TextHeader parseFrom(byte[] bArr) {
                return (TextHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
            }

            public static TextHeader parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
                return (TextHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
            }

            public static TextHeader parseFrom(InputStream inputStream) {
                return (TextHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
            }

            public static TextHeader parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (TextHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
            }

            public static TextHeader parseFrom(CodedInputStream codedInputStream) {
                return (TextHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
            }

            public static TextHeader parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (TextHeader) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public interface TextHeaderOrBuilder extends MessageLiteOrBuilder {
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Trailer extends GeneratedMessageLite<Trailer, Builder> implements TrailerOrBuilder {
            public static final int ATTRIBUTES_FIELD_NUMBER = 3;
            private static final Trailer DEFAULT_INSTANCE;
            private static volatile Parser<Trailer> PARSER = null;
            public static final int REASON_FIELD_NUMBER = 2;
            public static final int STREAM_ID_FIELD_NUMBER = 1;
            private MapFieldLite<String, String> attributes_ = MapFieldLite.f();
            private String reason_;
            private String streamId_;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class AttributesDefaultEntryHolder {
                static final MapEntryLite a;

                static {
                    WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                    String strA = ap.a(1590771079);
                    a = MapEntryLite.d(fieldType, strA, fieldType, strA);
                }

                private AttributesDefaultEntryHolder() {
                }
            }

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            public static final class Builder extends GeneratedMessageLite.Builder<Trailer, Builder> implements TrailerOrBuilder {
                /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                    this();
                }

                public Builder A(String str) {
                    q();
                    ((Trailer) ((GeneratedMessageLite.Builder) this).b).setReason(str);
                    return this;
                }

                public Builder B(String str) {
                    q();
                    ((Trailer) ((GeneratedMessageLite.Builder) this).b).setStreamId(str);
                    return this;
                }

                private Builder() {
                    super(Trailer.DEFAULT_INSTANCE);
                }
            }

            static {
                Trailer trailer = new Trailer();
                DEFAULT_INSTANCE = trailer;
                GeneratedMessageLite.registerDefaultInstance(Trailer.class, trailer);
            }

            private Trailer() {
                String strA = ap.a(1834055899);
                this.streamId_ = strA;
                this.reason_ = strA;
            }

            private void clearReason() {
                this.reason_ = getDefaultInstance().getReason();
            }

            private void clearStreamId() {
                this.streamId_ = getDefaultInstance().getStreamId();
            }

            public static Trailer getDefaultInstance() {
                return DEFAULT_INSTANCE;
            }

            private Map<String, String> getMutableAttributesMap() {
                return internalGetMutableAttributes();
            }

            private MapFieldLite<String, String> internalGetAttributes() {
                return this.attributes_;
            }

            private MapFieldLite<String, String> internalGetMutableAttributes() {
                if (!this.attributes_.k()) {
                    this.attributes_ = this.attributes_.n();
                }
                return this.attributes_;
            }

            public static Builder newBuilder() {
                return (Builder) DEFAULT_INSTANCE.createBuilder();
            }

            public static Trailer parseDelimitedFrom(InputStream inputStream) {
                return (Trailer) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
            }

            public static Trailer parseFrom(ByteBuffer byteBuffer) {
                return (Trailer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
            }

            public static Parser<Trailer> parser() {
                return DEFAULT_INSTANCE.getParserForType();
            }

            private void setReason(String str) {
                str.getClass();
                this.reason_ = str;
            }

            private void setReasonBytes(ByteString byteString) {
                AbstractMessageLite.checkByteStringIsUtf8(byteString);
                this.reason_ = byteString.L();
            }

            private void setStreamId(String str) {
                str.getClass();
                this.streamId_ = str;
            }

            private void setStreamIdBytes(ByteString byteString) {
                AbstractMessageLite.checkByteStringIsUtf8(byteString);
                this.streamId_ = byteString.L();
            }

            public boolean containsAttributes(String str) {
                str.getClass();
                return internalGetAttributes().containsKey(str);
            }

            protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
                GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
                int i = AnonymousClass1.a[methodToInvoke.ordinal()];
                AnonymousClass1 anonymousClass1 = null;
                switch (i) {
                    case 1:
                        return new Trailer();
                    case 2:
                        return new Builder(anonymousClass1);
                    case 3:
                        return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0001\u0000\u0000\u0001Ȉ\u0002Ȉ\u00032", new Object[]{"streamId_", "reason_", "attributes_", AttributesDefaultEntryHolder.a});
                    case 4:
                        return DEFAULT_INSTANCE;
                    case 5:
                        Parser<Trailer> parser = PARSER;
                        if (parser != null) {
                            return parser;
                        }
                        synchronized (Trailer.class) {
                            try {
                                defaultInstanceBasedParser = PARSER;
                                if (defaultInstanceBasedParser == null) {
                                    defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                    PARSER = defaultInstanceBasedParser;
                                }
                            } catch (Throwable th) {
                                throw th;
                            }
                            break;
                        }
                        return defaultInstanceBasedParser;
                    case 6:
                        return (byte) 1;
                    case 7:
                        return null;
                    default:
                        throw new UnsupportedOperationException();
                }
            }

            @Deprecated
            public Map<String, String> getAttributes() {
                return getAttributesMap();
            }

            public int getAttributesCount() {
                return internalGetAttributes().size();
            }

            public Map<String, String> getAttributesMap() {
                return Collections.unmodifiableMap(internalGetAttributes());
            }

            public String getAttributesOrDefault(String str, String str2) {
                str.getClass();
                MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
                return mapFieldLiteInternalGetAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetAttributes.get(str) : str2;
            }

            public String getAttributesOrThrow(String str) {
                str.getClass();
                MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
                if (mapFieldLiteInternalGetAttributes.containsKey(str)) {
                    return (String) mapFieldLiteInternalGetAttributes.get(str);
                }
                throw new IllegalArgumentException();
            }

            public String getReason() {
                return this.reason_;
            }

            public ByteString getReasonBytes() {
                return ByteString.n(this.reason_);
            }

            public String getStreamId() {
                return this.streamId_;
            }

            public ByteString getStreamIdBytes() {
                return ByteString.n(this.streamId_);
            }

            public static Builder newBuilder(Trailer trailer) {
                return (Builder) DEFAULT_INSTANCE.createBuilder(trailer);
            }

            public static Trailer parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (Trailer) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
            }

            public static Trailer parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
                return (Trailer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
            }

            public static Trailer parseFrom(ByteString byteString) {
                return (Trailer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
            }

            public static Trailer parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
                return (Trailer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
            }

            public static Trailer parseFrom(byte[] bArr) {
                return (Trailer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
            }

            public static Trailer parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
                return (Trailer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
            }

            public static Trailer parseFrom(InputStream inputStream) {
                return (Trailer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
            }

            public static Trailer parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (Trailer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
            }

            public static Trailer parseFrom(CodedInputStream codedInputStream) {
                return (Trailer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
            }

            public static Trailer parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
                return (Trailer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public interface TrailerOrBuilder extends MessageLiteOrBuilder {
        }

        static {
            DataStream dataStream = new DataStream();
            DEFAULT_INSTANCE = dataStream;
            GeneratedMessageLite.registerDefaultInstance(DataStream.class, dataStream);
        }

        private DataStream() {
        }

        public static DataStream getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DataStream parseDelimitedFrom(InputStream inputStream) {
            return (DataStream) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DataStream parseFrom(ByteBuffer byteBuffer) {
            return (DataStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DataStream> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DataStream();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0000", (Object[]) null);
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DataStream> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DataStream.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public static Builder newBuilder(DataStream dataStream) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(dataStream);
        }

        public static DataStream parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataStream) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DataStream parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DataStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DataStream parseFrom(ByteString byteString) {
            return (DataStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DataStream parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DataStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DataStream parseFrom(byte[] bArr) {
            return (DataStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DataStream parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DataStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DataStream parseFrom(InputStream inputStream) {
            return (DataStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DataStream parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DataStream parseFrom(CodedInputStream codedInputStream) {
            return (DataStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DataStream parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DataStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DataStreamOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DisabledCodecs extends GeneratedMessageLite<DisabledCodecs, Builder> implements DisabledCodecsOrBuilder {
        public static final int CODECS_FIELD_NUMBER = 1;
        private static final DisabledCodecs DEFAULT_INSTANCE;
        private static volatile Parser<DisabledCodecs> PARSER = null;
        public static final int PUBLISH_FIELD_NUMBER = 2;
        private Internal.ProtobufList<Codec> codecs_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<Codec> publish_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DisabledCodecs, Builder> implements DisabledCodecsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DisabledCodecs.DEFAULT_INSTANCE);
            }
        }

        static {
            DisabledCodecs disabledCodecs = new DisabledCodecs();
            DEFAULT_INSTANCE = disabledCodecs;
            GeneratedMessageLite.registerDefaultInstance(DisabledCodecs.class, disabledCodecs);
        }

        private DisabledCodecs() {
        }

        private void addAllCodecs(Iterable<? extends Codec> iterable) {
            ensureCodecsIsMutable();
            AbstractMessageLite.addAll(iterable, this.codecs_);
        }

        private void addAllPublish(Iterable<? extends Codec> iterable) {
            ensurePublishIsMutable();
            AbstractMessageLite.addAll(iterable, this.publish_);
        }

        private void addCodecs(Codec codec) {
            codec.getClass();
            ensureCodecsIsMutable();
            this.codecs_.add(codec);
        }

        private void addPublish(Codec codec) {
            codec.getClass();
            ensurePublishIsMutable();
            this.publish_.add(codec);
        }

        private void clearCodecs() {
            this.codecs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearPublish() {
            this.publish_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureCodecsIsMutable() {
            Internal.ProtobufList<Codec> protobufList = this.codecs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.codecs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensurePublishIsMutable() {
            Internal.ProtobufList<Codec> protobufList = this.publish_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.publish_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static DisabledCodecs getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DisabledCodecs parseDelimitedFrom(InputStream inputStream) {
            return (DisabledCodecs) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DisabledCodecs parseFrom(ByteBuffer byteBuffer) {
            return (DisabledCodecs) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DisabledCodecs> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeCodecs(int i) {
            ensureCodecsIsMutable();
            this.codecs_.remove(i);
        }

        private void removePublish(int i) {
            ensurePublishIsMutable();
            this.publish_.remove(i);
        }

        private void setCodecs(int i, Codec codec) {
            codec.getClass();
            ensureCodecsIsMutable();
            this.codecs_.set(i, codec);
        }

        private void setPublish(int i, Codec codec) {
            codec.getClass();
            ensurePublishIsMutable();
            this.publish_.set(i, codec);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DisabledCodecs();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0002\u0000\u0001\u001b\u0002\u001b", new Object[]{ap.a(357572060), Codec.class, ap.a(1005550258), Codec.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DisabledCodecs> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DisabledCodecs.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Codec getCodecs(int i) {
            return (Codec) this.codecs_.get(i);
        }

        public int getCodecsCount() {
            return this.codecs_.size();
        }

        public List<Codec> getCodecsList() {
            return this.codecs_;
        }

        public CodecOrBuilder getCodecsOrBuilder(int i) {
            return (CodecOrBuilder) this.codecs_.get(i);
        }

        public List<? extends CodecOrBuilder> getCodecsOrBuilderList() {
            return this.codecs_;
        }

        public Codec getPublish(int i) {
            return (Codec) this.publish_.get(i);
        }

        public int getPublishCount() {
            return this.publish_.size();
        }

        public List<Codec> getPublishList() {
            return this.publish_;
        }

        public CodecOrBuilder getPublishOrBuilder(int i) {
            return (CodecOrBuilder) this.publish_.get(i);
        }

        public List<? extends CodecOrBuilder> getPublishOrBuilderList() {
            return this.publish_;
        }

        public static Builder newBuilder(DisabledCodecs disabledCodecs) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(disabledCodecs);
        }

        public static DisabledCodecs parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DisabledCodecs) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DisabledCodecs parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DisabledCodecs) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DisabledCodecs parseFrom(ByteString byteString) {
            return (DisabledCodecs) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addCodecs(int i, Codec codec) {
            codec.getClass();
            ensureCodecsIsMutable();
            this.codecs_.add(i, codec);
        }

        private void addPublish(int i, Codec codec) {
            codec.getClass();
            ensurePublishIsMutable();
            this.publish_.add(i, codec);
        }

        public static DisabledCodecs parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DisabledCodecs) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DisabledCodecs parseFrom(byte[] bArr) {
            return (DisabledCodecs) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DisabledCodecs parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DisabledCodecs) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DisabledCodecs parseFrom(InputStream inputStream) {
            return (DisabledCodecs) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DisabledCodecs parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DisabledCodecs) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DisabledCodecs parseFrom(CodedInputStream codedInputStream) {
            return (DisabledCodecs) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DisabledCodecs parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DisabledCodecs) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DisabledCodecsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum DisconnectReason implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(4),
        g(5),
        h(6),
        i(7),
        j(8),
        k(9),
        l(10),
        m(11),
        n(12),
        o(13),
        p(14),
        q(15),
        r(-1);

        private static final Internal.EnumLiteMap s = new Internal.EnumLiteMap<DisconnectReason>() { // from class: livekit.LivekitModels.DisconnectReason.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public DisconnectReason findValueByNumber(int i2) {
                return DisconnectReason.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class DisconnectReasonVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new DisconnectReasonVerifier();

            private DisconnectReasonVerifier() {
            }

            public boolean isInRange(int i) {
                return DisconnectReason.b(i) != null;
            }
        }

        DisconnectReason(int i2) {
            this.a = i2;
        }

        public static DisconnectReason b(int i2) {
            switch (i2) {
                case 0:
                    return b;
                case 1:
                    return c;
                case 2:
                    return d;
                case 3:
                    return e;
                case 4:
                    return f;
                case 5:
                    return g;
                case 6:
                    return h;
                case 7:
                    return i;
                case 8:
                    return j;
                case 9:
                    return k;
                case 10:
                    return l;
                case 11:
                    return m;
                case 12:
                    return n;
                case 13:
                    return o;
                case 14:
                    return p;
                case 15:
                    return q;
                default:
                    return null;
            }
        }

        public final int getNumber() {
            if (this != r) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class EncryptedPacket extends GeneratedMessageLite<EncryptedPacket, Builder> implements EncryptedPacketOrBuilder {
        private static final EncryptedPacket DEFAULT_INSTANCE;
        public static final int ENCRYPTED_VALUE_FIELD_NUMBER = 4;
        public static final int ENCRYPTION_TYPE_FIELD_NUMBER = 1;
        public static final int IV_FIELD_NUMBER = 2;
        public static final int KEY_INDEX_FIELD_NUMBER = 3;
        private static volatile Parser<EncryptedPacket> PARSER;
        private ByteString encryptedValue_;
        private int encryptionType_;
        private ByteString iv_;
        private int keyIndex_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<EncryptedPacket, Builder> implements EncryptedPacketOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(ByteString byteString) {
                q();
                ((EncryptedPacket) ((GeneratedMessageLite.Builder) this).b).setEncryptedValue(byteString);
                return this;
            }

            public Builder B(Encryption.Type type) {
                q();
                ((EncryptedPacket) ((GeneratedMessageLite.Builder) this).b).setEncryptionType(type);
                return this;
            }

            public Builder C(ByteString byteString) {
                q();
                ((EncryptedPacket) ((GeneratedMessageLite.Builder) this).b).setIv(byteString);
                return this;
            }

            public Builder D(int i) {
                q();
                ((EncryptedPacket) ((GeneratedMessageLite.Builder) this).b).setKeyIndex(i);
                return this;
            }

            private Builder() {
                super(EncryptedPacket.DEFAULT_INSTANCE);
            }
        }

        static {
            EncryptedPacket encryptedPacket = new EncryptedPacket();
            DEFAULT_INSTANCE = encryptedPacket;
            GeneratedMessageLite.registerDefaultInstance(EncryptedPacket.class, encryptedPacket);
        }

        private EncryptedPacket() {
            ByteString byteString = ByteString.b;
            this.iv_ = byteString;
            this.encryptedValue_ = byteString;
        }

        private void clearEncryptedValue() {
            this.encryptedValue_ = getDefaultInstance().getEncryptedValue();
        }

        private void clearEncryptionType() {
            this.encryptionType_ = 0;
        }

        private void clearIv() {
            this.iv_ = getDefaultInstance().getIv();
        }

        private void clearKeyIndex() {
            this.keyIndex_ = 0;
        }

        public static EncryptedPacket getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static EncryptedPacket parseDelimitedFrom(InputStream inputStream) {
            return (EncryptedPacket) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EncryptedPacket parseFrom(ByteBuffer byteBuffer) {
            return (EncryptedPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<EncryptedPacket> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setEncryptedValue(ByteString byteString) {
            byteString.getClass();
            this.encryptedValue_ = byteString;
        }

        private void setEncryptionType(Encryption.Type type) {
            this.encryptionType_ = type.getNumber();
        }

        private void setEncryptionTypeValue(int i) {
            this.encryptionType_ = i;
        }

        private void setIv(ByteString byteString) {
            byteString.getClass();
            this.iv_ = byteString;
        }

        private void setKeyIndex(int i) {
            this.keyIndex_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new EncryptedPacket();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\f\u0002\n\u0003\u000b\u0004\n", new Object[]{ap.a(1453119105), ap.a(1070267620), ap.a(1438828453), ap.a(162440098)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<EncryptedPacket> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (EncryptedPacket.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public ByteString getEncryptedValue() {
            return this.encryptedValue_;
        }

        public Encryption.Type getEncryptionType() {
            Encryption.Type typeB = Encryption.Type.b(this.encryptionType_);
            return typeB == null ? Encryption.Type.e : typeB;
        }

        public int getEncryptionTypeValue() {
            return this.encryptionType_;
        }

        public ByteString getIv() {
            return this.iv_;
        }

        public int getKeyIndex() {
            return this.keyIndex_;
        }

        public static Builder newBuilder(EncryptedPacket encryptedPacket) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(encryptedPacket);
        }

        public static EncryptedPacket parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacket) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EncryptedPacket parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static EncryptedPacket parseFrom(ByteString byteString) {
            return (EncryptedPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static EncryptedPacket parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static EncryptedPacket parseFrom(byte[] bArr) {
            return (EncryptedPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static EncryptedPacket parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static EncryptedPacket parseFrom(InputStream inputStream) {
            return (EncryptedPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EncryptedPacket parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EncryptedPacket parseFrom(CodedInputStream codedInputStream) {
            return (EncryptedPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static EncryptedPacket parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface EncryptedPacketOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class EncryptedPacketPayload extends GeneratedMessageLite<EncryptedPacketPayload, Builder> implements EncryptedPacketPayloadOrBuilder {
        public static final int CHAT_MESSAGE_FIELD_NUMBER = 3;
        private static final EncryptedPacketPayload DEFAULT_INSTANCE;
        private static volatile Parser<EncryptedPacketPayload> PARSER = null;
        public static final int RPC_ACK_FIELD_NUMBER = 5;
        public static final int RPC_REQUEST_FIELD_NUMBER = 4;
        public static final int RPC_RESPONSE_FIELD_NUMBER = 6;
        public static final int STREAM_CHUNK_FIELD_NUMBER = 8;
        public static final int STREAM_HEADER_FIELD_NUMBER = 7;
        public static final int STREAM_TRAILER_FIELD_NUMBER = 9;
        public static final int USER_FIELD_NUMBER = 1;
        private int valueCase_ = 0;
        private Object value_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<EncryptedPacketPayload, Builder> implements EncryptedPacketPayloadOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(ChatMessage chatMessage) {
                q();
                ((EncryptedPacketPayload) ((GeneratedMessageLite.Builder) this).b).setChatMessage(chatMessage);
                return this;
            }

            public Builder B(RpcAck rpcAck) {
                q();
                ((EncryptedPacketPayload) ((GeneratedMessageLite.Builder) this).b).setRpcAck(rpcAck);
                return this;
            }

            public Builder C(RpcRequest rpcRequest) {
                q();
                ((EncryptedPacketPayload) ((GeneratedMessageLite.Builder) this).b).setRpcRequest(rpcRequest);
                return this;
            }

            public Builder D(RpcResponse rpcResponse) {
                q();
                ((EncryptedPacketPayload) ((GeneratedMessageLite.Builder) this).b).setRpcResponse(rpcResponse);
                return this;
            }

            public Builder E(DataStream.Chunk chunk) {
                q();
                ((EncryptedPacketPayload) ((GeneratedMessageLite.Builder) this).b).setStreamChunk(chunk);
                return this;
            }

            public Builder F(DataStream.Header header) {
                q();
                ((EncryptedPacketPayload) ((GeneratedMessageLite.Builder) this).b).setStreamHeader(header);
                return this;
            }

            public Builder G(DataStream.Trailer trailer) {
                q();
                ((EncryptedPacketPayload) ((GeneratedMessageLite.Builder) this).b).setStreamTrailer(trailer);
                return this;
            }

            public Builder H(UserPacket userPacket) {
                q();
                ((EncryptedPacketPayload) ((GeneratedMessageLite.Builder) this).b).setUser(userPacket);
                return this;
            }

            private Builder() {
                super(EncryptedPacketPayload.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum ValueCase {
            b(1),
            c(3),
            d(4),
            e(5),
            f(6),
            g(7),
            h(8),
            i(9),
            j(0);

            private final int a;

            ValueCase(int i2) {
                this.a = i2;
            }

            public static ValueCase b(int i2) {
                switch (i2) {
                    case 0:
                        return j;
                    case 1:
                        return b;
                    case 2:
                    default:
                        return null;
                    case 3:
                        return c;
                    case 4:
                        return d;
                    case 5:
                        return e;
                    case 6:
                        return f;
                    case 7:
                        return g;
                    case 8:
                        return h;
                    case 9:
                        return i;
                }
            }
        }

        static {
            EncryptedPacketPayload encryptedPacketPayload = new EncryptedPacketPayload();
            DEFAULT_INSTANCE = encryptedPacketPayload;
            GeneratedMessageLite.registerDefaultInstance(EncryptedPacketPayload.class, encryptedPacketPayload);
        }

        private EncryptedPacketPayload() {
        }

        private void clearChatMessage() {
            if (this.valueCase_ == 3) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearRpcAck() {
            if (this.valueCase_ == 5) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearRpcRequest() {
            if (this.valueCase_ == 4) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearRpcResponse() {
            if (this.valueCase_ == 6) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearStreamChunk() {
            if (this.valueCase_ == 8) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearStreamHeader() {
            if (this.valueCase_ == 7) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearStreamTrailer() {
            if (this.valueCase_ == 9) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearUser() {
            if (this.valueCase_ == 1) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearValue() {
            this.valueCase_ = 0;
            this.value_ = null;
        }

        public static EncryptedPacketPayload getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeChatMessage(ChatMessage chatMessage) {
            chatMessage.getClass();
            if (this.valueCase_ != 3 || this.value_ == ChatMessage.getDefaultInstance()) {
                this.value_ = chatMessage;
            } else {
                this.value_ = ((ChatMessage.Builder) ChatMessage.newBuilder((ChatMessage) this.value_).v(chatMessage)).o();
            }
            this.valueCase_ = 3;
        }

        private void mergeRpcAck(RpcAck rpcAck) {
            rpcAck.getClass();
            if (this.valueCase_ != 5 || this.value_ == RpcAck.getDefaultInstance()) {
                this.value_ = rpcAck;
            } else {
                this.value_ = ((RpcAck.Builder) RpcAck.newBuilder((RpcAck) this.value_).v(rpcAck)).o();
            }
            this.valueCase_ = 5;
        }

        private void mergeRpcRequest(RpcRequest rpcRequest) {
            rpcRequest.getClass();
            if (this.valueCase_ != 4 || this.value_ == RpcRequest.getDefaultInstance()) {
                this.value_ = rpcRequest;
            } else {
                this.value_ = ((RpcRequest.Builder) RpcRequest.newBuilder((RpcRequest) this.value_).v(rpcRequest)).o();
            }
            this.valueCase_ = 4;
        }

        private void mergeRpcResponse(RpcResponse rpcResponse) {
            rpcResponse.getClass();
            if (this.valueCase_ != 6 || this.value_ == RpcResponse.getDefaultInstance()) {
                this.value_ = rpcResponse;
            } else {
                this.value_ = ((RpcResponse.Builder) RpcResponse.newBuilder((RpcResponse) this.value_).v(rpcResponse)).o();
            }
            this.valueCase_ = 6;
        }

        private void mergeStreamChunk(DataStream.Chunk chunk) {
            chunk.getClass();
            if (this.valueCase_ != 8 || this.value_ == DataStream.Chunk.getDefaultInstance()) {
                this.value_ = chunk;
            } else {
                this.value_ = ((DataStream.Chunk.Builder) DataStream.Chunk.newBuilder((DataStream.Chunk) this.value_).v(chunk)).o();
            }
            this.valueCase_ = 8;
        }

        private void mergeStreamHeader(DataStream.Header header) {
            header.getClass();
            if (this.valueCase_ != 7 || this.value_ == DataStream.Header.getDefaultInstance()) {
                this.value_ = header;
            } else {
                this.value_ = ((DataStream.Header.Builder) DataStream.Header.newBuilder((DataStream.Header) this.value_).v(header)).o();
            }
            this.valueCase_ = 7;
        }

        private void mergeStreamTrailer(DataStream.Trailer trailer) {
            trailer.getClass();
            if (this.valueCase_ != 9 || this.value_ == DataStream.Trailer.getDefaultInstance()) {
                this.value_ = trailer;
            } else {
                this.value_ = ((DataStream.Trailer.Builder) DataStream.Trailer.newBuilder((DataStream.Trailer) this.value_).v(trailer)).o();
            }
            this.valueCase_ = 9;
        }

        private void mergeUser(UserPacket userPacket) {
            userPacket.getClass();
            if (this.valueCase_ != 1 || this.value_ == UserPacket.getDefaultInstance()) {
                this.value_ = userPacket;
            } else {
                this.value_ = ((UserPacket.Builder) UserPacket.newBuilder((UserPacket) this.value_).v(userPacket)).o();
            }
            this.valueCase_ = 1;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static EncryptedPacketPayload parseDelimitedFrom(InputStream inputStream) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EncryptedPacketPayload parseFrom(ByteBuffer byteBuffer) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<EncryptedPacketPayload> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setChatMessage(ChatMessage chatMessage) {
            chatMessage.getClass();
            this.value_ = chatMessage;
            this.valueCase_ = 3;
        }

        private void setRpcAck(RpcAck rpcAck) {
            rpcAck.getClass();
            this.value_ = rpcAck;
            this.valueCase_ = 5;
        }

        private void setRpcRequest(RpcRequest rpcRequest) {
            rpcRequest.getClass();
            this.value_ = rpcRequest;
            this.valueCase_ = 4;
        }

        private void setRpcResponse(RpcResponse rpcResponse) {
            rpcResponse.getClass();
            this.value_ = rpcResponse;
            this.valueCase_ = 6;
        }

        private void setStreamChunk(DataStream.Chunk chunk) {
            chunk.getClass();
            this.value_ = chunk;
            this.valueCase_ = 8;
        }

        private void setStreamHeader(DataStream.Header header) {
            header.getClass();
            this.value_ = header;
            this.valueCase_ = 7;
        }

        private void setStreamTrailer(DataStream.Trailer trailer) {
            trailer.getClass();
            this.value_ = trailer;
            this.valueCase_ = 9;
        }

        private void setUser(UserPacket userPacket) {
            userPacket.getClass();
            this.value_ = userPacket;
            this.valueCase_ = 1;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new EncryptedPacketPayload();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\b\u0001\u0000\u0001\t\b\u0000\u0000\u0000\u0001<\u0000\u0003<\u0000\u0004<\u0000\u0005<\u0000\u0006<\u0000\u0007<\u0000\b<\u0000\t<\u0000", new Object[]{ap.a(1949451387), ap.a(1686617263), UserPacket.class, ChatMessage.class, RpcRequest.class, RpcAck.class, RpcResponse.class, DataStream.Header.class, DataStream.Chunk.class, DataStream.Trailer.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<EncryptedPacketPayload> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (EncryptedPacketPayload.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public ChatMessage getChatMessage() {
            return this.valueCase_ == 3 ? (ChatMessage) this.value_ : ChatMessage.getDefaultInstance();
        }

        public RpcAck getRpcAck() {
            return this.valueCase_ == 5 ? (RpcAck) this.value_ : RpcAck.getDefaultInstance();
        }

        public RpcRequest getRpcRequest() {
            return this.valueCase_ == 4 ? (RpcRequest) this.value_ : RpcRequest.getDefaultInstance();
        }

        public RpcResponse getRpcResponse() {
            return this.valueCase_ == 6 ? (RpcResponse) this.value_ : RpcResponse.getDefaultInstance();
        }

        public DataStream.Chunk getStreamChunk() {
            return this.valueCase_ == 8 ? (DataStream.Chunk) this.value_ : DataStream.Chunk.getDefaultInstance();
        }

        public DataStream.Header getStreamHeader() {
            return this.valueCase_ == 7 ? (DataStream.Header) this.value_ : DataStream.Header.getDefaultInstance();
        }

        public DataStream.Trailer getStreamTrailer() {
            return this.valueCase_ == 9 ? (DataStream.Trailer) this.value_ : DataStream.Trailer.getDefaultInstance();
        }

        public UserPacket getUser() {
            return this.valueCase_ == 1 ? (UserPacket) this.value_ : UserPacket.getDefaultInstance();
        }

        public ValueCase getValueCase() {
            return ValueCase.b(this.valueCase_);
        }

        public boolean hasChatMessage() {
            return this.valueCase_ == 3;
        }

        public boolean hasRpcAck() {
            return this.valueCase_ == 5;
        }

        public boolean hasRpcRequest() {
            return this.valueCase_ == 4;
        }

        public boolean hasRpcResponse() {
            return this.valueCase_ == 6;
        }

        public boolean hasStreamChunk() {
            return this.valueCase_ == 8;
        }

        public boolean hasStreamHeader() {
            return this.valueCase_ == 7;
        }

        public boolean hasStreamTrailer() {
            return this.valueCase_ == 9;
        }

        public boolean hasUser() {
            return this.valueCase_ == 1;
        }

        public static Builder newBuilder(EncryptedPacketPayload encryptedPacketPayload) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(encryptedPacketPayload);
        }

        public static EncryptedPacketPayload parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EncryptedPacketPayload parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static EncryptedPacketPayload parseFrom(ByteString byteString) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static EncryptedPacketPayload parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static EncryptedPacketPayload parseFrom(byte[] bArr) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static EncryptedPacketPayload parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static EncryptedPacketPayload parseFrom(InputStream inputStream) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EncryptedPacketPayload parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EncryptedPacketPayload parseFrom(CodedInputStream codedInputStream) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static EncryptedPacketPayload parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncryptedPacketPayload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface EncryptedPacketPayloadOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class Encryption extends GeneratedMessageLite<Encryption, Builder> implements EncryptionOrBuilder {
        private static final Encryption DEFAULT_INSTANCE;
        private static volatile Parser<Encryption> PARSER;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<Encryption, Builder> implements EncryptionOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(Encryption.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum Type implements Internal.EnumLite {
            b(0),
            c(1),
            d(2),
            e(-1);

            private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<Type>() { // from class: livekit.LivekitModels.Encryption.Type.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public Type findValueByNumber(int i) {
                    return Type.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class TypeVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new TypeVerifier();

                private TypeVerifier() {
                }

                public boolean isInRange(int i) {
                    return Type.b(i) != null;
                }
            }

            Type(int i) {
                this.a = i;
            }

            public static Type b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i == 1) {
                    return c;
                }
                if (i != 2) {
                    return null;
                }
                return d;
            }

            public final int getNumber() {
                if (this != e) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        static {
            Encryption encryption = new Encryption();
            DEFAULT_INSTANCE = encryption;
            GeneratedMessageLite.registerDefaultInstance(Encryption.class, encryption);
        }

        private Encryption() {
        }

        public static Encryption getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static Encryption parseDelimitedFrom(InputStream inputStream) {
            return (Encryption) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Encryption parseFrom(ByteBuffer byteBuffer) {
            return (Encryption) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<Encryption> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new Encryption();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0000", (Object[]) null);
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<Encryption> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (Encryption.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public static Builder newBuilder(Encryption encryption) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(encryption);
        }

        public static Encryption parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Encryption) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Encryption parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (Encryption) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static Encryption parseFrom(ByteString byteString) {
            return (Encryption) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static Encryption parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (Encryption) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static Encryption parseFrom(byte[] bArr) {
            return (Encryption) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static Encryption parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (Encryption) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static Encryption parseFrom(InputStream inputStream) {
            return (Encryption) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Encryption parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Encryption) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Encryption parseFrom(CodedInputStream codedInputStream) {
            return (Encryption) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static Encryption parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Encryption) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface EncryptionOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum ImageCodec implements Internal.EnumLite {
        b(0),
        c(1),
        d(-1);

        private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<ImageCodec>() { // from class: livekit.LivekitModels.ImageCodec.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public ImageCodec findValueByNumber(int i) {
                return ImageCodec.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class ImageCodecVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new ImageCodecVerifier();

            private ImageCodecVerifier() {
            }

            public boolean isInRange(int i) {
                return ImageCodec.b(i) != null;
            }
        }

        ImageCodec(int i) {
            this.a = i;
        }

        public static ImageCodec b(int i) {
            if (i == 0) {
                return b;
            }
            if (i != 1) {
                return null;
            }
            return c;
        }

        public final int getNumber() {
            if (this != d) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListUpdate extends GeneratedMessageLite<ListUpdate, Builder> implements ListUpdateOrBuilder {
        public static final int ADD_FIELD_NUMBER = 2;
        public static final int CLEAR_FIELD_NUMBER = 4;
        private static final ListUpdate DEFAULT_INSTANCE;
        private static volatile Parser<ListUpdate> PARSER = null;
        public static final int REMOVE_FIELD_NUMBER = 3;
        public static final int SET_FIELD_NUMBER = 1;
        private boolean clear_;
        private Internal.ProtobufList<String> set_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<String> add_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<String> remove_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListUpdate, Builder> implements ListUpdateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListUpdate.DEFAULT_INSTANCE);
            }
        }

        static {
            ListUpdate listUpdate = new ListUpdate();
            DEFAULT_INSTANCE = listUpdate;
            GeneratedMessageLite.registerDefaultInstance(ListUpdate.class, listUpdate);
        }

        private ListUpdate() {
        }

        private void addAdd(String str) {
            str.getClass();
            ensureAddIsMutable();
            this.add_.add(str);
        }

        private void addAddBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureAddIsMutable();
            this.add_.add(byteString.L());
        }

        private void addAllAdd(Iterable<String> iterable) {
            ensureAddIsMutable();
            AbstractMessageLite.addAll(iterable, this.add_);
        }

        private void addAllRemove(Iterable<String> iterable) {
            ensureRemoveIsMutable();
            AbstractMessageLite.addAll(iterable, this.remove_);
        }

        private void addAllSet(Iterable<String> iterable) {
            ensureSetIsMutable();
            AbstractMessageLite.addAll(iterable, this.set_);
        }

        private void addRemove(String str) {
            str.getClass();
            ensureRemoveIsMutable();
            this.remove_.add(str);
        }

        private void addRemoveBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureRemoveIsMutable();
            this.remove_.add(byteString.L());
        }

        private void addSet(String str) {
            str.getClass();
            ensureSetIsMutable();
            this.set_.add(str);
        }

        private void addSetBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureSetIsMutable();
            this.set_.add(byteString.L());
        }

        private void clearAdd() {
            this.add_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearClear() {
            this.clear_ = false;
        }

        private void clearRemove() {
            this.remove_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSet() {
            this.set_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureAddIsMutable() {
            Internal.ProtobufList<String> protobufList = this.add_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.add_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureRemoveIsMutable() {
            Internal.ProtobufList<String> protobufList = this.remove_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.remove_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSetIsMutable() {
            Internal.ProtobufList<String> protobufList = this.set_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.set_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListUpdate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListUpdate parseDelimitedFrom(InputStream inputStream) {
            return (ListUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListUpdate parseFrom(ByteBuffer byteBuffer) {
            return (ListUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListUpdate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAdd(int i, String str) {
            str.getClass();
            ensureAddIsMutable();
            this.add_.set(i, str);
        }

        private void setClear(boolean z) {
            this.clear_ = z;
        }

        private void setRemove(int i, String str) {
            str.getClass();
            ensureRemoveIsMutable();
            this.remove_.set(i, str);
        }

        private void setSet(int i, String str) {
            str.getClass();
            ensureSetIsMutable();
            this.set_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListUpdate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0003\u0000\u0001Ț\u0002Ț\u0003Ț\u0004\u0007", new Object[]{ap.a(90233744), ap.a(1455953791), ap.a(1926194373), ap.a(446257885)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListUpdate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListUpdate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAdd(int i) {
            return (String) this.add_.get(i);
        }

        public ByteString getAddBytes(int i) {
            return ByteString.n((String) this.add_.get(i));
        }

        public int getAddCount() {
            return this.add_.size();
        }

        public List<String> getAddList() {
            return this.add_;
        }

        public boolean getClear() {
            return this.clear_;
        }

        public String getRemove(int i) {
            return (String) this.remove_.get(i);
        }

        public ByteString getRemoveBytes(int i) {
            return ByteString.n((String) this.remove_.get(i));
        }

        public int getRemoveCount() {
            return this.remove_.size();
        }

        public List<String> getRemoveList() {
            return this.remove_;
        }

        public String getSet(int i) {
            return (String) this.set_.get(i);
        }

        public ByteString getSetBytes(int i) {
            return ByteString.n((String) this.set_.get(i));
        }

        public int getSetCount() {
            return this.set_.size();
        }

        public List<String> getSetList() {
            return this.set_;
        }

        public static Builder newBuilder(ListUpdate listUpdate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listUpdate);
        }

        public static ListUpdate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListUpdate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListUpdate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListUpdate parseFrom(ByteString byteString) {
            return (ListUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListUpdate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListUpdate parseFrom(byte[] bArr) {
            return (ListUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListUpdate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListUpdate parseFrom(InputStream inputStream) {
            return (ListUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListUpdate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListUpdate parseFrom(CodedInputStream codedInputStream) {
            return (ListUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListUpdate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListUpdate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListUpdateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class Pagination extends GeneratedMessageLite<Pagination, Builder> implements PaginationOrBuilder {
        public static final int AFTER_ID_FIELD_NUMBER = 1;
        private static final Pagination DEFAULT_INSTANCE;
        public static final int LIMIT_FIELD_NUMBER = 2;
        private static volatile Parser<Pagination> PARSER;
        private String afterId_ = ap.a(2049032055);
        private int limit_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<Pagination, Builder> implements PaginationOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(Pagination.DEFAULT_INSTANCE);
            }
        }

        static {
            Pagination pagination = new Pagination();
            DEFAULT_INSTANCE = pagination;
            GeneratedMessageLite.registerDefaultInstance(Pagination.class, pagination);
        }

        private Pagination() {
        }

        private void clearAfterId() {
            this.afterId_ = getDefaultInstance().getAfterId();
        }

        private void clearLimit() {
            this.limit_ = 0;
        }

        public static Pagination getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static Pagination parseDelimitedFrom(InputStream inputStream) {
            return (Pagination) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Pagination parseFrom(ByteBuffer byteBuffer) {
            return (Pagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<Pagination> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAfterId(String str) {
            str.getClass();
            this.afterId_ = str;
        }

        private void setAfterIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.afterId_ = byteString.L();
        }

        private void setLimit(int i) {
            this.limit_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new Pagination();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002\u0004", new Object[]{"afterId_", "limit_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<Pagination> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (Pagination.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAfterId() {
            return this.afterId_;
        }

        public ByteString getAfterIdBytes() {
            return ByteString.n(this.afterId_);
        }

        public int getLimit() {
            return this.limit_;
        }

        public static Builder newBuilder(Pagination pagination) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(pagination);
        }

        public static Pagination parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Pagination) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Pagination parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (Pagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static Pagination parseFrom(ByteString byteString) {
            return (Pagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static Pagination parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (Pagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static Pagination parseFrom(byte[] bArr) {
            return (Pagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static Pagination parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (Pagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static Pagination parseFrom(InputStream inputStream) {
            return (Pagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Pagination parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Pagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Pagination parseFrom(CodedInputStream codedInputStream) {
            return (Pagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static Pagination parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Pagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface PaginationOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ParticipantInfo extends GeneratedMessageLite<ParticipantInfo, Builder> implements ParticipantInfoOrBuilder {
        public static final int ATTRIBUTES_FIELD_NUMBER = 15;
        private static final ParticipantInfo DEFAULT_INSTANCE;
        public static final int DISCONNECT_REASON_FIELD_NUMBER = 16;
        public static final int IDENTITY_FIELD_NUMBER = 2;
        public static final int IS_PUBLISHER_FIELD_NUMBER = 13;
        public static final int JOINED_AT_FIELD_NUMBER = 6;
        public static final int JOINED_AT_MS_FIELD_NUMBER = 17;
        public static final int KIND_DETAILS_FIELD_NUMBER = 18;
        public static final int KIND_FIELD_NUMBER = 14;
        public static final int METADATA_FIELD_NUMBER = 5;
        public static final int NAME_FIELD_NUMBER = 9;
        private static volatile Parser<ParticipantInfo> PARSER = null;
        public static final int PERMISSION_FIELD_NUMBER = 11;
        public static final int REGION_FIELD_NUMBER = 12;
        public static final int SID_FIELD_NUMBER = 1;
        public static final int STATE_FIELD_NUMBER = 3;
        public static final int TRACKS_FIELD_NUMBER = 4;
        public static final int VERSION_FIELD_NUMBER = 10;
        private static final Internal.ListAdapter.Converter<Integer, KindDetail> kindDetails_converter_ = new Internal.ListAdapter.Converter<Integer, KindDetail>() { // from class: livekit.LivekitModels.ParticipantInfo.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public KindDetail convert(Integer num) {
                KindDetail kindDetailB = KindDetail.b(num.intValue());
                return kindDetailB == null ? KindDetail.d : kindDetailB;
            }
        };
        private MapFieldLite<String, String> attributes_ = MapFieldLite.f();
        private int disconnectReason_;
        private String identity_;
        private boolean isPublisher_;
        private long joinedAtMs_;
        private long joinedAt_;
        private int kindDetailsMemoizedSerializedSize;
        private Internal.IntList kindDetails_;
        private int kind_;
        private String metadata_;
        private String name_;
        private ParticipantPermission permission_;
        private String region_;
        private String sid_;
        private int state_;
        private Internal.ProtobufList<TrackInfo> tracks_;
        private int version_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(909982674);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private AttributesDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ParticipantInfo, Builder> implements ParticipantInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(String str) {
                q();
                ((ParticipantInfo) ((GeneratedMessageLite.Builder) this).b).setIdentity(str);
                return this;
            }

            private Builder() {
                super(ParticipantInfo.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum Kind implements Internal.EnumLite {
            b(0),
            c(1),
            d(2),
            e(3),
            f(4),
            g(-1);

            private static final Internal.EnumLiteMap h = new Internal.EnumLiteMap<Kind>() { // from class: livekit.LivekitModels.ParticipantInfo.Kind.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public Kind findValueByNumber(int i2) {
                    return Kind.b(i2);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class KindVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new KindVerifier();

                private KindVerifier() {
                }

                public boolean isInRange(int i) {
                    return Kind.b(i) != null;
                }
            }

            Kind(int i2) {
                this.a = i2;
            }

            public static Kind b(int i2) {
                if (i2 == 0) {
                    return b;
                }
                if (i2 == 1) {
                    return c;
                }
                if (i2 == 2) {
                    return d;
                }
                if (i2 == 3) {
                    return e;
                }
                if (i2 != 4) {
                    return null;
                }
                return f;
            }

            public final int getNumber() {
                if (this != g) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum KindDetail implements Internal.EnumLite {
            b(0),
            c(1),
            d(-1);

            private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<KindDetail>() { // from class: livekit.LivekitModels.ParticipantInfo.KindDetail.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public KindDetail findValueByNumber(int i) {
                    return KindDetail.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class KindDetailVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new KindDetailVerifier();

                private KindDetailVerifier() {
                }

                public boolean isInRange(int i) {
                    return KindDetail.b(i) != null;
                }
            }

            KindDetail(int i) {
                this.a = i;
            }

            public static KindDetail b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i != 1) {
                    return null;
                }
                return c;
            }

            public final int getNumber() {
                if (this != d) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum State implements Internal.EnumLite {
            b(0),
            c(1),
            d(2),
            e(3),
            f(-1);

            private static final Internal.EnumLiteMap g = new Internal.EnumLiteMap<State>() { // from class: livekit.LivekitModels.ParticipantInfo.State.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public State findValueByNumber(int i) {
                    return State.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class StateVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new StateVerifier();

                private StateVerifier() {
                }

                public boolean isInRange(int i) {
                    return State.b(i) != null;
                }
            }

            State(int i) {
                this.a = i;
            }

            public static State b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i == 1) {
                    return c;
                }
                if (i == 2) {
                    return d;
                }
                if (i != 3) {
                    return null;
                }
                return e;
            }

            public final int getNumber() {
                if (this != f) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        static {
            ParticipantInfo participantInfo = new ParticipantInfo();
            DEFAULT_INSTANCE = participantInfo;
            GeneratedMessageLite.registerDefaultInstance(ParticipantInfo.class, participantInfo);
        }

        private ParticipantInfo() {
            String strA = ap.a(1334488860);
            this.sid_ = strA;
            this.identity_ = strA;
            this.tracks_ = GeneratedMessageLite.emptyProtobufList();
            this.metadata_ = strA;
            this.name_ = strA;
            this.region_ = strA;
            this.kindDetails_ = GeneratedMessageLite.emptyIntList();
        }

        private void addAllKindDetails(Iterable<? extends KindDetail> iterable) {
            ensureKindDetailsIsMutable();
            Iterator<? extends KindDetail> it = iterable.iterator();
            while (it.hasNext()) {
                this.kindDetails_.addInt(it.next().getNumber());
            }
        }

        private void addAllKindDetailsValue(Iterable<Integer> iterable) {
            ensureKindDetailsIsMutable();
            Iterator<Integer> it = iterable.iterator();
            while (it.hasNext()) {
                this.kindDetails_.addInt(it.next().intValue());
            }
        }

        private void addAllTracks(Iterable<? extends TrackInfo> iterable) {
            ensureTracksIsMutable();
            AbstractMessageLite.addAll(iterable, this.tracks_);
        }

        private void addKindDetails(KindDetail kindDetail) {
            kindDetail.getClass();
            ensureKindDetailsIsMutable();
            this.kindDetails_.addInt(kindDetail.getNumber());
        }

        private void addKindDetailsValue(int i) {
            ensureKindDetailsIsMutable();
            this.kindDetails_.addInt(i);
        }

        private void addTracks(TrackInfo trackInfo) {
            trackInfo.getClass();
            ensureTracksIsMutable();
            this.tracks_.add(trackInfo);
        }

        private void clearDisconnectReason() {
            this.disconnectReason_ = 0;
        }

        private void clearIdentity() {
            this.identity_ = getDefaultInstance().getIdentity();
        }

        private void clearIsPublisher() {
            this.isPublisher_ = false;
        }

        private void clearJoinedAt() {
            this.joinedAt_ = 0L;
        }

        private void clearJoinedAtMs() {
            this.joinedAtMs_ = 0L;
        }

        private void clearKind() {
            this.kind_ = 0;
        }

        private void clearKindDetails() {
            this.kindDetails_ = GeneratedMessageLite.emptyIntList();
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearPermission() {
            this.permission_ = null;
        }

        private void clearRegion() {
            this.region_ = getDefaultInstance().getRegion();
        }

        private void clearSid() {
            this.sid_ = getDefaultInstance().getSid();
        }

        private void clearState() {
            this.state_ = 0;
        }

        private void clearTracks() {
            this.tracks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearVersion() {
            this.version_ = 0;
        }

        private void ensureKindDetailsIsMutable() {
            Internal.IntList intList = this.kindDetails_;
            if (intList.isModifiable()) {
                return;
            }
            this.kindDetails_ = GeneratedMessageLite.mutableCopy(intList);
        }

        private void ensureTracksIsMutable() {
            Internal.ProtobufList<TrackInfo> protobufList = this.tracks_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.tracks_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ParticipantInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableAttributesMap() {
            return internalGetMutableAttributes();
        }

        private MapFieldLite<String, String> internalGetAttributes() {
            return this.attributes_;
        }

        private MapFieldLite<String, String> internalGetMutableAttributes() {
            if (!this.attributes_.k()) {
                this.attributes_ = this.attributes_.n();
            }
            return this.attributes_;
        }

        private void mergePermission(ParticipantPermission participantPermission) {
            participantPermission.getClass();
            ParticipantPermission participantPermission2 = this.permission_;
            if (participantPermission2 == null || participantPermission2 == ParticipantPermission.getDefaultInstance()) {
                this.permission_ = participantPermission;
            } else {
                this.permission_ = (ParticipantPermission) ((ParticipantPermission.Builder) ParticipantPermission.newBuilder(this.permission_).v(participantPermission)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ParticipantInfo parseDelimitedFrom(InputStream inputStream) {
            return (ParticipantInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ParticipantInfo parseFrom(ByteBuffer byteBuffer) {
            return (ParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ParticipantInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeTracks(int i) {
            ensureTracksIsMutable();
            this.tracks_.remove(i);
        }

        private void setDisconnectReason(DisconnectReason disconnectReason) {
            this.disconnectReason_ = disconnectReason.getNumber();
        }

        private void setDisconnectReasonValue(int i) {
            this.disconnectReason_ = i;
        }

        private void setIdentity(String str) {
            str.getClass();
            this.identity_ = str;
        }

        private void setIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.identity_ = byteString.L();
        }

        private void setIsPublisher(boolean z) {
            this.isPublisher_ = z;
        }

        private void setJoinedAt(long j) {
            this.joinedAt_ = j;
        }

        private void setJoinedAtMs(long j) {
            this.joinedAtMs_ = j;
        }

        private void setKind(Kind kind) {
            this.kind_ = kind.getNumber();
        }

        private void setKindDetails(int i, KindDetail kindDetail) {
            kindDetail.getClass();
            ensureKindDetailsIsMutable();
            this.kindDetails_.setInt(i, kindDetail.getNumber());
        }

        private void setKindDetailsValue(int i, int i2) {
            ensureKindDetailsIsMutable();
            this.kindDetails_.setInt(i, i2);
        }

        private void setKindValue(int i) {
            this.kind_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setPermission(ParticipantPermission participantPermission) {
            participantPermission.getClass();
            this.permission_ = participantPermission;
        }

        private void setRegion(String str) {
            str.getClass();
            this.region_ = str;
        }

        private void setRegionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.region_ = byteString.L();
        }

        private void setSid(String str) {
            str.getClass();
            this.sid_ = str;
        }

        private void setSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sid_ = byteString.L();
        }

        private void setState(State state) {
            this.state_ = state.getNumber();
        }

        private void setStateValue(int i) {
            this.state_ = i;
        }

        private void setTracks(int i, TrackInfo trackInfo) {
            trackInfo.getClass();
            ensureTracksIsMutable();
            this.tracks_.set(i, trackInfo);
        }

        private void setVersion(int i) {
            this.version_ = i;
        }

        public boolean containsAttributes(String str) {
            str.getClass();
            return internalGetAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new ParticipantInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0010\u0000\u0000\u0001\u0012\u0010\u0001\u0002\u0000\u0001Ȉ\u0002Ȉ\u0003\f\u0004\u001b\u0005Ȉ\u0006\u0002\tȈ\n\u000b\u000b\t\fȈ\r\u0007\u000e\f\u000f2\u0010\f\u0011\u0002\u0012,", new Object[]{"sid_", "identity_", "state_", "tracks_", TrackInfo.class, "metadata_", "joinedAt_", "name_", "version_", "permission_", "region_", "isPublisher_", "kind_", "attributes_", AttributesDefaultEntryHolder.a, "disconnectReason_", "joinedAtMs_", "kindDetails_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ParticipantInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ParticipantInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public Map<String, String> getAttributes() {
            return getAttributesMap();
        }

        public int getAttributesCount() {
            return internalGetAttributes().size();
        }

        public Map<String, String> getAttributesMap() {
            return Collections.unmodifiableMap(internalGetAttributes());
        }

        public String getAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            return mapFieldLiteInternalGetAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetAttributes.get(str) : str2;
        }

        public String getAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            if (mapFieldLiteInternalGetAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public DisconnectReason getDisconnectReason() {
            DisconnectReason disconnectReasonB = DisconnectReason.b(this.disconnectReason_);
            return disconnectReasonB == null ? DisconnectReason.r : disconnectReasonB;
        }

        public int getDisconnectReasonValue() {
            return this.disconnectReason_;
        }

        public String getIdentity() {
            return this.identity_;
        }

        public ByteString getIdentityBytes() {
            return ByteString.n(this.identity_);
        }

        public boolean getIsPublisher() {
            return this.isPublisher_;
        }

        public long getJoinedAt() {
            return this.joinedAt_;
        }

        public long getJoinedAtMs() {
            return this.joinedAtMs_;
        }

        public Kind getKind() {
            Kind kindB = Kind.b(this.kind_);
            return kindB == null ? Kind.g : kindB;
        }

        public KindDetail getKindDetails(int i) {
            KindDetail kindDetailB = KindDetail.b(this.kindDetails_.getInt(i));
            return kindDetailB == null ? KindDetail.d : kindDetailB;
        }

        public int getKindDetailsCount() {
            return this.kindDetails_.size();
        }

        public List<KindDetail> getKindDetailsList() {
            return new Internal.ListAdapter(this.kindDetails_, kindDetails_converter_);
        }

        public int getKindDetailsValue(int i) {
            return this.kindDetails_.getInt(i);
        }

        public List<Integer> getKindDetailsValueList() {
            return this.kindDetails_;
        }

        public int getKindValue() {
            return this.kind_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public ParticipantPermission getPermission() {
            ParticipantPermission participantPermission = this.permission_;
            return participantPermission == null ? ParticipantPermission.getDefaultInstance() : participantPermission;
        }

        public String getRegion() {
            return this.region_;
        }

        public ByteString getRegionBytes() {
            return ByteString.n(this.region_);
        }

        public String getSid() {
            return this.sid_;
        }

        public ByteString getSidBytes() {
            return ByteString.n(this.sid_);
        }

        public State getState() {
            State stateB = State.b(this.state_);
            return stateB == null ? State.f : stateB;
        }

        public int getStateValue() {
            return this.state_;
        }

        public TrackInfo getTracks(int i) {
            return (TrackInfo) this.tracks_.get(i);
        }

        public int getTracksCount() {
            return this.tracks_.size();
        }

        public List<TrackInfo> getTracksList() {
            return this.tracks_;
        }

        public TrackInfoOrBuilder getTracksOrBuilder(int i) {
            return (TrackInfoOrBuilder) this.tracks_.get(i);
        }

        public List<? extends TrackInfoOrBuilder> getTracksOrBuilderList() {
            return this.tracks_;
        }

        public int getVersion() {
            return this.version_;
        }

        public boolean hasPermission() {
            return this.permission_ != null;
        }

        public static Builder newBuilder(ParticipantInfo participantInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(participantInfo);
        }

        public static ParticipantInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ParticipantInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ParticipantInfo parseFrom(ByteString byteString) {
            return (ParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addTracks(int i, TrackInfo trackInfo) {
            trackInfo.getClass();
            ensureTracksIsMutable();
            this.tracks_.add(i, trackInfo);
        }

        public static ParticipantInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ParticipantInfo parseFrom(byte[] bArr) {
            return (ParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ParticipantInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ParticipantInfo parseFrom(InputStream inputStream) {
            return (ParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ParticipantInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ParticipantInfo parseFrom(CodedInputStream codedInputStream) {
            return (ParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ParticipantInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ParticipantInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ParticipantPermission extends GeneratedMessageLite<ParticipantPermission, Builder> implements ParticipantPermissionOrBuilder {
        public static final int AGENT_FIELD_NUMBER = 11;
        public static final int CAN_PUBLISH_DATA_FIELD_NUMBER = 3;
        public static final int CAN_PUBLISH_FIELD_NUMBER = 2;
        public static final int CAN_PUBLISH_SOURCES_FIELD_NUMBER = 9;
        public static final int CAN_SUBSCRIBE_FIELD_NUMBER = 1;
        public static final int CAN_SUBSCRIBE_METRICS_FIELD_NUMBER = 12;
        public static final int CAN_UPDATE_METADATA_FIELD_NUMBER = 10;
        private static final ParticipantPermission DEFAULT_INSTANCE;
        public static final int HIDDEN_FIELD_NUMBER = 7;
        private static volatile Parser<ParticipantPermission> PARSER = null;
        public static final int RECORDER_FIELD_NUMBER = 8;
        private static final Internal.ListAdapter.Converter<Integer, TrackSource> canPublishSources_converter_ = new Internal.ListAdapter.Converter<Integer, TrackSource>() { // from class: livekit.LivekitModels.ParticipantPermission.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public TrackSource convert(Integer num) {
                TrackSource trackSourceB = TrackSource.b(num.intValue());
                return trackSourceB == null ? TrackSource.g : trackSourceB;
            }
        };
        private boolean agent_;
        private boolean canPublishData_;
        private int canPublishSourcesMemoizedSerializedSize;
        private Internal.IntList canPublishSources_ = GeneratedMessageLite.emptyIntList();
        private boolean canPublish_;
        private boolean canSubscribeMetrics_;
        private boolean canSubscribe_;
        private boolean canUpdateMetadata_;
        private boolean hidden_;
        private boolean recorder_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ParticipantPermission, Builder> implements ParticipantPermissionOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ParticipantPermission.DEFAULT_INSTANCE);
            }
        }

        static {
            ParticipantPermission participantPermission = new ParticipantPermission();
            DEFAULT_INSTANCE = participantPermission;
            GeneratedMessageLite.registerDefaultInstance(ParticipantPermission.class, participantPermission);
        }

        private ParticipantPermission() {
        }

        private void addAllCanPublishSources(Iterable<? extends TrackSource> iterable) {
            ensureCanPublishSourcesIsMutable();
            Iterator<? extends TrackSource> it = iterable.iterator();
            while (it.hasNext()) {
                this.canPublishSources_.addInt(it.next().getNumber());
            }
        }

        private void addAllCanPublishSourcesValue(Iterable<Integer> iterable) {
            ensureCanPublishSourcesIsMutable();
            Iterator<Integer> it = iterable.iterator();
            while (it.hasNext()) {
                this.canPublishSources_.addInt(it.next().intValue());
            }
        }

        private void addCanPublishSources(TrackSource trackSource) {
            trackSource.getClass();
            ensureCanPublishSourcesIsMutable();
            this.canPublishSources_.addInt(trackSource.getNumber());
        }

        private void addCanPublishSourcesValue(int i) {
            ensureCanPublishSourcesIsMutable();
            this.canPublishSources_.addInt(i);
        }

        private void clearAgent() {
            this.agent_ = false;
        }

        private void clearCanPublish() {
            this.canPublish_ = false;
        }

        private void clearCanPublishData() {
            this.canPublishData_ = false;
        }

        private void clearCanPublishSources() {
            this.canPublishSources_ = GeneratedMessageLite.emptyIntList();
        }

        private void clearCanSubscribe() {
            this.canSubscribe_ = false;
        }

        private void clearCanSubscribeMetrics() {
            this.canSubscribeMetrics_ = false;
        }

        private void clearCanUpdateMetadata() {
            this.canUpdateMetadata_ = false;
        }

        private void clearHidden() {
            this.hidden_ = false;
        }

        private void clearRecorder() {
            this.recorder_ = false;
        }

        private void ensureCanPublishSourcesIsMutable() {
            Internal.IntList intList = this.canPublishSources_;
            if (intList.isModifiable()) {
                return;
            }
            this.canPublishSources_ = GeneratedMessageLite.mutableCopy(intList);
        }

        public static ParticipantPermission getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ParticipantPermission parseDelimitedFrom(InputStream inputStream) {
            return (ParticipantPermission) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ParticipantPermission parseFrom(ByteBuffer byteBuffer) {
            return (ParticipantPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ParticipantPermission> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgent(boolean z) {
            this.agent_ = z;
        }

        private void setCanPublish(boolean z) {
            this.canPublish_ = z;
        }

        private void setCanPublishData(boolean z) {
            this.canPublishData_ = z;
        }

        private void setCanPublishSources(int i, TrackSource trackSource) {
            trackSource.getClass();
            ensureCanPublishSourcesIsMutable();
            this.canPublishSources_.setInt(i, trackSource.getNumber());
        }

        private void setCanPublishSourcesValue(int i, int i2) {
            ensureCanPublishSourcesIsMutable();
            this.canPublishSources_.setInt(i, i2);
        }

        private void setCanSubscribe(boolean z) {
            this.canSubscribe_ = z;
        }

        private void setCanSubscribeMetrics(boolean z) {
            this.canSubscribeMetrics_ = z;
        }

        private void setCanUpdateMetadata(boolean z) {
            this.canUpdateMetadata_ = z;
        }

        private void setHidden(boolean z) {
            this.hidden_ = z;
        }

        private void setRecorder(boolean z) {
            this.recorder_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ParticipantPermission();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\t\u0000\u0000\u0001\f\t\u0000\u0001\u0000\u0001\u0007\u0002\u0007\u0003\u0007\u0007\u0007\b\u0007\t,\n\u0007\u000b\u0007\f\u0007", new Object[]{ap.a(1695844502), ap.a(1865779829), ap.a(897842277), ap.a(746529510), ap.a(1266185280), ap.a(1586495794), ap.a(894486546), ap.a(1798990053), ap.a(1588212125)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ParticipantPermission> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ParticipantPermission.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public boolean getAgent() {
            return this.agent_;
        }

        public boolean getCanPublish() {
            return this.canPublish_;
        }

        public boolean getCanPublishData() {
            return this.canPublishData_;
        }

        public TrackSource getCanPublishSources(int i) {
            TrackSource trackSourceB = TrackSource.b(this.canPublishSources_.getInt(i));
            return trackSourceB == null ? TrackSource.g : trackSourceB;
        }

        public int getCanPublishSourcesCount() {
            return this.canPublishSources_.size();
        }

        public List<TrackSource> getCanPublishSourcesList() {
            return new Internal.ListAdapter(this.canPublishSources_, canPublishSources_converter_);
        }

        public int getCanPublishSourcesValue(int i) {
            return this.canPublishSources_.getInt(i);
        }

        public List<Integer> getCanPublishSourcesValueList() {
            return this.canPublishSources_;
        }

        public boolean getCanSubscribe() {
            return this.canSubscribe_;
        }

        public boolean getCanSubscribeMetrics() {
            return this.canSubscribeMetrics_;
        }

        public boolean getCanUpdateMetadata() {
            return this.canUpdateMetadata_;
        }

        public boolean getHidden() {
            return this.hidden_;
        }

        @Deprecated
        public boolean getRecorder() {
            return this.recorder_;
        }

        public static Builder newBuilder(ParticipantPermission participantPermission) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(participantPermission);
        }

        public static ParticipantPermission parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantPermission) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ParticipantPermission parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ParticipantPermission parseFrom(ByteString byteString) {
            return (ParticipantPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ParticipantPermission parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ParticipantPermission parseFrom(byte[] bArr) {
            return (ParticipantPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ParticipantPermission parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ParticipantPermission parseFrom(InputStream inputStream) {
            return (ParticipantPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ParticipantPermission parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ParticipantPermission parseFrom(CodedInputStream codedInputStream) {
            return (ParticipantPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ParticipantPermission parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantPermission) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ParticipantPermissionOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ParticipantTracks extends GeneratedMessageLite<ParticipantTracks, Builder> implements ParticipantTracksOrBuilder {
        private static final ParticipantTracks DEFAULT_INSTANCE;
        private static volatile Parser<ParticipantTracks> PARSER = null;
        public static final int PARTICIPANT_SID_FIELD_NUMBER = 1;
        public static final int TRACK_SIDS_FIELD_NUMBER = 2;
        private String participantSid_ = ap.a(1831006226);
        private Internal.ProtobufList<String> trackSids_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ParticipantTracks, Builder> implements ParticipantTracksOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(String str) {
                q();
                ((ParticipantTracks) ((GeneratedMessageLite.Builder) this).b).addTrackSids(str);
                return this;
            }

            public int B() {
                return ((ParticipantTracks) ((GeneratedMessageLite.Builder) this).b).getTrackSidsCount();
            }

            public Builder C(String str) {
                q();
                ((ParticipantTracks) ((GeneratedMessageLite.Builder) this).b).setParticipantSid(str);
                return this;
            }

            private Builder() {
                super(ParticipantTracks.DEFAULT_INSTANCE);
            }
        }

        static {
            ParticipantTracks participantTracks = new ParticipantTracks();
            DEFAULT_INSTANCE = participantTracks;
            GeneratedMessageLite.registerDefaultInstance(ParticipantTracks.class, participantTracks);
        }

        private ParticipantTracks() {
        }

        private void addAllTrackSids(Iterable<String> iterable) {
            ensureTrackSidsIsMutable();
            AbstractMessageLite.addAll(iterable, this.trackSids_);
        }

        private void addTrackSids(String str) {
            str.getClass();
            ensureTrackSidsIsMutable();
            this.trackSids_.add(str);
        }

        private void addTrackSidsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureTrackSidsIsMutable();
            this.trackSids_.add(byteString.L());
        }

        private void clearParticipantSid() {
            this.participantSid_ = getDefaultInstance().getParticipantSid();
        }

        private void clearTrackSids() {
            this.trackSids_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureTrackSidsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.trackSids_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trackSids_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ParticipantTracks getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ParticipantTracks parseDelimitedFrom(InputStream inputStream) {
            return (ParticipantTracks) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ParticipantTracks parseFrom(ByteBuffer byteBuffer) {
            return (ParticipantTracks) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ParticipantTracks> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setParticipantSid(String str) {
            str.getClass();
            this.participantSid_ = str;
        }

        private void setParticipantSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantSid_ = byteString.L();
        }

        private void setTrackSids(int i, String str) {
            str.getClass();
            ensureTrackSidsIsMutable();
            this.trackSids_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ParticipantTracks();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001Ȉ\u0002Ț", new Object[]{"participantSid_", "trackSids_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ParticipantTracks> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ParticipantTracks.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getParticipantSid() {
            return this.participantSid_;
        }

        public ByteString getParticipantSidBytes() {
            return ByteString.n(this.participantSid_);
        }

        public String getTrackSids(int i) {
            return (String) this.trackSids_.get(i);
        }

        public ByteString getTrackSidsBytes(int i) {
            return ByteString.n((String) this.trackSids_.get(i));
        }

        public int getTrackSidsCount() {
            return this.trackSids_.size();
        }

        public List<String> getTrackSidsList() {
            return this.trackSids_;
        }

        public static Builder newBuilder(ParticipantTracks participantTracks) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(participantTracks);
        }

        public static ParticipantTracks parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantTracks) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ParticipantTracks parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantTracks) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ParticipantTracks parseFrom(ByteString byteString) {
            return (ParticipantTracks) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ParticipantTracks parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantTracks) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ParticipantTracks parseFrom(byte[] bArr) {
            return (ParticipantTracks) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ParticipantTracks parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantTracks) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ParticipantTracks parseFrom(InputStream inputStream) {
            return (ParticipantTracks) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ParticipantTracks parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantTracks) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ParticipantTracks parseFrom(CodedInputStream codedInputStream) {
            return (ParticipantTracks) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ParticipantTracks parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantTracks) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ParticipantTracksOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class PlayoutDelay extends GeneratedMessageLite<PlayoutDelay, Builder> implements PlayoutDelayOrBuilder {
        private static final PlayoutDelay DEFAULT_INSTANCE;
        public static final int ENABLED_FIELD_NUMBER = 1;
        public static final int MAX_FIELD_NUMBER = 3;
        public static final int MIN_FIELD_NUMBER = 2;
        private static volatile Parser<PlayoutDelay> PARSER;
        private boolean enabled_;
        private int max_;
        private int min_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<PlayoutDelay, Builder> implements PlayoutDelayOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(PlayoutDelay.DEFAULT_INSTANCE);
            }
        }

        static {
            PlayoutDelay playoutDelay = new PlayoutDelay();
            DEFAULT_INSTANCE = playoutDelay;
            GeneratedMessageLite.registerDefaultInstance(PlayoutDelay.class, playoutDelay);
        }

        private PlayoutDelay() {
        }

        private void clearEnabled() {
            this.enabled_ = false;
        }

        private void clearMax() {
            this.max_ = 0;
        }

        private void clearMin() {
            this.min_ = 0;
        }

        public static PlayoutDelay getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static PlayoutDelay parseDelimitedFrom(InputStream inputStream) {
            return (PlayoutDelay) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PlayoutDelay parseFrom(ByteBuffer byteBuffer) {
            return (PlayoutDelay) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<PlayoutDelay> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setEnabled(boolean z) {
            this.enabled_ = z;
        }

        private void setMax(int i) {
            this.max_ = i;
        }

        private void setMin(int i) {
            this.min_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new PlayoutDelay();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u0007\u0002\u000b\u0003\u000b", new Object[]{ap.a(1541252947), ap.a(40528409), ap.a(546053027)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<PlayoutDelay> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (PlayoutDelay.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getEnabled() {
            return this.enabled_;
        }

        public int getMax() {
            return this.max_;
        }

        public int getMin() {
            return this.min_;
        }

        public static Builder newBuilder(PlayoutDelay playoutDelay) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(playoutDelay);
        }

        public static PlayoutDelay parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PlayoutDelay) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PlayoutDelay parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (PlayoutDelay) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static PlayoutDelay parseFrom(ByteString byteString) {
            return (PlayoutDelay) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static PlayoutDelay parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (PlayoutDelay) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static PlayoutDelay parseFrom(byte[] bArr) {
            return (PlayoutDelay) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static PlayoutDelay parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (PlayoutDelay) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static PlayoutDelay parseFrom(InputStream inputStream) {
            return (PlayoutDelay) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PlayoutDelay parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PlayoutDelay) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PlayoutDelay parseFrom(CodedInputStream codedInputStream) {
            return (PlayoutDelay) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static PlayoutDelay parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PlayoutDelay) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface PlayoutDelayOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RTCPSenderReportState extends GeneratedMessageLite<RTCPSenderReportState, Builder> implements RTCPSenderReportStateOrBuilder {
        public static final int AT_ADJUSTED_FIELD_NUMBER = 5;
        public static final int AT_FIELD_NUMBER = 4;
        private static final RTCPSenderReportState DEFAULT_INSTANCE;
        public static final int NTP_TIMESTAMP_FIELD_NUMBER = 3;
        public static final int OCTETS_FIELD_NUMBER = 7;
        public static final int PACKETS_FIELD_NUMBER = 6;
        private static volatile Parser<RTCPSenderReportState> PARSER = null;
        public static final int RTP_TIMESTAMP_EXT_FIELD_NUMBER = 2;
        public static final int RTP_TIMESTAMP_FIELD_NUMBER = 1;
        private long atAdjusted_;
        private long at_;
        private long ntpTimestamp_;
        private long octets_;
        private int packets_;
        private long rtpTimestampExt_;
        private int rtpTimestamp_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RTCPSenderReportState, Builder> implements RTCPSenderReportStateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RTCPSenderReportState.DEFAULT_INSTANCE);
            }
        }

        static {
            RTCPSenderReportState rTCPSenderReportState = new RTCPSenderReportState();
            DEFAULT_INSTANCE = rTCPSenderReportState;
            GeneratedMessageLite.registerDefaultInstance(RTCPSenderReportState.class, rTCPSenderReportState);
        }

        private RTCPSenderReportState() {
        }

        private void clearAt() {
            this.at_ = 0L;
        }

        private void clearAtAdjusted() {
            this.atAdjusted_ = 0L;
        }

        private void clearNtpTimestamp() {
            this.ntpTimestamp_ = 0L;
        }

        private void clearOctets() {
            this.octets_ = 0L;
        }

        private void clearPackets() {
            this.packets_ = 0;
        }

        private void clearRtpTimestamp() {
            this.rtpTimestamp_ = 0;
        }

        private void clearRtpTimestampExt() {
            this.rtpTimestampExt_ = 0L;
        }

        public static RTCPSenderReportState getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RTCPSenderReportState parseDelimitedFrom(InputStream inputStream) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RTCPSenderReportState parseFrom(ByteBuffer byteBuffer) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RTCPSenderReportState> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAt(long j) {
            this.at_ = j;
        }

        private void setAtAdjusted(long j) {
            this.atAdjusted_ = j;
        }

        private void setNtpTimestamp(long j) {
            this.ntpTimestamp_ = j;
        }

        private void setOctets(long j) {
            this.octets_ = j;
        }

        private void setPackets(int i) {
            this.packets_ = i;
        }

        private void setRtpTimestamp(int i) {
            this.rtpTimestamp_ = i;
        }

        private void setRtpTimestampExt(long j) {
            this.rtpTimestampExt_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RTCPSenderReportState();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0000\u0000\u0001\u0007\u0007\u0000\u0000\u0000\u0001\u000b\u0002\u0003\u0003\u0003\u0004\u0002\u0005\u0002\u0006\u000b\u0007\u0003", new Object[]{ap.a(353489458), ap.a(1351225956), ap.a(349935090), ap.a(1734739492), ap.a(1020164858), ap.a(1882340101), ap.a(1519693696)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RTCPSenderReportState> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RTCPSenderReportState.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getAt() {
            return this.at_;
        }

        public long getAtAdjusted() {
            return this.atAdjusted_;
        }

        public long getNtpTimestamp() {
            return this.ntpTimestamp_;
        }

        public long getOctets() {
            return this.octets_;
        }

        public int getPackets() {
            return this.packets_;
        }

        public int getRtpTimestamp() {
            return this.rtpTimestamp_;
        }

        public long getRtpTimestampExt() {
            return this.rtpTimestampExt_;
        }

        public static Builder newBuilder(RTCPSenderReportState rTCPSenderReportState) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(rTCPSenderReportState);
        }

        public static RTCPSenderReportState parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RTCPSenderReportState parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RTCPSenderReportState parseFrom(ByteString byteString) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RTCPSenderReportState parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RTCPSenderReportState parseFrom(byte[] bArr) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RTCPSenderReportState parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RTCPSenderReportState parseFrom(InputStream inputStream) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RTCPSenderReportState parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RTCPSenderReportState parseFrom(CodedInputStream codedInputStream) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RTCPSenderReportState parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTCPSenderReportState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RTCPSenderReportStateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RTPDrift extends GeneratedMessageLite<RTPDrift, Builder> implements RTPDriftOrBuilder {
        public static final int CLOCK_RATE_FIELD_NUMBER = 9;
        private static final RTPDrift DEFAULT_INSTANCE;
        public static final int DRIFT_MS_FIELD_NUMBER = 8;
        public static final int DRIFT_SAMPLES_FIELD_NUMBER = 7;
        public static final int DURATION_FIELD_NUMBER = 3;
        public static final int END_TIMESTAMP_FIELD_NUMBER = 5;
        public static final int END_TIME_FIELD_NUMBER = 2;
        private static volatile Parser<RTPDrift> PARSER = null;
        public static final int RTP_CLOCK_TICKS_FIELD_NUMBER = 6;
        public static final int START_TIMESTAMP_FIELD_NUMBER = 4;
        public static final int START_TIME_FIELD_NUMBER = 1;
        private double clockRate_;
        private double driftMs_;
        private long driftSamples_;
        private double duration_;
        private Timestamp endTime_;
        private long endTimestamp_;
        private long rtpClockTicks_;
        private Timestamp startTime_;
        private long startTimestamp_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RTPDrift, Builder> implements RTPDriftOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RTPDrift.DEFAULT_INSTANCE);
            }
        }

        static {
            RTPDrift rTPDrift = new RTPDrift();
            DEFAULT_INSTANCE = rTPDrift;
            GeneratedMessageLite.registerDefaultInstance(RTPDrift.class, rTPDrift);
        }

        private RTPDrift() {
        }

        private void clearClockRate() {
            this.clockRate_ = 0.0d;
        }

        private void clearDriftMs() {
            this.driftMs_ = 0.0d;
        }

        private void clearDriftSamples() {
            this.driftSamples_ = 0L;
        }

        private void clearDuration() {
            this.duration_ = 0.0d;
        }

        private void clearEndTime() {
            this.endTime_ = null;
        }

        private void clearEndTimestamp() {
            this.endTimestamp_ = 0L;
        }

        private void clearRtpClockTicks() {
            this.rtpClockTicks_ = 0L;
        }

        private void clearStartTime() {
            this.startTime_ = null;
        }

        private void clearStartTimestamp() {
            this.startTimestamp_ = 0L;
        }

        public static RTPDrift getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeEndTime(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.endTime_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.endTime_ = timestamp;
            } else {
                this.endTime_ = Timestamp.newBuilder(this.endTime_).v(timestamp).o();
            }
        }

        private void mergeStartTime(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.startTime_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.startTime_ = timestamp;
            } else {
                this.startTime_ = Timestamp.newBuilder(this.startTime_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RTPDrift parseDelimitedFrom(InputStream inputStream) {
            return (RTPDrift) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RTPDrift parseFrom(ByteBuffer byteBuffer) {
            return (RTPDrift) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RTPDrift> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setClockRate(double d) {
            this.clockRate_ = d;
        }

        private void setDriftMs(double d) {
            this.driftMs_ = d;
        }

        private void setDriftSamples(long j) {
            this.driftSamples_ = j;
        }

        private void setDuration(double d) {
            this.duration_ = d;
        }

        private void setEndTime(Timestamp timestamp) {
            timestamp.getClass();
            this.endTime_ = timestamp;
        }

        private void setEndTimestamp(long j) {
            this.endTimestamp_ = j;
        }

        private void setRtpClockTicks(long j) {
            this.rtpClockTicks_ = j;
        }

        private void setStartTime(Timestamp timestamp) {
            timestamp.getClass();
            this.startTime_ = timestamp;
        }

        private void setStartTimestamp(long j) {
            this.startTimestamp_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RTPDrift();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\t\u0000\u0000\u0001\t\t\u0000\u0000\u0000\u0001\t\u0002\t\u0003\u0000\u0004\u0003\u0005\u0003\u0006\u0003\u0007\u0002\b\u0000\t\u0000", new Object[]{ap.a(867806981), ap.a(1630633997), ap.a(1359017399), ap.a(1360106839), ap.a(1056299574), ap.a(867145713), ap.a(1596108626), ap.a(175000084), ap.a(650492777)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RTPDrift> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RTPDrift.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public double getClockRate() {
            return this.clockRate_;
        }

        public double getDriftMs() {
            return this.driftMs_;
        }

        public long getDriftSamples() {
            return this.driftSamples_;
        }

        public double getDuration() {
            return this.duration_;
        }

        public Timestamp getEndTime() {
            Timestamp timestamp = this.endTime_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public long getEndTimestamp() {
            return this.endTimestamp_;
        }

        public long getRtpClockTicks() {
            return this.rtpClockTicks_;
        }

        public Timestamp getStartTime() {
            Timestamp timestamp = this.startTime_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public long getStartTimestamp() {
            return this.startTimestamp_;
        }

        public boolean hasEndTime() {
            return this.endTime_ != null;
        }

        public boolean hasStartTime() {
            return this.startTime_ != null;
        }

        public static Builder newBuilder(RTPDrift rTPDrift) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(rTPDrift);
        }

        public static RTPDrift parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPDrift) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RTPDrift parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPDrift) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RTPDrift parseFrom(ByteString byteString) {
            return (RTPDrift) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RTPDrift parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPDrift) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RTPDrift parseFrom(byte[] bArr) {
            return (RTPDrift) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RTPDrift parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPDrift) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RTPDrift parseFrom(InputStream inputStream) {
            return (RTPDrift) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RTPDrift parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPDrift) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RTPDrift parseFrom(CodedInputStream codedInputStream) {
            return (RTPDrift) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RTPDrift parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPDrift) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RTPDriftOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RTPForwarderState extends GeneratedMessageLite<RTPForwarderState, Builder> implements RTPForwarderStateOrBuilder {
        private static final RTPForwarderState DEFAULT_INSTANCE;
        public static final int DUMMY_START_TIMESTAMP_OFFSET_FIELD_NUMBER = 5;
        public static final int EXT_FIRST_TIMESTAMP_FIELD_NUMBER = 4;
        private static volatile Parser<RTPForwarderState> PARSER = null;
        public static final int PRE_START_TIME_FIELD_NUMBER = 3;
        public static final int REFERENCE_LAYER_SPATIAL_FIELD_NUMBER = 2;
        public static final int RTP_MUNGER_FIELD_NUMBER = 6;
        public static final int SENDER_REPORT_STATE_FIELD_NUMBER = 8;
        public static final int STARTED_FIELD_NUMBER = 1;
        public static final int VP8_MUNGER_FIELD_NUMBER = 7;
        private Object codecMunger_;
        private long dummyStartTimestampOffset_;
        private long extFirstTimestamp_;
        private long preStartTime_;
        private int referenceLayerSpatial_;
        private RTPMungerState rtpMunger_;
        private boolean started_;
        private int codecMungerCase_ = 0;
        private Internal.ProtobufList<RTCPSenderReportState> senderReportState_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RTPForwarderState, Builder> implements RTPForwarderStateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RTPForwarderState.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum CodecMungerCase {
            b(7),
            c(0);

            private final int a;

            CodecMungerCase(int i) {
                this.a = i;
            }

            public static CodecMungerCase b(int i) {
                if (i == 0) {
                    return c;
                }
                if (i != 7) {
                    return null;
                }
                return b;
            }
        }

        static {
            RTPForwarderState rTPForwarderState = new RTPForwarderState();
            DEFAULT_INSTANCE = rTPForwarderState;
            GeneratedMessageLite.registerDefaultInstance(RTPForwarderState.class, rTPForwarderState);
        }

        private RTPForwarderState() {
        }

        private void addAllSenderReportState(Iterable<? extends RTCPSenderReportState> iterable) {
            ensureSenderReportStateIsMutable();
            AbstractMessageLite.addAll(iterable, this.senderReportState_);
        }

        private void addSenderReportState(RTCPSenderReportState rTCPSenderReportState) {
            rTCPSenderReportState.getClass();
            ensureSenderReportStateIsMutable();
            this.senderReportState_.add(rTCPSenderReportState);
        }

        private void clearCodecMunger() {
            this.codecMungerCase_ = 0;
            this.codecMunger_ = null;
        }

        private void clearDummyStartTimestampOffset() {
            this.dummyStartTimestampOffset_ = 0L;
        }

        private void clearExtFirstTimestamp() {
            this.extFirstTimestamp_ = 0L;
        }

        private void clearPreStartTime() {
            this.preStartTime_ = 0L;
        }

        private void clearReferenceLayerSpatial() {
            this.referenceLayerSpatial_ = 0;
        }

        private void clearRtpMunger() {
            this.rtpMunger_ = null;
        }

        private void clearSenderReportState() {
            this.senderReportState_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearStarted() {
            this.started_ = false;
        }

        private void clearVp8Munger() {
            if (this.codecMungerCase_ == 7) {
                this.codecMungerCase_ = 0;
                this.codecMunger_ = null;
            }
        }

        private void ensureSenderReportStateIsMutable() {
            Internal.ProtobufList<RTCPSenderReportState> protobufList = this.senderReportState_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.senderReportState_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static RTPForwarderState getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeRtpMunger(RTPMungerState rTPMungerState) {
            rTPMungerState.getClass();
            RTPMungerState rTPMungerState2 = this.rtpMunger_;
            if (rTPMungerState2 == null || rTPMungerState2 == RTPMungerState.getDefaultInstance()) {
                this.rtpMunger_ = rTPMungerState;
            } else {
                this.rtpMunger_ = (RTPMungerState) ((RTPMungerState.Builder) RTPMungerState.newBuilder(this.rtpMunger_).v(rTPMungerState)).o();
            }
        }

        private void mergeVp8Munger(VP8MungerState vP8MungerState) {
            vP8MungerState.getClass();
            if (this.codecMungerCase_ != 7 || this.codecMunger_ == VP8MungerState.getDefaultInstance()) {
                this.codecMunger_ = vP8MungerState;
            } else {
                this.codecMunger_ = ((VP8MungerState.Builder) VP8MungerState.newBuilder((VP8MungerState) this.codecMunger_).v(vP8MungerState)).o();
            }
            this.codecMungerCase_ = 7;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RTPForwarderState parseDelimitedFrom(InputStream inputStream) {
            return (RTPForwarderState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RTPForwarderState parseFrom(ByteBuffer byteBuffer) {
            return (RTPForwarderState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RTPForwarderState> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSenderReportState(int i) {
            ensureSenderReportStateIsMutable();
            this.senderReportState_.remove(i);
        }

        private void setDummyStartTimestampOffset(long j) {
            this.dummyStartTimestampOffset_ = j;
        }

        private void setExtFirstTimestamp(long j) {
            this.extFirstTimestamp_ = j;
        }

        private void setPreStartTime(long j) {
            this.preStartTime_ = j;
        }

        private void setReferenceLayerSpatial(int i) {
            this.referenceLayerSpatial_ = i;
        }

        private void setRtpMunger(RTPMungerState rTPMungerState) {
            rTPMungerState.getClass();
            this.rtpMunger_ = rTPMungerState;
        }

        private void setSenderReportState(int i, RTCPSenderReportState rTCPSenderReportState) {
            rTCPSenderReportState.getClass();
            ensureSenderReportStateIsMutable();
            this.senderReportState_.set(i, rTCPSenderReportState);
        }

        private void setStarted(boolean z) {
            this.started_ = z;
        }

        private void setVp8Munger(VP8MungerState vP8MungerState) {
            vP8MungerState.getClass();
            this.codecMunger_ = vP8MungerState;
            this.codecMungerCase_ = 7;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RTPForwarderState();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\b\u0001\u0000\u0001\b\b\u0000\u0001\u0000\u0001\u0007\u0002\u0004\u0003\u0002\u0004\u0003\u0005\u0003\u0006\t\u0007<\u0000\b\u001b", new Object[]{ap.a(136534065), ap.a(326822537), ap.a(888150996), ap.a(782215523), ap.a(658844376), ap.a(1267643808), ap.a(1770202979), ap.a(720846255), VP8MungerState.class, ap.a(2097903193), RTCPSenderReportState.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RTPForwarderState> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RTPForwarderState.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public CodecMungerCase getCodecMungerCase() {
            return CodecMungerCase.b(this.codecMungerCase_);
        }

        public long getDummyStartTimestampOffset() {
            return this.dummyStartTimestampOffset_;
        }

        public long getExtFirstTimestamp() {
            return this.extFirstTimestamp_;
        }

        public long getPreStartTime() {
            return this.preStartTime_;
        }

        public int getReferenceLayerSpatial() {
            return this.referenceLayerSpatial_;
        }

        public RTPMungerState getRtpMunger() {
            RTPMungerState rTPMungerState = this.rtpMunger_;
            return rTPMungerState == null ? RTPMungerState.getDefaultInstance() : rTPMungerState;
        }

        public RTCPSenderReportState getSenderReportState(int i) {
            return (RTCPSenderReportState) this.senderReportState_.get(i);
        }

        public int getSenderReportStateCount() {
            return this.senderReportState_.size();
        }

        public List<RTCPSenderReportState> getSenderReportStateList() {
            return this.senderReportState_;
        }

        public RTCPSenderReportStateOrBuilder getSenderReportStateOrBuilder(int i) {
            return (RTCPSenderReportStateOrBuilder) this.senderReportState_.get(i);
        }

        public List<? extends RTCPSenderReportStateOrBuilder> getSenderReportStateOrBuilderList() {
            return this.senderReportState_;
        }

        public boolean getStarted() {
            return this.started_;
        }

        public VP8MungerState getVp8Munger() {
            return this.codecMungerCase_ == 7 ? (VP8MungerState) this.codecMunger_ : VP8MungerState.getDefaultInstance();
        }

        public boolean hasRtpMunger() {
            return this.rtpMunger_ != null;
        }

        public boolean hasVp8Munger() {
            return this.codecMungerCase_ == 7;
        }

        public static Builder newBuilder(RTPForwarderState rTPForwarderState) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(rTPForwarderState);
        }

        public static RTPForwarderState parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPForwarderState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RTPForwarderState parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPForwarderState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RTPForwarderState parseFrom(ByteString byteString) {
            return (RTPForwarderState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSenderReportState(int i, RTCPSenderReportState rTCPSenderReportState) {
            rTCPSenderReportState.getClass();
            ensureSenderReportStateIsMutable();
            this.senderReportState_.add(i, rTCPSenderReportState);
        }

        public static RTPForwarderState parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPForwarderState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RTPForwarderState parseFrom(byte[] bArr) {
            return (RTPForwarderState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RTPForwarderState parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPForwarderState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RTPForwarderState parseFrom(InputStream inputStream) {
            return (RTPForwarderState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RTPForwarderState parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPForwarderState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RTPForwarderState parseFrom(CodedInputStream codedInputStream) {
            return (RTPForwarderState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RTPForwarderState parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPForwarderState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RTPForwarderStateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RTPMungerState extends GeneratedMessageLite<RTPMungerState, Builder> implements RTPMungerStateOrBuilder {
        private static final RTPMungerState DEFAULT_INSTANCE;
        public static final int EXT_LAST_SEQUENCE_NUMBER_FIELD_NUMBER = 1;
        public static final int EXT_LAST_TIMESTAMP_FIELD_NUMBER = 3;
        public static final int EXT_SECOND_LAST_SEQUENCE_NUMBER_FIELD_NUMBER = 2;
        public static final int EXT_SECOND_LAST_TIMESTAMP_FIELD_NUMBER = 4;
        public static final int LAST_MARKER_FIELD_NUMBER = 5;
        private static volatile Parser<RTPMungerState> PARSER = null;
        public static final int SECOND_LAST_MARKER_FIELD_NUMBER = 6;
        private long extLastSequenceNumber_;
        private long extLastTimestamp_;
        private long extSecondLastSequenceNumber_;
        private long extSecondLastTimestamp_;
        private boolean lastMarker_;
        private boolean secondLastMarker_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RTPMungerState, Builder> implements RTPMungerStateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RTPMungerState.DEFAULT_INSTANCE);
            }
        }

        static {
            RTPMungerState rTPMungerState = new RTPMungerState();
            DEFAULT_INSTANCE = rTPMungerState;
            GeneratedMessageLite.registerDefaultInstance(RTPMungerState.class, rTPMungerState);
        }

        private RTPMungerState() {
        }

        private void clearExtLastSequenceNumber() {
            this.extLastSequenceNumber_ = 0L;
        }

        private void clearExtLastTimestamp() {
            this.extLastTimestamp_ = 0L;
        }

        private void clearExtSecondLastSequenceNumber() {
            this.extSecondLastSequenceNumber_ = 0L;
        }

        private void clearExtSecondLastTimestamp() {
            this.extSecondLastTimestamp_ = 0L;
        }

        private void clearLastMarker() {
            this.lastMarker_ = false;
        }

        private void clearSecondLastMarker() {
            this.secondLastMarker_ = false;
        }

        public static RTPMungerState getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RTPMungerState parseDelimitedFrom(InputStream inputStream) {
            return (RTPMungerState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RTPMungerState parseFrom(ByteBuffer byteBuffer) {
            return (RTPMungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RTPMungerState> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setExtLastSequenceNumber(long j) {
            this.extLastSequenceNumber_ = j;
        }

        private void setExtLastTimestamp(long j) {
            this.extLastTimestamp_ = j;
        }

        private void setExtSecondLastSequenceNumber(long j) {
            this.extSecondLastSequenceNumber_ = j;
        }

        private void setExtSecondLastTimestamp(long j) {
            this.extSecondLastTimestamp_ = j;
        }

        private void setLastMarker(boolean z) {
            this.lastMarker_ = z;
        }

        private void setSecondLastMarker(boolean z) {
            this.secondLastMarker_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RTPMungerState();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001\u0003\u0002\u0003\u0003\u0003\u0004\u0003\u0005\u0007\u0006\u0007", new Object[]{ap.a(173087473), ap.a(729612254), ap.a(1723405166), ap.a(187810974), ap.a(327193021), ap.a(1123266468)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RTPMungerState> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RTPMungerState.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getExtLastSequenceNumber() {
            return this.extLastSequenceNumber_;
        }

        public long getExtLastTimestamp() {
            return this.extLastTimestamp_;
        }

        public long getExtSecondLastSequenceNumber() {
            return this.extSecondLastSequenceNumber_;
        }

        public long getExtSecondLastTimestamp() {
            return this.extSecondLastTimestamp_;
        }

        public boolean getLastMarker() {
            return this.lastMarker_;
        }

        public boolean getSecondLastMarker() {
            return this.secondLastMarker_;
        }

        public static Builder newBuilder(RTPMungerState rTPMungerState) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(rTPMungerState);
        }

        public static RTPMungerState parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPMungerState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RTPMungerState parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPMungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RTPMungerState parseFrom(ByteString byteString) {
            return (RTPMungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RTPMungerState parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPMungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RTPMungerState parseFrom(byte[] bArr) {
            return (RTPMungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RTPMungerState parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPMungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RTPMungerState parseFrom(InputStream inputStream) {
            return (RTPMungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RTPMungerState parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPMungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RTPMungerState parseFrom(CodedInputStream codedInputStream) {
            return (RTPMungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RTPMungerState parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPMungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RTPMungerStateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RTPStats extends GeneratedMessageLite<RTPStats, Builder> implements RTPStatsOrBuilder {
        public static final int BITRATE_DUPLICATE_FIELD_NUMBER = 14;
        public static final int BITRATE_FIELD_NUMBER = 7;
        public static final int BITRATE_PADDING_FIELD_NUMBER = 18;
        public static final int BYTES_DUPLICATE_FIELD_NUMBER = 13;
        public static final int BYTES_FIELD_NUMBER = 6;
        public static final int BYTES_PADDING_FIELD_NUMBER = 17;
        private static final RTPStats DEFAULT_INSTANCE;
        public static final int DURATION_FIELD_NUMBER = 3;
        public static final int END_TIME_FIELD_NUMBER = 2;
        public static final int FIRS_FIELD_NUMBER = 29;
        public static final int FRAMES_FIELD_NUMBER = 20;
        public static final int FRAME_RATE_FIELD_NUMBER = 21;
        public static final int GAP_HISTOGRAM_FIELD_NUMBER = 24;
        public static final int HEADER_BYTES_DUPLICATE_FIELD_NUMBER = 40;
        public static final int HEADER_BYTES_FIELD_NUMBER = 39;
        public static final int HEADER_BYTES_PADDING_FIELD_NUMBER = 41;
        public static final int JITTER_CURRENT_FIELD_NUMBER = 22;
        public static final int JITTER_MAX_FIELD_NUMBER = 23;
        public static final int KEY_FRAMES_FIELD_NUMBER = 33;
        public static final int LAST_FIR_FIELD_NUMBER = 30;
        public static final int LAST_KEY_FRAME_FIELD_NUMBER = 34;
        public static final int LAST_LAYER_LOCK_PLI_FIELD_NUMBER = 36;
        public static final int LAST_PLI_FIELD_NUMBER = 28;
        public static final int LAYER_LOCK_PLIS_FIELD_NUMBER = 35;
        public static final int NACKS_FIELD_NUMBER = 25;
        public static final int NACK_ACKS_FIELD_NUMBER = 37;
        public static final int NACK_MISSES_FIELD_NUMBER = 26;
        public static final int NACK_REPEATED_FIELD_NUMBER = 38;
        public static final int NTP_REPORT_DRIFT_FIELD_NUMBER = 45;
        public static final int PACKETS_DUPLICATE_FIELD_NUMBER = 11;
        public static final int PACKETS_FIELD_NUMBER = 4;
        public static final int PACKETS_LOST_FIELD_NUMBER = 8;
        public static final int PACKETS_OUT_OF_ORDER_FIELD_NUMBER = 19;
        public static final int PACKETS_PADDING_FIELD_NUMBER = 15;
        public static final int PACKET_DRIFT_FIELD_NUMBER = 44;
        public static final int PACKET_DUPLICATE_RATE_FIELD_NUMBER = 12;
        public static final int PACKET_LOSS_PERCENTAGE_FIELD_NUMBER = 10;
        public static final int PACKET_LOSS_RATE_FIELD_NUMBER = 9;
        public static final int PACKET_PADDING_RATE_FIELD_NUMBER = 16;
        public static final int PACKET_RATE_FIELD_NUMBER = 5;
        private static volatile Parser<RTPStats> PARSER = null;
        public static final int PLIS_FIELD_NUMBER = 27;
        public static final int REBASED_REPORT_DRIFT_FIELD_NUMBER = 46;
        public static final int RECEIVED_REPORT_DRIFT_FIELD_NUMBER = 47;
        public static final int RTT_CURRENT_FIELD_NUMBER = 31;
        public static final int RTT_MAX_FIELD_NUMBER = 32;
        public static final int START_TIME_FIELD_NUMBER = 1;
        private double bitrateDuplicate_;
        private double bitratePadding_;
        private double bitrate_;
        private long bytesDuplicate_;
        private long bytesPadding_;
        private long bytes_;
        private double duration_;
        private Timestamp endTime_;
        private int firs_;
        private double frameRate_;
        private int frames_;
        private MapFieldLite<Integer, Integer> gapHistogram_ = MapFieldLite.f();
        private long headerBytesDuplicate_;
        private long headerBytesPadding_;
        private long headerBytes_;
        private double jitterCurrent_;
        private double jitterMax_;
        private int keyFrames_;
        private Timestamp lastFir_;
        private Timestamp lastKeyFrame_;
        private Timestamp lastLayerLockPli_;
        private Timestamp lastPli_;
        private int layerLockPlis_;
        private int nackAcks_;
        private int nackMisses_;
        private int nackRepeated_;
        private int nacks_;
        private RTPDrift ntpReportDrift_;
        private RTPDrift packetDrift_;
        private double packetDuplicateRate_;
        private float packetLossPercentage_;
        private double packetLossRate_;
        private double packetPaddingRate_;
        private double packetRate_;
        private int packetsDuplicate_;
        private int packetsLost_;
        private int packetsOutOfOrder_;
        private int packetsPadding_;
        private int packets_;
        private int plis_;
        private RTPDrift rebasedReportDrift_;
        private RTPDrift receivedReportDrift_;
        private int rttCurrent_;
        private int rttMax_;
        private Timestamp startTime_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RTPStats, Builder> implements RTPStatsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RTPStats.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class GapHistogramDefaultEntryHolder {
            static final MapEntryLite a = MapEntryLite.d(WireFormat.FieldType.g, 0, WireFormat.FieldType.o, 0);

            private GapHistogramDefaultEntryHolder() {
            }
        }

        static {
            RTPStats rTPStats = new RTPStats();
            DEFAULT_INSTANCE = rTPStats;
            GeneratedMessageLite.registerDefaultInstance(RTPStats.class, rTPStats);
        }

        private RTPStats() {
        }

        private void clearBitrate() {
            this.bitrate_ = 0.0d;
        }

        private void clearBitrateDuplicate() {
            this.bitrateDuplicate_ = 0.0d;
        }

        private void clearBitratePadding() {
            this.bitratePadding_ = 0.0d;
        }

        private void clearBytes() {
            this.bytes_ = 0L;
        }

        private void clearBytesDuplicate() {
            this.bytesDuplicate_ = 0L;
        }

        private void clearBytesPadding() {
            this.bytesPadding_ = 0L;
        }

        private void clearDuration() {
            this.duration_ = 0.0d;
        }

        private void clearEndTime() {
            this.endTime_ = null;
        }

        private void clearFirs() {
            this.firs_ = 0;
        }

        private void clearFrameRate() {
            this.frameRate_ = 0.0d;
        }

        private void clearFrames() {
            this.frames_ = 0;
        }

        private void clearHeaderBytes() {
            this.headerBytes_ = 0L;
        }

        private void clearHeaderBytesDuplicate() {
            this.headerBytesDuplicate_ = 0L;
        }

        private void clearHeaderBytesPadding() {
            this.headerBytesPadding_ = 0L;
        }

        private void clearJitterCurrent() {
            this.jitterCurrent_ = 0.0d;
        }

        private void clearJitterMax() {
            this.jitterMax_ = 0.0d;
        }

        private void clearKeyFrames() {
            this.keyFrames_ = 0;
        }

        private void clearLastFir() {
            this.lastFir_ = null;
        }

        private void clearLastKeyFrame() {
            this.lastKeyFrame_ = null;
        }

        private void clearLastLayerLockPli() {
            this.lastLayerLockPli_ = null;
        }

        private void clearLastPli() {
            this.lastPli_ = null;
        }

        private void clearLayerLockPlis() {
            this.layerLockPlis_ = 0;
        }

        private void clearNackAcks() {
            this.nackAcks_ = 0;
        }

        private void clearNackMisses() {
            this.nackMisses_ = 0;
        }

        private void clearNackRepeated() {
            this.nackRepeated_ = 0;
        }

        private void clearNacks() {
            this.nacks_ = 0;
        }

        private void clearNtpReportDrift() {
            this.ntpReportDrift_ = null;
        }

        private void clearPacketDrift() {
            this.packetDrift_ = null;
        }

        private void clearPacketDuplicateRate() {
            this.packetDuplicateRate_ = 0.0d;
        }

        private void clearPacketLossPercentage() {
            this.packetLossPercentage_ = 0.0f;
        }

        private void clearPacketLossRate() {
            this.packetLossRate_ = 0.0d;
        }

        private void clearPacketPaddingRate() {
            this.packetPaddingRate_ = 0.0d;
        }

        private void clearPacketRate() {
            this.packetRate_ = 0.0d;
        }

        private void clearPackets() {
            this.packets_ = 0;
        }

        private void clearPacketsDuplicate() {
            this.packetsDuplicate_ = 0;
        }

        private void clearPacketsLost() {
            this.packetsLost_ = 0;
        }

        private void clearPacketsOutOfOrder() {
            this.packetsOutOfOrder_ = 0;
        }

        private void clearPacketsPadding() {
            this.packetsPadding_ = 0;
        }

        private void clearPlis() {
            this.plis_ = 0;
        }

        private void clearRebasedReportDrift() {
            this.rebasedReportDrift_ = null;
        }

        private void clearReceivedReportDrift() {
            this.receivedReportDrift_ = null;
        }

        private void clearRttCurrent() {
            this.rttCurrent_ = 0;
        }

        private void clearRttMax() {
            this.rttMax_ = 0;
        }

        private void clearStartTime() {
            this.startTime_ = null;
        }

        public static RTPStats getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<Integer, Integer> getMutableGapHistogramMap() {
            return internalGetMutableGapHistogram();
        }

        private MapFieldLite<Integer, Integer> internalGetGapHistogram() {
            return this.gapHistogram_;
        }

        private MapFieldLite<Integer, Integer> internalGetMutableGapHistogram() {
            if (!this.gapHistogram_.k()) {
                this.gapHistogram_ = this.gapHistogram_.n();
            }
            return this.gapHistogram_;
        }

        private void mergeEndTime(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.endTime_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.endTime_ = timestamp;
            } else {
                this.endTime_ = Timestamp.newBuilder(this.endTime_).v(timestamp).o();
            }
        }

        private void mergeLastFir(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.lastFir_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.lastFir_ = timestamp;
            } else {
                this.lastFir_ = Timestamp.newBuilder(this.lastFir_).v(timestamp).o();
            }
        }

        private void mergeLastKeyFrame(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.lastKeyFrame_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.lastKeyFrame_ = timestamp;
            } else {
                this.lastKeyFrame_ = Timestamp.newBuilder(this.lastKeyFrame_).v(timestamp).o();
            }
        }

        private void mergeLastLayerLockPli(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.lastLayerLockPli_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.lastLayerLockPli_ = timestamp;
            } else {
                this.lastLayerLockPli_ = Timestamp.newBuilder(this.lastLayerLockPli_).v(timestamp).o();
            }
        }

        private void mergeLastPli(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.lastPli_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.lastPli_ = timestamp;
            } else {
                this.lastPli_ = Timestamp.newBuilder(this.lastPli_).v(timestamp).o();
            }
        }

        private void mergeNtpReportDrift(RTPDrift rTPDrift) {
            rTPDrift.getClass();
            RTPDrift rTPDrift2 = this.ntpReportDrift_;
            if (rTPDrift2 == null || rTPDrift2 == RTPDrift.getDefaultInstance()) {
                this.ntpReportDrift_ = rTPDrift;
            } else {
                this.ntpReportDrift_ = (RTPDrift) ((RTPDrift.Builder) RTPDrift.newBuilder(this.ntpReportDrift_).v(rTPDrift)).o();
            }
        }

        private void mergePacketDrift(RTPDrift rTPDrift) {
            rTPDrift.getClass();
            RTPDrift rTPDrift2 = this.packetDrift_;
            if (rTPDrift2 == null || rTPDrift2 == RTPDrift.getDefaultInstance()) {
                this.packetDrift_ = rTPDrift;
            } else {
                this.packetDrift_ = (RTPDrift) ((RTPDrift.Builder) RTPDrift.newBuilder(this.packetDrift_).v(rTPDrift)).o();
            }
        }

        private void mergeRebasedReportDrift(RTPDrift rTPDrift) {
            rTPDrift.getClass();
            RTPDrift rTPDrift2 = this.rebasedReportDrift_;
            if (rTPDrift2 == null || rTPDrift2 == RTPDrift.getDefaultInstance()) {
                this.rebasedReportDrift_ = rTPDrift;
            } else {
                this.rebasedReportDrift_ = (RTPDrift) ((RTPDrift.Builder) RTPDrift.newBuilder(this.rebasedReportDrift_).v(rTPDrift)).o();
            }
        }

        private void mergeReceivedReportDrift(RTPDrift rTPDrift) {
            rTPDrift.getClass();
            RTPDrift rTPDrift2 = this.receivedReportDrift_;
            if (rTPDrift2 == null || rTPDrift2 == RTPDrift.getDefaultInstance()) {
                this.receivedReportDrift_ = rTPDrift;
            } else {
                this.receivedReportDrift_ = (RTPDrift) ((RTPDrift.Builder) RTPDrift.newBuilder(this.receivedReportDrift_).v(rTPDrift)).o();
            }
        }

        private void mergeStartTime(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.startTime_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.startTime_ = timestamp;
            } else {
                this.startTime_ = Timestamp.newBuilder(this.startTime_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RTPStats parseDelimitedFrom(InputStream inputStream) {
            return (RTPStats) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RTPStats parseFrom(ByteBuffer byteBuffer) {
            return (RTPStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RTPStats> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setBitrate(double d) {
            this.bitrate_ = d;
        }

        private void setBitrateDuplicate(double d) {
            this.bitrateDuplicate_ = d;
        }

        private void setBitratePadding(double d) {
            this.bitratePadding_ = d;
        }

        private void setBytes(long j) {
            this.bytes_ = j;
        }

        private void setBytesDuplicate(long j) {
            this.bytesDuplicate_ = j;
        }

        private void setBytesPadding(long j) {
            this.bytesPadding_ = j;
        }

        private void setDuration(double d) {
            this.duration_ = d;
        }

        private void setEndTime(Timestamp timestamp) {
            timestamp.getClass();
            this.endTime_ = timestamp;
        }

        private void setFirs(int i) {
            this.firs_ = i;
        }

        private void setFrameRate(double d) {
            this.frameRate_ = d;
        }

        private void setFrames(int i) {
            this.frames_ = i;
        }

        private void setHeaderBytes(long j) {
            this.headerBytes_ = j;
        }

        private void setHeaderBytesDuplicate(long j) {
            this.headerBytesDuplicate_ = j;
        }

        private void setHeaderBytesPadding(long j) {
            this.headerBytesPadding_ = j;
        }

        private void setJitterCurrent(double d) {
            this.jitterCurrent_ = d;
        }

        private void setJitterMax(double d) {
            this.jitterMax_ = d;
        }

        private void setKeyFrames(int i) {
            this.keyFrames_ = i;
        }

        private void setLastFir(Timestamp timestamp) {
            timestamp.getClass();
            this.lastFir_ = timestamp;
        }

        private void setLastKeyFrame(Timestamp timestamp) {
            timestamp.getClass();
            this.lastKeyFrame_ = timestamp;
        }

        private void setLastLayerLockPli(Timestamp timestamp) {
            timestamp.getClass();
            this.lastLayerLockPli_ = timestamp;
        }

        private void setLastPli(Timestamp timestamp) {
            timestamp.getClass();
            this.lastPli_ = timestamp;
        }

        private void setLayerLockPlis(int i) {
            this.layerLockPlis_ = i;
        }

        private void setNackAcks(int i) {
            this.nackAcks_ = i;
        }

        private void setNackMisses(int i) {
            this.nackMisses_ = i;
        }

        private void setNackRepeated(int i) {
            this.nackRepeated_ = i;
        }

        private void setNacks(int i) {
            this.nacks_ = i;
        }

        private void setNtpReportDrift(RTPDrift rTPDrift) {
            rTPDrift.getClass();
            this.ntpReportDrift_ = rTPDrift;
        }

        private void setPacketDrift(RTPDrift rTPDrift) {
            rTPDrift.getClass();
            this.packetDrift_ = rTPDrift;
        }

        private void setPacketDuplicateRate(double d) {
            this.packetDuplicateRate_ = d;
        }

        private void setPacketLossPercentage(float f) {
            this.packetLossPercentage_ = f;
        }

        private void setPacketLossRate(double d) {
            this.packetLossRate_ = d;
        }

        private void setPacketPaddingRate(double d) {
            this.packetPaddingRate_ = d;
        }

        private void setPacketRate(double d) {
            this.packetRate_ = d;
        }

        private void setPackets(int i) {
            this.packets_ = i;
        }

        private void setPacketsDuplicate(int i) {
            this.packetsDuplicate_ = i;
        }

        private void setPacketsLost(int i) {
            this.packetsLost_ = i;
        }

        private void setPacketsOutOfOrder(int i) {
            this.packetsOutOfOrder_ = i;
        }

        private void setPacketsPadding(int i) {
            this.packetsPadding_ = i;
        }

        private void setPlis(int i) {
            this.plis_ = i;
        }

        private void setRebasedReportDrift(RTPDrift rTPDrift) {
            rTPDrift.getClass();
            this.rebasedReportDrift_ = rTPDrift;
        }

        private void setReceivedReportDrift(RTPDrift rTPDrift) {
            rTPDrift.getClass();
            this.receivedReportDrift_ = rTPDrift;
        }

        private void setRttCurrent(int i) {
            this.rttCurrent_ = i;
        }

        private void setRttMax(int i) {
            this.rttMax_ = i;
        }

        private void setStartTime(Timestamp timestamp) {
            timestamp.getClass();
            this.startTime_ = timestamp;
        }

        public boolean containsGapHistogram(int i) {
            return internalGetGapHistogram().containsKey(Integer.valueOf(i));
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new RTPStats();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000-\u0000\u0000\u0001/-\u0001\u0000\u0000\u0001\t\u0002\t\u0003\u0000\u0004\u000b\u0005\u0000\u0006\u0003\u0007\u0000\b\u000b\t\u0000\n\u0001\u000b\u000b\f\u0000\r\u0003\u000e\u0000\u000f\u000b\u0010\u0000\u0011\u0003\u0012\u0000\u0013\u000b\u0014\u000b\u0015\u0000\u0016\u0000\u0017\u0000\u00182\u0019\u000b\u001a\u000b\u001b\u000b\u001c\t\u001d\u000b\u001e\t\u001f\u000b \u000b!\u000b\"\t#\u000b$\t%\u000b&\u000b'\u0003(\u0003)\u0003,\t-\t.\t/\t", new Object[]{ap.a(1227876737), ap.a(1413379331), ap.a(1649122287), ap.a(2123769027), ap.a(545607447), ap.a(1549736727), ap.a(1761958772), ap.a(237559569), ap.a(857242005), ap.a(314003601), ap.a(2030308538), ap.a(1034103041), ap.a(1176100555), ap.a(703833652), ap.a(1717341773), ap.a(1652701586), ap.a(1794308469), ap.a(2004209428), ap.a(659012667), ap.a(525643851), ap.a(450617126), ap.a(1973518233), ap.a(1653850222), ap.a(1527003361), GapHistogramDefaultEntryHolder.a, ap.a(1968457711), ap.a(817846197), ap.a(326813161), ap.a(1414097585), ap.a(175030098), ap.a(1345899476), ap.a(8351730), ap.a(456646465), ap.a(311207755), ap.a(1010904991), ap.a(1365577606), ap.a(462917604), ap.a(101058371), ap.a(266306459), ap.a(1905520812), ap.a(1390336873), ap.a(1213423852), ap.a(987909683), ap.a(224556825), ap.a(1875861321), ap.a(697348498)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RTPStats> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RTPStats.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public double getBitrate() {
            return this.bitrate_;
        }

        public double getBitrateDuplicate() {
            return this.bitrateDuplicate_;
        }

        public double getBitratePadding() {
            return this.bitratePadding_;
        }

        public long getBytes() {
            return this.bytes_;
        }

        public long getBytesDuplicate() {
            return this.bytesDuplicate_;
        }

        public long getBytesPadding() {
            return this.bytesPadding_;
        }

        public double getDuration() {
            return this.duration_;
        }

        public Timestamp getEndTime() {
            Timestamp timestamp = this.endTime_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public int getFirs() {
            return this.firs_;
        }

        public double getFrameRate() {
            return this.frameRate_;
        }

        public int getFrames() {
            return this.frames_;
        }

        @Deprecated
        public Map<Integer, Integer> getGapHistogram() {
            return getGapHistogramMap();
        }

        public int getGapHistogramCount() {
            return internalGetGapHistogram().size();
        }

        public Map<Integer, Integer> getGapHistogramMap() {
            return Collections.unmodifiableMap(internalGetGapHistogram());
        }

        public int getGapHistogramOrDefault(int i, int i2) {
            MapFieldLite<Integer, Integer> mapFieldLiteInternalGetGapHistogram = internalGetGapHistogram();
            return mapFieldLiteInternalGetGapHistogram.containsKey(Integer.valueOf(i)) ? ((Integer) mapFieldLiteInternalGetGapHistogram.get(Integer.valueOf(i))).intValue() : i2;
        }

        public int getGapHistogramOrThrow(int i) {
            MapFieldLite<Integer, Integer> mapFieldLiteInternalGetGapHistogram = internalGetGapHistogram();
            if (mapFieldLiteInternalGetGapHistogram.containsKey(Integer.valueOf(i))) {
                return ((Integer) mapFieldLiteInternalGetGapHistogram.get(Integer.valueOf(i))).intValue();
            }
            throw new IllegalArgumentException();
        }

        public long getHeaderBytes() {
            return this.headerBytes_;
        }

        public long getHeaderBytesDuplicate() {
            return this.headerBytesDuplicate_;
        }

        public long getHeaderBytesPadding() {
            return this.headerBytesPadding_;
        }

        public double getJitterCurrent() {
            return this.jitterCurrent_;
        }

        public double getJitterMax() {
            return this.jitterMax_;
        }

        public int getKeyFrames() {
            return this.keyFrames_;
        }

        public Timestamp getLastFir() {
            Timestamp timestamp = this.lastFir_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public Timestamp getLastKeyFrame() {
            Timestamp timestamp = this.lastKeyFrame_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public Timestamp getLastLayerLockPli() {
            Timestamp timestamp = this.lastLayerLockPli_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public Timestamp getLastPli() {
            Timestamp timestamp = this.lastPli_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public int getLayerLockPlis() {
            return this.layerLockPlis_;
        }

        public int getNackAcks() {
            return this.nackAcks_;
        }

        public int getNackMisses() {
            return this.nackMisses_;
        }

        public int getNackRepeated() {
            return this.nackRepeated_;
        }

        public int getNacks() {
            return this.nacks_;
        }

        public RTPDrift getNtpReportDrift() {
            RTPDrift rTPDrift = this.ntpReportDrift_;
            return rTPDrift == null ? RTPDrift.getDefaultInstance() : rTPDrift;
        }

        public RTPDrift getPacketDrift() {
            RTPDrift rTPDrift = this.packetDrift_;
            return rTPDrift == null ? RTPDrift.getDefaultInstance() : rTPDrift;
        }

        public double getPacketDuplicateRate() {
            return this.packetDuplicateRate_;
        }

        public float getPacketLossPercentage() {
            return this.packetLossPercentage_;
        }

        public double getPacketLossRate() {
            return this.packetLossRate_;
        }

        public double getPacketPaddingRate() {
            return this.packetPaddingRate_;
        }

        public double getPacketRate() {
            return this.packetRate_;
        }

        public int getPackets() {
            return this.packets_;
        }

        public int getPacketsDuplicate() {
            return this.packetsDuplicate_;
        }

        public int getPacketsLost() {
            return this.packetsLost_;
        }

        public int getPacketsOutOfOrder() {
            return this.packetsOutOfOrder_;
        }

        public int getPacketsPadding() {
            return this.packetsPadding_;
        }

        public int getPlis() {
            return this.plis_;
        }

        public RTPDrift getRebasedReportDrift() {
            RTPDrift rTPDrift = this.rebasedReportDrift_;
            return rTPDrift == null ? RTPDrift.getDefaultInstance() : rTPDrift;
        }

        public RTPDrift getReceivedReportDrift() {
            RTPDrift rTPDrift = this.receivedReportDrift_;
            return rTPDrift == null ? RTPDrift.getDefaultInstance() : rTPDrift;
        }

        public int getRttCurrent() {
            return this.rttCurrent_;
        }

        public int getRttMax() {
            return this.rttMax_;
        }

        public Timestamp getStartTime() {
            Timestamp timestamp = this.startTime_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public boolean hasEndTime() {
            return this.endTime_ != null;
        }

        public boolean hasLastFir() {
            return this.lastFir_ != null;
        }

        public boolean hasLastKeyFrame() {
            return this.lastKeyFrame_ != null;
        }

        public boolean hasLastLayerLockPli() {
            return this.lastLayerLockPli_ != null;
        }

        public boolean hasLastPli() {
            return this.lastPli_ != null;
        }

        public boolean hasNtpReportDrift() {
            return this.ntpReportDrift_ != null;
        }

        public boolean hasPacketDrift() {
            return this.packetDrift_ != null;
        }

        public boolean hasRebasedReportDrift() {
            return this.rebasedReportDrift_ != null;
        }

        public boolean hasReceivedReportDrift() {
            return this.receivedReportDrift_ != null;
        }

        public boolean hasStartTime() {
            return this.startTime_ != null;
        }

        public static Builder newBuilder(RTPStats rTPStats) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(rTPStats);
        }

        public static RTPStats parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPStats) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RTPStats parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RTPStats parseFrom(ByteString byteString) {
            return (RTPStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RTPStats parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RTPStats parseFrom(byte[] bArr) {
            return (RTPStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RTPStats parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RTPStats parseFrom(InputStream inputStream) {
            return (RTPStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RTPStats parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RTPStats parseFrom(CodedInputStream codedInputStream) {
            return (RTPStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RTPStats parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RTPStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RTPStatsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum ReconnectReason implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(4),
        g(-1);

        private static final Internal.EnumLiteMap h = new Internal.EnumLiteMap<ReconnectReason>() { // from class: livekit.LivekitModels.ReconnectReason.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public ReconnectReason findValueByNumber(int i2) {
                return ReconnectReason.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class ReconnectReasonVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new ReconnectReasonVerifier();

            private ReconnectReasonVerifier() {
            }

            public boolean isInRange(int i) {
                return ReconnectReason.b(i) != null;
            }
        }

        ReconnectReason(int i2) {
            this.a = i2;
        }

        public static ReconnectReason b(int i2) {
            if (i2 == 0) {
                return b;
            }
            if (i2 == 1) {
                return c;
            }
            if (i2 == 2) {
                return d;
            }
            if (i2 == 3) {
                return e;
            }
            if (i2 != 4) {
                return null;
            }
            return f;
        }

        public final int getNumber() {
            if (this != g) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class Room extends GeneratedMessageLite<Room, Builder> implements RoomOrBuilder {
        public static final int ACTIVE_RECORDING_FIELD_NUMBER = 10;
        public static final int CREATION_TIME_FIELD_NUMBER = 5;
        public static final int CREATION_TIME_MS_FIELD_NUMBER = 15;
        private static final Room DEFAULT_INSTANCE;
        public static final int DEPARTURE_TIMEOUT_FIELD_NUMBER = 14;
        public static final int EMPTY_TIMEOUT_FIELD_NUMBER = 3;
        public static final int ENABLED_CODECS_FIELD_NUMBER = 7;
        public static final int MAX_PARTICIPANTS_FIELD_NUMBER = 4;
        public static final int METADATA_FIELD_NUMBER = 8;
        public static final int NAME_FIELD_NUMBER = 2;
        public static final int NUM_PARTICIPANTS_FIELD_NUMBER = 9;
        public static final int NUM_PUBLISHERS_FIELD_NUMBER = 11;
        private static volatile Parser<Room> PARSER = null;
        public static final int SID_FIELD_NUMBER = 1;
        public static final int TURN_PASSWORD_FIELD_NUMBER = 6;
        public static final int VERSION_FIELD_NUMBER = 13;
        private boolean activeRecording_;
        private long creationTimeMs_;
        private long creationTime_;
        private int departureTimeout_;
        private int emptyTimeout_;
        private Internal.ProtobufList<Codec> enabledCodecs_;
        private int maxParticipants_;
        private String metadata_;
        private String name_;
        private int numParticipants_;
        private int numPublishers_;
        private String sid_;
        private String turnPassword_;
        private TimedVersion version_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<Room, Builder> implements RoomOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(Room.DEFAULT_INSTANCE);
            }
        }

        static {
            Room room = new Room();
            DEFAULT_INSTANCE = room;
            GeneratedMessageLite.registerDefaultInstance(Room.class, room);
        }

        private Room() {
            String strA = ap.a(1097994995);
            this.sid_ = strA;
            this.name_ = strA;
            this.turnPassword_ = strA;
            this.enabledCodecs_ = GeneratedMessageLite.emptyProtobufList();
            this.metadata_ = strA;
        }

        private void addAllEnabledCodecs(Iterable<? extends Codec> iterable) {
            ensureEnabledCodecsIsMutable();
            AbstractMessageLite.addAll(iterable, this.enabledCodecs_);
        }

        private void addEnabledCodecs(Codec codec) {
            codec.getClass();
            ensureEnabledCodecsIsMutable();
            this.enabledCodecs_.add(codec);
        }

        private void clearActiveRecording() {
            this.activeRecording_ = false;
        }

        private void clearCreationTime() {
            this.creationTime_ = 0L;
        }

        private void clearCreationTimeMs() {
            this.creationTimeMs_ = 0L;
        }

        private void clearDepartureTimeout() {
            this.departureTimeout_ = 0;
        }

        private void clearEmptyTimeout() {
            this.emptyTimeout_ = 0;
        }

        private void clearEnabledCodecs() {
            this.enabledCodecs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearMaxParticipants() {
            this.maxParticipants_ = 0;
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearNumParticipants() {
            this.numParticipants_ = 0;
        }

        private void clearNumPublishers() {
            this.numPublishers_ = 0;
        }

        private void clearSid() {
            this.sid_ = getDefaultInstance().getSid();
        }

        private void clearTurnPassword() {
            this.turnPassword_ = getDefaultInstance().getTurnPassword();
        }

        private void clearVersion() {
            this.version_ = null;
        }

        private void ensureEnabledCodecsIsMutable() {
            Internal.ProtobufList<Codec> protobufList = this.enabledCodecs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.enabledCodecs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static Room getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeVersion(TimedVersion timedVersion) {
            timedVersion.getClass();
            TimedVersion timedVersion2 = this.version_;
            if (timedVersion2 == null || timedVersion2 == TimedVersion.getDefaultInstance()) {
                this.version_ = timedVersion;
            } else {
                this.version_ = (TimedVersion) ((TimedVersion.Builder) TimedVersion.newBuilder(this.version_).v(timedVersion)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static Room parseDelimitedFrom(InputStream inputStream) {
            return (Room) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Room parseFrom(ByteBuffer byteBuffer) {
            return (Room) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<Room> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeEnabledCodecs(int i) {
            ensureEnabledCodecsIsMutable();
            this.enabledCodecs_.remove(i);
        }

        private void setActiveRecording(boolean z) {
            this.activeRecording_ = z;
        }

        private void setCreationTime(long j) {
            this.creationTime_ = j;
        }

        private void setCreationTimeMs(long j) {
            this.creationTimeMs_ = j;
        }

        private void setDepartureTimeout(int i) {
            this.departureTimeout_ = i;
        }

        private void setEmptyTimeout(int i) {
            this.emptyTimeout_ = i;
        }

        private void setEnabledCodecs(int i, Codec codec) {
            codec.getClass();
            ensureEnabledCodecsIsMutable();
            this.enabledCodecs_.set(i, codec);
        }

        private void setMaxParticipants(int i) {
            this.maxParticipants_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setNumParticipants(int i) {
            this.numParticipants_ = i;
        }

        private void setNumPublishers(int i) {
            this.numPublishers_ = i;
        }

        private void setSid(String str) {
            str.getClass();
            this.sid_ = str;
        }

        private void setSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sid_ = byteString.L();
        }

        private void setTurnPassword(String str) {
            str.getClass();
            this.turnPassword_ = str;
        }

        private void setTurnPasswordBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.turnPassword_ = byteString.L();
        }

        private void setVersion(TimedVersion timedVersion) {
            timedVersion.getClass();
            this.version_ = timedVersion;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new Room();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000e\u0000\u0000\u0001\u000f\u000e\u0000\u0001\u0000\u0001Ȉ\u0002Ȉ\u0003\u000b\u0004\u000b\u0005\u0002\u0006Ȉ\u0007\u001b\bȈ\t\u000b\n\u0007\u000b\u000b\r\t\u000e\u000b\u000f\u0002", new Object[]{"sid_", "name_", "emptyTimeout_", "maxParticipants_", "creationTime_", "turnPassword_", "enabledCodecs_", Codec.class, "metadata_", "numParticipants_", "activeRecording_", "numPublishers_", "version_", "departureTimeout_", "creationTimeMs_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<Room> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (Room.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getActiveRecording() {
            return this.activeRecording_;
        }

        public long getCreationTime() {
            return this.creationTime_;
        }

        public long getCreationTimeMs() {
            return this.creationTimeMs_;
        }

        public int getDepartureTimeout() {
            return this.departureTimeout_;
        }

        public int getEmptyTimeout() {
            return this.emptyTimeout_;
        }

        public Codec getEnabledCodecs(int i) {
            return (Codec) this.enabledCodecs_.get(i);
        }

        public int getEnabledCodecsCount() {
            return this.enabledCodecs_.size();
        }

        public List<Codec> getEnabledCodecsList() {
            return this.enabledCodecs_;
        }

        public CodecOrBuilder getEnabledCodecsOrBuilder(int i) {
            return (CodecOrBuilder) this.enabledCodecs_.get(i);
        }

        public List<? extends CodecOrBuilder> getEnabledCodecsOrBuilderList() {
            return this.enabledCodecs_;
        }

        public int getMaxParticipants() {
            return this.maxParticipants_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public int getNumParticipants() {
            return this.numParticipants_;
        }

        public int getNumPublishers() {
            return this.numPublishers_;
        }

        public String getSid() {
            return this.sid_;
        }

        public ByteString getSidBytes() {
            return ByteString.n(this.sid_);
        }

        public String getTurnPassword() {
            return this.turnPassword_;
        }

        public ByteString getTurnPasswordBytes() {
            return ByteString.n(this.turnPassword_);
        }

        public TimedVersion getVersion() {
            TimedVersion timedVersion = this.version_;
            return timedVersion == null ? TimedVersion.getDefaultInstance() : timedVersion;
        }

        public boolean hasVersion() {
            return this.version_ != null;
        }

        public static Builder newBuilder(Room room) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(room);
        }

        public static Room parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Room) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Room parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (Room) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static Room parseFrom(ByteString byteString) {
            return (Room) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addEnabledCodecs(int i, Codec codec) {
            codec.getClass();
            ensureEnabledCodecsIsMutable();
            this.enabledCodecs_.add(i, codec);
        }

        public static Room parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (Room) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static Room parseFrom(byte[] bArr) {
            return (Room) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static Room parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (Room) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static Room parseFrom(InputStream inputStream) {
            return (Room) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Room parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Room) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Room parseFrom(CodedInputStream codedInputStream) {
            return (Room) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static Room parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Room) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RoomOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RpcAck extends GeneratedMessageLite<RpcAck, Builder> implements RpcAckOrBuilder {
        private static final RpcAck DEFAULT_INSTANCE;
        private static volatile Parser<RpcAck> PARSER = null;
        public static final int REQUEST_ID_FIELD_NUMBER = 1;
        private String requestId_ = ap.a(1682779564);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RpcAck, Builder> implements RpcAckOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(String str) {
                q();
                ((RpcAck) ((GeneratedMessageLite.Builder) this).b).setRequestId(str);
                return this;
            }

            private Builder() {
                super(RpcAck.DEFAULT_INSTANCE);
            }
        }

        static {
            RpcAck rpcAck = new RpcAck();
            DEFAULT_INSTANCE = rpcAck;
            GeneratedMessageLite.registerDefaultInstance(RpcAck.class, rpcAck);
        }

        private RpcAck() {
        }

        private void clearRequestId() {
            this.requestId_ = getDefaultInstance().getRequestId();
        }

        public static RpcAck getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RpcAck parseDelimitedFrom(InputStream inputStream) {
            return (RpcAck) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RpcAck parseFrom(ByteBuffer byteBuffer) {
            return (RpcAck) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RpcAck> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setRequestId(String str) {
            str.getClass();
            this.requestId_ = str;
        }

        private void setRequestIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.requestId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RpcAck();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"requestId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RpcAck> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RpcAck.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getRequestId() {
            return this.requestId_;
        }

        public ByteString getRequestIdBytes() {
            return ByteString.n(this.requestId_);
        }

        public static Builder newBuilder(RpcAck rpcAck) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(rpcAck);
        }

        public static RpcAck parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcAck) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RpcAck parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcAck) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RpcAck parseFrom(ByteString byteString) {
            return (RpcAck) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RpcAck parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcAck) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RpcAck parseFrom(byte[] bArr) {
            return (RpcAck) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RpcAck parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcAck) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RpcAck parseFrom(InputStream inputStream) {
            return (RpcAck) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RpcAck parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcAck) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RpcAck parseFrom(CodedInputStream codedInputStream) {
            return (RpcAck) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RpcAck parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcAck) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RpcAckOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RpcError extends GeneratedMessageLite<RpcError, Builder> implements RpcErrorOrBuilder {
        public static final int CODE_FIELD_NUMBER = 1;
        public static final int DATA_FIELD_NUMBER = 3;
        private static final RpcError DEFAULT_INSTANCE;
        public static final int MESSAGE_FIELD_NUMBER = 2;
        private static volatile Parser<RpcError> PARSER;
        private int code_;
        private String data_;
        private String message_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RpcError, Builder> implements RpcErrorOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(int i) {
                q();
                ((RpcError) ((GeneratedMessageLite.Builder) this).b).setCode(i);
                return this;
            }

            public Builder B(String str) {
                q();
                ((RpcError) ((GeneratedMessageLite.Builder) this).b).setData(str);
                return this;
            }

            public Builder C(String str) {
                q();
                ((RpcError) ((GeneratedMessageLite.Builder) this).b).setMessage(str);
                return this;
            }

            private Builder() {
                super(RpcError.DEFAULT_INSTANCE);
            }
        }

        static {
            RpcError rpcError = new RpcError();
            DEFAULT_INSTANCE = rpcError;
            GeneratedMessageLite.registerDefaultInstance(RpcError.class, rpcError);
        }

        private RpcError() {
            String strA = ap.a(586617637);
            this.message_ = strA;
            this.data_ = strA;
        }

        private void clearCode() {
            this.code_ = 0;
        }

        private void clearData() {
            this.data_ = getDefaultInstance().getData();
        }

        private void clearMessage() {
            this.message_ = getDefaultInstance().getMessage();
        }

        public static RpcError getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RpcError parseDelimitedFrom(InputStream inputStream) {
            return (RpcError) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RpcError parseFrom(ByteBuffer byteBuffer) {
            return (RpcError) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RpcError> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCode(int i) {
            this.code_ = i;
        }

        private void setData(String str) {
            str.getClass();
            this.data_ = str;
        }

        private void setDataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.data_ = byteString.L();
        }

        private void setMessage(String str) {
            str.getClass();
            this.message_ = str;
        }

        private void setMessageBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.message_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RpcError();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\u000b\u0002Ȉ\u0003Ȉ", new Object[]{"code_", "message_", "data_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RpcError> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RpcError.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getCode() {
            return this.code_;
        }

        public String getData() {
            return this.data_;
        }

        public ByteString getDataBytes() {
            return ByteString.n(this.data_);
        }

        public String getMessage() {
            return this.message_;
        }

        public ByteString getMessageBytes() {
            return ByteString.n(this.message_);
        }

        public static Builder newBuilder(RpcError rpcError) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(rpcError);
        }

        public static RpcError parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcError) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RpcError parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcError) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RpcError parseFrom(ByteString byteString) {
            return (RpcError) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RpcError parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcError) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RpcError parseFrom(byte[] bArr) {
            return (RpcError) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RpcError parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcError) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RpcError parseFrom(InputStream inputStream) {
            return (RpcError) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RpcError parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcError) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RpcError parseFrom(CodedInputStream codedInputStream) {
            return (RpcError) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RpcError parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcError) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RpcErrorOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RpcRequest extends GeneratedMessageLite<RpcRequest, Builder> implements RpcRequestOrBuilder {
        private static final RpcRequest DEFAULT_INSTANCE;
        public static final int ID_FIELD_NUMBER = 1;
        public static final int METHOD_FIELD_NUMBER = 2;
        private static volatile Parser<RpcRequest> PARSER = null;
        public static final int PAYLOAD_FIELD_NUMBER = 3;
        public static final int RESPONSE_TIMEOUT_MS_FIELD_NUMBER = 4;
        public static final int VERSION_FIELD_NUMBER = 5;
        private String id_;
        private String method_;
        private String payload_;
        private int responseTimeoutMs_;
        private int version_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RpcRequest, Builder> implements RpcRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(String str) {
                q();
                ((RpcRequest) ((GeneratedMessageLite.Builder) this).b).setId(str);
                return this;
            }

            public Builder B(String str) {
                q();
                ((RpcRequest) ((GeneratedMessageLite.Builder) this).b).setMethod(str);
                return this;
            }

            public Builder C(String str) {
                q();
                ((RpcRequest) ((GeneratedMessageLite.Builder) this).b).setPayload(str);
                return this;
            }

            public Builder D(int i) {
                q();
                ((RpcRequest) ((GeneratedMessageLite.Builder) this).b).setResponseTimeoutMs(i);
                return this;
            }

            public Builder E(int i) {
                q();
                ((RpcRequest) ((GeneratedMessageLite.Builder) this).b).setVersion(i);
                return this;
            }

            private Builder() {
                super(RpcRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            RpcRequest rpcRequest = new RpcRequest();
            DEFAULT_INSTANCE = rpcRequest;
            GeneratedMessageLite.registerDefaultInstance(RpcRequest.class, rpcRequest);
        }

        private RpcRequest() {
            String strA = ap.a(1264453670);
            this.id_ = strA;
            this.method_ = strA;
            this.payload_ = strA;
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearMethod() {
            this.method_ = getDefaultInstance().getMethod();
        }

        private void clearPayload() {
            this.payload_ = getDefaultInstance().getPayload();
        }

        private void clearResponseTimeoutMs() {
            this.responseTimeoutMs_ = 0;
        }

        private void clearVersion() {
            this.version_ = 0;
        }

        public static RpcRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RpcRequest parseDelimitedFrom(InputStream inputStream) {
            return (RpcRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RpcRequest parseFrom(ByteBuffer byteBuffer) {
            return (RpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RpcRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setMethod(String str) {
            str.getClass();
            this.method_ = str;
        }

        private void setMethodBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.method_ = byteString.L();
        }

        private void setPayload(String str) {
            str.getClass();
            this.payload_ = str;
        }

        private void setPayloadBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.payload_ = byteString.L();
        }

        private void setResponseTimeoutMs(int i) {
            this.responseTimeoutMs_ = i;
        }

        private void setVersion(int i) {
            this.version_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RpcRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\u000b\u0005\u000b", new Object[]{"id_", "method_", "payload_", "responseTimeoutMs_", "version_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RpcRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RpcRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public String getMethod() {
            return this.method_;
        }

        public ByteString getMethodBytes() {
            return ByteString.n(this.method_);
        }

        public String getPayload() {
            return this.payload_;
        }

        public ByteString getPayloadBytes() {
            return ByteString.n(this.payload_);
        }

        public int getResponseTimeoutMs() {
            return this.responseTimeoutMs_;
        }

        public int getVersion() {
            return this.version_;
        }

        public static Builder newBuilder(RpcRequest rpcRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(rpcRequest);
        }

        public static RpcRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RpcRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RpcRequest parseFrom(ByteString byteString) {
            return (RpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RpcRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RpcRequest parseFrom(byte[] bArr) {
            return (RpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RpcRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RpcRequest parseFrom(InputStream inputStream) {
            return (RpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RpcRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RpcRequest parseFrom(CodedInputStream codedInputStream) {
            return (RpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RpcRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RpcRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RpcResponse extends GeneratedMessageLite<RpcResponse, Builder> implements RpcResponseOrBuilder {
        private static final RpcResponse DEFAULT_INSTANCE;
        public static final int ERROR_FIELD_NUMBER = 3;
        private static volatile Parser<RpcResponse> PARSER = null;
        public static final int PAYLOAD_FIELD_NUMBER = 2;
        public static final int REQUEST_ID_FIELD_NUMBER = 1;
        private Object value_;
        private int valueCase_ = 0;
        private String requestId_ = ap.a(1350079201);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RpcResponse, Builder> implements RpcResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(RpcError rpcError) {
                q();
                ((RpcResponse) ((GeneratedMessageLite.Builder) this).b).setError(rpcError);
                return this;
            }

            public Builder B(String str) {
                q();
                ((RpcResponse) ((GeneratedMessageLite.Builder) this).b).setPayload(str);
                return this;
            }

            public Builder C(String str) {
                q();
                ((RpcResponse) ((GeneratedMessageLite.Builder) this).b).setRequestId(str);
                return this;
            }

            private Builder() {
                super(RpcResponse.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum ValueCase {
            b(2),
            c(3),
            d(0);

            private final int a;

            ValueCase(int i) {
                this.a = i;
            }

            public static ValueCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 2) {
                    return b;
                }
                if (i != 3) {
                    return null;
                }
                return c;
            }
        }

        static {
            RpcResponse rpcResponse = new RpcResponse();
            DEFAULT_INSTANCE = rpcResponse;
            GeneratedMessageLite.registerDefaultInstance(RpcResponse.class, rpcResponse);
        }

        private RpcResponse() {
        }

        private void clearError() {
            if (this.valueCase_ == 3) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearPayload() {
            if (this.valueCase_ == 2) {
                this.valueCase_ = 0;
                this.value_ = null;
            }
        }

        private void clearRequestId() {
            this.requestId_ = getDefaultInstance().getRequestId();
        }

        private void clearValue() {
            this.valueCase_ = 0;
            this.value_ = null;
        }

        public static RpcResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeError(RpcError rpcError) {
            rpcError.getClass();
            if (this.valueCase_ != 3 || this.value_ == RpcError.getDefaultInstance()) {
                this.value_ = rpcError;
            } else {
                this.value_ = ((RpcError.Builder) RpcError.newBuilder((RpcError) this.value_).v(rpcError)).o();
            }
            this.valueCase_ = 3;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RpcResponse parseDelimitedFrom(InputStream inputStream) {
            return (RpcResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RpcResponse parseFrom(ByteBuffer byteBuffer) {
            return (RpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RpcResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setError(RpcError rpcError) {
            rpcError.getClass();
            this.value_ = rpcError;
            this.valueCase_ = 3;
        }

        private void setPayload(String str) {
            str.getClass();
            this.valueCase_ = 2;
            this.value_ = str;
        }

        private void setPayloadBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.value_ = byteString.L();
            this.valueCase_ = 2;
        }

        private void setRequestId(String str) {
            str.getClass();
            this.requestId_ = str;
        }

        private void setRequestIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.requestId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RpcResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0001\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȼ\u0000\u0003<\u0000", new Object[]{"value_", "valueCase_", "requestId_", RpcError.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RpcResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RpcResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public RpcError getError() {
            return this.valueCase_ == 3 ? (RpcError) this.value_ : RpcError.getDefaultInstance();
        }

        public String getPayload() {
            return this.valueCase_ == 2 ? (String) this.value_ : StringUtils.EMPTY;
        }

        public ByteString getPayloadBytes() {
            return ByteString.n(this.valueCase_ == 2 ? (String) this.value_ : StringUtils.EMPTY);
        }

        public String getRequestId() {
            return this.requestId_;
        }

        public ByteString getRequestIdBytes() {
            return ByteString.n(this.requestId_);
        }

        public ValueCase getValueCase() {
            return ValueCase.b(this.valueCase_);
        }

        public boolean hasError() {
            return this.valueCase_ == 3;
        }

        public boolean hasPayload() {
            return this.valueCase_ == 2;
        }

        public static Builder newBuilder(RpcResponse rpcResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(rpcResponse);
        }

        public static RpcResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RpcResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RpcResponse parseFrom(ByteString byteString) {
            return (RpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RpcResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RpcResponse parseFrom(byte[] bArr) {
            return (RpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RpcResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RpcResponse parseFrom(InputStream inputStream) {
            return (RpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RpcResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RpcResponse parseFrom(CodedInputStream codedInputStream) {
            return (RpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RpcResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RpcResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ServerInfo extends GeneratedMessageLite<ServerInfo, Builder> implements ServerInfoOrBuilder {
        public static final int AGENT_PROTOCOL_FIELD_NUMBER = 7;
        public static final int DEBUG_INFO_FIELD_NUMBER = 6;
        private static final ServerInfo DEFAULT_INSTANCE;
        public static final int EDITION_FIELD_NUMBER = 1;
        public static final int NODE_ID_FIELD_NUMBER = 5;
        private static volatile Parser<ServerInfo> PARSER = null;
        public static final int PROTOCOL_FIELD_NUMBER = 3;
        public static final int REGION_FIELD_NUMBER = 4;
        public static final int VERSION_FIELD_NUMBER = 2;
        private int agentProtocol_;
        private String debugInfo_;
        private int edition_;
        private String nodeId_;
        private int protocol_;
        private String region_;
        private String version_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ServerInfo, Builder> implements ServerInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ServerInfo.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum Edition implements Internal.EnumLite {
            b(0),
            c(1),
            d(-1);

            private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<Edition>() { // from class: livekit.LivekitModels.ServerInfo.Edition.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public Edition findValueByNumber(int i) {
                    return Edition.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class EditionVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new EditionVerifier();

                private EditionVerifier() {
                }

                public boolean isInRange(int i) {
                    return Edition.b(i) != null;
                }
            }

            Edition(int i) {
                this.a = i;
            }

            public static Edition b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i != 1) {
                    return null;
                }
                return c;
            }

            public final int getNumber() {
                if (this != d) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        static {
            ServerInfo serverInfo = new ServerInfo();
            DEFAULT_INSTANCE = serverInfo;
            GeneratedMessageLite.registerDefaultInstance(ServerInfo.class, serverInfo);
        }

        private ServerInfo() {
            String strA = ap.a(508224492);
            this.version_ = strA;
            this.region_ = strA;
            this.nodeId_ = strA;
            this.debugInfo_ = strA;
        }

        private void clearAgentProtocol() {
            this.agentProtocol_ = 0;
        }

        private void clearDebugInfo() {
            this.debugInfo_ = getDefaultInstance().getDebugInfo();
        }

        private void clearEdition() {
            this.edition_ = 0;
        }

        private void clearNodeId() {
            this.nodeId_ = getDefaultInstance().getNodeId();
        }

        private void clearProtocol() {
            this.protocol_ = 0;
        }

        private void clearRegion() {
            this.region_ = getDefaultInstance().getRegion();
        }

        private void clearVersion() {
            this.version_ = getDefaultInstance().getVersion();
        }

        public static ServerInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ServerInfo parseDelimitedFrom(InputStream inputStream) {
            return (ServerInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ServerInfo parseFrom(ByteBuffer byteBuffer) {
            return (ServerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ServerInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentProtocol(int i) {
            this.agentProtocol_ = i;
        }

        private void setDebugInfo(String str) {
            str.getClass();
            this.debugInfo_ = str;
        }

        private void setDebugInfoBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.debugInfo_ = byteString.L();
        }

        private void setEdition(Edition edition) {
            this.edition_ = edition.getNumber();
        }

        private void setEditionValue(int i) {
            this.edition_ = i;
        }

        private void setNodeId(String str) {
            str.getClass();
            this.nodeId_ = str;
        }

        private void setNodeIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.nodeId_ = byteString.L();
        }

        private void setProtocol(int i) {
            this.protocol_ = i;
        }

        private void setRegion(String str) {
            str.getClass();
            this.region_ = str;
        }

        private void setRegionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.region_ = byteString.L();
        }

        private void setVersion(String str) {
            str.getClass();
            this.version_ = str;
        }

        private void setVersionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.version_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ServerInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0000\u0000\u0001\u0007\u0007\u0000\u0000\u0000\u0001\f\u0002Ȉ\u0003\u0004\u0004Ȉ\u0005Ȉ\u0006Ȉ\u0007\u0004", new Object[]{"edition_", "version_", "protocol_", "region_", "nodeId_", "debugInfo_", "agentProtocol_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ServerInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ServerInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getAgentProtocol() {
            return this.agentProtocol_;
        }

        public String getDebugInfo() {
            return this.debugInfo_;
        }

        public ByteString getDebugInfoBytes() {
            return ByteString.n(this.debugInfo_);
        }

        public Edition getEdition() {
            Edition editionB = Edition.b(this.edition_);
            return editionB == null ? Edition.d : editionB;
        }

        public int getEditionValue() {
            return this.edition_;
        }

        public String getNodeId() {
            return this.nodeId_;
        }

        public ByteString getNodeIdBytes() {
            return ByteString.n(this.nodeId_);
        }

        public int getProtocol() {
            return this.protocol_;
        }

        public String getRegion() {
            return this.region_;
        }

        public ByteString getRegionBytes() {
            return ByteString.n(this.region_);
        }

        public String getVersion() {
            return this.version_;
        }

        public ByteString getVersionBytes() {
            return ByteString.n(this.version_);
        }

        public static Builder newBuilder(ServerInfo serverInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(serverInfo);
        }

        public static ServerInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ServerInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ServerInfo parseFrom(ByteString byteString) {
            return (ServerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ServerInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ServerInfo parseFrom(byte[] bArr) {
            return (ServerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ServerInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ServerInfo parseFrom(InputStream inputStream) {
            return (ServerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ServerInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ServerInfo parseFrom(CodedInputStream codedInputStream) {
            return (ServerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ServerInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ServerInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SimulcastCodecInfo extends GeneratedMessageLite<SimulcastCodecInfo, Builder> implements SimulcastCodecInfoOrBuilder {
        public static final int CID_FIELD_NUMBER = 3;
        private static final SimulcastCodecInfo DEFAULT_INSTANCE;
        public static final int LAYERS_FIELD_NUMBER = 4;
        public static final int MID_FIELD_NUMBER = 2;
        public static final int MIME_TYPE_FIELD_NUMBER = 1;
        private static volatile Parser<SimulcastCodecInfo> PARSER = null;
        public static final int SDP_CID_FIELD_NUMBER = 6;
        public static final int VIDEO_LAYER_MODE_FIELD_NUMBER = 5;
        private String cid_;
        private Internal.ProtobufList<VideoLayer> layers_;
        private String mid_;
        private String mimeType_;
        private String sdpCid_;
        private int videoLayerMode_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SimulcastCodecInfo, Builder> implements SimulcastCodecInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SimulcastCodecInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            SimulcastCodecInfo simulcastCodecInfo = new SimulcastCodecInfo();
            DEFAULT_INSTANCE = simulcastCodecInfo;
            GeneratedMessageLite.registerDefaultInstance(SimulcastCodecInfo.class, simulcastCodecInfo);
        }

        private SimulcastCodecInfo() {
            String strA = ap.a(24264576);
            this.mimeType_ = strA;
            this.mid_ = strA;
            this.cid_ = strA;
            this.layers_ = GeneratedMessageLite.emptyProtobufList();
            this.sdpCid_ = strA;
        }

        private void addAllLayers(Iterable<? extends VideoLayer> iterable) {
            ensureLayersIsMutable();
            AbstractMessageLite.addAll(iterable, this.layers_);
        }

        private void addLayers(VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(videoLayer);
        }

        private void clearCid() {
            this.cid_ = getDefaultInstance().getCid();
        }

        private void clearLayers() {
            this.layers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearMid() {
            this.mid_ = getDefaultInstance().getMid();
        }

        private void clearMimeType() {
            this.mimeType_ = getDefaultInstance().getMimeType();
        }

        private void clearSdpCid() {
            this.sdpCid_ = getDefaultInstance().getSdpCid();
        }

        private void clearVideoLayerMode() {
            this.videoLayerMode_ = 0;
        }

        private void ensureLayersIsMutable() {
            Internal.ProtobufList<VideoLayer> protobufList = this.layers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.layers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SimulcastCodecInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SimulcastCodecInfo parseDelimitedFrom(InputStream inputStream) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SimulcastCodecInfo parseFrom(ByteBuffer byteBuffer) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SimulcastCodecInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeLayers(int i) {
            ensureLayersIsMutable();
            this.layers_.remove(i);
        }

        private void setCid(String str) {
            str.getClass();
            this.cid_ = str;
        }

        private void setCidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.cid_ = byteString.L();
        }

        private void setLayers(int i, VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.set(i, videoLayer);
        }

        private void setMid(String str) {
            str.getClass();
            this.mid_ = str;
        }

        private void setMidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.mid_ = byteString.L();
        }

        private void setMimeType(String str) {
            str.getClass();
            this.mimeType_ = str;
        }

        private void setMimeTypeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.mimeType_ = byteString.L();
        }

        private void setSdpCid(String str) {
            str.getClass();
            this.sdpCid_ = str;
        }

        private void setSdpCidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sdpCid_ = byteString.L();
        }

        private void setVideoLayerMode(VideoLayer.Mode mode) {
            this.videoLayerMode_ = mode.getNumber();
        }

        private void setVideoLayerModeValue(int i) {
            this.videoLayerMode_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SimulcastCodecInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0001\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\u001b\u0005\f\u0006Ȉ", new Object[]{"mimeType_", "mid_", "cid_", "layers_", VideoLayer.class, "videoLayerMode_", "sdpCid_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SimulcastCodecInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SimulcastCodecInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getCid() {
            return this.cid_;
        }

        public ByteString getCidBytes() {
            return ByteString.n(this.cid_);
        }

        public VideoLayer getLayers(int i) {
            return (VideoLayer) this.layers_.get(i);
        }

        public int getLayersCount() {
            return this.layers_.size();
        }

        public List<VideoLayer> getLayersList() {
            return this.layers_;
        }

        public VideoLayerOrBuilder getLayersOrBuilder(int i) {
            return (VideoLayerOrBuilder) this.layers_.get(i);
        }

        public List<? extends VideoLayerOrBuilder> getLayersOrBuilderList() {
            return this.layers_;
        }

        public String getMid() {
            return this.mid_;
        }

        public ByteString getMidBytes() {
            return ByteString.n(this.mid_);
        }

        public String getMimeType() {
            return this.mimeType_;
        }

        public ByteString getMimeTypeBytes() {
            return ByteString.n(this.mimeType_);
        }

        public String getSdpCid() {
            return this.sdpCid_;
        }

        public ByteString getSdpCidBytes() {
            return ByteString.n(this.sdpCid_);
        }

        public VideoLayer.Mode getVideoLayerMode() {
            VideoLayer.Mode modeB = VideoLayer.Mode.b(this.videoLayerMode_);
            return modeB == null ? VideoLayer.Mode.f : modeB;
        }

        public int getVideoLayerModeValue() {
            return this.videoLayerMode_;
        }

        public static Builder newBuilder(SimulcastCodecInfo simulcastCodecInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(simulcastCodecInfo);
        }

        public static SimulcastCodecInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SimulcastCodecInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SimulcastCodecInfo parseFrom(ByteString byteString) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addLayers(int i, VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(i, videoLayer);
        }

        public static SimulcastCodecInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SimulcastCodecInfo parseFrom(byte[] bArr) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SimulcastCodecInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SimulcastCodecInfo parseFrom(InputStream inputStream) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SimulcastCodecInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SimulcastCodecInfo parseFrom(CodedInputStream codedInputStream) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SimulcastCodecInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulcastCodecInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SimulcastCodecInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SipDTMF extends GeneratedMessageLite<SipDTMF, Builder> implements SipDTMFOrBuilder {
        public static final int CODE_FIELD_NUMBER = 3;
        private static final SipDTMF DEFAULT_INSTANCE;
        public static final int DIGIT_FIELD_NUMBER = 4;
        private static volatile Parser<SipDTMF> PARSER;
        private int code_;
        private String digit_ = ap.a(223057489);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SipDTMF, Builder> implements SipDTMFOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(int i) {
                q();
                ((SipDTMF) ((GeneratedMessageLite.Builder) this).b).setCode(i);
                return this;
            }

            public Builder B(String str) {
                q();
                ((SipDTMF) ((GeneratedMessageLite.Builder) this).b).setDigit(str);
                return this;
            }

            private Builder() {
                super(SipDTMF.DEFAULT_INSTANCE);
            }
        }

        static {
            SipDTMF sipDTMF = new SipDTMF();
            DEFAULT_INSTANCE = sipDTMF;
            GeneratedMessageLite.registerDefaultInstance(SipDTMF.class, sipDTMF);
        }

        private SipDTMF() {
        }

        private void clearCode() {
            this.code_ = 0;
        }

        private void clearDigit() {
            this.digit_ = getDefaultInstance().getDigit();
        }

        public static SipDTMF getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SipDTMF parseDelimitedFrom(InputStream inputStream) {
            return (SipDTMF) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SipDTMF parseFrom(ByteBuffer byteBuffer) {
            return (SipDTMF) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SipDTMF> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCode(int i) {
            this.code_ = i;
        }

        private void setDigit(String str) {
            str.getClass();
            this.digit_ = str;
        }

        private void setDigitBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.digit_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SipDTMF();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0003\u0004\u0002\u0000\u0000\u0000\u0003\u000b\u0004Ȉ", new Object[]{"code_", "digit_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SipDTMF> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SipDTMF.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getCode() {
            return this.code_;
        }

        public String getDigit() {
            return this.digit_;
        }

        public ByteString getDigitBytes() {
            return ByteString.n(this.digit_);
        }

        public static Builder newBuilder(SipDTMF sipDTMF) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sipDTMF);
        }

        public static SipDTMF parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SipDTMF) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SipDTMF parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SipDTMF) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SipDTMF parseFrom(ByteString byteString) {
            return (SipDTMF) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SipDTMF parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SipDTMF) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SipDTMF parseFrom(byte[] bArr) {
            return (SipDTMF) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SipDTMF parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SipDTMF) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SipDTMF parseFrom(InputStream inputStream) {
            return (SipDTMF) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SipDTMF parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SipDTMF) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SipDTMF parseFrom(CodedInputStream codedInputStream) {
            return (SipDTMF) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SipDTMF parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SipDTMF) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SipDTMFOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SpeakerInfo extends GeneratedMessageLite<SpeakerInfo, Builder> implements SpeakerInfoOrBuilder {
        public static final int ACTIVE_FIELD_NUMBER = 3;
        private static final SpeakerInfo DEFAULT_INSTANCE;
        public static final int LEVEL_FIELD_NUMBER = 2;
        private static volatile Parser<SpeakerInfo> PARSER = null;
        public static final int SID_FIELD_NUMBER = 1;
        private boolean active_;
        private float level_;
        private String sid_ = ap.a(772241998);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SpeakerInfo, Builder> implements SpeakerInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SpeakerInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            SpeakerInfo speakerInfo = new SpeakerInfo();
            DEFAULT_INSTANCE = speakerInfo;
            GeneratedMessageLite.registerDefaultInstance(SpeakerInfo.class, speakerInfo);
        }

        private SpeakerInfo() {
        }

        private void clearActive() {
            this.active_ = false;
        }

        private void clearLevel() {
            this.level_ = 0.0f;
        }

        private void clearSid() {
            this.sid_ = getDefaultInstance().getSid();
        }

        public static SpeakerInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SpeakerInfo parseDelimitedFrom(InputStream inputStream) {
            return (SpeakerInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SpeakerInfo parseFrom(ByteBuffer byteBuffer) {
            return (SpeakerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SpeakerInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setActive(boolean z) {
            this.active_ = z;
        }

        private void setLevel(float f) {
            this.level_ = f;
        }

        private void setSid(String str) {
            str.getClass();
            this.sid_ = str;
        }

        private void setSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SpeakerInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002\u0001\u0003\u0007", new Object[]{"sid_", "level_", "active_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SpeakerInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SpeakerInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getActive() {
            return this.active_;
        }

        public float getLevel() {
            return this.level_;
        }

        public String getSid() {
            return this.sid_;
        }

        public ByteString getSidBytes() {
            return ByteString.n(this.sid_);
        }

        public static Builder newBuilder(SpeakerInfo speakerInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(speakerInfo);
        }

        public static SpeakerInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakerInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SpeakerInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SpeakerInfo parseFrom(ByteString byteString) {
            return (SpeakerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SpeakerInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SpeakerInfo parseFrom(byte[] bArr) {
            return (SpeakerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SpeakerInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SpeakerInfo parseFrom(InputStream inputStream) {
            return (SpeakerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SpeakerInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SpeakerInfo parseFrom(CodedInputStream codedInputStream) {
            return (SpeakerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SpeakerInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SpeakerInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SpeakerInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SubscribedAudioCodec extends GeneratedMessageLite<SubscribedAudioCodec, Builder> implements SubscribedAudioCodecOrBuilder {
        public static final int CODEC_FIELD_NUMBER = 1;
        private static final SubscribedAudioCodec DEFAULT_INSTANCE;
        public static final int ENABLED_FIELD_NUMBER = 2;
        private static volatile Parser<SubscribedAudioCodec> PARSER;
        private String codec_ = ap.a(1095220027);
        private boolean enabled_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SubscribedAudioCodec, Builder> implements SubscribedAudioCodecOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SubscribedAudioCodec.DEFAULT_INSTANCE);
            }
        }

        static {
            SubscribedAudioCodec subscribedAudioCodec = new SubscribedAudioCodec();
            DEFAULT_INSTANCE = subscribedAudioCodec;
            GeneratedMessageLite.registerDefaultInstance(SubscribedAudioCodec.class, subscribedAudioCodec);
        }

        private SubscribedAudioCodec() {
        }

        private void clearCodec() {
            this.codec_ = getDefaultInstance().getCodec();
        }

        private void clearEnabled() {
            this.enabled_ = false;
        }

        public static SubscribedAudioCodec getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SubscribedAudioCodec parseDelimitedFrom(InputStream inputStream) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscribedAudioCodec parseFrom(ByteBuffer byteBuffer) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SubscribedAudioCodec> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCodec(String str) {
            str.getClass();
            this.codec_ = str;
        }

        private void setCodecBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.codec_ = byteString.L();
        }

        private void setEnabled(boolean z) {
            this.enabled_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SubscribedAudioCodec();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002\u0007", new Object[]{"codec_", "enabled_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SubscribedAudioCodec> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SubscribedAudioCodec.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getCodec() {
            return this.codec_;
        }

        public ByteString getCodecBytes() {
            return ByteString.n(this.codec_);
        }

        public boolean getEnabled() {
            return this.enabled_;
        }

        public static Builder newBuilder(SubscribedAudioCodec subscribedAudioCodec) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(subscribedAudioCodec);
        }

        public static SubscribedAudioCodec parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscribedAudioCodec parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SubscribedAudioCodec parseFrom(ByteString byteString) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SubscribedAudioCodec parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SubscribedAudioCodec parseFrom(byte[] bArr) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SubscribedAudioCodec parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SubscribedAudioCodec parseFrom(InputStream inputStream) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SubscribedAudioCodec parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SubscribedAudioCodec parseFrom(CodedInputStream codedInputStream) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SubscribedAudioCodec parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SubscribedAudioCodec) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SubscribedAudioCodecOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SubscriptionError implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<SubscriptionError>() { // from class: livekit.LivekitModels.SubscriptionError.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SubscriptionError findValueByNumber(int i) {
                return SubscriptionError.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SubscriptionErrorVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SubscriptionErrorVerifier();

            private SubscriptionErrorVerifier() {
            }

            public boolean isInRange(int i) {
                return SubscriptionError.b(i) != null;
            }
        }

        SubscriptionError(int i) {
            this.a = i;
        }

        public static SubscriptionError b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TimedVersion extends GeneratedMessageLite<TimedVersion, Builder> implements TimedVersionOrBuilder {
        private static final TimedVersion DEFAULT_INSTANCE;
        private static volatile Parser<TimedVersion> PARSER = null;
        public static final int TICKS_FIELD_NUMBER = 2;
        public static final int UNIX_MICRO_FIELD_NUMBER = 1;
        private int ticks_;
        private long unixMicro_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TimedVersion, Builder> implements TimedVersionOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TimedVersion.DEFAULT_INSTANCE);
            }
        }

        static {
            TimedVersion timedVersion = new TimedVersion();
            DEFAULT_INSTANCE = timedVersion;
            GeneratedMessageLite.registerDefaultInstance(TimedVersion.class, timedVersion);
        }

        private TimedVersion() {
        }

        private void clearTicks() {
            this.ticks_ = 0;
        }

        private void clearUnixMicro() {
            this.unixMicro_ = 0L;
        }

        public static TimedVersion getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TimedVersion parseDelimitedFrom(InputStream inputStream) {
            return (TimedVersion) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TimedVersion parseFrom(ByteBuffer byteBuffer) {
            return (TimedVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TimedVersion> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setTicks(int i) {
            this.ticks_ = i;
        }

        private void setUnixMicro(long j) {
            this.unixMicro_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TimedVersion();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0002\u0002\u0004", new Object[]{ap.a(699550706), ap.a(1024724780)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TimedVersion> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TimedVersion.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getTicks() {
            return this.ticks_;
        }

        public long getUnixMicro() {
            return this.unixMicro_;
        }

        public static Builder newBuilder(TimedVersion timedVersion) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(timedVersion);
        }

        public static TimedVersion parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TimedVersion) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TimedVersion parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TimedVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TimedVersion parseFrom(ByteString byteString) {
            return (TimedVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TimedVersion parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TimedVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TimedVersion parseFrom(byte[] bArr) {
            return (TimedVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TimedVersion parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TimedVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TimedVersion parseFrom(InputStream inputStream) {
            return (TimedVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TimedVersion parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TimedVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TimedVersion parseFrom(CodedInputStream codedInputStream) {
            return (TimedVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TimedVersion parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TimedVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TimedVersionOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TokenPagination extends GeneratedMessageLite<TokenPagination, Builder> implements TokenPaginationOrBuilder {
        private static final TokenPagination DEFAULT_INSTANCE;
        private static volatile Parser<TokenPagination> PARSER = null;
        public static final int TOKEN_FIELD_NUMBER = 1;
        private String token_ = ap.a(150587809);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TokenPagination, Builder> implements TokenPaginationOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TokenPagination.DEFAULT_INSTANCE);
            }
        }

        static {
            TokenPagination tokenPagination = new TokenPagination();
            DEFAULT_INSTANCE = tokenPagination;
            GeneratedMessageLite.registerDefaultInstance(TokenPagination.class, tokenPagination);
        }

        private TokenPagination() {
        }

        private void clearToken() {
            this.token_ = getDefaultInstance().getToken();
        }

        public static TokenPagination getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TokenPagination parseDelimitedFrom(InputStream inputStream) {
            return (TokenPagination) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TokenPagination parseFrom(ByteBuffer byteBuffer) {
            return (TokenPagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TokenPagination> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setToken(String str) {
            str.getClass();
            this.token_ = str;
        }

        private void setTokenBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.token_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TokenPagination();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"token_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TokenPagination> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TokenPagination.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getToken() {
            return this.token_;
        }

        public ByteString getTokenBytes() {
            return ByteString.n(this.token_);
        }

        public static Builder newBuilder(TokenPagination tokenPagination) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(tokenPagination);
        }

        public static TokenPagination parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenPagination) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TokenPagination parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenPagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TokenPagination parseFrom(ByteString byteString) {
            return (TokenPagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TokenPagination parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenPagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TokenPagination parseFrom(byte[] bArr) {
            return (TokenPagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TokenPagination parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenPagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TokenPagination parseFrom(InputStream inputStream) {
            return (TokenPagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TokenPagination parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenPagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TokenPagination parseFrom(CodedInputStream codedInputStream) {
            return (TokenPagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TokenPagination parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenPagination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TokenPaginationOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TrackInfo extends GeneratedMessageLite<TrackInfo, Builder> implements TrackInfoOrBuilder {
        public static final int AUDIO_FEATURES_FIELD_NUMBER = 19;
        public static final int BACKUP_CODEC_POLICY_FIELD_NUMBER = 20;
        public static final int CODECS_FIELD_NUMBER = 13;
        private static final TrackInfo DEFAULT_INSTANCE;
        public static final int DISABLE_DTX_FIELD_NUMBER = 8;
        public static final int DISABLE_RED_FIELD_NUMBER = 15;
        public static final int ENCRYPTION_FIELD_NUMBER = 16;
        public static final int HEIGHT_FIELD_NUMBER = 6;
        public static final int LAYERS_FIELD_NUMBER = 10;
        public static final int MID_FIELD_NUMBER = 12;
        public static final int MIME_TYPE_FIELD_NUMBER = 11;
        public static final int MUTED_FIELD_NUMBER = 4;
        public static final int NAME_FIELD_NUMBER = 3;
        private static volatile Parser<TrackInfo> PARSER = null;
        public static final int SID_FIELD_NUMBER = 1;
        public static final int SIMULCAST_FIELD_NUMBER = 7;
        public static final int SOURCE_FIELD_NUMBER = 9;
        public static final int STEREO_FIELD_NUMBER = 14;
        public static final int STREAM_FIELD_NUMBER = 17;
        public static final int TYPE_FIELD_NUMBER = 2;
        public static final int VERSION_FIELD_NUMBER = 18;
        public static final int WIDTH_FIELD_NUMBER = 5;
        private static final Internal.ListAdapter.Converter<Integer, AudioTrackFeature> audioFeatures_converter_ = new Internal.ListAdapter.Converter<Integer, AudioTrackFeature>() { // from class: livekit.LivekitModels.TrackInfo.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public AudioTrackFeature convert(Integer num) {
                AudioTrackFeature audioTrackFeatureB = AudioTrackFeature.b(num.intValue());
                return audioTrackFeatureB == null ? AudioTrackFeature.i : audioTrackFeatureB;
            }
        };
        private int audioFeaturesMemoizedSerializedSize;
        private Internal.IntList audioFeatures_;
        private int backupCodecPolicy_;
        private Internal.ProtobufList<SimulcastCodecInfo> codecs_;
        private boolean disableDtx_;
        private boolean disableRed_;
        private int encryption_;
        private int height_;
        private Internal.ProtobufList<VideoLayer> layers_;
        private String mid_;
        private String mimeType_;
        private boolean muted_;
        private String name_;
        private String sid_;
        private boolean simulcast_;
        private int source_;
        private boolean stereo_;
        private String stream_;
        private int type_;
        private TimedVersion version_;
        private int width_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TrackInfo, Builder> implements TrackInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TrackInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            TrackInfo trackInfo = new TrackInfo();
            DEFAULT_INSTANCE = trackInfo;
            GeneratedMessageLite.registerDefaultInstance(TrackInfo.class, trackInfo);
        }

        private TrackInfo() {
            String strA = ap.a(2058979331);
            this.sid_ = strA;
            this.name_ = strA;
            this.layers_ = GeneratedMessageLite.emptyProtobufList();
            this.mimeType_ = strA;
            this.mid_ = strA;
            this.codecs_ = GeneratedMessageLite.emptyProtobufList();
            this.stream_ = strA;
            this.audioFeatures_ = GeneratedMessageLite.emptyIntList();
        }

        private void addAllAudioFeatures(Iterable<? extends AudioTrackFeature> iterable) {
            ensureAudioFeaturesIsMutable();
            Iterator<? extends AudioTrackFeature> it = iterable.iterator();
            while (it.hasNext()) {
                this.audioFeatures_.addInt(it.next().getNumber());
            }
        }

        private void addAllAudioFeaturesValue(Iterable<Integer> iterable) {
            ensureAudioFeaturesIsMutable();
            Iterator<Integer> it = iterable.iterator();
            while (it.hasNext()) {
                this.audioFeatures_.addInt(it.next().intValue());
            }
        }

        private void addAllCodecs(Iterable<? extends SimulcastCodecInfo> iterable) {
            ensureCodecsIsMutable();
            AbstractMessageLite.addAll(iterable, this.codecs_);
        }

        private void addAllLayers(Iterable<? extends VideoLayer> iterable) {
            ensureLayersIsMutable();
            AbstractMessageLite.addAll(iterable, this.layers_);
        }

        private void addAudioFeatures(AudioTrackFeature audioTrackFeature) {
            audioTrackFeature.getClass();
            ensureAudioFeaturesIsMutable();
            this.audioFeatures_.addInt(audioTrackFeature.getNumber());
        }

        private void addAudioFeaturesValue(int i) {
            ensureAudioFeaturesIsMutable();
            this.audioFeatures_.addInt(i);
        }

        private void addCodecs(SimulcastCodecInfo simulcastCodecInfo) {
            simulcastCodecInfo.getClass();
            ensureCodecsIsMutable();
            this.codecs_.add(simulcastCodecInfo);
        }

        private void addLayers(VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(videoLayer);
        }

        private void clearAudioFeatures() {
            this.audioFeatures_ = GeneratedMessageLite.emptyIntList();
        }

        private void clearBackupCodecPolicy() {
            this.backupCodecPolicy_ = 0;
        }

        private void clearCodecs() {
            this.codecs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearDisableDtx() {
            this.disableDtx_ = false;
        }

        private void clearDisableRed() {
            this.disableRed_ = false;
        }

        private void clearEncryption() {
            this.encryption_ = 0;
        }

        private void clearHeight() {
            this.height_ = 0;
        }

        private void clearLayers() {
            this.layers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearMid() {
            this.mid_ = getDefaultInstance().getMid();
        }

        private void clearMimeType() {
            this.mimeType_ = getDefaultInstance().getMimeType();
        }

        private void clearMuted() {
            this.muted_ = false;
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearSid() {
            this.sid_ = getDefaultInstance().getSid();
        }

        private void clearSimulcast() {
            this.simulcast_ = false;
        }

        private void clearSource() {
            this.source_ = 0;
        }

        private void clearStereo() {
            this.stereo_ = false;
        }

        private void clearStream() {
            this.stream_ = getDefaultInstance().getStream();
        }

        private void clearType() {
            this.type_ = 0;
        }

        private void clearVersion() {
            this.version_ = null;
        }

        private void clearWidth() {
            this.width_ = 0;
        }

        private void ensureAudioFeaturesIsMutable() {
            Internal.IntList intList = this.audioFeatures_;
            if (intList.isModifiable()) {
                return;
            }
            this.audioFeatures_ = GeneratedMessageLite.mutableCopy(intList);
        }

        private void ensureCodecsIsMutable() {
            Internal.ProtobufList<SimulcastCodecInfo> protobufList = this.codecs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.codecs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureLayersIsMutable() {
            Internal.ProtobufList<VideoLayer> protobufList = this.layers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.layers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static TrackInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeVersion(TimedVersion timedVersion) {
            timedVersion.getClass();
            TimedVersion timedVersion2 = this.version_;
            if (timedVersion2 == null || timedVersion2 == TimedVersion.getDefaultInstance()) {
                this.version_ = timedVersion;
            } else {
                this.version_ = (TimedVersion) ((TimedVersion.Builder) TimedVersion.newBuilder(this.version_).v(timedVersion)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TrackInfo parseDelimitedFrom(InputStream inputStream) {
            return (TrackInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackInfo parseFrom(ByteBuffer byteBuffer) {
            return (TrackInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TrackInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeCodecs(int i) {
            ensureCodecsIsMutable();
            this.codecs_.remove(i);
        }

        private void removeLayers(int i) {
            ensureLayersIsMutable();
            this.layers_.remove(i);
        }

        private void setAudioFeatures(int i, AudioTrackFeature audioTrackFeature) {
            audioTrackFeature.getClass();
            ensureAudioFeaturesIsMutable();
            this.audioFeatures_.setInt(i, audioTrackFeature.getNumber());
        }

        private void setAudioFeaturesValue(int i, int i2) {
            ensureAudioFeaturesIsMutable();
            this.audioFeatures_.setInt(i, i2);
        }

        private void setBackupCodecPolicy(BackupCodecPolicy backupCodecPolicy) {
            this.backupCodecPolicy_ = backupCodecPolicy.getNumber();
        }

        private void setBackupCodecPolicyValue(int i) {
            this.backupCodecPolicy_ = i;
        }

        private void setCodecs(int i, SimulcastCodecInfo simulcastCodecInfo) {
            simulcastCodecInfo.getClass();
            ensureCodecsIsMutable();
            this.codecs_.set(i, simulcastCodecInfo);
        }

        private void setDisableDtx(boolean z) {
            this.disableDtx_ = z;
        }

        private void setDisableRed(boolean z) {
            this.disableRed_ = z;
        }

        private void setEncryption(Encryption.Type type) {
            this.encryption_ = type.getNumber();
        }

        private void setEncryptionValue(int i) {
            this.encryption_ = i;
        }

        private void setHeight(int i) {
            this.height_ = i;
        }

        private void setLayers(int i, VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.set(i, videoLayer);
        }

        private void setMid(String str) {
            str.getClass();
            this.mid_ = str;
        }

        private void setMidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.mid_ = byteString.L();
        }

        private void setMimeType(String str) {
            str.getClass();
            this.mimeType_ = str;
        }

        private void setMimeTypeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.mimeType_ = byteString.L();
        }

        private void setMuted(boolean z) {
            this.muted_ = z;
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setSid(String str) {
            str.getClass();
            this.sid_ = str;
        }

        private void setSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sid_ = byteString.L();
        }

        private void setSimulcast(boolean z) {
            this.simulcast_ = z;
        }

        private void setSource(TrackSource trackSource) {
            this.source_ = trackSource.getNumber();
        }

        private void setSourceValue(int i) {
            this.source_ = i;
        }

        private void setStereo(boolean z) {
            this.stereo_ = z;
        }

        private void setStream(String str) {
            str.getClass();
            this.stream_ = str;
        }

        private void setStreamBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.stream_ = byteString.L();
        }

        private void setType(TrackType trackType) {
            this.type_ = trackType.getNumber();
        }

        private void setTypeValue(int i) {
            this.type_ = i;
        }

        private void setVersion(TimedVersion timedVersion) {
            timedVersion.getClass();
            this.version_ = timedVersion;
        }

        private void setWidth(int i) {
            this.width_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new TrackInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0014\u0000\u0000\u0001\u0014\u0014\u0000\u0003\u0000\u0001Ȉ\u0002\f\u0003Ȉ\u0004\u0007\u0005\u000b\u0006\u000b\u0007\u0007\b\u0007\t\f\n\u001b\u000bȈ\fȈ\r\u001b\u000e\u0007\u000f\u0007\u0010\f\u0011Ȉ\u0012\t\u0013,\u0014\f", new Object[]{"sid_", "type_", "name_", "muted_", "width_", "height_", "simulcast_", "disableDtx_", "source_", "layers_", VideoLayer.class, "mimeType_", "mid_", "codecs_", SimulcastCodecInfo.class, "stereo_", "disableRed_", "encryption_", "stream_", "version_", "audioFeatures_", "backupCodecPolicy_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TrackInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TrackInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AudioTrackFeature getAudioFeatures(int i) {
            AudioTrackFeature audioTrackFeatureB = AudioTrackFeature.b(this.audioFeatures_.getInt(i));
            return audioTrackFeatureB == null ? AudioTrackFeature.i : audioTrackFeatureB;
        }

        public int getAudioFeaturesCount() {
            return this.audioFeatures_.size();
        }

        public List<AudioTrackFeature> getAudioFeaturesList() {
            return new Internal.ListAdapter(this.audioFeatures_, audioFeatures_converter_);
        }

        public int getAudioFeaturesValue(int i) {
            return this.audioFeatures_.getInt(i);
        }

        public List<Integer> getAudioFeaturesValueList() {
            return this.audioFeatures_;
        }

        public BackupCodecPolicy getBackupCodecPolicy() {
            BackupCodecPolicy backupCodecPolicyB = BackupCodecPolicy.b(this.backupCodecPolicy_);
            return backupCodecPolicyB == null ? BackupCodecPolicy.e : backupCodecPolicyB;
        }

        public int getBackupCodecPolicyValue() {
            return this.backupCodecPolicy_;
        }

        public SimulcastCodecInfo getCodecs(int i) {
            return (SimulcastCodecInfo) this.codecs_.get(i);
        }

        public int getCodecsCount() {
            return this.codecs_.size();
        }

        public List<SimulcastCodecInfo> getCodecsList() {
            return this.codecs_;
        }

        public SimulcastCodecInfoOrBuilder getCodecsOrBuilder(int i) {
            return (SimulcastCodecInfoOrBuilder) this.codecs_.get(i);
        }

        public List<? extends SimulcastCodecInfoOrBuilder> getCodecsOrBuilderList() {
            return this.codecs_;
        }

        @Deprecated
        public boolean getDisableDtx() {
            return this.disableDtx_;
        }

        public boolean getDisableRed() {
            return this.disableRed_;
        }

        public Encryption.Type getEncryption() {
            Encryption.Type typeB = Encryption.Type.b(this.encryption_);
            return typeB == null ? Encryption.Type.e : typeB;
        }

        public int getEncryptionValue() {
            return this.encryption_;
        }

        @Deprecated
        public int getHeight() {
            return this.height_;
        }

        @Deprecated
        public VideoLayer getLayers(int i) {
            return (VideoLayer) this.layers_.get(i);
        }

        @Deprecated
        public int getLayersCount() {
            return this.layers_.size();
        }

        @Deprecated
        public List<VideoLayer> getLayersList() {
            return this.layers_;
        }

        @Deprecated
        public VideoLayerOrBuilder getLayersOrBuilder(int i) {
            return (VideoLayerOrBuilder) this.layers_.get(i);
        }

        @Deprecated
        public List<? extends VideoLayerOrBuilder> getLayersOrBuilderList() {
            return this.layers_;
        }

        public String getMid() {
            return this.mid_;
        }

        public ByteString getMidBytes() {
            return ByteString.n(this.mid_);
        }

        public String getMimeType() {
            return this.mimeType_;
        }

        public ByteString getMimeTypeBytes() {
            return ByteString.n(this.mimeType_);
        }

        public boolean getMuted() {
            return this.muted_;
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getSid() {
            return this.sid_;
        }

        public ByteString getSidBytes() {
            return ByteString.n(this.sid_);
        }

        @Deprecated
        public boolean getSimulcast() {
            return this.simulcast_;
        }

        public TrackSource getSource() {
            TrackSource trackSourceB = TrackSource.b(this.source_);
            return trackSourceB == null ? TrackSource.g : trackSourceB;
        }

        public int getSourceValue() {
            return this.source_;
        }

        @Deprecated
        public boolean getStereo() {
            return this.stereo_;
        }

        public String getStream() {
            return this.stream_;
        }

        public ByteString getStreamBytes() {
            return ByteString.n(this.stream_);
        }

        public TrackType getType() {
            TrackType trackTypeB = TrackType.b(this.type_);
            return trackTypeB == null ? TrackType.e : trackTypeB;
        }

        public int getTypeValue() {
            return this.type_;
        }

        public TimedVersion getVersion() {
            TimedVersion timedVersion = this.version_;
            return timedVersion == null ? TimedVersion.getDefaultInstance() : timedVersion;
        }

        @Deprecated
        public int getWidth() {
            return this.width_;
        }

        public boolean hasVersion() {
            return this.version_ != null;
        }

        public static Builder newBuilder(TrackInfo trackInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(trackInfo);
        }

        public static TrackInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TrackInfo parseFrom(ByteString byteString) {
            return (TrackInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addCodecs(int i, SimulcastCodecInfo simulcastCodecInfo) {
            simulcastCodecInfo.getClass();
            ensureCodecsIsMutable();
            this.codecs_.add(i, simulcastCodecInfo);
        }

        private void addLayers(int i, VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(i, videoLayer);
        }

        public static TrackInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TrackInfo parseFrom(byte[] bArr) {
            return (TrackInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TrackInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TrackInfo parseFrom(InputStream inputStream) {
            return (TrackInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackInfo parseFrom(CodedInputStream codedInputStream) {
            return (TrackInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TrackInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TrackInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum TrackSource implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(4),
        g(-1);

        private static final Internal.EnumLiteMap h = new Internal.EnumLiteMap<TrackSource>() { // from class: livekit.LivekitModels.TrackSource.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public TrackSource findValueByNumber(int i2) {
                return TrackSource.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class TrackSourceVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new TrackSourceVerifier();

            private TrackSourceVerifier() {
            }

            public boolean isInRange(int i) {
                return TrackSource.b(i) != null;
            }
        }

        TrackSource(int i2) {
            this.a = i2;
        }

        public static TrackSource b(int i2) {
            if (i2 == 0) {
                return b;
            }
            if (i2 == 1) {
                return c;
            }
            if (i2 == 2) {
                return d;
            }
            if (i2 == 3) {
                return e;
            }
            if (i2 != 4) {
                return null;
            }
            return f;
        }

        public final int getNumber() {
            if (this != g) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum TrackType implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<TrackType>() { // from class: livekit.LivekitModels.TrackType.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public TrackType findValueByNumber(int i) {
                return TrackType.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class TrackTypeVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new TrackTypeVerifier();

            private TrackTypeVerifier() {
            }

            public boolean isInRange(int i) {
                return TrackType.b(i) != null;
            }
        }

        TrackType(int i) {
            this.a = i;
        }

        public static TrackType b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class Transcription extends GeneratedMessageLite<Transcription, Builder> implements TranscriptionOrBuilder {
        private static final Transcription DEFAULT_INSTANCE;
        private static volatile Parser<Transcription> PARSER = null;
        public static final int SEGMENTS_FIELD_NUMBER = 4;
        public static final int TRACK_ID_FIELD_NUMBER = 3;
        public static final int TRANSCRIBED_PARTICIPANT_IDENTITY_FIELD_NUMBER = 2;
        private Internal.ProtobufList<TranscriptionSegment> segments_;
        private String trackId_;
        private String transcribedParticipantIdentity_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<Transcription, Builder> implements TranscriptionOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(Transcription.DEFAULT_INSTANCE);
            }
        }

        static {
            Transcription transcription = new Transcription();
            DEFAULT_INSTANCE = transcription;
            GeneratedMessageLite.registerDefaultInstance(Transcription.class, transcription);
        }

        private Transcription() {
            String strA = ap.a(1549877876);
            this.transcribedParticipantIdentity_ = strA;
            this.trackId_ = strA;
            this.segments_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllSegments(Iterable<? extends TranscriptionSegment> iterable) {
            ensureSegmentsIsMutable();
            AbstractMessageLite.addAll(iterable, this.segments_);
        }

        private void addSegments(TranscriptionSegment transcriptionSegment) {
            transcriptionSegment.getClass();
            ensureSegmentsIsMutable();
            this.segments_.add(transcriptionSegment);
        }

        private void clearSegments() {
            this.segments_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearTrackId() {
            this.trackId_ = getDefaultInstance().getTrackId();
        }

        private void clearTranscribedParticipantIdentity() {
            this.transcribedParticipantIdentity_ = getDefaultInstance().getTranscribedParticipantIdentity();
        }

        private void ensureSegmentsIsMutable() {
            Internal.ProtobufList<TranscriptionSegment> protobufList = this.segments_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.segments_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static Transcription getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static Transcription parseDelimitedFrom(InputStream inputStream) {
            return (Transcription) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Transcription parseFrom(ByteBuffer byteBuffer) {
            return (Transcription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<Transcription> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSegments(int i) {
            ensureSegmentsIsMutable();
            this.segments_.remove(i);
        }

        private void setSegments(int i, TranscriptionSegment transcriptionSegment) {
            transcriptionSegment.getClass();
            ensureSegmentsIsMutable();
            this.segments_.set(i, transcriptionSegment);
        }

        private void setTrackId(String str) {
            str.getClass();
            this.trackId_ = str;
        }

        private void setTrackIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackId_ = byteString.L();
        }

        private void setTranscribedParticipantIdentity(String str) {
            str.getClass();
            this.transcribedParticipantIdentity_ = str;
        }

        private void setTranscribedParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.transcribedParticipantIdentity_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new Transcription();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0002\u0004\u0003\u0000\u0001\u0000\u0002Ȉ\u0003Ȉ\u0004\u001b", new Object[]{"transcribedParticipantIdentity_", "trackId_", "segments_", TranscriptionSegment.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<Transcription> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (Transcription.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public TranscriptionSegment getSegments(int i) {
            return (TranscriptionSegment) this.segments_.get(i);
        }

        public int getSegmentsCount() {
            return this.segments_.size();
        }

        public List<TranscriptionSegment> getSegmentsList() {
            return this.segments_;
        }

        public TranscriptionSegmentOrBuilder getSegmentsOrBuilder(int i) {
            return (TranscriptionSegmentOrBuilder) this.segments_.get(i);
        }

        public List<? extends TranscriptionSegmentOrBuilder> getSegmentsOrBuilderList() {
            return this.segments_;
        }

        public String getTrackId() {
            return this.trackId_;
        }

        public ByteString getTrackIdBytes() {
            return ByteString.n(this.trackId_);
        }

        public String getTranscribedParticipantIdentity() {
            return this.transcribedParticipantIdentity_;
        }

        public ByteString getTranscribedParticipantIdentityBytes() {
            return ByteString.n(this.transcribedParticipantIdentity_);
        }

        public static Builder newBuilder(Transcription transcription) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(transcription);
        }

        public static Transcription parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Transcription) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Transcription parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (Transcription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static Transcription parseFrom(ByteString byteString) {
            return (Transcription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSegments(int i, TranscriptionSegment transcriptionSegment) {
            transcriptionSegment.getClass();
            ensureSegmentsIsMutable();
            this.segments_.add(i, transcriptionSegment);
        }

        public static Transcription parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (Transcription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static Transcription parseFrom(byte[] bArr) {
            return (Transcription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static Transcription parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (Transcription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static Transcription parseFrom(InputStream inputStream) {
            return (Transcription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Transcription parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Transcription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Transcription parseFrom(CodedInputStream codedInputStream) {
            return (Transcription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static Transcription parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Transcription) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TranscriptionOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TranscriptionSegment extends GeneratedMessageLite<TranscriptionSegment, Builder> implements TranscriptionSegmentOrBuilder {
        private static final TranscriptionSegment DEFAULT_INSTANCE;
        public static final int END_TIME_FIELD_NUMBER = 4;
        public static final int FINAL_FIELD_NUMBER = 5;
        public static final int ID_FIELD_NUMBER = 1;
        public static final int LANGUAGE_FIELD_NUMBER = 6;
        private static volatile Parser<TranscriptionSegment> PARSER = null;
        public static final int START_TIME_FIELD_NUMBER = 3;
        public static final int TEXT_FIELD_NUMBER = 2;
        private long endTime_;
        private boolean final_;
        private String id_;
        private String language_;
        private long startTime_;
        private String text_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TranscriptionSegment, Builder> implements TranscriptionSegmentOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TranscriptionSegment.DEFAULT_INSTANCE);
            }
        }

        static {
            TranscriptionSegment transcriptionSegment = new TranscriptionSegment();
            DEFAULT_INSTANCE = transcriptionSegment;
            GeneratedMessageLite.registerDefaultInstance(TranscriptionSegment.class, transcriptionSegment);
        }

        private TranscriptionSegment() {
            String strA = ap.a(173936653);
            this.id_ = strA;
            this.text_ = strA;
            this.language_ = strA;
        }

        private void clearEndTime() {
            this.endTime_ = 0L;
        }

        private void clearFinal() {
            this.final_ = false;
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearLanguage() {
            this.language_ = getDefaultInstance().getLanguage();
        }

        private void clearStartTime() {
            this.startTime_ = 0L;
        }

        private void clearText() {
            this.text_ = getDefaultInstance().getText();
        }

        public static TranscriptionSegment getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TranscriptionSegment parseDelimitedFrom(InputStream inputStream) {
            return (TranscriptionSegment) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TranscriptionSegment parseFrom(ByteBuffer byteBuffer) {
            return (TranscriptionSegment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TranscriptionSegment> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setEndTime(long j) {
            this.endTime_ = j;
        }

        private void setFinal(boolean z) {
            this.final_ = z;
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setLanguage(String str) {
            str.getClass();
            this.language_ = str;
        }

        private void setLanguageBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.language_ = byteString.L();
        }

        private void setStartTime(long j) {
            this.startTime_ = j;
        }

        private void setText(String str) {
            str.getClass();
            this.text_ = str;
        }

        private void setTextBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.text_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TranscriptionSegment();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\u0003\u0004\u0003\u0005\u0007\u0006Ȉ", new Object[]{"id_", "text_", "startTime_", "endTime_", "final_", "language_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TranscriptionSegment> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TranscriptionSegment.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getEndTime() {
            return this.endTime_;
        }

        public boolean getFinal() {
            return this.final_;
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public String getLanguage() {
            return this.language_;
        }

        public ByteString getLanguageBytes() {
            return ByteString.n(this.language_);
        }

        public long getStartTime() {
            return this.startTime_;
        }

        public String getText() {
            return this.text_;
        }

        public ByteString getTextBytes() {
            return ByteString.n(this.text_);
        }

        public static Builder newBuilder(TranscriptionSegment transcriptionSegment) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(transcriptionSegment);
        }

        public static TranscriptionSegment parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TranscriptionSegment) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TranscriptionSegment parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TranscriptionSegment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TranscriptionSegment parseFrom(ByteString byteString) {
            return (TranscriptionSegment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TranscriptionSegment parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TranscriptionSegment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TranscriptionSegment parseFrom(byte[] bArr) {
            return (TranscriptionSegment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TranscriptionSegment parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TranscriptionSegment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TranscriptionSegment parseFrom(InputStream inputStream) {
            return (TranscriptionSegment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TranscriptionSegment parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TranscriptionSegment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TranscriptionSegment parseFrom(CodedInputStream codedInputStream) {
            return (TranscriptionSegment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TranscriptionSegment parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TranscriptionSegment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TranscriptionSegmentOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UserPacket extends GeneratedMessageLite<UserPacket, Builder> implements UserPacketOrBuilder {
        private static final UserPacket DEFAULT_INSTANCE;
        public static final int DESTINATION_IDENTITIES_FIELD_NUMBER = 6;
        public static final int DESTINATION_SIDS_FIELD_NUMBER = 3;
        public static final int END_TIME_FIELD_NUMBER = 10;
        public static final int ID_FIELD_NUMBER = 8;
        public static final int NONCE_FIELD_NUMBER = 11;
        private static volatile Parser<UserPacket> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 5;
        public static final int PARTICIPANT_SID_FIELD_NUMBER = 1;
        public static final int PAYLOAD_FIELD_NUMBER = 2;
        public static final int START_TIME_FIELD_NUMBER = 9;
        public static final int TOPIC_FIELD_NUMBER = 4;
        private int bitField0_;
        private Internal.ProtobufList<String> destinationIdentities_;
        private Internal.ProtobufList<String> destinationSids_;
        private long endTime_;
        private String id_;
        private ByteString nonce_;
        private String participantIdentity_;
        private String participantSid_;
        private ByteString payload_;
        private long startTime_;
        private String topic_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UserPacket, Builder> implements UserPacketOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(Iterable iterable) {
                q();
                ((UserPacket) ((GeneratedMessageLite.Builder) this).b).addAllDestinationIdentities(iterable);
                return this;
            }

            public Builder B(String str) {
                q();
                ((UserPacket) ((GeneratedMessageLite.Builder) this).b).setParticipantSid(str);
                return this;
            }

            public Builder C(ByteString byteString) {
                q();
                ((UserPacket) ((GeneratedMessageLite.Builder) this).b).setPayload(byteString);
                return this;
            }

            public Builder D(String str) {
                q();
                ((UserPacket) ((GeneratedMessageLite.Builder) this).b).setTopic(str);
                return this;
            }

            private Builder() {
                super(UserPacket.DEFAULT_INSTANCE);
            }
        }

        static {
            UserPacket userPacket = new UserPacket();
            DEFAULT_INSTANCE = userPacket;
            GeneratedMessageLite.registerDefaultInstance(UserPacket.class, userPacket);
        }

        private UserPacket() {
            String strA = ap.a(1482318211);
            this.participantSid_ = strA;
            this.participantIdentity_ = strA;
            ByteString byteString = ByteString.b;
            this.payload_ = byteString;
            this.destinationSids_ = GeneratedMessageLite.emptyProtobufList();
            this.destinationIdentities_ = GeneratedMessageLite.emptyProtobufList();
            this.topic_ = strA;
            this.id_ = strA;
            this.nonce_ = byteString;
        }

        private void addAllDestinationIdentities(Iterable<String> iterable) {
            ensureDestinationIdentitiesIsMutable();
            AbstractMessageLite.addAll(iterable, this.destinationIdentities_);
        }

        private void addAllDestinationSids(Iterable<String> iterable) {
            ensureDestinationSidsIsMutable();
            AbstractMessageLite.addAll(iterable, this.destinationSids_);
        }

        private void addDestinationIdentities(String str) {
            str.getClass();
            ensureDestinationIdentitiesIsMutable();
            this.destinationIdentities_.add(str);
        }

        private void addDestinationIdentitiesBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureDestinationIdentitiesIsMutable();
            this.destinationIdentities_.add(byteString.L());
        }

        private void addDestinationSids(String str) {
            str.getClass();
            ensureDestinationSidsIsMutable();
            this.destinationSids_.add(str);
        }

        private void addDestinationSidsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureDestinationSidsIsMutable();
            this.destinationSids_.add(byteString.L());
        }

        private void clearDestinationIdentities() {
            this.destinationIdentities_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearDestinationSids() {
            this.destinationSids_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearEndTime() {
            this.bitField0_ &= -9;
            this.endTime_ = 0L;
        }

        private void clearId() {
            this.bitField0_ &= -3;
            this.id_ = getDefaultInstance().getId();
        }

        private void clearNonce() {
            this.nonce_ = getDefaultInstance().getNonce();
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearParticipantSid() {
            this.participantSid_ = getDefaultInstance().getParticipantSid();
        }

        private void clearPayload() {
            this.payload_ = getDefaultInstance().getPayload();
        }

        private void clearStartTime() {
            this.bitField0_ &= -5;
            this.startTime_ = 0L;
        }

        private void clearTopic() {
            this.bitField0_ &= -2;
            this.topic_ = getDefaultInstance().getTopic();
        }

        private void ensureDestinationIdentitiesIsMutable() {
            Internal.ProtobufList<String> protobufList = this.destinationIdentities_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.destinationIdentities_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureDestinationSidsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.destinationSids_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.destinationSids_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static UserPacket getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UserPacket parseDelimitedFrom(InputStream inputStream) {
            return (UserPacket) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UserPacket parseFrom(ByteBuffer byteBuffer) {
            return (UserPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UserPacket> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDestinationIdentities(int i, String str) {
            str.getClass();
            ensureDestinationIdentitiesIsMutable();
            this.destinationIdentities_.set(i, str);
        }

        private void setDestinationSids(int i, String str) {
            str.getClass();
            ensureDestinationSidsIsMutable();
            this.destinationSids_.set(i, str);
        }

        private void setEndTime(long j) {
            this.bitField0_ |= 8;
            this.endTime_ = j;
        }

        private void setId(String str) {
            str.getClass();
            this.bitField0_ |= 2;
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
            this.bitField0_ |= 2;
        }

        private void setNonce(ByteString byteString) {
            byteString.getClass();
            this.nonce_ = byteString;
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setParticipantSid(String str) {
            str.getClass();
            this.participantSid_ = str;
        }

        private void setParticipantSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantSid_ = byteString.L();
        }

        private void setPayload(ByteString byteString) {
            byteString.getClass();
            this.payload_ = byteString;
        }

        private void setStartTime(long j) {
            this.bitField0_ |= 4;
            this.startTime_ = j;
        }

        private void setTopic(String str) {
            str.getClass();
            this.bitField0_ |= 1;
            this.topic_ = str;
        }

        private void setTopicBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.topic_ = byteString.L();
            this.bitField0_ |= 1;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UserPacket();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\n\u0000\u0001\u0001\u000b\n\u0000\u0002\u0000\u0001Ȉ\u0002\n\u0003Ț\u0004ለ\u0000\u0005Ȉ\u0006Ț\bለ\u0001\tဃ\u0002\nဃ\u0003\u000b\n", new Object[]{"bitField0_", "participantSid_", "payload_", "destinationSids_", "topic_", "participantIdentity_", "destinationIdentities_", "id_", "startTime_", "endTime_", "nonce_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UserPacket> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UserPacket.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public String getDestinationIdentities(int i) {
            return (String) this.destinationIdentities_.get(i);
        }

        @Deprecated
        public ByteString getDestinationIdentitiesBytes(int i) {
            return ByteString.n((String) this.destinationIdentities_.get(i));
        }

        @Deprecated
        public int getDestinationIdentitiesCount() {
            return this.destinationIdentities_.size();
        }

        @Deprecated
        public List<String> getDestinationIdentitiesList() {
            return this.destinationIdentities_;
        }

        @Deprecated
        public String getDestinationSids(int i) {
            return (String) this.destinationSids_.get(i);
        }

        @Deprecated
        public ByteString getDestinationSidsBytes(int i) {
            return ByteString.n((String) this.destinationSids_.get(i));
        }

        @Deprecated
        public int getDestinationSidsCount() {
            return this.destinationSids_.size();
        }

        @Deprecated
        public List<String> getDestinationSidsList() {
            return this.destinationSids_;
        }

        public long getEndTime() {
            return this.endTime_;
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public ByteString getNonce() {
            return this.nonce_;
        }

        @Deprecated
        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        @Deprecated
        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        @Deprecated
        public String getParticipantSid() {
            return this.participantSid_;
        }

        @Deprecated
        public ByteString getParticipantSidBytes() {
            return ByteString.n(this.participantSid_);
        }

        public ByteString getPayload() {
            return this.payload_;
        }

        public long getStartTime() {
            return this.startTime_;
        }

        public String getTopic() {
            return this.topic_;
        }

        public ByteString getTopicBytes() {
            return ByteString.n(this.topic_);
        }

        public boolean hasEndTime() {
            return (this.bitField0_ & 8) != 0;
        }

        public boolean hasId() {
            return (this.bitField0_ & 2) != 0;
        }

        public boolean hasStartTime() {
            return (this.bitField0_ & 4) != 0;
        }

        public boolean hasTopic() {
            return (this.bitField0_ & 1) != 0;
        }

        public static Builder newBuilder(UserPacket userPacket) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(userPacket);
        }

        public static UserPacket parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UserPacket) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UserPacket parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UserPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UserPacket parseFrom(ByteString byteString) {
            return (UserPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UserPacket parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UserPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UserPacket parseFrom(byte[] bArr) {
            return (UserPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UserPacket parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UserPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UserPacket parseFrom(InputStream inputStream) {
            return (UserPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UserPacket parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UserPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UserPacket parseFrom(CodedInputStream codedInputStream) {
            return (UserPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UserPacket parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UserPacket) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UserPacketOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class VP8MungerState extends GeneratedMessageLite<VP8MungerState, Builder> implements VP8MungerStateOrBuilder {
        private static final VP8MungerState DEFAULT_INSTANCE;
        public static final int EXT_LAST_PICTURE_ID_FIELD_NUMBER = 1;
        public static final int KEY_IDX_USED_FIELD_NUMBER = 7;
        public static final int LAST_KEY_IDX_FIELD_NUMBER = 6;
        public static final int LAST_TL0_PIC_IDX_FIELD_NUMBER = 3;
        private static volatile Parser<VP8MungerState> PARSER = null;
        public static final int PICTURE_ID_USED_FIELD_NUMBER = 2;
        public static final int TID_USED_FIELD_NUMBER = 5;
        public static final int TL0_PIC_IDX_USED_FIELD_NUMBER = 4;
        private int extLastPictureId_;
        private boolean keyIdxUsed_;
        private int lastKeyIdx_;
        private int lastTl0PicIdx_;
        private boolean pictureIdUsed_;
        private boolean tidUsed_;
        private boolean tl0PicIdxUsed_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<VP8MungerState, Builder> implements VP8MungerStateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(VP8MungerState.DEFAULT_INSTANCE);
            }
        }

        static {
            VP8MungerState vP8MungerState = new VP8MungerState();
            DEFAULT_INSTANCE = vP8MungerState;
            GeneratedMessageLite.registerDefaultInstance(VP8MungerState.class, vP8MungerState);
        }

        private VP8MungerState() {
        }

        private void clearExtLastPictureId() {
            this.extLastPictureId_ = 0;
        }

        private void clearKeyIdxUsed() {
            this.keyIdxUsed_ = false;
        }

        private void clearLastKeyIdx() {
            this.lastKeyIdx_ = 0;
        }

        private void clearLastTl0PicIdx() {
            this.lastTl0PicIdx_ = 0;
        }

        private void clearPictureIdUsed() {
            this.pictureIdUsed_ = false;
        }

        private void clearTidUsed() {
            this.tidUsed_ = false;
        }

        private void clearTl0PicIdxUsed() {
            this.tl0PicIdxUsed_ = false;
        }

        public static VP8MungerState getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static VP8MungerState parseDelimitedFrom(InputStream inputStream) {
            return (VP8MungerState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static VP8MungerState parseFrom(ByteBuffer byteBuffer) {
            return (VP8MungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<VP8MungerState> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setExtLastPictureId(int i) {
            this.extLastPictureId_ = i;
        }

        private void setKeyIdxUsed(boolean z) {
            this.keyIdxUsed_ = z;
        }

        private void setLastKeyIdx(int i) {
            this.lastKeyIdx_ = i;
        }

        private void setLastTl0PicIdx(int i) {
            this.lastTl0PicIdx_ = i;
        }

        private void setPictureIdUsed(boolean z) {
            this.pictureIdUsed_ = z;
        }

        private void setTidUsed(boolean z) {
            this.tidUsed_ = z;
        }

        private void setTl0PicIdxUsed(boolean z) {
            this.tl0PicIdxUsed_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new VP8MungerState();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0000\u0000\u0001\u0007\u0007\u0000\u0000\u0000\u0001\u0004\u0002\u0007\u0003\u000b\u0004\u0007\u0005\u0007\u0006\u000b\u0007\u0007", new Object[]{ap.a(1402854437), ap.a(933495291), ap.a(1860144517), ap.a(2100634282), ap.a(1152373480), ap.a(812809437), ap.a(1034619901)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<VP8MungerState> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (VP8MungerState.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getExtLastPictureId() {
            return this.extLastPictureId_;
        }

        public boolean getKeyIdxUsed() {
            return this.keyIdxUsed_;
        }

        public int getLastKeyIdx() {
            return this.lastKeyIdx_;
        }

        public int getLastTl0PicIdx() {
            return this.lastTl0PicIdx_;
        }

        public boolean getPictureIdUsed() {
            return this.pictureIdUsed_;
        }

        public boolean getTidUsed() {
            return this.tidUsed_;
        }

        public boolean getTl0PicIdxUsed() {
            return this.tl0PicIdxUsed_;
        }

        public static Builder newBuilder(VP8MungerState vP8MungerState) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(vP8MungerState);
        }

        public static VP8MungerState parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (VP8MungerState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static VP8MungerState parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (VP8MungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static VP8MungerState parseFrom(ByteString byteString) {
            return (VP8MungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static VP8MungerState parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (VP8MungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static VP8MungerState parseFrom(byte[] bArr) {
            return (VP8MungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static VP8MungerState parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (VP8MungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static VP8MungerState parseFrom(InputStream inputStream) {
            return (VP8MungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static VP8MungerState parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (VP8MungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static VP8MungerState parseFrom(CodedInputStream codedInputStream) {
            return (VP8MungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static VP8MungerState parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (VP8MungerState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface VP8MungerStateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum VideoCodec implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(4),
        g(-1);

        private static final Internal.EnumLiteMap h = new Internal.EnumLiteMap<VideoCodec>() { // from class: livekit.LivekitModels.VideoCodec.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public VideoCodec findValueByNumber(int i2) {
                return VideoCodec.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class VideoCodecVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new VideoCodecVerifier();

            private VideoCodecVerifier() {
            }

            public boolean isInRange(int i) {
                return VideoCodec.b(i) != null;
            }
        }

        VideoCodec(int i2) {
            this.a = i2;
        }

        public static VideoCodec b(int i2) {
            if (i2 == 0) {
                return b;
            }
            if (i2 == 1) {
                return c;
            }
            if (i2 == 2) {
                return d;
            }
            if (i2 == 3) {
                return e;
            }
            if (i2 != 4) {
                return null;
            }
            return f;
        }

        public final int getNumber() {
            if (this != g) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class VideoConfiguration extends GeneratedMessageLite<VideoConfiguration, Builder> implements VideoConfigurationOrBuilder {
        private static final VideoConfiguration DEFAULT_INSTANCE;
        public static final int HARDWARE_ENCODER_FIELD_NUMBER = 1;
        private static volatile Parser<VideoConfiguration> PARSER;
        private int hardwareEncoder_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<VideoConfiguration, Builder> implements VideoConfigurationOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(VideoConfiguration.DEFAULT_INSTANCE);
            }
        }

        static {
            VideoConfiguration videoConfiguration = new VideoConfiguration();
            DEFAULT_INSTANCE = videoConfiguration;
            GeneratedMessageLite.registerDefaultInstance(VideoConfiguration.class, videoConfiguration);
        }

        private VideoConfiguration() {
        }

        private void clearHardwareEncoder() {
            this.hardwareEncoder_ = 0;
        }

        public static VideoConfiguration getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static VideoConfiguration parseDelimitedFrom(InputStream inputStream) {
            return (VideoConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static VideoConfiguration parseFrom(ByteBuffer byteBuffer) {
            return (VideoConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<VideoConfiguration> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setHardwareEncoder(ClientConfigSetting clientConfigSetting) {
            this.hardwareEncoder_ = clientConfigSetting.getNumber();
        }

        private void setHardwareEncoderValue(int i) {
            this.hardwareEncoder_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new VideoConfiguration();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\f", new Object[]{ap.a(281022573)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<VideoConfiguration> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (VideoConfiguration.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public ClientConfigSetting getHardwareEncoder() {
            ClientConfigSetting clientConfigSettingB = ClientConfigSetting.b(this.hardwareEncoder_);
            return clientConfigSettingB == null ? ClientConfigSetting.e : clientConfigSettingB;
        }

        public int getHardwareEncoderValue() {
            return this.hardwareEncoder_;
        }

        public static Builder newBuilder(VideoConfiguration videoConfiguration) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(videoConfiguration);
        }

        public static VideoConfiguration parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static VideoConfiguration parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static VideoConfiguration parseFrom(ByteString byteString) {
            return (VideoConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static VideoConfiguration parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static VideoConfiguration parseFrom(byte[] bArr) {
            return (VideoConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static VideoConfiguration parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static VideoConfiguration parseFrom(InputStream inputStream) {
            return (VideoConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static VideoConfiguration parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static VideoConfiguration parseFrom(CodedInputStream codedInputStream) {
            return (VideoConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static VideoConfiguration parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface VideoConfigurationOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class VideoLayer extends GeneratedMessageLite<VideoLayer, Builder> implements VideoLayerOrBuilder {
        public static final int BITRATE_FIELD_NUMBER = 4;
        private static final VideoLayer DEFAULT_INSTANCE;
        public static final int HEIGHT_FIELD_NUMBER = 3;
        private static volatile Parser<VideoLayer> PARSER = null;
        public static final int QUALITY_FIELD_NUMBER = 1;
        public static final int RID_FIELD_NUMBER = 7;
        public static final int SPATIAL_LAYER_FIELD_NUMBER = 6;
        public static final int SSRC_FIELD_NUMBER = 5;
        public static final int WIDTH_FIELD_NUMBER = 2;
        private int bitrate_;
        private int height_;
        private int quality_;
        private String rid_ = ap.a(1234943904);
        private int spatialLayer_;
        private int ssrc_;
        private int width_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<VideoLayer, Builder> implements VideoLayerOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            public Builder A(int i) {
                q();
                ((VideoLayer) ((GeneratedMessageLite.Builder) this).b).setBitrate(i);
                return this;
            }

            public Builder B(int i) {
                q();
                ((VideoLayer) ((GeneratedMessageLite.Builder) this).b).setHeight(i);
                return this;
            }

            public Builder C(VideoQuality videoQuality) {
                q();
                ((VideoLayer) ((GeneratedMessageLite.Builder) this).b).setQuality(videoQuality);
                return this;
            }

            public Builder D(int i) {
                q();
                ((VideoLayer) ((GeneratedMessageLite.Builder) this).b).setSsrc(i);
                return this;
            }

            public Builder E(int i) {
                q();
                ((VideoLayer) ((GeneratedMessageLite.Builder) this).b).setWidth(i);
                return this;
            }

            private Builder() {
                super(VideoLayer.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum Mode implements Internal.EnumLite {
            b(0),
            c(1),
            d(2),
            e(3),
            f(-1);

            private static final Internal.EnumLiteMap g = new Internal.EnumLiteMap<Mode>() { // from class: livekit.LivekitModels.VideoLayer.Mode.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public Mode findValueByNumber(int i) {
                    return Mode.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class ModeVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new ModeVerifier();

                private ModeVerifier() {
                }

                public boolean isInRange(int i) {
                    return Mode.b(i) != null;
                }
            }

            Mode(int i) {
                this.a = i;
            }

            public static Mode b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i == 1) {
                    return c;
                }
                if (i == 2) {
                    return d;
                }
                if (i != 3) {
                    return null;
                }
                return e;
            }

            public final int getNumber() {
                if (this != f) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        static {
            VideoLayer videoLayer = new VideoLayer();
            DEFAULT_INSTANCE = videoLayer;
            GeneratedMessageLite.registerDefaultInstance(VideoLayer.class, videoLayer);
        }

        private VideoLayer() {
        }

        private void clearBitrate() {
            this.bitrate_ = 0;
        }

        private void clearHeight() {
            this.height_ = 0;
        }

        private void clearQuality() {
            this.quality_ = 0;
        }

        private void clearRid() {
            this.rid_ = getDefaultInstance().getRid();
        }

        private void clearSpatialLayer() {
            this.spatialLayer_ = 0;
        }

        private void clearSsrc() {
            this.ssrc_ = 0;
        }

        private void clearWidth() {
            this.width_ = 0;
        }

        public static VideoLayer getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static VideoLayer parseDelimitedFrom(InputStream inputStream) {
            return (VideoLayer) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static VideoLayer parseFrom(ByteBuffer byteBuffer) {
            return (VideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<VideoLayer> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setBitrate(int i) {
            this.bitrate_ = i;
        }

        private void setHeight(int i) {
            this.height_ = i;
        }

        private void setQuality(VideoQuality videoQuality) {
            this.quality_ = videoQuality.getNumber();
        }

        private void setQualityValue(int i) {
            this.quality_ = i;
        }

        private void setRid(String str) {
            str.getClass();
            this.rid_ = str;
        }

        private void setRidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.rid_ = byteString.L();
        }

        private void setSpatialLayer(int i) {
            this.spatialLayer_ = i;
        }

        private void setSsrc(int i) {
            this.ssrc_ = i;
        }

        private void setWidth(int i) {
            this.width_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new VideoLayer();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0000\u0000\u0001\u0007\u0007\u0000\u0000\u0000\u0001\f\u0002\u000b\u0003\u000b\u0004\u000b\u0005\u000b\u0006\u0004\u0007Ȉ", new Object[]{"quality_", "width_", "height_", "bitrate_", "ssrc_", "spatialLayer_", "rid_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<VideoLayer> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (VideoLayer.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getBitrate() {
            return this.bitrate_;
        }

        public int getHeight() {
            return this.height_;
        }

        public VideoQuality getQuality() {
            VideoQuality videoQualityB = VideoQuality.b(this.quality_);
            return videoQualityB == null ? VideoQuality.f : videoQualityB;
        }

        public int getQualityValue() {
            return this.quality_;
        }

        public String getRid() {
            return this.rid_;
        }

        public ByteString getRidBytes() {
            return ByteString.n(this.rid_);
        }

        public int getSpatialLayer() {
            return this.spatialLayer_;
        }

        public int getSsrc() {
            return this.ssrc_;
        }

        public int getWidth() {
            return this.width_;
        }

        public static Builder newBuilder(VideoLayer videoLayer) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(videoLayer);
        }

        public static VideoLayer parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoLayer) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static VideoLayer parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static VideoLayer parseFrom(ByteString byteString) {
            return (VideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static VideoLayer parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static VideoLayer parseFrom(byte[] bArr) {
            return (VideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static VideoLayer parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static VideoLayer parseFrom(InputStream inputStream) {
            return (VideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static VideoLayer parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static VideoLayer parseFrom(CodedInputStream codedInputStream) {
            return (VideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static VideoLayer parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (VideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface VideoLayerOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum VideoQuality implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(-1);

        private static final Internal.EnumLiteMap g = new Internal.EnumLiteMap<VideoQuality>() { // from class: livekit.LivekitModels.VideoQuality.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public VideoQuality findValueByNumber(int i) {
                return VideoQuality.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class VideoQualityVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new VideoQualityVerifier();

            private VideoQualityVerifier() {
            }

            public boolean isInRange(int i) {
                return VideoQuality.b(i) != null;
            }
        }

        VideoQuality(int i) {
            this.a = i;
        }

        public static VideoQuality b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i == 2) {
                return d;
            }
            if (i != 3) {
                return null;
            }
            return e;
        }

        public final int getNumber() {
            if (this != f) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class WebhookConfig extends GeneratedMessageLite<WebhookConfig, Builder> implements WebhookConfigOrBuilder {
        private static final WebhookConfig DEFAULT_INSTANCE;
        private static volatile Parser<WebhookConfig> PARSER = null;
        public static final int SIGNING_KEY_FIELD_NUMBER = 2;
        public static final int URL_FIELD_NUMBER = 1;
        private String signingKey_;
        private String url_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<WebhookConfig, Builder> implements WebhookConfigOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(WebhookConfig.DEFAULT_INSTANCE);
            }
        }

        static {
            WebhookConfig webhookConfig = new WebhookConfig();
            DEFAULT_INSTANCE = webhookConfig;
            GeneratedMessageLite.registerDefaultInstance(WebhookConfig.class, webhookConfig);
        }

        private WebhookConfig() {
            String strA = ap.a(994063665);
            this.url_ = strA;
            this.signingKey_ = strA;
        }

        private void clearSigningKey() {
            this.signingKey_ = getDefaultInstance().getSigningKey();
        }

        private void clearUrl() {
            this.url_ = getDefaultInstance().getUrl();
        }

        public static WebhookConfig getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static WebhookConfig parseDelimitedFrom(InputStream inputStream) {
            return (WebhookConfig) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WebhookConfig parseFrom(ByteBuffer byteBuffer) {
            return (WebhookConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<WebhookConfig> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setSigningKey(String str) {
            str.getClass();
            this.signingKey_ = str;
        }

        private void setSigningKeyBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.signingKey_ = byteString.L();
        }

        private void setUrl(String str) {
            str.getClass();
            this.url_ = str;
        }

        private void setUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.url_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new WebhookConfig();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"url_", "signingKey_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<WebhookConfig> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (WebhookConfig.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getSigningKey() {
            return this.signingKey_;
        }

        public ByteString getSigningKeyBytes() {
            return ByteString.n(this.signingKey_);
        }

        public String getUrl() {
            return this.url_;
        }

        public ByteString getUrlBytes() {
            return ByteString.n(this.url_);
        }

        public static Builder newBuilder(WebhookConfig webhookConfig) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(webhookConfig);
        }

        public static WebhookConfig parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookConfig) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WebhookConfig parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static WebhookConfig parseFrom(ByteString byteString) {
            return (WebhookConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static WebhookConfig parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static WebhookConfig parseFrom(byte[] bArr) {
            return (WebhookConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static WebhookConfig parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static WebhookConfig parseFrom(InputStream inputStream) {
            return (WebhookConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WebhookConfig parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WebhookConfig parseFrom(CodedInputStream codedInputStream) {
            return (WebhookConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static WebhookConfig parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface WebhookConfigOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitModels() {
    }
}