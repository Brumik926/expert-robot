package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MapEntryLite;
import com.google.protobuf.MapFieldLite;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import com.google.protobuf.WireFormat;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import livekit.LivekitAgentDispatch;
import livekit.LivekitEgress;
import livekit.LivekitModels;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitRoom {

    /* JADX INFO: renamed from: livekit.LivekitRoom$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class CreateRoomRequest extends GeneratedMessageLite<CreateRoomRequest, Builder> implements CreateRoomRequestOrBuilder {
        public static final int AGENTS_FIELD_NUMBER = 14;
        private static final CreateRoomRequest DEFAULT_INSTANCE;
        public static final int DEPARTURE_TIMEOUT_FIELD_NUMBER = 10;
        public static final int EGRESS_FIELD_NUMBER = 6;
        public static final int EMPTY_TIMEOUT_FIELD_NUMBER = 2;
        public static final int MAX_PARTICIPANTS_FIELD_NUMBER = 3;
        public static final int MAX_PLAYOUT_DELAY_FIELD_NUMBER = 8;
        public static final int METADATA_FIELD_NUMBER = 5;
        public static final int MIN_PLAYOUT_DELAY_FIELD_NUMBER = 7;
        public static final int NAME_FIELD_NUMBER = 1;
        public static final int NODE_ID_FIELD_NUMBER = 4;
        private static volatile Parser<CreateRoomRequest> PARSER = null;
        public static final int REPLAY_ENABLED_FIELD_NUMBER = 13;
        public static final int ROOM_PRESET_FIELD_NUMBER = 12;
        public static final int SYNC_STREAMS_FIELD_NUMBER = 9;
        private Internal.ProtobufList<LivekitAgentDispatch.RoomAgentDispatch> agents_;
        private int departureTimeout_;
        private RoomEgress egress_;
        private int emptyTimeout_;
        private int maxParticipants_;
        private int maxPlayoutDelay_;
        private String metadata_;
        private int minPlayoutDelay_;
        private String name_;
        private String nodeId_;
        private boolean replayEnabled_;
        private String roomPreset_;
        private boolean syncStreams_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<CreateRoomRequest, Builder> implements CreateRoomRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(CreateRoomRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            CreateRoomRequest createRoomRequest = new CreateRoomRequest();
            DEFAULT_INSTANCE = createRoomRequest;
            GeneratedMessageLite.registerDefaultInstance(CreateRoomRequest.class, createRoomRequest);
        }

        private CreateRoomRequest() {
            String strA = ap.a(237878031);
            this.name_ = strA;
            this.roomPreset_ = strA;
            this.nodeId_ = strA;
            this.metadata_ = strA;
            this.agents_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAgents(LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureAgentsIsMutable();
            this.agents_.add(roomAgentDispatch);
        }

        private void addAllAgents(Iterable<? extends LivekitAgentDispatch.RoomAgentDispatch> iterable) {
            ensureAgentsIsMutable();
            AbstractMessageLite.addAll(iterable, this.agents_);
        }

        private void clearAgents() {
            this.agents_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearDepartureTimeout() {
            this.departureTimeout_ = 0;
        }

        private void clearEgress() {
            this.egress_ = null;
        }

        private void clearEmptyTimeout() {
            this.emptyTimeout_ = 0;
        }

        private void clearMaxParticipants() {
            this.maxParticipants_ = 0;
        }

        private void clearMaxPlayoutDelay() {
            this.maxPlayoutDelay_ = 0;
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearMinPlayoutDelay() {
            this.minPlayoutDelay_ = 0;
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearNodeId() {
            this.nodeId_ = getDefaultInstance().getNodeId();
        }

        private void clearReplayEnabled() {
            this.replayEnabled_ = false;
        }

        private void clearRoomPreset() {
            this.roomPreset_ = getDefaultInstance().getRoomPreset();
        }

        private void clearSyncStreams() {
            this.syncStreams_ = false;
        }

        private void ensureAgentsIsMutable() {
            Internal.ProtobufList<LivekitAgentDispatch.RoomAgentDispatch> protobufList = this.agents_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.agents_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static CreateRoomRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeEgress(RoomEgress roomEgress) {
            roomEgress.getClass();
            RoomEgress roomEgress2 = this.egress_;
            if (roomEgress2 == null || roomEgress2 == RoomEgress.getDefaultInstance()) {
                this.egress_ = roomEgress;
            } else {
                this.egress_ = (RoomEgress) ((RoomEgress.Builder) RoomEgress.newBuilder(this.egress_).v(roomEgress)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static CreateRoomRequest parseDelimitedFrom(InputStream inputStream) {
            return (CreateRoomRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateRoomRequest parseFrom(ByteBuffer byteBuffer) {
            return (CreateRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<CreateRoomRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeAgents(int i) {
            ensureAgentsIsMutable();
            this.agents_.remove(i);
        }

        private void setAgents(int i, LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureAgentsIsMutable();
            this.agents_.set(i, roomAgentDispatch);
        }

        private void setDepartureTimeout(int i) {
            this.departureTimeout_ = i;
        }

        private void setEgress(RoomEgress roomEgress) {
            roomEgress.getClass();
            this.egress_ = roomEgress;
        }

        private void setEmptyTimeout(int i) {
            this.emptyTimeout_ = i;
        }

        private void setMaxParticipants(int i) {
            this.maxParticipants_ = i;
        }

        private void setMaxPlayoutDelay(int i) {
            this.maxPlayoutDelay_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setMinPlayoutDelay(int i) {
            this.minPlayoutDelay_ = i;
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setNodeId(String str) {
            str.getClass();
            this.nodeId_ = str;
        }

        private void setNodeIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.nodeId_ = byteString.L();
        }

        private void setReplayEnabled(boolean z) {
            this.replayEnabled_ = z;
        }

        private void setRoomPreset(String str) {
            str.getClass();
            this.roomPreset_ = str;
        }

        private void setRoomPresetBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomPreset_ = byteString.L();
        }

        private void setSyncStreams(boolean z) {
            this.syncStreams_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new CreateRoomRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\r\u0000\u0000\u0001\u000e\r\u0000\u0001\u0000\u0001Ȉ\u0002\u000b\u0003\u000b\u0004Ȉ\u0005Ȉ\u0006\t\u0007\u000b\b\u000b\t\u0007\n\u000b\fȈ\r\u0007\u000e\u001b", new Object[]{"name_", "emptyTimeout_", "maxParticipants_", "nodeId_", "metadata_", "egress_", "minPlayoutDelay_", "maxPlayoutDelay_", "syncStreams_", "departureTimeout_", "roomPreset_", "replayEnabled_", "agents_", LivekitAgentDispatch.RoomAgentDispatch.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<CreateRoomRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (CreateRoomRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitAgentDispatch.RoomAgentDispatch getAgents(int i) {
            return (LivekitAgentDispatch.RoomAgentDispatch) this.agents_.get(i);
        }

        public int getAgentsCount() {
            return this.agents_.size();
        }

        public List<LivekitAgentDispatch.RoomAgentDispatch> getAgentsList() {
            return this.agents_;
        }

        public LivekitAgentDispatch.RoomAgentDispatchOrBuilder getAgentsOrBuilder(int i) {
            return (LivekitAgentDispatch.RoomAgentDispatchOrBuilder) this.agents_.get(i);
        }

        public List<? extends LivekitAgentDispatch.RoomAgentDispatchOrBuilder> getAgentsOrBuilderList() {
            return this.agents_;
        }

        public int getDepartureTimeout() {
            return this.departureTimeout_;
        }

        public RoomEgress getEgress() {
            RoomEgress roomEgress = this.egress_;
            return roomEgress == null ? RoomEgress.getDefaultInstance() : roomEgress;
        }

        public int getEmptyTimeout() {
            return this.emptyTimeout_;
        }

        public int getMaxParticipants() {
            return this.maxParticipants_;
        }

        public int getMaxPlayoutDelay() {
            return this.maxPlayoutDelay_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public int getMinPlayoutDelay() {
            return this.minPlayoutDelay_;
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getNodeId() {
            return this.nodeId_;
        }

        public ByteString getNodeIdBytes() {
            return ByteString.n(this.nodeId_);
        }

        public boolean getReplayEnabled() {
            return this.replayEnabled_;
        }

        public String getRoomPreset() {
            return this.roomPreset_;
        }

        public ByteString getRoomPresetBytes() {
            return ByteString.n(this.roomPreset_);
        }

        public boolean getSyncStreams() {
            return this.syncStreams_;
        }

        public boolean hasEgress() {
            return this.egress_ != null;
        }

        public static Builder newBuilder(CreateRoomRequest createRoomRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(createRoomRequest);
        }

        public static CreateRoomRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateRoomRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateRoomRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static CreateRoomRequest parseFrom(ByteString byteString) {
            return (CreateRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addAgents(int i, LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureAgentsIsMutable();
            this.agents_.add(i, roomAgentDispatch);
        }

        public static CreateRoomRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static CreateRoomRequest parseFrom(byte[] bArr) {
            return (CreateRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static CreateRoomRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static CreateRoomRequest parseFrom(InputStream inputStream) {
            return (CreateRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateRoomRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateRoomRequest parseFrom(CodedInputStream codedInputStream) {
            return (CreateRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static CreateRoomRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface CreateRoomRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DeleteRoomRequest extends GeneratedMessageLite<DeleteRoomRequest, Builder> implements DeleteRoomRequestOrBuilder {
        private static final DeleteRoomRequest DEFAULT_INSTANCE;
        private static volatile Parser<DeleteRoomRequest> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 1;
        private String room_ = ap.a(905087215);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DeleteRoomRequest, Builder> implements DeleteRoomRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DeleteRoomRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            DeleteRoomRequest deleteRoomRequest = new DeleteRoomRequest();
            DEFAULT_INSTANCE = deleteRoomRequest;
            GeneratedMessageLite.registerDefaultInstance(DeleteRoomRequest.class, deleteRoomRequest);
        }

        private DeleteRoomRequest() {
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        public static DeleteRoomRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DeleteRoomRequest parseDelimitedFrom(InputStream inputStream) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteRoomRequest parseFrom(ByteBuffer byteBuffer) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DeleteRoomRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DeleteRoomRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"room_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DeleteRoomRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DeleteRoomRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public static Builder newBuilder(DeleteRoomRequest deleteRoomRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(deleteRoomRequest);
        }

        public static DeleteRoomRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteRoomRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DeleteRoomRequest parseFrom(ByteString byteString) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DeleteRoomRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DeleteRoomRequest parseFrom(byte[] bArr) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DeleteRoomRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DeleteRoomRequest parseFrom(InputStream inputStream) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteRoomRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteRoomRequest parseFrom(CodedInputStream codedInputStream) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DeleteRoomRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DeleteRoomRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DeleteRoomResponse extends GeneratedMessageLite<DeleteRoomResponse, Builder> implements DeleteRoomResponseOrBuilder {
        private static final DeleteRoomResponse DEFAULT_INSTANCE;
        private static volatile Parser<DeleteRoomResponse> PARSER;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DeleteRoomResponse, Builder> implements DeleteRoomResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DeleteRoomResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            DeleteRoomResponse deleteRoomResponse = new DeleteRoomResponse();
            DEFAULT_INSTANCE = deleteRoomResponse;
            GeneratedMessageLite.registerDefaultInstance(DeleteRoomResponse.class, deleteRoomResponse);
        }

        private DeleteRoomResponse() {
        }

        public static DeleteRoomResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DeleteRoomResponse parseDelimitedFrom(InputStream inputStream) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteRoomResponse parseFrom(ByteBuffer byteBuffer) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DeleteRoomResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DeleteRoomResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0000", (Object[]) null);
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DeleteRoomResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DeleteRoomResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public static Builder newBuilder(DeleteRoomResponse deleteRoomResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(deleteRoomResponse);
        }

        public static DeleteRoomResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteRoomResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DeleteRoomResponse parseFrom(ByteString byteString) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DeleteRoomResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DeleteRoomResponse parseFrom(byte[] bArr) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DeleteRoomResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DeleteRoomResponse parseFrom(InputStream inputStream) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteRoomResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteRoomResponse parseFrom(CodedInputStream codedInputStream) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DeleteRoomResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteRoomResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DeleteRoomResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ForwardParticipantRequest extends GeneratedMessageLite<ForwardParticipantRequest, Builder> implements ForwardParticipantRequestOrBuilder {
        private static final ForwardParticipantRequest DEFAULT_INSTANCE;
        public static final int DESTINATION_ROOM_FIELD_NUMBER = 3;
        public static final int IDENTITY_FIELD_NUMBER = 2;
        private static volatile Parser<ForwardParticipantRequest> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 1;
        private String destinationRoom_;
        private String identity_;
        private String room_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ForwardParticipantRequest, Builder> implements ForwardParticipantRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ForwardParticipantRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ForwardParticipantRequest forwardParticipantRequest = new ForwardParticipantRequest();
            DEFAULT_INSTANCE = forwardParticipantRequest;
            GeneratedMessageLite.registerDefaultInstance(ForwardParticipantRequest.class, forwardParticipantRequest);
        }

        private ForwardParticipantRequest() {
            String strA = ap.a(66275671);
            this.room_ = strA;
            this.identity_ = strA;
            this.destinationRoom_ = strA;
        }

        private void clearDestinationRoom() {
            this.destinationRoom_ = getDefaultInstance().getDestinationRoom();
        }

        private void clearIdentity() {
            this.identity_ = getDefaultInstance().getIdentity();
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        public static ForwardParticipantRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ForwardParticipantRequest parseDelimitedFrom(InputStream inputStream) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ForwardParticipantRequest parseFrom(ByteBuffer byteBuffer) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ForwardParticipantRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDestinationRoom(String str) {
            str.getClass();
            this.destinationRoom_ = str;
        }

        private void setDestinationRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.destinationRoom_ = byteString.L();
        }

        private void setIdentity(String str) {
            str.getClass();
            this.identity_ = str;
        }

        private void setIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.identity_ = byteString.L();
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ForwardParticipantRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ", new Object[]{"room_", "identity_", "destinationRoom_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ForwardParticipantRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ForwardParticipantRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getDestinationRoom() {
            return this.destinationRoom_;
        }

        public ByteString getDestinationRoomBytes() {
            return ByteString.n(this.destinationRoom_);
        }

        public String getIdentity() {
            return this.identity_;
        }

        public ByteString getIdentityBytes() {
            return ByteString.n(this.identity_);
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public static Builder newBuilder(ForwardParticipantRequest forwardParticipantRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(forwardParticipantRequest);
        }

        public static ForwardParticipantRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ForwardParticipantRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ForwardParticipantRequest parseFrom(ByteString byteString) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ForwardParticipantRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ForwardParticipantRequest parseFrom(byte[] bArr) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ForwardParticipantRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ForwardParticipantRequest parseFrom(InputStream inputStream) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ForwardParticipantRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ForwardParticipantRequest parseFrom(CodedInputStream codedInputStream) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ForwardParticipantRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ForwardParticipantRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ForwardParticipantResponse extends GeneratedMessageLite<ForwardParticipantResponse, Builder> implements ForwardParticipantResponseOrBuilder {
        private static final ForwardParticipantResponse DEFAULT_INSTANCE;
        private static volatile Parser<ForwardParticipantResponse> PARSER;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ForwardParticipantResponse, Builder> implements ForwardParticipantResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ForwardParticipantResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ForwardParticipantResponse forwardParticipantResponse = new ForwardParticipantResponse();
            DEFAULT_INSTANCE = forwardParticipantResponse;
            GeneratedMessageLite.registerDefaultInstance(ForwardParticipantResponse.class, forwardParticipantResponse);
        }

        private ForwardParticipantResponse() {
        }

        public static ForwardParticipantResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ForwardParticipantResponse parseDelimitedFrom(InputStream inputStream) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ForwardParticipantResponse parseFrom(ByteBuffer byteBuffer) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ForwardParticipantResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ForwardParticipantResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0000", (Object[]) null);
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ForwardParticipantResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ForwardParticipantResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public static Builder newBuilder(ForwardParticipantResponse forwardParticipantResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(forwardParticipantResponse);
        }

        public static ForwardParticipantResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ForwardParticipantResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ForwardParticipantResponse parseFrom(ByteString byteString) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ForwardParticipantResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ForwardParticipantResponse parseFrom(byte[] bArr) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ForwardParticipantResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ForwardParticipantResponse parseFrom(InputStream inputStream) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ForwardParticipantResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ForwardParticipantResponse parseFrom(CodedInputStream codedInputStream) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ForwardParticipantResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ForwardParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ForwardParticipantResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListParticipantsRequest extends GeneratedMessageLite<ListParticipantsRequest, Builder> implements ListParticipantsRequestOrBuilder {
        private static final ListParticipantsRequest DEFAULT_INSTANCE;
        private static volatile Parser<ListParticipantsRequest> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 1;
        private String room_ = ap.a(1921004494);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListParticipantsRequest, Builder> implements ListParticipantsRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListParticipantsRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListParticipantsRequest listParticipantsRequest = new ListParticipantsRequest();
            DEFAULT_INSTANCE = listParticipantsRequest;
            GeneratedMessageLite.registerDefaultInstance(ListParticipantsRequest.class, listParticipantsRequest);
        }

        private ListParticipantsRequest() {
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        public static ListParticipantsRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListParticipantsRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListParticipantsRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListParticipantsRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListParticipantsRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"room_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListParticipantsRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListParticipantsRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public static Builder newBuilder(ListParticipantsRequest listParticipantsRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listParticipantsRequest);
        }

        public static ListParticipantsRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListParticipantsRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListParticipantsRequest parseFrom(ByteString byteString) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListParticipantsRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListParticipantsRequest parseFrom(byte[] bArr) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListParticipantsRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListParticipantsRequest parseFrom(InputStream inputStream) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListParticipantsRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListParticipantsRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListParticipantsRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListParticipantsRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListParticipantsResponse extends GeneratedMessageLite<ListParticipantsResponse, Builder> implements ListParticipantsResponseOrBuilder {
        private static final ListParticipantsResponse DEFAULT_INSTANCE;
        private static volatile Parser<ListParticipantsResponse> PARSER = null;
        public static final int PARTICIPANTS_FIELD_NUMBER = 1;
        private Internal.ProtobufList<LivekitModels.ParticipantInfo> participants_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListParticipantsResponse, Builder> implements ListParticipantsResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListParticipantsResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListParticipantsResponse listParticipantsResponse = new ListParticipantsResponse();
            DEFAULT_INSTANCE = listParticipantsResponse;
            GeneratedMessageLite.registerDefaultInstance(ListParticipantsResponse.class, listParticipantsResponse);
        }

        private ListParticipantsResponse() {
        }

        private void addAllParticipants(Iterable<? extends LivekitModels.ParticipantInfo> iterable) {
            ensureParticipantsIsMutable();
            AbstractMessageLite.addAll(iterable, this.participants_);
        }

        private void addParticipants(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureParticipantsIsMutable();
            this.participants_.add(participantInfo);
        }

        private void clearParticipants() {
            this.participants_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureParticipantsIsMutable() {
            Internal.ProtobufList<LivekitModels.ParticipantInfo> protobufList = this.participants_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.participants_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListParticipantsResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListParticipantsResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListParticipantsResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListParticipantsResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeParticipants(int i) {
            ensureParticipantsIsMutable();
            this.participants_.remove(i);
        }

        private void setParticipants(int i, LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureParticipantsIsMutable();
            this.participants_.set(i, participantInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListParticipantsResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(636742022), LivekitModels.ParticipantInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListParticipantsResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListParticipantsResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.ParticipantInfo getParticipants(int i) {
            return (LivekitModels.ParticipantInfo) this.participants_.get(i);
        }

        public int getParticipantsCount() {
            return this.participants_.size();
        }

        public List<LivekitModels.ParticipantInfo> getParticipantsList() {
            return this.participants_;
        }

        public LivekitModels.ParticipantInfoOrBuilder getParticipantsOrBuilder(int i) {
            return (LivekitModels.ParticipantInfoOrBuilder) this.participants_.get(i);
        }

        public List<? extends LivekitModels.ParticipantInfoOrBuilder> getParticipantsOrBuilderList() {
            return this.participants_;
        }

        public static Builder newBuilder(ListParticipantsResponse listParticipantsResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listParticipantsResponse);
        }

        public static ListParticipantsResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListParticipantsResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListParticipantsResponse parseFrom(ByteString byteString) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addParticipants(int i, LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            ensureParticipantsIsMutable();
            this.participants_.add(i, participantInfo);
        }

        public static ListParticipantsResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListParticipantsResponse parseFrom(byte[] bArr) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListParticipantsResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListParticipantsResponse parseFrom(InputStream inputStream) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListParticipantsResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListParticipantsResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListParticipantsResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListParticipantsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListParticipantsResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListRoomsRequest extends GeneratedMessageLite<ListRoomsRequest, Builder> implements ListRoomsRequestOrBuilder {
        private static final ListRoomsRequest DEFAULT_INSTANCE;
        public static final int NAMES_FIELD_NUMBER = 1;
        private static volatile Parser<ListRoomsRequest> PARSER;
        private Internal.ProtobufList<String> names_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListRoomsRequest, Builder> implements ListRoomsRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListRoomsRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListRoomsRequest listRoomsRequest = new ListRoomsRequest();
            DEFAULT_INSTANCE = listRoomsRequest;
            GeneratedMessageLite.registerDefaultInstance(ListRoomsRequest.class, listRoomsRequest);
        }

        private ListRoomsRequest() {
        }

        private void addAllNames(Iterable<String> iterable) {
            ensureNamesIsMutable();
            AbstractMessageLite.addAll(iterable, this.names_);
        }

        private void addNames(String str) {
            str.getClass();
            ensureNamesIsMutable();
            this.names_.add(str);
        }

        private void addNamesBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureNamesIsMutable();
            this.names_.add(byteString.L());
        }

        private void clearNames() {
            this.names_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureNamesIsMutable() {
            Internal.ProtobufList<String> protobufList = this.names_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.names_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListRoomsRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListRoomsRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListRoomsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListRoomsRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListRoomsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListRoomsRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setNames(int i, String str) {
            str.getClass();
            ensureNamesIsMutable();
            this.names_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListRoomsRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001Ț", new Object[]{ap.a(368295075)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListRoomsRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListRoomsRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getNames(int i) {
            return (String) this.names_.get(i);
        }

        public ByteString getNamesBytes(int i) {
            return ByteString.n((String) this.names_.get(i));
        }

        public int getNamesCount() {
            return this.names_.size();
        }

        public List<String> getNamesList() {
            return this.names_;
        }

        public static Builder newBuilder(ListRoomsRequest listRoomsRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listRoomsRequest);
        }

        public static ListRoomsRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListRoomsRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListRoomsRequest parseFrom(ByteString byteString) {
            return (ListRoomsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListRoomsRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListRoomsRequest parseFrom(byte[] bArr) {
            return (ListRoomsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListRoomsRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListRoomsRequest parseFrom(InputStream inputStream) {
            return (ListRoomsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListRoomsRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListRoomsRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListRoomsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListRoomsRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListRoomsRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListRoomsResponse extends GeneratedMessageLite<ListRoomsResponse, Builder> implements ListRoomsResponseOrBuilder {
        private static final ListRoomsResponse DEFAULT_INSTANCE;
        private static volatile Parser<ListRoomsResponse> PARSER = null;
        public static final int ROOMS_FIELD_NUMBER = 1;
        private Internal.ProtobufList<LivekitModels.Room> rooms_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListRoomsResponse, Builder> implements ListRoomsResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListRoomsResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListRoomsResponse listRoomsResponse = new ListRoomsResponse();
            DEFAULT_INSTANCE = listRoomsResponse;
            GeneratedMessageLite.registerDefaultInstance(ListRoomsResponse.class, listRoomsResponse);
        }

        private ListRoomsResponse() {
        }

        private void addAllRooms(Iterable<? extends LivekitModels.Room> iterable) {
            ensureRoomsIsMutable();
            AbstractMessageLite.addAll(iterable, this.rooms_);
        }

        private void addRooms(LivekitModels.Room room) {
            room.getClass();
            ensureRoomsIsMutable();
            this.rooms_.add(room);
        }

        private void clearRooms() {
            this.rooms_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureRoomsIsMutable() {
            Internal.ProtobufList<LivekitModels.Room> protobufList = this.rooms_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.rooms_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListRoomsResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListRoomsResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListRoomsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListRoomsResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListRoomsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListRoomsResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeRooms(int i) {
            ensureRoomsIsMutable();
            this.rooms_.remove(i);
        }

        private void setRooms(int i, LivekitModels.Room room) {
            room.getClass();
            ensureRoomsIsMutable();
            this.rooms_.set(i, room);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListRoomsResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(160721445), LivekitModels.Room.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListRoomsResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListRoomsResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.Room getRooms(int i) {
            return (LivekitModels.Room) this.rooms_.get(i);
        }

        public int getRoomsCount() {
            return this.rooms_.size();
        }

        public List<LivekitModels.Room> getRoomsList() {
            return this.rooms_;
        }

        public LivekitModels.RoomOrBuilder getRoomsOrBuilder(int i) {
            return (LivekitModels.RoomOrBuilder) this.rooms_.get(i);
        }

        public List<? extends LivekitModels.RoomOrBuilder> getRoomsOrBuilderList() {
            return this.rooms_;
        }

        public static Builder newBuilder(ListRoomsResponse listRoomsResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listRoomsResponse);
        }

        public static ListRoomsResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListRoomsResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListRoomsResponse parseFrom(ByteString byteString) {
            return (ListRoomsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addRooms(int i, LivekitModels.Room room) {
            room.getClass();
            ensureRoomsIsMutable();
            this.rooms_.add(i, room);
        }

        public static ListRoomsResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListRoomsResponse parseFrom(byte[] bArr) {
            return (ListRoomsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListRoomsResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListRoomsResponse parseFrom(InputStream inputStream) {
            return (ListRoomsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListRoomsResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListRoomsResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListRoomsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListRoomsResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListRoomsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListRoomsResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class MoveParticipantRequest extends GeneratedMessageLite<MoveParticipantRequest, Builder> implements MoveParticipantRequestOrBuilder {
        private static final MoveParticipantRequest DEFAULT_INSTANCE;
        public static final int DESTINATION_ROOM_FIELD_NUMBER = 3;
        public static final int IDENTITY_FIELD_NUMBER = 2;
        private static volatile Parser<MoveParticipantRequest> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 1;
        private String destinationRoom_;
        private String identity_;
        private String room_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<MoveParticipantRequest, Builder> implements MoveParticipantRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(MoveParticipantRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            MoveParticipantRequest moveParticipantRequest = new MoveParticipantRequest();
            DEFAULT_INSTANCE = moveParticipantRequest;
            GeneratedMessageLite.registerDefaultInstance(MoveParticipantRequest.class, moveParticipantRequest);
        }

        private MoveParticipantRequest() {
            String strA = ap.a(675153927);
            this.room_ = strA;
            this.identity_ = strA;
            this.destinationRoom_ = strA;
        }

        private void clearDestinationRoom() {
            this.destinationRoom_ = getDefaultInstance().getDestinationRoom();
        }

        private void clearIdentity() {
            this.identity_ = getDefaultInstance().getIdentity();
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        public static MoveParticipantRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static MoveParticipantRequest parseDelimitedFrom(InputStream inputStream) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MoveParticipantRequest parseFrom(ByteBuffer byteBuffer) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<MoveParticipantRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDestinationRoom(String str) {
            str.getClass();
            this.destinationRoom_ = str;
        }

        private void setDestinationRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.destinationRoom_ = byteString.L();
        }

        private void setIdentity(String str) {
            str.getClass();
            this.identity_ = str;
        }

        private void setIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.identity_ = byteString.L();
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new MoveParticipantRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ", new Object[]{"room_", "identity_", "destinationRoom_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<MoveParticipantRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (MoveParticipantRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getDestinationRoom() {
            return this.destinationRoom_;
        }

        public ByteString getDestinationRoomBytes() {
            return ByteString.n(this.destinationRoom_);
        }

        public String getIdentity() {
            return this.identity_;
        }

        public ByteString getIdentityBytes() {
            return ByteString.n(this.identity_);
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public static Builder newBuilder(MoveParticipantRequest moveParticipantRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(moveParticipantRequest);
        }

        public static MoveParticipantRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MoveParticipantRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static MoveParticipantRequest parseFrom(ByteString byteString) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static MoveParticipantRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static MoveParticipantRequest parseFrom(byte[] bArr) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static MoveParticipantRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static MoveParticipantRequest parseFrom(InputStream inputStream) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MoveParticipantRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MoveParticipantRequest parseFrom(CodedInputStream codedInputStream) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static MoveParticipantRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface MoveParticipantRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class MoveParticipantResponse extends GeneratedMessageLite<MoveParticipantResponse, Builder> implements MoveParticipantResponseOrBuilder {
        private static final MoveParticipantResponse DEFAULT_INSTANCE;
        private static volatile Parser<MoveParticipantResponse> PARSER;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<MoveParticipantResponse, Builder> implements MoveParticipantResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(MoveParticipantResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            MoveParticipantResponse moveParticipantResponse = new MoveParticipantResponse();
            DEFAULT_INSTANCE = moveParticipantResponse;
            GeneratedMessageLite.registerDefaultInstance(MoveParticipantResponse.class, moveParticipantResponse);
        }

        private MoveParticipantResponse() {
        }

        public static MoveParticipantResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static MoveParticipantResponse parseDelimitedFrom(InputStream inputStream) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MoveParticipantResponse parseFrom(ByteBuffer byteBuffer) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<MoveParticipantResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new MoveParticipantResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0000", (Object[]) null);
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<MoveParticipantResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (MoveParticipantResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public static Builder newBuilder(MoveParticipantResponse moveParticipantResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(moveParticipantResponse);
        }

        public static MoveParticipantResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MoveParticipantResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static MoveParticipantResponse parseFrom(ByteString byteString) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static MoveParticipantResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static MoveParticipantResponse parseFrom(byte[] bArr) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static MoveParticipantResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static MoveParticipantResponse parseFrom(InputStream inputStream) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MoveParticipantResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MoveParticipantResponse parseFrom(CodedInputStream codedInputStream) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static MoveParticipantResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface MoveParticipantResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class MuteRoomTrackRequest extends GeneratedMessageLite<MuteRoomTrackRequest, Builder> implements MuteRoomTrackRequestOrBuilder {
        private static final MuteRoomTrackRequest DEFAULT_INSTANCE;
        public static final int IDENTITY_FIELD_NUMBER = 2;
        public static final int MUTED_FIELD_NUMBER = 4;
        private static volatile Parser<MuteRoomTrackRequest> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 1;
        public static final int TRACK_SID_FIELD_NUMBER = 3;
        private String identity_;
        private boolean muted_;
        private String room_;
        private String trackSid_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<MuteRoomTrackRequest, Builder> implements MuteRoomTrackRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(MuteRoomTrackRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            MuteRoomTrackRequest muteRoomTrackRequest = new MuteRoomTrackRequest();
            DEFAULT_INSTANCE = muteRoomTrackRequest;
            GeneratedMessageLite.registerDefaultInstance(MuteRoomTrackRequest.class, muteRoomTrackRequest);
        }

        private MuteRoomTrackRequest() {
            String strA = ap.a(1506751098);
            this.room_ = strA;
            this.identity_ = strA;
            this.trackSid_ = strA;
        }

        private void clearIdentity() {
            this.identity_ = getDefaultInstance().getIdentity();
        }

        private void clearMuted() {
            this.muted_ = false;
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        private void clearTrackSid() {
            this.trackSid_ = getDefaultInstance().getTrackSid();
        }

        public static MuteRoomTrackRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static MuteRoomTrackRequest parseDelimitedFrom(InputStream inputStream) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MuteRoomTrackRequest parseFrom(ByteBuffer byteBuffer) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<MuteRoomTrackRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setIdentity(String str) {
            str.getClass();
            this.identity_ = str;
        }

        private void setIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.identity_ = byteString.L();
        }

        private void setMuted(boolean z) {
            this.muted_ = z;
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        private void setTrackSid(String str) {
            str.getClass();
            this.trackSid_ = str;
        }

        private void setTrackSidBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackSid_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new MuteRoomTrackRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\u0007", new Object[]{"room_", "identity_", "trackSid_", "muted_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<MuteRoomTrackRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (MuteRoomTrackRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getIdentity() {
            return this.identity_;
        }

        public ByteString getIdentityBytes() {
            return ByteString.n(this.identity_);
        }

        public boolean getMuted() {
            return this.muted_;
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public String getTrackSid() {
            return this.trackSid_;
        }

        public ByteString getTrackSidBytes() {
            return ByteString.n(this.trackSid_);
        }

        public static Builder newBuilder(MuteRoomTrackRequest muteRoomTrackRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(muteRoomTrackRequest);
        }

        public static MuteRoomTrackRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MuteRoomTrackRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static MuteRoomTrackRequest parseFrom(ByteString byteString) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static MuteRoomTrackRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static MuteRoomTrackRequest parseFrom(byte[] bArr) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static MuteRoomTrackRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static MuteRoomTrackRequest parseFrom(InputStream inputStream) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MuteRoomTrackRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MuteRoomTrackRequest parseFrom(CodedInputStream codedInputStream) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static MuteRoomTrackRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface MuteRoomTrackRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class MuteRoomTrackResponse extends GeneratedMessageLite<MuteRoomTrackResponse, Builder> implements MuteRoomTrackResponseOrBuilder {
        private static final MuteRoomTrackResponse DEFAULT_INSTANCE;
        private static volatile Parser<MuteRoomTrackResponse> PARSER = null;
        public static final int TRACK_FIELD_NUMBER = 1;
        private LivekitModels.TrackInfo track_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<MuteRoomTrackResponse, Builder> implements MuteRoomTrackResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(MuteRoomTrackResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            MuteRoomTrackResponse muteRoomTrackResponse = new MuteRoomTrackResponse();
            DEFAULT_INSTANCE = muteRoomTrackResponse;
            GeneratedMessageLite.registerDefaultInstance(MuteRoomTrackResponse.class, muteRoomTrackResponse);
        }

        private MuteRoomTrackResponse() {
        }

        private void clearTrack() {
            this.track_ = null;
        }

        public static MuteRoomTrackResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeTrack(LivekitModels.TrackInfo trackInfo) {
            trackInfo.getClass();
            LivekitModels.TrackInfo trackInfo2 = this.track_;
            if (trackInfo2 == null || trackInfo2 == LivekitModels.TrackInfo.getDefaultInstance()) {
                this.track_ = trackInfo;
            } else {
                this.track_ = (LivekitModels.TrackInfo) ((LivekitModels.TrackInfo.Builder) LivekitModels.TrackInfo.newBuilder(this.track_).v(trackInfo)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static MuteRoomTrackResponse parseDelimitedFrom(InputStream inputStream) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MuteRoomTrackResponse parseFrom(ByteBuffer byteBuffer) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<MuteRoomTrackResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setTrack(LivekitModels.TrackInfo trackInfo) {
            trackInfo.getClass();
            this.track_ = trackInfo;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new MuteRoomTrackResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\t", new Object[]{ap.a(377033390)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<MuteRoomTrackResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (MuteRoomTrackResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.TrackInfo getTrack() {
            LivekitModels.TrackInfo trackInfo = this.track_;
            return trackInfo == null ? LivekitModels.TrackInfo.getDefaultInstance() : trackInfo;
        }

        public boolean hasTrack() {
            return this.track_ != null;
        }

        public static Builder newBuilder(MuteRoomTrackResponse muteRoomTrackResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(muteRoomTrackResponse);
        }

        public static MuteRoomTrackResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MuteRoomTrackResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static MuteRoomTrackResponse parseFrom(ByteString byteString) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static MuteRoomTrackResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static MuteRoomTrackResponse parseFrom(byte[] bArr) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static MuteRoomTrackResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static MuteRoomTrackResponse parseFrom(InputStream inputStream) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MuteRoomTrackResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MuteRoomTrackResponse parseFrom(CodedInputStream codedInputStream) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static MuteRoomTrackResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MuteRoomTrackResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface MuteRoomTrackResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class PerformRpcRequest extends GeneratedMessageLite<PerformRpcRequest, Builder> implements PerformRpcRequestOrBuilder {
        private static final PerformRpcRequest DEFAULT_INSTANCE;
        public static final int DESTINATION_IDENTITY_FIELD_NUMBER = 2;
        public static final int METHOD_FIELD_NUMBER = 3;
        private static volatile Parser<PerformRpcRequest> PARSER = null;
        public static final int PAYLOAD_FIELD_NUMBER = 4;
        public static final int RESPONSE_TIMEOUT_MS_FIELD_NUMBER = 5;
        public static final int ROOM_FIELD_NUMBER = 1;
        private String destinationIdentity_;
        private String method_;
        private String payload_;
        private int responseTimeoutMs_;
        private String room_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<PerformRpcRequest, Builder> implements PerformRpcRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(PerformRpcRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            PerformRpcRequest performRpcRequest = new PerformRpcRequest();
            DEFAULT_INSTANCE = performRpcRequest;
            GeneratedMessageLite.registerDefaultInstance(PerformRpcRequest.class, performRpcRequest);
        }

        private PerformRpcRequest() {
            String strA = ap.a(13274415);
            this.room_ = strA;
            this.destinationIdentity_ = strA;
            this.method_ = strA;
            this.payload_ = strA;
        }

        private void clearDestinationIdentity() {
            this.destinationIdentity_ = getDefaultInstance().getDestinationIdentity();
        }

        private void clearMethod() {
            this.method_ = getDefaultInstance().getMethod();
        }

        private void clearPayload() {
            this.payload_ = getDefaultInstance().getPayload();
        }

        private void clearResponseTimeoutMs() {
            this.responseTimeoutMs_ = 0;
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        public static PerformRpcRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static PerformRpcRequest parseDelimitedFrom(InputStream inputStream) {
            return (PerformRpcRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PerformRpcRequest parseFrom(ByteBuffer byteBuffer) {
            return (PerformRpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<PerformRpcRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDestinationIdentity(String str) {
            str.getClass();
            this.destinationIdentity_ = str;
        }

        private void setDestinationIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.destinationIdentity_ = byteString.L();
        }

        private void setMethod(String str) {
            str.getClass();
            this.method_ = str;
        }

        private void setMethodBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.method_ = byteString.L();
        }

        private void setPayload(String str) {
            str.getClass();
            this.payload_ = str;
        }

        private void setPayloadBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.payload_ = byteString.L();
        }

        private void setResponseTimeoutMs(int i) {
            this.responseTimeoutMs_ = i;
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new PerformRpcRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005\u000b", new Object[]{"room_", "destinationIdentity_", "method_", "payload_", "responseTimeoutMs_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<PerformRpcRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (PerformRpcRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getDestinationIdentity() {
            return this.destinationIdentity_;
        }

        public ByteString getDestinationIdentityBytes() {
            return ByteString.n(this.destinationIdentity_);
        }

        public String getMethod() {
            return this.method_;
        }

        public ByteString getMethodBytes() {
            return ByteString.n(this.method_);
        }

        public String getPayload() {
            return this.payload_;
        }

        public ByteString getPayloadBytes() {
            return ByteString.n(this.payload_);
        }

        public int getResponseTimeoutMs() {
            return this.responseTimeoutMs_;
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public static Builder newBuilder(PerformRpcRequest performRpcRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(performRpcRequest);
        }

        public static PerformRpcRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PerformRpcRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static PerformRpcRequest parseFrom(ByteString byteString) {
            return (PerformRpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static PerformRpcRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static PerformRpcRequest parseFrom(byte[] bArr) {
            return (PerformRpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static PerformRpcRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static PerformRpcRequest parseFrom(InputStream inputStream) {
            return (PerformRpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PerformRpcRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PerformRpcRequest parseFrom(CodedInputStream codedInputStream) {
            return (PerformRpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static PerformRpcRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface PerformRpcRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class PerformRpcResponse extends GeneratedMessageLite<PerformRpcResponse, Builder> implements PerformRpcResponseOrBuilder {
        private static final PerformRpcResponse DEFAULT_INSTANCE;
        private static volatile Parser<PerformRpcResponse> PARSER = null;
        public static final int PAYLOAD_FIELD_NUMBER = 1;
        private String payload_ = ap.a(2470488);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<PerformRpcResponse, Builder> implements PerformRpcResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(PerformRpcResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            PerformRpcResponse performRpcResponse = new PerformRpcResponse();
            DEFAULT_INSTANCE = performRpcResponse;
            GeneratedMessageLite.registerDefaultInstance(PerformRpcResponse.class, performRpcResponse);
        }

        private PerformRpcResponse() {
        }

        private void clearPayload() {
            this.payload_ = getDefaultInstance().getPayload();
        }

        public static PerformRpcResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static PerformRpcResponse parseDelimitedFrom(InputStream inputStream) {
            return (PerformRpcResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PerformRpcResponse parseFrom(ByteBuffer byteBuffer) {
            return (PerformRpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<PerformRpcResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setPayload(String str) {
            str.getClass();
            this.payload_ = str;
        }

        private void setPayloadBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.payload_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new PerformRpcResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"payload_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<PerformRpcResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (PerformRpcResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getPayload() {
            return this.payload_;
        }

        public ByteString getPayloadBytes() {
            return ByteString.n(this.payload_);
        }

        public static Builder newBuilder(PerformRpcResponse performRpcResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(performRpcResponse);
        }

        public static PerformRpcResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PerformRpcResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static PerformRpcResponse parseFrom(ByteString byteString) {
            return (PerformRpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static PerformRpcResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static PerformRpcResponse parseFrom(byte[] bArr) {
            return (PerformRpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static PerformRpcResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static PerformRpcResponse parseFrom(InputStream inputStream) {
            return (PerformRpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static PerformRpcResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static PerformRpcResponse parseFrom(CodedInputStream codedInputStream) {
            return (PerformRpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static PerformRpcResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (PerformRpcResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface PerformRpcResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RemoveParticipantResponse extends GeneratedMessageLite<RemoveParticipantResponse, Builder> implements RemoveParticipantResponseOrBuilder {
        private static final RemoveParticipantResponse DEFAULT_INSTANCE;
        private static volatile Parser<RemoveParticipantResponse> PARSER;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RemoveParticipantResponse, Builder> implements RemoveParticipantResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RemoveParticipantResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            RemoveParticipantResponse removeParticipantResponse = new RemoveParticipantResponse();
            DEFAULT_INSTANCE = removeParticipantResponse;
            GeneratedMessageLite.registerDefaultInstance(RemoveParticipantResponse.class, removeParticipantResponse);
        }

        private RemoveParticipantResponse() {
        }

        public static RemoveParticipantResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RemoveParticipantResponse parseDelimitedFrom(InputStream inputStream) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RemoveParticipantResponse parseFrom(ByteBuffer byteBuffer) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RemoveParticipantResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RemoveParticipantResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0000", (Object[]) null);
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RemoveParticipantResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RemoveParticipantResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public static Builder newBuilder(RemoveParticipantResponse removeParticipantResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(removeParticipantResponse);
        }

        public static RemoveParticipantResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RemoveParticipantResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RemoveParticipantResponse parseFrom(ByteString byteString) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RemoveParticipantResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RemoveParticipantResponse parseFrom(byte[] bArr) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RemoveParticipantResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RemoveParticipantResponse parseFrom(InputStream inputStream) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RemoveParticipantResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RemoveParticipantResponse parseFrom(CodedInputStream codedInputStream) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RemoveParticipantResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RemoveParticipantResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RemoveParticipantResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RoomAgent extends GeneratedMessageLite<RoomAgent, Builder> implements RoomAgentOrBuilder {
        private static final RoomAgent DEFAULT_INSTANCE;
        public static final int DISPATCHES_FIELD_NUMBER = 1;
        private static volatile Parser<RoomAgent> PARSER;
        private Internal.ProtobufList<LivekitAgentDispatch.RoomAgentDispatch> dispatches_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RoomAgent, Builder> implements RoomAgentOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RoomAgent.DEFAULT_INSTANCE);
            }
        }

        static {
            RoomAgent roomAgent = new RoomAgent();
            DEFAULT_INSTANCE = roomAgent;
            GeneratedMessageLite.registerDefaultInstance(RoomAgent.class, roomAgent);
        }

        private RoomAgent() {
        }

        private void addAllDispatches(Iterable<? extends LivekitAgentDispatch.RoomAgentDispatch> iterable) {
            ensureDispatchesIsMutable();
            AbstractMessageLite.addAll(iterable, this.dispatches_);
        }

        private void addDispatches(LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureDispatchesIsMutable();
            this.dispatches_.add(roomAgentDispatch);
        }

        private void clearDispatches() {
            this.dispatches_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureDispatchesIsMutable() {
            Internal.ProtobufList<LivekitAgentDispatch.RoomAgentDispatch> protobufList = this.dispatches_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.dispatches_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static RoomAgent getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RoomAgent parseDelimitedFrom(InputStream inputStream) {
            return (RoomAgent) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomAgent parseFrom(ByteBuffer byteBuffer) {
            return (RoomAgent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RoomAgent> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeDispatches(int i) {
            ensureDispatchesIsMutable();
            this.dispatches_.remove(i);
        }

        private void setDispatches(int i, LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureDispatchesIsMutable();
            this.dispatches_.set(i, roomAgentDispatch);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RoomAgent();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(795193240), LivekitAgentDispatch.RoomAgentDispatch.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RoomAgent> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RoomAgent.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitAgentDispatch.RoomAgentDispatch getDispatches(int i) {
            return (LivekitAgentDispatch.RoomAgentDispatch) this.dispatches_.get(i);
        }

        public int getDispatchesCount() {
            return this.dispatches_.size();
        }

        public List<LivekitAgentDispatch.RoomAgentDispatch> getDispatchesList() {
            return this.dispatches_;
        }

        public LivekitAgentDispatch.RoomAgentDispatchOrBuilder getDispatchesOrBuilder(int i) {
            return (LivekitAgentDispatch.RoomAgentDispatchOrBuilder) this.dispatches_.get(i);
        }

        public List<? extends LivekitAgentDispatch.RoomAgentDispatchOrBuilder> getDispatchesOrBuilderList() {
            return this.dispatches_;
        }

        public static Builder newBuilder(RoomAgent roomAgent) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(roomAgent);
        }

        public static RoomAgent parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgent) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomAgent parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RoomAgent parseFrom(ByteString byteString) {
            return (RoomAgent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addDispatches(int i, LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureDispatchesIsMutable();
            this.dispatches_.add(i, roomAgentDispatch);
        }

        public static RoomAgent parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RoomAgent parseFrom(byte[] bArr) {
            return (RoomAgent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RoomAgent parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RoomAgent parseFrom(InputStream inputStream) {
            return (RoomAgent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomAgent parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomAgent parseFrom(CodedInputStream codedInputStream) {
            return (RoomAgent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RoomAgent parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RoomAgentOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RoomConfiguration extends GeneratedMessageLite<RoomConfiguration, Builder> implements RoomConfigurationOrBuilder {
        public static final int AGENTS_FIELD_NUMBER = 10;
        private static final RoomConfiguration DEFAULT_INSTANCE;
        public static final int DEPARTURE_TIMEOUT_FIELD_NUMBER = 3;
        public static final int EGRESS_FIELD_NUMBER = 5;
        public static final int EMPTY_TIMEOUT_FIELD_NUMBER = 2;
        public static final int MAX_PARTICIPANTS_FIELD_NUMBER = 4;
        public static final int MAX_PLAYOUT_DELAY_FIELD_NUMBER = 8;
        public static final int METADATA_FIELD_NUMBER = 11;
        public static final int MIN_PLAYOUT_DELAY_FIELD_NUMBER = 7;
        public static final int NAME_FIELD_NUMBER = 1;
        private static volatile Parser<RoomConfiguration> PARSER = null;
        public static final int SYNC_STREAMS_FIELD_NUMBER = 9;
        private Internal.ProtobufList<LivekitAgentDispatch.RoomAgentDispatch> agents_;
        private int departureTimeout_;
        private RoomEgress egress_;
        private int emptyTimeout_;
        private int maxParticipants_;
        private int maxPlayoutDelay_;
        private String metadata_;
        private int minPlayoutDelay_;
        private String name_;
        private boolean syncStreams_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RoomConfiguration, Builder> implements RoomConfigurationOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RoomConfiguration.DEFAULT_INSTANCE);
            }
        }

        static {
            RoomConfiguration roomConfiguration = new RoomConfiguration();
            DEFAULT_INSTANCE = roomConfiguration;
            GeneratedMessageLite.registerDefaultInstance(RoomConfiguration.class, roomConfiguration);
        }

        private RoomConfiguration() {
            String strA = ap.a(928402378);
            this.name_ = strA;
            this.metadata_ = strA;
            this.agents_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAgents(LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureAgentsIsMutable();
            this.agents_.add(roomAgentDispatch);
        }

        private void addAllAgents(Iterable<? extends LivekitAgentDispatch.RoomAgentDispatch> iterable) {
            ensureAgentsIsMutable();
            AbstractMessageLite.addAll(iterable, this.agents_);
        }

        private void clearAgents() {
            this.agents_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearDepartureTimeout() {
            this.departureTimeout_ = 0;
        }

        private void clearEgress() {
            this.egress_ = null;
        }

        private void clearEmptyTimeout() {
            this.emptyTimeout_ = 0;
        }

        private void clearMaxParticipants() {
            this.maxParticipants_ = 0;
        }

        private void clearMaxPlayoutDelay() {
            this.maxPlayoutDelay_ = 0;
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearMinPlayoutDelay() {
            this.minPlayoutDelay_ = 0;
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearSyncStreams() {
            this.syncStreams_ = false;
        }

        private void ensureAgentsIsMutable() {
            Internal.ProtobufList<LivekitAgentDispatch.RoomAgentDispatch> protobufList = this.agents_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.agents_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static RoomConfiguration getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeEgress(RoomEgress roomEgress) {
            roomEgress.getClass();
            RoomEgress roomEgress2 = this.egress_;
            if (roomEgress2 == null || roomEgress2 == RoomEgress.getDefaultInstance()) {
                this.egress_ = roomEgress;
            } else {
                this.egress_ = (RoomEgress) ((RoomEgress.Builder) RoomEgress.newBuilder(this.egress_).v(roomEgress)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RoomConfiguration parseDelimitedFrom(InputStream inputStream) {
            return (RoomConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomConfiguration parseFrom(ByteBuffer byteBuffer) {
            return (RoomConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RoomConfiguration> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeAgents(int i) {
            ensureAgentsIsMutable();
            this.agents_.remove(i);
        }

        private void setAgents(int i, LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureAgentsIsMutable();
            this.agents_.set(i, roomAgentDispatch);
        }

        private void setDepartureTimeout(int i) {
            this.departureTimeout_ = i;
        }

        private void setEgress(RoomEgress roomEgress) {
            roomEgress.getClass();
            this.egress_ = roomEgress;
        }

        private void setEmptyTimeout(int i) {
            this.emptyTimeout_ = i;
        }

        private void setMaxParticipants(int i) {
            this.maxParticipants_ = i;
        }

        private void setMaxPlayoutDelay(int i) {
            this.maxPlayoutDelay_ = i;
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setMinPlayoutDelay(int i) {
            this.minPlayoutDelay_ = i;
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setSyncStreams(boolean z) {
            this.syncStreams_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RoomConfiguration();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\n\u0000\u0000\u0001\u000b\n\u0000\u0001\u0000\u0001Ȉ\u0002\u000b\u0003\u000b\u0004\u000b\u0005\t\u0007\u000b\b\u000b\t\u0007\n\u001b\u000bȈ", new Object[]{"name_", "emptyTimeout_", "departureTimeout_", "maxParticipants_", "egress_", "minPlayoutDelay_", "maxPlayoutDelay_", "syncStreams_", "agents_", LivekitAgentDispatch.RoomAgentDispatch.class, "metadata_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RoomConfiguration> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RoomConfiguration.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitAgentDispatch.RoomAgentDispatch getAgents(int i) {
            return (LivekitAgentDispatch.RoomAgentDispatch) this.agents_.get(i);
        }

        public int getAgentsCount() {
            return this.agents_.size();
        }

        public List<LivekitAgentDispatch.RoomAgentDispatch> getAgentsList() {
            return this.agents_;
        }

        public LivekitAgentDispatch.RoomAgentDispatchOrBuilder getAgentsOrBuilder(int i) {
            return (LivekitAgentDispatch.RoomAgentDispatchOrBuilder) this.agents_.get(i);
        }

        public List<? extends LivekitAgentDispatch.RoomAgentDispatchOrBuilder> getAgentsOrBuilderList() {
            return this.agents_;
        }

        public int getDepartureTimeout() {
            return this.departureTimeout_;
        }

        public RoomEgress getEgress() {
            RoomEgress roomEgress = this.egress_;
            return roomEgress == null ? RoomEgress.getDefaultInstance() : roomEgress;
        }

        public int getEmptyTimeout() {
            return this.emptyTimeout_;
        }

        public int getMaxParticipants() {
            return this.maxParticipants_;
        }

        public int getMaxPlayoutDelay() {
            return this.maxPlayoutDelay_;
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public int getMinPlayoutDelay() {
            return this.minPlayoutDelay_;
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public boolean getSyncStreams() {
            return this.syncStreams_;
        }

        public boolean hasEgress() {
            return this.egress_ != null;
        }

        public static Builder newBuilder(RoomConfiguration roomConfiguration) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(roomConfiguration);
        }

        public static RoomConfiguration parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomConfiguration) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomConfiguration parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RoomConfiguration parseFrom(ByteString byteString) {
            return (RoomConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addAgents(int i, LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureAgentsIsMutable();
            this.agents_.add(i, roomAgentDispatch);
        }

        public static RoomConfiguration parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RoomConfiguration parseFrom(byte[] bArr) {
            return (RoomConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RoomConfiguration parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RoomConfiguration parseFrom(InputStream inputStream) {
            return (RoomConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomConfiguration parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomConfiguration parseFrom(CodedInputStream codedInputStream) {
            return (RoomConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RoomConfiguration parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomConfiguration) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RoomConfigurationOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RoomEgress extends GeneratedMessageLite<RoomEgress, Builder> implements RoomEgressOrBuilder {
        private static final RoomEgress DEFAULT_INSTANCE;
        private static volatile Parser<RoomEgress> PARSER = null;
        public static final int PARTICIPANT_FIELD_NUMBER = 3;
        public static final int ROOM_FIELD_NUMBER = 1;
        public static final int TRACKS_FIELD_NUMBER = 2;
        private LivekitEgress.AutoParticipantEgress participant_;
        private LivekitEgress.RoomCompositeEgressRequest room_;
        private LivekitEgress.AutoTrackEgress tracks_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RoomEgress, Builder> implements RoomEgressOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RoomEgress.DEFAULT_INSTANCE);
            }
        }

        static {
            RoomEgress roomEgress = new RoomEgress();
            DEFAULT_INSTANCE = roomEgress;
            GeneratedMessageLite.registerDefaultInstance(RoomEgress.class, roomEgress);
        }

        private RoomEgress() {
        }

        private void clearParticipant() {
            this.participant_ = null;
        }

        private void clearRoom() {
            this.room_ = null;
        }

        private void clearTracks() {
            this.tracks_ = null;
        }

        public static RoomEgress getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeParticipant(LivekitEgress.AutoParticipantEgress autoParticipantEgress) {
            autoParticipantEgress.getClass();
            LivekitEgress.AutoParticipantEgress autoParticipantEgress2 = this.participant_;
            if (autoParticipantEgress2 == null || autoParticipantEgress2 == LivekitEgress.AutoParticipantEgress.getDefaultInstance()) {
                this.participant_ = autoParticipantEgress;
            } else {
                this.participant_ = (LivekitEgress.AutoParticipantEgress) ((LivekitEgress.AutoParticipantEgress.Builder) LivekitEgress.AutoParticipantEgress.newBuilder(this.participant_).v(autoParticipantEgress)).o();
            }
        }

        private void mergeRoom(LivekitEgress.RoomCompositeEgressRequest roomCompositeEgressRequest) {
            roomCompositeEgressRequest.getClass();
            LivekitEgress.RoomCompositeEgressRequest roomCompositeEgressRequest2 = this.room_;
            if (roomCompositeEgressRequest2 == null || roomCompositeEgressRequest2 == LivekitEgress.RoomCompositeEgressRequest.getDefaultInstance()) {
                this.room_ = roomCompositeEgressRequest;
            } else {
                this.room_ = (LivekitEgress.RoomCompositeEgressRequest) ((LivekitEgress.RoomCompositeEgressRequest.Builder) LivekitEgress.RoomCompositeEgressRequest.newBuilder(this.room_).v(roomCompositeEgressRequest)).o();
            }
        }

        private void mergeTracks(LivekitEgress.AutoTrackEgress autoTrackEgress) {
            autoTrackEgress.getClass();
            LivekitEgress.AutoTrackEgress autoTrackEgress2 = this.tracks_;
            if (autoTrackEgress2 == null || autoTrackEgress2 == LivekitEgress.AutoTrackEgress.getDefaultInstance()) {
                this.tracks_ = autoTrackEgress;
            } else {
                this.tracks_ = (LivekitEgress.AutoTrackEgress) ((LivekitEgress.AutoTrackEgress.Builder) LivekitEgress.AutoTrackEgress.newBuilder(this.tracks_).v(autoTrackEgress)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RoomEgress parseDelimitedFrom(InputStream inputStream) {
            return (RoomEgress) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomEgress parseFrom(ByteBuffer byteBuffer) {
            return (RoomEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RoomEgress> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setParticipant(LivekitEgress.AutoParticipantEgress autoParticipantEgress) {
            autoParticipantEgress.getClass();
            this.participant_ = autoParticipantEgress;
        }

        private void setRoom(LivekitEgress.RoomCompositeEgressRequest roomCompositeEgressRequest) {
            roomCompositeEgressRequest.getClass();
            this.room_ = roomCompositeEgressRequest;
        }

        private void setTracks(LivekitEgress.AutoTrackEgress autoTrackEgress) {
            autoTrackEgress.getClass();
            this.tracks_ = autoTrackEgress;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RoomEgress();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\t\u0002\t\u0003\t", new Object[]{ap.a(632365221), ap.a(1044839586), ap.a(1929805283)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RoomEgress> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RoomEgress.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitEgress.AutoParticipantEgress getParticipant() {
            LivekitEgress.AutoParticipantEgress autoParticipantEgress = this.participant_;
            return autoParticipantEgress == null ? LivekitEgress.AutoParticipantEgress.getDefaultInstance() : autoParticipantEgress;
        }

        public LivekitEgress.RoomCompositeEgressRequest getRoom() {
            LivekitEgress.RoomCompositeEgressRequest roomCompositeEgressRequest = this.room_;
            return roomCompositeEgressRequest == null ? LivekitEgress.RoomCompositeEgressRequest.getDefaultInstance() : roomCompositeEgressRequest;
        }

        public LivekitEgress.AutoTrackEgress getTracks() {
            LivekitEgress.AutoTrackEgress autoTrackEgress = this.tracks_;
            return autoTrackEgress == null ? LivekitEgress.AutoTrackEgress.getDefaultInstance() : autoTrackEgress;
        }

        public boolean hasParticipant() {
            return this.participant_ != null;
        }

        public boolean hasRoom() {
            return this.room_ != null;
        }

        public boolean hasTracks() {
            return this.tracks_ != null;
        }

        public static Builder newBuilder(RoomEgress roomEgress) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(roomEgress);
        }

        public static RoomEgress parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomEgress) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomEgress parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RoomEgress parseFrom(ByteString byteString) {
            return (RoomEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RoomEgress parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RoomEgress parseFrom(byte[] bArr) {
            return (RoomEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RoomEgress parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RoomEgress parseFrom(InputStream inputStream) {
            return (RoomEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomEgress parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomEgress parseFrom(CodedInputStream codedInputStream) {
            return (RoomEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RoomEgress parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RoomEgressOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RoomParticipantIdentity extends GeneratedMessageLite<RoomParticipantIdentity, Builder> implements RoomParticipantIdentityOrBuilder {
        private static final RoomParticipantIdentity DEFAULT_INSTANCE;
        public static final int IDENTITY_FIELD_NUMBER = 2;
        private static volatile Parser<RoomParticipantIdentity> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 1;
        private String identity_;
        private String room_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RoomParticipantIdentity, Builder> implements RoomParticipantIdentityOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RoomParticipantIdentity.DEFAULT_INSTANCE);
            }
        }

        static {
            RoomParticipantIdentity roomParticipantIdentity = new RoomParticipantIdentity();
            DEFAULT_INSTANCE = roomParticipantIdentity;
            GeneratedMessageLite.registerDefaultInstance(RoomParticipantIdentity.class, roomParticipantIdentity);
        }

        private RoomParticipantIdentity() {
            String strA = ap.a(1593630163);
            this.room_ = strA;
            this.identity_ = strA;
        }

        private void clearIdentity() {
            this.identity_ = getDefaultInstance().getIdentity();
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        public static RoomParticipantIdentity getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RoomParticipantIdentity parseDelimitedFrom(InputStream inputStream) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomParticipantIdentity parseFrom(ByteBuffer byteBuffer) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RoomParticipantIdentity> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setIdentity(String str) {
            str.getClass();
            this.identity_ = str;
        }

        private void setIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.identity_ = byteString.L();
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RoomParticipantIdentity();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"room_", "identity_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RoomParticipantIdentity> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RoomParticipantIdentity.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getIdentity() {
            return this.identity_;
        }

        public ByteString getIdentityBytes() {
            return ByteString.n(this.identity_);
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public static Builder newBuilder(RoomParticipantIdentity roomParticipantIdentity) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(roomParticipantIdentity);
        }

        public static RoomParticipantIdentity parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomParticipantIdentity parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RoomParticipantIdentity parseFrom(ByteString byteString) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RoomParticipantIdentity parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RoomParticipantIdentity parseFrom(byte[] bArr) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RoomParticipantIdentity parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RoomParticipantIdentity parseFrom(InputStream inputStream) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomParticipantIdentity parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomParticipantIdentity parseFrom(CodedInputStream codedInputStream) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RoomParticipantIdentity parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomParticipantIdentity) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RoomParticipantIdentityOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SendDataRequest extends GeneratedMessageLite<SendDataRequest, Builder> implements SendDataRequestOrBuilder {
        public static final int DATA_FIELD_NUMBER = 2;
        private static final SendDataRequest DEFAULT_INSTANCE;
        public static final int DESTINATION_IDENTITIES_FIELD_NUMBER = 6;
        public static final int DESTINATION_SIDS_FIELD_NUMBER = 4;
        public static final int KIND_FIELD_NUMBER = 3;
        public static final int NONCE_FIELD_NUMBER = 7;
        private static volatile Parser<SendDataRequest> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 1;
        public static final int TOPIC_FIELD_NUMBER = 5;
        private int bitField0_;
        private ByteString data_;
        private Internal.ProtobufList<String> destinationIdentities_;
        private Internal.ProtobufList<String> destinationSids_;
        private int kind_;
        private ByteString nonce_;
        private String room_;
        private String topic_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SendDataRequest, Builder> implements SendDataRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SendDataRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            SendDataRequest sendDataRequest = new SendDataRequest();
            DEFAULT_INSTANCE = sendDataRequest;
            GeneratedMessageLite.registerDefaultInstance(SendDataRequest.class, sendDataRequest);
        }

        private SendDataRequest() {
            String strA = ap.a(1579278316);
            this.room_ = strA;
            ByteString byteString = ByteString.b;
            this.data_ = byteString;
            this.destinationSids_ = GeneratedMessageLite.emptyProtobufList();
            this.destinationIdentities_ = GeneratedMessageLite.emptyProtobufList();
            this.topic_ = strA;
            this.nonce_ = byteString;
        }

        private void addAllDestinationIdentities(Iterable<String> iterable) {
            ensureDestinationIdentitiesIsMutable();
            AbstractMessageLite.addAll(iterable, this.destinationIdentities_);
        }

        private void addAllDestinationSids(Iterable<String> iterable) {
            ensureDestinationSidsIsMutable();
            AbstractMessageLite.addAll(iterable, this.destinationSids_);
        }

        private void addDestinationIdentities(String str) {
            str.getClass();
            ensureDestinationIdentitiesIsMutable();
            this.destinationIdentities_.add(str);
        }

        private void addDestinationIdentitiesBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureDestinationIdentitiesIsMutable();
            this.destinationIdentities_.add(byteString.L());
        }

        private void addDestinationSids(String str) {
            str.getClass();
            ensureDestinationSidsIsMutable();
            this.destinationSids_.add(str);
        }

        private void addDestinationSidsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureDestinationSidsIsMutable();
            this.destinationSids_.add(byteString.L());
        }

        private void clearData() {
            this.data_ = getDefaultInstance().getData();
        }

        private void clearDestinationIdentities() {
            this.destinationIdentities_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearDestinationSids() {
            this.destinationSids_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearKind() {
            this.kind_ = 0;
        }

        private void clearNonce() {
            this.nonce_ = getDefaultInstance().getNonce();
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        private void clearTopic() {
            this.bitField0_ &= -2;
            this.topic_ = getDefaultInstance().getTopic();
        }

        private void ensureDestinationIdentitiesIsMutable() {
            Internal.ProtobufList<String> protobufList = this.destinationIdentities_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.destinationIdentities_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureDestinationSidsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.destinationSids_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.destinationSids_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static SendDataRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SendDataRequest parseDelimitedFrom(InputStream inputStream) {
            return (SendDataRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SendDataRequest parseFrom(ByteBuffer byteBuffer) {
            return (SendDataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SendDataRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setData(ByteString byteString) {
            byteString.getClass();
            this.data_ = byteString;
        }

        private void setDestinationIdentities(int i, String str) {
            str.getClass();
            ensureDestinationIdentitiesIsMutable();
            this.destinationIdentities_.set(i, str);
        }

        private void setDestinationSids(int i, String str) {
            str.getClass();
            ensureDestinationSidsIsMutable();
            this.destinationSids_.set(i, str);
        }

        private void setKind(LivekitModels.DataPacket.Kind kind) {
            this.kind_ = kind.getNumber();
        }

        private void setKindValue(int i) {
            this.kind_ = i;
        }

        private void setNonce(ByteString byteString) {
            byteString.getClass();
            this.nonce_ = byteString;
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        private void setTopic(String str) {
            str.getClass();
            this.bitField0_ |= 1;
            this.topic_ = str;
        }

        private void setTopicBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.topic_ = byteString.L();
            this.bitField0_ |= 1;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SendDataRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0000\u0001\u0001\u0007\u0007\u0000\u0002\u0000\u0001Ȉ\u0002\n\u0003\f\u0004Ț\u0005ለ\u0000\u0006Ț\u0007\n", new Object[]{"bitField0_", "room_", "data_", "kind_", "destinationSids_", "topic_", "destinationIdentities_", "nonce_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SendDataRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SendDataRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public ByteString getData() {
            return this.data_;
        }

        public String getDestinationIdentities(int i) {
            return (String) this.destinationIdentities_.get(i);
        }

        public ByteString getDestinationIdentitiesBytes(int i) {
            return ByteString.n((String) this.destinationIdentities_.get(i));
        }

        public int getDestinationIdentitiesCount() {
            return this.destinationIdentities_.size();
        }

        public List<String> getDestinationIdentitiesList() {
            return this.destinationIdentities_;
        }

        @Deprecated
        public String getDestinationSids(int i) {
            return (String) this.destinationSids_.get(i);
        }

        @Deprecated
        public ByteString getDestinationSidsBytes(int i) {
            return ByteString.n((String) this.destinationSids_.get(i));
        }

        @Deprecated
        public int getDestinationSidsCount() {
            return this.destinationSids_.size();
        }

        @Deprecated
        public List<String> getDestinationSidsList() {
            return this.destinationSids_;
        }

        public LivekitModels.DataPacket.Kind getKind() {
            LivekitModels.DataPacket.Kind kindB = LivekitModels.DataPacket.Kind.b(this.kind_);
            return kindB == null ? LivekitModels.DataPacket.Kind.d : kindB;
        }

        public int getKindValue() {
            return this.kind_;
        }

        public ByteString getNonce() {
            return this.nonce_;
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public String getTopic() {
            return this.topic_;
        }

        public ByteString getTopicBytes() {
            return ByteString.n(this.topic_);
        }

        public boolean hasTopic() {
            return (this.bitField0_ & 1) != 0;
        }

        public static Builder newBuilder(SendDataRequest sendDataRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sendDataRequest);
        }

        public static SendDataRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SendDataRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SendDataRequest parseFrom(ByteString byteString) {
            return (SendDataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SendDataRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SendDataRequest parseFrom(byte[] bArr) {
            return (SendDataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SendDataRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SendDataRequest parseFrom(InputStream inputStream) {
            return (SendDataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SendDataRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SendDataRequest parseFrom(CodedInputStream codedInputStream) {
            return (SendDataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SendDataRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SendDataRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SendDataResponse extends GeneratedMessageLite<SendDataResponse, Builder> implements SendDataResponseOrBuilder {
        private static final SendDataResponse DEFAULT_INSTANCE;
        private static volatile Parser<SendDataResponse> PARSER;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SendDataResponse, Builder> implements SendDataResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SendDataResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            SendDataResponse sendDataResponse = new SendDataResponse();
            DEFAULT_INSTANCE = sendDataResponse;
            GeneratedMessageLite.registerDefaultInstance(SendDataResponse.class, sendDataResponse);
        }

        private SendDataResponse() {
        }

        public static SendDataResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SendDataResponse parseDelimitedFrom(InputStream inputStream) {
            return (SendDataResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SendDataResponse parseFrom(ByteBuffer byteBuffer) {
            return (SendDataResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SendDataResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SendDataResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0000", (Object[]) null);
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SendDataResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SendDataResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public static Builder newBuilder(SendDataResponse sendDataResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(sendDataResponse);
        }

        public static SendDataResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SendDataResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SendDataResponse parseFrom(ByteString byteString) {
            return (SendDataResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SendDataResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SendDataResponse parseFrom(byte[] bArr) {
            return (SendDataResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SendDataResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SendDataResponse parseFrom(InputStream inputStream) {
            return (SendDataResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SendDataResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SendDataResponse parseFrom(CodedInputStream codedInputStream) {
            return (SendDataResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SendDataResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SendDataResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SendDataResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateParticipantRequest extends GeneratedMessageLite<UpdateParticipantRequest, Builder> implements UpdateParticipantRequestOrBuilder {
        public static final int ATTRIBUTES_FIELD_NUMBER = 6;
        private static final UpdateParticipantRequest DEFAULT_INSTANCE;
        public static final int IDENTITY_FIELD_NUMBER = 2;
        public static final int METADATA_FIELD_NUMBER = 3;
        public static final int NAME_FIELD_NUMBER = 5;
        private static volatile Parser<UpdateParticipantRequest> PARSER = null;
        public static final int PERMISSION_FIELD_NUMBER = 4;
        public static final int ROOM_FIELD_NUMBER = 1;
        private MapFieldLite<String, String> attributes_ = MapFieldLite.f();
        private String identity_;
        private String metadata_;
        private String name_;
        private LivekitModels.ParticipantPermission permission_;
        private String room_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(972164668);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private AttributesDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateParticipantRequest, Builder> implements UpdateParticipantRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateParticipantRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateParticipantRequest updateParticipantRequest = new UpdateParticipantRequest();
            DEFAULT_INSTANCE = updateParticipantRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdateParticipantRequest.class, updateParticipantRequest);
        }

        private UpdateParticipantRequest() {
            String strA = ap.a(1339533086);
            this.room_ = strA;
            this.identity_ = strA;
            this.metadata_ = strA;
            this.name_ = strA;
        }

        private void clearIdentity() {
            this.identity_ = getDefaultInstance().getIdentity();
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearPermission() {
            this.permission_ = null;
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        public static UpdateParticipantRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableAttributesMap() {
            return internalGetMutableAttributes();
        }

        private MapFieldLite<String, String> internalGetAttributes() {
            return this.attributes_;
        }

        private MapFieldLite<String, String> internalGetMutableAttributes() {
            if (!this.attributes_.k()) {
                this.attributes_ = this.attributes_.n();
            }
            return this.attributes_;
        }

        private void mergePermission(LivekitModels.ParticipantPermission participantPermission) {
            participantPermission.getClass();
            LivekitModels.ParticipantPermission participantPermission2 = this.permission_;
            if (participantPermission2 == null || participantPermission2 == LivekitModels.ParticipantPermission.getDefaultInstance()) {
                this.permission_ = participantPermission;
            } else {
                this.permission_ = (LivekitModels.ParticipantPermission) ((LivekitModels.ParticipantPermission.Builder) LivekitModels.ParticipantPermission.newBuilder(this.permission_).v(participantPermission)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateParticipantRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateParticipantRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateParticipantRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setIdentity(String str) {
            str.getClass();
            this.identity_ = str;
        }

        private void setIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.identity_ = byteString.L();
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setPermission(LivekitModels.ParticipantPermission participantPermission) {
            participantPermission.getClass();
            this.permission_ = participantPermission;
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        public boolean containsAttributes(String str) {
            str.getClass();
            return internalGetAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateParticipantRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0001\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\t\u0005Ȉ\u00062", new Object[]{"room_", "identity_", "metadata_", "permission_", "name_", "attributes_", AttributesDefaultEntryHolder.a});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateParticipantRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateParticipantRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public Map<String, String> getAttributes() {
            return getAttributesMap();
        }

        public int getAttributesCount() {
            return internalGetAttributes().size();
        }

        public Map<String, String> getAttributesMap() {
            return Collections.unmodifiableMap(internalGetAttributes());
        }

        public String getAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            return mapFieldLiteInternalGetAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetAttributes.get(str) : str2;
        }

        public String getAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            if (mapFieldLiteInternalGetAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getIdentity() {
            return this.identity_;
        }

        public ByteString getIdentityBytes() {
            return ByteString.n(this.identity_);
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public LivekitModels.ParticipantPermission getPermission() {
            LivekitModels.ParticipantPermission participantPermission = this.permission_;
            return participantPermission == null ? LivekitModels.ParticipantPermission.getDefaultInstance() : participantPermission;
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public boolean hasPermission() {
            return this.permission_ != null;
        }

        public static Builder newBuilder(UpdateParticipantRequest updateParticipantRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateParticipantRequest);
        }

        public static UpdateParticipantRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateParticipantRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateParticipantRequest parseFrom(ByteString byteString) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateParticipantRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateParticipantRequest parseFrom(byte[] bArr) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateParticipantRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateParticipantRequest parseFrom(InputStream inputStream) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateParticipantRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateParticipantRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateParticipantRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateParticipantRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateParticipantRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateRoomMetadataRequest extends GeneratedMessageLite<UpdateRoomMetadataRequest, Builder> implements UpdateRoomMetadataRequestOrBuilder {
        private static final UpdateRoomMetadataRequest DEFAULT_INSTANCE;
        public static final int METADATA_FIELD_NUMBER = 2;
        private static volatile Parser<UpdateRoomMetadataRequest> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 1;
        private String metadata_;
        private String room_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateRoomMetadataRequest, Builder> implements UpdateRoomMetadataRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateRoomMetadataRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateRoomMetadataRequest updateRoomMetadataRequest = new UpdateRoomMetadataRequest();
            DEFAULT_INSTANCE = updateRoomMetadataRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdateRoomMetadataRequest.class, updateRoomMetadataRequest);
        }

        private UpdateRoomMetadataRequest() {
            String strA = ap.a(1524026125);
            this.room_ = strA;
            this.metadata_ = strA;
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        public static UpdateRoomMetadataRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateRoomMetadataRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateRoomMetadataRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateRoomMetadataRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateRoomMetadataRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"room_", "metadata_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateRoomMetadataRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateRoomMetadataRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public static Builder newBuilder(UpdateRoomMetadataRequest updateRoomMetadataRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateRoomMetadataRequest);
        }

        public static UpdateRoomMetadataRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateRoomMetadataRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateRoomMetadataRequest parseFrom(ByteString byteString) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateRoomMetadataRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateRoomMetadataRequest parseFrom(byte[] bArr) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateRoomMetadataRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateRoomMetadataRequest parseFrom(InputStream inputStream) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateRoomMetadataRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateRoomMetadataRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateRoomMetadataRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateRoomMetadataRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateRoomMetadataRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateSubscriptionsRequest extends GeneratedMessageLite<UpdateSubscriptionsRequest, Builder> implements UpdateSubscriptionsRequestOrBuilder {
        private static final UpdateSubscriptionsRequest DEFAULT_INSTANCE;
        public static final int IDENTITY_FIELD_NUMBER = 2;
        private static volatile Parser<UpdateSubscriptionsRequest> PARSER = null;
        public static final int PARTICIPANT_TRACKS_FIELD_NUMBER = 5;
        public static final int ROOM_FIELD_NUMBER = 1;
        public static final int SUBSCRIBE_FIELD_NUMBER = 4;
        public static final int TRACK_SIDS_FIELD_NUMBER = 3;
        private String identity_;
        private Internal.ProtobufList<LivekitModels.ParticipantTracks> participantTracks_;
        private String room_;
        private boolean subscribe_;
        private Internal.ProtobufList<String> trackSids_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateSubscriptionsRequest, Builder> implements UpdateSubscriptionsRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateSubscriptionsRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateSubscriptionsRequest updateSubscriptionsRequest = new UpdateSubscriptionsRequest();
            DEFAULT_INSTANCE = updateSubscriptionsRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdateSubscriptionsRequest.class, updateSubscriptionsRequest);
        }

        private UpdateSubscriptionsRequest() {
            String strA = ap.a(330064127);
            this.room_ = strA;
            this.identity_ = strA;
            this.trackSids_ = GeneratedMessageLite.emptyProtobufList();
            this.participantTracks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllParticipantTracks(Iterable<? extends LivekitModels.ParticipantTracks> iterable) {
            ensureParticipantTracksIsMutable();
            AbstractMessageLite.addAll(iterable, this.participantTracks_);
        }

        private void addAllTrackSids(Iterable<String> iterable) {
            ensureTrackSidsIsMutable();
            AbstractMessageLite.addAll(iterable, this.trackSids_);
        }

        private void addParticipantTracks(LivekitModels.ParticipantTracks participantTracks) {
            participantTracks.getClass();
            ensureParticipantTracksIsMutable();
            this.participantTracks_.add(participantTracks);
        }

        private void addTrackSids(String str) {
            str.getClass();
            ensureTrackSidsIsMutable();
            this.trackSids_.add(str);
        }

        private void addTrackSidsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureTrackSidsIsMutable();
            this.trackSids_.add(byteString.L());
        }

        private void clearIdentity() {
            this.identity_ = getDefaultInstance().getIdentity();
        }

        private void clearParticipantTracks() {
            this.participantTracks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        private void clearSubscribe() {
            this.subscribe_ = false;
        }

        private void clearTrackSids() {
            this.trackSids_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureParticipantTracksIsMutable() {
            Internal.ProtobufList<LivekitModels.ParticipantTracks> protobufList = this.participantTracks_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.participantTracks_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureTrackSidsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.trackSids_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.trackSids_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static UpdateSubscriptionsRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateSubscriptionsRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSubscriptionsRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateSubscriptionsRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeParticipantTracks(int i) {
            ensureParticipantTracksIsMutable();
            this.participantTracks_.remove(i);
        }

        private void setIdentity(String str) {
            str.getClass();
            this.identity_ = str;
        }

        private void setIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.identity_ = byteString.L();
        }

        private void setParticipantTracks(int i, LivekitModels.ParticipantTracks participantTracks) {
            participantTracks.getClass();
            ensureParticipantTracksIsMutable();
            this.participantTracks_.set(i, participantTracks);
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        private void setSubscribe(boolean z) {
            this.subscribe_ = z;
        }

        private void setTrackSids(int i, String str) {
            str.getClass();
            ensureTrackSidsIsMutable();
            this.trackSids_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateSubscriptionsRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0002\u0000\u0001Ȉ\u0002Ȉ\u0003Ț\u0004\u0007\u0005\u001b", new Object[]{"room_", "identity_", "trackSids_", "subscribe_", "participantTracks_", LivekitModels.ParticipantTracks.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateSubscriptionsRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateSubscriptionsRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getIdentity() {
            return this.identity_;
        }

        public ByteString getIdentityBytes() {
            return ByteString.n(this.identity_);
        }

        public LivekitModels.ParticipantTracks getParticipantTracks(int i) {
            return (LivekitModels.ParticipantTracks) this.participantTracks_.get(i);
        }

        public int getParticipantTracksCount() {
            return this.participantTracks_.size();
        }

        public List<LivekitModels.ParticipantTracks> getParticipantTracksList() {
            return this.participantTracks_;
        }

        public LivekitModels.ParticipantTracksOrBuilder getParticipantTracksOrBuilder(int i) {
            return (LivekitModels.ParticipantTracksOrBuilder) this.participantTracks_.get(i);
        }

        public List<? extends LivekitModels.ParticipantTracksOrBuilder> getParticipantTracksOrBuilderList() {
            return this.participantTracks_;
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public boolean getSubscribe() {
            return this.subscribe_;
        }

        public String getTrackSids(int i) {
            return (String) this.trackSids_.get(i);
        }

        public ByteString getTrackSidsBytes(int i) {
            return ByteString.n((String) this.trackSids_.get(i));
        }

        public int getTrackSidsCount() {
            return this.trackSids_.size();
        }

        public List<String> getTrackSidsList() {
            return this.trackSids_;
        }

        public static Builder newBuilder(UpdateSubscriptionsRequest updateSubscriptionsRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateSubscriptionsRequest);
        }

        public static UpdateSubscriptionsRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSubscriptionsRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateSubscriptionsRequest parseFrom(ByteString byteString) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addParticipantTracks(int i, LivekitModels.ParticipantTracks participantTracks) {
            participantTracks.getClass();
            ensureParticipantTracksIsMutable();
            this.participantTracks_.add(i, participantTracks);
        }

        public static UpdateSubscriptionsRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateSubscriptionsRequest parseFrom(byte[] bArr) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateSubscriptionsRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateSubscriptionsRequest parseFrom(InputStream inputStream) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSubscriptionsRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSubscriptionsRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateSubscriptionsRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateSubscriptionsRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateSubscriptionsResponse extends GeneratedMessageLite<UpdateSubscriptionsResponse, Builder> implements UpdateSubscriptionsResponseOrBuilder {
        private static final UpdateSubscriptionsResponse DEFAULT_INSTANCE;
        private static volatile Parser<UpdateSubscriptionsResponse> PARSER;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateSubscriptionsResponse, Builder> implements UpdateSubscriptionsResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateSubscriptionsResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateSubscriptionsResponse updateSubscriptionsResponse = new UpdateSubscriptionsResponse();
            DEFAULT_INSTANCE = updateSubscriptionsResponse;
            GeneratedMessageLite.registerDefaultInstance(UpdateSubscriptionsResponse.class, updateSubscriptionsResponse);
        }

        private UpdateSubscriptionsResponse() {
        }

        public static UpdateSubscriptionsResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateSubscriptionsResponse parseDelimitedFrom(InputStream inputStream) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSubscriptionsResponse parseFrom(ByteBuffer byteBuffer) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateSubscriptionsResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateSubscriptionsResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0000", (Object[]) null);
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateSubscriptionsResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateSubscriptionsResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public static Builder newBuilder(UpdateSubscriptionsResponse updateSubscriptionsResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateSubscriptionsResponse);
        }

        public static UpdateSubscriptionsResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSubscriptionsResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateSubscriptionsResponse parseFrom(ByteString byteString) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateSubscriptionsResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateSubscriptionsResponse parseFrom(byte[] bArr) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateSubscriptionsResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateSubscriptionsResponse parseFrom(InputStream inputStream) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateSubscriptionsResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateSubscriptionsResponse parseFrom(CodedInputStream codedInputStream) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateSubscriptionsResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateSubscriptionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateSubscriptionsResponseOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitRoom() {
    }
}