package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;
import livekit.LivekitAgent;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitAgentDispatch {

    /* JADX INFO: renamed from: livekit.LivekitAgentDispatch$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AgentDispatch extends GeneratedMessageLite<AgentDispatch, Builder> implements AgentDispatchOrBuilder {
        public static final int AGENT_NAME_FIELD_NUMBER = 2;
        private static final AgentDispatch DEFAULT_INSTANCE;
        public static final int ID_FIELD_NUMBER = 1;
        public static final int METADATA_FIELD_NUMBER = 4;
        private static volatile Parser<AgentDispatch> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 3;
        public static final int STATE_FIELD_NUMBER = 5;
        private String agentName_;
        private String id_;
        private String metadata_;
        private String room_;
        private AgentDispatchState state_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AgentDispatch, Builder> implements AgentDispatchOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AgentDispatch.DEFAULT_INSTANCE);
            }
        }

        static {
            AgentDispatch agentDispatch = new AgentDispatch();
            DEFAULT_INSTANCE = agentDispatch;
            GeneratedMessageLite.registerDefaultInstance(AgentDispatch.class, agentDispatch);
        }

        private AgentDispatch() {
            String strA = ap.a(1720811104);
            this.id_ = strA;
            this.agentName_ = strA;
            this.room_ = strA;
            this.metadata_ = strA;
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        private void clearState() {
            this.state_ = null;
        }

        public static AgentDispatch getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeState(AgentDispatchState agentDispatchState) {
            agentDispatchState.getClass();
            AgentDispatchState agentDispatchState2 = this.state_;
            if (agentDispatchState2 == null || agentDispatchState2 == AgentDispatchState.getDefaultInstance()) {
                this.state_ = agentDispatchState;
            } else {
                this.state_ = (AgentDispatchState) ((AgentDispatchState.Builder) AgentDispatchState.newBuilder(this.state_).v(agentDispatchState)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AgentDispatch parseDelimitedFrom(InputStream inputStream) {
            return (AgentDispatch) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentDispatch parseFrom(ByteBuffer byteBuffer) {
            return (AgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AgentDispatch> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        private void setState(AgentDispatchState agentDispatchState) {
            agentDispatchState.getClass();
            this.state_ = agentDispatchState;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AgentDispatch();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005\t", new Object[]{"id_", "agentName_", "room_", "metadata_", "state_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AgentDispatch> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AgentDispatch.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public AgentDispatchState getState() {
            AgentDispatchState agentDispatchState = this.state_;
            return agentDispatchState == null ? AgentDispatchState.getDefaultInstance() : agentDispatchState;
        }

        public boolean hasState() {
            return this.state_ != null;
        }

        public static Builder newBuilder(AgentDispatch agentDispatch) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(agentDispatch);
        }

        public static AgentDispatch parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatch) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentDispatch parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AgentDispatch parseFrom(ByteString byteString) {
            return (AgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AgentDispatch parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AgentDispatch parseFrom(byte[] bArr) {
            return (AgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AgentDispatch parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AgentDispatch parseFrom(InputStream inputStream) {
            return (AgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentDispatch parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentDispatch parseFrom(CodedInputStream codedInputStream) {
            return (AgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AgentDispatch parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AgentDispatchOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AgentDispatchState extends GeneratedMessageLite<AgentDispatchState, Builder> implements AgentDispatchStateOrBuilder {
        public static final int CREATED_AT_FIELD_NUMBER = 2;
        private static final AgentDispatchState DEFAULT_INSTANCE;
        public static final int DELETED_AT_FIELD_NUMBER = 3;
        public static final int JOBS_FIELD_NUMBER = 1;
        private static volatile Parser<AgentDispatchState> PARSER;
        private long createdAt_;
        private long deletedAt_;
        private Internal.ProtobufList<LivekitAgent.Job> jobs_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AgentDispatchState, Builder> implements AgentDispatchStateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AgentDispatchState.DEFAULT_INSTANCE);
            }
        }

        static {
            AgentDispatchState agentDispatchState = new AgentDispatchState();
            DEFAULT_INSTANCE = agentDispatchState;
            GeneratedMessageLite.registerDefaultInstance(AgentDispatchState.class, agentDispatchState);
        }

        private AgentDispatchState() {
        }

        private void addAllJobs(Iterable<? extends LivekitAgent.Job> iterable) {
            ensureJobsIsMutable();
            AbstractMessageLite.addAll(iterable, this.jobs_);
        }

        private void addJobs(LivekitAgent.Job job) {
            job.getClass();
            ensureJobsIsMutable();
            this.jobs_.add(job);
        }

        private void clearCreatedAt() {
            this.createdAt_ = 0L;
        }

        private void clearDeletedAt() {
            this.deletedAt_ = 0L;
        }

        private void clearJobs() {
            this.jobs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureJobsIsMutable() {
            Internal.ProtobufList<LivekitAgent.Job> protobufList = this.jobs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.jobs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static AgentDispatchState getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AgentDispatchState parseDelimitedFrom(InputStream inputStream) {
            return (AgentDispatchState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentDispatchState parseFrom(ByteBuffer byteBuffer) {
            return (AgentDispatchState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AgentDispatchState> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeJobs(int i) {
            ensureJobsIsMutable();
            this.jobs_.remove(i);
        }

        private void setCreatedAt(long j) {
            this.createdAt_ = j;
        }

        private void setDeletedAt(long j) {
            this.deletedAt_ = j;
        }

        private void setJobs(int i, LivekitAgent.Job job) {
            job.getClass();
            ensureJobsIsMutable();
            this.jobs_.set(i, job);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AgentDispatchState();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0001\u0000\u0001\u001b\u0002\u0002\u0003\u0002", new Object[]{ap.a(591637382), LivekitAgent.Job.class, ap.a(1266478052), ap.a(1454825941)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AgentDispatchState> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AgentDispatchState.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getCreatedAt() {
            return this.createdAt_;
        }

        public long getDeletedAt() {
            return this.deletedAt_;
        }

        public LivekitAgent.Job getJobs(int i) {
            return (LivekitAgent.Job) this.jobs_.get(i);
        }

        public int getJobsCount() {
            return this.jobs_.size();
        }

        public List<LivekitAgent.Job> getJobsList() {
            return this.jobs_;
        }

        public LivekitAgent.JobOrBuilder getJobsOrBuilder(int i) {
            return (LivekitAgent.JobOrBuilder) this.jobs_.get(i);
        }

        public List<? extends LivekitAgent.JobOrBuilder> getJobsOrBuilderList() {
            return this.jobs_;
        }

        public static Builder newBuilder(AgentDispatchState agentDispatchState) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(agentDispatchState);
        }

        public static AgentDispatchState parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatchState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentDispatchState parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatchState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AgentDispatchState parseFrom(ByteString byteString) {
            return (AgentDispatchState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addJobs(int i, LivekitAgent.Job job) {
            job.getClass();
            ensureJobsIsMutable();
            this.jobs_.add(i, job);
        }

        public static AgentDispatchState parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatchState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AgentDispatchState parseFrom(byte[] bArr) {
            return (AgentDispatchState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AgentDispatchState parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatchState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AgentDispatchState parseFrom(InputStream inputStream) {
            return (AgentDispatchState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentDispatchState parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatchState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentDispatchState parseFrom(CodedInputStream codedInputStream) {
            return (AgentDispatchState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AgentDispatchState parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDispatchState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AgentDispatchStateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class CreateAgentDispatchRequest extends GeneratedMessageLite<CreateAgentDispatchRequest, Builder> implements CreateAgentDispatchRequestOrBuilder {
        public static final int AGENT_NAME_FIELD_NUMBER = 1;
        private static final CreateAgentDispatchRequest DEFAULT_INSTANCE;
        public static final int METADATA_FIELD_NUMBER = 3;
        private static volatile Parser<CreateAgentDispatchRequest> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 2;
        private String agentName_;
        private String metadata_;
        private String room_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<CreateAgentDispatchRequest, Builder> implements CreateAgentDispatchRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(CreateAgentDispatchRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            CreateAgentDispatchRequest createAgentDispatchRequest = new CreateAgentDispatchRequest();
            DEFAULT_INSTANCE = createAgentDispatchRequest;
            GeneratedMessageLite.registerDefaultInstance(CreateAgentDispatchRequest.class, createAgentDispatchRequest);
        }

        private CreateAgentDispatchRequest() {
            String strA = ap.a(1696190159);
            this.agentName_ = strA;
            this.room_ = strA;
            this.metadata_ = strA;
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        public static CreateAgentDispatchRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static CreateAgentDispatchRequest parseDelimitedFrom(InputStream inputStream) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateAgentDispatchRequest parseFrom(ByteBuffer byteBuffer) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<CreateAgentDispatchRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new CreateAgentDispatchRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ", new Object[]{"agentName_", "room_", "metadata_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<CreateAgentDispatchRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (CreateAgentDispatchRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public static Builder newBuilder(CreateAgentDispatchRequest createAgentDispatchRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(createAgentDispatchRequest);
        }

        public static CreateAgentDispatchRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateAgentDispatchRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static CreateAgentDispatchRequest parseFrom(ByteString byteString) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static CreateAgentDispatchRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static CreateAgentDispatchRequest parseFrom(byte[] bArr) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static CreateAgentDispatchRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static CreateAgentDispatchRequest parseFrom(InputStream inputStream) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateAgentDispatchRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateAgentDispatchRequest parseFrom(CodedInputStream codedInputStream) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static CreateAgentDispatchRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface CreateAgentDispatchRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DeleteAgentDispatchRequest extends GeneratedMessageLite<DeleteAgentDispatchRequest, Builder> implements DeleteAgentDispatchRequestOrBuilder {
        private static final DeleteAgentDispatchRequest DEFAULT_INSTANCE;
        public static final int DISPATCH_ID_FIELD_NUMBER = 1;
        private static volatile Parser<DeleteAgentDispatchRequest> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 2;
        private String dispatchId_;
        private String room_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DeleteAgentDispatchRequest, Builder> implements DeleteAgentDispatchRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DeleteAgentDispatchRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            DeleteAgentDispatchRequest deleteAgentDispatchRequest = new DeleteAgentDispatchRequest();
            DEFAULT_INSTANCE = deleteAgentDispatchRequest;
            GeneratedMessageLite.registerDefaultInstance(DeleteAgentDispatchRequest.class, deleteAgentDispatchRequest);
        }

        private DeleteAgentDispatchRequest() {
            String strA = ap.a(181635545);
            this.dispatchId_ = strA;
            this.room_ = strA;
        }

        private void clearDispatchId() {
            this.dispatchId_ = getDefaultInstance().getDispatchId();
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        public static DeleteAgentDispatchRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DeleteAgentDispatchRequest parseDelimitedFrom(InputStream inputStream) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteAgentDispatchRequest parseFrom(ByteBuffer byteBuffer) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DeleteAgentDispatchRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDispatchId(String str) {
            str.getClass();
            this.dispatchId_ = str;
        }

        private void setDispatchIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.dispatchId_ = byteString.L();
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DeleteAgentDispatchRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"dispatchId_", "room_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DeleteAgentDispatchRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DeleteAgentDispatchRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getDispatchId() {
            return this.dispatchId_;
        }

        public ByteString getDispatchIdBytes() {
            return ByteString.n(this.dispatchId_);
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public static Builder newBuilder(DeleteAgentDispatchRequest deleteAgentDispatchRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(deleteAgentDispatchRequest);
        }

        public static DeleteAgentDispatchRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteAgentDispatchRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DeleteAgentDispatchRequest parseFrom(ByteString byteString) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DeleteAgentDispatchRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DeleteAgentDispatchRequest parseFrom(byte[] bArr) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DeleteAgentDispatchRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DeleteAgentDispatchRequest parseFrom(InputStream inputStream) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteAgentDispatchRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteAgentDispatchRequest parseFrom(CodedInputStream codedInputStream) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DeleteAgentDispatchRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DeleteAgentDispatchRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListAgentDispatchRequest extends GeneratedMessageLite<ListAgentDispatchRequest, Builder> implements ListAgentDispatchRequestOrBuilder {
        private static final ListAgentDispatchRequest DEFAULT_INSTANCE;
        public static final int DISPATCH_ID_FIELD_NUMBER = 1;
        private static volatile Parser<ListAgentDispatchRequest> PARSER = null;
        public static final int ROOM_FIELD_NUMBER = 2;
        private String dispatchId_;
        private String room_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListAgentDispatchRequest, Builder> implements ListAgentDispatchRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListAgentDispatchRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListAgentDispatchRequest listAgentDispatchRequest = new ListAgentDispatchRequest();
            DEFAULT_INSTANCE = listAgentDispatchRequest;
            GeneratedMessageLite.registerDefaultInstance(ListAgentDispatchRequest.class, listAgentDispatchRequest);
        }

        private ListAgentDispatchRequest() {
            String strA = ap.a(1347680968);
            this.dispatchId_ = strA;
            this.room_ = strA;
        }

        private void clearDispatchId() {
            this.dispatchId_ = getDefaultInstance().getDispatchId();
        }

        private void clearRoom() {
            this.room_ = getDefaultInstance().getRoom();
        }

        public static ListAgentDispatchRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListAgentDispatchRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentDispatchRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListAgentDispatchRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDispatchId(String str) {
            str.getClass();
            this.dispatchId_ = str;
        }

        private void setDispatchIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.dispatchId_ = byteString.L();
        }

        private void setRoom(String str) {
            str.getClass();
            this.room_ = str;
        }

        private void setRoomBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.room_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListAgentDispatchRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"dispatchId_", "room_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListAgentDispatchRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListAgentDispatchRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getDispatchId() {
            return this.dispatchId_;
        }

        public ByteString getDispatchIdBytes() {
            return ByteString.n(this.dispatchId_);
        }

        public String getRoom() {
            return this.room_;
        }

        public ByteString getRoomBytes() {
            return ByteString.n(this.room_);
        }

        public static Builder newBuilder(ListAgentDispatchRequest listAgentDispatchRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listAgentDispatchRequest);
        }

        public static ListAgentDispatchRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentDispatchRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListAgentDispatchRequest parseFrom(ByteString byteString) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListAgentDispatchRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListAgentDispatchRequest parseFrom(byte[] bArr) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListAgentDispatchRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListAgentDispatchRequest parseFrom(InputStream inputStream) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentDispatchRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentDispatchRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListAgentDispatchRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListAgentDispatchRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListAgentDispatchResponse extends GeneratedMessageLite<ListAgentDispatchResponse, Builder> implements ListAgentDispatchResponseOrBuilder {
        public static final int AGENT_DISPATCHES_FIELD_NUMBER = 1;
        private static final ListAgentDispatchResponse DEFAULT_INSTANCE;
        private static volatile Parser<ListAgentDispatchResponse> PARSER;
        private Internal.ProtobufList<AgentDispatch> agentDispatches_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListAgentDispatchResponse, Builder> implements ListAgentDispatchResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListAgentDispatchResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListAgentDispatchResponse listAgentDispatchResponse = new ListAgentDispatchResponse();
            DEFAULT_INSTANCE = listAgentDispatchResponse;
            GeneratedMessageLite.registerDefaultInstance(ListAgentDispatchResponse.class, listAgentDispatchResponse);
        }

        private ListAgentDispatchResponse() {
        }

        private void addAgentDispatches(AgentDispatch agentDispatch) {
            agentDispatch.getClass();
            ensureAgentDispatchesIsMutable();
            this.agentDispatches_.add(agentDispatch);
        }

        private void addAllAgentDispatches(Iterable<? extends AgentDispatch> iterable) {
            ensureAgentDispatchesIsMutable();
            AbstractMessageLite.addAll(iterable, this.agentDispatches_);
        }

        private void clearAgentDispatches() {
            this.agentDispatches_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureAgentDispatchesIsMutable() {
            Internal.ProtobufList<AgentDispatch> protobufList = this.agentDispatches_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.agentDispatches_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListAgentDispatchResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListAgentDispatchResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentDispatchResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListAgentDispatchResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeAgentDispatches(int i) {
            ensureAgentDispatchesIsMutable();
            this.agentDispatches_.remove(i);
        }

        private void setAgentDispatches(int i, AgentDispatch agentDispatch) {
            agentDispatch.getClass();
            ensureAgentDispatchesIsMutable();
            this.agentDispatches_.set(i, agentDispatch);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListAgentDispatchResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1491383685), AgentDispatch.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListAgentDispatchResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListAgentDispatchResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AgentDispatch getAgentDispatches(int i) {
            return (AgentDispatch) this.agentDispatches_.get(i);
        }

        public int getAgentDispatchesCount() {
            return this.agentDispatches_.size();
        }

        public List<AgentDispatch> getAgentDispatchesList() {
            return this.agentDispatches_;
        }

        public AgentDispatchOrBuilder getAgentDispatchesOrBuilder(int i) {
            return (AgentDispatchOrBuilder) this.agentDispatches_.get(i);
        }

        public List<? extends AgentDispatchOrBuilder> getAgentDispatchesOrBuilderList() {
            return this.agentDispatches_;
        }

        public static Builder newBuilder(ListAgentDispatchResponse listAgentDispatchResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listAgentDispatchResponse);
        }

        public static ListAgentDispatchResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentDispatchResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListAgentDispatchResponse parseFrom(ByteString byteString) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addAgentDispatches(int i, AgentDispatch agentDispatch) {
            agentDispatch.getClass();
            ensureAgentDispatchesIsMutable();
            this.agentDispatches_.add(i, agentDispatch);
        }

        public static ListAgentDispatchResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListAgentDispatchResponse parseFrom(byte[] bArr) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListAgentDispatchResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListAgentDispatchResponse parseFrom(InputStream inputStream) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentDispatchResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentDispatchResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListAgentDispatchResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentDispatchResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListAgentDispatchResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RoomAgentDispatch extends GeneratedMessageLite<RoomAgentDispatch, Builder> implements RoomAgentDispatchOrBuilder {
        public static final int AGENT_NAME_FIELD_NUMBER = 1;
        private static final RoomAgentDispatch DEFAULT_INSTANCE;
        public static final int METADATA_FIELD_NUMBER = 2;
        private static volatile Parser<RoomAgentDispatch> PARSER;
        private String agentName_;
        private String metadata_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RoomAgentDispatch, Builder> implements RoomAgentDispatchOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RoomAgentDispatch.DEFAULT_INSTANCE);
            }
        }

        static {
            RoomAgentDispatch roomAgentDispatch = new RoomAgentDispatch();
            DEFAULT_INSTANCE = roomAgentDispatch;
            GeneratedMessageLite.registerDefaultInstance(RoomAgentDispatch.class, roomAgentDispatch);
        }

        private RoomAgentDispatch() {
            String strA = ap.a(1490869023);
            this.agentName_ = strA;
            this.metadata_ = strA;
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        public static RoomAgentDispatch getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RoomAgentDispatch parseDelimitedFrom(InputStream inputStream) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomAgentDispatch parseFrom(ByteBuffer byteBuffer) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RoomAgentDispatch> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RoomAgentDispatch();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"agentName_", "metadata_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RoomAgentDispatch> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RoomAgentDispatch.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        public static Builder newBuilder(RoomAgentDispatch roomAgentDispatch) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(roomAgentDispatch);
        }

        public static RoomAgentDispatch parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomAgentDispatch parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RoomAgentDispatch parseFrom(ByteString byteString) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RoomAgentDispatch parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RoomAgentDispatch parseFrom(byte[] bArr) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RoomAgentDispatch parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RoomAgentDispatch parseFrom(InputStream inputStream) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomAgentDispatch parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomAgentDispatch parseFrom(CodedInputStream codedInputStream) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RoomAgentDispatch parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomAgentDispatch) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RoomAgentDispatchOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitAgentDispatch() {
    }
}