package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;
import livekit.LivekitAgentDispatch;
import livekit.LivekitEgress;
import livekit.LivekitModels;
import livekit.LivekitRoom;
import livekit.LivekitRtc;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitInternal {

    /* JADX INFO: renamed from: livekit.LivekitInternal$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum ICECandidateType implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<ICECandidateType>() { // from class: livekit.LivekitInternal.ICECandidateType.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public ICECandidateType findValueByNumber(int i) {
                return ICECandidateType.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class ICECandidateTypeVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new ICECandidateTypeVerifier();

            private ICECandidateTypeVerifier() {
            }

            public boolean isInRange(int i) {
                return ICECandidateType.b(i) != null;
            }
        }

        ICECandidateType(int i) {
            this.a = i;
        }

        public static ICECandidateType b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ICEConfig extends GeneratedMessageLite<ICEConfig, Builder> implements ICEConfigOrBuilder {
        private static final ICEConfig DEFAULT_INSTANCE;
        private static volatile Parser<ICEConfig> PARSER = null;
        public static final int PREFERENCE_PUBLISHER_FIELD_NUMBER = 2;
        public static final int PREFERENCE_SUBSCRIBER_FIELD_NUMBER = 1;
        private int preferencePublisher_;
        private int preferenceSubscriber_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ICEConfig, Builder> implements ICEConfigOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ICEConfig.DEFAULT_INSTANCE);
            }
        }

        static {
            ICEConfig iCEConfig = new ICEConfig();
            DEFAULT_INSTANCE = iCEConfig;
            GeneratedMessageLite.registerDefaultInstance(ICEConfig.class, iCEConfig);
        }

        private ICEConfig() {
        }

        private void clearPreferencePublisher() {
            this.preferencePublisher_ = 0;
        }

        private void clearPreferenceSubscriber() {
            this.preferenceSubscriber_ = 0;
        }

        public static ICEConfig getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ICEConfig parseDelimitedFrom(InputStream inputStream) {
            return (ICEConfig) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ICEConfig parseFrom(ByteBuffer byteBuffer) {
            return (ICEConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ICEConfig> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setPreferencePublisher(ICECandidateType iCECandidateType) {
            this.preferencePublisher_ = iCECandidateType.getNumber();
        }

        private void setPreferencePublisherValue(int i) {
            this.preferencePublisher_ = i;
        }

        private void setPreferenceSubscriber(ICECandidateType iCECandidateType) {
            this.preferenceSubscriber_ = iCECandidateType.getNumber();
        }

        private void setPreferenceSubscriberValue(int i) {
            this.preferenceSubscriber_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ICEConfig();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\f\u0002\f", new Object[]{ap.a(689664271), ap.a(1155598482)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ICEConfig> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ICEConfig.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public ICECandidateType getPreferencePublisher() {
            ICECandidateType iCECandidateTypeB = ICECandidateType.b(this.preferencePublisher_);
            return iCECandidateTypeB == null ? ICECandidateType.e : iCECandidateTypeB;
        }

        public int getPreferencePublisherValue() {
            return this.preferencePublisher_;
        }

        public ICECandidateType getPreferenceSubscriber() {
            ICECandidateType iCECandidateTypeB = ICECandidateType.b(this.preferenceSubscriber_);
            return iCECandidateTypeB == null ? ICECandidateType.e : iCECandidateTypeB;
        }

        public int getPreferenceSubscriberValue() {
            return this.preferenceSubscriber_;
        }

        public static Builder newBuilder(ICEConfig iCEConfig) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(iCEConfig);
        }

        public static ICEConfig parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEConfig) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ICEConfig parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ICEConfig parseFrom(ByteString byteString) {
            return (ICEConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ICEConfig parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ICEConfig parseFrom(byte[] bArr) {
            return (ICEConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ICEConfig parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ICEConfig parseFrom(InputStream inputStream) {
            return (ICEConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ICEConfig parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ICEConfig parseFrom(CodedInputStream codedInputStream) {
            return (ICEConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ICEConfig parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ICEConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ICEConfigOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class Node extends GeneratedMessageLite<Node, Builder> implements NodeOrBuilder {
        private static final Node DEFAULT_INSTANCE;
        public static final int ID_FIELD_NUMBER = 1;
        public static final int IP_FIELD_NUMBER = 2;
        public static final int NUM_CPUS_FIELD_NUMBER = 3;
        private static volatile Parser<Node> PARSER = null;
        public static final int REGION_FIELD_NUMBER = 7;
        public static final int STATE_FIELD_NUMBER = 6;
        public static final int STATS_FIELD_NUMBER = 4;
        public static final int TYPE_FIELD_NUMBER = 5;
        private String id_;
        private String ip_;
        private int numCpus_;
        private String region_;
        private int state_;
        private NodeStats stats_;
        private int type_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<Node, Builder> implements NodeOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(Node.DEFAULT_INSTANCE);
            }
        }

        static {
            Node node = new Node();
            DEFAULT_INSTANCE = node;
            GeneratedMessageLite.registerDefaultInstance(Node.class, node);
        }

        private Node() {
            String strA = ap.a(628280339);
            this.id_ = strA;
            this.ip_ = strA;
            this.region_ = strA;
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearIp() {
            this.ip_ = getDefaultInstance().getIp();
        }

        private void clearNumCpus() {
            this.numCpus_ = 0;
        }

        private void clearRegion() {
            this.region_ = getDefaultInstance().getRegion();
        }

        private void clearState() {
            this.state_ = 0;
        }

        private void clearStats() {
            this.stats_ = null;
        }

        private void clearType() {
            this.type_ = 0;
        }

        public static Node getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeStats(NodeStats nodeStats) {
            nodeStats.getClass();
            NodeStats nodeStats2 = this.stats_;
            if (nodeStats2 == null || nodeStats2 == NodeStats.getDefaultInstance()) {
                this.stats_ = nodeStats;
            } else {
                this.stats_ = (NodeStats) ((NodeStats.Builder) NodeStats.newBuilder(this.stats_).v(nodeStats)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static Node parseDelimitedFrom(InputStream inputStream) {
            return (Node) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Node parseFrom(ByteBuffer byteBuffer) {
            return (Node) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<Node> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setIp(String str) {
            str.getClass();
            this.ip_ = str;
        }

        private void setIpBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.ip_ = byteString.L();
        }

        private void setNumCpus(int i) {
            this.numCpus_ = i;
        }

        private void setRegion(String str) {
            str.getClass();
            this.region_ = str;
        }

        private void setRegionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.region_ = byteString.L();
        }

        private void setState(NodeState nodeState) {
            this.state_ = nodeState.getNumber();
        }

        private void setStateValue(int i) {
            this.state_ = i;
        }

        private void setStats(NodeStats nodeStats) {
            nodeStats.getClass();
            this.stats_ = nodeStats;
        }

        private void setType(NodeType nodeType) {
            this.type_ = nodeType.getNumber();
        }

        private void setTypeValue(int i) {
            this.type_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new Node();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0000\u0000\u0001\u0007\u0007\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\u000b\u0004\t\u0005\f\u0006\f\u0007Ȉ", new Object[]{"id_", "ip_", "numCpus_", "stats_", "type_", "state_", "region_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<Node> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (Node.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public String getIp() {
            return this.ip_;
        }

        public ByteString getIpBytes() {
            return ByteString.n(this.ip_);
        }

        public int getNumCpus() {
            return this.numCpus_;
        }

        public String getRegion() {
            return this.region_;
        }

        public ByteString getRegionBytes() {
            return ByteString.n(this.region_);
        }

        public NodeState getState() {
            NodeState nodeStateB = NodeState.b(this.state_);
            return nodeStateB == null ? NodeState.e : nodeStateB;
        }

        public int getStateValue() {
            return this.state_;
        }

        public NodeStats getStats() {
            NodeStats nodeStats = this.stats_;
            return nodeStats == null ? NodeStats.getDefaultInstance() : nodeStats;
        }

        public NodeType getType() {
            NodeType nodeTypeB = NodeType.b(this.type_);
            return nodeTypeB == null ? NodeType.i : nodeTypeB;
        }

        public int getTypeValue() {
            return this.type_;
        }

        public boolean hasStats() {
            return this.stats_ != null;
        }

        public static Builder newBuilder(Node node) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(node);
        }

        public static Node parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Node) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Node parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (Node) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static Node parseFrom(ByteString byteString) {
            return (Node) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static Node parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (Node) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static Node parseFrom(byte[] bArr) {
            return (Node) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static Node parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (Node) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static Node parseFrom(InputStream inputStream) {
            return (Node) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Node parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Node) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Node parseFrom(CodedInputStream codedInputStream) {
            return (Node) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static Node parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Node) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface NodeOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum NodeState implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<NodeState>() { // from class: livekit.LivekitInternal.NodeState.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public NodeState findValueByNumber(int i) {
                return NodeState.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class NodeStateVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new NodeStateVerifier();

            private NodeStateVerifier() {
            }

            public boolean isInRange(int i) {
                return NodeState.b(i) != null;
            }
        }

        NodeState(int i) {
            this.a = i;
        }

        public static NodeState b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class NodeStats extends GeneratedMessageLite<NodeStats, Builder> implements NodeStatsOrBuilder {
        public static final int BYTES_IN_FIELD_NUMBER = 7;
        public static final int BYTES_IN_PER_SEC_FIELD_NUMBER = 12;
        public static final int BYTES_OUT_FIELD_NUMBER = 8;
        public static final int BYTES_OUT_PER_SEC_FIELD_NUMBER = 13;
        public static final int CPU_LOAD_FIELD_NUMBER = 21;
        private static final NodeStats DEFAULT_INSTANCE;
        public static final int FORWARD_JITTER_FIELD_NUMBER = 49;
        public static final int FORWARD_LATENCY_FIELD_NUMBER = 48;
        public static final int LOAD_AVG_LAST15MIN_FIELD_NUMBER = 20;
        public static final int LOAD_AVG_LAST1MIN_FIELD_NUMBER = 18;
        public static final int LOAD_AVG_LAST5MIN_FIELD_NUMBER = 19;
        public static final int MEMORY_LOAD_FIELD_NUMBER = 33;
        public static final int MEMORY_TOTAL_FIELD_NUMBER = 34;
        public static final int MEMORY_USED_FIELD_NUMBER = 35;
        public static final int NACK_PER_SEC_FIELD_NUMBER = 16;
        public static final int NACK_TOTAL_FIELD_NUMBER = 11;
        public static final int NUM_CLIENTS_FIELD_NUMBER = 4;
        public static final int NUM_CPUS_FIELD_NUMBER = 17;
        public static final int NUM_ROOMS_FIELD_NUMBER = 3;
        public static final int NUM_TRACKS_IN_FIELD_NUMBER = 5;
        public static final int NUM_TRACKS_OUT_FIELD_NUMBER = 6;
        public static final int NUM_TRACK_PUBLISH_ATTEMPTS_FIELD_NUMBER = 36;
        public static final int NUM_TRACK_PUBLISH_SUCCESS_FIELD_NUMBER = 38;
        public static final int NUM_TRACK_SUBSCRIBE_ATTEMPTS_FIELD_NUMBER = 40;
        public static final int NUM_TRACK_SUBSCRIBE_SUCCESS_FIELD_NUMBER = 42;
        public static final int PACKETS_IN_FIELD_NUMBER = 9;
        public static final int PACKETS_IN_PER_SEC_FIELD_NUMBER = 14;
        public static final int PACKETS_OUT_FIELD_NUMBER = 10;
        public static final int PACKETS_OUT_PER_SEC_FIELD_NUMBER = 15;
        private static volatile Parser<NodeStats> PARSER = null;
        public static final int PARTICIPANT_RTC_CONNECTED_FIELD_NUMBER = 44;
        public static final int PARTICIPANT_RTC_CONNECTED_PER_SEC_FIELD_NUMBER = 45;
        public static final int PARTICIPANT_RTC_INIT_FIELD_NUMBER = 46;
        public static final int PARTICIPANT_RTC_INIT_PER_SEC_FIELD_NUMBER = 47;
        public static final int PARTICIPANT_SIGNAL_CONNECTED_FIELD_NUMBER = 26;
        public static final int PARTICIPANT_SIGNAL_CONNECTED_PER_SEC_FIELD_NUMBER = 27;
        public static final int RATES_FIELD_NUMBER = 50;
        public static final int RETRANSMIT_BYTES_OUT_FIELD_NUMBER = 22;
        public static final int RETRANSMIT_BYTES_OUT_PER_SEC_FIELD_NUMBER = 24;
        public static final int RETRANSMIT_PACKETS_OUT_FIELD_NUMBER = 23;
        public static final int RETRANSMIT_PACKETS_OUT_PER_SEC_FIELD_NUMBER = 25;
        public static final int STARTED_AT_FIELD_NUMBER = 1;
        public static final int SYS_PACKETS_DROPPED_FIELD_NUMBER = 29;
        public static final int SYS_PACKETS_DROPPED_PCT_PER_SEC_FIELD_NUMBER = 32;
        public static final int SYS_PACKETS_DROPPED_PER_SEC_FIELD_NUMBER = 31;
        public static final int SYS_PACKETS_OUT_FIELD_NUMBER = 28;
        public static final int SYS_PACKETS_OUT_PER_SEC_FIELD_NUMBER = 30;
        public static final int TRACK_PUBLISH_ATTEMPTS_PER_SEC_FIELD_NUMBER = 37;
        public static final int TRACK_PUBLISH_SUCCESS_PER_SEC_FIELD_NUMBER = 39;
        public static final int TRACK_SUBSCRIBE_ATTEMPTS_PER_SEC_FIELD_NUMBER = 41;
        public static final int TRACK_SUBSCRIBE_SUCCESS_PER_SEC_FIELD_NUMBER = 43;
        public static final int UPDATED_AT_FIELD_NUMBER = 2;
        private float bytesInPerSec_;
        private long bytesIn_;
        private float bytesOutPerSec_;
        private long bytesOut_;
        private float cpuLoad_;
        private int forwardJitter_;
        private int forwardLatency_;
        private float loadAvgLast15Min_;
        private float loadAvgLast1Min_;
        private float loadAvgLast5Min_;
        private float memoryLoad_;
        private long memoryTotal_;
        private long memoryUsed_;
        private float nackPerSec_;
        private long nackTotal_;
        private int numClients_;
        private int numCpus_;
        private int numRooms_;
        private int numTrackPublishAttempts_;
        private int numTrackPublishSuccess_;
        private int numTrackSubscribeAttempts_;
        private int numTrackSubscribeSuccess_;
        private int numTracksIn_;
        private int numTracksOut_;
        private float packetsInPerSec_;
        private long packetsIn_;
        private float packetsOutPerSec_;
        private long packetsOut_;
        private float participantRtcConnectedPerSec_;
        private long participantRtcConnected_;
        private float participantRtcInitPerSec_;
        private long participantRtcInit_;
        private float participantSignalConnectedPerSec_;
        private long participantSignalConnected_;
        private Internal.ProtobufList<NodeStatsRate> rates_ = GeneratedMessageLite.emptyProtobufList();
        private float retransmitBytesOutPerSec_;
        private long retransmitBytesOut_;
        private float retransmitPacketsOutPerSec_;
        private long retransmitPacketsOut_;
        private long startedAt_;
        private float sysPacketsDroppedPctPerSec_;
        private float sysPacketsDroppedPerSec_;
        private int sysPacketsDropped_;
        private float sysPacketsOutPerSec_;
        private int sysPacketsOut_;
        private float trackPublishAttemptsPerSec_;
        private float trackPublishSuccessPerSec_;
        private float trackSubscribeAttemptsPerSec_;
        private float trackSubscribeSuccessPerSec_;
        private long updatedAt_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<NodeStats, Builder> implements NodeStatsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(NodeStats.DEFAULT_INSTANCE);
            }
        }

        static {
            NodeStats nodeStats = new NodeStats();
            DEFAULT_INSTANCE = nodeStats;
            GeneratedMessageLite.registerDefaultInstance(NodeStats.class, nodeStats);
        }

        private NodeStats() {
        }

        private void addAllRates(Iterable<? extends NodeStatsRate> iterable) {
            ensureRatesIsMutable();
            AbstractMessageLite.addAll(iterable, this.rates_);
        }

        private void addRates(NodeStatsRate nodeStatsRate) {
            nodeStatsRate.getClass();
            ensureRatesIsMutable();
            this.rates_.add(nodeStatsRate);
        }

        private void clearBytesIn() {
            this.bytesIn_ = 0L;
        }

        private void clearBytesInPerSec() {
            this.bytesInPerSec_ = 0.0f;
        }

        private void clearBytesOut() {
            this.bytesOut_ = 0L;
        }

        private void clearBytesOutPerSec() {
            this.bytesOutPerSec_ = 0.0f;
        }

        private void clearCpuLoad() {
            this.cpuLoad_ = 0.0f;
        }

        private void clearForwardJitter() {
            this.forwardJitter_ = 0;
        }

        private void clearForwardLatency() {
            this.forwardLatency_ = 0;
        }

        private void clearLoadAvgLast15Min() {
            this.loadAvgLast15Min_ = 0.0f;
        }

        private void clearLoadAvgLast1Min() {
            this.loadAvgLast1Min_ = 0.0f;
        }

        private void clearLoadAvgLast5Min() {
            this.loadAvgLast5Min_ = 0.0f;
        }

        private void clearMemoryLoad() {
            this.memoryLoad_ = 0.0f;
        }

        private void clearMemoryTotal() {
            this.memoryTotal_ = 0L;
        }

        private void clearMemoryUsed() {
            this.memoryUsed_ = 0L;
        }

        private void clearNackPerSec() {
            this.nackPerSec_ = 0.0f;
        }

        private void clearNackTotal() {
            this.nackTotal_ = 0L;
        }

        private void clearNumClients() {
            this.numClients_ = 0;
        }

        private void clearNumCpus() {
            this.numCpus_ = 0;
        }

        private void clearNumRooms() {
            this.numRooms_ = 0;
        }

        private void clearNumTrackPublishAttempts() {
            this.numTrackPublishAttempts_ = 0;
        }

        private void clearNumTrackPublishSuccess() {
            this.numTrackPublishSuccess_ = 0;
        }

        private void clearNumTrackSubscribeAttempts() {
            this.numTrackSubscribeAttempts_ = 0;
        }

        private void clearNumTrackSubscribeSuccess() {
            this.numTrackSubscribeSuccess_ = 0;
        }

        private void clearNumTracksIn() {
            this.numTracksIn_ = 0;
        }

        private void clearNumTracksOut() {
            this.numTracksOut_ = 0;
        }

        private void clearPacketsIn() {
            this.packetsIn_ = 0L;
        }

        private void clearPacketsInPerSec() {
            this.packetsInPerSec_ = 0.0f;
        }

        private void clearPacketsOut() {
            this.packetsOut_ = 0L;
        }

        private void clearPacketsOutPerSec() {
            this.packetsOutPerSec_ = 0.0f;
        }

        private void clearParticipantRtcConnected() {
            this.participantRtcConnected_ = 0L;
        }

        private void clearParticipantRtcConnectedPerSec() {
            this.participantRtcConnectedPerSec_ = 0.0f;
        }

        private void clearParticipantRtcInit() {
            this.participantRtcInit_ = 0L;
        }

        private void clearParticipantRtcInitPerSec() {
            this.participantRtcInitPerSec_ = 0.0f;
        }

        private void clearParticipantSignalConnected() {
            this.participantSignalConnected_ = 0L;
        }

        private void clearParticipantSignalConnectedPerSec() {
            this.participantSignalConnectedPerSec_ = 0.0f;
        }

        private void clearRates() {
            this.rates_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearRetransmitBytesOut() {
            this.retransmitBytesOut_ = 0L;
        }

        private void clearRetransmitBytesOutPerSec() {
            this.retransmitBytesOutPerSec_ = 0.0f;
        }

        private void clearRetransmitPacketsOut() {
            this.retransmitPacketsOut_ = 0L;
        }

        private void clearRetransmitPacketsOutPerSec() {
            this.retransmitPacketsOutPerSec_ = 0.0f;
        }

        private void clearStartedAt() {
            this.startedAt_ = 0L;
        }

        private void clearSysPacketsDropped() {
            this.sysPacketsDropped_ = 0;
        }

        private void clearSysPacketsDroppedPctPerSec() {
            this.sysPacketsDroppedPctPerSec_ = 0.0f;
        }

        private void clearSysPacketsDroppedPerSec() {
            this.sysPacketsDroppedPerSec_ = 0.0f;
        }

        private void clearSysPacketsOut() {
            this.sysPacketsOut_ = 0;
        }

        private void clearSysPacketsOutPerSec() {
            this.sysPacketsOutPerSec_ = 0.0f;
        }

        private void clearTrackPublishAttemptsPerSec() {
            this.trackPublishAttemptsPerSec_ = 0.0f;
        }

        private void clearTrackPublishSuccessPerSec() {
            this.trackPublishSuccessPerSec_ = 0.0f;
        }

        private void clearTrackSubscribeAttemptsPerSec() {
            this.trackSubscribeAttemptsPerSec_ = 0.0f;
        }

        private void clearTrackSubscribeSuccessPerSec() {
            this.trackSubscribeSuccessPerSec_ = 0.0f;
        }

        private void clearUpdatedAt() {
            this.updatedAt_ = 0L;
        }

        private void ensureRatesIsMutable() {
            Internal.ProtobufList<NodeStatsRate> protobufList = this.rates_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.rates_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static NodeStats getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static NodeStats parseDelimitedFrom(InputStream inputStream) {
            return (NodeStats) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static NodeStats parseFrom(ByteBuffer byteBuffer) {
            return (NodeStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<NodeStats> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeRates(int i) {
            ensureRatesIsMutable();
            this.rates_.remove(i);
        }

        private void setBytesIn(long j) {
            this.bytesIn_ = j;
        }

        private void setBytesInPerSec(float f) {
            this.bytesInPerSec_ = f;
        }

        private void setBytesOut(long j) {
            this.bytesOut_ = j;
        }

        private void setBytesOutPerSec(float f) {
            this.bytesOutPerSec_ = f;
        }

        private void setCpuLoad(float f) {
            this.cpuLoad_ = f;
        }

        private void setForwardJitter(int i) {
            this.forwardJitter_ = i;
        }

        private void setForwardLatency(int i) {
            this.forwardLatency_ = i;
        }

        private void setLoadAvgLast15Min(float f) {
            this.loadAvgLast15Min_ = f;
        }

        private void setLoadAvgLast1Min(float f) {
            this.loadAvgLast1Min_ = f;
        }

        private void setLoadAvgLast5Min(float f) {
            this.loadAvgLast5Min_ = f;
        }

        private void setMemoryLoad(float f) {
            this.memoryLoad_ = f;
        }

        private void setMemoryTotal(long j) {
            this.memoryTotal_ = j;
        }

        private void setMemoryUsed(long j) {
            this.memoryUsed_ = j;
        }

        private void setNackPerSec(float f) {
            this.nackPerSec_ = f;
        }

        private void setNackTotal(long j) {
            this.nackTotal_ = j;
        }

        private void setNumClients(int i) {
            this.numClients_ = i;
        }

        private void setNumCpus(int i) {
            this.numCpus_ = i;
        }

        private void setNumRooms(int i) {
            this.numRooms_ = i;
        }

        private void setNumTrackPublishAttempts(int i) {
            this.numTrackPublishAttempts_ = i;
        }

        private void setNumTrackPublishSuccess(int i) {
            this.numTrackPublishSuccess_ = i;
        }

        private void setNumTrackSubscribeAttempts(int i) {
            this.numTrackSubscribeAttempts_ = i;
        }

        private void setNumTrackSubscribeSuccess(int i) {
            this.numTrackSubscribeSuccess_ = i;
        }

        private void setNumTracksIn(int i) {
            this.numTracksIn_ = i;
        }

        private void setNumTracksOut(int i) {
            this.numTracksOut_ = i;
        }

        private void setPacketsIn(long j) {
            this.packetsIn_ = j;
        }

        private void setPacketsInPerSec(float f) {
            this.packetsInPerSec_ = f;
        }

        private void setPacketsOut(long j) {
            this.packetsOut_ = j;
        }

        private void setPacketsOutPerSec(float f) {
            this.packetsOutPerSec_ = f;
        }

        private void setParticipantRtcConnected(long j) {
            this.participantRtcConnected_ = j;
        }

        private void setParticipantRtcConnectedPerSec(float f) {
            this.participantRtcConnectedPerSec_ = f;
        }

        private void setParticipantRtcInit(long j) {
            this.participantRtcInit_ = j;
        }

        private void setParticipantRtcInitPerSec(float f) {
            this.participantRtcInitPerSec_ = f;
        }

        private void setParticipantSignalConnected(long j) {
            this.participantSignalConnected_ = j;
        }

        private void setParticipantSignalConnectedPerSec(float f) {
            this.participantSignalConnectedPerSec_ = f;
        }

        private void setRates(int i, NodeStatsRate nodeStatsRate) {
            nodeStatsRate.getClass();
            ensureRatesIsMutable();
            this.rates_.set(i, nodeStatsRate);
        }

        private void setRetransmitBytesOut(long j) {
            this.retransmitBytesOut_ = j;
        }

        private void setRetransmitBytesOutPerSec(float f) {
            this.retransmitBytesOutPerSec_ = f;
        }

        private void setRetransmitPacketsOut(long j) {
            this.retransmitPacketsOut_ = j;
        }

        private void setRetransmitPacketsOutPerSec(float f) {
            this.retransmitPacketsOutPerSec_ = f;
        }

        private void setStartedAt(long j) {
            this.startedAt_ = j;
        }

        private void setSysPacketsDropped(int i) {
            this.sysPacketsDropped_ = i;
        }

        private void setSysPacketsDroppedPctPerSec(float f) {
            this.sysPacketsDroppedPctPerSec_ = f;
        }

        private void setSysPacketsDroppedPerSec(float f) {
            this.sysPacketsDroppedPerSec_ = f;
        }

        private void setSysPacketsOut(int i) {
            this.sysPacketsOut_ = i;
        }

        private void setSysPacketsOutPerSec(float f) {
            this.sysPacketsOutPerSec_ = f;
        }

        private void setTrackPublishAttemptsPerSec(float f) {
            this.trackPublishAttemptsPerSec_ = f;
        }

        private void setTrackPublishSuccessPerSec(float f) {
            this.trackPublishSuccessPerSec_ = f;
        }

        private void setTrackSubscribeAttemptsPerSec(float f) {
            this.trackSubscribeAttemptsPerSec_ = f;
        }

        private void setTrackSubscribeSuccessPerSec(float f) {
            this.trackSubscribeSuccessPerSec_ = f;
        }

        private void setUpdatedAt(long j) {
            this.updatedAt_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new NodeStats();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u00002\u0000\u0000\u000122\u0000\u0001\u0000\u0001\u0002\u0002\u0002\u0003\u0004\u0004\u0004\u0005\u0004\u0006\u0004\u0007\u0003\b\u0003\t\u0003\n\u0003\u000b\u0003\f\u0001\r\u0001\u000e\u0001\u000f\u0001\u0010\u0001\u0011\u000b\u0012\u0001\u0013\u0001\u0014\u0001\u0015\u0001\u0016\u0003\u0017\u0003\u0018\u0001\u0019\u0001\u001a\u0003\u001b\u0001\u001c\u000b\u001d\u000b\u001e\u0001\u001f\u0001 \u0001!\u0001\"\u0003#\u0003$\u0004%\u0001&\u0004'\u0001(\u0004)\u0001*\u0004+\u0001,\u0003-\u0001.\u0003/\u00010\u000b1\u000b2\u001b", new Object[]{ap.a(1370538791), ap.a(974068729), ap.a(592258682), ap.a(1788459164), ap.a(1502640225), ap.a(2029479847), ap.a(524834831), ap.a(780905869), ap.a(1002240339), ap.a(915777132), ap.a(1452576558), ap.a(70645918), ap.a(1267941526), ap.a(436905900), ap.a(412840640), ap.a(1493999400), ap.a(56766500), ap.a(1286413247), ap.a(148691598), ap.a(226590106), ap.a(76651528), ap.a(727045575), ap.a(886873782), ap.a(1570046941), ap.a(414598432), ap.a(1242012164), ap.a(1425943981), ap.a(2120029154), ap.a(2026297166), ap.a(553977913), ap.a(627031088), ap.a(472450485), ap.a(1845907572), ap.a(580018585), ap.a(2074877355), ap.a(883336989), ap.a(1852216437), ap.a(443847616), ap.a(2060719260), ap.a(781685134), ap.a(1868755111), ap.a(717629038), ap.a(197749976), ap.a(566374529), ap.a(145672758), ap.a(1132255023), ap.a(1770178557), ap.a(1240799559), ap.a(1638665007), ap.a(1877230542), NodeStatsRate.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<NodeStats> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (NodeStats.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getBytesIn() {
            return this.bytesIn_;
        }

        @Deprecated
        public float getBytesInPerSec() {
            return this.bytesInPerSec_;
        }

        public long getBytesOut() {
            return this.bytesOut_;
        }

        @Deprecated
        public float getBytesOutPerSec() {
            return this.bytesOutPerSec_;
        }

        public float getCpuLoad() {
            return this.cpuLoad_;
        }

        public int getForwardJitter() {
            return this.forwardJitter_;
        }

        public int getForwardLatency() {
            return this.forwardLatency_;
        }

        public float getLoadAvgLast15Min() {
            return this.loadAvgLast15Min_;
        }

        public float getLoadAvgLast1Min() {
            return this.loadAvgLast1Min_;
        }

        public float getLoadAvgLast5Min() {
            return this.loadAvgLast5Min_;
        }

        @Deprecated
        public float getMemoryLoad() {
            return this.memoryLoad_;
        }

        public long getMemoryTotal() {
            return this.memoryTotal_;
        }

        public long getMemoryUsed() {
            return this.memoryUsed_;
        }

        @Deprecated
        public float getNackPerSec() {
            return this.nackPerSec_;
        }

        public long getNackTotal() {
            return this.nackTotal_;
        }

        public int getNumClients() {
            return this.numClients_;
        }

        public int getNumCpus() {
            return this.numCpus_;
        }

        public int getNumRooms() {
            return this.numRooms_;
        }

        public int getNumTrackPublishAttempts() {
            return this.numTrackPublishAttempts_;
        }

        public int getNumTrackPublishSuccess() {
            return this.numTrackPublishSuccess_;
        }

        public int getNumTrackSubscribeAttempts() {
            return this.numTrackSubscribeAttempts_;
        }

        public int getNumTrackSubscribeSuccess() {
            return this.numTrackSubscribeSuccess_;
        }

        public int getNumTracksIn() {
            return this.numTracksIn_;
        }

        public int getNumTracksOut() {
            return this.numTracksOut_;
        }

        public long getPacketsIn() {
            return this.packetsIn_;
        }

        @Deprecated
        public float getPacketsInPerSec() {
            return this.packetsInPerSec_;
        }

        public long getPacketsOut() {
            return this.packetsOut_;
        }

        @Deprecated
        public float getPacketsOutPerSec() {
            return this.packetsOutPerSec_;
        }

        public long getParticipantRtcConnected() {
            return this.participantRtcConnected_;
        }

        @Deprecated
        public float getParticipantRtcConnectedPerSec() {
            return this.participantRtcConnectedPerSec_;
        }

        public long getParticipantRtcInit() {
            return this.participantRtcInit_;
        }

        @Deprecated
        public float getParticipantRtcInitPerSec() {
            return this.participantRtcInitPerSec_;
        }

        public long getParticipantSignalConnected() {
            return this.participantSignalConnected_;
        }

        @Deprecated
        public float getParticipantSignalConnectedPerSec() {
            return this.participantSignalConnectedPerSec_;
        }

        public NodeStatsRate getRates(int i) {
            return (NodeStatsRate) this.rates_.get(i);
        }

        public int getRatesCount() {
            return this.rates_.size();
        }

        public List<NodeStatsRate> getRatesList() {
            return this.rates_;
        }

        public NodeStatsRateOrBuilder getRatesOrBuilder(int i) {
            return (NodeStatsRateOrBuilder) this.rates_.get(i);
        }

        public List<? extends NodeStatsRateOrBuilder> getRatesOrBuilderList() {
            return this.rates_;
        }

        public long getRetransmitBytesOut() {
            return this.retransmitBytesOut_;
        }

        @Deprecated
        public float getRetransmitBytesOutPerSec() {
            return this.retransmitBytesOutPerSec_;
        }

        public long getRetransmitPacketsOut() {
            return this.retransmitPacketsOut_;
        }

        @Deprecated
        public float getRetransmitPacketsOutPerSec() {
            return this.retransmitPacketsOutPerSec_;
        }

        public long getStartedAt() {
            return this.startedAt_;
        }

        public int getSysPacketsDropped() {
            return this.sysPacketsDropped_;
        }

        @Deprecated
        public float getSysPacketsDroppedPctPerSec() {
            return this.sysPacketsDroppedPctPerSec_;
        }

        @Deprecated
        public float getSysPacketsDroppedPerSec() {
            return this.sysPacketsDroppedPerSec_;
        }

        public int getSysPacketsOut() {
            return this.sysPacketsOut_;
        }

        @Deprecated
        public float getSysPacketsOutPerSec() {
            return this.sysPacketsOutPerSec_;
        }

        @Deprecated
        public float getTrackPublishAttemptsPerSec() {
            return this.trackPublishAttemptsPerSec_;
        }

        @Deprecated
        public float getTrackPublishSuccessPerSec() {
            return this.trackPublishSuccessPerSec_;
        }

        @Deprecated
        public float getTrackSubscribeAttemptsPerSec() {
            return this.trackSubscribeAttemptsPerSec_;
        }

        @Deprecated
        public float getTrackSubscribeSuccessPerSec() {
            return this.trackSubscribeSuccessPerSec_;
        }

        public long getUpdatedAt() {
            return this.updatedAt_;
        }

        public static Builder newBuilder(NodeStats nodeStats) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(nodeStats);
        }

        public static NodeStats parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStats) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static NodeStats parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static NodeStats parseFrom(ByteString byteString) {
            return (NodeStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addRates(int i, NodeStatsRate nodeStatsRate) {
            nodeStatsRate.getClass();
            ensureRatesIsMutable();
            this.rates_.add(i, nodeStatsRate);
        }

        public static NodeStats parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static NodeStats parseFrom(byte[] bArr) {
            return (NodeStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static NodeStats parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static NodeStats parseFrom(InputStream inputStream) {
            return (NodeStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static NodeStats parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static NodeStats parseFrom(CodedInputStream codedInputStream) {
            return (NodeStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static NodeStats parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface NodeStatsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class NodeStatsRate extends GeneratedMessageLite<NodeStatsRate, Builder> implements NodeStatsRateOrBuilder {
        public static final int BYTES_IN_FIELD_NUMBER = 8;
        public static final int BYTES_OUT_FIELD_NUMBER = 9;
        public static final int CPU_LOAD_FIELD_NUMBER = 20;
        private static final NodeStatsRate DEFAULT_INSTANCE;
        public static final int DURATION_FIELD_NUMBER = 3;
        public static final int ENDED_AT_FIELD_NUMBER = 2;
        public static final int MEMORY_LOAD_FIELD_NUMBER = 21;
        public static final int MEMORY_TOTAL_FIELD_NUMBER = 23;
        public static final int MEMORY_USED_FIELD_NUMBER = 22;
        public static final int NACK_TOTAL_FIELD_NUMBER = 12;
        public static final int PACKETS_IN_FIELD_NUMBER = 10;
        public static final int PACKETS_OUT_FIELD_NUMBER = 11;
        private static volatile Parser<NodeStatsRate> PARSER = null;
        public static final int PARTICIPANT_RTC_CONNECTED_FIELD_NUMBER = 18;
        public static final int PARTICIPANT_RTC_INIT_FIELD_NUMBER = 19;
        public static final int PARTICIPANT_SIGNAL_CONNECTED_FIELD_NUMBER = 17;
        public static final int RETRANSMIT_BYTES_OUT_FIELD_NUMBER = 15;
        public static final int RETRANSMIT_PACKETS_OUT_FIELD_NUMBER = 16;
        public static final int STARTED_AT_FIELD_NUMBER = 1;
        public static final int SYS_PACKETS_DROPPED_FIELD_NUMBER = 14;
        public static final int SYS_PACKETS_OUT_FIELD_NUMBER = 13;
        public static final int TRACK_PUBLISH_ATTEMPTS_FIELD_NUMBER = 4;
        public static final int TRACK_PUBLISH_SUCCESS_FIELD_NUMBER = 5;
        public static final int TRACK_SUBSCRIBE_ATTEMPTS_FIELD_NUMBER = 6;
        public static final int TRACK_SUBSCRIBE_SUCCESS_FIELD_NUMBER = 7;
        private float bytesIn_;
        private float bytesOut_;
        private float cpuLoad_;
        private long duration_;
        private long endedAt_;
        private float memoryLoad_;
        private float memoryTotal_;
        private float memoryUsed_;
        private float nackTotal_;
        private float packetsIn_;
        private float packetsOut_;
        private float participantRtcConnected_;
        private float participantRtcInit_;
        private float participantSignalConnected_;
        private float retransmitBytesOut_;
        private float retransmitPacketsOut_;
        private long startedAt_;
        private float sysPacketsDropped_;
        private float sysPacketsOut_;
        private float trackPublishAttempts_;
        private float trackPublishSuccess_;
        private float trackSubscribeAttempts_;
        private float trackSubscribeSuccess_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<NodeStatsRate, Builder> implements NodeStatsRateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(NodeStatsRate.DEFAULT_INSTANCE);
            }
        }

        static {
            NodeStatsRate nodeStatsRate = new NodeStatsRate();
            DEFAULT_INSTANCE = nodeStatsRate;
            GeneratedMessageLite.registerDefaultInstance(NodeStatsRate.class, nodeStatsRate);
        }

        private NodeStatsRate() {
        }

        private void clearBytesIn() {
            this.bytesIn_ = 0.0f;
        }

        private void clearBytesOut() {
            this.bytesOut_ = 0.0f;
        }

        private void clearCpuLoad() {
            this.cpuLoad_ = 0.0f;
        }

        private void clearDuration() {
            this.duration_ = 0L;
        }

        private void clearEndedAt() {
            this.endedAt_ = 0L;
        }

        private void clearMemoryLoad() {
            this.memoryLoad_ = 0.0f;
        }

        private void clearMemoryTotal() {
            this.memoryTotal_ = 0.0f;
        }

        private void clearMemoryUsed() {
            this.memoryUsed_ = 0.0f;
        }

        private void clearNackTotal() {
            this.nackTotal_ = 0.0f;
        }

        private void clearPacketsIn() {
            this.packetsIn_ = 0.0f;
        }

        private void clearPacketsOut() {
            this.packetsOut_ = 0.0f;
        }

        private void clearParticipantRtcConnected() {
            this.participantRtcConnected_ = 0.0f;
        }

        private void clearParticipantRtcInit() {
            this.participantRtcInit_ = 0.0f;
        }

        private void clearParticipantSignalConnected() {
            this.participantSignalConnected_ = 0.0f;
        }

        private void clearRetransmitBytesOut() {
            this.retransmitBytesOut_ = 0.0f;
        }

        private void clearRetransmitPacketsOut() {
            this.retransmitPacketsOut_ = 0.0f;
        }

        private void clearStartedAt() {
            this.startedAt_ = 0L;
        }

        private void clearSysPacketsDropped() {
            this.sysPacketsDropped_ = 0.0f;
        }

        private void clearSysPacketsOut() {
            this.sysPacketsOut_ = 0.0f;
        }

        private void clearTrackPublishAttempts() {
            this.trackPublishAttempts_ = 0.0f;
        }

        private void clearTrackPublishSuccess() {
            this.trackPublishSuccess_ = 0.0f;
        }

        private void clearTrackSubscribeAttempts() {
            this.trackSubscribeAttempts_ = 0.0f;
        }

        private void clearTrackSubscribeSuccess() {
            this.trackSubscribeSuccess_ = 0.0f;
        }

        public static NodeStatsRate getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static NodeStatsRate parseDelimitedFrom(InputStream inputStream) {
            return (NodeStatsRate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static NodeStatsRate parseFrom(ByteBuffer byteBuffer) {
            return (NodeStatsRate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<NodeStatsRate> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setBytesIn(float f) {
            this.bytesIn_ = f;
        }

        private void setBytesOut(float f) {
            this.bytesOut_ = f;
        }

        private void setCpuLoad(float f) {
            this.cpuLoad_ = f;
        }

        private void setDuration(long j) {
            this.duration_ = j;
        }

        private void setEndedAt(long j) {
            this.endedAt_ = j;
        }

        private void setMemoryLoad(float f) {
            this.memoryLoad_ = f;
        }

        private void setMemoryTotal(float f) {
            this.memoryTotal_ = f;
        }

        private void setMemoryUsed(float f) {
            this.memoryUsed_ = f;
        }

        private void setNackTotal(float f) {
            this.nackTotal_ = f;
        }

        private void setPacketsIn(float f) {
            this.packetsIn_ = f;
        }

        private void setPacketsOut(float f) {
            this.packetsOut_ = f;
        }

        private void setParticipantRtcConnected(float f) {
            this.participantRtcConnected_ = f;
        }

        private void setParticipantRtcInit(float f) {
            this.participantRtcInit_ = f;
        }

        private void setParticipantSignalConnected(float f) {
            this.participantSignalConnected_ = f;
        }

        private void setRetransmitBytesOut(float f) {
            this.retransmitBytesOut_ = f;
        }

        private void setRetransmitPacketsOut(float f) {
            this.retransmitPacketsOut_ = f;
        }

        private void setStartedAt(long j) {
            this.startedAt_ = j;
        }

        private void setSysPacketsDropped(float f) {
            this.sysPacketsDropped_ = f;
        }

        private void setSysPacketsOut(float f) {
            this.sysPacketsOut_ = f;
        }

        private void setTrackPublishAttempts(float f) {
            this.trackPublishAttempts_ = f;
        }

        private void setTrackPublishSuccess(float f) {
            this.trackPublishSuccess_ = f;
        }

        private void setTrackSubscribeAttempts(float f) {
            this.trackSubscribeAttempts_ = f;
        }

        private void setTrackSubscribeSuccess(float f) {
            this.trackSubscribeSuccess_ = f;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new NodeStatsRate();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0017\u0000\u0000\u0001\u0017\u0017\u0000\u0000\u0000\u0001\u0002\u0002\u0002\u0003\u0002\u0004\u0001\u0005\u0001\u0006\u0001\u0007\u0001\b\u0001\t\u0001\n\u0001\u000b\u0001\f\u0001\r\u0001\u000e\u0001\u000f\u0001\u0010\u0001\u0011\u0001\u0012\u0001\u0013\u0001\u0014\u0001\u0015\u0001\u0016\u0001\u0017\u0001", new Object[]{ap.a(1576735817), ap.a(336327251), ap.a(1137223690), ap.a(1975583211), ap.a(851787046), ap.a(2067997286), ap.a(1077147552), ap.a(1754671756), ap.a(1269599047), ap.a(1755040847), ap.a(1409297089), ap.a(117311090), ap.a(1968055750), ap.a(179637995), ap.a(915037515), ap.a(921502728), ap.a(2017897706), ap.a(1658178954), ap.a(1515123445), ap.a(842410546), ap.a(1274339178), ap.a(914239325), ap.a(591971349)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<NodeStatsRate> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (NodeStatsRate.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public float getBytesIn() {
            return this.bytesIn_;
        }

        public float getBytesOut() {
            return this.bytesOut_;
        }

        public float getCpuLoad() {
            return this.cpuLoad_;
        }

        public long getDuration() {
            return this.duration_;
        }

        public long getEndedAt() {
            return this.endedAt_;
        }

        public float getMemoryLoad() {
            return this.memoryLoad_;
        }

        public float getMemoryTotal() {
            return this.memoryTotal_;
        }

        public float getMemoryUsed() {
            return this.memoryUsed_;
        }

        public float getNackTotal() {
            return this.nackTotal_;
        }

        public float getPacketsIn() {
            return this.packetsIn_;
        }

        public float getPacketsOut() {
            return this.packetsOut_;
        }

        public float getParticipantRtcConnected() {
            return this.participantRtcConnected_;
        }

        public float getParticipantRtcInit() {
            return this.participantRtcInit_;
        }

        public float getParticipantSignalConnected() {
            return this.participantSignalConnected_;
        }

        public float getRetransmitBytesOut() {
            return this.retransmitBytesOut_;
        }

        public float getRetransmitPacketsOut() {
            return this.retransmitPacketsOut_;
        }

        public long getStartedAt() {
            return this.startedAt_;
        }

        public float getSysPacketsDropped() {
            return this.sysPacketsDropped_;
        }

        public float getSysPacketsOut() {
            return this.sysPacketsOut_;
        }

        public float getTrackPublishAttempts() {
            return this.trackPublishAttempts_;
        }

        public float getTrackPublishSuccess() {
            return this.trackPublishSuccess_;
        }

        public float getTrackSubscribeAttempts() {
            return this.trackSubscribeAttempts_;
        }

        public float getTrackSubscribeSuccess() {
            return this.trackSubscribeSuccess_;
        }

        public static Builder newBuilder(NodeStatsRate nodeStatsRate) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(nodeStatsRate);
        }

        public static NodeStatsRate parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStatsRate) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static NodeStatsRate parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStatsRate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static NodeStatsRate parseFrom(ByteString byteString) {
            return (NodeStatsRate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static NodeStatsRate parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStatsRate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static NodeStatsRate parseFrom(byte[] bArr) {
            return (NodeStatsRate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static NodeStatsRate parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStatsRate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static NodeStatsRate parseFrom(InputStream inputStream) {
            return (NodeStatsRate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static NodeStatsRate parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStatsRate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static NodeStatsRate parseFrom(CodedInputStream codedInputStream) {
            return (NodeStatsRate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static NodeStatsRate parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (NodeStatsRate) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface NodeStatsRateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum NodeType implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(4),
        f(5),
        g(6),
        h(7),
        i(-1);

        private static final Internal.EnumLiteMap j = new Internal.EnumLiteMap<NodeType>() { // from class: livekit.LivekitInternal.NodeType.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public NodeType findValueByNumber(int i2) {
                return NodeType.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class NodeTypeVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new NodeTypeVerifier();

            private NodeTypeVerifier() {
            }

            public boolean isInRange(int i) {
                return NodeType.b(i) != null;
            }
        }

        NodeType(int i2) {
            this.a = i2;
        }

        public static NodeType b(int i2) {
            if (i2 == 0) {
                return b;
            }
            if (i2 == 1) {
                return c;
            }
            if (i2 == 2) {
                return d;
            }
            if (i2 == 4) {
                return e;
            }
            if (i2 == 5) {
                return f;
            }
            if (i2 == 6) {
                return g;
            }
            if (i2 != 7) {
                return null;
            }
            return h;
        }

        public final int getNumber() {
            if (this != i) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RoomInternal extends GeneratedMessageLite<RoomInternal, Builder> implements RoomInternalOrBuilder {
        public static final int AGENT_DISPATCHES_FIELD_NUMBER = 5;
        private static final RoomInternal DEFAULT_INSTANCE;
        private static volatile Parser<RoomInternal> PARSER = null;
        public static final int PARTICIPANT_EGRESS_FIELD_NUMBER = 2;
        public static final int PLAYOUT_DELAY_FIELD_NUMBER = 3;
        public static final int REPLAY_ENABLED_FIELD_NUMBER = 6;
        public static final int SYNC_STREAMS_FIELD_NUMBER = 4;
        public static final int TRACK_EGRESS_FIELD_NUMBER = 1;
        private Internal.ProtobufList<LivekitAgentDispatch.RoomAgentDispatch> agentDispatches_ = GeneratedMessageLite.emptyProtobufList();
        private LivekitEgress.AutoParticipantEgress participantEgress_;
        private LivekitModels.PlayoutDelay playoutDelay_;
        private boolean replayEnabled_;
        private boolean syncStreams_;
        private LivekitEgress.AutoTrackEgress trackEgress_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RoomInternal, Builder> implements RoomInternalOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RoomInternal.DEFAULT_INSTANCE);
            }
        }

        static {
            RoomInternal roomInternal = new RoomInternal();
            DEFAULT_INSTANCE = roomInternal;
            GeneratedMessageLite.registerDefaultInstance(RoomInternal.class, roomInternal);
        }

        private RoomInternal() {
        }

        private void addAgentDispatches(LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureAgentDispatchesIsMutable();
            this.agentDispatches_.add(roomAgentDispatch);
        }

        private void addAllAgentDispatches(Iterable<? extends LivekitAgentDispatch.RoomAgentDispatch> iterable) {
            ensureAgentDispatchesIsMutable();
            AbstractMessageLite.addAll(iterable, this.agentDispatches_);
        }

        private void clearAgentDispatches() {
            this.agentDispatches_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearParticipantEgress() {
            this.participantEgress_ = null;
        }

        private void clearPlayoutDelay() {
            this.playoutDelay_ = null;
        }

        private void clearReplayEnabled() {
            this.replayEnabled_ = false;
        }

        private void clearSyncStreams() {
            this.syncStreams_ = false;
        }

        private void clearTrackEgress() {
            this.trackEgress_ = null;
        }

        private void ensureAgentDispatchesIsMutable() {
            Internal.ProtobufList<LivekitAgentDispatch.RoomAgentDispatch> protobufList = this.agentDispatches_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.agentDispatches_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static RoomInternal getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeParticipantEgress(LivekitEgress.AutoParticipantEgress autoParticipantEgress) {
            autoParticipantEgress.getClass();
            LivekitEgress.AutoParticipantEgress autoParticipantEgress2 = this.participantEgress_;
            if (autoParticipantEgress2 == null || autoParticipantEgress2 == LivekitEgress.AutoParticipantEgress.getDefaultInstance()) {
                this.participantEgress_ = autoParticipantEgress;
            } else {
                this.participantEgress_ = (LivekitEgress.AutoParticipantEgress) ((LivekitEgress.AutoParticipantEgress.Builder) LivekitEgress.AutoParticipantEgress.newBuilder(this.participantEgress_).v(autoParticipantEgress)).o();
            }
        }

        private void mergePlayoutDelay(LivekitModels.PlayoutDelay playoutDelay) {
            playoutDelay.getClass();
            LivekitModels.PlayoutDelay playoutDelay2 = this.playoutDelay_;
            if (playoutDelay2 == null || playoutDelay2 == LivekitModels.PlayoutDelay.getDefaultInstance()) {
                this.playoutDelay_ = playoutDelay;
            } else {
                this.playoutDelay_ = (LivekitModels.PlayoutDelay) ((LivekitModels.PlayoutDelay.Builder) LivekitModels.PlayoutDelay.newBuilder(this.playoutDelay_).v(playoutDelay)).o();
            }
        }

        private void mergeTrackEgress(LivekitEgress.AutoTrackEgress autoTrackEgress) {
            autoTrackEgress.getClass();
            LivekitEgress.AutoTrackEgress autoTrackEgress2 = this.trackEgress_;
            if (autoTrackEgress2 == null || autoTrackEgress2 == LivekitEgress.AutoTrackEgress.getDefaultInstance()) {
                this.trackEgress_ = autoTrackEgress;
            } else {
                this.trackEgress_ = (LivekitEgress.AutoTrackEgress) ((LivekitEgress.AutoTrackEgress.Builder) LivekitEgress.AutoTrackEgress.newBuilder(this.trackEgress_).v(autoTrackEgress)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RoomInternal parseDelimitedFrom(InputStream inputStream) {
            return (RoomInternal) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomInternal parseFrom(ByteBuffer byteBuffer) {
            return (RoomInternal) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RoomInternal> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeAgentDispatches(int i) {
            ensureAgentDispatchesIsMutable();
            this.agentDispatches_.remove(i);
        }

        private void setAgentDispatches(int i, LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureAgentDispatchesIsMutable();
            this.agentDispatches_.set(i, roomAgentDispatch);
        }

        private void setParticipantEgress(LivekitEgress.AutoParticipantEgress autoParticipantEgress) {
            autoParticipantEgress.getClass();
            this.participantEgress_ = autoParticipantEgress;
        }

        private void setPlayoutDelay(LivekitModels.PlayoutDelay playoutDelay) {
            playoutDelay.getClass();
            this.playoutDelay_ = playoutDelay;
        }

        private void setReplayEnabled(boolean z) {
            this.replayEnabled_ = z;
        }

        private void setSyncStreams(boolean z) {
            this.syncStreams_ = z;
        }

        private void setTrackEgress(LivekitEgress.AutoTrackEgress autoTrackEgress) {
            autoTrackEgress.getClass();
            this.trackEgress_ = autoTrackEgress;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RoomInternal();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0001\u0000\u0001\t\u0002\t\u0003\t\u0004\u0007\u0005\u001b\u0006\u0007", new Object[]{ap.a(168959642), ap.a(1487095571), ap.a(353475554), ap.a(1530266982), ap.a(1370121211), LivekitAgentDispatch.RoomAgentDispatch.class, ap.a(2107590720)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RoomInternal> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RoomInternal.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitAgentDispatch.RoomAgentDispatch getAgentDispatches(int i) {
            return (LivekitAgentDispatch.RoomAgentDispatch) this.agentDispatches_.get(i);
        }

        public int getAgentDispatchesCount() {
            return this.agentDispatches_.size();
        }

        public List<LivekitAgentDispatch.RoomAgentDispatch> getAgentDispatchesList() {
            return this.agentDispatches_;
        }

        public LivekitAgentDispatch.RoomAgentDispatchOrBuilder getAgentDispatchesOrBuilder(int i) {
            return (LivekitAgentDispatch.RoomAgentDispatchOrBuilder) this.agentDispatches_.get(i);
        }

        public List<? extends LivekitAgentDispatch.RoomAgentDispatchOrBuilder> getAgentDispatchesOrBuilderList() {
            return this.agentDispatches_;
        }

        public LivekitEgress.AutoParticipantEgress getParticipantEgress() {
            LivekitEgress.AutoParticipantEgress autoParticipantEgress = this.participantEgress_;
            return autoParticipantEgress == null ? LivekitEgress.AutoParticipantEgress.getDefaultInstance() : autoParticipantEgress;
        }

        public LivekitModels.PlayoutDelay getPlayoutDelay() {
            LivekitModels.PlayoutDelay playoutDelay = this.playoutDelay_;
            return playoutDelay == null ? LivekitModels.PlayoutDelay.getDefaultInstance() : playoutDelay;
        }

        public boolean getReplayEnabled() {
            return this.replayEnabled_;
        }

        public boolean getSyncStreams() {
            return this.syncStreams_;
        }

        public LivekitEgress.AutoTrackEgress getTrackEgress() {
            LivekitEgress.AutoTrackEgress autoTrackEgress = this.trackEgress_;
            return autoTrackEgress == null ? LivekitEgress.AutoTrackEgress.getDefaultInstance() : autoTrackEgress;
        }

        public boolean hasParticipantEgress() {
            return this.participantEgress_ != null;
        }

        public boolean hasPlayoutDelay() {
            return this.playoutDelay_ != null;
        }

        public boolean hasTrackEgress() {
            return this.trackEgress_ != null;
        }

        public static Builder newBuilder(RoomInternal roomInternal) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(roomInternal);
        }

        public static RoomInternal parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomInternal) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomInternal parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomInternal) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RoomInternal parseFrom(ByteString byteString) {
            return (RoomInternal) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addAgentDispatches(int i, LivekitAgentDispatch.RoomAgentDispatch roomAgentDispatch) {
            roomAgentDispatch.getClass();
            ensureAgentDispatchesIsMutable();
            this.agentDispatches_.add(i, roomAgentDispatch);
        }

        public static RoomInternal parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomInternal) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RoomInternal parseFrom(byte[] bArr) {
            return (RoomInternal) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RoomInternal parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomInternal) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RoomInternal parseFrom(InputStream inputStream) {
            return (RoomInternal) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomInternal parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomInternal) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomInternal parseFrom(CodedInputStream codedInputStream) {
            return (RoomInternal) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RoomInternal parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomInternal) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RoomInternalOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class StartSession extends GeneratedMessageLite<StartSession, Builder> implements StartSessionOrBuilder {
        public static final int ADAPTIVE_STREAM_FIELD_NUMBER = 15;
        public static final int ADD_TRACK_REQUESTS_FIELD_NUMBER = 21;
        public static final int AUTO_SUBSCRIBE_FIELD_NUMBER = 9;
        public static final int CLIENT_FIELD_NUMBER = 11;
        public static final int CONNECTION_ID_FIELD_NUMBER = 3;
        public static final int CREATE_ROOM_FIELD_NUMBER = 20;
        private static final StartSession DEFAULT_INSTANCE;
        public static final int DISABLE_ICE_LITE_FIELD_NUMBER = 19;
        public static final int GRANTS_JSON_FIELD_NUMBER = 14;
        public static final int HIDDEN_FIELD_NUMBER = 10;
        public static final int IDENTITY_FIELD_NUMBER = 2;
        public static final int NAME_FIELD_NUMBER = 13;
        private static volatile Parser<StartSession> PARSER = null;
        public static final int PARTICIPANT_ID_FIELD_NUMBER = 16;
        public static final int PUBLISHER_OFFER_FIELD_NUMBER = 22;
        public static final int RECONNECT_FIELD_NUMBER = 4;
        public static final int RECONNECT_REASON_FIELD_NUMBER = 17;
        public static final int RECORDER_FIELD_NUMBER = 12;
        public static final int ROOM_NAME_FIELD_NUMBER = 1;
        public static final int SUBSCRIBER_ALLOW_PAUSE_FIELD_NUMBER = 18;
        public static final int SYNC_STATE_FIELD_NUMBER = 23;
        public static final int USE_SINGLE_PEER_CONNECTION_FIELD_NUMBER = 24;
        private boolean adaptiveStream_;
        private Internal.ProtobufList<LivekitRtc.AddTrackRequest> addTrackRequests_;
        private boolean autoSubscribe_;
        private int bitField0_;
        private LivekitModels.ClientInfo client_;
        private String connectionId_;
        private LivekitRoom.CreateRoomRequest createRoom_;
        private boolean disableIceLite_;
        private String grantsJson_;
        private boolean hidden_;
        private String identity_;
        private String name_;
        private String participantId_;
        private LivekitRtc.SessionDescription publisherOffer_;
        private int reconnectReason_;
        private boolean reconnect_;
        private boolean recorder_;
        private String roomName_;
        private boolean subscriberAllowPause_;
        private LivekitRtc.SyncState syncState_;
        private boolean useSinglePeerConnection_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<StartSession, Builder> implements StartSessionOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(StartSession.DEFAULT_INSTANCE);
            }
        }

        static {
            StartSession startSession = new StartSession();
            DEFAULT_INSTANCE = startSession;
            GeneratedMessageLite.registerDefaultInstance(StartSession.class, startSession);
        }

        private StartSession() {
            String strA = ap.a(801969849);
            this.roomName_ = strA;
            this.identity_ = strA;
            this.connectionId_ = strA;
            this.name_ = strA;
            this.grantsJson_ = strA;
            this.participantId_ = strA;
            this.addTrackRequests_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAddTrackRequests(LivekitRtc.AddTrackRequest addTrackRequest) {
            addTrackRequest.getClass();
            ensureAddTrackRequestsIsMutable();
            this.addTrackRequests_.add(addTrackRequest);
        }

        private void addAllAddTrackRequests(Iterable<? extends LivekitRtc.AddTrackRequest> iterable) {
            ensureAddTrackRequestsIsMutable();
            AbstractMessageLite.addAll(iterable, this.addTrackRequests_);
        }

        private void clearAdaptiveStream() {
            this.adaptiveStream_ = false;
        }

        private void clearAddTrackRequests() {
            this.addTrackRequests_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearAutoSubscribe() {
            this.autoSubscribe_ = false;
        }

        private void clearClient() {
            this.client_ = null;
        }

        private void clearConnectionId() {
            this.connectionId_ = getDefaultInstance().getConnectionId();
        }

        private void clearCreateRoom() {
            this.createRoom_ = null;
        }

        private void clearDisableIceLite() {
            this.disableIceLite_ = false;
        }

        private void clearGrantsJson() {
            this.grantsJson_ = getDefaultInstance().getGrantsJson();
        }

        private void clearHidden() {
            this.hidden_ = false;
        }

        private void clearIdentity() {
            this.identity_ = getDefaultInstance().getIdentity();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearParticipantId() {
            this.participantId_ = getDefaultInstance().getParticipantId();
        }

        private void clearPublisherOffer() {
            this.publisherOffer_ = null;
        }

        private void clearReconnect() {
            this.reconnect_ = false;
        }

        private void clearReconnectReason() {
            this.reconnectReason_ = 0;
        }

        private void clearRecorder() {
            this.recorder_ = false;
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearSubscriberAllowPause() {
            this.bitField0_ &= -2;
            this.subscriberAllowPause_ = false;
        }

        private void clearSyncState() {
            this.syncState_ = null;
        }

        private void clearUseSinglePeerConnection() {
            this.useSinglePeerConnection_ = false;
        }

        private void ensureAddTrackRequestsIsMutable() {
            Internal.ProtobufList<LivekitRtc.AddTrackRequest> protobufList = this.addTrackRequests_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.addTrackRequests_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static StartSession getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeClient(LivekitModels.ClientInfo clientInfo) {
            clientInfo.getClass();
            LivekitModels.ClientInfo clientInfo2 = this.client_;
            if (clientInfo2 == null || clientInfo2 == LivekitModels.ClientInfo.getDefaultInstance()) {
                this.client_ = clientInfo;
            } else {
                this.client_ = (LivekitModels.ClientInfo) ((LivekitModels.ClientInfo.Builder) LivekitModels.ClientInfo.newBuilder(this.client_).v(clientInfo)).o();
            }
        }

        private void mergeCreateRoom(LivekitRoom.CreateRoomRequest createRoomRequest) {
            createRoomRequest.getClass();
            LivekitRoom.CreateRoomRequest createRoomRequest2 = this.createRoom_;
            if (createRoomRequest2 == null || createRoomRequest2 == LivekitRoom.CreateRoomRequest.getDefaultInstance()) {
                this.createRoom_ = createRoomRequest;
            } else {
                this.createRoom_ = (LivekitRoom.CreateRoomRequest) ((LivekitRoom.CreateRoomRequest.Builder) LivekitRoom.CreateRoomRequest.newBuilder(this.createRoom_).v(createRoomRequest)).o();
            }
        }

        private void mergePublisherOffer(LivekitRtc.SessionDescription sessionDescription) {
            sessionDescription.getClass();
            LivekitRtc.SessionDescription sessionDescription2 = this.publisherOffer_;
            if (sessionDescription2 == null || sessionDescription2 == LivekitRtc.SessionDescription.getDefaultInstance()) {
                this.publisherOffer_ = sessionDescription;
            } else {
                this.publisherOffer_ = (LivekitRtc.SessionDescription) ((LivekitRtc.SessionDescription.Builder) LivekitRtc.SessionDescription.newBuilder(this.publisherOffer_).v(sessionDescription)).o();
            }
        }

        private void mergeSyncState(LivekitRtc.SyncState syncState) {
            syncState.getClass();
            LivekitRtc.SyncState syncState2 = this.syncState_;
            if (syncState2 == null || syncState2 == LivekitRtc.SyncState.getDefaultInstance()) {
                this.syncState_ = syncState;
            } else {
                this.syncState_ = (LivekitRtc.SyncState) ((LivekitRtc.SyncState.Builder) LivekitRtc.SyncState.newBuilder(this.syncState_).v(syncState)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static StartSession parseDelimitedFrom(InputStream inputStream) {
            return (StartSession) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StartSession parseFrom(ByteBuffer byteBuffer) {
            return (StartSession) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<StartSession> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeAddTrackRequests(int i) {
            ensureAddTrackRequestsIsMutable();
            this.addTrackRequests_.remove(i);
        }

        private void setAdaptiveStream(boolean z) {
            this.adaptiveStream_ = z;
        }

        private void setAddTrackRequests(int i, LivekitRtc.AddTrackRequest addTrackRequest) {
            addTrackRequest.getClass();
            ensureAddTrackRequestsIsMutable();
            this.addTrackRequests_.set(i, addTrackRequest);
        }

        private void setAutoSubscribe(boolean z) {
            this.autoSubscribe_ = z;
        }

        private void setClient(LivekitModels.ClientInfo clientInfo) {
            clientInfo.getClass();
            this.client_ = clientInfo;
        }

        private void setConnectionId(String str) {
            str.getClass();
            this.connectionId_ = str;
        }

        private void setConnectionIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.connectionId_ = byteString.L();
        }

        private void setCreateRoom(LivekitRoom.CreateRoomRequest createRoomRequest) {
            createRoomRequest.getClass();
            this.createRoom_ = createRoomRequest;
        }

        private void setDisableIceLite(boolean z) {
            this.disableIceLite_ = z;
        }

        private void setGrantsJson(String str) {
            str.getClass();
            this.grantsJson_ = str;
        }

        private void setGrantsJsonBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.grantsJson_ = byteString.L();
        }

        private void setHidden(boolean z) {
            this.hidden_ = z;
        }

        private void setIdentity(String str) {
            str.getClass();
            this.identity_ = str;
        }

        private void setIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.identity_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setParticipantId(String str) {
            str.getClass();
            this.participantId_ = str;
        }

        private void setParticipantIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantId_ = byteString.L();
        }

        private void setPublisherOffer(LivekitRtc.SessionDescription sessionDescription) {
            sessionDescription.getClass();
            this.publisherOffer_ = sessionDescription;
        }

        private void setReconnect(boolean z) {
            this.reconnect_ = z;
        }

        private void setReconnectReason(LivekitModels.ReconnectReason reconnectReason) {
            this.reconnectReason_ = reconnectReason.getNumber();
        }

        private void setReconnectReasonValue(int i) {
            this.reconnectReason_ = i;
        }

        private void setRecorder(boolean z) {
            this.recorder_ = z;
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setSubscriberAllowPause(boolean z) {
            this.bitField0_ |= 1;
            this.subscriberAllowPause_ = z;
        }

        private void setSyncState(LivekitRtc.SyncState syncState) {
            syncState.getClass();
            this.syncState_ = syncState;
        }

        private void setUseSinglePeerConnection(boolean z) {
            this.useSinglePeerConnection_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new StartSession();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0014\u0000\u0001\u0001\u0018\u0014\u0000\u0001\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\u0007\t\u0007\n\u0007\u000b\t\f\u0007\rȈ\u000eȈ\u000f\u0007\u0010Ȉ\u0011\f\u0012ဇ\u0000\u0013\u0007\u0014\t\u0015\u001b\u0016\t\u0017\t\u0018\u0007", new Object[]{"bitField0_", "roomName_", "identity_", "connectionId_", "reconnect_", "autoSubscribe_", "hidden_", "client_", "recorder_", "name_", "grantsJson_", "adaptiveStream_", "participantId_", "reconnectReason_", "subscriberAllowPause_", "disableIceLite_", "createRoom_", "addTrackRequests_", LivekitRtc.AddTrackRequest.class, "publisherOffer_", "syncState_", "useSinglePeerConnection_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<StartSession> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (StartSession.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getAdaptiveStream() {
            return this.adaptiveStream_;
        }

        public LivekitRtc.AddTrackRequest getAddTrackRequests(int i) {
            return (LivekitRtc.AddTrackRequest) this.addTrackRequests_.get(i);
        }

        public int getAddTrackRequestsCount() {
            return this.addTrackRequests_.size();
        }

        public List<LivekitRtc.AddTrackRequest> getAddTrackRequestsList() {
            return this.addTrackRequests_;
        }

        public LivekitRtc.AddTrackRequestOrBuilder getAddTrackRequestsOrBuilder(int i) {
            return (LivekitRtc.AddTrackRequestOrBuilder) this.addTrackRequests_.get(i);
        }

        public List<? extends LivekitRtc.AddTrackRequestOrBuilder> getAddTrackRequestsOrBuilderList() {
            return this.addTrackRequests_;
        }

        public boolean getAutoSubscribe() {
            return this.autoSubscribe_;
        }

        public LivekitModels.ClientInfo getClient() {
            LivekitModels.ClientInfo clientInfo = this.client_;
            return clientInfo == null ? LivekitModels.ClientInfo.getDefaultInstance() : clientInfo;
        }

        public String getConnectionId() {
            return this.connectionId_;
        }

        public ByteString getConnectionIdBytes() {
            return ByteString.n(this.connectionId_);
        }

        public LivekitRoom.CreateRoomRequest getCreateRoom() {
            LivekitRoom.CreateRoomRequest createRoomRequest = this.createRoom_;
            return createRoomRequest == null ? LivekitRoom.CreateRoomRequest.getDefaultInstance() : createRoomRequest;
        }

        public boolean getDisableIceLite() {
            return this.disableIceLite_;
        }

        public String getGrantsJson() {
            return this.grantsJson_;
        }

        public ByteString getGrantsJsonBytes() {
            return ByteString.n(this.grantsJson_);
        }

        @Deprecated
        public boolean getHidden() {
            return this.hidden_;
        }

        public String getIdentity() {
            return this.identity_;
        }

        public ByteString getIdentityBytes() {
            return ByteString.n(this.identity_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getParticipantId() {
            return this.participantId_;
        }

        public ByteString getParticipantIdBytes() {
            return ByteString.n(this.participantId_);
        }

        public LivekitRtc.SessionDescription getPublisherOffer() {
            LivekitRtc.SessionDescription sessionDescription = this.publisherOffer_;
            return sessionDescription == null ? LivekitRtc.SessionDescription.getDefaultInstance() : sessionDescription;
        }

        public boolean getReconnect() {
            return this.reconnect_;
        }

        public LivekitModels.ReconnectReason getReconnectReason() {
            LivekitModels.ReconnectReason reconnectReasonB = LivekitModels.ReconnectReason.b(this.reconnectReason_);
            return reconnectReasonB == null ? LivekitModels.ReconnectReason.g : reconnectReasonB;
        }

        public int getReconnectReasonValue() {
            return this.reconnectReason_;
        }

        @Deprecated
        public boolean getRecorder() {
            return this.recorder_;
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public boolean getSubscriberAllowPause() {
            return this.subscriberAllowPause_;
        }

        public LivekitRtc.SyncState getSyncState() {
            LivekitRtc.SyncState syncState = this.syncState_;
            return syncState == null ? LivekitRtc.SyncState.getDefaultInstance() : syncState;
        }

        public boolean getUseSinglePeerConnection() {
            return this.useSinglePeerConnection_;
        }

        public boolean hasClient() {
            return this.client_ != null;
        }

        public boolean hasCreateRoom() {
            return this.createRoom_ != null;
        }

        public boolean hasPublisherOffer() {
            return this.publisherOffer_ != null;
        }

        public boolean hasSubscriberAllowPause() {
            return (this.bitField0_ & 1) != 0;
        }

        public boolean hasSyncState() {
            return this.syncState_ != null;
        }

        public static Builder newBuilder(StartSession startSession) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(startSession);
        }

        public static StartSession parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StartSession) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StartSession parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (StartSession) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static StartSession parseFrom(ByteString byteString) {
            return (StartSession) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addAddTrackRequests(int i, LivekitRtc.AddTrackRequest addTrackRequest) {
            addTrackRequest.getClass();
            ensureAddTrackRequestsIsMutable();
            this.addTrackRequests_.add(i, addTrackRequest);
        }

        public static StartSession parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (StartSession) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static StartSession parseFrom(byte[] bArr) {
            return (StartSession) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static StartSession parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (StartSession) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static StartSession parseFrom(InputStream inputStream) {
            return (StartSession) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StartSession parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StartSession) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StartSession parseFrom(CodedInputStream codedInputStream) {
            return (StartSession) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static StartSession parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StartSession) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface StartSessionOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitInternal() {
    }
}