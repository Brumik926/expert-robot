package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import com.google.protobuf.Timestamp;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;
import livekit.LivekitEgress;
import livekit.LivekitIngress;
import livekit.LivekitInternal;
import livekit.LivekitModels;
import livekit.LivekitRoom;
import livekit.LivekitSip;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitAnalytics {

    /* JADX INFO: renamed from: livekit.LivekitAnalytics$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class APICallInfo extends GeneratedMessageLite<APICallInfo, Builder> implements APICallInfoOrBuilder {
        private static final APICallInfo DEFAULT_INSTANCE;
        public static final int DURATION_NS_FIELD_NUMBER = 15;
        public static final int METHOD_FIELD_NUMBER = 4;
        public static final int NODE_ID_FIELD_NUMBER = 5;
        private static volatile Parser<APICallInfo> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 11;
        public static final int PARTICIPANT_ID_FIELD_NUMBER = 12;
        public static final int PROJECT_ID_FIELD_NUMBER = 1;
        public static final int REQUEST_FIELD_NUMBER = 2;
        public static final int ROOM_ID_FIELD_NUMBER = 10;
        public static final int ROOM_NAME_FIELD_NUMBER = 9;
        public static final int SERVICE_FIELD_NUMBER = 3;
        public static final int STARTED_AT_FIELD_NUMBER = 14;
        public static final int STATUS_FIELD_NUMBER = 6;
        public static final int TRACK_ID_FIELD_NUMBER = 13;
        public static final int TWIRP_ERROR_CODE_FIELD_NUMBER = 7;
        public static final int TWIRP_ERROR_MESSAGE_FIELD_NUMBER = 8;
        private long durationNs_;
        private String method_;
        private String nodeId_;
        private String participantId_;
        private String participantIdentity_;
        private String projectId_;
        private APICallRequest request_;
        private String roomId_;
        private String roomName_;
        private String service_;
        private Timestamp startedAt_;
        private int status_;
        private String trackId_;
        private String twirpErrorCode_;
        private String twirpErrorMessage_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<APICallInfo, Builder> implements APICallInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(APICallInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            APICallInfo aPICallInfo = new APICallInfo();
            DEFAULT_INSTANCE = aPICallInfo;
            GeneratedMessageLite.registerDefaultInstance(APICallInfo.class, aPICallInfo);
        }

        private APICallInfo() {
            String strA = ap.a(81434100);
            this.projectId_ = strA;
            this.service_ = strA;
            this.method_ = strA;
            this.nodeId_ = strA;
            this.twirpErrorCode_ = strA;
            this.twirpErrorMessage_ = strA;
            this.roomName_ = strA;
            this.roomId_ = strA;
            this.participantIdentity_ = strA;
            this.participantId_ = strA;
            this.trackId_ = strA;
        }

        private void clearDurationNs() {
            this.durationNs_ = 0L;
        }

        private void clearMethod() {
            this.method_ = getDefaultInstance().getMethod();
        }

        private void clearNodeId() {
            this.nodeId_ = getDefaultInstance().getNodeId();
        }

        private void clearParticipantId() {
            this.participantId_ = getDefaultInstance().getParticipantId();
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearProjectId() {
            this.projectId_ = getDefaultInstance().getProjectId();
        }

        private void clearRequest() {
            this.request_ = null;
        }

        private void clearRoomId() {
            this.roomId_ = getDefaultInstance().getRoomId();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearService() {
            this.service_ = getDefaultInstance().getService();
        }

        private void clearStartedAt() {
            this.startedAt_ = null;
        }

        private void clearStatus() {
            this.status_ = 0;
        }

        private void clearTrackId() {
            this.trackId_ = getDefaultInstance().getTrackId();
        }

        private void clearTwirpErrorCode() {
            this.twirpErrorCode_ = getDefaultInstance().getTwirpErrorCode();
        }

        private void clearTwirpErrorMessage() {
            this.twirpErrorMessage_ = getDefaultInstance().getTwirpErrorMessage();
        }

        public static APICallInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeRequest(APICallRequest aPICallRequest) {
            aPICallRequest.getClass();
            APICallRequest aPICallRequest2 = this.request_;
            if (aPICallRequest2 == null || aPICallRequest2 == APICallRequest.getDefaultInstance()) {
                this.request_ = aPICallRequest;
            } else {
                this.request_ = (APICallRequest) ((APICallRequest.Builder) APICallRequest.newBuilder(this.request_).v(aPICallRequest)).o();
            }
        }

        private void mergeStartedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.startedAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.startedAt_ = timestamp;
            } else {
                this.startedAt_ = Timestamp.newBuilder(this.startedAt_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static APICallInfo parseDelimitedFrom(InputStream inputStream) {
            return (APICallInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static APICallInfo parseFrom(ByteBuffer byteBuffer) {
            return (APICallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<APICallInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDurationNs(long j) {
            this.durationNs_ = j;
        }

        private void setMethod(String str) {
            str.getClass();
            this.method_ = str;
        }

        private void setMethodBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.method_ = byteString.L();
        }

        private void setNodeId(String str) {
            str.getClass();
            this.nodeId_ = str;
        }

        private void setNodeIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.nodeId_ = byteString.L();
        }

        private void setParticipantId(String str) {
            str.getClass();
            this.participantId_ = str;
        }

        private void setParticipantIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantId_ = byteString.L();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setProjectId(String str) {
            str.getClass();
            this.projectId_ = str;
        }

        private void setProjectIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.projectId_ = byteString.L();
        }

        private void setRequest(APICallRequest aPICallRequest) {
            aPICallRequest.getClass();
            this.request_ = aPICallRequest;
        }

        private void setRoomId(String str) {
            str.getClass();
            this.roomId_ = str;
        }

        private void setRoomIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomId_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setService(String str) {
            str.getClass();
            this.service_ = str;
        }

        private void setServiceBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.service_ = byteString.L();
        }

        private void setStartedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.startedAt_ = timestamp;
        }

        private void setStatus(int i) {
            this.status_ = i;
        }

        private void setTrackId(String str) {
            str.getClass();
            this.trackId_ = str;
        }

        private void setTrackIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackId_ = byteString.L();
        }

        private void setTwirpErrorCode(String str) {
            str.getClass();
            this.twirpErrorCode_ = str;
        }

        private void setTwirpErrorCodeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.twirpErrorCode_ = byteString.L();
        }

        private void setTwirpErrorMessage(String str) {
            str.getClass();
            this.twirpErrorMessage_ = str;
        }

        private void setTwirpErrorMessageBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.twirpErrorMessage_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new APICallInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000f\u0000\u0000\u0001\u000f\u000f\u0000\u0000\u0000\u0001Ȉ\u0002\t\u0003Ȉ\u0004Ȉ\u0005Ȉ\u0006\u0004\u0007Ȉ\bȈ\tȈ\nȈ\u000bȈ\fȈ\rȈ\u000e\t\u000f\u0002", new Object[]{"projectId_", "request_", "service_", "method_", "nodeId_", "status_", "twirpErrorCode_", "twirpErrorMessage_", "roomName_", "roomId_", "participantIdentity_", "participantId_", "trackId_", "startedAt_", "durationNs_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<APICallInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (APICallInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getDurationNs() {
            return this.durationNs_;
        }

        public String getMethod() {
            return this.method_;
        }

        public ByteString getMethodBytes() {
            return ByteString.n(this.method_);
        }

        public String getNodeId() {
            return this.nodeId_;
        }

        public ByteString getNodeIdBytes() {
            return ByteString.n(this.nodeId_);
        }

        public String getParticipantId() {
            return this.participantId_;
        }

        public ByteString getParticipantIdBytes() {
            return ByteString.n(this.participantId_);
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getProjectId() {
            return this.projectId_;
        }

        public ByteString getProjectIdBytes() {
            return ByteString.n(this.projectId_);
        }

        public APICallRequest getRequest() {
            APICallRequest aPICallRequest = this.request_;
            return aPICallRequest == null ? APICallRequest.getDefaultInstance() : aPICallRequest;
        }

        public String getRoomId() {
            return this.roomId_;
        }

        public ByteString getRoomIdBytes() {
            return ByteString.n(this.roomId_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public String getService() {
            return this.service_;
        }

        public ByteString getServiceBytes() {
            return ByteString.n(this.service_);
        }

        public Timestamp getStartedAt() {
            Timestamp timestamp = this.startedAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public int getStatus() {
            return this.status_;
        }

        public String getTrackId() {
            return this.trackId_;
        }

        public ByteString getTrackIdBytes() {
            return ByteString.n(this.trackId_);
        }

        public String getTwirpErrorCode() {
            return this.twirpErrorCode_;
        }

        public ByteString getTwirpErrorCodeBytes() {
            return ByteString.n(this.twirpErrorCode_);
        }

        public String getTwirpErrorMessage() {
            return this.twirpErrorMessage_;
        }

        public ByteString getTwirpErrorMessageBytes() {
            return ByteString.n(this.twirpErrorMessage_);
        }

        public boolean hasRequest() {
            return this.request_ != null;
        }

        public boolean hasStartedAt() {
            return this.startedAt_ != null;
        }

        public static Builder newBuilder(APICallInfo aPICallInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(aPICallInfo);
        }

        public static APICallInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static APICallInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static APICallInfo parseFrom(ByteString byteString) {
            return (APICallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static APICallInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static APICallInfo parseFrom(byte[] bArr) {
            return (APICallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static APICallInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static APICallInfo parseFrom(InputStream inputStream) {
            return (APICallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static APICallInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static APICallInfo parseFrom(CodedInputStream codedInputStream) {
            return (APICallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static APICallInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface APICallInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class APICallRequest extends GeneratedMessageLite<APICallRequest, Builder> implements APICallRequestOrBuilder {
        public static final int CREATE_ROOM_REQUEST_FIELD_NUMBER = 1;
        private static final APICallRequest DEFAULT_INSTANCE;
        public static final int DELETE_ROOM_REQUEST_FIELD_NUMBER = 3;
        public static final int LIST_PARTICIPANTS_REQUEST_FIELD_NUMBER = 4;
        public static final int LIST_ROOMS_REQUEST_FIELD_NUMBER = 2;
        public static final int MUTE_ROOM_TRACK_REQUEST_FIELD_NUMBER = 6;
        private static volatile Parser<APICallRequest> PARSER = null;
        public static final int ROOM_PARTICIPANT_IDENTITY_FIELD_NUMBER = 5;
        public static final int SEND_DATA_REQUEST_FIELD_NUMBER = 9;
        public static final int UPDATE_PARTICIPANT_REQUEST_FIELD_NUMBER = 7;
        public static final int UPDATE_ROOM_METADATA_REQUEST_FIELD_NUMBER = 10;
        public static final int UPDATE_SUBSCRIPTIONS_REQUEST_FIELD_NUMBER = 8;
        private int messageCase_ = 0;
        private Object message_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<APICallRequest, Builder> implements APICallRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(APICallRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum MessageCase {
            b(1),
            c(2),
            d(3),
            e(4),
            f(5),
            g(6),
            h(7),
            i(8),
            j(9),
            k(10),
            l(0);

            private final int a;

            MessageCase(int i2) {
                this.a = i2;
            }

            public static MessageCase b(int i2) {
                switch (i2) {
                    case 0:
                        return l;
                    case 1:
                        return b;
                    case 2:
                        return c;
                    case 3:
                        return d;
                    case 4:
                        return e;
                    case 5:
                        return f;
                    case 6:
                        return g;
                    case 7:
                        return h;
                    case 8:
                        return i;
                    case 9:
                        return j;
                    case 10:
                        return k;
                    default:
                        return null;
                }
            }
        }

        static {
            APICallRequest aPICallRequest = new APICallRequest();
            DEFAULT_INSTANCE = aPICallRequest;
            GeneratedMessageLite.registerDefaultInstance(APICallRequest.class, aPICallRequest);
        }

        private APICallRequest() {
        }

        private void clearCreateRoomRequest() {
            if (this.messageCase_ == 1) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearDeleteRoomRequest() {
            if (this.messageCase_ == 3) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearListParticipantsRequest() {
            if (this.messageCase_ == 4) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearListRoomsRequest() {
            if (this.messageCase_ == 2) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearMessage() {
            this.messageCase_ = 0;
            this.message_ = null;
        }

        private void clearMuteRoomTrackRequest() {
            if (this.messageCase_ == 6) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearRoomParticipantIdentity() {
            if (this.messageCase_ == 5) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearSendDataRequest() {
            if (this.messageCase_ == 9) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearUpdateParticipantRequest() {
            if (this.messageCase_ == 7) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearUpdateRoomMetadataRequest() {
            if (this.messageCase_ == 10) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearUpdateSubscriptionsRequest() {
            if (this.messageCase_ == 8) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        public static APICallRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeCreateRoomRequest(LivekitRoom.CreateRoomRequest createRoomRequest) {
            createRoomRequest.getClass();
            if (this.messageCase_ != 1 || this.message_ == LivekitRoom.CreateRoomRequest.getDefaultInstance()) {
                this.message_ = createRoomRequest;
            } else {
                this.message_ = ((LivekitRoom.CreateRoomRequest.Builder) LivekitRoom.CreateRoomRequest.newBuilder((LivekitRoom.CreateRoomRequest) this.message_).v(createRoomRequest)).o();
            }
            this.messageCase_ = 1;
        }

        private void mergeDeleteRoomRequest(LivekitRoom.DeleteRoomRequest deleteRoomRequest) {
            deleteRoomRequest.getClass();
            if (this.messageCase_ != 3 || this.message_ == LivekitRoom.DeleteRoomRequest.getDefaultInstance()) {
                this.message_ = deleteRoomRequest;
            } else {
                this.message_ = ((LivekitRoom.DeleteRoomRequest.Builder) LivekitRoom.DeleteRoomRequest.newBuilder((LivekitRoom.DeleteRoomRequest) this.message_).v(deleteRoomRequest)).o();
            }
            this.messageCase_ = 3;
        }

        private void mergeListParticipantsRequest(LivekitRoom.ListParticipantsRequest listParticipantsRequest) {
            listParticipantsRequest.getClass();
            if (this.messageCase_ != 4 || this.message_ == LivekitRoom.ListParticipantsRequest.getDefaultInstance()) {
                this.message_ = listParticipantsRequest;
            } else {
                this.message_ = ((LivekitRoom.ListParticipantsRequest.Builder) LivekitRoom.ListParticipantsRequest.newBuilder((LivekitRoom.ListParticipantsRequest) this.message_).v(listParticipantsRequest)).o();
            }
            this.messageCase_ = 4;
        }

        private void mergeListRoomsRequest(LivekitRoom.ListRoomsRequest listRoomsRequest) {
            listRoomsRequest.getClass();
            if (this.messageCase_ != 2 || this.message_ == LivekitRoom.ListRoomsRequest.getDefaultInstance()) {
                this.message_ = listRoomsRequest;
            } else {
                this.message_ = ((LivekitRoom.ListRoomsRequest.Builder) LivekitRoom.ListRoomsRequest.newBuilder((LivekitRoom.ListRoomsRequest) this.message_).v(listRoomsRequest)).o();
            }
            this.messageCase_ = 2;
        }

        private void mergeMuteRoomTrackRequest(LivekitRoom.MuteRoomTrackRequest muteRoomTrackRequest) {
            muteRoomTrackRequest.getClass();
            if (this.messageCase_ != 6 || this.message_ == LivekitRoom.MuteRoomTrackRequest.getDefaultInstance()) {
                this.message_ = muteRoomTrackRequest;
            } else {
                this.message_ = ((LivekitRoom.MuteRoomTrackRequest.Builder) LivekitRoom.MuteRoomTrackRequest.newBuilder((LivekitRoom.MuteRoomTrackRequest) this.message_).v(muteRoomTrackRequest)).o();
            }
            this.messageCase_ = 6;
        }

        private void mergeRoomParticipantIdentity(LivekitRoom.RoomParticipantIdentity roomParticipantIdentity) {
            roomParticipantIdentity.getClass();
            if (this.messageCase_ != 5 || this.message_ == LivekitRoom.RoomParticipantIdentity.getDefaultInstance()) {
                this.message_ = roomParticipantIdentity;
            } else {
                this.message_ = ((LivekitRoom.RoomParticipantIdentity.Builder) LivekitRoom.RoomParticipantIdentity.newBuilder((LivekitRoom.RoomParticipantIdentity) this.message_).v(roomParticipantIdentity)).o();
            }
            this.messageCase_ = 5;
        }

        private void mergeSendDataRequest(LivekitRoom.SendDataRequest sendDataRequest) {
            sendDataRequest.getClass();
            if (this.messageCase_ != 9 || this.message_ == LivekitRoom.SendDataRequest.getDefaultInstance()) {
                this.message_ = sendDataRequest;
            } else {
                this.message_ = ((LivekitRoom.SendDataRequest.Builder) LivekitRoom.SendDataRequest.newBuilder((LivekitRoom.SendDataRequest) this.message_).v(sendDataRequest)).o();
            }
            this.messageCase_ = 9;
        }

        private void mergeUpdateParticipantRequest(LivekitRoom.UpdateParticipantRequest updateParticipantRequest) {
            updateParticipantRequest.getClass();
            if (this.messageCase_ != 7 || this.message_ == LivekitRoom.UpdateParticipantRequest.getDefaultInstance()) {
                this.message_ = updateParticipantRequest;
            } else {
                this.message_ = ((LivekitRoom.UpdateParticipantRequest.Builder) LivekitRoom.UpdateParticipantRequest.newBuilder((LivekitRoom.UpdateParticipantRequest) this.message_).v(updateParticipantRequest)).o();
            }
            this.messageCase_ = 7;
        }

        private void mergeUpdateRoomMetadataRequest(LivekitRoom.UpdateRoomMetadataRequest updateRoomMetadataRequest) {
            updateRoomMetadataRequest.getClass();
            if (this.messageCase_ != 10 || this.message_ == LivekitRoom.UpdateRoomMetadataRequest.getDefaultInstance()) {
                this.message_ = updateRoomMetadataRequest;
            } else {
                this.message_ = ((LivekitRoom.UpdateRoomMetadataRequest.Builder) LivekitRoom.UpdateRoomMetadataRequest.newBuilder((LivekitRoom.UpdateRoomMetadataRequest) this.message_).v(updateRoomMetadataRequest)).o();
            }
            this.messageCase_ = 10;
        }

        private void mergeUpdateSubscriptionsRequest(LivekitRoom.UpdateSubscriptionsRequest updateSubscriptionsRequest) {
            updateSubscriptionsRequest.getClass();
            if (this.messageCase_ != 8 || this.message_ == LivekitRoom.UpdateSubscriptionsRequest.getDefaultInstance()) {
                this.message_ = updateSubscriptionsRequest;
            } else {
                this.message_ = ((LivekitRoom.UpdateSubscriptionsRequest.Builder) LivekitRoom.UpdateSubscriptionsRequest.newBuilder((LivekitRoom.UpdateSubscriptionsRequest) this.message_).v(updateSubscriptionsRequest)).o();
            }
            this.messageCase_ = 8;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static APICallRequest parseDelimitedFrom(InputStream inputStream) {
            return (APICallRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static APICallRequest parseFrom(ByteBuffer byteBuffer) {
            return (APICallRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<APICallRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCreateRoomRequest(LivekitRoom.CreateRoomRequest createRoomRequest) {
            createRoomRequest.getClass();
            this.message_ = createRoomRequest;
            this.messageCase_ = 1;
        }

        private void setDeleteRoomRequest(LivekitRoom.DeleteRoomRequest deleteRoomRequest) {
            deleteRoomRequest.getClass();
            this.message_ = deleteRoomRequest;
            this.messageCase_ = 3;
        }

        private void setListParticipantsRequest(LivekitRoom.ListParticipantsRequest listParticipantsRequest) {
            listParticipantsRequest.getClass();
            this.message_ = listParticipantsRequest;
            this.messageCase_ = 4;
        }

        private void setListRoomsRequest(LivekitRoom.ListRoomsRequest listRoomsRequest) {
            listRoomsRequest.getClass();
            this.message_ = listRoomsRequest;
            this.messageCase_ = 2;
        }

        private void setMuteRoomTrackRequest(LivekitRoom.MuteRoomTrackRequest muteRoomTrackRequest) {
            muteRoomTrackRequest.getClass();
            this.message_ = muteRoomTrackRequest;
            this.messageCase_ = 6;
        }

        private void setRoomParticipantIdentity(LivekitRoom.RoomParticipantIdentity roomParticipantIdentity) {
            roomParticipantIdentity.getClass();
            this.message_ = roomParticipantIdentity;
            this.messageCase_ = 5;
        }

        private void setSendDataRequest(LivekitRoom.SendDataRequest sendDataRequest) {
            sendDataRequest.getClass();
            this.message_ = sendDataRequest;
            this.messageCase_ = 9;
        }

        private void setUpdateParticipantRequest(LivekitRoom.UpdateParticipantRequest updateParticipantRequest) {
            updateParticipantRequest.getClass();
            this.message_ = updateParticipantRequest;
            this.messageCase_ = 7;
        }

        private void setUpdateRoomMetadataRequest(LivekitRoom.UpdateRoomMetadataRequest updateRoomMetadataRequest) {
            updateRoomMetadataRequest.getClass();
            this.message_ = updateRoomMetadataRequest;
            this.messageCase_ = 10;
        }

        private void setUpdateSubscriptionsRequest(LivekitRoom.UpdateSubscriptionsRequest updateSubscriptionsRequest) {
            updateSubscriptionsRequest.getClass();
            this.message_ = updateSubscriptionsRequest;
            this.messageCase_ = 8;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new APICallRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\n\u0001\u0000\u0001\n\n\u0000\u0000\u0000\u0001<\u0000\u0002<\u0000\u0003<\u0000\u0004<\u0000\u0005<\u0000\u0006<\u0000\u0007<\u0000\b<\u0000\t<\u0000\n<\u0000", new Object[]{ap.a(1816576176), ap.a(526280206), LivekitRoom.CreateRoomRequest.class, LivekitRoom.ListRoomsRequest.class, LivekitRoom.DeleteRoomRequest.class, LivekitRoom.ListParticipantsRequest.class, LivekitRoom.RoomParticipantIdentity.class, LivekitRoom.MuteRoomTrackRequest.class, LivekitRoom.UpdateParticipantRequest.class, LivekitRoom.UpdateSubscriptionsRequest.class, LivekitRoom.SendDataRequest.class, LivekitRoom.UpdateRoomMetadataRequest.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<APICallRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (APICallRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitRoom.CreateRoomRequest getCreateRoomRequest() {
            return this.messageCase_ == 1 ? (LivekitRoom.CreateRoomRequest) this.message_ : LivekitRoom.CreateRoomRequest.getDefaultInstance();
        }

        public LivekitRoom.DeleteRoomRequest getDeleteRoomRequest() {
            return this.messageCase_ == 3 ? (LivekitRoom.DeleteRoomRequest) this.message_ : LivekitRoom.DeleteRoomRequest.getDefaultInstance();
        }

        public LivekitRoom.ListParticipantsRequest getListParticipantsRequest() {
            return this.messageCase_ == 4 ? (LivekitRoom.ListParticipantsRequest) this.message_ : LivekitRoom.ListParticipantsRequest.getDefaultInstance();
        }

        public LivekitRoom.ListRoomsRequest getListRoomsRequest() {
            return this.messageCase_ == 2 ? (LivekitRoom.ListRoomsRequest) this.message_ : LivekitRoom.ListRoomsRequest.getDefaultInstance();
        }

        public MessageCase getMessageCase() {
            return MessageCase.b(this.messageCase_);
        }

        public LivekitRoom.MuteRoomTrackRequest getMuteRoomTrackRequest() {
            return this.messageCase_ == 6 ? (LivekitRoom.MuteRoomTrackRequest) this.message_ : LivekitRoom.MuteRoomTrackRequest.getDefaultInstance();
        }

        public LivekitRoom.RoomParticipantIdentity getRoomParticipantIdentity() {
            return this.messageCase_ == 5 ? (LivekitRoom.RoomParticipantIdentity) this.message_ : LivekitRoom.RoomParticipantIdentity.getDefaultInstance();
        }

        public LivekitRoom.SendDataRequest getSendDataRequest() {
            return this.messageCase_ == 9 ? (LivekitRoom.SendDataRequest) this.message_ : LivekitRoom.SendDataRequest.getDefaultInstance();
        }

        public LivekitRoom.UpdateParticipantRequest getUpdateParticipantRequest() {
            return this.messageCase_ == 7 ? (LivekitRoom.UpdateParticipantRequest) this.message_ : LivekitRoom.UpdateParticipantRequest.getDefaultInstance();
        }

        public LivekitRoom.UpdateRoomMetadataRequest getUpdateRoomMetadataRequest() {
            return this.messageCase_ == 10 ? (LivekitRoom.UpdateRoomMetadataRequest) this.message_ : LivekitRoom.UpdateRoomMetadataRequest.getDefaultInstance();
        }

        public LivekitRoom.UpdateSubscriptionsRequest getUpdateSubscriptionsRequest() {
            return this.messageCase_ == 8 ? (LivekitRoom.UpdateSubscriptionsRequest) this.message_ : LivekitRoom.UpdateSubscriptionsRequest.getDefaultInstance();
        }

        public boolean hasCreateRoomRequest() {
            return this.messageCase_ == 1;
        }

        public boolean hasDeleteRoomRequest() {
            return this.messageCase_ == 3;
        }

        public boolean hasListParticipantsRequest() {
            return this.messageCase_ == 4;
        }

        public boolean hasListRoomsRequest() {
            return this.messageCase_ == 2;
        }

        public boolean hasMuteRoomTrackRequest() {
            return this.messageCase_ == 6;
        }

        public boolean hasRoomParticipantIdentity() {
            return this.messageCase_ == 5;
        }

        public boolean hasSendDataRequest() {
            return this.messageCase_ == 9;
        }

        public boolean hasUpdateParticipantRequest() {
            return this.messageCase_ == 7;
        }

        public boolean hasUpdateRoomMetadataRequest() {
            return this.messageCase_ == 10;
        }

        public boolean hasUpdateSubscriptionsRequest() {
            return this.messageCase_ == 8;
        }

        public static Builder newBuilder(APICallRequest aPICallRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(aPICallRequest);
        }

        public static APICallRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static APICallRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static APICallRequest parseFrom(ByteString byteString) {
            return (APICallRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static APICallRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static APICallRequest parseFrom(byte[] bArr) {
            return (APICallRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static APICallRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static APICallRequest parseFrom(InputStream inputStream) {
            return (APICallRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static APICallRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static APICallRequest parseFrom(CodedInputStream codedInputStream) {
            return (APICallRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static APICallRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (APICallRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface APICallRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AnalyticsClientMeta extends GeneratedMessageLite<AnalyticsClientMeta, Builder> implements AnalyticsClientMetaOrBuilder {
        public static final int CLIENT_ADDR_FIELD_NUMBER = 3;
        public static final int CLIENT_CONNECT_TIME_FIELD_NUMBER = 4;
        public static final int CONNECTION_TYPE_FIELD_NUMBER = 5;
        public static final int COUNTRY_FIELD_NUMBER = 8;
        private static final AnalyticsClientMeta DEFAULT_INSTANCE;
        public static final int GEO_HASH_FIELD_NUMBER = 7;
        public static final int ISP_ASN_FIELD_NUMBER = 9;
        public static final int NODE_FIELD_NUMBER = 2;
        private static volatile Parser<AnalyticsClientMeta> PARSER = null;
        public static final int RECONNECT_REASON_FIELD_NUMBER = 6;
        public static final int REGION_FIELD_NUMBER = 1;
        private int bitField0_;
        private String clientAddr_;
        private int clientConnectTime_;
        private String connectionType_;
        private String country_;
        private String geoHash_;
        private int ispAsn_;
        private String node_;
        private int reconnectReason_;
        private String region_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AnalyticsClientMeta, Builder> implements AnalyticsClientMetaOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AnalyticsClientMeta.DEFAULT_INSTANCE);
            }
        }

        static {
            AnalyticsClientMeta analyticsClientMeta = new AnalyticsClientMeta();
            DEFAULT_INSTANCE = analyticsClientMeta;
            GeneratedMessageLite.registerDefaultInstance(AnalyticsClientMeta.class, analyticsClientMeta);
        }

        private AnalyticsClientMeta() {
            String strA = ap.a(1465235251);
            this.region_ = strA;
            this.node_ = strA;
            this.clientAddr_ = strA;
            this.connectionType_ = strA;
            this.geoHash_ = strA;
            this.country_ = strA;
        }

        private void clearClientAddr() {
            this.clientAddr_ = getDefaultInstance().getClientAddr();
        }

        private void clearClientConnectTime() {
            this.clientConnectTime_ = 0;
        }

        private void clearConnectionType() {
            this.connectionType_ = getDefaultInstance().getConnectionType();
        }

        private void clearCountry() {
            this.bitField0_ &= -3;
            this.country_ = getDefaultInstance().getCountry();
        }

        private void clearGeoHash() {
            this.bitField0_ &= -2;
            this.geoHash_ = getDefaultInstance().getGeoHash();
        }

        private void clearIspAsn() {
            this.bitField0_ &= -5;
            this.ispAsn_ = 0;
        }

        private void clearNode() {
            this.node_ = getDefaultInstance().getNode();
        }

        private void clearReconnectReason() {
            this.reconnectReason_ = 0;
        }

        private void clearRegion() {
            this.region_ = getDefaultInstance().getRegion();
        }

        public static AnalyticsClientMeta getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AnalyticsClientMeta parseDelimitedFrom(InputStream inputStream) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsClientMeta parseFrom(ByteBuffer byteBuffer) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AnalyticsClientMeta> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setClientAddr(String str) {
            str.getClass();
            this.clientAddr_ = str;
        }

        private void setClientAddrBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.clientAddr_ = byteString.L();
        }

        private void setClientConnectTime(int i) {
            this.clientConnectTime_ = i;
        }

        private void setConnectionType(String str) {
            str.getClass();
            this.connectionType_ = str;
        }

        private void setConnectionTypeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.connectionType_ = byteString.L();
        }

        private void setCountry(String str) {
            str.getClass();
            this.bitField0_ |= 2;
            this.country_ = str;
        }

        private void setCountryBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.country_ = byteString.L();
            this.bitField0_ |= 2;
        }

        private void setGeoHash(String str) {
            str.getClass();
            this.bitField0_ |= 1;
            this.geoHash_ = str;
        }

        private void setGeoHashBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.geoHash_ = byteString.L();
            this.bitField0_ |= 1;
        }

        private void setIspAsn(int i) {
            this.bitField0_ |= 4;
            this.ispAsn_ = i;
        }

        private void setNode(String str) {
            str.getClass();
            this.node_ = str;
        }

        private void setNodeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.node_ = byteString.L();
        }

        private void setReconnectReason(LivekitModels.ReconnectReason reconnectReason) {
            this.reconnectReason_ = reconnectReason.getNumber();
        }

        private void setReconnectReasonValue(int i) {
            this.reconnectReason_ = i;
        }

        private void setRegion(String str) {
            str.getClass();
            this.region_ = str;
        }

        private void setRegionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.region_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AnalyticsClientMeta();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\t\u0000\u0001\u0001\t\t\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\u000b\u0005Ȉ\u0006\f\u0007ለ\u0000\bለ\u0001\tဋ\u0002", new Object[]{"bitField0_", "region_", "node_", "clientAddr_", "clientConnectTime_", "connectionType_", "reconnectReason_", "geoHash_", "country_", "ispAsn_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AnalyticsClientMeta> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AnalyticsClientMeta.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getClientAddr() {
            return this.clientAddr_;
        }

        public ByteString getClientAddrBytes() {
            return ByteString.n(this.clientAddr_);
        }

        public int getClientConnectTime() {
            return this.clientConnectTime_;
        }

        public String getConnectionType() {
            return this.connectionType_;
        }

        public ByteString getConnectionTypeBytes() {
            return ByteString.n(this.connectionType_);
        }

        public String getCountry() {
            return this.country_;
        }

        public ByteString getCountryBytes() {
            return ByteString.n(this.country_);
        }

        public String getGeoHash() {
            return this.geoHash_;
        }

        public ByteString getGeoHashBytes() {
            return ByteString.n(this.geoHash_);
        }

        public int getIspAsn() {
            return this.ispAsn_;
        }

        public String getNode() {
            return this.node_;
        }

        public ByteString getNodeBytes() {
            return ByteString.n(this.node_);
        }

        public LivekitModels.ReconnectReason getReconnectReason() {
            LivekitModels.ReconnectReason reconnectReasonB = LivekitModels.ReconnectReason.b(this.reconnectReason_);
            return reconnectReasonB == null ? LivekitModels.ReconnectReason.g : reconnectReasonB;
        }

        public int getReconnectReasonValue() {
            return this.reconnectReason_;
        }

        public String getRegion() {
            return this.region_;
        }

        public ByteString getRegionBytes() {
            return ByteString.n(this.region_);
        }

        public boolean hasCountry() {
            return (this.bitField0_ & 2) != 0;
        }

        public boolean hasGeoHash() {
            return (this.bitField0_ & 1) != 0;
        }

        public boolean hasIspAsn() {
            return (this.bitField0_ & 4) != 0;
        }

        public static Builder newBuilder(AnalyticsClientMeta analyticsClientMeta) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(analyticsClientMeta);
        }

        public static AnalyticsClientMeta parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsClientMeta parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AnalyticsClientMeta parseFrom(ByteString byteString) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AnalyticsClientMeta parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AnalyticsClientMeta parseFrom(byte[] bArr) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AnalyticsClientMeta parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AnalyticsClientMeta parseFrom(InputStream inputStream) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsClientMeta parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsClientMeta parseFrom(CodedInputStream codedInputStream) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AnalyticsClientMeta parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsClientMeta) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AnalyticsClientMetaOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AnalyticsEvent extends GeneratedMessageLite<AnalyticsEvent, Builder> implements AnalyticsEventOrBuilder {
        public static final int ANALYTICS_KEY_FIELD_NUMBER = 10;
        public static final int API_CALL_FIELD_NUMBER = 34;
        public static final int CLIENT_INFO_FIELD_NUMBER = 11;
        public static final int CLIENT_META_FIELD_NUMBER = 12;
        private static final AnalyticsEvent DEFAULT_INSTANCE;
        public static final int EGRESS_FIELD_NUMBER = 17;
        public static final int EGRESS_ID_FIELD_NUMBER = 13;
        public static final int ERROR_FIELD_NUMBER = 20;
        public static final int ID_FIELD_NUMBER = 25;
        public static final int INGRESS_FIELD_NUMBER = 18;
        public static final int INGRESS_ID_FIELD_NUMBER = 19;
        public static final int MAX_SUBSCRIBED_VIDEO_QUALITY_FIELD_NUMBER = 14;
        public static final int MIME_FIELD_NUMBER = 16;
        public static final int NODE_ID_FIELD_NUMBER = 24;
        private static volatile Parser<AnalyticsEvent> PARSER = null;
        public static final int PARTICIPANT_FIELD_NUMBER = 6;
        public static final int PARTICIPANT_ID_FIELD_NUMBER = 5;
        public static final int PUBLISHER_FIELD_NUMBER = 15;
        public static final int REPORT_FIELD_NUMBER = 33;
        public static final int ROOM_FIELD_NUMBER = 4;
        public static final int ROOM_ID_FIELD_NUMBER = 3;
        public static final int RTP_STATS_FIELD_NUMBER = 21;
        public static final int SIP_CALL_FIELD_NUMBER = 27;
        public static final int SIP_CALL_ID_FIELD_NUMBER = 26;
        public static final int SIP_DISPATCH_RULE_FIELD_NUMBER = 32;
        public static final int SIP_DISPATCH_RULE_ID_FIELD_NUMBER = 31;
        public static final int SIP_INBOUND_TRUNK_FIELD_NUMBER = 29;
        public static final int SIP_OUTBOUND_TRUNK_FIELD_NUMBER = 30;
        public static final int SIP_TRANSFER_FIELD_NUMBER = 36;
        public static final int SIP_TRUNK_ID_FIELD_NUMBER = 28;
        public static final int TIMESTAMP_FIELD_NUMBER = 2;
        public static final int TRACK_FIELD_NUMBER = 8;
        public static final int TRACK_ID_FIELD_NUMBER = 7;
        public static final int TYPE_FIELD_NUMBER = 1;
        public static final int VIDEO_LAYER_FIELD_NUMBER = 22;
        public static final int WEBHOOK_FIELD_NUMBER = 35;
        private String analyticsKey_;
        private APICallInfo apiCall_;
        private LivekitModels.ClientInfo clientInfo_;
        private AnalyticsClientMeta clientMeta_;
        private String egressId_;
        private LivekitEgress.EgressInfo egress_;
        private String error_;
        private String id_;
        private String ingressId_;
        private LivekitIngress.IngressInfo ingress_;
        private int maxSubscribedVideoQuality_;
        private String mime_;
        private String nodeId_;
        private String participantId_;
        private LivekitModels.ParticipantInfo participant_;
        private LivekitModels.ParticipantInfo publisher_;
        private ReportInfo report_;
        private String roomId_;
        private LivekitModels.Room room_;
        private LivekitModels.RTPStats rtpStats_;
        private String sipCallId_;
        private LivekitSip.SIPCallInfo sipCall_;
        private String sipDispatchRuleId_;
        private LivekitSip.SIPDispatchRuleInfo sipDispatchRule_;
        private LivekitSip.SIPInboundTrunkInfo sipInboundTrunk_;
        private LivekitSip.SIPOutboundTrunkInfo sipOutboundTrunk_;
        private LivekitSip.SIPTransferInfo sipTransfer_;
        private String sipTrunkId_;
        private Timestamp timestamp_;
        private String trackId_;
        private LivekitModels.TrackInfo track_;
        private int type_;
        private int videoLayer_;
        private WebhookInfo webhook_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AnalyticsEvent, Builder> implements AnalyticsEventOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AnalyticsEvent.DEFAULT_INSTANCE);
            }
        }

        static {
            AnalyticsEvent analyticsEvent = new AnalyticsEvent();
            DEFAULT_INSTANCE = analyticsEvent;
            GeneratedMessageLite.registerDefaultInstance(AnalyticsEvent.class, analyticsEvent);
        }

        private AnalyticsEvent() {
            String strA = ap.a(1331316463);
            this.id_ = strA;
            this.roomId_ = strA;
            this.participantId_ = strA;
            this.trackId_ = strA;
            this.analyticsKey_ = strA;
            this.egressId_ = strA;
            this.ingressId_ = strA;
            this.mime_ = strA;
            this.error_ = strA;
            this.nodeId_ = strA;
            this.sipCallId_ = strA;
            this.sipTrunkId_ = strA;
            this.sipDispatchRuleId_ = strA;
        }

        private void clearAnalyticsKey() {
            this.analyticsKey_ = getDefaultInstance().getAnalyticsKey();
        }

        private void clearApiCall() {
            this.apiCall_ = null;
        }

        private void clearClientInfo() {
            this.clientInfo_ = null;
        }

        private void clearClientMeta() {
            this.clientMeta_ = null;
        }

        private void clearEgress() {
            this.egress_ = null;
        }

        private void clearEgressId() {
            this.egressId_ = getDefaultInstance().getEgressId();
        }

        private void clearError() {
            this.error_ = getDefaultInstance().getError();
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearIngress() {
            this.ingress_ = null;
        }

        private void clearIngressId() {
            this.ingressId_ = getDefaultInstance().getIngressId();
        }

        private void clearMaxSubscribedVideoQuality() {
            this.maxSubscribedVideoQuality_ = 0;
        }

        private void clearMime() {
            this.mime_ = getDefaultInstance().getMime();
        }

        private void clearNodeId() {
            this.nodeId_ = getDefaultInstance().getNodeId();
        }

        private void clearParticipant() {
            this.participant_ = null;
        }

        private void clearParticipantId() {
            this.participantId_ = getDefaultInstance().getParticipantId();
        }

        private void clearPublisher() {
            this.publisher_ = null;
        }

        private void clearReport() {
            this.report_ = null;
        }

        private void clearRoom() {
            this.room_ = null;
        }

        private void clearRoomId() {
            this.roomId_ = getDefaultInstance().getRoomId();
        }

        private void clearRtpStats() {
            this.rtpStats_ = null;
        }

        private void clearSipCall() {
            this.sipCall_ = null;
        }

        private void clearSipCallId() {
            this.sipCallId_ = getDefaultInstance().getSipCallId();
        }

        private void clearSipDispatchRule() {
            this.sipDispatchRule_ = null;
        }

        private void clearSipDispatchRuleId() {
            this.sipDispatchRuleId_ = getDefaultInstance().getSipDispatchRuleId();
        }

        private void clearSipInboundTrunk() {
            this.sipInboundTrunk_ = null;
        }

        private void clearSipOutboundTrunk() {
            this.sipOutboundTrunk_ = null;
        }

        private void clearSipTransfer() {
            this.sipTransfer_ = null;
        }

        private void clearSipTrunkId() {
            this.sipTrunkId_ = getDefaultInstance().getSipTrunkId();
        }

        private void clearTimestamp() {
            this.timestamp_ = null;
        }

        private void clearTrack() {
            this.track_ = null;
        }

        private void clearTrackId() {
            this.trackId_ = getDefaultInstance().getTrackId();
        }

        private void clearType() {
            this.type_ = 0;
        }

        private void clearVideoLayer() {
            this.videoLayer_ = 0;
        }

        private void clearWebhook() {
            this.webhook_ = null;
        }

        public static AnalyticsEvent getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeApiCall(APICallInfo aPICallInfo) {
            aPICallInfo.getClass();
            APICallInfo aPICallInfo2 = this.apiCall_;
            if (aPICallInfo2 == null || aPICallInfo2 == APICallInfo.getDefaultInstance()) {
                this.apiCall_ = aPICallInfo;
            } else {
                this.apiCall_ = (APICallInfo) ((APICallInfo.Builder) APICallInfo.newBuilder(this.apiCall_).v(aPICallInfo)).o();
            }
        }

        private void mergeClientInfo(LivekitModels.ClientInfo clientInfo) {
            clientInfo.getClass();
            LivekitModels.ClientInfo clientInfo2 = this.clientInfo_;
            if (clientInfo2 == null || clientInfo2 == LivekitModels.ClientInfo.getDefaultInstance()) {
                this.clientInfo_ = clientInfo;
            } else {
                this.clientInfo_ = (LivekitModels.ClientInfo) ((LivekitModels.ClientInfo.Builder) LivekitModels.ClientInfo.newBuilder(this.clientInfo_).v(clientInfo)).o();
            }
        }

        private void mergeClientMeta(AnalyticsClientMeta analyticsClientMeta) {
            analyticsClientMeta.getClass();
            AnalyticsClientMeta analyticsClientMeta2 = this.clientMeta_;
            if (analyticsClientMeta2 == null || analyticsClientMeta2 == AnalyticsClientMeta.getDefaultInstance()) {
                this.clientMeta_ = analyticsClientMeta;
            } else {
                this.clientMeta_ = (AnalyticsClientMeta) ((AnalyticsClientMeta.Builder) AnalyticsClientMeta.newBuilder(this.clientMeta_).v(analyticsClientMeta)).o();
            }
        }

        private void mergeEgress(LivekitEgress.EgressInfo egressInfo) {
            egressInfo.getClass();
            LivekitEgress.EgressInfo egressInfo2 = this.egress_;
            if (egressInfo2 == null || egressInfo2 == LivekitEgress.EgressInfo.getDefaultInstance()) {
                this.egress_ = egressInfo;
            } else {
                this.egress_ = (LivekitEgress.EgressInfo) ((LivekitEgress.EgressInfo.Builder) LivekitEgress.EgressInfo.newBuilder(this.egress_).v(egressInfo)).o();
            }
        }

        private void mergeIngress(LivekitIngress.IngressInfo ingressInfo) {
            ingressInfo.getClass();
            LivekitIngress.IngressInfo ingressInfo2 = this.ingress_;
            if (ingressInfo2 == null || ingressInfo2 == LivekitIngress.IngressInfo.getDefaultInstance()) {
                this.ingress_ = ingressInfo;
            } else {
                this.ingress_ = (LivekitIngress.IngressInfo) ((LivekitIngress.IngressInfo.Builder) LivekitIngress.IngressInfo.newBuilder(this.ingress_).v(ingressInfo)).o();
            }
        }

        private void mergeParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            LivekitModels.ParticipantInfo participantInfo2 = this.participant_;
            if (participantInfo2 == null || participantInfo2 == LivekitModels.ParticipantInfo.getDefaultInstance()) {
                this.participant_ = participantInfo;
            } else {
                this.participant_ = (LivekitModels.ParticipantInfo) ((LivekitModels.ParticipantInfo.Builder) LivekitModels.ParticipantInfo.newBuilder(this.participant_).v(participantInfo)).o();
            }
        }

        private void mergePublisher(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            LivekitModels.ParticipantInfo participantInfo2 = this.publisher_;
            if (participantInfo2 == null || participantInfo2 == LivekitModels.ParticipantInfo.getDefaultInstance()) {
                this.publisher_ = participantInfo;
            } else {
                this.publisher_ = (LivekitModels.ParticipantInfo) ((LivekitModels.ParticipantInfo.Builder) LivekitModels.ParticipantInfo.newBuilder(this.publisher_).v(participantInfo)).o();
            }
        }

        private void mergeReport(ReportInfo reportInfo) {
            reportInfo.getClass();
            ReportInfo reportInfo2 = this.report_;
            if (reportInfo2 == null || reportInfo2 == ReportInfo.getDefaultInstance()) {
                this.report_ = reportInfo;
            } else {
                this.report_ = (ReportInfo) ((ReportInfo.Builder) ReportInfo.newBuilder(this.report_).v(reportInfo)).o();
            }
        }

        private void mergeRoom(LivekitModels.Room room) {
            room.getClass();
            LivekitModels.Room room2 = this.room_;
            if (room2 == null || room2 == LivekitModels.Room.getDefaultInstance()) {
                this.room_ = room;
            } else {
                this.room_ = (LivekitModels.Room) ((LivekitModels.Room.Builder) LivekitModels.Room.newBuilder(this.room_).v(room)).o();
            }
        }

        private void mergeRtpStats(LivekitModels.RTPStats rTPStats) {
            rTPStats.getClass();
            LivekitModels.RTPStats rTPStats2 = this.rtpStats_;
            if (rTPStats2 == null || rTPStats2 == LivekitModels.RTPStats.getDefaultInstance()) {
                this.rtpStats_ = rTPStats;
            } else {
                this.rtpStats_ = (LivekitModels.RTPStats) ((LivekitModels.RTPStats.Builder) LivekitModels.RTPStats.newBuilder(this.rtpStats_).v(rTPStats)).o();
            }
        }

        private void mergeSipCall(LivekitSip.SIPCallInfo sIPCallInfo) {
            sIPCallInfo.getClass();
            LivekitSip.SIPCallInfo sIPCallInfo2 = this.sipCall_;
            if (sIPCallInfo2 == null || sIPCallInfo2 == LivekitSip.SIPCallInfo.getDefaultInstance()) {
                this.sipCall_ = sIPCallInfo;
            } else {
                this.sipCall_ = (LivekitSip.SIPCallInfo) ((LivekitSip.SIPCallInfo.Builder) LivekitSip.SIPCallInfo.newBuilder(this.sipCall_).v(sIPCallInfo)).o();
            }
        }

        private void mergeSipDispatchRule(LivekitSip.SIPDispatchRuleInfo sIPDispatchRuleInfo) {
            sIPDispatchRuleInfo.getClass();
            LivekitSip.SIPDispatchRuleInfo sIPDispatchRuleInfo2 = this.sipDispatchRule_;
            if (sIPDispatchRuleInfo2 == null || sIPDispatchRuleInfo2 == LivekitSip.SIPDispatchRuleInfo.getDefaultInstance()) {
                this.sipDispatchRule_ = sIPDispatchRuleInfo;
            } else {
                this.sipDispatchRule_ = (LivekitSip.SIPDispatchRuleInfo) ((LivekitSip.SIPDispatchRuleInfo.Builder) LivekitSip.SIPDispatchRuleInfo.newBuilder(this.sipDispatchRule_).v(sIPDispatchRuleInfo)).o();
            }
        }

        private void mergeSipInboundTrunk(LivekitSip.SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            sIPInboundTrunkInfo.getClass();
            LivekitSip.SIPInboundTrunkInfo sIPInboundTrunkInfo2 = this.sipInboundTrunk_;
            if (sIPInboundTrunkInfo2 == null || sIPInboundTrunkInfo2 == LivekitSip.SIPInboundTrunkInfo.getDefaultInstance()) {
                this.sipInboundTrunk_ = sIPInboundTrunkInfo;
            } else {
                this.sipInboundTrunk_ = (LivekitSip.SIPInboundTrunkInfo) ((LivekitSip.SIPInboundTrunkInfo.Builder) LivekitSip.SIPInboundTrunkInfo.newBuilder(this.sipInboundTrunk_).v(sIPInboundTrunkInfo)).o();
            }
        }

        private void mergeSipOutboundTrunk(LivekitSip.SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            sIPOutboundTrunkInfo.getClass();
            LivekitSip.SIPOutboundTrunkInfo sIPOutboundTrunkInfo2 = this.sipOutboundTrunk_;
            if (sIPOutboundTrunkInfo2 == null || sIPOutboundTrunkInfo2 == LivekitSip.SIPOutboundTrunkInfo.getDefaultInstance()) {
                this.sipOutboundTrunk_ = sIPOutboundTrunkInfo;
            } else {
                this.sipOutboundTrunk_ = (LivekitSip.SIPOutboundTrunkInfo) ((LivekitSip.SIPOutboundTrunkInfo.Builder) LivekitSip.SIPOutboundTrunkInfo.newBuilder(this.sipOutboundTrunk_).v(sIPOutboundTrunkInfo)).o();
            }
        }

        private void mergeSipTransfer(LivekitSip.SIPTransferInfo sIPTransferInfo) {
            sIPTransferInfo.getClass();
            LivekitSip.SIPTransferInfo sIPTransferInfo2 = this.sipTransfer_;
            if (sIPTransferInfo2 == null || sIPTransferInfo2 == LivekitSip.SIPTransferInfo.getDefaultInstance()) {
                this.sipTransfer_ = sIPTransferInfo;
            } else {
                this.sipTransfer_ = (LivekitSip.SIPTransferInfo) ((LivekitSip.SIPTransferInfo.Builder) LivekitSip.SIPTransferInfo.newBuilder(this.sipTransfer_).v(sIPTransferInfo)).o();
            }
        }

        private void mergeTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.timestamp_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.timestamp_ = timestamp;
            } else {
                this.timestamp_ = Timestamp.newBuilder(this.timestamp_).v(timestamp).o();
            }
        }

        private void mergeTrack(LivekitModels.TrackInfo trackInfo) {
            trackInfo.getClass();
            LivekitModels.TrackInfo trackInfo2 = this.track_;
            if (trackInfo2 == null || trackInfo2 == LivekitModels.TrackInfo.getDefaultInstance()) {
                this.track_ = trackInfo;
            } else {
                this.track_ = (LivekitModels.TrackInfo) ((LivekitModels.TrackInfo.Builder) LivekitModels.TrackInfo.newBuilder(this.track_).v(trackInfo)).o();
            }
        }

        private void mergeWebhook(WebhookInfo webhookInfo) {
            webhookInfo.getClass();
            WebhookInfo webhookInfo2 = this.webhook_;
            if (webhookInfo2 == null || webhookInfo2 == WebhookInfo.getDefaultInstance()) {
                this.webhook_ = webhookInfo;
            } else {
                this.webhook_ = (WebhookInfo) ((WebhookInfo.Builder) WebhookInfo.newBuilder(this.webhook_).v(webhookInfo)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AnalyticsEvent parseDelimitedFrom(InputStream inputStream) {
            return (AnalyticsEvent) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsEvent parseFrom(ByteBuffer byteBuffer) {
            return (AnalyticsEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AnalyticsEvent> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAnalyticsKey(String str) {
            str.getClass();
            this.analyticsKey_ = str;
        }

        private void setAnalyticsKeyBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.analyticsKey_ = byteString.L();
        }

        private void setApiCall(APICallInfo aPICallInfo) {
            aPICallInfo.getClass();
            this.apiCall_ = aPICallInfo;
        }

        private void setClientInfo(LivekitModels.ClientInfo clientInfo) {
            clientInfo.getClass();
            this.clientInfo_ = clientInfo;
        }

        private void setClientMeta(AnalyticsClientMeta analyticsClientMeta) {
            analyticsClientMeta.getClass();
            this.clientMeta_ = analyticsClientMeta;
        }

        private void setEgress(LivekitEgress.EgressInfo egressInfo) {
            egressInfo.getClass();
            this.egress_ = egressInfo;
        }

        private void setEgressId(String str) {
            str.getClass();
            this.egressId_ = str;
        }

        private void setEgressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.egressId_ = byteString.L();
        }

        private void setError(String str) {
            str.getClass();
            this.error_ = str;
        }

        private void setErrorBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.error_ = byteString.L();
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setIngress(LivekitIngress.IngressInfo ingressInfo) {
            ingressInfo.getClass();
            this.ingress_ = ingressInfo;
        }

        private void setIngressId(String str) {
            str.getClass();
            this.ingressId_ = str;
        }

        private void setIngressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.ingressId_ = byteString.L();
        }

        private void setMaxSubscribedVideoQuality(LivekitModels.VideoQuality videoQuality) {
            this.maxSubscribedVideoQuality_ = videoQuality.getNumber();
        }

        private void setMaxSubscribedVideoQualityValue(int i) {
            this.maxSubscribedVideoQuality_ = i;
        }

        private void setMime(String str) {
            str.getClass();
            this.mime_ = str;
        }

        private void setMimeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.mime_ = byteString.L();
        }

        private void setNodeId(String str) {
            str.getClass();
            this.nodeId_ = str;
        }

        private void setNodeIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.nodeId_ = byteString.L();
        }

        private void setParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            this.participant_ = participantInfo;
        }

        private void setParticipantId(String str) {
            str.getClass();
            this.participantId_ = str;
        }

        private void setParticipantIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantId_ = byteString.L();
        }

        private void setPublisher(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            this.publisher_ = participantInfo;
        }

        private void setReport(ReportInfo reportInfo) {
            reportInfo.getClass();
            this.report_ = reportInfo;
        }

        private void setRoom(LivekitModels.Room room) {
            room.getClass();
            this.room_ = room;
        }

        private void setRoomId(String str) {
            str.getClass();
            this.roomId_ = str;
        }

        private void setRoomIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomId_ = byteString.L();
        }

        private void setRtpStats(LivekitModels.RTPStats rTPStats) {
            rTPStats.getClass();
            this.rtpStats_ = rTPStats;
        }

        private void setSipCall(LivekitSip.SIPCallInfo sIPCallInfo) {
            sIPCallInfo.getClass();
            this.sipCall_ = sIPCallInfo;
        }

        private void setSipCallId(String str) {
            str.getClass();
            this.sipCallId_ = str;
        }

        private void setSipCallIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipCallId_ = byteString.L();
        }

        private void setSipDispatchRule(LivekitSip.SIPDispatchRuleInfo sIPDispatchRuleInfo) {
            sIPDispatchRuleInfo.getClass();
            this.sipDispatchRule_ = sIPDispatchRuleInfo;
        }

        private void setSipDispatchRuleId(String str) {
            str.getClass();
            this.sipDispatchRuleId_ = str;
        }

        private void setSipDispatchRuleIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipDispatchRuleId_ = byteString.L();
        }

        private void setSipInboundTrunk(LivekitSip.SIPInboundTrunkInfo sIPInboundTrunkInfo) {
            sIPInboundTrunkInfo.getClass();
            this.sipInboundTrunk_ = sIPInboundTrunkInfo;
        }

        private void setSipOutboundTrunk(LivekitSip.SIPOutboundTrunkInfo sIPOutboundTrunkInfo) {
            sIPOutboundTrunkInfo.getClass();
            this.sipOutboundTrunk_ = sIPOutboundTrunkInfo;
        }

        private void setSipTransfer(LivekitSip.SIPTransferInfo sIPTransferInfo) {
            sIPTransferInfo.getClass();
            this.sipTransfer_ = sIPTransferInfo;
        }

        private void setSipTrunkId(String str) {
            str.getClass();
            this.sipTrunkId_ = str;
        }

        private void setSipTrunkIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sipTrunkId_ = byteString.L();
        }

        private void setTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            this.timestamp_ = timestamp;
        }

        private void setTrack(LivekitModels.TrackInfo trackInfo) {
            trackInfo.getClass();
            this.track_ = trackInfo;
        }

        private void setTrackId(String str) {
            str.getClass();
            this.trackId_ = str;
        }

        private void setTrackIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackId_ = byteString.L();
        }

        private void setType(AnalyticsEventType analyticsEventType) {
            this.type_ = analyticsEventType.getNumber();
        }

        private void setTypeValue(int i) {
            this.type_ = i;
        }

        private void setVideoLayer(int i) {
            this.videoLayer_ = i;
        }

        private void setWebhook(WebhookInfo webhookInfo) {
            webhookInfo.getClass();
            this.webhook_ = webhookInfo;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new AnalyticsEvent();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\"\u0000\u0000\u0001$\"\u0000\u0000\u0000\u0001\f\u0002\t\u0003Ȉ\u0004\t\u0005Ȉ\u0006\t\u0007Ȉ\b\t\nȈ\u000b\t\f\t\rȈ\u000e\f\u000f\t\u0010Ȉ\u0011\t\u0012\t\u0013Ȉ\u0014Ȉ\u0015\t\u0016\u0004\u0018Ȉ\u0019Ȉ\u001aȈ\u001b\t\u001cȈ\u001d\t\u001e\t\u001fȈ \t!\t\"\t#\t$\t", new Object[]{"type_", "timestamp_", "roomId_", "room_", "participantId_", "participant_", "trackId_", "track_", "analyticsKey_", "clientInfo_", "clientMeta_", "egressId_", "maxSubscribedVideoQuality_", "publisher_", "mime_", "egress_", "ingress_", "ingressId_", "error_", "rtpStats_", "videoLayer_", "nodeId_", "id_", "sipCallId_", "sipCall_", "sipTrunkId_", "sipInboundTrunk_", "sipOutboundTrunk_", "sipDispatchRuleId_", "sipDispatchRule_", "report_", "apiCall_", "webhook_", "sipTransfer_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AnalyticsEvent> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AnalyticsEvent.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAnalyticsKey() {
            return this.analyticsKey_;
        }

        public ByteString getAnalyticsKeyBytes() {
            return ByteString.n(this.analyticsKey_);
        }

        public APICallInfo getApiCall() {
            APICallInfo aPICallInfo = this.apiCall_;
            return aPICallInfo == null ? APICallInfo.getDefaultInstance() : aPICallInfo;
        }

        public LivekitModels.ClientInfo getClientInfo() {
            LivekitModels.ClientInfo clientInfo = this.clientInfo_;
            return clientInfo == null ? LivekitModels.ClientInfo.getDefaultInstance() : clientInfo;
        }

        public AnalyticsClientMeta getClientMeta() {
            AnalyticsClientMeta analyticsClientMeta = this.clientMeta_;
            return analyticsClientMeta == null ? AnalyticsClientMeta.getDefaultInstance() : analyticsClientMeta;
        }

        public LivekitEgress.EgressInfo getEgress() {
            LivekitEgress.EgressInfo egressInfo = this.egress_;
            return egressInfo == null ? LivekitEgress.EgressInfo.getDefaultInstance() : egressInfo;
        }

        public String getEgressId() {
            return this.egressId_;
        }

        public ByteString getEgressIdBytes() {
            return ByteString.n(this.egressId_);
        }

        public String getError() {
            return this.error_;
        }

        public ByteString getErrorBytes() {
            return ByteString.n(this.error_);
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public LivekitIngress.IngressInfo getIngress() {
            LivekitIngress.IngressInfo ingressInfo = this.ingress_;
            return ingressInfo == null ? LivekitIngress.IngressInfo.getDefaultInstance() : ingressInfo;
        }

        public String getIngressId() {
            return this.ingressId_;
        }

        public ByteString getIngressIdBytes() {
            return ByteString.n(this.ingressId_);
        }

        public LivekitModels.VideoQuality getMaxSubscribedVideoQuality() {
            LivekitModels.VideoQuality videoQualityB = LivekitModels.VideoQuality.b(this.maxSubscribedVideoQuality_);
            return videoQualityB == null ? LivekitModels.VideoQuality.f : videoQualityB;
        }

        public int getMaxSubscribedVideoQualityValue() {
            return this.maxSubscribedVideoQuality_;
        }

        public String getMime() {
            return this.mime_;
        }

        public ByteString getMimeBytes() {
            return ByteString.n(this.mime_);
        }

        public String getNodeId() {
            return this.nodeId_;
        }

        public ByteString getNodeIdBytes() {
            return ByteString.n(this.nodeId_);
        }

        public LivekitModels.ParticipantInfo getParticipant() {
            LivekitModels.ParticipantInfo participantInfo = this.participant_;
            return participantInfo == null ? LivekitModels.ParticipantInfo.getDefaultInstance() : participantInfo;
        }

        public String getParticipantId() {
            return this.participantId_;
        }

        public ByteString getParticipantIdBytes() {
            return ByteString.n(this.participantId_);
        }

        public LivekitModels.ParticipantInfo getPublisher() {
            LivekitModels.ParticipantInfo participantInfo = this.publisher_;
            return participantInfo == null ? LivekitModels.ParticipantInfo.getDefaultInstance() : participantInfo;
        }

        public ReportInfo getReport() {
            ReportInfo reportInfo = this.report_;
            return reportInfo == null ? ReportInfo.getDefaultInstance() : reportInfo;
        }

        public LivekitModels.Room getRoom() {
            LivekitModels.Room room = this.room_;
            return room == null ? LivekitModels.Room.getDefaultInstance() : room;
        }

        public String getRoomId() {
            return this.roomId_;
        }

        public ByteString getRoomIdBytes() {
            return ByteString.n(this.roomId_);
        }

        public LivekitModels.RTPStats getRtpStats() {
            LivekitModels.RTPStats rTPStats = this.rtpStats_;
            return rTPStats == null ? LivekitModels.RTPStats.getDefaultInstance() : rTPStats;
        }

        public LivekitSip.SIPCallInfo getSipCall() {
            LivekitSip.SIPCallInfo sIPCallInfo = this.sipCall_;
            return sIPCallInfo == null ? LivekitSip.SIPCallInfo.getDefaultInstance() : sIPCallInfo;
        }

        public String getSipCallId() {
            return this.sipCallId_;
        }

        public ByteString getSipCallIdBytes() {
            return ByteString.n(this.sipCallId_);
        }

        public LivekitSip.SIPDispatchRuleInfo getSipDispatchRule() {
            LivekitSip.SIPDispatchRuleInfo sIPDispatchRuleInfo = this.sipDispatchRule_;
            return sIPDispatchRuleInfo == null ? LivekitSip.SIPDispatchRuleInfo.getDefaultInstance() : sIPDispatchRuleInfo;
        }

        public String getSipDispatchRuleId() {
            return this.sipDispatchRuleId_;
        }

        public ByteString getSipDispatchRuleIdBytes() {
            return ByteString.n(this.sipDispatchRuleId_);
        }

        public LivekitSip.SIPInboundTrunkInfo getSipInboundTrunk() {
            LivekitSip.SIPInboundTrunkInfo sIPInboundTrunkInfo = this.sipInboundTrunk_;
            return sIPInboundTrunkInfo == null ? LivekitSip.SIPInboundTrunkInfo.getDefaultInstance() : sIPInboundTrunkInfo;
        }

        public LivekitSip.SIPOutboundTrunkInfo getSipOutboundTrunk() {
            LivekitSip.SIPOutboundTrunkInfo sIPOutboundTrunkInfo = this.sipOutboundTrunk_;
            return sIPOutboundTrunkInfo == null ? LivekitSip.SIPOutboundTrunkInfo.getDefaultInstance() : sIPOutboundTrunkInfo;
        }

        public LivekitSip.SIPTransferInfo getSipTransfer() {
            LivekitSip.SIPTransferInfo sIPTransferInfo = this.sipTransfer_;
            return sIPTransferInfo == null ? LivekitSip.SIPTransferInfo.getDefaultInstance() : sIPTransferInfo;
        }

        public String getSipTrunkId() {
            return this.sipTrunkId_;
        }

        public ByteString getSipTrunkIdBytes() {
            return ByteString.n(this.sipTrunkId_);
        }

        public Timestamp getTimestamp() {
            Timestamp timestamp = this.timestamp_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public LivekitModels.TrackInfo getTrack() {
            LivekitModels.TrackInfo trackInfo = this.track_;
            return trackInfo == null ? LivekitModels.TrackInfo.getDefaultInstance() : trackInfo;
        }

        public String getTrackId() {
            return this.trackId_;
        }

        public ByteString getTrackIdBytes() {
            return ByteString.n(this.trackId_);
        }

        public AnalyticsEventType getType() {
            AnalyticsEventType analyticsEventTypeB = AnalyticsEventType.b(this.type_);
            return analyticsEventTypeB == null ? AnalyticsEventType.F0 : analyticsEventTypeB;
        }

        public int getTypeValue() {
            return this.type_;
        }

        public int getVideoLayer() {
            return this.videoLayer_;
        }

        public WebhookInfo getWebhook() {
            WebhookInfo webhookInfo = this.webhook_;
            return webhookInfo == null ? WebhookInfo.getDefaultInstance() : webhookInfo;
        }

        public boolean hasApiCall() {
            return this.apiCall_ != null;
        }

        public boolean hasClientInfo() {
            return this.clientInfo_ != null;
        }

        public boolean hasClientMeta() {
            return this.clientMeta_ != null;
        }

        public boolean hasEgress() {
            return this.egress_ != null;
        }

        public boolean hasIngress() {
            return this.ingress_ != null;
        }

        public boolean hasParticipant() {
            return this.participant_ != null;
        }

        public boolean hasPublisher() {
            return this.publisher_ != null;
        }

        public boolean hasReport() {
            return this.report_ != null;
        }

        public boolean hasRoom() {
            return this.room_ != null;
        }

        public boolean hasRtpStats() {
            return this.rtpStats_ != null;
        }

        public boolean hasSipCall() {
            return this.sipCall_ != null;
        }

        public boolean hasSipDispatchRule() {
            return this.sipDispatchRule_ != null;
        }

        public boolean hasSipInboundTrunk() {
            return this.sipInboundTrunk_ != null;
        }

        public boolean hasSipOutboundTrunk() {
            return this.sipOutboundTrunk_ != null;
        }

        public boolean hasSipTransfer() {
            return this.sipTransfer_ != null;
        }

        public boolean hasTimestamp() {
            return this.timestamp_ != null;
        }

        public boolean hasTrack() {
            return this.track_ != null;
        }

        public boolean hasWebhook() {
            return this.webhook_ != null;
        }

        public static Builder newBuilder(AnalyticsEvent analyticsEvent) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(analyticsEvent);
        }

        public static AnalyticsEvent parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvent) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsEvent parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AnalyticsEvent parseFrom(ByteString byteString) {
            return (AnalyticsEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AnalyticsEvent parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AnalyticsEvent parseFrom(byte[] bArr) {
            return (AnalyticsEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AnalyticsEvent parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AnalyticsEvent parseFrom(InputStream inputStream) {
            return (AnalyticsEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsEvent parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsEvent parseFrom(CodedInputStream codedInputStream) {
            return (AnalyticsEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AnalyticsEvent parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AnalyticsEventOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum AnalyticsEventType implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(45),
        g(4),
        h(20),
        i(5),
        j(6),
        k(21),
        l(25),
        m(7),
        n(10),
        o(23),
        p(24),
        q(26),
        r(27),
        s(11),
        t(22),
        u(12),
        v(13),
        w(28),
        x(14),
        y(15),
        z(18),
        A(19),
        B(16),
        D(17),
        G(29),
        H(30),
        J(31),
        N(32),
        Y(33),
        Z(34),
        u0(35),
        v0(36),
        w0(37),
        x0(38),
        y0(39),
        z0(43),
        A0(44),
        B0(46),
        C0(40),
        D0(41),
        E0(42),
        F0(-1);

        private static final Internal.EnumLiteMap G0 = new Internal.EnumLiteMap<AnalyticsEventType>() { // from class: livekit.LivekitAnalytics.AnalyticsEventType.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public AnalyticsEventType findValueByNumber(int i2) {
                return AnalyticsEventType.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AnalyticsEventTypeVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new AnalyticsEventTypeVerifier();

            private AnalyticsEventTypeVerifier() {
            }

            public boolean isInRange(int i) {
                return AnalyticsEventType.b(i) != null;
            }
        }

        AnalyticsEventType(int i2) {
            this.a = i2;
        }

        public static AnalyticsEventType b(int i2) {
            switch (i2) {
                case 0:
                    return b;
                case 1:
                    return c;
                case 2:
                    return d;
                case 3:
                    return e;
                case 4:
                    return g;
                case 5:
                    return i;
                case 6:
                    return j;
                case 7:
                    return m;
                case 8:
                case 9:
                default:
                    return null;
                case 10:
                    return n;
                case 11:
                    return s;
                case 12:
                    return u;
                case 13:
                    return v;
                case 14:
                    return x;
                case 15:
                    return y;
                case 16:
                    return B;
                case 17:
                    return D;
                case 18:
                    return z;
                case 19:
                    return A;
                case 20:
                    return h;
                case 21:
                    return k;
                case 22:
                    return t;
                case 23:
                    return o;
                case 24:
                    return p;
                case 25:
                    return l;
                case 26:
                    return q;
                case 27:
                    return r;
                case 28:
                    return w;
                case 29:
                    return G;
                case 30:
                    return H;
                case 31:
                    return J;
                case 32:
                    return N;
                case 33:
                    return Y;
                case 34:
                    return Z;
                case 35:
                    return u0;
                case 36:
                    return v0;
                case 37:
                    return w0;
                case 38:
                    return x0;
                case 39:
                    return y0;
                case 40:
                    return C0;
                case 41:
                    return D0;
                case LivekitInternal.NodeStats.NUM_TRACK_SUBSCRIBE_SUCCESS_FIELD_NUMBER /* 42 */:
                    return E0;
                case LivekitInternal.NodeStats.TRACK_SUBSCRIBE_SUCCESS_PER_SEC_FIELD_NUMBER /* 43 */:
                    return z0;
                case 44:
                    return A0;
                case 45:
                    return f;
                case 46:
                    return B0;
            }
        }

        public final int getNumber() {
            if (this != F0) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AnalyticsEvents extends GeneratedMessageLite<AnalyticsEvents, Builder> implements AnalyticsEventsOrBuilder {
        private static final AnalyticsEvents DEFAULT_INSTANCE;
        public static final int EVENTS_FIELD_NUMBER = 1;
        private static volatile Parser<AnalyticsEvents> PARSER;
        private Internal.ProtobufList<AnalyticsEvent> events_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AnalyticsEvents, Builder> implements AnalyticsEventsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AnalyticsEvents.DEFAULT_INSTANCE);
            }
        }

        static {
            AnalyticsEvents analyticsEvents = new AnalyticsEvents();
            DEFAULT_INSTANCE = analyticsEvents;
            GeneratedMessageLite.registerDefaultInstance(AnalyticsEvents.class, analyticsEvents);
        }

        private AnalyticsEvents() {
        }

        private void addAllEvents(Iterable<? extends AnalyticsEvent> iterable) {
            ensureEventsIsMutable();
            AbstractMessageLite.addAll(iterable, this.events_);
        }

        private void addEvents(AnalyticsEvent analyticsEvent) {
            analyticsEvent.getClass();
            ensureEventsIsMutable();
            this.events_.add(analyticsEvent);
        }

        private void clearEvents() {
            this.events_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureEventsIsMutable() {
            Internal.ProtobufList<AnalyticsEvent> protobufList = this.events_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.events_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static AnalyticsEvents getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AnalyticsEvents parseDelimitedFrom(InputStream inputStream) {
            return (AnalyticsEvents) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsEvents parseFrom(ByteBuffer byteBuffer) {
            return (AnalyticsEvents) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AnalyticsEvents> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeEvents(int i) {
            ensureEventsIsMutable();
            this.events_.remove(i);
        }

        private void setEvents(int i, AnalyticsEvent analyticsEvent) {
            analyticsEvent.getClass();
            ensureEventsIsMutable();
            this.events_.set(i, analyticsEvent);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AnalyticsEvents();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1331642863), AnalyticsEvent.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AnalyticsEvents> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AnalyticsEvents.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AnalyticsEvent getEvents(int i) {
            return (AnalyticsEvent) this.events_.get(i);
        }

        public int getEventsCount() {
            return this.events_.size();
        }

        public List<AnalyticsEvent> getEventsList() {
            return this.events_;
        }

        public AnalyticsEventOrBuilder getEventsOrBuilder(int i) {
            return (AnalyticsEventOrBuilder) this.events_.get(i);
        }

        public List<? extends AnalyticsEventOrBuilder> getEventsOrBuilderList() {
            return this.events_;
        }

        public static Builder newBuilder(AnalyticsEvents analyticsEvents) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(analyticsEvents);
        }

        public static AnalyticsEvents parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvents) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsEvents parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvents) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AnalyticsEvents parseFrom(ByteString byteString) {
            return (AnalyticsEvents) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addEvents(int i, AnalyticsEvent analyticsEvent) {
            analyticsEvent.getClass();
            ensureEventsIsMutable();
            this.events_.add(i, analyticsEvent);
        }

        public static AnalyticsEvents parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvents) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AnalyticsEvents parseFrom(byte[] bArr) {
            return (AnalyticsEvents) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AnalyticsEvents parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvents) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AnalyticsEvents parseFrom(InputStream inputStream) {
            return (AnalyticsEvents) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsEvents parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvents) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsEvents parseFrom(CodedInputStream codedInputStream) {
            return (AnalyticsEvents) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AnalyticsEvents parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsEvents) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AnalyticsEventsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AnalyticsNodeRooms extends GeneratedMessageLite<AnalyticsNodeRooms, Builder> implements AnalyticsNodeRoomsOrBuilder {
        private static final AnalyticsNodeRooms DEFAULT_INSTANCE;
        public static final int NODE_ID_FIELD_NUMBER = 1;
        private static volatile Parser<AnalyticsNodeRooms> PARSER = null;
        public static final int ROOMS_FIELD_NUMBER = 4;
        public static final int SEQUENCE_NUMBER_FIELD_NUMBER = 2;
        public static final int TIMESTAMP_FIELD_NUMBER = 3;
        private String nodeId_ = ap.a(2048549429);
        private Internal.ProtobufList<AnalyticsRoom> rooms_ = GeneratedMessageLite.emptyProtobufList();
        private long sequenceNumber_;
        private Timestamp timestamp_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AnalyticsNodeRooms, Builder> implements AnalyticsNodeRoomsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AnalyticsNodeRooms.DEFAULT_INSTANCE);
            }
        }

        static {
            AnalyticsNodeRooms analyticsNodeRooms = new AnalyticsNodeRooms();
            DEFAULT_INSTANCE = analyticsNodeRooms;
            GeneratedMessageLite.registerDefaultInstance(AnalyticsNodeRooms.class, analyticsNodeRooms);
        }

        private AnalyticsNodeRooms() {
        }

        private void addAllRooms(Iterable<? extends AnalyticsRoom> iterable) {
            ensureRoomsIsMutable();
            AbstractMessageLite.addAll(iterable, this.rooms_);
        }

        private void addRooms(AnalyticsRoom analyticsRoom) {
            analyticsRoom.getClass();
            ensureRoomsIsMutable();
            this.rooms_.add(analyticsRoom);
        }

        private void clearNodeId() {
            this.nodeId_ = getDefaultInstance().getNodeId();
        }

        private void clearRooms() {
            this.rooms_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSequenceNumber() {
            this.sequenceNumber_ = 0L;
        }

        private void clearTimestamp() {
            this.timestamp_ = null;
        }

        private void ensureRoomsIsMutable() {
            Internal.ProtobufList<AnalyticsRoom> protobufList = this.rooms_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.rooms_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static AnalyticsNodeRooms getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.timestamp_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.timestamp_ = timestamp;
            } else {
                this.timestamp_ = Timestamp.newBuilder(this.timestamp_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AnalyticsNodeRooms parseDelimitedFrom(InputStream inputStream) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsNodeRooms parseFrom(ByteBuffer byteBuffer) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AnalyticsNodeRooms> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeRooms(int i) {
            ensureRoomsIsMutable();
            this.rooms_.remove(i);
        }

        private void setNodeId(String str) {
            str.getClass();
            this.nodeId_ = str;
        }

        private void setNodeIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.nodeId_ = byteString.L();
        }

        private void setRooms(int i, AnalyticsRoom analyticsRoom) {
            analyticsRoom.getClass();
            ensureRoomsIsMutable();
            this.rooms_.set(i, analyticsRoom);
        }

        private void setSequenceNumber(long j) {
            this.sequenceNumber_ = j;
        }

        private void setTimestamp(Timestamp timestamp) {
            timestamp.getClass();
            this.timestamp_ = timestamp;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AnalyticsNodeRooms();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0001\u0000\u0001Ȉ\u0002\u0003\u0003\t\u0004\u001b", new Object[]{"nodeId_", "sequenceNumber_", "timestamp_", "rooms_", AnalyticsRoom.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AnalyticsNodeRooms> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AnalyticsNodeRooms.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getNodeId() {
            return this.nodeId_;
        }

        public ByteString getNodeIdBytes() {
            return ByteString.n(this.nodeId_);
        }

        public AnalyticsRoom getRooms(int i) {
            return (AnalyticsRoom) this.rooms_.get(i);
        }

        public int getRoomsCount() {
            return this.rooms_.size();
        }

        public List<AnalyticsRoom> getRoomsList() {
            return this.rooms_;
        }

        public AnalyticsRoomOrBuilder getRoomsOrBuilder(int i) {
            return (AnalyticsRoomOrBuilder) this.rooms_.get(i);
        }

        public List<? extends AnalyticsRoomOrBuilder> getRoomsOrBuilderList() {
            return this.rooms_;
        }

        public long getSequenceNumber() {
            return this.sequenceNumber_;
        }

        public Timestamp getTimestamp() {
            Timestamp timestamp = this.timestamp_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public boolean hasTimestamp() {
            return this.timestamp_ != null;
        }

        public static Builder newBuilder(AnalyticsNodeRooms analyticsNodeRooms) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(analyticsNodeRooms);
        }

        public static AnalyticsNodeRooms parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsNodeRooms parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AnalyticsNodeRooms parseFrom(ByteString byteString) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addRooms(int i, AnalyticsRoom analyticsRoom) {
            analyticsRoom.getClass();
            ensureRoomsIsMutable();
            this.rooms_.add(i, analyticsRoom);
        }

        public static AnalyticsNodeRooms parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AnalyticsNodeRooms parseFrom(byte[] bArr) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AnalyticsNodeRooms parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AnalyticsNodeRooms parseFrom(InputStream inputStream) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsNodeRooms parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsNodeRooms parseFrom(CodedInputStream codedInputStream) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AnalyticsNodeRooms parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsNodeRooms) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AnalyticsNodeRoomsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AnalyticsRoom extends GeneratedMessageLite<AnalyticsRoom, Builder> implements AnalyticsRoomOrBuilder {
        public static final int CREATED_AT_FIELD_NUMBER = 3;
        private static final AnalyticsRoom DEFAULT_INSTANCE;
        public static final int ID_FIELD_NUMBER = 1;
        public static final int NAME_FIELD_NUMBER = 2;
        private static volatile Parser<AnalyticsRoom> PARSER = null;
        public static final int PARTICIPANTS_FIELD_NUMBER = 4;
        public static final int PROJECT_ID_FIELD_NUMBER = 5;
        private Timestamp createdAt_;
        private String id_;
        private String name_;
        private Internal.ProtobufList<AnalyticsRoomParticipant> participants_;
        private String projectId_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AnalyticsRoom, Builder> implements AnalyticsRoomOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AnalyticsRoom.DEFAULT_INSTANCE);
            }
        }

        static {
            AnalyticsRoom analyticsRoom = new AnalyticsRoom();
            DEFAULT_INSTANCE = analyticsRoom;
            GeneratedMessageLite.registerDefaultInstance(AnalyticsRoom.class, analyticsRoom);
        }

        private AnalyticsRoom() {
            String strA = ap.a(1564002815);
            this.id_ = strA;
            this.name_ = strA;
            this.projectId_ = strA;
            this.participants_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllParticipants(Iterable<? extends AnalyticsRoomParticipant> iterable) {
            ensureParticipantsIsMutable();
            AbstractMessageLite.addAll(iterable, this.participants_);
        }

        private void addParticipants(AnalyticsRoomParticipant analyticsRoomParticipant) {
            analyticsRoomParticipant.getClass();
            ensureParticipantsIsMutable();
            this.participants_.add(analyticsRoomParticipant);
        }

        private void clearCreatedAt() {
            this.createdAt_ = null;
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearParticipants() {
            this.participants_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearProjectId() {
            this.projectId_ = getDefaultInstance().getProjectId();
        }

        private void ensureParticipantsIsMutable() {
            Internal.ProtobufList<AnalyticsRoomParticipant> protobufList = this.participants_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.participants_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static AnalyticsRoom getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeCreatedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.createdAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.createdAt_ = timestamp;
            } else {
                this.createdAt_ = Timestamp.newBuilder(this.createdAt_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AnalyticsRoom parseDelimitedFrom(InputStream inputStream) {
            return (AnalyticsRoom) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsRoom parseFrom(ByteBuffer byteBuffer) {
            return (AnalyticsRoom) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AnalyticsRoom> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeParticipants(int i) {
            ensureParticipantsIsMutable();
            this.participants_.remove(i);
        }

        private void setCreatedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.createdAt_ = timestamp;
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setParticipants(int i, AnalyticsRoomParticipant analyticsRoomParticipant) {
            analyticsRoomParticipant.getClass();
            ensureParticipantsIsMutable();
            this.participants_.set(i, analyticsRoomParticipant);
        }

        private void setProjectId(String str) {
            str.getClass();
            this.projectId_ = str;
        }

        private void setProjectIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.projectId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AnalyticsRoom();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0001\u0000\u0001Ȉ\u0002Ȉ\u0003\t\u0004\u001b\u0005Ȉ", new Object[]{"id_", "name_", "createdAt_", "participants_", AnalyticsRoomParticipant.class, "projectId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AnalyticsRoom> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AnalyticsRoom.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Timestamp getCreatedAt() {
            Timestamp timestamp = this.createdAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public AnalyticsRoomParticipant getParticipants(int i) {
            return (AnalyticsRoomParticipant) this.participants_.get(i);
        }

        public int getParticipantsCount() {
            return this.participants_.size();
        }

        public List<AnalyticsRoomParticipant> getParticipantsList() {
            return this.participants_;
        }

        public AnalyticsRoomParticipantOrBuilder getParticipantsOrBuilder(int i) {
            return (AnalyticsRoomParticipantOrBuilder) this.participants_.get(i);
        }

        public List<? extends AnalyticsRoomParticipantOrBuilder> getParticipantsOrBuilderList() {
            return this.participants_;
        }

        public String getProjectId() {
            return this.projectId_;
        }

        public ByteString getProjectIdBytes() {
            return ByteString.n(this.projectId_);
        }

        public boolean hasCreatedAt() {
            return this.createdAt_ != null;
        }

        public static Builder newBuilder(AnalyticsRoom analyticsRoom) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(analyticsRoom);
        }

        public static AnalyticsRoom parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoom) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsRoom parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoom) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AnalyticsRoom parseFrom(ByteString byteString) {
            return (AnalyticsRoom) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addParticipants(int i, AnalyticsRoomParticipant analyticsRoomParticipant) {
            analyticsRoomParticipant.getClass();
            ensureParticipantsIsMutable();
            this.participants_.add(i, analyticsRoomParticipant);
        }

        public static AnalyticsRoom parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoom) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AnalyticsRoom parseFrom(byte[] bArr) {
            return (AnalyticsRoom) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AnalyticsRoom parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoom) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AnalyticsRoom parseFrom(InputStream inputStream) {
            return (AnalyticsRoom) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsRoom parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoom) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsRoom parseFrom(CodedInputStream codedInputStream) {
            return (AnalyticsRoom) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AnalyticsRoom parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoom) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AnalyticsRoomOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AnalyticsRoomParticipant extends GeneratedMessageLite<AnalyticsRoomParticipant, Builder> implements AnalyticsRoomParticipantOrBuilder {
        private static final AnalyticsRoomParticipant DEFAULT_INSTANCE;
        public static final int IDENTITY_FIELD_NUMBER = 2;
        public static final int ID_FIELD_NUMBER = 1;
        public static final int JOINED_AT_FIELD_NUMBER = 5;
        public static final int NAME_FIELD_NUMBER = 3;
        private static volatile Parser<AnalyticsRoomParticipant> PARSER = null;
        public static final int STATE_FIELD_NUMBER = 4;
        private String id_;
        private String identity_;
        private Timestamp joinedAt_;
        private String name_;
        private int state_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AnalyticsRoomParticipant, Builder> implements AnalyticsRoomParticipantOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AnalyticsRoomParticipant.DEFAULT_INSTANCE);
            }
        }

        static {
            AnalyticsRoomParticipant analyticsRoomParticipant = new AnalyticsRoomParticipant();
            DEFAULT_INSTANCE = analyticsRoomParticipant;
            GeneratedMessageLite.registerDefaultInstance(AnalyticsRoomParticipant.class, analyticsRoomParticipant);
        }

        private AnalyticsRoomParticipant() {
            String strA = ap.a(1925036389);
            this.id_ = strA;
            this.identity_ = strA;
            this.name_ = strA;
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearIdentity() {
            this.identity_ = getDefaultInstance().getIdentity();
        }

        private void clearJoinedAt() {
            this.joinedAt_ = null;
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearState() {
            this.state_ = 0;
        }

        public static AnalyticsRoomParticipant getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeJoinedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.joinedAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.joinedAt_ = timestamp;
            } else {
                this.joinedAt_ = Timestamp.newBuilder(this.joinedAt_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AnalyticsRoomParticipant parseDelimitedFrom(InputStream inputStream) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsRoomParticipant parseFrom(ByteBuffer byteBuffer) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AnalyticsRoomParticipant> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setIdentity(String str) {
            str.getClass();
            this.identity_ = str;
        }

        private void setIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.identity_ = byteString.L();
        }

        private void setJoinedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.joinedAt_ = timestamp;
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setState(LivekitModels.ParticipantInfo.State state) {
            this.state_ = state.getNumber();
        }

        private void setStateValue(int i) {
            this.state_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AnalyticsRoomParticipant();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\f\u0005\t", new Object[]{"id_", "identity_", "name_", "state_", "joinedAt_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AnalyticsRoomParticipant> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AnalyticsRoomParticipant.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public String getIdentity() {
            return this.identity_;
        }

        public ByteString getIdentityBytes() {
            return ByteString.n(this.identity_);
        }

        public Timestamp getJoinedAt() {
            Timestamp timestamp = this.joinedAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public LivekitModels.ParticipantInfo.State getState() {
            LivekitModels.ParticipantInfo.State stateB = LivekitModels.ParticipantInfo.State.b(this.state_);
            return stateB == null ? LivekitModels.ParticipantInfo.State.f : stateB;
        }

        public int getStateValue() {
            return this.state_;
        }

        public boolean hasJoinedAt() {
            return this.joinedAt_ != null;
        }

        public static Builder newBuilder(AnalyticsRoomParticipant analyticsRoomParticipant) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(analyticsRoomParticipant);
        }

        public static AnalyticsRoomParticipant parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsRoomParticipant parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AnalyticsRoomParticipant parseFrom(ByteString byteString) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AnalyticsRoomParticipant parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AnalyticsRoomParticipant parseFrom(byte[] bArr) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AnalyticsRoomParticipant parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AnalyticsRoomParticipant parseFrom(InputStream inputStream) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsRoomParticipant parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsRoomParticipant parseFrom(CodedInputStream codedInputStream) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AnalyticsRoomParticipant parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsRoomParticipant) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AnalyticsRoomParticipantOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AnalyticsStat extends GeneratedMessageLite<AnalyticsStat, Builder> implements AnalyticsStatOrBuilder {
        public static final int ANALYTICS_KEY_FIELD_NUMBER = 1;
        private static final AnalyticsStat DEFAULT_INSTANCE;
        public static final int ID_FIELD_NUMBER = 14;
        public static final int KIND_FIELD_NUMBER = 2;
        public static final int MEDIAN_SCORE_FIELD_NUMBER = 13;
        public static final int MIME_FIELD_NUMBER = 11;
        public static final int MIN_SCORE_FIELD_NUMBER = 12;
        public static final int NODE_FIELD_NUMBER = 4;
        private static volatile Parser<AnalyticsStat> PARSER = null;
        public static final int PARTICIPANT_ID_FIELD_NUMBER = 7;
        public static final int ROOM_ID_FIELD_NUMBER = 5;
        public static final int ROOM_NAME_FIELD_NUMBER = 6;
        public static final int SCORE_FIELD_NUMBER = 9;
        public static final int STREAMS_FIELD_NUMBER = 10;
        public static final int TIME_STAMP_FIELD_NUMBER = 3;
        public static final int TRACK_ID_FIELD_NUMBER = 8;
        private String analyticsKey_;
        private String id_;
        private int kind_;
        private float medianScore_;
        private String mime_;
        private float minScore_;
        private String node_;
        private String participantId_;
        private String roomId_;
        private String roomName_;
        private float score_;
        private Internal.ProtobufList<AnalyticsStream> streams_;
        private Timestamp timeStamp_;
        private String trackId_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AnalyticsStat, Builder> implements AnalyticsStatOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AnalyticsStat.DEFAULT_INSTANCE);
            }
        }

        static {
            AnalyticsStat analyticsStat = new AnalyticsStat();
            DEFAULT_INSTANCE = analyticsStat;
            GeneratedMessageLite.registerDefaultInstance(AnalyticsStat.class, analyticsStat);
        }

        private AnalyticsStat() {
            String strA = ap.a(580789396);
            this.id_ = strA;
            this.analyticsKey_ = strA;
            this.node_ = strA;
            this.roomId_ = strA;
            this.roomName_ = strA;
            this.participantId_ = strA;
            this.trackId_ = strA;
            this.streams_ = GeneratedMessageLite.emptyProtobufList();
            this.mime_ = strA;
        }

        private void addAllStreams(Iterable<? extends AnalyticsStream> iterable) {
            ensureStreamsIsMutable();
            AbstractMessageLite.addAll(iterable, this.streams_);
        }

        private void addStreams(AnalyticsStream analyticsStream) {
            analyticsStream.getClass();
            ensureStreamsIsMutable();
            this.streams_.add(analyticsStream);
        }

        private void clearAnalyticsKey() {
            this.analyticsKey_ = getDefaultInstance().getAnalyticsKey();
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearKind() {
            this.kind_ = 0;
        }

        private void clearMedianScore() {
            this.medianScore_ = 0.0f;
        }

        private void clearMime() {
            this.mime_ = getDefaultInstance().getMime();
        }

        private void clearMinScore() {
            this.minScore_ = 0.0f;
        }

        private void clearNode() {
            this.node_ = getDefaultInstance().getNode();
        }

        private void clearParticipantId() {
            this.participantId_ = getDefaultInstance().getParticipantId();
        }

        private void clearRoomId() {
            this.roomId_ = getDefaultInstance().getRoomId();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearScore() {
            this.score_ = 0.0f;
        }

        private void clearStreams() {
            this.streams_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearTimeStamp() {
            this.timeStamp_ = null;
        }

        private void clearTrackId() {
            this.trackId_ = getDefaultInstance().getTrackId();
        }

        private void ensureStreamsIsMutable() {
            Internal.ProtobufList<AnalyticsStream> protobufList = this.streams_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.streams_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static AnalyticsStat getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeTimeStamp(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.timeStamp_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.timeStamp_ = timestamp;
            } else {
                this.timeStamp_ = Timestamp.newBuilder(this.timeStamp_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AnalyticsStat parseDelimitedFrom(InputStream inputStream) {
            return (AnalyticsStat) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsStat parseFrom(ByteBuffer byteBuffer) {
            return (AnalyticsStat) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AnalyticsStat> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeStreams(int i) {
            ensureStreamsIsMutable();
            this.streams_.remove(i);
        }

        private void setAnalyticsKey(String str) {
            str.getClass();
            this.analyticsKey_ = str;
        }

        private void setAnalyticsKeyBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.analyticsKey_ = byteString.L();
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setKind(StreamType streamType) {
            this.kind_ = streamType.getNumber();
        }

        private void setKindValue(int i) {
            this.kind_ = i;
        }

        private void setMedianScore(float f) {
            this.medianScore_ = f;
        }

        private void setMime(String str) {
            str.getClass();
            this.mime_ = str;
        }

        private void setMimeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.mime_ = byteString.L();
        }

        private void setMinScore(float f) {
            this.minScore_ = f;
        }

        private void setNode(String str) {
            str.getClass();
            this.node_ = str;
        }

        private void setNodeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.node_ = byteString.L();
        }

        private void setParticipantId(String str) {
            str.getClass();
            this.participantId_ = str;
        }

        private void setParticipantIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantId_ = byteString.L();
        }

        private void setRoomId(String str) {
            str.getClass();
            this.roomId_ = str;
        }

        private void setRoomIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomId_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setScore(float f) {
            this.score_ = f;
        }

        private void setStreams(int i, AnalyticsStream analyticsStream) {
            analyticsStream.getClass();
            ensureStreamsIsMutable();
            this.streams_.set(i, analyticsStream);
        }

        private void setTimeStamp(Timestamp timestamp) {
            timestamp.getClass();
            this.timeStamp_ = timestamp;
        }

        private void setTrackId(String str) {
            str.getClass();
            this.trackId_ = str;
        }

        private void setTrackIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new AnalyticsStat();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000e\u0000\u0000\u0001\u000e\u000e\u0000\u0001\u0000\u0001Ȉ\u0002\f\u0003\t\u0004Ȉ\u0005Ȉ\u0006Ȉ\u0007Ȉ\bȈ\t\u0001\n\u001b\u000bȈ\f\u0001\r\u0001\u000eȈ", new Object[]{"analyticsKey_", "kind_", "timeStamp_", "node_", "roomId_", "roomName_", "participantId_", "trackId_", "score_", "streams_", AnalyticsStream.class, "mime_", "minScore_", "medianScore_", "id_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AnalyticsStat> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AnalyticsStat.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAnalyticsKey() {
            return this.analyticsKey_;
        }

        public ByteString getAnalyticsKeyBytes() {
            return ByteString.n(this.analyticsKey_);
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public StreamType getKind() {
            StreamType streamTypeB = StreamType.b(this.kind_);
            return streamTypeB == null ? StreamType.d : streamTypeB;
        }

        public int getKindValue() {
            return this.kind_;
        }

        public float getMedianScore() {
            return this.medianScore_;
        }

        public String getMime() {
            return this.mime_;
        }

        public ByteString getMimeBytes() {
            return ByteString.n(this.mime_);
        }

        public float getMinScore() {
            return this.minScore_;
        }

        public String getNode() {
            return this.node_;
        }

        public ByteString getNodeBytes() {
            return ByteString.n(this.node_);
        }

        public String getParticipantId() {
            return this.participantId_;
        }

        public ByteString getParticipantIdBytes() {
            return ByteString.n(this.participantId_);
        }

        public String getRoomId() {
            return this.roomId_;
        }

        public ByteString getRoomIdBytes() {
            return ByteString.n(this.roomId_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public float getScore() {
            return this.score_;
        }

        public AnalyticsStream getStreams(int i) {
            return (AnalyticsStream) this.streams_.get(i);
        }

        public int getStreamsCount() {
            return this.streams_.size();
        }

        public List<AnalyticsStream> getStreamsList() {
            return this.streams_;
        }

        public AnalyticsStreamOrBuilder getStreamsOrBuilder(int i) {
            return (AnalyticsStreamOrBuilder) this.streams_.get(i);
        }

        public List<? extends AnalyticsStreamOrBuilder> getStreamsOrBuilderList() {
            return this.streams_;
        }

        public Timestamp getTimeStamp() {
            Timestamp timestamp = this.timeStamp_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public String getTrackId() {
            return this.trackId_;
        }

        public ByteString getTrackIdBytes() {
            return ByteString.n(this.trackId_);
        }

        public boolean hasTimeStamp() {
            return this.timeStamp_ != null;
        }

        public static Builder newBuilder(AnalyticsStat analyticsStat) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(analyticsStat);
        }

        public static AnalyticsStat parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStat) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsStat parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStat) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AnalyticsStat parseFrom(ByteString byteString) {
            return (AnalyticsStat) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addStreams(int i, AnalyticsStream analyticsStream) {
            analyticsStream.getClass();
            ensureStreamsIsMutable();
            this.streams_.add(i, analyticsStream);
        }

        public static AnalyticsStat parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStat) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AnalyticsStat parseFrom(byte[] bArr) {
            return (AnalyticsStat) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AnalyticsStat parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStat) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AnalyticsStat parseFrom(InputStream inputStream) {
            return (AnalyticsStat) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsStat parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStat) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsStat parseFrom(CodedInputStream codedInputStream) {
            return (AnalyticsStat) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AnalyticsStat parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStat) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AnalyticsStatOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AnalyticsStats extends GeneratedMessageLite<AnalyticsStats, Builder> implements AnalyticsStatsOrBuilder {
        private static final AnalyticsStats DEFAULT_INSTANCE;
        private static volatile Parser<AnalyticsStats> PARSER = null;
        public static final int STATS_FIELD_NUMBER = 1;
        private Internal.ProtobufList<AnalyticsStat> stats_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AnalyticsStats, Builder> implements AnalyticsStatsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AnalyticsStats.DEFAULT_INSTANCE);
            }
        }

        static {
            AnalyticsStats analyticsStats = new AnalyticsStats();
            DEFAULT_INSTANCE = analyticsStats;
            GeneratedMessageLite.registerDefaultInstance(AnalyticsStats.class, analyticsStats);
        }

        private AnalyticsStats() {
        }

        private void addAllStats(Iterable<? extends AnalyticsStat> iterable) {
            ensureStatsIsMutable();
            AbstractMessageLite.addAll(iterable, this.stats_);
        }

        private void addStats(AnalyticsStat analyticsStat) {
            analyticsStat.getClass();
            ensureStatsIsMutable();
            this.stats_.add(analyticsStat);
        }

        private void clearStats() {
            this.stats_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureStatsIsMutable() {
            Internal.ProtobufList<AnalyticsStat> protobufList = this.stats_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.stats_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static AnalyticsStats getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AnalyticsStats parseDelimitedFrom(InputStream inputStream) {
            return (AnalyticsStats) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsStats parseFrom(ByteBuffer byteBuffer) {
            return (AnalyticsStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AnalyticsStats> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeStats(int i) {
            ensureStatsIsMutable();
            this.stats_.remove(i);
        }

        private void setStats(int i, AnalyticsStat analyticsStat) {
            analyticsStat.getClass();
            ensureStatsIsMutable();
            this.stats_.set(i, analyticsStat);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AnalyticsStats();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(776316697), AnalyticsStat.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AnalyticsStats> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AnalyticsStats.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AnalyticsStat getStats(int i) {
            return (AnalyticsStat) this.stats_.get(i);
        }

        public int getStatsCount() {
            return this.stats_.size();
        }

        public List<AnalyticsStat> getStatsList() {
            return this.stats_;
        }

        public AnalyticsStatOrBuilder getStatsOrBuilder(int i) {
            return (AnalyticsStatOrBuilder) this.stats_.get(i);
        }

        public List<? extends AnalyticsStatOrBuilder> getStatsOrBuilderList() {
            return this.stats_;
        }

        public static Builder newBuilder(AnalyticsStats analyticsStats) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(analyticsStats);
        }

        public static AnalyticsStats parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStats) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsStats parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AnalyticsStats parseFrom(ByteString byteString) {
            return (AnalyticsStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addStats(int i, AnalyticsStat analyticsStat) {
            analyticsStat.getClass();
            ensureStatsIsMutable();
            this.stats_.add(i, analyticsStat);
        }

        public static AnalyticsStats parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AnalyticsStats parseFrom(byte[] bArr) {
            return (AnalyticsStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AnalyticsStats parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AnalyticsStats parseFrom(InputStream inputStream) {
            return (AnalyticsStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsStats parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsStats parseFrom(CodedInputStream codedInputStream) {
            return (AnalyticsStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AnalyticsStats parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStats) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AnalyticsStatsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AnalyticsStream extends GeneratedMessageLite<AnalyticsStream, Builder> implements AnalyticsStreamOrBuilder {
        private static final AnalyticsStream DEFAULT_INSTANCE;
        public static final int END_TIME_FIELD_NUMBER = 18;
        public static final int FIRS_FIELD_NUMBER = 14;
        public static final int FRAMES_FIELD_NUMBER = 9;
        public static final int JITTER_FIELD_NUMBER = 11;
        public static final int NACKS_FIELD_NUMBER = 12;
        public static final int PACKETS_LOST_FIELD_NUMBER = 8;
        public static final int PACKETS_OUT_OF_ORDER_FIELD_NUMBER = 19;
        public static final int PADDING_BYTES_FIELD_NUMBER = 7;
        public static final int PADDING_PACKETS_FIELD_NUMBER = 6;
        private static volatile Parser<AnalyticsStream> PARSER = null;
        public static final int PLIS_FIELD_NUMBER = 13;
        public static final int PRIMARY_BYTES_FIELD_NUMBER = 3;
        public static final int PRIMARY_PACKETS_FIELD_NUMBER = 2;
        public static final int RETRANSMIT_BYTES_FIELD_NUMBER = 5;
        public static final int RETRANSMIT_PACKETS_FIELD_NUMBER = 4;
        public static final int RTT_FIELD_NUMBER = 10;
        public static final int SSRC_FIELD_NUMBER = 1;
        public static final int START_TIME_FIELD_NUMBER = 17;
        public static final int VIDEO_LAYERS_FIELD_NUMBER = 15;
        private Timestamp endTime_;
        private int firs_;
        private int frames_;
        private int jitter_;
        private int nacks_;
        private int packetsLost_;
        private int packetsOutOfOrder_;
        private long paddingBytes_;
        private int paddingPackets_;
        private int plis_;
        private long primaryBytes_;
        private int primaryPackets_;
        private long retransmitBytes_;
        private int retransmitPackets_;
        private int rtt_;
        private int ssrc_;
        private Timestamp startTime_;
        private Internal.ProtobufList<AnalyticsVideoLayer> videoLayers_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AnalyticsStream, Builder> implements AnalyticsStreamOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AnalyticsStream.DEFAULT_INSTANCE);
            }
        }

        static {
            AnalyticsStream analyticsStream = new AnalyticsStream();
            DEFAULT_INSTANCE = analyticsStream;
            GeneratedMessageLite.registerDefaultInstance(AnalyticsStream.class, analyticsStream);
        }

        private AnalyticsStream() {
        }

        private void addAllVideoLayers(Iterable<? extends AnalyticsVideoLayer> iterable) {
            ensureVideoLayersIsMutable();
            AbstractMessageLite.addAll(iterable, this.videoLayers_);
        }

        private void addVideoLayers(AnalyticsVideoLayer analyticsVideoLayer) {
            analyticsVideoLayer.getClass();
            ensureVideoLayersIsMutable();
            this.videoLayers_.add(analyticsVideoLayer);
        }

        private void clearEndTime() {
            this.endTime_ = null;
        }

        private void clearFirs() {
            this.firs_ = 0;
        }

        private void clearFrames() {
            this.frames_ = 0;
        }

        private void clearJitter() {
            this.jitter_ = 0;
        }

        private void clearNacks() {
            this.nacks_ = 0;
        }

        private void clearPacketsLost() {
            this.packetsLost_ = 0;
        }

        private void clearPacketsOutOfOrder() {
            this.packetsOutOfOrder_ = 0;
        }

        private void clearPaddingBytes() {
            this.paddingBytes_ = 0L;
        }

        private void clearPaddingPackets() {
            this.paddingPackets_ = 0;
        }

        private void clearPlis() {
            this.plis_ = 0;
        }

        private void clearPrimaryBytes() {
            this.primaryBytes_ = 0L;
        }

        private void clearPrimaryPackets() {
            this.primaryPackets_ = 0;
        }

        private void clearRetransmitBytes() {
            this.retransmitBytes_ = 0L;
        }

        private void clearRetransmitPackets() {
            this.retransmitPackets_ = 0;
        }

        private void clearRtt() {
            this.rtt_ = 0;
        }

        private void clearSsrc() {
            this.ssrc_ = 0;
        }

        private void clearStartTime() {
            this.startTime_ = null;
        }

        private void clearVideoLayers() {
            this.videoLayers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureVideoLayersIsMutable() {
            Internal.ProtobufList<AnalyticsVideoLayer> protobufList = this.videoLayers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.videoLayers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static AnalyticsStream getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeEndTime(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.endTime_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.endTime_ = timestamp;
            } else {
                this.endTime_ = Timestamp.newBuilder(this.endTime_).v(timestamp).o();
            }
        }

        private void mergeStartTime(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.startTime_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.startTime_ = timestamp;
            } else {
                this.startTime_ = Timestamp.newBuilder(this.startTime_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AnalyticsStream parseDelimitedFrom(InputStream inputStream) {
            return (AnalyticsStream) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsStream parseFrom(ByteBuffer byteBuffer) {
            return (AnalyticsStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AnalyticsStream> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeVideoLayers(int i) {
            ensureVideoLayersIsMutable();
            this.videoLayers_.remove(i);
        }

        private void setEndTime(Timestamp timestamp) {
            timestamp.getClass();
            this.endTime_ = timestamp;
        }

        private void setFirs(int i) {
            this.firs_ = i;
        }

        private void setFrames(int i) {
            this.frames_ = i;
        }

        private void setJitter(int i) {
            this.jitter_ = i;
        }

        private void setNacks(int i) {
            this.nacks_ = i;
        }

        private void setPacketsLost(int i) {
            this.packetsLost_ = i;
        }

        private void setPacketsOutOfOrder(int i) {
            this.packetsOutOfOrder_ = i;
        }

        private void setPaddingBytes(long j) {
            this.paddingBytes_ = j;
        }

        private void setPaddingPackets(int i) {
            this.paddingPackets_ = i;
        }

        private void setPlis(int i) {
            this.plis_ = i;
        }

        private void setPrimaryBytes(long j) {
            this.primaryBytes_ = j;
        }

        private void setPrimaryPackets(int i) {
            this.primaryPackets_ = i;
        }

        private void setRetransmitBytes(long j) {
            this.retransmitBytes_ = j;
        }

        private void setRetransmitPackets(int i) {
            this.retransmitPackets_ = i;
        }

        private void setRtt(int i) {
            this.rtt_ = i;
        }

        private void setSsrc(int i) {
            this.ssrc_ = i;
        }

        private void setStartTime(Timestamp timestamp) {
            timestamp.getClass();
            this.startTime_ = timestamp;
        }

        private void setVideoLayers(int i, AnalyticsVideoLayer analyticsVideoLayer) {
            analyticsVideoLayer.getClass();
            ensureVideoLayersIsMutable();
            this.videoLayers_.set(i, analyticsVideoLayer);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new AnalyticsStream();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0012\u0000\u0000\u0001\u0013\u0012\u0000\u0001\u0000\u0001\u000b\u0002\u000b\u0003\u0003\u0004\u000b\u0005\u0003\u0006\u000b\u0007\u0003\b\u000b\t\u000b\n\u000b\u000b\u000b\f\u000b\r\u000b\u000e\u000b\u000f\u001b\u0011\t\u0012\t\u0013\u000b", new Object[]{ap.a(1053971802), ap.a(697428378), ap.a(1297456936), ap.a(117024510), ap.a(1852201657), ap.a(1419424111), ap.a(80247724), ap.a(1415583983), ap.a(856017489), ap.a(593575070), ap.a(1446793065), ap.a(290564026), ap.a(74360613), ap.a(1618408976), ap.a(6515191), AnalyticsVideoLayer.class, ap.a(599310186), ap.a(1157687060), ap.a(1609458796)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AnalyticsStream> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AnalyticsStream.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Timestamp getEndTime() {
            Timestamp timestamp = this.endTime_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public int getFirs() {
            return this.firs_;
        }

        public int getFrames() {
            return this.frames_;
        }

        public int getJitter() {
            return this.jitter_;
        }

        public int getNacks() {
            return this.nacks_;
        }

        public int getPacketsLost() {
            return this.packetsLost_;
        }

        public int getPacketsOutOfOrder() {
            return this.packetsOutOfOrder_;
        }

        public long getPaddingBytes() {
            return this.paddingBytes_;
        }

        public int getPaddingPackets() {
            return this.paddingPackets_;
        }

        public int getPlis() {
            return this.plis_;
        }

        public long getPrimaryBytes() {
            return this.primaryBytes_;
        }

        public int getPrimaryPackets() {
            return this.primaryPackets_;
        }

        public long getRetransmitBytes() {
            return this.retransmitBytes_;
        }

        public int getRetransmitPackets() {
            return this.retransmitPackets_;
        }

        public int getRtt() {
            return this.rtt_;
        }

        public int getSsrc() {
            return this.ssrc_;
        }

        public Timestamp getStartTime() {
            Timestamp timestamp = this.startTime_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public AnalyticsVideoLayer getVideoLayers(int i) {
            return (AnalyticsVideoLayer) this.videoLayers_.get(i);
        }

        public int getVideoLayersCount() {
            return this.videoLayers_.size();
        }

        public List<AnalyticsVideoLayer> getVideoLayersList() {
            return this.videoLayers_;
        }

        public AnalyticsVideoLayerOrBuilder getVideoLayersOrBuilder(int i) {
            return (AnalyticsVideoLayerOrBuilder) this.videoLayers_.get(i);
        }

        public List<? extends AnalyticsVideoLayerOrBuilder> getVideoLayersOrBuilderList() {
            return this.videoLayers_;
        }

        public boolean hasEndTime() {
            return this.endTime_ != null;
        }

        public boolean hasStartTime() {
            return this.startTime_ != null;
        }

        public static Builder newBuilder(AnalyticsStream analyticsStream) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(analyticsStream);
        }

        public static AnalyticsStream parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStream) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsStream parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AnalyticsStream parseFrom(ByteString byteString) {
            return (AnalyticsStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addVideoLayers(int i, AnalyticsVideoLayer analyticsVideoLayer) {
            analyticsVideoLayer.getClass();
            ensureVideoLayersIsMutable();
            this.videoLayers_.add(i, analyticsVideoLayer);
        }

        public static AnalyticsStream parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AnalyticsStream parseFrom(byte[] bArr) {
            return (AnalyticsStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AnalyticsStream parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AnalyticsStream parseFrom(InputStream inputStream) {
            return (AnalyticsStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsStream parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsStream parseFrom(CodedInputStream codedInputStream) {
            return (AnalyticsStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AnalyticsStream parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsStream) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AnalyticsStreamOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AnalyticsVideoLayer extends GeneratedMessageLite<AnalyticsVideoLayer, Builder> implements AnalyticsVideoLayerOrBuilder {
        public static final int BYTES_FIELD_NUMBER = 3;
        private static final AnalyticsVideoLayer DEFAULT_INSTANCE;
        public static final int FRAMES_FIELD_NUMBER = 4;
        public static final int LAYER_FIELD_NUMBER = 1;
        public static final int PACKETS_FIELD_NUMBER = 2;
        private static volatile Parser<AnalyticsVideoLayer> PARSER;
        private long bytes_;
        private int frames_;
        private int layer_;
        private int packets_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AnalyticsVideoLayer, Builder> implements AnalyticsVideoLayerOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AnalyticsVideoLayer.DEFAULT_INSTANCE);
            }
        }

        static {
            AnalyticsVideoLayer analyticsVideoLayer = new AnalyticsVideoLayer();
            DEFAULT_INSTANCE = analyticsVideoLayer;
            GeneratedMessageLite.registerDefaultInstance(AnalyticsVideoLayer.class, analyticsVideoLayer);
        }

        private AnalyticsVideoLayer() {
        }

        private void clearBytes() {
            this.bytes_ = 0L;
        }

        private void clearFrames() {
            this.frames_ = 0;
        }

        private void clearLayer() {
            this.layer_ = 0;
        }

        private void clearPackets() {
            this.packets_ = 0;
        }

        public static AnalyticsVideoLayer getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AnalyticsVideoLayer parseDelimitedFrom(InputStream inputStream) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsVideoLayer parseFrom(ByteBuffer byteBuffer) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AnalyticsVideoLayer> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setBytes(long j) {
            this.bytes_ = j;
        }

        private void setFrames(int i) {
            this.frames_ = i;
        }

        private void setLayer(int i) {
            this.layer_ = i;
        }

        private void setPackets(int i) {
            this.packets_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AnalyticsVideoLayer();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u0004\u0002\u000b\u0003\u0003\u0004\u000b", new Object[]{ap.a(1428437062), ap.a(1412795043), ap.a(583881511), ap.a(1676561936)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AnalyticsVideoLayer> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AnalyticsVideoLayer.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getBytes() {
            return this.bytes_;
        }

        public int getFrames() {
            return this.frames_;
        }

        public int getLayer() {
            return this.layer_;
        }

        public int getPackets() {
            return this.packets_;
        }

        public static Builder newBuilder(AnalyticsVideoLayer analyticsVideoLayer) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(analyticsVideoLayer);
        }

        public static AnalyticsVideoLayer parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsVideoLayer parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AnalyticsVideoLayer parseFrom(ByteString byteString) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AnalyticsVideoLayer parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AnalyticsVideoLayer parseFrom(byte[] bArr) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AnalyticsVideoLayer parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AnalyticsVideoLayer parseFrom(InputStream inputStream) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AnalyticsVideoLayer parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AnalyticsVideoLayer parseFrom(CodedInputStream codedInputStream) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AnalyticsVideoLayer parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AnalyticsVideoLayer) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AnalyticsVideoLayerOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class FeatureUsageInfo extends GeneratedMessageLite<FeatureUsageInfo, Builder> implements FeatureUsageInfoOrBuilder {
        private static final FeatureUsageInfo DEFAULT_INSTANCE;
        public static final int FEATURE_FIELD_NUMBER = 1;
        private static volatile Parser<FeatureUsageInfo> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 5;
        public static final int PARTICIPANT_ID_FIELD_NUMBER = 6;
        public static final int PROJECT_ID_FIELD_NUMBER = 2;
        public static final int ROOM_ID_FIELD_NUMBER = 4;
        public static final int ROOM_NAME_FIELD_NUMBER = 3;
        public static final int TIME_RANGES_FIELD_NUMBER = 8;
        public static final int TRACK_ID_FIELD_NUMBER = 7;
        private int feature_;
        private String participantId_;
        private String participantIdentity_;
        private String projectId_;
        private String roomId_;
        private String roomName_;
        private Internal.ProtobufList<TimeRange> timeRanges_;
        private String trackId_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<FeatureUsageInfo, Builder> implements FeatureUsageInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(FeatureUsageInfo.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum Feature implements Internal.EnumLite {
            b(0),
            c(1),
            d(-1);

            private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<Feature>() { // from class: livekit.LivekitAnalytics.FeatureUsageInfo.Feature.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public Feature findValueByNumber(int i) {
                    return Feature.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class FeatureVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new FeatureVerifier();

                private FeatureVerifier() {
                }

                public boolean isInRange(int i) {
                    return Feature.b(i) != null;
                }
            }

            Feature(int i) {
                this.a = i;
            }

            public static Feature b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i != 1) {
                    return null;
                }
                return c;
            }

            public final int getNumber() {
                if (this != d) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        static {
            FeatureUsageInfo featureUsageInfo = new FeatureUsageInfo();
            DEFAULT_INSTANCE = featureUsageInfo;
            GeneratedMessageLite.registerDefaultInstance(FeatureUsageInfo.class, featureUsageInfo);
        }

        private FeatureUsageInfo() {
            String strA = ap.a(19947449);
            this.projectId_ = strA;
            this.roomName_ = strA;
            this.roomId_ = strA;
            this.participantIdentity_ = strA;
            this.participantId_ = strA;
            this.trackId_ = strA;
            this.timeRanges_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllTimeRanges(Iterable<? extends TimeRange> iterable) {
            ensureTimeRangesIsMutable();
            AbstractMessageLite.addAll(iterable, this.timeRanges_);
        }

        private void addTimeRanges(TimeRange timeRange) {
            timeRange.getClass();
            ensureTimeRangesIsMutable();
            this.timeRanges_.add(timeRange);
        }

        private void clearFeature() {
            this.feature_ = 0;
        }

        private void clearParticipantId() {
            this.participantId_ = getDefaultInstance().getParticipantId();
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearProjectId() {
            this.projectId_ = getDefaultInstance().getProjectId();
        }

        private void clearRoomId() {
            this.roomId_ = getDefaultInstance().getRoomId();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearTimeRanges() {
            this.timeRanges_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearTrackId() {
            this.trackId_ = getDefaultInstance().getTrackId();
        }

        private void ensureTimeRangesIsMutable() {
            Internal.ProtobufList<TimeRange> protobufList = this.timeRanges_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.timeRanges_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static FeatureUsageInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static FeatureUsageInfo parseDelimitedFrom(InputStream inputStream) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static FeatureUsageInfo parseFrom(ByteBuffer byteBuffer) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<FeatureUsageInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeTimeRanges(int i) {
            ensureTimeRangesIsMutable();
            this.timeRanges_.remove(i);
        }

        private void setFeature(Feature feature) {
            this.feature_ = feature.getNumber();
        }

        private void setFeatureValue(int i) {
            this.feature_ = i;
        }

        private void setParticipantId(String str) {
            str.getClass();
            this.participantId_ = str;
        }

        private void setParticipantIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantId_ = byteString.L();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setProjectId(String str) {
            str.getClass();
            this.projectId_ = str;
        }

        private void setProjectIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.projectId_ = byteString.L();
        }

        private void setRoomId(String str) {
            str.getClass();
            this.roomId_ = str;
        }

        private void setRoomIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomId_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setTimeRanges(int i, TimeRange timeRange) {
            timeRange.getClass();
            ensureTimeRangesIsMutable();
            this.timeRanges_.set(i, timeRange);
        }

        private void setTrackId(String str) {
            str.getClass();
            this.trackId_ = str;
        }

        private void setTrackIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new FeatureUsageInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\b\u0000\u0000\u0001\b\b\u0000\u0001\u0000\u0001\f\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005Ȉ\u0006Ȉ\u0007Ȉ\b\u001b", new Object[]{"feature_", "projectId_", "roomName_", "roomId_", "participantIdentity_", "participantId_", "trackId_", "timeRanges_", TimeRange.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<FeatureUsageInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (FeatureUsageInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Feature getFeature() {
            Feature featureB = Feature.b(this.feature_);
            return featureB == null ? Feature.d : featureB;
        }

        public int getFeatureValue() {
            return this.feature_;
        }

        public String getParticipantId() {
            return this.participantId_;
        }

        public ByteString getParticipantIdBytes() {
            return ByteString.n(this.participantId_);
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getProjectId() {
            return this.projectId_;
        }

        public ByteString getProjectIdBytes() {
            return ByteString.n(this.projectId_);
        }

        public String getRoomId() {
            return this.roomId_;
        }

        public ByteString getRoomIdBytes() {
            return ByteString.n(this.roomId_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public TimeRange getTimeRanges(int i) {
            return (TimeRange) this.timeRanges_.get(i);
        }

        public int getTimeRangesCount() {
            return this.timeRanges_.size();
        }

        public List<TimeRange> getTimeRangesList() {
            return this.timeRanges_;
        }

        public TimeRangeOrBuilder getTimeRangesOrBuilder(int i) {
            return (TimeRangeOrBuilder) this.timeRanges_.get(i);
        }

        public List<? extends TimeRangeOrBuilder> getTimeRangesOrBuilderList() {
            return this.timeRanges_;
        }

        public String getTrackId() {
            return this.trackId_;
        }

        public ByteString getTrackIdBytes() {
            return ByteString.n(this.trackId_);
        }

        public static Builder newBuilder(FeatureUsageInfo featureUsageInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(featureUsageInfo);
        }

        public static FeatureUsageInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static FeatureUsageInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static FeatureUsageInfo parseFrom(ByteString byteString) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addTimeRanges(int i, TimeRange timeRange) {
            timeRange.getClass();
            ensureTimeRangesIsMutable();
            this.timeRanges_.add(i, timeRange);
        }

        public static FeatureUsageInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static FeatureUsageInfo parseFrom(byte[] bArr) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static FeatureUsageInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static FeatureUsageInfo parseFrom(InputStream inputStream) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static FeatureUsageInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static FeatureUsageInfo parseFrom(CodedInputStream codedInputStream) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static FeatureUsageInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (FeatureUsageInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface FeatureUsageInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ReportInfo extends GeneratedMessageLite<ReportInfo, Builder> implements ReportInfoOrBuilder {
        private static final ReportInfo DEFAULT_INSTANCE;
        public static final int FEATURE_USAGE_FIELD_NUMBER = 1;
        private static volatile Parser<ReportInfo> PARSER;
        private int messageCase_ = 0;
        private Object message_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ReportInfo, Builder> implements ReportInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ReportInfo.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum MessageCase {
            b(1),
            c(0);

            private final int a;

            MessageCase(int i) {
                this.a = i;
            }

            public static MessageCase b(int i) {
                if (i == 0) {
                    return c;
                }
                if (i != 1) {
                    return null;
                }
                return b;
            }
        }

        static {
            ReportInfo reportInfo = new ReportInfo();
            DEFAULT_INSTANCE = reportInfo;
            GeneratedMessageLite.registerDefaultInstance(ReportInfo.class, reportInfo);
        }

        private ReportInfo() {
        }

        private void clearFeatureUsage() {
            if (this.messageCase_ == 1) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearMessage() {
            this.messageCase_ = 0;
            this.message_ = null;
        }

        public static ReportInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeFeatureUsage(FeatureUsageInfo featureUsageInfo) {
            featureUsageInfo.getClass();
            if (this.messageCase_ != 1 || this.message_ == FeatureUsageInfo.getDefaultInstance()) {
                this.message_ = featureUsageInfo;
            } else {
                this.message_ = ((FeatureUsageInfo.Builder) FeatureUsageInfo.newBuilder((FeatureUsageInfo) this.message_).v(featureUsageInfo)).o();
            }
            this.messageCase_ = 1;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ReportInfo parseDelimitedFrom(InputStream inputStream) {
            return (ReportInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ReportInfo parseFrom(ByteBuffer byteBuffer) {
            return (ReportInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ReportInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setFeatureUsage(FeatureUsageInfo featureUsageInfo) {
            featureUsageInfo.getClass();
            this.message_ = featureUsageInfo;
            this.messageCase_ = 1;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ReportInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0001\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001<\u0000", new Object[]{ap.a(2027847155), ap.a(697753568), FeatureUsageInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ReportInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ReportInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public FeatureUsageInfo getFeatureUsage() {
            return this.messageCase_ == 1 ? (FeatureUsageInfo) this.message_ : FeatureUsageInfo.getDefaultInstance();
        }

        public MessageCase getMessageCase() {
            return MessageCase.b(this.messageCase_);
        }

        public boolean hasFeatureUsage() {
            return this.messageCase_ == 1;
        }

        public static Builder newBuilder(ReportInfo reportInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(reportInfo);
        }

        public static ReportInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReportInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ReportInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ReportInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ReportInfo parseFrom(ByteString byteString) {
            return (ReportInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ReportInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ReportInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ReportInfo parseFrom(byte[] bArr) {
            return (ReportInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ReportInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ReportInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ReportInfo parseFrom(InputStream inputStream) {
            return (ReportInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ReportInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReportInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ReportInfo parseFrom(CodedInputStream codedInputStream) {
            return (ReportInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ReportInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ReportInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ReportInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum StreamType implements Internal.EnumLite {
        b(0),
        c(1),
        d(-1);

        private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<StreamType>() { // from class: livekit.LivekitAnalytics.StreamType.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public StreamType findValueByNumber(int i) {
                return StreamType.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class StreamTypeVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new StreamTypeVerifier();

            private StreamTypeVerifier() {
            }

            public boolean isInRange(int i) {
                return StreamType.b(i) != null;
            }
        }

        StreamType(int i) {
            this.a = i;
        }

        public static StreamType b(int i) {
            if (i == 0) {
                return b;
            }
            if (i != 1) {
                return null;
            }
            return c;
        }

        public final int getNumber() {
            if (this != d) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TimeRange extends GeneratedMessageLite<TimeRange, Builder> implements TimeRangeOrBuilder {
        private static final TimeRange DEFAULT_INSTANCE;
        public static final int ENDED_AT_FIELD_NUMBER = 2;
        private static volatile Parser<TimeRange> PARSER = null;
        public static final int STARTED_AT_FIELD_NUMBER = 1;
        private Timestamp endedAt_;
        private Timestamp startedAt_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TimeRange, Builder> implements TimeRangeOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TimeRange.DEFAULT_INSTANCE);
            }
        }

        static {
            TimeRange timeRange = new TimeRange();
            DEFAULT_INSTANCE = timeRange;
            GeneratedMessageLite.registerDefaultInstance(TimeRange.class, timeRange);
        }

        private TimeRange() {
        }

        private void clearEndedAt() {
            this.endedAt_ = null;
        }

        private void clearStartedAt() {
            this.startedAt_ = null;
        }

        public static TimeRange getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeEndedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.endedAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.endedAt_ = timestamp;
            } else {
                this.endedAt_ = Timestamp.newBuilder(this.endedAt_).v(timestamp).o();
            }
        }

        private void mergeStartedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.startedAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.startedAt_ = timestamp;
            } else {
                this.startedAt_ = Timestamp.newBuilder(this.startedAt_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TimeRange parseDelimitedFrom(InputStream inputStream) {
            return (TimeRange) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TimeRange parseFrom(ByteBuffer byteBuffer) {
            return (TimeRange) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TimeRange> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setEndedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.endedAt_ = timestamp;
        }

        private void setStartedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.startedAt_ = timestamp;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TimeRange();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\t\u0002\t", new Object[]{ap.a(220679667), ap.a(382763794)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TimeRange> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TimeRange.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Timestamp getEndedAt() {
            Timestamp timestamp = this.endedAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public Timestamp getStartedAt() {
            Timestamp timestamp = this.startedAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public boolean hasEndedAt() {
            return this.endedAt_ != null;
        }

        public boolean hasStartedAt() {
            return this.startedAt_ != null;
        }

        public static Builder newBuilder(TimeRange timeRange) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(timeRange);
        }

        public static TimeRange parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeRange) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TimeRange parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeRange) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TimeRange parseFrom(ByteString byteString) {
            return (TimeRange) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TimeRange parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeRange) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TimeRange parseFrom(byte[] bArr) {
            return (TimeRange) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TimeRange parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeRange) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TimeRange parseFrom(InputStream inputStream) {
            return (TimeRange) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TimeRange parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeRange) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TimeRange parseFrom(CodedInputStream codedInputStream) {
            return (TimeRange) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TimeRange parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TimeRange) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TimeRangeOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class WebhookInfo extends GeneratedMessageLite<WebhookInfo, Builder> implements WebhookInfoOrBuilder {
        public static final int CREATED_AT_FIELD_NUMBER = 11;
        private static final WebhookInfo DEFAULT_INSTANCE;
        public static final int EGRESS_ID_FIELD_NUMBER = 9;
        public static final int EVENT_FIELD_NUMBER = 2;
        public static final int EVENT_ID_FIELD_NUMBER = 1;
        public static final int INGRESS_ID_FIELD_NUMBER = 10;
        public static final int IS_DROPPED_FIELD_NUMBER = 18;
        public static final int NUM_DROPPED_FIELD_NUMBER = 17;
        private static volatile Parser<WebhookInfo> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 6;
        public static final int PARTICIPANT_ID_FIELD_NUMBER = 7;
        public static final int PROJECT_ID_FIELD_NUMBER = 3;
        public static final int QUEUED_AT_FIELD_NUMBER = 12;
        public static final int QUEUE_DURATION_NS_FIELD_NUMBER = 13;
        public static final int ROOM_ID_FIELD_NUMBER = 5;
        public static final int ROOM_NAME_FIELD_NUMBER = 4;
        public static final int SEND_DURATION_NS_FIELD_NUMBER = 15;
        public static final int SEND_ERROR_FIELD_NUMBER = 22;
        public static final int SENT_AT_FIELD_NUMBER = 14;
        public static final int SERVICE_ERROR_CODE_FIELD_NUMBER = 20;
        public static final int SERVICE_ERROR_FIELD_NUMBER = 21;
        public static final int SERVICE_STATUS_FIELD_NUMBER = 19;
        public static final int TRACK_ID_FIELD_NUMBER = 8;
        public static final int URL_FIELD_NUMBER = 16;
        private Timestamp createdAt_;
        private String egressId_;
        private String eventId_;
        private String event_;
        private String ingressId_;
        private boolean isDropped_;
        private int numDropped_;
        private String participantId_;
        private String participantIdentity_;
        private String projectId_;
        private long queueDurationNs_;
        private Timestamp queuedAt_;
        private String roomId_;
        private String roomName_;
        private long sendDurationNs_;
        private String sendError_;
        private Timestamp sentAt_;
        private int serviceErrorCode_;
        private String serviceError_;
        private String serviceStatus_;
        private String trackId_;
        private String url_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<WebhookInfo, Builder> implements WebhookInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(WebhookInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            WebhookInfo webhookInfo = new WebhookInfo();
            DEFAULT_INSTANCE = webhookInfo;
            GeneratedMessageLite.registerDefaultInstance(WebhookInfo.class, webhookInfo);
        }

        private WebhookInfo() {
            String strA = ap.a(1801126453);
            this.eventId_ = strA;
            this.event_ = strA;
            this.projectId_ = strA;
            this.roomName_ = strA;
            this.roomId_ = strA;
            this.participantIdentity_ = strA;
            this.participantId_ = strA;
            this.trackId_ = strA;
            this.egressId_ = strA;
            this.ingressId_ = strA;
            this.url_ = strA;
            this.serviceStatus_ = strA;
            this.serviceError_ = strA;
            this.sendError_ = strA;
        }

        private void clearCreatedAt() {
            this.createdAt_ = null;
        }

        private void clearEgressId() {
            this.egressId_ = getDefaultInstance().getEgressId();
        }

        private void clearEvent() {
            this.event_ = getDefaultInstance().getEvent();
        }

        private void clearEventId() {
            this.eventId_ = getDefaultInstance().getEventId();
        }

        private void clearIngressId() {
            this.ingressId_ = getDefaultInstance().getIngressId();
        }

        private void clearIsDropped() {
            this.isDropped_ = false;
        }

        private void clearNumDropped() {
            this.numDropped_ = 0;
        }

        private void clearParticipantId() {
            this.participantId_ = getDefaultInstance().getParticipantId();
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearProjectId() {
            this.projectId_ = getDefaultInstance().getProjectId();
        }

        private void clearQueueDurationNs() {
            this.queueDurationNs_ = 0L;
        }

        private void clearQueuedAt() {
            this.queuedAt_ = null;
        }

        private void clearRoomId() {
            this.roomId_ = getDefaultInstance().getRoomId();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearSendDurationNs() {
            this.sendDurationNs_ = 0L;
        }

        private void clearSendError() {
            this.sendError_ = getDefaultInstance().getSendError();
        }

        private void clearSentAt() {
            this.sentAt_ = null;
        }

        private void clearServiceError() {
            this.serviceError_ = getDefaultInstance().getServiceError();
        }

        private void clearServiceErrorCode() {
            this.serviceErrorCode_ = 0;
        }

        private void clearServiceStatus() {
            this.serviceStatus_ = getDefaultInstance().getServiceStatus();
        }

        private void clearTrackId() {
            this.trackId_ = getDefaultInstance().getTrackId();
        }

        private void clearUrl() {
            this.url_ = getDefaultInstance().getUrl();
        }

        public static WebhookInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeCreatedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.createdAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.createdAt_ = timestamp;
            } else {
                this.createdAt_ = Timestamp.newBuilder(this.createdAt_).v(timestamp).o();
            }
        }

        private void mergeQueuedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.queuedAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.queuedAt_ = timestamp;
            } else {
                this.queuedAt_ = Timestamp.newBuilder(this.queuedAt_).v(timestamp).o();
            }
        }

        private void mergeSentAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.sentAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.sentAt_ = timestamp;
            } else {
                this.sentAt_ = Timestamp.newBuilder(this.sentAt_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static WebhookInfo parseDelimitedFrom(InputStream inputStream) {
            return (WebhookInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WebhookInfo parseFrom(ByteBuffer byteBuffer) {
            return (WebhookInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<WebhookInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCreatedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.createdAt_ = timestamp;
        }

        private void setEgressId(String str) {
            str.getClass();
            this.egressId_ = str;
        }

        private void setEgressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.egressId_ = byteString.L();
        }

        private void setEvent(String str) {
            str.getClass();
            this.event_ = str;
        }

        private void setEventBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.event_ = byteString.L();
        }

        private void setEventId(String str) {
            str.getClass();
            this.eventId_ = str;
        }

        private void setEventIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.eventId_ = byteString.L();
        }

        private void setIngressId(String str) {
            str.getClass();
            this.ingressId_ = str;
        }

        private void setIngressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.ingressId_ = byteString.L();
        }

        private void setIsDropped(boolean z) {
            this.isDropped_ = z;
        }

        private void setNumDropped(int i) {
            this.numDropped_ = i;
        }

        private void setParticipantId(String str) {
            str.getClass();
            this.participantId_ = str;
        }

        private void setParticipantIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantId_ = byteString.L();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setProjectId(String str) {
            str.getClass();
            this.projectId_ = str;
        }

        private void setProjectIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.projectId_ = byteString.L();
        }

        private void setQueueDurationNs(long j) {
            this.queueDurationNs_ = j;
        }

        private void setQueuedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.queuedAt_ = timestamp;
        }

        private void setRoomId(String str) {
            str.getClass();
            this.roomId_ = str;
        }

        private void setRoomIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomId_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setSendDurationNs(long j) {
            this.sendDurationNs_ = j;
        }

        private void setSendError(String str) {
            str.getClass();
            this.sendError_ = str;
        }

        private void setSendErrorBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sendError_ = byteString.L();
        }

        private void setSentAt(Timestamp timestamp) {
            timestamp.getClass();
            this.sentAt_ = timestamp;
        }

        private void setServiceError(String str) {
            str.getClass();
            this.serviceError_ = str;
        }

        private void setServiceErrorBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.serviceError_ = byteString.L();
        }

        private void setServiceErrorCode(int i) {
            this.serviceErrorCode_ = i;
        }

        private void setServiceStatus(String str) {
            str.getClass();
            this.serviceStatus_ = str;
        }

        private void setServiceStatusBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.serviceStatus_ = byteString.L();
        }

        private void setTrackId(String str) {
            str.getClass();
            this.trackId_ = str;
        }

        private void setTrackIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackId_ = byteString.L();
        }

        private void setUrl(String str) {
            str.getClass();
            this.url_ = str;
        }

        private void setUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.url_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new WebhookInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0016\u0000\u0000\u0001\u0016\u0016\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005Ȉ\u0006Ȉ\u0007Ȉ\bȈ\tȈ\nȈ\u000b\t\f\t\r\u0002\u000e\t\u000f\u0002\u0010Ȉ\u0011\u0004\u0012\u0007\u0013Ȉ\u0014\u0004\u0015Ȉ\u0016Ȉ", new Object[]{"eventId_", "event_", "projectId_", "roomName_", "roomId_", "participantIdentity_", "participantId_", "trackId_", "egressId_", "ingressId_", "createdAt_", "queuedAt_", "queueDurationNs_", "sentAt_", "sendDurationNs_", "url_", "numDropped_", "isDropped_", "serviceStatus_", "serviceErrorCode_", "serviceError_", "sendError_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<WebhookInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (WebhookInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Timestamp getCreatedAt() {
            Timestamp timestamp = this.createdAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public String getEgressId() {
            return this.egressId_;
        }

        public ByteString getEgressIdBytes() {
            return ByteString.n(this.egressId_);
        }

        public String getEvent() {
            return this.event_;
        }

        public ByteString getEventBytes() {
            return ByteString.n(this.event_);
        }

        public String getEventId() {
            return this.eventId_;
        }

        public ByteString getEventIdBytes() {
            return ByteString.n(this.eventId_);
        }

        public String getIngressId() {
            return this.ingressId_;
        }

        public ByteString getIngressIdBytes() {
            return ByteString.n(this.ingressId_);
        }

        public boolean getIsDropped() {
            return this.isDropped_;
        }

        public int getNumDropped() {
            return this.numDropped_;
        }

        public String getParticipantId() {
            return this.participantId_;
        }

        public ByteString getParticipantIdBytes() {
            return ByteString.n(this.participantId_);
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getProjectId() {
            return this.projectId_;
        }

        public ByteString getProjectIdBytes() {
            return ByteString.n(this.projectId_);
        }

        public long getQueueDurationNs() {
            return this.queueDurationNs_;
        }

        public Timestamp getQueuedAt() {
            Timestamp timestamp = this.queuedAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public String getRoomId() {
            return this.roomId_;
        }

        public ByteString getRoomIdBytes() {
            return ByteString.n(this.roomId_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public long getSendDurationNs() {
            return this.sendDurationNs_;
        }

        public String getSendError() {
            return this.sendError_;
        }

        public ByteString getSendErrorBytes() {
            return ByteString.n(this.sendError_);
        }

        public Timestamp getSentAt() {
            Timestamp timestamp = this.sentAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public String getServiceError() {
            return this.serviceError_;
        }

        public ByteString getServiceErrorBytes() {
            return ByteString.n(this.serviceError_);
        }

        public int getServiceErrorCode() {
            return this.serviceErrorCode_;
        }

        public String getServiceStatus() {
            return this.serviceStatus_;
        }

        public ByteString getServiceStatusBytes() {
            return ByteString.n(this.serviceStatus_);
        }

        public String getTrackId() {
            return this.trackId_;
        }

        public ByteString getTrackIdBytes() {
            return ByteString.n(this.trackId_);
        }

        public String getUrl() {
            return this.url_;
        }

        public ByteString getUrlBytes() {
            return ByteString.n(this.url_);
        }

        public boolean hasCreatedAt() {
            return this.createdAt_ != null;
        }

        public boolean hasQueuedAt() {
            return this.queuedAt_ != null;
        }

        public boolean hasSentAt() {
            return this.sentAt_ != null;
        }

        public static Builder newBuilder(WebhookInfo webhookInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(webhookInfo);
        }

        public static WebhookInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WebhookInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static WebhookInfo parseFrom(ByteString byteString) {
            return (WebhookInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static WebhookInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static WebhookInfo parseFrom(byte[] bArr) {
            return (WebhookInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static WebhookInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static WebhookInfo parseFrom(InputStream inputStream) {
            return (WebhookInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WebhookInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WebhookInfo parseFrom(CodedInputStream codedInputStream) {
            return (WebhookInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static WebhookInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface WebhookInfoOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitAnalytics() {
    }
}