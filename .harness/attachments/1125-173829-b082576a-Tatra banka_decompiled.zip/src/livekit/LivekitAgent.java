package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MapEntryLite;
import com.google.protobuf.MapFieldLite;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import com.google.protobuf.WireFormat;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import livekit.LivekitModels;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitAgent {

    /* JADX INFO: renamed from: livekit.LivekitAgent$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AvailabilityRequest extends GeneratedMessageLite<AvailabilityRequest, Builder> implements AvailabilityRequestOrBuilder {
        private static final AvailabilityRequest DEFAULT_INSTANCE;
        public static final int JOB_FIELD_NUMBER = 1;
        private static volatile Parser<AvailabilityRequest> PARSER = null;
        public static final int RESUMING_FIELD_NUMBER = 2;
        private Job job_;
        private boolean resuming_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AvailabilityRequest, Builder> implements AvailabilityRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AvailabilityRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            AvailabilityRequest availabilityRequest = new AvailabilityRequest();
            DEFAULT_INSTANCE = availabilityRequest;
            GeneratedMessageLite.registerDefaultInstance(AvailabilityRequest.class, availabilityRequest);
        }

        private AvailabilityRequest() {
        }

        private void clearJob() {
            this.job_ = null;
        }

        private void clearResuming() {
            this.resuming_ = false;
        }

        public static AvailabilityRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeJob(Job job) {
            job.getClass();
            Job job2 = this.job_;
            if (job2 == null || job2 == Job.getDefaultInstance()) {
                this.job_ = job;
            } else {
                this.job_ = (Job) ((Job.Builder) Job.newBuilder(this.job_).v(job)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AvailabilityRequest parseDelimitedFrom(InputStream inputStream) {
            return (AvailabilityRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AvailabilityRequest parseFrom(ByteBuffer byteBuffer) {
            return (AvailabilityRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AvailabilityRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setJob(Job job) {
            job.getClass();
            this.job_ = job;
        }

        private void setResuming(boolean z) {
            this.resuming_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AvailabilityRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\t\u0002\u0007", new Object[]{ap.a(1082121549), ap.a(966634376)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AvailabilityRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AvailabilityRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Job getJob() {
            Job job = this.job_;
            return job == null ? Job.getDefaultInstance() : job;
        }

        public boolean getResuming() {
            return this.resuming_;
        }

        public boolean hasJob() {
            return this.job_ != null;
        }

        public static Builder newBuilder(AvailabilityRequest availabilityRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(availabilityRequest);
        }

        public static AvailabilityRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AvailabilityRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AvailabilityRequest parseFrom(ByteString byteString) {
            return (AvailabilityRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AvailabilityRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AvailabilityRequest parseFrom(byte[] bArr) {
            return (AvailabilityRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AvailabilityRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AvailabilityRequest parseFrom(InputStream inputStream) {
            return (AvailabilityRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AvailabilityRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AvailabilityRequest parseFrom(CodedInputStream codedInputStream) {
            return (AvailabilityRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AvailabilityRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AvailabilityRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AvailabilityResponse extends GeneratedMessageLite<AvailabilityResponse, Builder> implements AvailabilityResponseOrBuilder {
        public static final int AVAILABLE_FIELD_NUMBER = 2;
        private static final AvailabilityResponse DEFAULT_INSTANCE;
        public static final int JOB_ID_FIELD_NUMBER = 1;
        private static volatile Parser<AvailabilityResponse> PARSER = null;
        public static final int PARTICIPANT_ATTRIBUTES_FIELD_NUMBER = 7;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 5;
        public static final int PARTICIPANT_METADATA_FIELD_NUMBER = 6;
        public static final int PARTICIPANT_NAME_FIELD_NUMBER = 4;
        public static final int SUPPORTS_RESUME_FIELD_NUMBER = 3;
        public static final int TERMINATE_FIELD_NUMBER = 8;
        private boolean available_;
        private String jobId_;
        private MapFieldLite<String, String> participantAttributes_ = MapFieldLite.f();
        private String participantIdentity_;
        private String participantMetadata_;
        private String participantName_;
        private boolean supportsResume_;
        private boolean terminate_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AvailabilityResponse, Builder> implements AvailabilityResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AvailabilityResponse.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class ParticipantAttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(582582119);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private ParticipantAttributesDefaultEntryHolder() {
            }
        }

        static {
            AvailabilityResponse availabilityResponse = new AvailabilityResponse();
            DEFAULT_INSTANCE = availabilityResponse;
            GeneratedMessageLite.registerDefaultInstance(AvailabilityResponse.class, availabilityResponse);
        }

        private AvailabilityResponse() {
            String strA = ap.a(1813799767);
            this.jobId_ = strA;
            this.participantName_ = strA;
            this.participantIdentity_ = strA;
            this.participantMetadata_ = strA;
        }

        private void clearAvailable() {
            this.available_ = false;
        }

        private void clearJobId() {
            this.jobId_ = getDefaultInstance().getJobId();
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearParticipantMetadata() {
            this.participantMetadata_ = getDefaultInstance().getParticipantMetadata();
        }

        private void clearParticipantName() {
            this.participantName_ = getDefaultInstance().getParticipantName();
        }

        private void clearSupportsResume() {
            this.supportsResume_ = false;
        }

        private void clearTerminate() {
            this.terminate_ = false;
        }

        public static AvailabilityResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableParticipantAttributesMap() {
            return internalGetMutableParticipantAttributes();
        }

        private MapFieldLite<String, String> internalGetMutableParticipantAttributes() {
            if (!this.participantAttributes_.k()) {
                this.participantAttributes_ = this.participantAttributes_.n();
            }
            return this.participantAttributes_;
        }

        private MapFieldLite<String, String> internalGetParticipantAttributes() {
            return this.participantAttributes_;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AvailabilityResponse parseDelimitedFrom(InputStream inputStream) {
            return (AvailabilityResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AvailabilityResponse parseFrom(ByteBuffer byteBuffer) {
            return (AvailabilityResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AvailabilityResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAvailable(boolean z) {
            this.available_ = z;
        }

        private void setJobId(String str) {
            str.getClass();
            this.jobId_ = str;
        }

        private void setJobIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.jobId_ = byteString.L();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setParticipantMetadata(String str) {
            str.getClass();
            this.participantMetadata_ = str;
        }

        private void setParticipantMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantMetadata_ = byteString.L();
        }

        private void setParticipantName(String str) {
            str.getClass();
            this.participantName_ = str;
        }

        private void setParticipantNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantName_ = byteString.L();
        }

        private void setSupportsResume(boolean z) {
            this.supportsResume_ = z;
        }

        private void setTerminate(boolean z) {
            this.terminate_ = z;
        }

        public boolean containsParticipantAttributes(String str) {
            str.getClass();
            return internalGetParticipantAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AvailabilityResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\b\u0000\u0000\u0001\b\b\u0001\u0000\u0000\u0001Ȉ\u0002\u0007\u0003\u0007\u0004Ȉ\u0005Ȉ\u0006Ȉ\u00072\b\u0007", new Object[]{"jobId_", "available_", "supportsResume_", "participantName_", "participantIdentity_", "participantMetadata_", "participantAttributes_", ParticipantAttributesDefaultEntryHolder.a, "terminate_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AvailabilityResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AvailabilityResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getAvailable() {
            return this.available_;
        }

        public String getJobId() {
            return this.jobId_;
        }

        public ByteString getJobIdBytes() {
            return ByteString.n(this.jobId_);
        }

        @Deprecated
        public Map<String, String> getParticipantAttributes() {
            return getParticipantAttributesMap();
        }

        public int getParticipantAttributesCount() {
            return internalGetParticipantAttributes().size();
        }

        public Map<String, String> getParticipantAttributesMap() {
            return Collections.unmodifiableMap(internalGetParticipantAttributes());
        }

        public String getParticipantAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetParticipantAttributes = internalGetParticipantAttributes();
            return mapFieldLiteInternalGetParticipantAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetParticipantAttributes.get(str) : str2;
        }

        public String getParticipantAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetParticipantAttributes = internalGetParticipantAttributes();
            if (mapFieldLiteInternalGetParticipantAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetParticipantAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getParticipantMetadata() {
            return this.participantMetadata_;
        }

        public ByteString getParticipantMetadataBytes() {
            return ByteString.n(this.participantMetadata_);
        }

        public String getParticipantName() {
            return this.participantName_;
        }

        public ByteString getParticipantNameBytes() {
            return ByteString.n(this.participantName_);
        }

        public boolean getSupportsResume() {
            return this.supportsResume_;
        }

        public boolean getTerminate() {
            return this.terminate_;
        }

        public static Builder newBuilder(AvailabilityResponse availabilityResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(availabilityResponse);
        }

        public static AvailabilityResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AvailabilityResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AvailabilityResponse parseFrom(ByteString byteString) {
            return (AvailabilityResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AvailabilityResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AvailabilityResponse parseFrom(byte[] bArr) {
            return (AvailabilityResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AvailabilityResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AvailabilityResponse parseFrom(InputStream inputStream) {
            return (AvailabilityResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AvailabilityResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AvailabilityResponse parseFrom(CodedInputStream codedInputStream) {
            return (AvailabilityResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AvailabilityResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AvailabilityResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AvailabilityResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class Job extends GeneratedMessageLite<Job, Builder> implements JobOrBuilder {
        public static final int AGENT_NAME_FIELD_NUMBER = 7;
        private static final Job DEFAULT_INSTANCE;
        public static final int DISPATCH_ID_FIELD_NUMBER = 9;
        public static final int ID_FIELD_NUMBER = 1;
        public static final int METADATA_FIELD_NUMBER = 6;
        public static final int NAMESPACE_FIELD_NUMBER = 5;
        private static volatile Parser<Job> PARSER = null;
        public static final int PARTICIPANT_FIELD_NUMBER = 4;
        public static final int ROOM_FIELD_NUMBER = 3;
        public static final int STATE_FIELD_NUMBER = 8;
        public static final int TYPE_FIELD_NUMBER = 2;
        private String agentName_;
        private int bitField0_;
        private String dispatchId_;
        private String id_;
        private String metadata_;
        private String namespace_;
        private LivekitModels.ParticipantInfo participant_;
        private LivekitModels.Room room_;
        private JobState state_;
        private int type_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<Job, Builder> implements JobOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(Job.DEFAULT_INSTANCE);
            }
        }

        static {
            Job job = new Job();
            DEFAULT_INSTANCE = job;
            GeneratedMessageLite.registerDefaultInstance(Job.class, job);
        }

        private Job() {
            String strA = ap.a(1908167997);
            this.id_ = strA;
            this.dispatchId_ = strA;
            this.namespace_ = strA;
            this.metadata_ = strA;
            this.agentName_ = strA;
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearDispatchId() {
            this.dispatchId_ = getDefaultInstance().getDispatchId();
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearMetadata() {
            this.metadata_ = getDefaultInstance().getMetadata();
        }

        private void clearNamespace() {
            this.namespace_ = getDefaultInstance().getNamespace();
        }

        private void clearParticipant() {
            this.participant_ = null;
            this.bitField0_ &= -2;
        }

        private void clearRoom() {
            this.room_ = null;
        }

        private void clearState() {
            this.state_ = null;
        }

        private void clearType() {
            this.type_ = 0;
        }

        public static Job getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            LivekitModels.ParticipantInfo participantInfo2 = this.participant_;
            if (participantInfo2 == null || participantInfo2 == LivekitModels.ParticipantInfo.getDefaultInstance()) {
                this.participant_ = participantInfo;
            } else {
                this.participant_ = (LivekitModels.ParticipantInfo) ((LivekitModels.ParticipantInfo.Builder) LivekitModels.ParticipantInfo.newBuilder(this.participant_).v(participantInfo)).o();
            }
            this.bitField0_ |= 1;
        }

        private void mergeRoom(LivekitModels.Room room) {
            room.getClass();
            LivekitModels.Room room2 = this.room_;
            if (room2 == null || room2 == LivekitModels.Room.getDefaultInstance()) {
                this.room_ = room;
            } else {
                this.room_ = (LivekitModels.Room) ((LivekitModels.Room.Builder) LivekitModels.Room.newBuilder(this.room_).v(room)).o();
            }
        }

        private void mergeState(JobState jobState) {
            jobState.getClass();
            JobState jobState2 = this.state_;
            if (jobState2 == null || jobState2 == JobState.getDefaultInstance()) {
                this.state_ = jobState;
            } else {
                this.state_ = (JobState) ((JobState.Builder) JobState.newBuilder(this.state_).v(jobState)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static Job parseDelimitedFrom(InputStream inputStream) {
            return (Job) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Job parseFrom(ByteBuffer byteBuffer) {
            return (Job) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<Job> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setDispatchId(String str) {
            str.getClass();
            this.dispatchId_ = str;
        }

        private void setDispatchIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.dispatchId_ = byteString.L();
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setMetadata(String str) {
            str.getClass();
            this.metadata_ = str;
        }

        private void setMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.metadata_ = byteString.L();
        }

        private void setNamespace(String str) {
            str.getClass();
            this.namespace_ = str;
        }

        private void setNamespaceBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.namespace_ = byteString.L();
        }

        private void setParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            this.participant_ = participantInfo;
            this.bitField0_ |= 1;
        }

        private void setRoom(LivekitModels.Room room) {
            room.getClass();
            this.room_ = room;
        }

        private void setState(JobState jobState) {
            jobState.getClass();
            this.state_ = jobState;
        }

        private void setType(JobType jobType) {
            this.type_ = jobType.getNumber();
        }

        private void setTypeValue(int i) {
            this.type_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new Job();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\t\u0000\u0001\u0001\t\t\u0000\u0000\u0000\u0001Ȉ\u0002\f\u0003\t\u0004ဉ\u0000\u0005Ȉ\u0006Ȉ\u0007Ȉ\b\t\tȈ", new Object[]{"bitField0_", "id_", "type_", "room_", "participant_", "namespace_", "metadata_", "agentName_", "state_", "dispatchId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<Job> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (Job.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public String getDispatchId() {
            return this.dispatchId_;
        }

        public ByteString getDispatchIdBytes() {
            return ByteString.n(this.dispatchId_);
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public String getMetadata() {
            return this.metadata_;
        }

        public ByteString getMetadataBytes() {
            return ByteString.n(this.metadata_);
        }

        @Deprecated
        public String getNamespace() {
            return this.namespace_;
        }

        @Deprecated
        public ByteString getNamespaceBytes() {
            return ByteString.n(this.namespace_);
        }

        public LivekitModels.ParticipantInfo getParticipant() {
            LivekitModels.ParticipantInfo participantInfo = this.participant_;
            return participantInfo == null ? LivekitModels.ParticipantInfo.getDefaultInstance() : participantInfo;
        }

        public LivekitModels.Room getRoom() {
            LivekitModels.Room room = this.room_;
            return room == null ? LivekitModels.Room.getDefaultInstance() : room;
        }

        public JobState getState() {
            JobState jobState = this.state_;
            return jobState == null ? JobState.getDefaultInstance() : jobState;
        }

        public JobType getType() {
            JobType jobTypeB = JobType.b(this.type_);
            return jobTypeB == null ? JobType.e : jobTypeB;
        }

        public int getTypeValue() {
            return this.type_;
        }

        public boolean hasParticipant() {
            return (this.bitField0_ & 1) != 0;
        }

        public boolean hasRoom() {
            return this.room_ != null;
        }

        public boolean hasState() {
            return this.state_ != null;
        }

        public static Builder newBuilder(Job job) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(job);
        }

        public static Job parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Job) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Job parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (Job) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static Job parseFrom(ByteString byteString) {
            return (Job) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static Job parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (Job) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static Job parseFrom(byte[] bArr) {
            return (Job) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static Job parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (Job) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static Job parseFrom(InputStream inputStream) {
            return (Job) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static Job parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Job) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static Job parseFrom(CodedInputStream codedInputStream) {
            return (Job) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static Job parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (Job) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class JobAssignment extends GeneratedMessageLite<JobAssignment, Builder> implements JobAssignmentOrBuilder {
        private static final JobAssignment DEFAULT_INSTANCE;
        public static final int JOB_FIELD_NUMBER = 1;
        private static volatile Parser<JobAssignment> PARSER = null;
        public static final int TOKEN_FIELD_NUMBER = 3;
        public static final int URL_FIELD_NUMBER = 2;
        private int bitField0_;
        private Job job_;
        private String token_;
        private String url_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<JobAssignment, Builder> implements JobAssignmentOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(JobAssignment.DEFAULT_INSTANCE);
            }
        }

        static {
            JobAssignment jobAssignment = new JobAssignment();
            DEFAULT_INSTANCE = jobAssignment;
            GeneratedMessageLite.registerDefaultInstance(JobAssignment.class, jobAssignment);
        }

        private JobAssignment() {
            String strA = ap.a(1004285866);
            this.url_ = strA;
            this.token_ = strA;
        }

        private void clearJob() {
            this.job_ = null;
        }

        private void clearToken() {
            this.token_ = getDefaultInstance().getToken();
        }

        private void clearUrl() {
            this.bitField0_ &= -2;
            this.url_ = getDefaultInstance().getUrl();
        }

        public static JobAssignment getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeJob(Job job) {
            job.getClass();
            Job job2 = this.job_;
            if (job2 == null || job2 == Job.getDefaultInstance()) {
                this.job_ = job;
            } else {
                this.job_ = (Job) ((Job.Builder) Job.newBuilder(this.job_).v(job)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static JobAssignment parseDelimitedFrom(InputStream inputStream) {
            return (JobAssignment) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static JobAssignment parseFrom(ByteBuffer byteBuffer) {
            return (JobAssignment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<JobAssignment> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setJob(Job job) {
            job.getClass();
            this.job_ = job;
        }

        private void setToken(String str) {
            str.getClass();
            this.token_ = str;
        }

        private void setTokenBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.token_ = byteString.L();
        }

        private void setUrl(String str) {
            str.getClass();
            this.bitField0_ |= 1;
            this.url_ = str;
        }

        private void setUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.url_ = byteString.L();
            this.bitField0_ |= 1;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new JobAssignment();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0001\u0001\u0003\u0003\u0000\u0000\u0000\u0001\t\u0002ለ\u0000\u0003Ȉ", new Object[]{"bitField0_", "job_", "url_", "token_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<JobAssignment> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (JobAssignment.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Job getJob() {
            Job job = this.job_;
            return job == null ? Job.getDefaultInstance() : job;
        }

        public String getToken() {
            return this.token_;
        }

        public ByteString getTokenBytes() {
            return ByteString.n(this.token_);
        }

        public String getUrl() {
            return this.url_;
        }

        public ByteString getUrlBytes() {
            return ByteString.n(this.url_);
        }

        public boolean hasJob() {
            return this.job_ != null;
        }

        public boolean hasUrl() {
            return (this.bitField0_ & 1) != 0;
        }

        public static Builder newBuilder(JobAssignment jobAssignment) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(jobAssignment);
        }

        public static JobAssignment parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JobAssignment) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static JobAssignment parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (JobAssignment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static JobAssignment parseFrom(ByteString byteString) {
            return (JobAssignment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static JobAssignment parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (JobAssignment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static JobAssignment parseFrom(byte[] bArr) {
            return (JobAssignment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static JobAssignment parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (JobAssignment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static JobAssignment parseFrom(InputStream inputStream) {
            return (JobAssignment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static JobAssignment parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JobAssignment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static JobAssignment parseFrom(CodedInputStream codedInputStream) {
            return (JobAssignment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static JobAssignment parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JobAssignment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface JobAssignmentOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface JobOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class JobState extends GeneratedMessageLite<JobState, Builder> implements JobStateOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 8;
        private static final JobState DEFAULT_INSTANCE;
        public static final int ENDED_AT_FIELD_NUMBER = 4;
        public static final int ERROR_FIELD_NUMBER = 2;
        private static volatile Parser<JobState> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 6;
        public static final int STARTED_AT_FIELD_NUMBER = 3;
        public static final int STATUS_FIELD_NUMBER = 1;
        public static final int UPDATED_AT_FIELD_NUMBER = 5;
        public static final int WORKER_ID_FIELD_NUMBER = 7;
        private String agentId_;
        private long endedAt_;
        private String error_;
        private String participantIdentity_;
        private long startedAt_;
        private int status_;
        private long updatedAt_;
        private String workerId_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<JobState, Builder> implements JobStateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(JobState.DEFAULT_INSTANCE);
            }
        }

        static {
            JobState jobState = new JobState();
            DEFAULT_INSTANCE = jobState;
            GeneratedMessageLite.registerDefaultInstance(JobState.class, jobState);
        }

        private JobState() {
            String strA = ap.a(727797997);
            this.error_ = strA;
            this.participantIdentity_ = strA;
            this.workerId_ = strA;
            this.agentId_ = strA;
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearEndedAt() {
            this.endedAt_ = 0L;
        }

        private void clearError() {
            this.error_ = getDefaultInstance().getError();
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearStartedAt() {
            this.startedAt_ = 0L;
        }

        private void clearStatus() {
            this.status_ = 0;
        }

        private void clearUpdatedAt() {
            this.updatedAt_ = 0L;
        }

        private void clearWorkerId() {
            this.workerId_ = getDefaultInstance().getWorkerId();
        }

        public static JobState getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static JobState parseDelimitedFrom(InputStream inputStream) {
            return (JobState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static JobState parseFrom(ByteBuffer byteBuffer) {
            return (JobState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<JobState> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setEndedAt(long j) {
            this.endedAt_ = j;
        }

        private void setError(String str) {
            str.getClass();
            this.error_ = str;
        }

        private void setErrorBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.error_ = byteString.L();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setStartedAt(long j) {
            this.startedAt_ = j;
        }

        private void setStatus(JobStatus jobStatus) {
            this.status_ = jobStatus.getNumber();
        }

        private void setStatusValue(int i) {
            this.status_ = i;
        }

        private void setUpdatedAt(long j) {
            this.updatedAt_ = j;
        }

        private void setWorkerId(String str) {
            str.getClass();
            this.workerId_ = str;
        }

        private void setWorkerIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.workerId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new JobState();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\b\u0000\u0000\u0001\b\b\u0000\u0000\u0000\u0001\f\u0002Ȉ\u0003\u0002\u0004\u0002\u0005\u0002\u0006Ȉ\u0007Ȉ\bȈ", new Object[]{"status_", "error_", "startedAt_", "endedAt_", "updatedAt_", "participantIdentity_", "workerId_", "agentId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<JobState> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (JobState.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public long getEndedAt() {
            return this.endedAt_;
        }

        public String getError() {
            return this.error_;
        }

        public ByteString getErrorBytes() {
            return ByteString.n(this.error_);
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public long getStartedAt() {
            return this.startedAt_;
        }

        public JobStatus getStatus() {
            JobStatus jobStatusB = JobStatus.b(this.status_);
            return jobStatusB == null ? JobStatus.f : jobStatusB;
        }

        public int getStatusValue() {
            return this.status_;
        }

        public long getUpdatedAt() {
            return this.updatedAt_;
        }

        public String getWorkerId() {
            return this.workerId_;
        }

        public ByteString getWorkerIdBytes() {
            return ByteString.n(this.workerId_);
        }

        public static Builder newBuilder(JobState jobState) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(jobState);
        }

        public static JobState parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JobState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static JobState parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (JobState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static JobState parseFrom(ByteString byteString) {
            return (JobState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static JobState parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (JobState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static JobState parseFrom(byte[] bArr) {
            return (JobState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static JobState parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (JobState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static JobState parseFrom(InputStream inputStream) {
            return (JobState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static JobState parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JobState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static JobState parseFrom(CodedInputStream codedInputStream) {
            return (JobState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static JobState parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JobState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface JobStateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum JobStatus implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(-1);

        private static final Internal.EnumLiteMap g = new Internal.EnumLiteMap<JobStatus>() { // from class: livekit.LivekitAgent.JobStatus.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public JobStatus findValueByNumber(int i) {
                return JobStatus.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class JobStatusVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new JobStatusVerifier();

            private JobStatusVerifier() {
            }

            public boolean isInRange(int i) {
                return JobStatus.b(i) != null;
            }
        }

        JobStatus(int i) {
            this.a = i;
        }

        public static JobStatus b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i == 2) {
                return d;
            }
            if (i != 3) {
                return null;
            }
            return e;
        }

        public final int getNumber() {
            if (this != f) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class JobTermination extends GeneratedMessageLite<JobTermination, Builder> implements JobTerminationOrBuilder {
        private static final JobTermination DEFAULT_INSTANCE;
        public static final int JOB_ID_FIELD_NUMBER = 1;
        private static volatile Parser<JobTermination> PARSER;
        private String jobId_ = ap.a(256744633);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<JobTermination, Builder> implements JobTerminationOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(JobTermination.DEFAULT_INSTANCE);
            }
        }

        static {
            JobTermination jobTermination = new JobTermination();
            DEFAULT_INSTANCE = jobTermination;
            GeneratedMessageLite.registerDefaultInstance(JobTermination.class, jobTermination);
        }

        private JobTermination() {
        }

        private void clearJobId() {
            this.jobId_ = getDefaultInstance().getJobId();
        }

        public static JobTermination getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static JobTermination parseDelimitedFrom(InputStream inputStream) {
            return (JobTermination) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static JobTermination parseFrom(ByteBuffer byteBuffer) {
            return (JobTermination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<JobTermination> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setJobId(String str) {
            str.getClass();
            this.jobId_ = str;
        }

        private void setJobIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.jobId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new JobTermination();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"jobId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<JobTermination> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (JobTermination.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getJobId() {
            return this.jobId_;
        }

        public ByteString getJobIdBytes() {
            return ByteString.n(this.jobId_);
        }

        public static Builder newBuilder(JobTermination jobTermination) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(jobTermination);
        }

        public static JobTermination parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JobTermination) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static JobTermination parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (JobTermination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static JobTermination parseFrom(ByteString byteString) {
            return (JobTermination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static JobTermination parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (JobTermination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static JobTermination parseFrom(byte[] bArr) {
            return (JobTermination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static JobTermination parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (JobTermination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static JobTermination parseFrom(InputStream inputStream) {
            return (JobTermination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static JobTermination parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JobTermination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static JobTermination parseFrom(CodedInputStream codedInputStream) {
            return (JobTermination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static JobTermination parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (JobTermination) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface JobTerminationOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum JobType implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<JobType>() { // from class: livekit.LivekitAgent.JobType.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public JobType findValueByNumber(int i) {
                return JobType.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class JobTypeVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new JobTypeVerifier();

            private JobTypeVerifier() {
            }

            public boolean isInRange(int i) {
                return JobType.b(i) != null;
            }
        }

        JobType(int i) {
            this.a = i;
        }

        public static JobType b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class MigrateJobRequest extends GeneratedMessageLite<MigrateJobRequest, Builder> implements MigrateJobRequestOrBuilder {
        private static final MigrateJobRequest DEFAULT_INSTANCE;
        public static final int JOB_IDS_FIELD_NUMBER = 2;
        private static volatile Parser<MigrateJobRequest> PARSER;
        private Internal.ProtobufList<String> jobIds_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<MigrateJobRequest, Builder> implements MigrateJobRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(MigrateJobRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            MigrateJobRequest migrateJobRequest = new MigrateJobRequest();
            DEFAULT_INSTANCE = migrateJobRequest;
            GeneratedMessageLite.registerDefaultInstance(MigrateJobRequest.class, migrateJobRequest);
        }

        private MigrateJobRequest() {
        }

        private void addAllJobIds(Iterable<String> iterable) {
            ensureJobIdsIsMutable();
            AbstractMessageLite.addAll(iterable, this.jobIds_);
        }

        private void addJobIds(String str) {
            str.getClass();
            ensureJobIdsIsMutable();
            this.jobIds_.add(str);
        }

        private void addJobIdsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureJobIdsIsMutable();
            this.jobIds_.add(byteString.L());
        }

        private void clearJobIds() {
            this.jobIds_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureJobIdsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.jobIds_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.jobIds_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static MigrateJobRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static MigrateJobRequest parseDelimitedFrom(InputStream inputStream) {
            return (MigrateJobRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MigrateJobRequest parseFrom(ByteBuffer byteBuffer) {
            return (MigrateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<MigrateJobRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setJobIds(int i, String str) {
            str.getClass();
            ensureJobIdsIsMutable();
            this.jobIds_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new MigrateJobRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0002\u0002\u0001\u0000\u0001\u0000\u0002Ț", new Object[]{ap.a(1734857121)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<MigrateJobRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (MigrateJobRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getJobIds(int i) {
            return (String) this.jobIds_.get(i);
        }

        public ByteString getJobIdsBytes(int i) {
            return ByteString.n((String) this.jobIds_.get(i));
        }

        public int getJobIdsCount() {
            return this.jobIds_.size();
        }

        public List<String> getJobIdsList() {
            return this.jobIds_;
        }

        public static Builder newBuilder(MigrateJobRequest migrateJobRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(migrateJobRequest);
        }

        public static MigrateJobRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MigrateJobRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MigrateJobRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (MigrateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static MigrateJobRequest parseFrom(ByteString byteString) {
            return (MigrateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static MigrateJobRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (MigrateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static MigrateJobRequest parseFrom(byte[] bArr) {
            return (MigrateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static MigrateJobRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (MigrateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static MigrateJobRequest parseFrom(InputStream inputStream) {
            return (MigrateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static MigrateJobRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MigrateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static MigrateJobRequest parseFrom(CodedInputStream codedInputStream) {
            return (MigrateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static MigrateJobRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (MigrateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface MigrateJobRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RegisterWorkerRequest extends GeneratedMessageLite<RegisterWorkerRequest, Builder> implements RegisterWorkerRequestOrBuilder {
        public static final int AGENT_NAME_FIELD_NUMBER = 8;
        public static final int ALLOWED_PERMISSIONS_FIELD_NUMBER = 7;
        private static final RegisterWorkerRequest DEFAULT_INSTANCE;
        public static final int NAMESPACE_FIELD_NUMBER = 6;
        private static volatile Parser<RegisterWorkerRequest> PARSER = null;
        public static final int PING_INTERVAL_FIELD_NUMBER = 5;
        public static final int TYPE_FIELD_NUMBER = 1;
        public static final int VERSION_FIELD_NUMBER = 3;
        private String agentName_;
        private LivekitModels.ParticipantPermission allowedPermissions_;
        private int bitField0_;
        private String namespace_;
        private int pingInterval_;
        private int type_;
        private String version_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RegisterWorkerRequest, Builder> implements RegisterWorkerRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RegisterWorkerRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            RegisterWorkerRequest registerWorkerRequest = new RegisterWorkerRequest();
            DEFAULT_INSTANCE = registerWorkerRequest;
            GeneratedMessageLite.registerDefaultInstance(RegisterWorkerRequest.class, registerWorkerRequest);
        }

        private RegisterWorkerRequest() {
            String strA = ap.a(69043901);
            this.agentName_ = strA;
            this.version_ = strA;
            this.namespace_ = strA;
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearAllowedPermissions() {
            this.allowedPermissions_ = null;
        }

        private void clearNamespace() {
            this.bitField0_ &= -2;
            this.namespace_ = getDefaultInstance().getNamespace();
        }

        private void clearPingInterval() {
            this.pingInterval_ = 0;
        }

        private void clearType() {
            this.type_ = 0;
        }

        private void clearVersion() {
            this.version_ = getDefaultInstance().getVersion();
        }

        public static RegisterWorkerRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAllowedPermissions(LivekitModels.ParticipantPermission participantPermission) {
            participantPermission.getClass();
            LivekitModels.ParticipantPermission participantPermission2 = this.allowedPermissions_;
            if (participantPermission2 == null || participantPermission2 == LivekitModels.ParticipantPermission.getDefaultInstance()) {
                this.allowedPermissions_ = participantPermission;
            } else {
                this.allowedPermissions_ = (LivekitModels.ParticipantPermission) ((LivekitModels.ParticipantPermission.Builder) LivekitModels.ParticipantPermission.newBuilder(this.allowedPermissions_).v(participantPermission)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RegisterWorkerRequest parseDelimitedFrom(InputStream inputStream) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RegisterWorkerRequest parseFrom(ByteBuffer byteBuffer) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RegisterWorkerRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setAllowedPermissions(LivekitModels.ParticipantPermission participantPermission) {
            participantPermission.getClass();
            this.allowedPermissions_ = participantPermission;
        }

        private void setNamespace(String str) {
            str.getClass();
            this.bitField0_ |= 1;
            this.namespace_ = str;
        }

        private void setNamespaceBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.namespace_ = byteString.L();
            this.bitField0_ |= 1;
        }

        private void setPingInterval(int i) {
            this.pingInterval_ = i;
        }

        private void setType(JobType jobType) {
            this.type_ = jobType.getNumber();
        }

        private void setTypeValue(int i) {
            this.type_ = i;
        }

        private void setVersion(String str) {
            str.getClass();
            this.version_ = str;
        }

        private void setVersionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.version_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RegisterWorkerRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0001\u0001\b\u0006\u0000\u0000\u0000\u0001\f\u0003Ȉ\u0005\u000b\u0006ለ\u0000\u0007\t\bȈ", new Object[]{"bitField0_", "type_", "version_", "pingInterval_", "namespace_", "allowedPermissions_", "agentName_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RegisterWorkerRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RegisterWorkerRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public LivekitModels.ParticipantPermission getAllowedPermissions() {
            LivekitModels.ParticipantPermission participantPermission = this.allowedPermissions_;
            return participantPermission == null ? LivekitModels.ParticipantPermission.getDefaultInstance() : participantPermission;
        }

        public String getNamespace() {
            return this.namespace_;
        }

        public ByteString getNamespaceBytes() {
            return ByteString.n(this.namespace_);
        }

        public int getPingInterval() {
            return this.pingInterval_;
        }

        public JobType getType() {
            JobType jobTypeB = JobType.b(this.type_);
            return jobTypeB == null ? JobType.e : jobTypeB;
        }

        public int getTypeValue() {
            return this.type_;
        }

        public String getVersion() {
            return this.version_;
        }

        public ByteString getVersionBytes() {
            return ByteString.n(this.version_);
        }

        public boolean hasAllowedPermissions() {
            return this.allowedPermissions_ != null;
        }

        public boolean hasNamespace() {
            return (this.bitField0_ & 1) != 0;
        }

        public static Builder newBuilder(RegisterWorkerRequest registerWorkerRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(registerWorkerRequest);
        }

        public static RegisterWorkerRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RegisterWorkerRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RegisterWorkerRequest parseFrom(ByteString byteString) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RegisterWorkerRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RegisterWorkerRequest parseFrom(byte[] bArr) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RegisterWorkerRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RegisterWorkerRequest parseFrom(InputStream inputStream) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RegisterWorkerRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RegisterWorkerRequest parseFrom(CodedInputStream codedInputStream) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RegisterWorkerRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RegisterWorkerRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RegisterWorkerResponse extends GeneratedMessageLite<RegisterWorkerResponse, Builder> implements RegisterWorkerResponseOrBuilder {
        private static final RegisterWorkerResponse DEFAULT_INSTANCE;
        private static volatile Parser<RegisterWorkerResponse> PARSER = null;
        public static final int SERVER_INFO_FIELD_NUMBER = 3;
        public static final int WORKER_ID_FIELD_NUMBER = 1;
        private LivekitModels.ServerInfo serverInfo_;
        private String workerId_ = ap.a(1799381181);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RegisterWorkerResponse, Builder> implements RegisterWorkerResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RegisterWorkerResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            RegisterWorkerResponse registerWorkerResponse = new RegisterWorkerResponse();
            DEFAULT_INSTANCE = registerWorkerResponse;
            GeneratedMessageLite.registerDefaultInstance(RegisterWorkerResponse.class, registerWorkerResponse);
        }

        private RegisterWorkerResponse() {
        }

        private void clearServerInfo() {
            this.serverInfo_ = null;
        }

        private void clearWorkerId() {
            this.workerId_ = getDefaultInstance().getWorkerId();
        }

        public static RegisterWorkerResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeServerInfo(LivekitModels.ServerInfo serverInfo) {
            serverInfo.getClass();
            LivekitModels.ServerInfo serverInfo2 = this.serverInfo_;
            if (serverInfo2 == null || serverInfo2 == LivekitModels.ServerInfo.getDefaultInstance()) {
                this.serverInfo_ = serverInfo;
            } else {
                this.serverInfo_ = (LivekitModels.ServerInfo) ((LivekitModels.ServerInfo.Builder) LivekitModels.ServerInfo.newBuilder(this.serverInfo_).v(serverInfo)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RegisterWorkerResponse parseDelimitedFrom(InputStream inputStream) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RegisterWorkerResponse parseFrom(ByteBuffer byteBuffer) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RegisterWorkerResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setServerInfo(LivekitModels.ServerInfo serverInfo) {
            serverInfo.getClass();
            this.serverInfo_ = serverInfo;
        }

        private void setWorkerId(String str) {
            str.getClass();
            this.workerId_ = str;
        }

        private void setWorkerIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.workerId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RegisterWorkerResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0003\u0002\u0000\u0000\u0000\u0001Ȉ\u0003\t", new Object[]{"workerId_", "serverInfo_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RegisterWorkerResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RegisterWorkerResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.ServerInfo getServerInfo() {
            LivekitModels.ServerInfo serverInfo = this.serverInfo_;
            return serverInfo == null ? LivekitModels.ServerInfo.getDefaultInstance() : serverInfo;
        }

        public String getWorkerId() {
            return this.workerId_;
        }

        public ByteString getWorkerIdBytes() {
            return ByteString.n(this.workerId_);
        }

        public boolean hasServerInfo() {
            return this.serverInfo_ != null;
        }

        public static Builder newBuilder(RegisterWorkerResponse registerWorkerResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(registerWorkerResponse);
        }

        public static RegisterWorkerResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RegisterWorkerResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RegisterWorkerResponse parseFrom(ByteString byteString) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RegisterWorkerResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RegisterWorkerResponse parseFrom(byte[] bArr) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RegisterWorkerResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RegisterWorkerResponse parseFrom(InputStream inputStream) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RegisterWorkerResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RegisterWorkerResponse parseFrom(CodedInputStream codedInputStream) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RegisterWorkerResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RegisterWorkerResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RegisterWorkerResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ServerMessage extends GeneratedMessageLite<ServerMessage, Builder> implements ServerMessageOrBuilder {
        public static final int ASSIGNMENT_FIELD_NUMBER = 3;
        public static final int AVAILABILITY_FIELD_NUMBER = 2;
        private static final ServerMessage DEFAULT_INSTANCE;
        private static volatile Parser<ServerMessage> PARSER = null;
        public static final int PONG_FIELD_NUMBER = 4;
        public static final int REGISTER_FIELD_NUMBER = 1;
        public static final int TERMINATION_FIELD_NUMBER = 5;
        private int messageCase_ = 0;
        private Object message_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ServerMessage, Builder> implements ServerMessageOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ServerMessage.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum MessageCase {
            b(1),
            c(2),
            d(3),
            e(5),
            f(4),
            g(0);

            private final int a;

            MessageCase(int i) {
                this.a = i;
            }

            public static MessageCase b(int i) {
                if (i == 0) {
                    return g;
                }
                if (i == 1) {
                    return b;
                }
                if (i == 2) {
                    return c;
                }
                if (i == 3) {
                    return d;
                }
                if (i == 4) {
                    return f;
                }
                if (i != 5) {
                    return null;
                }
                return e;
            }
        }

        static {
            ServerMessage serverMessage = new ServerMessage();
            DEFAULT_INSTANCE = serverMessage;
            GeneratedMessageLite.registerDefaultInstance(ServerMessage.class, serverMessage);
        }

        private ServerMessage() {
        }

        private void clearAssignment() {
            if (this.messageCase_ == 3) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearAvailability() {
            if (this.messageCase_ == 2) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearMessage() {
            this.messageCase_ = 0;
            this.message_ = null;
        }

        private void clearPong() {
            if (this.messageCase_ == 4) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearRegister() {
            if (this.messageCase_ == 1) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearTermination() {
            if (this.messageCase_ == 5) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        public static ServerMessage getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAssignment(JobAssignment jobAssignment) {
            jobAssignment.getClass();
            if (this.messageCase_ != 3 || this.message_ == JobAssignment.getDefaultInstance()) {
                this.message_ = jobAssignment;
            } else {
                this.message_ = ((JobAssignment.Builder) JobAssignment.newBuilder((JobAssignment) this.message_).v(jobAssignment)).o();
            }
            this.messageCase_ = 3;
        }

        private void mergeAvailability(AvailabilityRequest availabilityRequest) {
            availabilityRequest.getClass();
            if (this.messageCase_ != 2 || this.message_ == AvailabilityRequest.getDefaultInstance()) {
                this.message_ = availabilityRequest;
            } else {
                this.message_ = ((AvailabilityRequest.Builder) AvailabilityRequest.newBuilder((AvailabilityRequest) this.message_).v(availabilityRequest)).o();
            }
            this.messageCase_ = 2;
        }

        private void mergePong(WorkerPong workerPong) {
            workerPong.getClass();
            if (this.messageCase_ != 4 || this.message_ == WorkerPong.getDefaultInstance()) {
                this.message_ = workerPong;
            } else {
                this.message_ = ((WorkerPong.Builder) WorkerPong.newBuilder((WorkerPong) this.message_).v(workerPong)).o();
            }
            this.messageCase_ = 4;
        }

        private void mergeRegister(RegisterWorkerResponse registerWorkerResponse) {
            registerWorkerResponse.getClass();
            if (this.messageCase_ != 1 || this.message_ == RegisterWorkerResponse.getDefaultInstance()) {
                this.message_ = registerWorkerResponse;
            } else {
                this.message_ = ((RegisterWorkerResponse.Builder) RegisterWorkerResponse.newBuilder((RegisterWorkerResponse) this.message_).v(registerWorkerResponse)).o();
            }
            this.messageCase_ = 1;
        }

        private void mergeTermination(JobTermination jobTermination) {
            jobTermination.getClass();
            if (this.messageCase_ != 5 || this.message_ == JobTermination.getDefaultInstance()) {
                this.message_ = jobTermination;
            } else {
                this.message_ = ((JobTermination.Builder) JobTermination.newBuilder((JobTermination) this.message_).v(jobTermination)).o();
            }
            this.messageCase_ = 5;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ServerMessage parseDelimitedFrom(InputStream inputStream) {
            return (ServerMessage) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ServerMessage parseFrom(ByteBuffer byteBuffer) {
            return (ServerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ServerMessage> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAssignment(JobAssignment jobAssignment) {
            jobAssignment.getClass();
            this.message_ = jobAssignment;
            this.messageCase_ = 3;
        }

        private void setAvailability(AvailabilityRequest availabilityRequest) {
            availabilityRequest.getClass();
            this.message_ = availabilityRequest;
            this.messageCase_ = 2;
        }

        private void setPong(WorkerPong workerPong) {
            workerPong.getClass();
            this.message_ = workerPong;
            this.messageCase_ = 4;
        }

        private void setRegister(RegisterWorkerResponse registerWorkerResponse) {
            registerWorkerResponse.getClass();
            this.message_ = registerWorkerResponse;
            this.messageCase_ = 1;
        }

        private void setTermination(JobTermination jobTermination) {
            jobTermination.getClass();
            this.message_ = jobTermination;
            this.messageCase_ = 5;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ServerMessage();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0001\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001<\u0000\u0002<\u0000\u0003<\u0000\u0004<\u0000\u0005<\u0000", new Object[]{ap.a(1141046048), ap.a(1144107082), RegisterWorkerResponse.class, AvailabilityRequest.class, JobAssignment.class, WorkerPong.class, JobTermination.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ServerMessage> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ServerMessage.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public JobAssignment getAssignment() {
            return this.messageCase_ == 3 ? (JobAssignment) this.message_ : JobAssignment.getDefaultInstance();
        }

        public AvailabilityRequest getAvailability() {
            return this.messageCase_ == 2 ? (AvailabilityRequest) this.message_ : AvailabilityRequest.getDefaultInstance();
        }

        public MessageCase getMessageCase() {
            return MessageCase.b(this.messageCase_);
        }

        public WorkerPong getPong() {
            return this.messageCase_ == 4 ? (WorkerPong) this.message_ : WorkerPong.getDefaultInstance();
        }

        public RegisterWorkerResponse getRegister() {
            return this.messageCase_ == 1 ? (RegisterWorkerResponse) this.message_ : RegisterWorkerResponse.getDefaultInstance();
        }

        public JobTermination getTermination() {
            return this.messageCase_ == 5 ? (JobTermination) this.message_ : JobTermination.getDefaultInstance();
        }

        public boolean hasAssignment() {
            return this.messageCase_ == 3;
        }

        public boolean hasAvailability() {
            return this.messageCase_ == 2;
        }

        public boolean hasPong() {
            return this.messageCase_ == 4;
        }

        public boolean hasRegister() {
            return this.messageCase_ == 1;
        }

        public boolean hasTermination() {
            return this.messageCase_ == 5;
        }

        public static Builder newBuilder(ServerMessage serverMessage) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(serverMessage);
        }

        public static ServerMessage parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerMessage) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ServerMessage parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ServerMessage parseFrom(ByteString byteString) {
            return (ServerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ServerMessage parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ServerMessage parseFrom(byte[] bArr) {
            return (ServerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ServerMessage parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ServerMessage parseFrom(InputStream inputStream) {
            return (ServerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ServerMessage parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ServerMessage parseFrom(CodedInputStream codedInputStream) {
            return (ServerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ServerMessage parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ServerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ServerMessageOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SimulateJobRequest extends GeneratedMessageLite<SimulateJobRequest, Builder> implements SimulateJobRequestOrBuilder {
        private static final SimulateJobRequest DEFAULT_INSTANCE;
        private static volatile Parser<SimulateJobRequest> PARSER = null;
        public static final int PARTICIPANT_FIELD_NUMBER = 3;
        public static final int ROOM_FIELD_NUMBER = 2;
        public static final int TYPE_FIELD_NUMBER = 1;
        private LivekitModels.ParticipantInfo participant_;
        private LivekitModels.Room room_;
        private int type_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SimulateJobRequest, Builder> implements SimulateJobRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SimulateJobRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            SimulateJobRequest simulateJobRequest = new SimulateJobRequest();
            DEFAULT_INSTANCE = simulateJobRequest;
            GeneratedMessageLite.registerDefaultInstance(SimulateJobRequest.class, simulateJobRequest);
        }

        private SimulateJobRequest() {
        }

        private void clearParticipant() {
            this.participant_ = null;
        }

        private void clearRoom() {
            this.room_ = null;
        }

        private void clearType() {
            this.type_ = 0;
        }

        public static SimulateJobRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            LivekitModels.ParticipantInfo participantInfo2 = this.participant_;
            if (participantInfo2 == null || participantInfo2 == LivekitModels.ParticipantInfo.getDefaultInstance()) {
                this.participant_ = participantInfo;
            } else {
                this.participant_ = (LivekitModels.ParticipantInfo) ((LivekitModels.ParticipantInfo.Builder) LivekitModels.ParticipantInfo.newBuilder(this.participant_).v(participantInfo)).o();
            }
        }

        private void mergeRoom(LivekitModels.Room room) {
            room.getClass();
            LivekitModels.Room room2 = this.room_;
            if (room2 == null || room2 == LivekitModels.Room.getDefaultInstance()) {
                this.room_ = room;
            } else {
                this.room_ = (LivekitModels.Room) ((LivekitModels.Room.Builder) LivekitModels.Room.newBuilder(this.room_).v(room)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SimulateJobRequest parseDelimitedFrom(InputStream inputStream) {
            return (SimulateJobRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SimulateJobRequest parseFrom(ByteBuffer byteBuffer) {
            return (SimulateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SimulateJobRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            this.participant_ = participantInfo;
        }

        private void setRoom(LivekitModels.Room room) {
            room.getClass();
            this.room_ = room;
        }

        private void setType(JobType jobType) {
            this.type_ = jobType.getNumber();
        }

        private void setTypeValue(int i) {
            this.type_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SimulateJobRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001\f\u0002\t\u0003\t", new Object[]{ap.a(2143096954), ap.a(877164132), ap.a(1735146327)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SimulateJobRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SimulateJobRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.ParticipantInfo getParticipant() {
            LivekitModels.ParticipantInfo participantInfo = this.participant_;
            return participantInfo == null ? LivekitModels.ParticipantInfo.getDefaultInstance() : participantInfo;
        }

        public LivekitModels.Room getRoom() {
            LivekitModels.Room room = this.room_;
            return room == null ? LivekitModels.Room.getDefaultInstance() : room;
        }

        public JobType getType() {
            JobType jobTypeB = JobType.b(this.type_);
            return jobTypeB == null ? JobType.e : jobTypeB;
        }

        public int getTypeValue() {
            return this.type_;
        }

        public boolean hasParticipant() {
            return this.participant_ != null;
        }

        public boolean hasRoom() {
            return this.room_ != null;
        }

        public static Builder newBuilder(SimulateJobRequest simulateJobRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(simulateJobRequest);
        }

        public static SimulateJobRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateJobRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SimulateJobRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SimulateJobRequest parseFrom(ByteString byteString) {
            return (SimulateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SimulateJobRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SimulateJobRequest parseFrom(byte[] bArr) {
            return (SimulateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SimulateJobRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SimulateJobRequest parseFrom(InputStream inputStream) {
            return (SimulateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SimulateJobRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SimulateJobRequest parseFrom(CodedInputStream codedInputStream) {
            return (SimulateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SimulateJobRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SimulateJobRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SimulateJobRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateJobStatus extends GeneratedMessageLite<UpdateJobStatus, Builder> implements UpdateJobStatusOrBuilder {
        private static final UpdateJobStatus DEFAULT_INSTANCE;
        public static final int ERROR_FIELD_NUMBER = 3;
        public static final int JOB_ID_FIELD_NUMBER = 1;
        private static volatile Parser<UpdateJobStatus> PARSER = null;
        public static final int STATUS_FIELD_NUMBER = 2;
        private String error_;
        private String jobId_;
        private int status_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateJobStatus, Builder> implements UpdateJobStatusOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateJobStatus.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateJobStatus updateJobStatus = new UpdateJobStatus();
            DEFAULT_INSTANCE = updateJobStatus;
            GeneratedMessageLite.registerDefaultInstance(UpdateJobStatus.class, updateJobStatus);
        }

        private UpdateJobStatus() {
            String strA = ap.a(506145732);
            this.jobId_ = strA;
            this.error_ = strA;
        }

        private void clearError() {
            this.error_ = getDefaultInstance().getError();
        }

        private void clearJobId() {
            this.jobId_ = getDefaultInstance().getJobId();
        }

        private void clearStatus() {
            this.status_ = 0;
        }

        public static UpdateJobStatus getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateJobStatus parseDelimitedFrom(InputStream inputStream) {
            return (UpdateJobStatus) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateJobStatus parseFrom(ByteBuffer byteBuffer) {
            return (UpdateJobStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateJobStatus> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setError(String str) {
            str.getClass();
            this.error_ = str;
        }

        private void setErrorBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.error_ = byteString.L();
        }

        private void setJobId(String str) {
            str.getClass();
            this.jobId_ = str;
        }

        private void setJobIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.jobId_ = byteString.L();
        }

        private void setStatus(JobStatus jobStatus) {
            this.status_ = jobStatus.getNumber();
        }

        private void setStatusValue(int i) {
            this.status_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateJobStatus();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002\f\u0003Ȉ", new Object[]{"jobId_", "status_", "error_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateJobStatus> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateJobStatus.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getError() {
            return this.error_;
        }

        public ByteString getErrorBytes() {
            return ByteString.n(this.error_);
        }

        public String getJobId() {
            return this.jobId_;
        }

        public ByteString getJobIdBytes() {
            return ByteString.n(this.jobId_);
        }

        public JobStatus getStatus() {
            JobStatus jobStatusB = JobStatus.b(this.status_);
            return jobStatusB == null ? JobStatus.f : jobStatusB;
        }

        public int getStatusValue() {
            return this.status_;
        }

        public static Builder newBuilder(UpdateJobStatus updateJobStatus) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateJobStatus);
        }

        public static UpdateJobStatus parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateJobStatus) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateJobStatus parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateJobStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateJobStatus parseFrom(ByteString byteString) {
            return (UpdateJobStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateJobStatus parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateJobStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateJobStatus parseFrom(byte[] bArr) {
            return (UpdateJobStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateJobStatus parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateJobStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateJobStatus parseFrom(InputStream inputStream) {
            return (UpdateJobStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateJobStatus parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateJobStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateJobStatus parseFrom(CodedInputStream codedInputStream) {
            return (UpdateJobStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateJobStatus parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateJobStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateJobStatusOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateWorkerStatus extends GeneratedMessageLite<UpdateWorkerStatus, Builder> implements UpdateWorkerStatusOrBuilder {
        private static final UpdateWorkerStatus DEFAULT_INSTANCE;
        public static final int JOB_COUNT_FIELD_NUMBER = 4;
        public static final int LOAD_FIELD_NUMBER = 3;
        private static volatile Parser<UpdateWorkerStatus> PARSER = null;
        public static final int STATUS_FIELD_NUMBER = 1;
        private int bitField0_;
        private int jobCount_;
        private float load_;
        private int status_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateWorkerStatus, Builder> implements UpdateWorkerStatusOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateWorkerStatus.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateWorkerStatus updateWorkerStatus = new UpdateWorkerStatus();
            DEFAULT_INSTANCE = updateWorkerStatus;
            GeneratedMessageLite.registerDefaultInstance(UpdateWorkerStatus.class, updateWorkerStatus);
        }

        private UpdateWorkerStatus() {
        }

        private void clearJobCount() {
            this.jobCount_ = 0;
        }

        private void clearLoad() {
            this.load_ = 0.0f;
        }

        private void clearStatus() {
            this.bitField0_ &= -2;
            this.status_ = 0;
        }

        public static UpdateWorkerStatus getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateWorkerStatus parseDelimitedFrom(InputStream inputStream) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateWorkerStatus parseFrom(ByteBuffer byteBuffer) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateWorkerStatus> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setJobCount(int i) {
            this.jobCount_ = i;
        }

        private void setLoad(float f) {
            this.load_ = f;
        }

        private void setStatus(WorkerStatus workerStatus) {
            this.status_ = workerStatus.getNumber();
            this.bitField0_ |= 1;
        }

        private void setStatusValue(int i) {
            this.bitField0_ |= 1;
            this.status_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateWorkerStatus();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0001\u0001\u0004\u0003\u0000\u0000\u0000\u0001ဌ\u0000\u0003\u0001\u0004\u000b", new Object[]{ap.a(1260514512), ap.a(1612085488), ap.a(2072555645), ap.a(1273949656)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateWorkerStatus> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateWorkerStatus.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getJobCount() {
            return this.jobCount_;
        }

        public float getLoad() {
            return this.load_;
        }

        public WorkerStatus getStatus() {
            WorkerStatus workerStatusB = WorkerStatus.b(this.status_);
            return workerStatusB == null ? WorkerStatus.d : workerStatusB;
        }

        public int getStatusValue() {
            return this.status_;
        }

        public boolean hasStatus() {
            return (this.bitField0_ & 1) != 0;
        }

        public static Builder newBuilder(UpdateWorkerStatus updateWorkerStatus) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateWorkerStatus);
        }

        public static UpdateWorkerStatus parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateWorkerStatus parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateWorkerStatus parseFrom(ByteString byteString) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateWorkerStatus parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateWorkerStatus parseFrom(byte[] bArr) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateWorkerStatus parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateWorkerStatus parseFrom(InputStream inputStream) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateWorkerStatus parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateWorkerStatus parseFrom(CodedInputStream codedInputStream) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateWorkerStatus parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateWorkerStatus) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateWorkerStatusOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class WorkerMessage extends GeneratedMessageLite<WorkerMessage, Builder> implements WorkerMessageOrBuilder {
        public static final int AVAILABILITY_FIELD_NUMBER = 2;
        private static final WorkerMessage DEFAULT_INSTANCE;
        public static final int MIGRATE_JOB_FIELD_NUMBER = 7;
        private static volatile Parser<WorkerMessage> PARSER = null;
        public static final int PING_FIELD_NUMBER = 5;
        public static final int REGISTER_FIELD_NUMBER = 1;
        public static final int SIMULATE_JOB_FIELD_NUMBER = 6;
        public static final int UPDATE_JOB_FIELD_NUMBER = 4;
        public static final int UPDATE_WORKER_FIELD_NUMBER = 3;
        private int messageCase_ = 0;
        private Object message_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<WorkerMessage, Builder> implements WorkerMessageOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(WorkerMessage.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum MessageCase {
            b(1),
            c(2),
            d(3),
            e(4),
            f(5),
            g(6),
            h(7),
            i(0);

            private final int a;

            MessageCase(int i2) {
                this.a = i2;
            }

            public static MessageCase b(int i2) {
                switch (i2) {
                    case 0:
                        return i;
                    case 1:
                        return b;
                    case 2:
                        return c;
                    case 3:
                        return d;
                    case 4:
                        return e;
                    case 5:
                        return f;
                    case 6:
                        return g;
                    case 7:
                        return h;
                    default:
                        return null;
                }
            }
        }

        static {
            WorkerMessage workerMessage = new WorkerMessage();
            DEFAULT_INSTANCE = workerMessage;
            GeneratedMessageLite.registerDefaultInstance(WorkerMessage.class, workerMessage);
        }

        private WorkerMessage() {
        }

        private void clearAvailability() {
            if (this.messageCase_ == 2) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearMessage() {
            this.messageCase_ = 0;
            this.message_ = null;
        }

        private void clearMigrateJob() {
            if (this.messageCase_ == 7) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearPing() {
            if (this.messageCase_ == 5) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearRegister() {
            if (this.messageCase_ == 1) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearSimulateJob() {
            if (this.messageCase_ == 6) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearUpdateJob() {
            if (this.messageCase_ == 4) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        private void clearUpdateWorker() {
            if (this.messageCase_ == 3) {
                this.messageCase_ = 0;
                this.message_ = null;
            }
        }

        public static WorkerMessage getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAvailability(AvailabilityResponse availabilityResponse) {
            availabilityResponse.getClass();
            if (this.messageCase_ != 2 || this.message_ == AvailabilityResponse.getDefaultInstance()) {
                this.message_ = availabilityResponse;
            } else {
                this.message_ = ((AvailabilityResponse.Builder) AvailabilityResponse.newBuilder((AvailabilityResponse) this.message_).v(availabilityResponse)).o();
            }
            this.messageCase_ = 2;
        }

        private void mergeMigrateJob(MigrateJobRequest migrateJobRequest) {
            migrateJobRequest.getClass();
            if (this.messageCase_ != 7 || this.message_ == MigrateJobRequest.getDefaultInstance()) {
                this.message_ = migrateJobRequest;
            } else {
                this.message_ = ((MigrateJobRequest.Builder) MigrateJobRequest.newBuilder((MigrateJobRequest) this.message_).v(migrateJobRequest)).o();
            }
            this.messageCase_ = 7;
        }

        private void mergePing(WorkerPing workerPing) {
            workerPing.getClass();
            if (this.messageCase_ != 5 || this.message_ == WorkerPing.getDefaultInstance()) {
                this.message_ = workerPing;
            } else {
                this.message_ = ((WorkerPing.Builder) WorkerPing.newBuilder((WorkerPing) this.message_).v(workerPing)).o();
            }
            this.messageCase_ = 5;
        }

        private void mergeRegister(RegisterWorkerRequest registerWorkerRequest) {
            registerWorkerRequest.getClass();
            if (this.messageCase_ != 1 || this.message_ == RegisterWorkerRequest.getDefaultInstance()) {
                this.message_ = registerWorkerRequest;
            } else {
                this.message_ = ((RegisterWorkerRequest.Builder) RegisterWorkerRequest.newBuilder((RegisterWorkerRequest) this.message_).v(registerWorkerRequest)).o();
            }
            this.messageCase_ = 1;
        }

        private void mergeSimulateJob(SimulateJobRequest simulateJobRequest) {
            simulateJobRequest.getClass();
            if (this.messageCase_ != 6 || this.message_ == SimulateJobRequest.getDefaultInstance()) {
                this.message_ = simulateJobRequest;
            } else {
                this.message_ = ((SimulateJobRequest.Builder) SimulateJobRequest.newBuilder((SimulateJobRequest) this.message_).v(simulateJobRequest)).o();
            }
            this.messageCase_ = 6;
        }

        private void mergeUpdateJob(UpdateJobStatus updateJobStatus) {
            updateJobStatus.getClass();
            if (this.messageCase_ != 4 || this.message_ == UpdateJobStatus.getDefaultInstance()) {
                this.message_ = updateJobStatus;
            } else {
                this.message_ = ((UpdateJobStatus.Builder) UpdateJobStatus.newBuilder((UpdateJobStatus) this.message_).v(updateJobStatus)).o();
            }
            this.messageCase_ = 4;
        }

        private void mergeUpdateWorker(UpdateWorkerStatus updateWorkerStatus) {
            updateWorkerStatus.getClass();
            if (this.messageCase_ != 3 || this.message_ == UpdateWorkerStatus.getDefaultInstance()) {
                this.message_ = updateWorkerStatus;
            } else {
                this.message_ = ((UpdateWorkerStatus.Builder) UpdateWorkerStatus.newBuilder((UpdateWorkerStatus) this.message_).v(updateWorkerStatus)).o();
            }
            this.messageCase_ = 3;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static WorkerMessage parseDelimitedFrom(InputStream inputStream) {
            return (WorkerMessage) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WorkerMessage parseFrom(ByteBuffer byteBuffer) {
            return (WorkerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<WorkerMessage> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAvailability(AvailabilityResponse availabilityResponse) {
            availabilityResponse.getClass();
            this.message_ = availabilityResponse;
            this.messageCase_ = 2;
        }

        private void setMigrateJob(MigrateJobRequest migrateJobRequest) {
            migrateJobRequest.getClass();
            this.message_ = migrateJobRequest;
            this.messageCase_ = 7;
        }

        private void setPing(WorkerPing workerPing) {
            workerPing.getClass();
            this.message_ = workerPing;
            this.messageCase_ = 5;
        }

        private void setRegister(RegisterWorkerRequest registerWorkerRequest) {
            registerWorkerRequest.getClass();
            this.message_ = registerWorkerRequest;
            this.messageCase_ = 1;
        }

        private void setSimulateJob(SimulateJobRequest simulateJobRequest) {
            simulateJobRequest.getClass();
            this.message_ = simulateJobRequest;
            this.messageCase_ = 6;
        }

        private void setUpdateJob(UpdateJobStatus updateJobStatus) {
            updateJobStatus.getClass();
            this.message_ = updateJobStatus;
            this.messageCase_ = 4;
        }

        private void setUpdateWorker(UpdateWorkerStatus updateWorkerStatus) {
            updateWorkerStatus.getClass();
            this.message_ = updateWorkerStatus;
            this.messageCase_ = 3;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new WorkerMessage();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0001\u0000\u0001\u0007\u0007\u0000\u0000\u0000\u0001<\u0000\u0002<\u0000\u0003<\u0000\u0004<\u0000\u0005<\u0000\u0006<\u0000\u0007<\u0000", new Object[]{ap.a(672191326), ap.a(207290925), RegisterWorkerRequest.class, AvailabilityResponse.class, UpdateWorkerStatus.class, UpdateJobStatus.class, WorkerPing.class, SimulateJobRequest.class, MigrateJobRequest.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<WorkerMessage> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (WorkerMessage.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AvailabilityResponse getAvailability() {
            return this.messageCase_ == 2 ? (AvailabilityResponse) this.message_ : AvailabilityResponse.getDefaultInstance();
        }

        public MessageCase getMessageCase() {
            return MessageCase.b(this.messageCase_);
        }

        public MigrateJobRequest getMigrateJob() {
            return this.messageCase_ == 7 ? (MigrateJobRequest) this.message_ : MigrateJobRequest.getDefaultInstance();
        }

        public WorkerPing getPing() {
            return this.messageCase_ == 5 ? (WorkerPing) this.message_ : WorkerPing.getDefaultInstance();
        }

        public RegisterWorkerRequest getRegister() {
            return this.messageCase_ == 1 ? (RegisterWorkerRequest) this.message_ : RegisterWorkerRequest.getDefaultInstance();
        }

        public SimulateJobRequest getSimulateJob() {
            return this.messageCase_ == 6 ? (SimulateJobRequest) this.message_ : SimulateJobRequest.getDefaultInstance();
        }

        public UpdateJobStatus getUpdateJob() {
            return this.messageCase_ == 4 ? (UpdateJobStatus) this.message_ : UpdateJobStatus.getDefaultInstance();
        }

        public UpdateWorkerStatus getUpdateWorker() {
            return this.messageCase_ == 3 ? (UpdateWorkerStatus) this.message_ : UpdateWorkerStatus.getDefaultInstance();
        }

        public boolean hasAvailability() {
            return this.messageCase_ == 2;
        }

        public boolean hasMigrateJob() {
            return this.messageCase_ == 7;
        }

        public boolean hasPing() {
            return this.messageCase_ == 5;
        }

        public boolean hasRegister() {
            return this.messageCase_ == 1;
        }

        public boolean hasSimulateJob() {
            return this.messageCase_ == 6;
        }

        public boolean hasUpdateJob() {
            return this.messageCase_ == 4;
        }

        public boolean hasUpdateWorker() {
            return this.messageCase_ == 3;
        }

        public static Builder newBuilder(WorkerMessage workerMessage) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(workerMessage);
        }

        public static WorkerMessage parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerMessage) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WorkerMessage parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static WorkerMessage parseFrom(ByteString byteString) {
            return (WorkerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static WorkerMessage parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static WorkerMessage parseFrom(byte[] bArr) {
            return (WorkerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static WorkerMessage parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static WorkerMessage parseFrom(InputStream inputStream) {
            return (WorkerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WorkerMessage parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WorkerMessage parseFrom(CodedInputStream codedInputStream) {
            return (WorkerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static WorkerMessage parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerMessage) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface WorkerMessageOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class WorkerPing extends GeneratedMessageLite<WorkerPing, Builder> implements WorkerPingOrBuilder {
        private static final WorkerPing DEFAULT_INSTANCE;
        private static volatile Parser<WorkerPing> PARSER = null;
        public static final int TIMESTAMP_FIELD_NUMBER = 1;
        private long timestamp_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<WorkerPing, Builder> implements WorkerPingOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(WorkerPing.DEFAULT_INSTANCE);
            }
        }

        static {
            WorkerPing workerPing = new WorkerPing();
            DEFAULT_INSTANCE = workerPing;
            GeneratedMessageLite.registerDefaultInstance(WorkerPing.class, workerPing);
        }

        private WorkerPing() {
        }

        private void clearTimestamp() {
            this.timestamp_ = 0L;
        }

        public static WorkerPing getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static WorkerPing parseDelimitedFrom(InputStream inputStream) {
            return (WorkerPing) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WorkerPing parseFrom(ByteBuffer byteBuffer) {
            return (WorkerPing) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<WorkerPing> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setTimestamp(long j) {
            this.timestamp_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new WorkerPing();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001\u0002", new Object[]{ap.a(466833812)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<WorkerPing> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (WorkerPing.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getTimestamp() {
            return this.timestamp_;
        }

        public static Builder newBuilder(WorkerPing workerPing) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(workerPing);
        }

        public static WorkerPing parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPing) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WorkerPing parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPing) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static WorkerPing parseFrom(ByteString byteString) {
            return (WorkerPing) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static WorkerPing parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPing) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static WorkerPing parseFrom(byte[] bArr) {
            return (WorkerPing) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static WorkerPing parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPing) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static WorkerPing parseFrom(InputStream inputStream) {
            return (WorkerPing) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WorkerPing parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPing) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WorkerPing parseFrom(CodedInputStream codedInputStream) {
            return (WorkerPing) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static WorkerPing parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPing) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface WorkerPingOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class WorkerPong extends GeneratedMessageLite<WorkerPong, Builder> implements WorkerPongOrBuilder {
        private static final WorkerPong DEFAULT_INSTANCE;
        public static final int LAST_TIMESTAMP_FIELD_NUMBER = 1;
        private static volatile Parser<WorkerPong> PARSER = null;
        public static final int TIMESTAMP_FIELD_NUMBER = 2;
        private long lastTimestamp_;
        private long timestamp_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<WorkerPong, Builder> implements WorkerPongOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(WorkerPong.DEFAULT_INSTANCE);
            }
        }

        static {
            WorkerPong workerPong = new WorkerPong();
            DEFAULT_INSTANCE = workerPong;
            GeneratedMessageLite.registerDefaultInstance(WorkerPong.class, workerPong);
        }

        private WorkerPong() {
        }

        private void clearLastTimestamp() {
            this.lastTimestamp_ = 0L;
        }

        private void clearTimestamp() {
            this.timestamp_ = 0L;
        }

        public static WorkerPong getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static WorkerPong parseDelimitedFrom(InputStream inputStream) {
            return (WorkerPong) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WorkerPong parseFrom(ByteBuffer byteBuffer) {
            return (WorkerPong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<WorkerPong> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setLastTimestamp(long j) {
            this.lastTimestamp_ = j;
        }

        private void setTimestamp(long j) {
            this.timestamp_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new WorkerPong();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0002\u0002\u0002", new Object[]{ap.a(1795907779), ap.a(516033465)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<WorkerPong> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (WorkerPong.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getLastTimestamp() {
            return this.lastTimestamp_;
        }

        public long getTimestamp() {
            return this.timestamp_;
        }

        public static Builder newBuilder(WorkerPong workerPong) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(workerPong);
        }

        public static WorkerPong parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPong) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WorkerPong parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static WorkerPong parseFrom(ByteString byteString) {
            return (WorkerPong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static WorkerPong parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static WorkerPong parseFrom(byte[] bArr) {
            return (WorkerPong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static WorkerPong parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static WorkerPong parseFrom(InputStream inputStream) {
            return (WorkerPong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WorkerPong parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WorkerPong parseFrom(CodedInputStream codedInputStream) {
            return (WorkerPong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static WorkerPong parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WorkerPong) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface WorkerPongOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum WorkerStatus implements Internal.EnumLite {
        b(0),
        c(1),
        d(-1);

        private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<WorkerStatus>() { // from class: livekit.LivekitAgent.WorkerStatus.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public WorkerStatus findValueByNumber(int i) {
                return WorkerStatus.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class WorkerStatusVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new WorkerStatusVerifier();

            private WorkerStatusVerifier() {
            }

            public boolean isInRange(int i) {
                return WorkerStatus.b(i) != null;
            }
        }

        WorkerStatus(int i) {
            this.a = i;
        }

        public static WorkerStatus b(int i) {
            if (i == 0) {
                return b;
            }
            if (i != 1) {
                return null;
            }
            return c;
        }

        public final int getNumber() {
            if (this != d) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    private LivekitAgent() {
    }
}