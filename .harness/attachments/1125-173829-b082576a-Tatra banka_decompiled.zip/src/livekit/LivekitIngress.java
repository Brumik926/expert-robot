package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;
import livekit.LivekitModels;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitIngress {

    /* JADX INFO: renamed from: livekit.LivekitIngress$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class CreateIngressRequest extends GeneratedMessageLite<CreateIngressRequest, Builder> implements CreateIngressRequestOrBuilder {
        public static final int AUDIO_FIELD_NUMBER = 6;
        public static final int BYPASS_TRANSCODING_FIELD_NUMBER = 8;
        private static final CreateIngressRequest DEFAULT_INSTANCE;
        public static final int ENABLED_FIELD_NUMBER = 12;
        public static final int ENABLE_TRANSCODING_FIELD_NUMBER = 11;
        public static final int INPUT_TYPE_FIELD_NUMBER = 1;
        public static final int NAME_FIELD_NUMBER = 2;
        private static volatile Parser<CreateIngressRequest> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 4;
        public static final int PARTICIPANT_METADATA_FIELD_NUMBER = 10;
        public static final int PARTICIPANT_NAME_FIELD_NUMBER = 5;
        public static final int ROOM_NAME_FIELD_NUMBER = 3;
        public static final int URL_FIELD_NUMBER = 9;
        public static final int VIDEO_FIELD_NUMBER = 7;
        private IngressAudioOptions audio_;
        private int bitField0_;
        private boolean bypassTranscoding_;
        private boolean enableTranscoding_;
        private boolean enabled_;
        private int inputType_;
        private String name_;
        private String participantIdentity_;
        private String participantMetadata_;
        private String participantName_;
        private String roomName_;
        private String url_;
        private IngressVideoOptions video_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<CreateIngressRequest, Builder> implements CreateIngressRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(CreateIngressRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            CreateIngressRequest createIngressRequest = new CreateIngressRequest();
            DEFAULT_INSTANCE = createIngressRequest;
            GeneratedMessageLite.registerDefaultInstance(CreateIngressRequest.class, createIngressRequest);
        }

        private CreateIngressRequest() {
            String strA = ap.a(1002507631);
            this.url_ = strA;
            this.name_ = strA;
            this.roomName_ = strA;
            this.participantIdentity_ = strA;
            this.participantName_ = strA;
            this.participantMetadata_ = strA;
        }

        private void clearAudio() {
            this.audio_ = null;
        }

        private void clearBypassTranscoding() {
            this.bypassTranscoding_ = false;
        }

        private void clearEnableTranscoding() {
            this.bitField0_ &= -2;
            this.enableTranscoding_ = false;
        }

        private void clearEnabled() {
            this.bitField0_ &= -3;
            this.enabled_ = false;
        }

        private void clearInputType() {
            this.inputType_ = 0;
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearParticipantMetadata() {
            this.participantMetadata_ = getDefaultInstance().getParticipantMetadata();
        }

        private void clearParticipantName() {
            this.participantName_ = getDefaultInstance().getParticipantName();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearUrl() {
            this.url_ = getDefaultInstance().getUrl();
        }

        private void clearVideo() {
            this.video_ = null;
        }

        public static CreateIngressRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAudio(IngressAudioOptions ingressAudioOptions) {
            ingressAudioOptions.getClass();
            IngressAudioOptions ingressAudioOptions2 = this.audio_;
            if (ingressAudioOptions2 == null || ingressAudioOptions2 == IngressAudioOptions.getDefaultInstance()) {
                this.audio_ = ingressAudioOptions;
            } else {
                this.audio_ = (IngressAudioOptions) ((IngressAudioOptions.Builder) IngressAudioOptions.newBuilder(this.audio_).v(ingressAudioOptions)).o();
            }
        }

        private void mergeVideo(IngressVideoOptions ingressVideoOptions) {
            ingressVideoOptions.getClass();
            IngressVideoOptions ingressVideoOptions2 = this.video_;
            if (ingressVideoOptions2 == null || ingressVideoOptions2 == IngressVideoOptions.getDefaultInstance()) {
                this.video_ = ingressVideoOptions;
            } else {
                this.video_ = (IngressVideoOptions) ((IngressVideoOptions.Builder) IngressVideoOptions.newBuilder(this.video_).v(ingressVideoOptions)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static CreateIngressRequest parseDelimitedFrom(InputStream inputStream) {
            return (CreateIngressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateIngressRequest parseFrom(ByteBuffer byteBuffer) {
            return (CreateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<CreateIngressRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAudio(IngressAudioOptions ingressAudioOptions) {
            ingressAudioOptions.getClass();
            this.audio_ = ingressAudioOptions;
        }

        private void setBypassTranscoding(boolean z) {
            this.bypassTranscoding_ = z;
        }

        private void setEnableTranscoding(boolean z) {
            this.bitField0_ |= 1;
            this.enableTranscoding_ = z;
        }

        private void setEnabled(boolean z) {
            this.bitField0_ |= 2;
            this.enabled_ = z;
        }

        private void setInputType(IngressInput ingressInput) {
            this.inputType_ = ingressInput.getNumber();
        }

        private void setInputTypeValue(int i) {
            this.inputType_ = i;
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setParticipantMetadata(String str) {
            str.getClass();
            this.participantMetadata_ = str;
        }

        private void setParticipantMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantMetadata_ = byteString.L();
        }

        private void setParticipantName(String str) {
            str.getClass();
            this.participantName_ = str;
        }

        private void setParticipantNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantName_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setUrl(String str) {
            str.getClass();
            this.url_ = str;
        }

        private void setUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.url_ = byteString.L();
        }

        private void setVideo(IngressVideoOptions ingressVideoOptions) {
            ingressVideoOptions.getClass();
            this.video_ = ingressVideoOptions;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new CreateIngressRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\f\u0000\u0001\u0001\f\f\u0000\u0000\u0000\u0001\f\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005Ȉ\u0006\t\u0007\t\b\u0007\tȈ\nȈ\u000bဇ\u0000\fဇ\u0001", new Object[]{"bitField0_", "inputType_", "name_", "roomName_", "participantIdentity_", "participantName_", "audio_", "video_", "bypassTranscoding_", "url_", "participantMetadata_", "enableTranscoding_", "enabled_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<CreateIngressRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (CreateIngressRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public IngressAudioOptions getAudio() {
            IngressAudioOptions ingressAudioOptions = this.audio_;
            return ingressAudioOptions == null ? IngressAudioOptions.getDefaultInstance() : ingressAudioOptions;
        }

        @Deprecated
        public boolean getBypassTranscoding() {
            return this.bypassTranscoding_;
        }

        public boolean getEnableTranscoding() {
            return this.enableTranscoding_;
        }

        public boolean getEnabled() {
            return this.enabled_;
        }

        public IngressInput getInputType() {
            IngressInput ingressInputB = IngressInput.b(this.inputType_);
            return ingressInputB == null ? IngressInput.e : ingressInputB;
        }

        public int getInputTypeValue() {
            return this.inputType_;
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getParticipantMetadata() {
            return this.participantMetadata_;
        }

        public ByteString getParticipantMetadataBytes() {
            return ByteString.n(this.participantMetadata_);
        }

        public String getParticipantName() {
            return this.participantName_;
        }

        public ByteString getParticipantNameBytes() {
            return ByteString.n(this.participantName_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public String getUrl() {
            return this.url_;
        }

        public ByteString getUrlBytes() {
            return ByteString.n(this.url_);
        }

        public IngressVideoOptions getVideo() {
            IngressVideoOptions ingressVideoOptions = this.video_;
            return ingressVideoOptions == null ? IngressVideoOptions.getDefaultInstance() : ingressVideoOptions;
        }

        public boolean hasAudio() {
            return this.audio_ != null;
        }

        public boolean hasEnableTranscoding() {
            return (this.bitField0_ & 1) != 0;
        }

        public boolean hasEnabled() {
            return (this.bitField0_ & 2) != 0;
        }

        public boolean hasVideo() {
            return this.video_ != null;
        }

        public static Builder newBuilder(CreateIngressRequest createIngressRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(createIngressRequest);
        }

        public static CreateIngressRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateIngressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateIngressRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static CreateIngressRequest parseFrom(ByteString byteString) {
            return (CreateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static CreateIngressRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static CreateIngressRequest parseFrom(byte[] bArr) {
            return (CreateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static CreateIngressRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static CreateIngressRequest parseFrom(InputStream inputStream) {
            return (CreateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateIngressRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateIngressRequest parseFrom(CodedInputStream codedInputStream) {
            return (CreateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static CreateIngressRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface CreateIngressRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DeleteIngressRequest extends GeneratedMessageLite<DeleteIngressRequest, Builder> implements DeleteIngressRequestOrBuilder {
        private static final DeleteIngressRequest DEFAULT_INSTANCE;
        public static final int INGRESS_ID_FIELD_NUMBER = 1;
        private static volatile Parser<DeleteIngressRequest> PARSER;
        private String ingressId_ = ap.a(767640845);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DeleteIngressRequest, Builder> implements DeleteIngressRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DeleteIngressRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            DeleteIngressRequest deleteIngressRequest = new DeleteIngressRequest();
            DEFAULT_INSTANCE = deleteIngressRequest;
            GeneratedMessageLite.registerDefaultInstance(DeleteIngressRequest.class, deleteIngressRequest);
        }

        private DeleteIngressRequest() {
        }

        private void clearIngressId() {
            this.ingressId_ = getDefaultInstance().getIngressId();
        }

        public static DeleteIngressRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DeleteIngressRequest parseDelimitedFrom(InputStream inputStream) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteIngressRequest parseFrom(ByteBuffer byteBuffer) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DeleteIngressRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setIngressId(String str) {
            str.getClass();
            this.ingressId_ = str;
        }

        private void setIngressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.ingressId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DeleteIngressRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"ingressId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DeleteIngressRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DeleteIngressRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getIngressId() {
            return this.ingressId_;
        }

        public ByteString getIngressIdBytes() {
            return ByteString.n(this.ingressId_);
        }

        public static Builder newBuilder(DeleteIngressRequest deleteIngressRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(deleteIngressRequest);
        }

        public static DeleteIngressRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteIngressRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DeleteIngressRequest parseFrom(ByteString byteString) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DeleteIngressRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DeleteIngressRequest parseFrom(byte[] bArr) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DeleteIngressRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DeleteIngressRequest parseFrom(InputStream inputStream) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteIngressRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteIngressRequest parseFrom(CodedInputStream codedInputStream) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DeleteIngressRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DeleteIngressRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class IngressAudioEncodingOptions extends GeneratedMessageLite<IngressAudioEncodingOptions, Builder> implements IngressAudioEncodingOptionsOrBuilder {
        public static final int AUDIO_CODEC_FIELD_NUMBER = 1;
        public static final int BITRATE_FIELD_NUMBER = 2;
        public static final int CHANNELS_FIELD_NUMBER = 4;
        private static final IngressAudioEncodingOptions DEFAULT_INSTANCE;
        public static final int DISABLE_DTX_FIELD_NUMBER = 3;
        private static volatile Parser<IngressAudioEncodingOptions> PARSER;
        private int audioCodec_;
        private int bitrate_;
        private int channels_;
        private boolean disableDtx_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<IngressAudioEncodingOptions, Builder> implements IngressAudioEncodingOptionsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(IngressAudioEncodingOptions.DEFAULT_INSTANCE);
            }
        }

        static {
            IngressAudioEncodingOptions ingressAudioEncodingOptions = new IngressAudioEncodingOptions();
            DEFAULT_INSTANCE = ingressAudioEncodingOptions;
            GeneratedMessageLite.registerDefaultInstance(IngressAudioEncodingOptions.class, ingressAudioEncodingOptions);
        }

        private IngressAudioEncodingOptions() {
        }

        private void clearAudioCodec() {
            this.audioCodec_ = 0;
        }

        private void clearBitrate() {
            this.bitrate_ = 0;
        }

        private void clearChannels() {
            this.channels_ = 0;
        }

        private void clearDisableDtx() {
            this.disableDtx_ = false;
        }

        public static IngressAudioEncodingOptions getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static IngressAudioEncodingOptions parseDelimitedFrom(InputStream inputStream) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressAudioEncodingOptions parseFrom(ByteBuffer byteBuffer) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<IngressAudioEncodingOptions> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAudioCodec(LivekitModels.AudioCodec audioCodec) {
            this.audioCodec_ = audioCodec.getNumber();
        }

        private void setAudioCodecValue(int i) {
            this.audioCodec_ = i;
        }

        private void setBitrate(int i) {
            this.bitrate_ = i;
        }

        private void setChannels(int i) {
            this.channels_ = i;
        }

        private void setDisableDtx(boolean z) {
            this.disableDtx_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new IngressAudioEncodingOptions();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\f\u0002\u000b\u0003\u0007\u0004\u000b", new Object[]{ap.a(569914430), ap.a(146915098), ap.a(1698517990), ap.a(1047485170)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<IngressAudioEncodingOptions> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (IngressAudioEncodingOptions.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public LivekitModels.AudioCodec getAudioCodec() {
            LivekitModels.AudioCodec audioCodecB = LivekitModels.AudioCodec.b(this.audioCodec_);
            return audioCodecB == null ? LivekitModels.AudioCodec.f : audioCodecB;
        }

        public int getAudioCodecValue() {
            return this.audioCodec_;
        }

        public int getBitrate() {
            return this.bitrate_;
        }

        public int getChannels() {
            return this.channels_;
        }

        public boolean getDisableDtx() {
            return this.disableDtx_;
        }

        public static Builder newBuilder(IngressAudioEncodingOptions ingressAudioEncodingOptions) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(ingressAudioEncodingOptions);
        }

        public static IngressAudioEncodingOptions parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressAudioEncodingOptions parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static IngressAudioEncodingOptions parseFrom(ByteString byteString) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static IngressAudioEncodingOptions parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static IngressAudioEncodingOptions parseFrom(byte[] bArr) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static IngressAudioEncodingOptions parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static IngressAudioEncodingOptions parseFrom(InputStream inputStream) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressAudioEncodingOptions parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressAudioEncodingOptions parseFrom(CodedInputStream codedInputStream) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static IngressAudioEncodingOptions parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface IngressAudioEncodingOptionsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum IngressAudioEncodingPreset implements Internal.EnumLite {
        b(0),
        c(1),
        d(-1);

        private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<IngressAudioEncodingPreset>() { // from class: livekit.LivekitIngress.IngressAudioEncodingPreset.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public IngressAudioEncodingPreset findValueByNumber(int i) {
                return IngressAudioEncodingPreset.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class IngressAudioEncodingPresetVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new IngressAudioEncodingPresetVerifier();

            private IngressAudioEncodingPresetVerifier() {
            }

            public boolean isInRange(int i) {
                return IngressAudioEncodingPreset.b(i) != null;
            }
        }

        IngressAudioEncodingPreset(int i) {
            this.a = i;
        }

        public static IngressAudioEncodingPreset b(int i) {
            if (i == 0) {
                return b;
            }
            if (i != 1) {
                return null;
            }
            return c;
        }

        public final int getNumber() {
            if (this != d) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class IngressAudioOptions extends GeneratedMessageLite<IngressAudioOptions, Builder> implements IngressAudioOptionsOrBuilder {
        private static final IngressAudioOptions DEFAULT_INSTANCE;
        public static final int NAME_FIELD_NUMBER = 1;
        public static final int OPTIONS_FIELD_NUMBER = 4;
        private static volatile Parser<IngressAudioOptions> PARSER = null;
        public static final int PRESET_FIELD_NUMBER = 3;
        public static final int SOURCE_FIELD_NUMBER = 2;
        private Object encodingOptions_;
        private int source_;
        private int encodingOptionsCase_ = 0;
        private String name_ = ap.a(1965019079);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<IngressAudioOptions, Builder> implements IngressAudioOptionsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(IngressAudioOptions.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum EncodingOptionsCase {
            b(3),
            c(4),
            d(0);

            private final int a;

            EncodingOptionsCase(int i) {
                this.a = i;
            }

            public static EncodingOptionsCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 3) {
                    return b;
                }
                if (i != 4) {
                    return null;
                }
                return c;
            }
        }

        static {
            IngressAudioOptions ingressAudioOptions = new IngressAudioOptions();
            DEFAULT_INSTANCE = ingressAudioOptions;
            GeneratedMessageLite.registerDefaultInstance(IngressAudioOptions.class, ingressAudioOptions);
        }

        private IngressAudioOptions() {
        }

        private void clearEncodingOptions() {
            this.encodingOptionsCase_ = 0;
            this.encodingOptions_ = null;
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearOptions() {
            if (this.encodingOptionsCase_ == 4) {
                this.encodingOptionsCase_ = 0;
                this.encodingOptions_ = null;
            }
        }

        private void clearPreset() {
            if (this.encodingOptionsCase_ == 3) {
                this.encodingOptionsCase_ = 0;
                this.encodingOptions_ = null;
            }
        }

        private void clearSource() {
            this.source_ = 0;
        }

        public static IngressAudioOptions getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeOptions(IngressAudioEncodingOptions ingressAudioEncodingOptions) {
            ingressAudioEncodingOptions.getClass();
            if (this.encodingOptionsCase_ != 4 || this.encodingOptions_ == IngressAudioEncodingOptions.getDefaultInstance()) {
                this.encodingOptions_ = ingressAudioEncodingOptions;
            } else {
                this.encodingOptions_ = ((IngressAudioEncodingOptions.Builder) IngressAudioEncodingOptions.newBuilder((IngressAudioEncodingOptions) this.encodingOptions_).v(ingressAudioEncodingOptions)).o();
            }
            this.encodingOptionsCase_ = 4;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static IngressAudioOptions parseDelimitedFrom(InputStream inputStream) {
            return (IngressAudioOptions) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressAudioOptions parseFrom(ByteBuffer byteBuffer) {
            return (IngressAudioOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<IngressAudioOptions> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setOptions(IngressAudioEncodingOptions ingressAudioEncodingOptions) {
            ingressAudioEncodingOptions.getClass();
            this.encodingOptions_ = ingressAudioEncodingOptions;
            this.encodingOptionsCase_ = 4;
        }

        private void setPreset(IngressAudioEncodingPreset ingressAudioEncodingPreset) {
            this.encodingOptions_ = Integer.valueOf(ingressAudioEncodingPreset.getNumber());
            this.encodingOptionsCase_ = 3;
        }

        private void setPresetValue(int i) {
            this.encodingOptionsCase_ = 3;
            this.encodingOptions_ = Integer.valueOf(i);
        }

        private void setSource(LivekitModels.TrackSource trackSource) {
            this.source_ = trackSource.getNumber();
        }

        private void setSourceValue(int i) {
            this.source_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new IngressAudioOptions();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0001\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001Ȉ\u0002\f\u0003?\u0000\u0004<\u0000", new Object[]{"encodingOptions_", "encodingOptionsCase_", "name_", "source_", IngressAudioEncodingOptions.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<IngressAudioOptions> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (IngressAudioOptions.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public EncodingOptionsCase getEncodingOptionsCase() {
            return EncodingOptionsCase.b(this.encodingOptionsCase_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public IngressAudioEncodingOptions getOptions() {
            return this.encodingOptionsCase_ == 4 ? (IngressAudioEncodingOptions) this.encodingOptions_ : IngressAudioEncodingOptions.getDefaultInstance();
        }

        public IngressAudioEncodingPreset getPreset() {
            if (this.encodingOptionsCase_ != 3) {
                return IngressAudioEncodingPreset.b;
            }
            IngressAudioEncodingPreset ingressAudioEncodingPresetB = IngressAudioEncodingPreset.b(((Integer) this.encodingOptions_).intValue());
            return ingressAudioEncodingPresetB == null ? IngressAudioEncodingPreset.d : ingressAudioEncodingPresetB;
        }

        public int getPresetValue() {
            if (this.encodingOptionsCase_ == 3) {
                return ((Integer) this.encodingOptions_).intValue();
            }
            return 0;
        }

        public LivekitModels.TrackSource getSource() {
            LivekitModels.TrackSource trackSourceB = LivekitModels.TrackSource.b(this.source_);
            return trackSourceB == null ? LivekitModels.TrackSource.g : trackSourceB;
        }

        public int getSourceValue() {
            return this.source_;
        }

        public boolean hasOptions() {
            return this.encodingOptionsCase_ == 4;
        }

        public boolean hasPreset() {
            return this.encodingOptionsCase_ == 3;
        }

        public static Builder newBuilder(IngressAudioOptions ingressAudioOptions) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(ingressAudioOptions);
        }

        public static IngressAudioOptions parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioOptions) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressAudioOptions parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static IngressAudioOptions parseFrom(ByteString byteString) {
            return (IngressAudioOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static IngressAudioOptions parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static IngressAudioOptions parseFrom(byte[] bArr) {
            return (IngressAudioOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static IngressAudioOptions parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static IngressAudioOptions parseFrom(InputStream inputStream) {
            return (IngressAudioOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressAudioOptions parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressAudioOptions parseFrom(CodedInputStream codedInputStream) {
            return (IngressAudioOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static IngressAudioOptions parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressAudioOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface IngressAudioOptionsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class IngressInfo extends GeneratedMessageLite<IngressInfo, Builder> implements IngressInfoOrBuilder {
        public static final int AUDIO_FIELD_NUMBER = 6;
        public static final int BYPASS_TRANSCODING_FIELD_NUMBER = 13;
        private static final IngressInfo DEFAULT_INSTANCE;
        public static final int ENABLED_FIELD_NUMBER = 16;
        public static final int ENABLE_TRANSCODING_FIELD_NUMBER = 15;
        public static final int INGRESS_ID_FIELD_NUMBER = 1;
        public static final int INPUT_TYPE_FIELD_NUMBER = 5;
        public static final int NAME_FIELD_NUMBER = 2;
        private static volatile Parser<IngressInfo> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 9;
        public static final int PARTICIPANT_METADATA_FIELD_NUMBER = 14;
        public static final int PARTICIPANT_NAME_FIELD_NUMBER = 10;
        public static final int REUSABLE_FIELD_NUMBER = 11;
        public static final int ROOM_NAME_FIELD_NUMBER = 8;
        public static final int STATE_FIELD_NUMBER = 12;
        public static final int STREAM_KEY_FIELD_NUMBER = 3;
        public static final int URL_FIELD_NUMBER = 4;
        public static final int VIDEO_FIELD_NUMBER = 7;
        private IngressAudioOptions audio_;
        private int bitField0_;
        private boolean bypassTranscoding_;
        private boolean enableTranscoding_;
        private boolean enabled_;
        private String ingressId_;
        private int inputType_;
        private String name_;
        private String participantIdentity_;
        private String participantMetadata_;
        private String participantName_;
        private boolean reusable_;
        private String roomName_;
        private IngressState state_;
        private String streamKey_;
        private String url_;
        private IngressVideoOptions video_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<IngressInfo, Builder> implements IngressInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(IngressInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            IngressInfo ingressInfo = new IngressInfo();
            DEFAULT_INSTANCE = ingressInfo;
            GeneratedMessageLite.registerDefaultInstance(IngressInfo.class, ingressInfo);
        }

        private IngressInfo() {
            String strA = ap.a(1547919542);
            this.ingressId_ = strA;
            this.name_ = strA;
            this.streamKey_ = strA;
            this.url_ = strA;
            this.roomName_ = strA;
            this.participantIdentity_ = strA;
            this.participantName_ = strA;
            this.participantMetadata_ = strA;
        }

        private void clearAudio() {
            this.audio_ = null;
        }

        private void clearBypassTranscoding() {
            this.bypassTranscoding_ = false;
        }

        private void clearEnableTranscoding() {
            this.bitField0_ &= -2;
            this.enableTranscoding_ = false;
        }

        private void clearEnabled() {
            this.bitField0_ &= -3;
            this.enabled_ = false;
        }

        private void clearIngressId() {
            this.ingressId_ = getDefaultInstance().getIngressId();
        }

        private void clearInputType() {
            this.inputType_ = 0;
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearParticipantMetadata() {
            this.participantMetadata_ = getDefaultInstance().getParticipantMetadata();
        }

        private void clearParticipantName() {
            this.participantName_ = getDefaultInstance().getParticipantName();
        }

        private void clearReusable() {
            this.reusable_ = false;
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearState() {
            this.state_ = null;
        }

        private void clearStreamKey() {
            this.streamKey_ = getDefaultInstance().getStreamKey();
        }

        private void clearUrl() {
            this.url_ = getDefaultInstance().getUrl();
        }

        private void clearVideo() {
            this.video_ = null;
        }

        public static IngressInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAudio(IngressAudioOptions ingressAudioOptions) {
            ingressAudioOptions.getClass();
            IngressAudioOptions ingressAudioOptions2 = this.audio_;
            if (ingressAudioOptions2 == null || ingressAudioOptions2 == IngressAudioOptions.getDefaultInstance()) {
                this.audio_ = ingressAudioOptions;
            } else {
                this.audio_ = (IngressAudioOptions) ((IngressAudioOptions.Builder) IngressAudioOptions.newBuilder(this.audio_).v(ingressAudioOptions)).o();
            }
        }

        private void mergeState(IngressState ingressState) {
            ingressState.getClass();
            IngressState ingressState2 = this.state_;
            if (ingressState2 == null || ingressState2 == IngressState.getDefaultInstance()) {
                this.state_ = ingressState;
            } else {
                this.state_ = (IngressState) ((IngressState.Builder) IngressState.newBuilder(this.state_).v(ingressState)).o();
            }
        }

        private void mergeVideo(IngressVideoOptions ingressVideoOptions) {
            ingressVideoOptions.getClass();
            IngressVideoOptions ingressVideoOptions2 = this.video_;
            if (ingressVideoOptions2 == null || ingressVideoOptions2 == IngressVideoOptions.getDefaultInstance()) {
                this.video_ = ingressVideoOptions;
            } else {
                this.video_ = (IngressVideoOptions) ((IngressVideoOptions.Builder) IngressVideoOptions.newBuilder(this.video_).v(ingressVideoOptions)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static IngressInfo parseDelimitedFrom(InputStream inputStream) {
            return (IngressInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressInfo parseFrom(ByteBuffer byteBuffer) {
            return (IngressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<IngressInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAudio(IngressAudioOptions ingressAudioOptions) {
            ingressAudioOptions.getClass();
            this.audio_ = ingressAudioOptions;
        }

        private void setBypassTranscoding(boolean z) {
            this.bypassTranscoding_ = z;
        }

        private void setEnableTranscoding(boolean z) {
            this.bitField0_ |= 1;
            this.enableTranscoding_ = z;
        }

        private void setEnabled(boolean z) {
            this.bitField0_ |= 2;
            this.enabled_ = z;
        }

        private void setIngressId(String str) {
            str.getClass();
            this.ingressId_ = str;
        }

        private void setIngressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.ingressId_ = byteString.L();
        }

        private void setInputType(IngressInput ingressInput) {
            this.inputType_ = ingressInput.getNumber();
        }

        private void setInputTypeValue(int i) {
            this.inputType_ = i;
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setParticipantMetadata(String str) {
            str.getClass();
            this.participantMetadata_ = str;
        }

        private void setParticipantMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantMetadata_ = byteString.L();
        }

        private void setParticipantName(String str) {
            str.getClass();
            this.participantName_ = str;
        }

        private void setParticipantNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantName_ = byteString.L();
        }

        private void setReusable(boolean z) {
            this.reusable_ = z;
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setState(IngressState ingressState) {
            ingressState.getClass();
            this.state_ = ingressState;
        }

        private void setStreamKey(String str) {
            str.getClass();
            this.streamKey_ = str;
        }

        private void setStreamKeyBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.streamKey_ = byteString.L();
        }

        private void setUrl(String str) {
            str.getClass();
            this.url_ = str;
        }

        private void setUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.url_ = byteString.L();
        }

        private void setVideo(IngressVideoOptions ingressVideoOptions) {
            ingressVideoOptions.getClass();
            this.video_ = ingressVideoOptions;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new IngressInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0010\u0000\u0001\u0001\u0010\u0010\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005\f\u0006\t\u0007\t\bȈ\tȈ\nȈ\u000b\u0007\f\t\r\u0007\u000eȈ\u000fဇ\u0000\u0010ဇ\u0001", new Object[]{"bitField0_", "ingressId_", "name_", "streamKey_", "url_", "inputType_", "audio_", "video_", "roomName_", "participantIdentity_", "participantName_", "reusable_", "state_", "bypassTranscoding_", "participantMetadata_", "enableTranscoding_", "enabled_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<IngressInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (IngressInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public IngressAudioOptions getAudio() {
            IngressAudioOptions ingressAudioOptions = this.audio_;
            return ingressAudioOptions == null ? IngressAudioOptions.getDefaultInstance() : ingressAudioOptions;
        }

        @Deprecated
        public boolean getBypassTranscoding() {
            return this.bypassTranscoding_;
        }

        public boolean getEnableTranscoding() {
            return this.enableTranscoding_;
        }

        public boolean getEnabled() {
            return this.enabled_;
        }

        public String getIngressId() {
            return this.ingressId_;
        }

        public ByteString getIngressIdBytes() {
            return ByteString.n(this.ingressId_);
        }

        public IngressInput getInputType() {
            IngressInput ingressInputB = IngressInput.b(this.inputType_);
            return ingressInputB == null ? IngressInput.e : ingressInputB;
        }

        public int getInputTypeValue() {
            return this.inputType_;
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getParticipantMetadata() {
            return this.participantMetadata_;
        }

        public ByteString getParticipantMetadataBytes() {
            return ByteString.n(this.participantMetadata_);
        }

        public String getParticipantName() {
            return this.participantName_;
        }

        public ByteString getParticipantNameBytes() {
            return ByteString.n(this.participantName_);
        }

        public boolean getReusable() {
            return this.reusable_;
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public IngressState getState() {
            IngressState ingressState = this.state_;
            return ingressState == null ? IngressState.getDefaultInstance() : ingressState;
        }

        public String getStreamKey() {
            return this.streamKey_;
        }

        public ByteString getStreamKeyBytes() {
            return ByteString.n(this.streamKey_);
        }

        public String getUrl() {
            return this.url_;
        }

        public ByteString getUrlBytes() {
            return ByteString.n(this.url_);
        }

        public IngressVideoOptions getVideo() {
            IngressVideoOptions ingressVideoOptions = this.video_;
            return ingressVideoOptions == null ? IngressVideoOptions.getDefaultInstance() : ingressVideoOptions;
        }

        public boolean hasAudio() {
            return this.audio_ != null;
        }

        public boolean hasEnableTranscoding() {
            return (this.bitField0_ & 1) != 0;
        }

        public boolean hasEnabled() {
            return (this.bitField0_ & 2) != 0;
        }

        public boolean hasState() {
            return this.state_ != null;
        }

        public boolean hasVideo() {
            return this.video_ != null;
        }

        public static Builder newBuilder(IngressInfo ingressInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(ingressInfo);
        }

        public static IngressInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static IngressInfo parseFrom(ByteString byteString) {
            return (IngressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static IngressInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static IngressInfo parseFrom(byte[] bArr) {
            return (IngressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static IngressInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static IngressInfo parseFrom(InputStream inputStream) {
            return (IngressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressInfo parseFrom(CodedInputStream codedInputStream) {
            return (IngressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static IngressInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface IngressInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum IngressInput implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<IngressInput>() { // from class: livekit.LivekitIngress.IngressInput.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public IngressInput findValueByNumber(int i) {
                return IngressInput.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class IngressInputVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new IngressInputVerifier();

            private IngressInputVerifier() {
            }

            public boolean isInRange(int i) {
                return IngressInput.b(i) != null;
            }
        }

        IngressInput(int i) {
            this.a = i;
        }

        public static IngressInput b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class IngressState extends GeneratedMessageLite<IngressState, Builder> implements IngressStateOrBuilder {
        public static final int AUDIO_FIELD_NUMBER = 4;
        private static final IngressState DEFAULT_INSTANCE;
        public static final int ENDED_AT_FIELD_NUMBER = 8;
        public static final int ERROR_FIELD_NUMBER = 2;
        private static volatile Parser<IngressState> PARSER = null;
        public static final int RESOURCE_ID_FIELD_NUMBER = 9;
        public static final int ROOM_ID_FIELD_NUMBER = 5;
        public static final int STARTED_AT_FIELD_NUMBER = 7;
        public static final int STATUS_FIELD_NUMBER = 1;
        public static final int TRACKS_FIELD_NUMBER = 6;
        public static final int UPDATED_AT_FIELD_NUMBER = 10;
        public static final int VIDEO_FIELD_NUMBER = 3;
        private InputAudioState audio_;
        private long endedAt_;
        private String error_;
        private String resourceId_;
        private String roomId_;
        private long startedAt_;
        private int status_;
        private Internal.ProtobufList<LivekitModels.TrackInfo> tracks_;
        private long updatedAt_;
        private InputVideoState video_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<IngressState, Builder> implements IngressStateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(IngressState.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum Status implements Internal.EnumLite {
            b(0),
            c(1),
            d(2),
            e(3),
            f(4),
            g(-1);

            private static final Internal.EnumLiteMap h = new Internal.EnumLiteMap<Status>() { // from class: livekit.LivekitIngress.IngressState.Status.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public Status findValueByNumber(int i2) {
                    return Status.b(i2);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class StatusVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new StatusVerifier();

                private StatusVerifier() {
                }

                public boolean isInRange(int i) {
                    return Status.b(i) != null;
                }
            }

            Status(int i2) {
                this.a = i2;
            }

            public static Status b(int i2) {
                if (i2 == 0) {
                    return b;
                }
                if (i2 == 1) {
                    return c;
                }
                if (i2 == 2) {
                    return d;
                }
                if (i2 == 3) {
                    return e;
                }
                if (i2 != 4) {
                    return null;
                }
                return f;
            }

            public final int getNumber() {
                if (this != g) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        static {
            IngressState ingressState = new IngressState();
            DEFAULT_INSTANCE = ingressState;
            GeneratedMessageLite.registerDefaultInstance(IngressState.class, ingressState);
        }

        private IngressState() {
            String strA = ap.a(1101687086);
            this.error_ = strA;
            this.roomId_ = strA;
            this.resourceId_ = strA;
            this.tracks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllTracks(Iterable<? extends LivekitModels.TrackInfo> iterable) {
            ensureTracksIsMutable();
            AbstractMessageLite.addAll(iterable, this.tracks_);
        }

        private void addTracks(LivekitModels.TrackInfo trackInfo) {
            trackInfo.getClass();
            ensureTracksIsMutable();
            this.tracks_.add(trackInfo);
        }

        private void clearAudio() {
            this.audio_ = null;
        }

        private void clearEndedAt() {
            this.endedAt_ = 0L;
        }

        private void clearError() {
            this.error_ = getDefaultInstance().getError();
        }

        private void clearResourceId() {
            this.resourceId_ = getDefaultInstance().getResourceId();
        }

        private void clearRoomId() {
            this.roomId_ = getDefaultInstance().getRoomId();
        }

        private void clearStartedAt() {
            this.startedAt_ = 0L;
        }

        private void clearStatus() {
            this.status_ = 0;
        }

        private void clearTracks() {
            this.tracks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearUpdatedAt() {
            this.updatedAt_ = 0L;
        }

        private void clearVideo() {
            this.video_ = null;
        }

        private void ensureTracksIsMutable() {
            Internal.ProtobufList<LivekitModels.TrackInfo> protobufList = this.tracks_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.tracks_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static IngressState getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAudio(InputAudioState inputAudioState) {
            inputAudioState.getClass();
            InputAudioState inputAudioState2 = this.audio_;
            if (inputAudioState2 == null || inputAudioState2 == InputAudioState.getDefaultInstance()) {
                this.audio_ = inputAudioState;
            } else {
                this.audio_ = (InputAudioState) ((InputAudioState.Builder) InputAudioState.newBuilder(this.audio_).v(inputAudioState)).o();
            }
        }

        private void mergeVideo(InputVideoState inputVideoState) {
            inputVideoState.getClass();
            InputVideoState inputVideoState2 = this.video_;
            if (inputVideoState2 == null || inputVideoState2 == InputVideoState.getDefaultInstance()) {
                this.video_ = inputVideoState;
            } else {
                this.video_ = (InputVideoState) ((InputVideoState.Builder) InputVideoState.newBuilder(this.video_).v(inputVideoState)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static IngressState parseDelimitedFrom(InputStream inputStream) {
            return (IngressState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressState parseFrom(ByteBuffer byteBuffer) {
            return (IngressState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<IngressState> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeTracks(int i) {
            ensureTracksIsMutable();
            this.tracks_.remove(i);
        }

        private void setAudio(InputAudioState inputAudioState) {
            inputAudioState.getClass();
            this.audio_ = inputAudioState;
        }

        private void setEndedAt(long j) {
            this.endedAt_ = j;
        }

        private void setError(String str) {
            str.getClass();
            this.error_ = str;
        }

        private void setErrorBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.error_ = byteString.L();
        }

        private void setResourceId(String str) {
            str.getClass();
            this.resourceId_ = str;
        }

        private void setResourceIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.resourceId_ = byteString.L();
        }

        private void setRoomId(String str) {
            str.getClass();
            this.roomId_ = str;
        }

        private void setRoomIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomId_ = byteString.L();
        }

        private void setStartedAt(long j) {
            this.startedAt_ = j;
        }

        private void setStatus(Status status) {
            this.status_ = status.getNumber();
        }

        private void setStatusValue(int i) {
            this.status_ = i;
        }

        private void setTracks(int i, LivekitModels.TrackInfo trackInfo) {
            trackInfo.getClass();
            ensureTracksIsMutable();
            this.tracks_.set(i, trackInfo);
        }

        private void setUpdatedAt(long j) {
            this.updatedAt_ = j;
        }

        private void setVideo(InputVideoState inputVideoState) {
            inputVideoState.getClass();
            this.video_ = inputVideoState;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new IngressState();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\n\u0000\u0000\u0001\n\n\u0000\u0001\u0000\u0001\f\u0002Ȉ\u0003\t\u0004\t\u0005Ȉ\u0006\u001b\u0007\u0002\b\u0002\tȈ\n\u0002", new Object[]{"status_", "error_", "video_", "audio_", "roomId_", "tracks_", LivekitModels.TrackInfo.class, "startedAt_", "endedAt_", "resourceId_", "updatedAt_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<IngressState> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (IngressState.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public InputAudioState getAudio() {
            InputAudioState inputAudioState = this.audio_;
            return inputAudioState == null ? InputAudioState.getDefaultInstance() : inputAudioState;
        }

        public long getEndedAt() {
            return this.endedAt_;
        }

        public String getError() {
            return this.error_;
        }

        public ByteString getErrorBytes() {
            return ByteString.n(this.error_);
        }

        public String getResourceId() {
            return this.resourceId_;
        }

        public ByteString getResourceIdBytes() {
            return ByteString.n(this.resourceId_);
        }

        public String getRoomId() {
            return this.roomId_;
        }

        public ByteString getRoomIdBytes() {
            return ByteString.n(this.roomId_);
        }

        public long getStartedAt() {
            return this.startedAt_;
        }

        public Status getStatus() {
            Status statusB = Status.b(this.status_);
            return statusB == null ? Status.g : statusB;
        }

        public int getStatusValue() {
            return this.status_;
        }

        public LivekitModels.TrackInfo getTracks(int i) {
            return (LivekitModels.TrackInfo) this.tracks_.get(i);
        }

        public int getTracksCount() {
            return this.tracks_.size();
        }

        public List<LivekitModels.TrackInfo> getTracksList() {
            return this.tracks_;
        }

        public LivekitModels.TrackInfoOrBuilder getTracksOrBuilder(int i) {
            return (LivekitModels.TrackInfoOrBuilder) this.tracks_.get(i);
        }

        public List<? extends LivekitModels.TrackInfoOrBuilder> getTracksOrBuilderList() {
            return this.tracks_;
        }

        public long getUpdatedAt() {
            return this.updatedAt_;
        }

        public InputVideoState getVideo() {
            InputVideoState inputVideoState = this.video_;
            return inputVideoState == null ? InputVideoState.getDefaultInstance() : inputVideoState;
        }

        public boolean hasAudio() {
            return this.audio_ != null;
        }

        public boolean hasVideo() {
            return this.video_ != null;
        }

        public static Builder newBuilder(IngressState ingressState) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(ingressState);
        }

        public static IngressState parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressState parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static IngressState parseFrom(ByteString byteString) {
            return (IngressState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addTracks(int i, LivekitModels.TrackInfo trackInfo) {
            trackInfo.getClass();
            ensureTracksIsMutable();
            this.tracks_.add(i, trackInfo);
        }

        public static IngressState parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static IngressState parseFrom(byte[] bArr) {
            return (IngressState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static IngressState parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static IngressState parseFrom(InputStream inputStream) {
            return (IngressState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressState parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressState parseFrom(CodedInputStream codedInputStream) {
            return (IngressState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static IngressState parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface IngressStateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class IngressVideoEncodingOptions extends GeneratedMessageLite<IngressVideoEncodingOptions, Builder> implements IngressVideoEncodingOptionsOrBuilder {
        private static final IngressVideoEncodingOptions DEFAULT_INSTANCE;
        public static final int FRAME_RATE_FIELD_NUMBER = 2;
        public static final int LAYERS_FIELD_NUMBER = 3;
        private static volatile Parser<IngressVideoEncodingOptions> PARSER = null;
        public static final int VIDEO_CODEC_FIELD_NUMBER = 1;
        private double frameRate_;
        private Internal.ProtobufList<LivekitModels.VideoLayer> layers_ = GeneratedMessageLite.emptyProtobufList();
        private int videoCodec_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<IngressVideoEncodingOptions, Builder> implements IngressVideoEncodingOptionsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(IngressVideoEncodingOptions.DEFAULT_INSTANCE);
            }
        }

        static {
            IngressVideoEncodingOptions ingressVideoEncodingOptions = new IngressVideoEncodingOptions();
            DEFAULT_INSTANCE = ingressVideoEncodingOptions;
            GeneratedMessageLite.registerDefaultInstance(IngressVideoEncodingOptions.class, ingressVideoEncodingOptions);
        }

        private IngressVideoEncodingOptions() {
        }

        private void addAllLayers(Iterable<? extends LivekitModels.VideoLayer> iterable) {
            ensureLayersIsMutable();
            AbstractMessageLite.addAll(iterable, this.layers_);
        }

        private void addLayers(LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(videoLayer);
        }

        private void clearFrameRate() {
            this.frameRate_ = 0.0d;
        }

        private void clearLayers() {
            this.layers_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearVideoCodec() {
            this.videoCodec_ = 0;
        }

        private void ensureLayersIsMutable() {
            Internal.ProtobufList<LivekitModels.VideoLayer> protobufList = this.layers_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.layers_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static IngressVideoEncodingOptions getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static IngressVideoEncodingOptions parseDelimitedFrom(InputStream inputStream) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressVideoEncodingOptions parseFrom(ByteBuffer byteBuffer) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<IngressVideoEncodingOptions> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeLayers(int i) {
            ensureLayersIsMutable();
            this.layers_.remove(i);
        }

        private void setFrameRate(double d) {
            this.frameRate_ = d;
        }

        private void setLayers(int i, LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.set(i, videoLayer);
        }

        private void setVideoCodec(LivekitModels.VideoCodec videoCodec) {
            this.videoCodec_ = videoCodec.getNumber();
        }

        private void setVideoCodecValue(int i) {
            this.videoCodec_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new IngressVideoEncodingOptions();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0001\u0000\u0001\f\u0002\u0000\u0003\u001b", new Object[]{ap.a(217586675), ap.a(1048455683), ap.a(37640473), LivekitModels.VideoLayer.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<IngressVideoEncodingOptions> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (IngressVideoEncodingOptions.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public double getFrameRate() {
            return this.frameRate_;
        }

        public LivekitModels.VideoLayer getLayers(int i) {
            return (LivekitModels.VideoLayer) this.layers_.get(i);
        }

        public int getLayersCount() {
            return this.layers_.size();
        }

        public List<LivekitModels.VideoLayer> getLayersList() {
            return this.layers_;
        }

        public LivekitModels.VideoLayerOrBuilder getLayersOrBuilder(int i) {
            return (LivekitModels.VideoLayerOrBuilder) this.layers_.get(i);
        }

        public List<? extends LivekitModels.VideoLayerOrBuilder> getLayersOrBuilderList() {
            return this.layers_;
        }

        public LivekitModels.VideoCodec getVideoCodec() {
            LivekitModels.VideoCodec videoCodecB = LivekitModels.VideoCodec.b(this.videoCodec_);
            return videoCodecB == null ? LivekitModels.VideoCodec.g : videoCodecB;
        }

        public int getVideoCodecValue() {
            return this.videoCodec_;
        }

        public static Builder newBuilder(IngressVideoEncodingOptions ingressVideoEncodingOptions) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(ingressVideoEncodingOptions);
        }

        public static IngressVideoEncodingOptions parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressVideoEncodingOptions parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static IngressVideoEncodingOptions parseFrom(ByteString byteString) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addLayers(int i, LivekitModels.VideoLayer videoLayer) {
            videoLayer.getClass();
            ensureLayersIsMutable();
            this.layers_.add(i, videoLayer);
        }

        public static IngressVideoEncodingOptions parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static IngressVideoEncodingOptions parseFrom(byte[] bArr) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static IngressVideoEncodingOptions parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static IngressVideoEncodingOptions parseFrom(InputStream inputStream) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressVideoEncodingOptions parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressVideoEncodingOptions parseFrom(CodedInputStream codedInputStream) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static IngressVideoEncodingOptions parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoEncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface IngressVideoEncodingOptionsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum IngressVideoEncodingPreset implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(4),
        g(5),
        h(6),
        i(7),
        j(8),
        k(9),
        l(-1);

        private static final Internal.EnumLiteMap m = new Internal.EnumLiteMap<IngressVideoEncodingPreset>() { // from class: livekit.LivekitIngress.IngressVideoEncodingPreset.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public IngressVideoEncodingPreset findValueByNumber(int i2) {
                return IngressVideoEncodingPreset.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class IngressVideoEncodingPresetVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new IngressVideoEncodingPresetVerifier();

            private IngressVideoEncodingPresetVerifier() {
            }

            public boolean isInRange(int i) {
                return IngressVideoEncodingPreset.b(i) != null;
            }
        }

        IngressVideoEncodingPreset(int i2) {
            this.a = i2;
        }

        public static IngressVideoEncodingPreset b(int i2) {
            switch (i2) {
                case 0:
                    return b;
                case 1:
                    return c;
                case 2:
                    return d;
                case 3:
                    return e;
                case 4:
                    return f;
                case 5:
                    return g;
                case 6:
                    return h;
                case 7:
                    return i;
                case 8:
                    return j;
                case 9:
                    return k;
                default:
                    return null;
            }
        }

        public final int getNumber() {
            if (this != l) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class IngressVideoOptions extends GeneratedMessageLite<IngressVideoOptions, Builder> implements IngressVideoOptionsOrBuilder {
        private static final IngressVideoOptions DEFAULT_INSTANCE;
        public static final int NAME_FIELD_NUMBER = 1;
        public static final int OPTIONS_FIELD_NUMBER = 4;
        private static volatile Parser<IngressVideoOptions> PARSER = null;
        public static final int PRESET_FIELD_NUMBER = 3;
        public static final int SOURCE_FIELD_NUMBER = 2;
        private Object encodingOptions_;
        private int source_;
        private int encodingOptionsCase_ = 0;
        private String name_ = ap.a(498781809);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<IngressVideoOptions, Builder> implements IngressVideoOptionsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(IngressVideoOptions.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum EncodingOptionsCase {
            b(3),
            c(4),
            d(0);

            private final int a;

            EncodingOptionsCase(int i) {
                this.a = i;
            }

            public static EncodingOptionsCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 3) {
                    return b;
                }
                if (i != 4) {
                    return null;
                }
                return c;
            }
        }

        static {
            IngressVideoOptions ingressVideoOptions = new IngressVideoOptions();
            DEFAULT_INSTANCE = ingressVideoOptions;
            GeneratedMessageLite.registerDefaultInstance(IngressVideoOptions.class, ingressVideoOptions);
        }

        private IngressVideoOptions() {
        }

        private void clearEncodingOptions() {
            this.encodingOptionsCase_ = 0;
            this.encodingOptions_ = null;
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearOptions() {
            if (this.encodingOptionsCase_ == 4) {
                this.encodingOptionsCase_ = 0;
                this.encodingOptions_ = null;
            }
        }

        private void clearPreset() {
            if (this.encodingOptionsCase_ == 3) {
                this.encodingOptionsCase_ = 0;
                this.encodingOptions_ = null;
            }
        }

        private void clearSource() {
            this.source_ = 0;
        }

        public static IngressVideoOptions getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeOptions(IngressVideoEncodingOptions ingressVideoEncodingOptions) {
            ingressVideoEncodingOptions.getClass();
            if (this.encodingOptionsCase_ != 4 || this.encodingOptions_ == IngressVideoEncodingOptions.getDefaultInstance()) {
                this.encodingOptions_ = ingressVideoEncodingOptions;
            } else {
                this.encodingOptions_ = ((IngressVideoEncodingOptions.Builder) IngressVideoEncodingOptions.newBuilder((IngressVideoEncodingOptions) this.encodingOptions_).v(ingressVideoEncodingOptions)).o();
            }
            this.encodingOptionsCase_ = 4;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static IngressVideoOptions parseDelimitedFrom(InputStream inputStream) {
            return (IngressVideoOptions) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressVideoOptions parseFrom(ByteBuffer byteBuffer) {
            return (IngressVideoOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<IngressVideoOptions> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setOptions(IngressVideoEncodingOptions ingressVideoEncodingOptions) {
            ingressVideoEncodingOptions.getClass();
            this.encodingOptions_ = ingressVideoEncodingOptions;
            this.encodingOptionsCase_ = 4;
        }

        private void setPreset(IngressVideoEncodingPreset ingressVideoEncodingPreset) {
            this.encodingOptions_ = Integer.valueOf(ingressVideoEncodingPreset.getNumber());
            this.encodingOptionsCase_ = 3;
        }

        private void setPresetValue(int i) {
            this.encodingOptionsCase_ = 3;
            this.encodingOptions_ = Integer.valueOf(i);
        }

        private void setSource(LivekitModels.TrackSource trackSource) {
            this.source_ = trackSource.getNumber();
        }

        private void setSourceValue(int i) {
            this.source_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new IngressVideoOptions();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0001\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001Ȉ\u0002\f\u0003?\u0000\u0004<\u0000", new Object[]{"encodingOptions_", "encodingOptionsCase_", "name_", "source_", IngressVideoEncodingOptions.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<IngressVideoOptions> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (IngressVideoOptions.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public EncodingOptionsCase getEncodingOptionsCase() {
            return EncodingOptionsCase.b(this.encodingOptionsCase_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public IngressVideoEncodingOptions getOptions() {
            return this.encodingOptionsCase_ == 4 ? (IngressVideoEncodingOptions) this.encodingOptions_ : IngressVideoEncodingOptions.getDefaultInstance();
        }

        public IngressVideoEncodingPreset getPreset() {
            if (this.encodingOptionsCase_ != 3) {
                return IngressVideoEncodingPreset.b;
            }
            IngressVideoEncodingPreset ingressVideoEncodingPresetB = IngressVideoEncodingPreset.b(((Integer) this.encodingOptions_).intValue());
            return ingressVideoEncodingPresetB == null ? IngressVideoEncodingPreset.l : ingressVideoEncodingPresetB;
        }

        public int getPresetValue() {
            if (this.encodingOptionsCase_ == 3) {
                return ((Integer) this.encodingOptions_).intValue();
            }
            return 0;
        }

        public LivekitModels.TrackSource getSource() {
            LivekitModels.TrackSource trackSourceB = LivekitModels.TrackSource.b(this.source_);
            return trackSourceB == null ? LivekitModels.TrackSource.g : trackSourceB;
        }

        public int getSourceValue() {
            return this.source_;
        }

        public boolean hasOptions() {
            return this.encodingOptionsCase_ == 4;
        }

        public boolean hasPreset() {
            return this.encodingOptionsCase_ == 3;
        }

        public static Builder newBuilder(IngressVideoOptions ingressVideoOptions) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(ingressVideoOptions);
        }

        public static IngressVideoOptions parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoOptions) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressVideoOptions parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static IngressVideoOptions parseFrom(ByteString byteString) {
            return (IngressVideoOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static IngressVideoOptions parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static IngressVideoOptions parseFrom(byte[] bArr) {
            return (IngressVideoOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static IngressVideoOptions parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static IngressVideoOptions parseFrom(InputStream inputStream) {
            return (IngressVideoOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static IngressVideoOptions parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static IngressVideoOptions parseFrom(CodedInputStream codedInputStream) {
            return (IngressVideoOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static IngressVideoOptions parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (IngressVideoOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface IngressVideoOptionsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class InputAudioState extends GeneratedMessageLite<InputAudioState, Builder> implements InputAudioStateOrBuilder {
        public static final int AVERAGE_BITRATE_FIELD_NUMBER = 2;
        public static final int CHANNELS_FIELD_NUMBER = 3;
        private static final InputAudioState DEFAULT_INSTANCE;
        public static final int MIME_TYPE_FIELD_NUMBER = 1;
        private static volatile Parser<InputAudioState> PARSER = null;
        public static final int SAMPLE_RATE_FIELD_NUMBER = 4;
        private int averageBitrate_;
        private int channels_;
        private String mimeType_ = ap.a(149426170);
        private int sampleRate_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<InputAudioState, Builder> implements InputAudioStateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(InputAudioState.DEFAULT_INSTANCE);
            }
        }

        static {
            InputAudioState inputAudioState = new InputAudioState();
            DEFAULT_INSTANCE = inputAudioState;
            GeneratedMessageLite.registerDefaultInstance(InputAudioState.class, inputAudioState);
        }

        private InputAudioState() {
        }

        private void clearAverageBitrate() {
            this.averageBitrate_ = 0;
        }

        private void clearChannels() {
            this.channels_ = 0;
        }

        private void clearMimeType() {
            this.mimeType_ = getDefaultInstance().getMimeType();
        }

        private void clearSampleRate() {
            this.sampleRate_ = 0;
        }

        public static InputAudioState getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static InputAudioState parseDelimitedFrom(InputStream inputStream) {
            return (InputAudioState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static InputAudioState parseFrom(ByteBuffer byteBuffer) {
            return (InputAudioState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<InputAudioState> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAverageBitrate(int i) {
            this.averageBitrate_ = i;
        }

        private void setChannels(int i) {
            this.channels_ = i;
        }

        private void setMimeType(String str) {
            str.getClass();
            this.mimeType_ = str;
        }

        private void setMimeTypeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.mimeType_ = byteString.L();
        }

        private void setSampleRate(int i) {
            this.sampleRate_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new InputAudioState();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001Ȉ\u0002\u000b\u0003\u000b\u0004\u000b", new Object[]{"mimeType_", "averageBitrate_", "channels_", "sampleRate_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<InputAudioState> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (InputAudioState.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getAverageBitrate() {
            return this.averageBitrate_;
        }

        public int getChannels() {
            return this.channels_;
        }

        public String getMimeType() {
            return this.mimeType_;
        }

        public ByteString getMimeTypeBytes() {
            return ByteString.n(this.mimeType_);
        }

        public int getSampleRate() {
            return this.sampleRate_;
        }

        public static Builder newBuilder(InputAudioState inputAudioState) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(inputAudioState);
        }

        public static InputAudioState parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (InputAudioState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static InputAudioState parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (InputAudioState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static InputAudioState parseFrom(ByteString byteString) {
            return (InputAudioState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static InputAudioState parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (InputAudioState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static InputAudioState parseFrom(byte[] bArr) {
            return (InputAudioState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static InputAudioState parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (InputAudioState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static InputAudioState parseFrom(InputStream inputStream) {
            return (InputAudioState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static InputAudioState parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (InputAudioState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static InputAudioState parseFrom(CodedInputStream codedInputStream) {
            return (InputAudioState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static InputAudioState parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (InputAudioState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface InputAudioStateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class InputVideoState extends GeneratedMessageLite<InputVideoState, Builder> implements InputVideoStateOrBuilder {
        public static final int AVERAGE_BITRATE_FIELD_NUMBER = 2;
        private static final InputVideoState DEFAULT_INSTANCE;
        public static final int FRAMERATE_FIELD_NUMBER = 5;
        public static final int HEIGHT_FIELD_NUMBER = 4;
        public static final int MIME_TYPE_FIELD_NUMBER = 1;
        private static volatile Parser<InputVideoState> PARSER = null;
        public static final int WIDTH_FIELD_NUMBER = 3;
        private int averageBitrate_;
        private double framerate_;
        private int height_;
        private String mimeType_ = ap.a(675379846);
        private int width_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<InputVideoState, Builder> implements InputVideoStateOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(InputVideoState.DEFAULT_INSTANCE);
            }
        }

        static {
            InputVideoState inputVideoState = new InputVideoState();
            DEFAULT_INSTANCE = inputVideoState;
            GeneratedMessageLite.registerDefaultInstance(InputVideoState.class, inputVideoState);
        }

        private InputVideoState() {
        }

        private void clearAverageBitrate() {
            this.averageBitrate_ = 0;
        }

        private void clearFramerate() {
            this.framerate_ = 0.0d;
        }

        private void clearHeight() {
            this.height_ = 0;
        }

        private void clearMimeType() {
            this.mimeType_ = getDefaultInstance().getMimeType();
        }

        private void clearWidth() {
            this.width_ = 0;
        }

        public static InputVideoState getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static InputVideoState parseDelimitedFrom(InputStream inputStream) {
            return (InputVideoState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static InputVideoState parseFrom(ByteBuffer byteBuffer) {
            return (InputVideoState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<InputVideoState> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAverageBitrate(int i) {
            this.averageBitrate_ = i;
        }

        private void setFramerate(double d) {
            this.framerate_ = d;
        }

        private void setHeight(int i) {
            this.height_ = i;
        }

        private void setMimeType(String str) {
            str.getClass();
            this.mimeType_ = str;
        }

        private void setMimeTypeBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.mimeType_ = byteString.L();
        }

        private void setWidth(int i) {
            this.width_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new InputVideoState();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001Ȉ\u0002\u000b\u0003\u000b\u0004\u000b\u0005\u0000", new Object[]{"mimeType_", "averageBitrate_", "width_", "height_", "framerate_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<InputVideoState> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (InputVideoState.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getAverageBitrate() {
            return this.averageBitrate_;
        }

        public double getFramerate() {
            return this.framerate_;
        }

        public int getHeight() {
            return this.height_;
        }

        public String getMimeType() {
            return this.mimeType_;
        }

        public ByteString getMimeTypeBytes() {
            return ByteString.n(this.mimeType_);
        }

        public int getWidth() {
            return this.width_;
        }

        public static Builder newBuilder(InputVideoState inputVideoState) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(inputVideoState);
        }

        public static InputVideoState parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (InputVideoState) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static InputVideoState parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (InputVideoState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static InputVideoState parseFrom(ByteString byteString) {
            return (InputVideoState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static InputVideoState parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (InputVideoState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static InputVideoState parseFrom(byte[] bArr) {
            return (InputVideoState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static InputVideoState parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (InputVideoState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static InputVideoState parseFrom(InputStream inputStream) {
            return (InputVideoState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static InputVideoState parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (InputVideoState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static InputVideoState parseFrom(CodedInputStream codedInputStream) {
            return (InputVideoState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static InputVideoState parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (InputVideoState) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface InputVideoStateOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListIngressRequest extends GeneratedMessageLite<ListIngressRequest, Builder> implements ListIngressRequestOrBuilder {
        private static final ListIngressRequest DEFAULT_INSTANCE;
        public static final int INGRESS_ID_FIELD_NUMBER = 2;
        private static volatile Parser<ListIngressRequest> PARSER = null;
        public static final int ROOM_NAME_FIELD_NUMBER = 1;
        private String ingressId_;
        private String roomName_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListIngressRequest, Builder> implements ListIngressRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListIngressRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListIngressRequest listIngressRequest = new ListIngressRequest();
            DEFAULT_INSTANCE = listIngressRequest;
            GeneratedMessageLite.registerDefaultInstance(ListIngressRequest.class, listIngressRequest);
        }

        private ListIngressRequest() {
            String strA = ap.a(576996501);
            this.roomName_ = strA;
            this.ingressId_ = strA;
        }

        private void clearIngressId() {
            this.ingressId_ = getDefaultInstance().getIngressId();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        public static ListIngressRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListIngressRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListIngressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListIngressRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListIngressRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setIngressId(String str) {
            str.getClass();
            this.ingressId_ = str;
        }

        private void setIngressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.ingressId_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListIngressRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"roomName_", "ingressId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListIngressRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListIngressRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getIngressId() {
            return this.ingressId_;
        }

        public ByteString getIngressIdBytes() {
            return ByteString.n(this.ingressId_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public static Builder newBuilder(ListIngressRequest listIngressRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listIngressRequest);
        }

        public static ListIngressRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListIngressRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListIngressRequest parseFrom(ByteString byteString) {
            return (ListIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListIngressRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListIngressRequest parseFrom(byte[] bArr) {
            return (ListIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListIngressRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListIngressRequest parseFrom(InputStream inputStream) {
            return (ListIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListIngressRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListIngressRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListIngressRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListIngressRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListIngressResponse extends GeneratedMessageLite<ListIngressResponse, Builder> implements ListIngressResponseOrBuilder {
        private static final ListIngressResponse DEFAULT_INSTANCE;
        public static final int ITEMS_FIELD_NUMBER = 1;
        private static volatile Parser<ListIngressResponse> PARSER;
        private Internal.ProtobufList<IngressInfo> items_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListIngressResponse, Builder> implements ListIngressResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListIngressResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListIngressResponse listIngressResponse = new ListIngressResponse();
            DEFAULT_INSTANCE = listIngressResponse;
            GeneratedMessageLite.registerDefaultInstance(ListIngressResponse.class, listIngressResponse);
        }

        private ListIngressResponse() {
        }

        private void addAllItems(Iterable<? extends IngressInfo> iterable) {
            ensureItemsIsMutable();
            AbstractMessageLite.addAll(iterable, this.items_);
        }

        private void addItems(IngressInfo ingressInfo) {
            ingressInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(ingressInfo);
        }

        private void clearItems() {
            this.items_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureItemsIsMutable() {
            Internal.ProtobufList<IngressInfo> protobufList = this.items_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.items_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListIngressResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListIngressResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListIngressResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListIngressResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListIngressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListIngressResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeItems(int i) {
            ensureItemsIsMutable();
            this.items_.remove(i);
        }

        private void setItems(int i, IngressInfo ingressInfo) {
            ingressInfo.getClass();
            ensureItemsIsMutable();
            this.items_.set(i, ingressInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListIngressResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(933436769), IngressInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListIngressResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListIngressResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public IngressInfo getItems(int i) {
            return (IngressInfo) this.items_.get(i);
        }

        public int getItemsCount() {
            return this.items_.size();
        }

        public List<IngressInfo> getItemsList() {
            return this.items_;
        }

        public IngressInfoOrBuilder getItemsOrBuilder(int i) {
            return (IngressInfoOrBuilder) this.items_.get(i);
        }

        public List<? extends IngressInfoOrBuilder> getItemsOrBuilderList() {
            return this.items_;
        }

        public static Builder newBuilder(ListIngressResponse listIngressResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listIngressResponse);
        }

        public static ListIngressResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListIngressResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListIngressResponse parseFrom(ByteString byteString) {
            return (ListIngressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addItems(int i, IngressInfo ingressInfo) {
            ingressInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(i, ingressInfo);
        }

        public static ListIngressResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListIngressResponse parseFrom(byte[] bArr) {
            return (ListIngressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListIngressResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListIngressResponse parseFrom(InputStream inputStream) {
            return (ListIngressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListIngressResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListIngressResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListIngressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListIngressResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListIngressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListIngressResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateIngressRequest extends GeneratedMessageLite<UpdateIngressRequest, Builder> implements UpdateIngressRequestOrBuilder {
        public static final int AUDIO_FIELD_NUMBER = 6;
        public static final int BYPASS_TRANSCODING_FIELD_NUMBER = 8;
        private static final UpdateIngressRequest DEFAULT_INSTANCE;
        public static final int ENABLED_FIELD_NUMBER = 11;
        public static final int ENABLE_TRANSCODING_FIELD_NUMBER = 10;
        public static final int INGRESS_ID_FIELD_NUMBER = 1;
        public static final int NAME_FIELD_NUMBER = 2;
        private static volatile Parser<UpdateIngressRequest> PARSER = null;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 4;
        public static final int PARTICIPANT_METADATA_FIELD_NUMBER = 9;
        public static final int PARTICIPANT_NAME_FIELD_NUMBER = 5;
        public static final int ROOM_NAME_FIELD_NUMBER = 3;
        public static final int VIDEO_FIELD_NUMBER = 7;
        private IngressAudioOptions audio_;
        private int bitField0_;
        private boolean bypassTranscoding_;
        private boolean enableTranscoding_;
        private boolean enabled_;
        private String ingressId_;
        private String name_;
        private String participantIdentity_;
        private String participantMetadata_;
        private String participantName_;
        private String roomName_;
        private IngressVideoOptions video_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateIngressRequest, Builder> implements UpdateIngressRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateIngressRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateIngressRequest updateIngressRequest = new UpdateIngressRequest();
            DEFAULT_INSTANCE = updateIngressRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdateIngressRequest.class, updateIngressRequest);
        }

        private UpdateIngressRequest() {
            String strA = ap.a(355196264);
            this.ingressId_ = strA;
            this.name_ = strA;
            this.roomName_ = strA;
            this.participantIdentity_ = strA;
            this.participantName_ = strA;
            this.participantMetadata_ = strA;
        }

        private void clearAudio() {
            this.audio_ = null;
        }

        private void clearBypassTranscoding() {
            this.bitField0_ &= -2;
            this.bypassTranscoding_ = false;
        }

        private void clearEnableTranscoding() {
            this.bitField0_ &= -3;
            this.enableTranscoding_ = false;
        }

        private void clearEnabled() {
            this.bitField0_ &= -5;
            this.enabled_ = false;
        }

        private void clearIngressId() {
            this.ingressId_ = getDefaultInstance().getIngressId();
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearParticipantIdentity() {
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearParticipantMetadata() {
            this.participantMetadata_ = getDefaultInstance().getParticipantMetadata();
        }

        private void clearParticipantName() {
            this.participantName_ = getDefaultInstance().getParticipantName();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearVideo() {
            this.video_ = null;
        }

        public static UpdateIngressRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAudio(IngressAudioOptions ingressAudioOptions) {
            ingressAudioOptions.getClass();
            IngressAudioOptions ingressAudioOptions2 = this.audio_;
            if (ingressAudioOptions2 == null || ingressAudioOptions2 == IngressAudioOptions.getDefaultInstance()) {
                this.audio_ = ingressAudioOptions;
            } else {
                this.audio_ = (IngressAudioOptions) ((IngressAudioOptions.Builder) IngressAudioOptions.newBuilder(this.audio_).v(ingressAudioOptions)).o();
            }
        }

        private void mergeVideo(IngressVideoOptions ingressVideoOptions) {
            ingressVideoOptions.getClass();
            IngressVideoOptions ingressVideoOptions2 = this.video_;
            if (ingressVideoOptions2 == null || ingressVideoOptions2 == IngressVideoOptions.getDefaultInstance()) {
                this.video_ = ingressVideoOptions;
            } else {
                this.video_ = (IngressVideoOptions) ((IngressVideoOptions.Builder) IngressVideoOptions.newBuilder(this.video_).v(ingressVideoOptions)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateIngressRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateIngressRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateIngressRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAudio(IngressAudioOptions ingressAudioOptions) {
            ingressAudioOptions.getClass();
            this.audio_ = ingressAudioOptions;
        }

        private void setBypassTranscoding(boolean z) {
            this.bitField0_ |= 1;
            this.bypassTranscoding_ = z;
        }

        private void setEnableTranscoding(boolean z) {
            this.bitField0_ |= 2;
            this.enableTranscoding_ = z;
        }

        private void setEnabled(boolean z) {
            this.bitField0_ |= 4;
            this.enabled_ = z;
        }

        private void setIngressId(String str) {
            str.getClass();
            this.ingressId_ = str;
        }

        private void setIngressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.ingressId_ = byteString.L();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
        }

        private void setParticipantMetadata(String str) {
            str.getClass();
            this.participantMetadata_ = str;
        }

        private void setParticipantMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantMetadata_ = byteString.L();
        }

        private void setParticipantName(String str) {
            str.getClass();
            this.participantName_ = str;
        }

        private void setParticipantNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantName_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setVideo(IngressVideoOptions ingressVideoOptions) {
            ingressVideoOptions.getClass();
            this.video_ = ingressVideoOptions;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateIngressRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000b\u0000\u0001\u0001\u000b\u000b\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005Ȉ\u0006\t\u0007\t\bဇ\u0000\tȈ\nဇ\u0001\u000bဇ\u0002", new Object[]{"bitField0_", "ingressId_", "name_", "roomName_", "participantIdentity_", "participantName_", "audio_", "video_", "bypassTranscoding_", "participantMetadata_", "enableTranscoding_", "enabled_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateIngressRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateIngressRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public IngressAudioOptions getAudio() {
            IngressAudioOptions ingressAudioOptions = this.audio_;
            return ingressAudioOptions == null ? IngressAudioOptions.getDefaultInstance() : ingressAudioOptions;
        }

        @Deprecated
        public boolean getBypassTranscoding() {
            return this.bypassTranscoding_;
        }

        public boolean getEnableTranscoding() {
            return this.enableTranscoding_;
        }

        public boolean getEnabled() {
            return this.enabled_;
        }

        public String getIngressId() {
            return this.ingressId_;
        }

        public ByteString getIngressIdBytes() {
            return ByteString.n(this.ingressId_);
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getParticipantMetadata() {
            return this.participantMetadata_;
        }

        public ByteString getParticipantMetadataBytes() {
            return ByteString.n(this.participantMetadata_);
        }

        public String getParticipantName() {
            return this.participantName_;
        }

        public ByteString getParticipantNameBytes() {
            return ByteString.n(this.participantName_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public IngressVideoOptions getVideo() {
            IngressVideoOptions ingressVideoOptions = this.video_;
            return ingressVideoOptions == null ? IngressVideoOptions.getDefaultInstance() : ingressVideoOptions;
        }

        public boolean hasAudio() {
            return this.audio_ != null;
        }

        @Deprecated
        public boolean hasBypassTranscoding() {
            return (this.bitField0_ & 1) != 0;
        }

        public boolean hasEnableTranscoding() {
            return (this.bitField0_ & 2) != 0;
        }

        public boolean hasEnabled() {
            return (this.bitField0_ & 4) != 0;
        }

        public boolean hasVideo() {
            return this.video_ != null;
        }

        public static Builder newBuilder(UpdateIngressRequest updateIngressRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateIngressRequest);
        }

        public static UpdateIngressRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateIngressRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateIngressRequest parseFrom(ByteString byteString) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateIngressRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateIngressRequest parseFrom(byte[] bArr) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateIngressRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateIngressRequest parseFrom(InputStream inputStream) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateIngressRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateIngressRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateIngressRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateIngressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateIngressRequestOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitIngress() {
    }
}