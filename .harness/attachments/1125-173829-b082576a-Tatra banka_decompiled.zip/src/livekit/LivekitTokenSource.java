package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.MapEntryLite;
import com.google.protobuf.MapFieldLite;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import com.google.protobuf.WireFormat;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Map;
import livekit.LivekitRoom;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitTokenSource {

    /* JADX INFO: renamed from: livekit.LivekitTokenSource$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TokenSourceRequest extends GeneratedMessageLite<TokenSourceRequest, Builder> implements TokenSourceRequestOrBuilder {
        private static final TokenSourceRequest DEFAULT_INSTANCE;
        private static volatile Parser<TokenSourceRequest> PARSER = null;
        public static final int PARTICIPANT_ATTRIBUTES_FIELD_NUMBER = 5;
        public static final int PARTICIPANT_IDENTITY_FIELD_NUMBER = 3;
        public static final int PARTICIPANT_METADATA_FIELD_NUMBER = 4;
        public static final int PARTICIPANT_NAME_FIELD_NUMBER = 2;
        public static final int ROOM_CONFIG_FIELD_NUMBER = 6;
        public static final int ROOM_NAME_FIELD_NUMBER = 1;
        private int bitField0_;
        private MapFieldLite<String, String> participantAttributes_ = MapFieldLite.f();
        private String participantIdentity_;
        private String participantMetadata_;
        private String participantName_;
        private LivekitRoom.RoomConfiguration roomConfig_;
        private String roomName_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TokenSourceRequest, Builder> implements TokenSourceRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TokenSourceRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class ParticipantAttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(1502005594);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private ParticipantAttributesDefaultEntryHolder() {
            }
        }

        static {
            TokenSourceRequest tokenSourceRequest = new TokenSourceRequest();
            DEFAULT_INSTANCE = tokenSourceRequest;
            GeneratedMessageLite.registerDefaultInstance(TokenSourceRequest.class, tokenSourceRequest);
        }

        private TokenSourceRequest() {
            String strA = ap.a(174672881);
            this.roomName_ = strA;
            this.participantName_ = strA;
            this.participantIdentity_ = strA;
            this.participantMetadata_ = strA;
        }

        private void clearParticipantIdentity() {
            this.bitField0_ &= -5;
            this.participantIdentity_ = getDefaultInstance().getParticipantIdentity();
        }

        private void clearParticipantMetadata() {
            this.bitField0_ &= -9;
            this.participantMetadata_ = getDefaultInstance().getParticipantMetadata();
        }

        private void clearParticipantName() {
            this.bitField0_ &= -3;
            this.participantName_ = getDefaultInstance().getParticipantName();
        }

        private void clearRoomConfig() {
            this.roomConfig_ = null;
            this.bitField0_ &= -17;
        }

        private void clearRoomName() {
            this.bitField0_ &= -2;
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        public static TokenSourceRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableParticipantAttributesMap() {
            return internalGetMutableParticipantAttributes();
        }

        private MapFieldLite<String, String> internalGetMutableParticipantAttributes() {
            if (!this.participantAttributes_.k()) {
                this.participantAttributes_ = this.participantAttributes_.n();
            }
            return this.participantAttributes_;
        }

        private MapFieldLite<String, String> internalGetParticipantAttributes() {
            return this.participantAttributes_;
        }

        private void mergeRoomConfig(LivekitRoom.RoomConfiguration roomConfiguration) {
            roomConfiguration.getClass();
            LivekitRoom.RoomConfiguration roomConfiguration2 = this.roomConfig_;
            if (roomConfiguration2 == null || roomConfiguration2 == LivekitRoom.RoomConfiguration.getDefaultInstance()) {
                this.roomConfig_ = roomConfiguration;
            } else {
                this.roomConfig_ = (LivekitRoom.RoomConfiguration) ((LivekitRoom.RoomConfiguration.Builder) LivekitRoom.RoomConfiguration.newBuilder(this.roomConfig_).v(roomConfiguration)).o();
            }
            this.bitField0_ |= 16;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TokenSourceRequest parseDelimitedFrom(InputStream inputStream) {
            return (TokenSourceRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TokenSourceRequest parseFrom(ByteBuffer byteBuffer) {
            return (TokenSourceRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TokenSourceRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setParticipantIdentity(String str) {
            str.getClass();
            this.bitField0_ |= 4;
            this.participantIdentity_ = str;
        }

        private void setParticipantIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantIdentity_ = byteString.L();
            this.bitField0_ |= 4;
        }

        private void setParticipantMetadata(String str) {
            str.getClass();
            this.bitField0_ |= 8;
            this.participantMetadata_ = str;
        }

        private void setParticipantMetadataBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantMetadata_ = byteString.L();
            this.bitField0_ |= 8;
        }

        private void setParticipantName(String str) {
            str.getClass();
            this.bitField0_ |= 2;
            this.participantName_ = str;
        }

        private void setParticipantNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantName_ = byteString.L();
            this.bitField0_ |= 2;
        }

        private void setRoomConfig(LivekitRoom.RoomConfiguration roomConfiguration) {
            roomConfiguration.getClass();
            this.roomConfig_ = roomConfiguration;
            this.bitField0_ |= 16;
        }

        private void setRoomName(String str) {
            str.getClass();
            this.bitField0_ |= 1;
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
            this.bitField0_ |= 1;
        }

        public boolean containsParticipantAttributes(String str) {
            str.getClass();
            return internalGetParticipantAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TokenSourceRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0001\u0001\u0006\u0006\u0001\u0000\u0000\u0001ለ\u0000\u0002ለ\u0001\u0003ለ\u0002\u0004ለ\u0003\u00052\u0006ဉ\u0004", new Object[]{"bitField0_", "roomName_", "participantName_", "participantIdentity_", "participantMetadata_", "participantAttributes_", ParticipantAttributesDefaultEntryHolder.a, "roomConfig_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TokenSourceRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TokenSourceRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public Map<String, String> getParticipantAttributes() {
            return getParticipantAttributesMap();
        }

        public int getParticipantAttributesCount() {
            return internalGetParticipantAttributes().size();
        }

        public Map<String, String> getParticipantAttributesMap() {
            return Collections.unmodifiableMap(internalGetParticipantAttributes());
        }

        public String getParticipantAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetParticipantAttributes = internalGetParticipantAttributes();
            return mapFieldLiteInternalGetParticipantAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetParticipantAttributes.get(str) : str2;
        }

        public String getParticipantAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetParticipantAttributes = internalGetParticipantAttributes();
            if (mapFieldLiteInternalGetParticipantAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetParticipantAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public String getParticipantIdentity() {
            return this.participantIdentity_;
        }

        public ByteString getParticipantIdentityBytes() {
            return ByteString.n(this.participantIdentity_);
        }

        public String getParticipantMetadata() {
            return this.participantMetadata_;
        }

        public ByteString getParticipantMetadataBytes() {
            return ByteString.n(this.participantMetadata_);
        }

        public String getParticipantName() {
            return this.participantName_;
        }

        public ByteString getParticipantNameBytes() {
            return ByteString.n(this.participantName_);
        }

        public LivekitRoom.RoomConfiguration getRoomConfig() {
            LivekitRoom.RoomConfiguration roomConfiguration = this.roomConfig_;
            return roomConfiguration == null ? LivekitRoom.RoomConfiguration.getDefaultInstance() : roomConfiguration;
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public boolean hasParticipantIdentity() {
            return (this.bitField0_ & 4) != 0;
        }

        public boolean hasParticipantMetadata() {
            return (this.bitField0_ & 8) != 0;
        }

        public boolean hasParticipantName() {
            return (this.bitField0_ & 2) != 0;
        }

        public boolean hasRoomConfig() {
            return (this.bitField0_ & 16) != 0;
        }

        public boolean hasRoomName() {
            return (this.bitField0_ & 1) != 0;
        }

        public static Builder newBuilder(TokenSourceRequest tokenSourceRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(tokenSourceRequest);
        }

        public static TokenSourceRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TokenSourceRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TokenSourceRequest parseFrom(ByteString byteString) {
            return (TokenSourceRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TokenSourceRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TokenSourceRequest parseFrom(byte[] bArr) {
            return (TokenSourceRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TokenSourceRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TokenSourceRequest parseFrom(InputStream inputStream) {
            return (TokenSourceRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TokenSourceRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TokenSourceRequest parseFrom(CodedInputStream codedInputStream) {
            return (TokenSourceRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TokenSourceRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TokenSourceRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TokenSourceResponse extends GeneratedMessageLite<TokenSourceResponse, Builder> implements TokenSourceResponseOrBuilder {
        private static final TokenSourceResponse DEFAULT_INSTANCE;
        private static volatile Parser<TokenSourceResponse> PARSER = null;
        public static final int PARTICIPANT_TOKEN_FIELD_NUMBER = 2;
        public static final int SERVER_URL_FIELD_NUMBER = 1;
        private String participantToken_;
        private String serverUrl_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TokenSourceResponse, Builder> implements TokenSourceResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TokenSourceResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            TokenSourceResponse tokenSourceResponse = new TokenSourceResponse();
            DEFAULT_INSTANCE = tokenSourceResponse;
            GeneratedMessageLite.registerDefaultInstance(TokenSourceResponse.class, tokenSourceResponse);
        }

        private TokenSourceResponse() {
            String strA = ap.a(1599862899);
            this.serverUrl_ = strA;
            this.participantToken_ = strA;
        }

        private void clearParticipantToken() {
            this.participantToken_ = getDefaultInstance().getParticipantToken();
        }

        private void clearServerUrl() {
            this.serverUrl_ = getDefaultInstance().getServerUrl();
        }

        public static TokenSourceResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TokenSourceResponse parseDelimitedFrom(InputStream inputStream) {
            return (TokenSourceResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TokenSourceResponse parseFrom(ByteBuffer byteBuffer) {
            return (TokenSourceResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TokenSourceResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setParticipantToken(String str) {
            str.getClass();
            this.participantToken_ = str;
        }

        private void setParticipantTokenBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.participantToken_ = byteString.L();
        }

        private void setServerUrl(String str) {
            str.getClass();
            this.serverUrl_ = str;
        }

        private void setServerUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.serverUrl_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TokenSourceResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"serverUrl_", "participantToken_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TokenSourceResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TokenSourceResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getParticipantToken() {
            return this.participantToken_;
        }

        public ByteString getParticipantTokenBytes() {
            return ByteString.n(this.participantToken_);
        }

        public String getServerUrl() {
            return this.serverUrl_;
        }

        public ByteString getServerUrlBytes() {
            return ByteString.n(this.serverUrl_);
        }

        public static Builder newBuilder(TokenSourceResponse tokenSourceResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(tokenSourceResponse);
        }

        public static TokenSourceResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TokenSourceResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TokenSourceResponse parseFrom(ByteString byteString) {
            return (TokenSourceResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static TokenSourceResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TokenSourceResponse parseFrom(byte[] bArr) {
            return (TokenSourceResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TokenSourceResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TokenSourceResponse parseFrom(InputStream inputStream) {
            return (TokenSourceResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TokenSourceResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TokenSourceResponse parseFrom(CodedInputStream codedInputStream) {
            return (TokenSourceResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TokenSourceResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TokenSourceResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TokenSourceResponseOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitTokenSource() {
    }
}