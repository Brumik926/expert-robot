package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MapEntryLite;
import com.google.protobuf.MapFieldLite;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import com.google.protobuf.WireFormat;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import livekit.LivekitModels;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitEgress {

    /* JADX INFO: renamed from: livekit.LivekitEgress$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AliOSSUpload extends GeneratedMessageLite<AliOSSUpload, Builder> implements AliOSSUploadOrBuilder {
        public static final int ACCESS_KEY_FIELD_NUMBER = 1;
        public static final int BUCKET_FIELD_NUMBER = 5;
        private static final AliOSSUpload DEFAULT_INSTANCE;
        public static final int ENDPOINT_FIELD_NUMBER = 4;
        private static volatile Parser<AliOSSUpload> PARSER = null;
        public static final int REGION_FIELD_NUMBER = 3;
        public static final int SECRET_FIELD_NUMBER = 2;
        private String accessKey_;
        private String bucket_;
        private String endpoint_;
        private String region_;
        private String secret_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AliOSSUpload, Builder> implements AliOSSUploadOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AliOSSUpload.DEFAULT_INSTANCE);
            }
        }

        static {
            AliOSSUpload aliOSSUpload = new AliOSSUpload();
            DEFAULT_INSTANCE = aliOSSUpload;
            GeneratedMessageLite.registerDefaultInstance(AliOSSUpload.class, aliOSSUpload);
        }

        private AliOSSUpload() {
            String strA = ap.a(673933506);
            this.accessKey_ = strA;
            this.secret_ = strA;
            this.region_ = strA;
            this.endpoint_ = strA;
            this.bucket_ = strA;
        }

        private void clearAccessKey() {
            this.accessKey_ = getDefaultInstance().getAccessKey();
        }

        private void clearBucket() {
            this.bucket_ = getDefaultInstance().getBucket();
        }

        private void clearEndpoint() {
            this.endpoint_ = getDefaultInstance().getEndpoint();
        }

        private void clearRegion() {
            this.region_ = getDefaultInstance().getRegion();
        }

        private void clearSecret() {
            this.secret_ = getDefaultInstance().getSecret();
        }

        public static AliOSSUpload getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AliOSSUpload parseDelimitedFrom(InputStream inputStream) {
            return (AliOSSUpload) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AliOSSUpload parseFrom(ByteBuffer byteBuffer) {
            return (AliOSSUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AliOSSUpload> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAccessKey(String str) {
            str.getClass();
            this.accessKey_ = str;
        }

        private void setAccessKeyBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.accessKey_ = byteString.L();
        }

        private void setBucket(String str) {
            str.getClass();
            this.bucket_ = str;
        }

        private void setBucketBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.bucket_ = byteString.L();
        }

        private void setEndpoint(String str) {
            str.getClass();
            this.endpoint_ = str;
        }

        private void setEndpointBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.endpoint_ = byteString.L();
        }

        private void setRegion(String str) {
            str.getClass();
            this.region_ = str;
        }

        private void setRegionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.region_ = byteString.L();
        }

        private void setSecret(String str) {
            str.getClass();
            this.secret_ = str;
        }

        private void setSecretBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.secret_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AliOSSUpload();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005Ȉ", new Object[]{"accessKey_", "secret_", "region_", "endpoint_", "bucket_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AliOSSUpload> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AliOSSUpload.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAccessKey() {
            return this.accessKey_;
        }

        public ByteString getAccessKeyBytes() {
            return ByteString.n(this.accessKey_);
        }

        public String getBucket() {
            return this.bucket_;
        }

        public ByteString getBucketBytes() {
            return ByteString.n(this.bucket_);
        }

        public String getEndpoint() {
            return this.endpoint_;
        }

        public ByteString getEndpointBytes() {
            return ByteString.n(this.endpoint_);
        }

        public String getRegion() {
            return this.region_;
        }

        public ByteString getRegionBytes() {
            return ByteString.n(this.region_);
        }

        public String getSecret() {
            return this.secret_;
        }

        public ByteString getSecretBytes() {
            return ByteString.n(this.secret_);
        }

        public static Builder newBuilder(AliOSSUpload aliOSSUpload) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(aliOSSUpload);
        }

        public static AliOSSUpload parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AliOSSUpload) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AliOSSUpload parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AliOSSUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AliOSSUpload parseFrom(ByteString byteString) {
            return (AliOSSUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AliOSSUpload parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AliOSSUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AliOSSUpload parseFrom(byte[] bArr) {
            return (AliOSSUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AliOSSUpload parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AliOSSUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AliOSSUpload parseFrom(InputStream inputStream) {
            return (AliOSSUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AliOSSUpload parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AliOSSUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AliOSSUpload parseFrom(CodedInputStream codedInputStream) {
            return (AliOSSUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AliOSSUpload parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AliOSSUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AliOSSUploadOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum AudioMixing implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<AudioMixing>() { // from class: livekit.LivekitEgress.AudioMixing.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public AudioMixing findValueByNumber(int i) {
                return AudioMixing.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AudioMixingVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new AudioMixingVerifier();

            private AudioMixingVerifier() {
            }

            public boolean isInRange(int i) {
                return AudioMixing.b(i) != null;
            }
        }

        AudioMixing(int i) {
            this.a = i;
        }

        public static AudioMixing b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AutoParticipantEgress extends GeneratedMessageLite<AutoParticipantEgress, Builder> implements AutoParticipantEgressOrBuilder {
        public static final int ADVANCED_FIELD_NUMBER = 2;
        private static final AutoParticipantEgress DEFAULT_INSTANCE;
        public static final int FILE_OUTPUTS_FIELD_NUMBER = 3;
        private static volatile Parser<AutoParticipantEgress> PARSER = null;
        public static final int PRESET_FIELD_NUMBER = 1;
        public static final int SEGMENT_OUTPUTS_FIELD_NUMBER = 4;
        private Object options_;
        private int optionsCase_ = 0;
        private Internal.ProtobufList<EncodedFileOutput> fileOutputs_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<SegmentedFileOutput> segmentOutputs_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AutoParticipantEgress, Builder> implements AutoParticipantEgressOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AutoParticipantEgress.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OptionsCase {
            b(1),
            c(2),
            d(0);

            private final int a;

            OptionsCase(int i) {
                this.a = i;
            }

            public static OptionsCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 1) {
                    return b;
                }
                if (i != 2) {
                    return null;
                }
                return c;
            }
        }

        static {
            AutoParticipantEgress autoParticipantEgress = new AutoParticipantEgress();
            DEFAULT_INSTANCE = autoParticipantEgress;
            GeneratedMessageLite.registerDefaultInstance(AutoParticipantEgress.class, autoParticipantEgress);
        }

        private AutoParticipantEgress() {
        }

        private void addAllFileOutputs(Iterable<? extends EncodedFileOutput> iterable) {
            ensureFileOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.fileOutputs_);
        }

        private void addAllSegmentOutputs(Iterable<? extends SegmentedFileOutput> iterable) {
            ensureSegmentOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.segmentOutputs_);
        }

        private void addFileOutputs(EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.add(encodedFileOutput);
        }

        private void addSegmentOutputs(SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.add(segmentedFileOutput);
        }

        private void clearAdvanced() {
            if (this.optionsCase_ == 2) {
                this.optionsCase_ = 0;
                this.options_ = null;
            }
        }

        private void clearFileOutputs() {
            this.fileOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearOptions() {
            this.optionsCase_ = 0;
            this.options_ = null;
        }

        private void clearPreset() {
            if (this.optionsCase_ == 1) {
                this.optionsCase_ = 0;
                this.options_ = null;
            }
        }

        private void clearSegmentOutputs() {
            this.segmentOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureFileOutputsIsMutable() {
            Internal.ProtobufList<EncodedFileOutput> protobufList = this.fileOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.fileOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSegmentOutputsIsMutable() {
            Internal.ProtobufList<SegmentedFileOutput> protobufList = this.segmentOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.segmentOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static AutoParticipantEgress getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAdvanced(EncodingOptions encodingOptions) {
            encodingOptions.getClass();
            if (this.optionsCase_ != 2 || this.options_ == EncodingOptions.getDefaultInstance()) {
                this.options_ = encodingOptions;
            } else {
                this.options_ = ((EncodingOptions.Builder) EncodingOptions.newBuilder((EncodingOptions) this.options_).v(encodingOptions)).o();
            }
            this.optionsCase_ = 2;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AutoParticipantEgress parseDelimitedFrom(InputStream inputStream) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AutoParticipantEgress parseFrom(ByteBuffer byteBuffer) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AutoParticipantEgress> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeFileOutputs(int i) {
            ensureFileOutputsIsMutable();
            this.fileOutputs_.remove(i);
        }

        private void removeSegmentOutputs(int i) {
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.remove(i);
        }

        private void setAdvanced(EncodingOptions encodingOptions) {
            encodingOptions.getClass();
            this.options_ = encodingOptions;
            this.optionsCase_ = 2;
        }

        private void setFileOutputs(int i, EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.set(i, encodedFileOutput);
        }

        private void setPreset(EncodingOptionsPreset encodingOptionsPreset) {
            this.options_ = Integer.valueOf(encodingOptionsPreset.getNumber());
            this.optionsCase_ = 1;
        }

        private void setPresetValue(int i) {
            this.optionsCase_ = 1;
            this.options_ = Integer.valueOf(i);
        }

        private void setSegmentOutputs(int i, SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.set(i, segmentedFileOutput);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AutoParticipantEgress();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0001\u0000\u0001\u0004\u0004\u0000\u0002\u0000\u0001?\u0000\u0002<\u0000\u0003\u001b\u0004\u001b", new Object[]{ap.a(870652423), ap.a(1477442176), EncodingOptions.class, ap.a(1963980487), EncodedFileOutput.class, ap.a(1317050706), SegmentedFileOutput.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AutoParticipantEgress> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AutoParticipantEgress.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public EncodingOptions getAdvanced() {
            return this.optionsCase_ == 2 ? (EncodingOptions) this.options_ : EncodingOptions.getDefaultInstance();
        }

        public EncodedFileOutput getFileOutputs(int i) {
            return (EncodedFileOutput) this.fileOutputs_.get(i);
        }

        public int getFileOutputsCount() {
            return this.fileOutputs_.size();
        }

        public List<EncodedFileOutput> getFileOutputsList() {
            return this.fileOutputs_;
        }

        public EncodedFileOutputOrBuilder getFileOutputsOrBuilder(int i) {
            return (EncodedFileOutputOrBuilder) this.fileOutputs_.get(i);
        }

        public List<? extends EncodedFileOutputOrBuilder> getFileOutputsOrBuilderList() {
            return this.fileOutputs_;
        }

        public OptionsCase getOptionsCase() {
            return OptionsCase.b(this.optionsCase_);
        }

        public EncodingOptionsPreset getPreset() {
            if (this.optionsCase_ != 1) {
                return EncodingOptionsPreset.b;
            }
            EncodingOptionsPreset encodingOptionsPresetB = EncodingOptionsPreset.b(((Integer) this.options_).intValue());
            return encodingOptionsPresetB == null ? EncodingOptionsPreset.j : encodingOptionsPresetB;
        }

        public int getPresetValue() {
            if (this.optionsCase_ == 1) {
                return ((Integer) this.options_).intValue();
            }
            return 0;
        }

        public SegmentedFileOutput getSegmentOutputs(int i) {
            return (SegmentedFileOutput) this.segmentOutputs_.get(i);
        }

        public int getSegmentOutputsCount() {
            return this.segmentOutputs_.size();
        }

        public List<SegmentedFileOutput> getSegmentOutputsList() {
            return this.segmentOutputs_;
        }

        public SegmentedFileOutputOrBuilder getSegmentOutputsOrBuilder(int i) {
            return (SegmentedFileOutputOrBuilder) this.segmentOutputs_.get(i);
        }

        public List<? extends SegmentedFileOutputOrBuilder> getSegmentOutputsOrBuilderList() {
            return this.segmentOutputs_;
        }

        public boolean hasAdvanced() {
            return this.optionsCase_ == 2;
        }

        public boolean hasPreset() {
            return this.optionsCase_ == 1;
        }

        public static Builder newBuilder(AutoParticipantEgress autoParticipantEgress) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(autoParticipantEgress);
        }

        public static AutoParticipantEgress parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AutoParticipantEgress parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AutoParticipantEgress parseFrom(ByteString byteString) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addFileOutputs(int i, EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.add(i, encodedFileOutput);
        }

        private void addSegmentOutputs(int i, SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.add(i, segmentedFileOutput);
        }

        public static AutoParticipantEgress parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AutoParticipantEgress parseFrom(byte[] bArr) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AutoParticipantEgress parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AutoParticipantEgress parseFrom(InputStream inputStream) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AutoParticipantEgress parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AutoParticipantEgress parseFrom(CodedInputStream codedInputStream) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AutoParticipantEgress parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoParticipantEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AutoParticipantEgressOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AutoTrackEgress extends GeneratedMessageLite<AutoTrackEgress, Builder> implements AutoTrackEgressOrBuilder {
        public static final int ALIOSS_FIELD_NUMBER = 6;
        public static final int AZURE_FIELD_NUMBER = 4;
        private static final AutoTrackEgress DEFAULT_INSTANCE;
        public static final int DISABLE_MANIFEST_FIELD_NUMBER = 5;
        public static final int FILEPATH_FIELD_NUMBER = 1;
        public static final int GCP_FIELD_NUMBER = 3;
        private static volatile Parser<AutoTrackEgress> PARSER = null;
        public static final int S3_FIELD_NUMBER = 2;
        private boolean disableManifest_;
        private Object output_;
        private int outputCase_ = 0;
        private String filepath_ = ap.a(927072066);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AutoTrackEgress, Builder> implements AutoTrackEgressOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AutoTrackEgress.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OutputCase {
            b(2),
            c(3),
            d(4),
            e(6),
            f(0);

            private final int a;

            OutputCase(int i) {
                this.a = i;
            }

            public static OutputCase b(int i) {
                if (i == 0) {
                    return f;
                }
                if (i == 6) {
                    return e;
                }
                if (i == 2) {
                    return b;
                }
                if (i == 3) {
                    return c;
                }
                if (i != 4) {
                    return null;
                }
                return d;
            }
        }

        static {
            AutoTrackEgress autoTrackEgress = new AutoTrackEgress();
            DEFAULT_INSTANCE = autoTrackEgress;
            GeneratedMessageLite.registerDefaultInstance(AutoTrackEgress.class, autoTrackEgress);
        }

        private AutoTrackEgress() {
        }

        private void clearAliOSS() {
            if (this.outputCase_ == 6) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearAzure() {
            if (this.outputCase_ == 4) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearDisableManifest() {
            this.disableManifest_ = false;
        }

        private void clearFilepath() {
            this.filepath_ = getDefaultInstance().getFilepath();
        }

        private void clearGcp() {
            if (this.outputCase_ == 3) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearOutput() {
            this.outputCase_ = 0;
            this.output_ = null;
        }

        private void clearS3() {
            if (this.outputCase_ == 2) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        public static AutoTrackEgress getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAliOSS(AliOSSUpload aliOSSUpload) {
            aliOSSUpload.getClass();
            if (this.outputCase_ != 6 || this.output_ == AliOSSUpload.getDefaultInstance()) {
                this.output_ = aliOSSUpload;
            } else {
                this.output_ = ((AliOSSUpload.Builder) AliOSSUpload.newBuilder((AliOSSUpload) this.output_).v(aliOSSUpload)).o();
            }
            this.outputCase_ = 6;
        }

        private void mergeAzure(AzureBlobUpload azureBlobUpload) {
            azureBlobUpload.getClass();
            if (this.outputCase_ != 4 || this.output_ == AzureBlobUpload.getDefaultInstance()) {
                this.output_ = azureBlobUpload;
            } else {
                this.output_ = ((AzureBlobUpload.Builder) AzureBlobUpload.newBuilder((AzureBlobUpload) this.output_).v(azureBlobUpload)).o();
            }
            this.outputCase_ = 4;
        }

        private void mergeGcp(GCPUpload gCPUpload) {
            gCPUpload.getClass();
            if (this.outputCase_ != 3 || this.output_ == GCPUpload.getDefaultInstance()) {
                this.output_ = gCPUpload;
            } else {
                this.output_ = ((GCPUpload.Builder) GCPUpload.newBuilder((GCPUpload) this.output_).v(gCPUpload)).o();
            }
            this.outputCase_ = 3;
        }

        private void mergeS3(S3Upload s3Upload) {
            s3Upload.getClass();
            if (this.outputCase_ != 2 || this.output_ == S3Upload.getDefaultInstance()) {
                this.output_ = s3Upload;
            } else {
                this.output_ = ((S3Upload.Builder) S3Upload.newBuilder((S3Upload) this.output_).v(s3Upload)).o();
            }
            this.outputCase_ = 2;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AutoTrackEgress parseDelimitedFrom(InputStream inputStream) {
            return (AutoTrackEgress) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AutoTrackEgress parseFrom(ByteBuffer byteBuffer) {
            return (AutoTrackEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AutoTrackEgress> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAliOSS(AliOSSUpload aliOSSUpload) {
            aliOSSUpload.getClass();
            this.output_ = aliOSSUpload;
            this.outputCase_ = 6;
        }

        private void setAzure(AzureBlobUpload azureBlobUpload) {
            azureBlobUpload.getClass();
            this.output_ = azureBlobUpload;
            this.outputCase_ = 4;
        }

        private void setDisableManifest(boolean z) {
            this.disableManifest_ = z;
        }

        private void setFilepath(String str) {
            str.getClass();
            this.filepath_ = str;
        }

        private void setFilepathBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.filepath_ = byteString.L();
        }

        private void setGcp(GCPUpload gCPUpload) {
            gCPUpload.getClass();
            this.output_ = gCPUpload;
            this.outputCase_ = 3;
        }

        private void setS3(S3Upload s3Upload) {
            s3Upload.getClass();
            this.output_ = s3Upload;
            this.outputCase_ = 2;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AutoTrackEgress();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0001\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001Ȉ\u0002<\u0000\u0003<\u0000\u0004<\u0000\u0005\u0007\u0006<\u0000", new Object[]{"output_", "outputCase_", "filepath_", S3Upload.class, GCPUpload.class, AzureBlobUpload.class, "disableManifest_", AliOSSUpload.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AutoTrackEgress> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AutoTrackEgress.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AliOSSUpload getAliOSS() {
            return this.outputCase_ == 6 ? (AliOSSUpload) this.output_ : AliOSSUpload.getDefaultInstance();
        }

        public AzureBlobUpload getAzure() {
            return this.outputCase_ == 4 ? (AzureBlobUpload) this.output_ : AzureBlobUpload.getDefaultInstance();
        }

        public boolean getDisableManifest() {
            return this.disableManifest_;
        }

        public String getFilepath() {
            return this.filepath_;
        }

        public ByteString getFilepathBytes() {
            return ByteString.n(this.filepath_);
        }

        public GCPUpload getGcp() {
            return this.outputCase_ == 3 ? (GCPUpload) this.output_ : GCPUpload.getDefaultInstance();
        }

        public OutputCase getOutputCase() {
            return OutputCase.b(this.outputCase_);
        }

        public S3Upload getS3() {
            return this.outputCase_ == 2 ? (S3Upload) this.output_ : S3Upload.getDefaultInstance();
        }

        public boolean hasAliOSS() {
            return this.outputCase_ == 6;
        }

        public boolean hasAzure() {
            return this.outputCase_ == 4;
        }

        public boolean hasGcp() {
            return this.outputCase_ == 3;
        }

        public boolean hasS3() {
            return this.outputCase_ == 2;
        }

        public static Builder newBuilder(AutoTrackEgress autoTrackEgress) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(autoTrackEgress);
        }

        public static AutoTrackEgress parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoTrackEgress) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AutoTrackEgress parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoTrackEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AutoTrackEgress parseFrom(ByteString byteString) {
            return (AutoTrackEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AutoTrackEgress parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoTrackEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AutoTrackEgress parseFrom(byte[] bArr) {
            return (AutoTrackEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AutoTrackEgress parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoTrackEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AutoTrackEgress parseFrom(InputStream inputStream) {
            return (AutoTrackEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AutoTrackEgress parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoTrackEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AutoTrackEgress parseFrom(CodedInputStream codedInputStream) {
            return (AutoTrackEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AutoTrackEgress parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AutoTrackEgress) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AutoTrackEgressOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AzureBlobUpload extends GeneratedMessageLite<AzureBlobUpload, Builder> implements AzureBlobUploadOrBuilder {
        public static final int ACCOUNT_KEY_FIELD_NUMBER = 2;
        public static final int ACCOUNT_NAME_FIELD_NUMBER = 1;
        public static final int CONTAINER_NAME_FIELD_NUMBER = 3;
        private static final AzureBlobUpload DEFAULT_INSTANCE;
        private static volatile Parser<AzureBlobUpload> PARSER;
        private String accountKey_;
        private String accountName_;
        private String containerName_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AzureBlobUpload, Builder> implements AzureBlobUploadOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AzureBlobUpload.DEFAULT_INSTANCE);
            }
        }

        static {
            AzureBlobUpload azureBlobUpload = new AzureBlobUpload();
            DEFAULT_INSTANCE = azureBlobUpload;
            GeneratedMessageLite.registerDefaultInstance(AzureBlobUpload.class, azureBlobUpload);
        }

        private AzureBlobUpload() {
            String strA = ap.a(2124234350);
            this.accountName_ = strA;
            this.accountKey_ = strA;
            this.containerName_ = strA;
        }

        private void clearAccountKey() {
            this.accountKey_ = getDefaultInstance().getAccountKey();
        }

        private void clearAccountName() {
            this.accountName_ = getDefaultInstance().getAccountName();
        }

        private void clearContainerName() {
            this.containerName_ = getDefaultInstance().getContainerName();
        }

        public static AzureBlobUpload getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AzureBlobUpload parseDelimitedFrom(InputStream inputStream) {
            return (AzureBlobUpload) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AzureBlobUpload parseFrom(ByteBuffer byteBuffer) {
            return (AzureBlobUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AzureBlobUpload> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAccountKey(String str) {
            str.getClass();
            this.accountKey_ = str;
        }

        private void setAccountKeyBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.accountKey_ = byteString.L();
        }

        private void setAccountName(String str) {
            str.getClass();
            this.accountName_ = str;
        }

        private void setAccountNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.accountName_ = byteString.L();
        }

        private void setContainerName(String str) {
            str.getClass();
            this.containerName_ = str;
        }

        private void setContainerNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.containerName_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AzureBlobUpload();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ", new Object[]{"accountName_", "accountKey_", "containerName_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AzureBlobUpload> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AzureBlobUpload.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAccountKey() {
            return this.accountKey_;
        }

        public ByteString getAccountKeyBytes() {
            return ByteString.n(this.accountKey_);
        }

        public String getAccountName() {
            return this.accountName_;
        }

        public ByteString getAccountNameBytes() {
            return ByteString.n(this.accountName_);
        }

        public String getContainerName() {
            return this.containerName_;
        }

        public ByteString getContainerNameBytes() {
            return ByteString.n(this.containerName_);
        }

        public static Builder newBuilder(AzureBlobUpload azureBlobUpload) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(azureBlobUpload);
        }

        public static AzureBlobUpload parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AzureBlobUpload) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AzureBlobUpload parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AzureBlobUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AzureBlobUpload parseFrom(ByteString byteString) {
            return (AzureBlobUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AzureBlobUpload parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AzureBlobUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AzureBlobUpload parseFrom(byte[] bArr) {
            return (AzureBlobUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AzureBlobUpload parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AzureBlobUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AzureBlobUpload parseFrom(InputStream inputStream) {
            return (AzureBlobUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AzureBlobUpload parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AzureBlobUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AzureBlobUpload parseFrom(CodedInputStream codedInputStream) {
            return (AzureBlobUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AzureBlobUpload parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AzureBlobUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AzureBlobUploadOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DirectFileOutput extends GeneratedMessageLite<DirectFileOutput, Builder> implements DirectFileOutputOrBuilder {
        public static final int ALIOSS_FIELD_NUMBER = 6;
        public static final int AZURE_FIELD_NUMBER = 4;
        private static final DirectFileOutput DEFAULT_INSTANCE;
        public static final int DISABLE_MANIFEST_FIELD_NUMBER = 5;
        public static final int FILEPATH_FIELD_NUMBER = 1;
        public static final int GCP_FIELD_NUMBER = 3;
        private static volatile Parser<DirectFileOutput> PARSER = null;
        public static final int S3_FIELD_NUMBER = 2;
        private boolean disableManifest_;
        private Object output_;
        private int outputCase_ = 0;
        private String filepath_ = ap.a(799382797);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DirectFileOutput, Builder> implements DirectFileOutputOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DirectFileOutput.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OutputCase {
            b(2),
            c(3),
            d(4),
            e(6),
            f(0);

            private final int a;

            OutputCase(int i) {
                this.a = i;
            }

            public static OutputCase b(int i) {
                if (i == 0) {
                    return f;
                }
                if (i == 6) {
                    return e;
                }
                if (i == 2) {
                    return b;
                }
                if (i == 3) {
                    return c;
                }
                if (i != 4) {
                    return null;
                }
                return d;
            }
        }

        static {
            DirectFileOutput directFileOutput = new DirectFileOutput();
            DEFAULT_INSTANCE = directFileOutput;
            GeneratedMessageLite.registerDefaultInstance(DirectFileOutput.class, directFileOutput);
        }

        private DirectFileOutput() {
        }

        private void clearAliOSS() {
            if (this.outputCase_ == 6) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearAzure() {
            if (this.outputCase_ == 4) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearDisableManifest() {
            this.disableManifest_ = false;
        }

        private void clearFilepath() {
            this.filepath_ = getDefaultInstance().getFilepath();
        }

        private void clearGcp() {
            if (this.outputCase_ == 3) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearOutput() {
            this.outputCase_ = 0;
            this.output_ = null;
        }

        private void clearS3() {
            if (this.outputCase_ == 2) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        public static DirectFileOutput getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAliOSS(AliOSSUpload aliOSSUpload) {
            aliOSSUpload.getClass();
            if (this.outputCase_ != 6 || this.output_ == AliOSSUpload.getDefaultInstance()) {
                this.output_ = aliOSSUpload;
            } else {
                this.output_ = ((AliOSSUpload.Builder) AliOSSUpload.newBuilder((AliOSSUpload) this.output_).v(aliOSSUpload)).o();
            }
            this.outputCase_ = 6;
        }

        private void mergeAzure(AzureBlobUpload azureBlobUpload) {
            azureBlobUpload.getClass();
            if (this.outputCase_ != 4 || this.output_ == AzureBlobUpload.getDefaultInstance()) {
                this.output_ = azureBlobUpload;
            } else {
                this.output_ = ((AzureBlobUpload.Builder) AzureBlobUpload.newBuilder((AzureBlobUpload) this.output_).v(azureBlobUpload)).o();
            }
            this.outputCase_ = 4;
        }

        private void mergeGcp(GCPUpload gCPUpload) {
            gCPUpload.getClass();
            if (this.outputCase_ != 3 || this.output_ == GCPUpload.getDefaultInstance()) {
                this.output_ = gCPUpload;
            } else {
                this.output_ = ((GCPUpload.Builder) GCPUpload.newBuilder((GCPUpload) this.output_).v(gCPUpload)).o();
            }
            this.outputCase_ = 3;
        }

        private void mergeS3(S3Upload s3Upload) {
            s3Upload.getClass();
            if (this.outputCase_ != 2 || this.output_ == S3Upload.getDefaultInstance()) {
                this.output_ = s3Upload;
            } else {
                this.output_ = ((S3Upload.Builder) S3Upload.newBuilder((S3Upload) this.output_).v(s3Upload)).o();
            }
            this.outputCase_ = 2;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DirectFileOutput parseDelimitedFrom(InputStream inputStream) {
            return (DirectFileOutput) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DirectFileOutput parseFrom(ByteBuffer byteBuffer) {
            return (DirectFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DirectFileOutput> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAliOSS(AliOSSUpload aliOSSUpload) {
            aliOSSUpload.getClass();
            this.output_ = aliOSSUpload;
            this.outputCase_ = 6;
        }

        private void setAzure(AzureBlobUpload azureBlobUpload) {
            azureBlobUpload.getClass();
            this.output_ = azureBlobUpload;
            this.outputCase_ = 4;
        }

        private void setDisableManifest(boolean z) {
            this.disableManifest_ = z;
        }

        private void setFilepath(String str) {
            str.getClass();
            this.filepath_ = str;
        }

        private void setFilepathBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.filepath_ = byteString.L();
        }

        private void setGcp(GCPUpload gCPUpload) {
            gCPUpload.getClass();
            this.output_ = gCPUpload;
            this.outputCase_ = 3;
        }

        private void setS3(S3Upload s3Upload) {
            s3Upload.getClass();
            this.output_ = s3Upload;
            this.outputCase_ = 2;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DirectFileOutput();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0001\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001Ȉ\u0002<\u0000\u0003<\u0000\u0004<\u0000\u0005\u0007\u0006<\u0000", new Object[]{"output_", "outputCase_", "filepath_", S3Upload.class, GCPUpload.class, AzureBlobUpload.class, "disableManifest_", AliOSSUpload.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DirectFileOutput> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DirectFileOutput.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AliOSSUpload getAliOSS() {
            return this.outputCase_ == 6 ? (AliOSSUpload) this.output_ : AliOSSUpload.getDefaultInstance();
        }

        public AzureBlobUpload getAzure() {
            return this.outputCase_ == 4 ? (AzureBlobUpload) this.output_ : AzureBlobUpload.getDefaultInstance();
        }

        public boolean getDisableManifest() {
            return this.disableManifest_;
        }

        public String getFilepath() {
            return this.filepath_;
        }

        public ByteString getFilepathBytes() {
            return ByteString.n(this.filepath_);
        }

        public GCPUpload getGcp() {
            return this.outputCase_ == 3 ? (GCPUpload) this.output_ : GCPUpload.getDefaultInstance();
        }

        public OutputCase getOutputCase() {
            return OutputCase.b(this.outputCase_);
        }

        public S3Upload getS3() {
            return this.outputCase_ == 2 ? (S3Upload) this.output_ : S3Upload.getDefaultInstance();
        }

        public boolean hasAliOSS() {
            return this.outputCase_ == 6;
        }

        public boolean hasAzure() {
            return this.outputCase_ == 4;
        }

        public boolean hasGcp() {
            return this.outputCase_ == 3;
        }

        public boolean hasS3() {
            return this.outputCase_ == 2;
        }

        public static Builder newBuilder(DirectFileOutput directFileOutput) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(directFileOutput);
        }

        public static DirectFileOutput parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DirectFileOutput) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DirectFileOutput parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DirectFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DirectFileOutput parseFrom(ByteString byteString) {
            return (DirectFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DirectFileOutput parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DirectFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DirectFileOutput parseFrom(byte[] bArr) {
            return (DirectFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DirectFileOutput parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DirectFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DirectFileOutput parseFrom(InputStream inputStream) {
            return (DirectFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DirectFileOutput parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DirectFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DirectFileOutput parseFrom(CodedInputStream codedInputStream) {
            return (DirectFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DirectFileOutput parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DirectFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DirectFileOutputOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class EgressInfo extends GeneratedMessageLite<EgressInfo, Builder> implements EgressInfoOrBuilder {
        public static final int BACKUP_STORAGE_USED_FIELD_NUMBER = 25;
        private static final EgressInfo DEFAULT_INSTANCE;
        public static final int DETAILS_FIELD_NUMBER = 21;
        public static final int EGRESS_ID_FIELD_NUMBER = 1;
        public static final int ENDED_AT_FIELD_NUMBER = 11;
        public static final int ERROR_CODE_FIELD_NUMBER = 22;
        public static final int ERROR_FIELD_NUMBER = 9;
        public static final int FILE_FIELD_NUMBER = 8;
        public static final int FILE_RESULTS_FIELD_NUMBER = 16;
        public static final int IMAGE_RESULTS_FIELD_NUMBER = 20;
        public static final int MANIFEST_LOCATION_FIELD_NUMBER = 23;
        private static volatile Parser<EgressInfo> PARSER = null;
        public static final int PARTICIPANT_FIELD_NUMBER = 19;
        public static final int ROOM_COMPOSITE_FIELD_NUMBER = 4;
        public static final int ROOM_ID_FIELD_NUMBER = 2;
        public static final int ROOM_NAME_FIELD_NUMBER = 13;
        public static final int SEGMENTS_FIELD_NUMBER = 12;
        public static final int SEGMENT_RESULTS_FIELD_NUMBER = 17;
        public static final int SOURCE_TYPE_FIELD_NUMBER = 26;
        public static final int STARTED_AT_FIELD_NUMBER = 10;
        public static final int STATUS_FIELD_NUMBER = 3;
        public static final int STREAM_FIELD_NUMBER = 7;
        public static final int STREAM_RESULTS_FIELD_NUMBER = 15;
        public static final int TRACK_COMPOSITE_FIELD_NUMBER = 5;
        public static final int TRACK_FIELD_NUMBER = 6;
        public static final int UPDATED_AT_FIELD_NUMBER = 18;
        public static final int WEB_FIELD_NUMBER = 14;
        private boolean backupStorageUsed_;
        private String details_;
        private String egressId_;
        private long endedAt_;
        private int errorCode_;
        private String error_;
        private Internal.ProtobufList<FileInfo> fileResults_;
        private Internal.ProtobufList<ImagesInfo> imageResults_;
        private String manifestLocation_;
        private Object request_;
        private Object result_;
        private String roomId_;
        private String roomName_;
        private Internal.ProtobufList<SegmentsInfo> segmentResults_;
        private int sourceType_;
        private long startedAt_;
        private int status_;
        private Internal.ProtobufList<StreamInfo> streamResults_;
        private long updatedAt_;
        private int requestCase_ = 0;
        private int resultCase_ = 0;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<EgressInfo, Builder> implements EgressInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(EgressInfo.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum RequestCase {
            b(4),
            c(14),
            d(19),
            e(5),
            f(6),
            g(0);

            private final int a;

            RequestCase(int i) {
                this.a = i;
            }

            public static RequestCase b(int i) {
                if (i == 0) {
                    return g;
                }
                if (i == 14) {
                    return c;
                }
                if (i == 19) {
                    return d;
                }
                if (i == 4) {
                    return b;
                }
                if (i == 5) {
                    return e;
                }
                if (i != 6) {
                    return null;
                }
                return f;
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum ResultCase {
            b(7),
            c(8),
            d(12),
            e(0);

            private final int a;

            ResultCase(int i) {
                this.a = i;
            }

            public static ResultCase b(int i) {
                if (i == 0) {
                    return e;
                }
                if (i == 12) {
                    return d;
                }
                if (i == 7) {
                    return b;
                }
                if (i != 8) {
                    return null;
                }
                return c;
            }
        }

        static {
            EgressInfo egressInfo = new EgressInfo();
            DEFAULT_INSTANCE = egressInfo;
            GeneratedMessageLite.registerDefaultInstance(EgressInfo.class, egressInfo);
        }

        private EgressInfo() {
            String strA = ap.a(933711262);
            this.egressId_ = strA;
            this.roomId_ = strA;
            this.roomName_ = strA;
            this.details_ = strA;
            this.error_ = strA;
            this.streamResults_ = GeneratedMessageLite.emptyProtobufList();
            this.fileResults_ = GeneratedMessageLite.emptyProtobufList();
            this.segmentResults_ = GeneratedMessageLite.emptyProtobufList();
            this.imageResults_ = GeneratedMessageLite.emptyProtobufList();
            this.manifestLocation_ = strA;
        }

        private void addAllFileResults(Iterable<? extends FileInfo> iterable) {
            ensureFileResultsIsMutable();
            AbstractMessageLite.addAll(iterable, this.fileResults_);
        }

        private void addAllImageResults(Iterable<? extends ImagesInfo> iterable) {
            ensureImageResultsIsMutable();
            AbstractMessageLite.addAll(iterable, this.imageResults_);
        }

        private void addAllSegmentResults(Iterable<? extends SegmentsInfo> iterable) {
            ensureSegmentResultsIsMutable();
            AbstractMessageLite.addAll(iterable, this.segmentResults_);
        }

        private void addAllStreamResults(Iterable<? extends StreamInfo> iterable) {
            ensureStreamResultsIsMutable();
            AbstractMessageLite.addAll(iterable, this.streamResults_);
        }

        private void addFileResults(FileInfo fileInfo) {
            fileInfo.getClass();
            ensureFileResultsIsMutable();
            this.fileResults_.add(fileInfo);
        }

        private void addImageResults(ImagesInfo imagesInfo) {
            imagesInfo.getClass();
            ensureImageResultsIsMutable();
            this.imageResults_.add(imagesInfo);
        }

        private void addSegmentResults(SegmentsInfo segmentsInfo) {
            segmentsInfo.getClass();
            ensureSegmentResultsIsMutable();
            this.segmentResults_.add(segmentsInfo);
        }

        private void addStreamResults(StreamInfo streamInfo) {
            streamInfo.getClass();
            ensureStreamResultsIsMutable();
            this.streamResults_.add(streamInfo);
        }

        private void clearBackupStorageUsed() {
            this.backupStorageUsed_ = false;
        }

        private void clearDetails() {
            this.details_ = getDefaultInstance().getDetails();
        }

        private void clearEgressId() {
            this.egressId_ = getDefaultInstance().getEgressId();
        }

        private void clearEndedAt() {
            this.endedAt_ = 0L;
        }

        private void clearError() {
            this.error_ = getDefaultInstance().getError();
        }

        private void clearErrorCode() {
            this.errorCode_ = 0;
        }

        private void clearFile() {
            if (this.resultCase_ == 8) {
                this.resultCase_ = 0;
                this.result_ = null;
            }
        }

        private void clearFileResults() {
            this.fileResults_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearImageResults() {
            this.imageResults_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearManifestLocation() {
            this.manifestLocation_ = getDefaultInstance().getManifestLocation();
        }

        private void clearParticipant() {
            if (this.requestCase_ == 19) {
                this.requestCase_ = 0;
                this.request_ = null;
            }
        }

        private void clearRequest() {
            this.requestCase_ = 0;
            this.request_ = null;
        }

        private void clearResult() {
            this.resultCase_ = 0;
            this.result_ = null;
        }

        private void clearRoomComposite() {
            if (this.requestCase_ == 4) {
                this.requestCase_ = 0;
                this.request_ = null;
            }
        }

        private void clearRoomId() {
            this.roomId_ = getDefaultInstance().getRoomId();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearSegmentResults() {
            this.segmentResults_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSegments() {
            if (this.resultCase_ == 12) {
                this.resultCase_ = 0;
                this.result_ = null;
            }
        }

        private void clearSourceType() {
            this.sourceType_ = 0;
        }

        private void clearStartedAt() {
            this.startedAt_ = 0L;
        }

        private void clearStatus() {
            this.status_ = 0;
        }

        private void clearStream() {
            if (this.resultCase_ == 7) {
                this.resultCase_ = 0;
                this.result_ = null;
            }
        }

        private void clearStreamResults() {
            this.streamResults_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearTrack() {
            if (this.requestCase_ == 6) {
                this.requestCase_ = 0;
                this.request_ = null;
            }
        }

        private void clearTrackComposite() {
            if (this.requestCase_ == 5) {
                this.requestCase_ = 0;
                this.request_ = null;
            }
        }

        private void clearUpdatedAt() {
            this.updatedAt_ = 0L;
        }

        private void clearWeb() {
            if (this.requestCase_ == 14) {
                this.requestCase_ = 0;
                this.request_ = null;
            }
        }

        private void ensureFileResultsIsMutable() {
            Internal.ProtobufList<FileInfo> protobufList = this.fileResults_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.fileResults_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureImageResultsIsMutable() {
            Internal.ProtobufList<ImagesInfo> protobufList = this.imageResults_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.imageResults_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSegmentResultsIsMutable() {
            Internal.ProtobufList<SegmentsInfo> protobufList = this.segmentResults_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.segmentResults_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureStreamResultsIsMutable() {
            Internal.ProtobufList<StreamInfo> protobufList = this.streamResults_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.streamResults_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static EgressInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeFile(FileInfo fileInfo) {
            fileInfo.getClass();
            if (this.resultCase_ != 8 || this.result_ == FileInfo.getDefaultInstance()) {
                this.result_ = fileInfo;
            } else {
                this.result_ = ((FileInfo.Builder) FileInfo.newBuilder((FileInfo) this.result_).v(fileInfo)).o();
            }
            this.resultCase_ = 8;
        }

        private void mergeParticipant(ParticipantEgressRequest participantEgressRequest) {
            participantEgressRequest.getClass();
            if (this.requestCase_ != 19 || this.request_ == ParticipantEgressRequest.getDefaultInstance()) {
                this.request_ = participantEgressRequest;
            } else {
                this.request_ = ((ParticipantEgressRequest.Builder) ParticipantEgressRequest.newBuilder((ParticipantEgressRequest) this.request_).v(participantEgressRequest)).o();
            }
            this.requestCase_ = 19;
        }

        private void mergeRoomComposite(RoomCompositeEgressRequest roomCompositeEgressRequest) {
            roomCompositeEgressRequest.getClass();
            if (this.requestCase_ != 4 || this.request_ == RoomCompositeEgressRequest.getDefaultInstance()) {
                this.request_ = roomCompositeEgressRequest;
            } else {
                this.request_ = ((RoomCompositeEgressRequest.Builder) RoomCompositeEgressRequest.newBuilder((RoomCompositeEgressRequest) this.request_).v(roomCompositeEgressRequest)).o();
            }
            this.requestCase_ = 4;
        }

        private void mergeSegments(SegmentsInfo segmentsInfo) {
            segmentsInfo.getClass();
            if (this.resultCase_ != 12 || this.result_ == SegmentsInfo.getDefaultInstance()) {
                this.result_ = segmentsInfo;
            } else {
                this.result_ = ((SegmentsInfo.Builder) SegmentsInfo.newBuilder((SegmentsInfo) this.result_).v(segmentsInfo)).o();
            }
            this.resultCase_ = 12;
        }

        private void mergeStream(StreamInfoList streamInfoList) {
            streamInfoList.getClass();
            if (this.resultCase_ != 7 || this.result_ == StreamInfoList.getDefaultInstance()) {
                this.result_ = streamInfoList;
            } else {
                this.result_ = ((StreamInfoList.Builder) StreamInfoList.newBuilder((StreamInfoList) this.result_).v(streamInfoList)).o();
            }
            this.resultCase_ = 7;
        }

        private void mergeTrack(TrackEgressRequest trackEgressRequest) {
            trackEgressRequest.getClass();
            if (this.requestCase_ != 6 || this.request_ == TrackEgressRequest.getDefaultInstance()) {
                this.request_ = trackEgressRequest;
            } else {
                this.request_ = ((TrackEgressRequest.Builder) TrackEgressRequest.newBuilder((TrackEgressRequest) this.request_).v(trackEgressRequest)).o();
            }
            this.requestCase_ = 6;
        }

        private void mergeTrackComposite(TrackCompositeEgressRequest trackCompositeEgressRequest) {
            trackCompositeEgressRequest.getClass();
            if (this.requestCase_ != 5 || this.request_ == TrackCompositeEgressRequest.getDefaultInstance()) {
                this.request_ = trackCompositeEgressRequest;
            } else {
                this.request_ = ((TrackCompositeEgressRequest.Builder) TrackCompositeEgressRequest.newBuilder((TrackCompositeEgressRequest) this.request_).v(trackCompositeEgressRequest)).o();
            }
            this.requestCase_ = 5;
        }

        private void mergeWeb(WebEgressRequest webEgressRequest) {
            webEgressRequest.getClass();
            if (this.requestCase_ != 14 || this.request_ == WebEgressRequest.getDefaultInstance()) {
                this.request_ = webEgressRequest;
            } else {
                this.request_ = ((WebEgressRequest.Builder) WebEgressRequest.newBuilder((WebEgressRequest) this.request_).v(webEgressRequest)).o();
            }
            this.requestCase_ = 14;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static EgressInfo parseDelimitedFrom(InputStream inputStream) {
            return (EgressInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EgressInfo parseFrom(ByteBuffer byteBuffer) {
            return (EgressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<EgressInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeFileResults(int i) {
            ensureFileResultsIsMutable();
            this.fileResults_.remove(i);
        }

        private void removeImageResults(int i) {
            ensureImageResultsIsMutable();
            this.imageResults_.remove(i);
        }

        private void removeSegmentResults(int i) {
            ensureSegmentResultsIsMutable();
            this.segmentResults_.remove(i);
        }

        private void removeStreamResults(int i) {
            ensureStreamResultsIsMutable();
            this.streamResults_.remove(i);
        }

        private void setBackupStorageUsed(boolean z) {
            this.backupStorageUsed_ = z;
        }

        private void setDetails(String str) {
            str.getClass();
            this.details_ = str;
        }

        private void setDetailsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.details_ = byteString.L();
        }

        private void setEgressId(String str) {
            str.getClass();
            this.egressId_ = str;
        }

        private void setEgressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.egressId_ = byteString.L();
        }

        private void setEndedAt(long j) {
            this.endedAt_ = j;
        }

        private void setError(String str) {
            str.getClass();
            this.error_ = str;
        }

        private void setErrorBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.error_ = byteString.L();
        }

        private void setErrorCode(int i) {
            this.errorCode_ = i;
        }

        private void setFile(FileInfo fileInfo) {
            fileInfo.getClass();
            this.result_ = fileInfo;
            this.resultCase_ = 8;
        }

        private void setFileResults(int i, FileInfo fileInfo) {
            fileInfo.getClass();
            ensureFileResultsIsMutable();
            this.fileResults_.set(i, fileInfo);
        }

        private void setImageResults(int i, ImagesInfo imagesInfo) {
            imagesInfo.getClass();
            ensureImageResultsIsMutable();
            this.imageResults_.set(i, imagesInfo);
        }

        private void setManifestLocation(String str) {
            str.getClass();
            this.manifestLocation_ = str;
        }

        private void setManifestLocationBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.manifestLocation_ = byteString.L();
        }

        private void setParticipant(ParticipantEgressRequest participantEgressRequest) {
            participantEgressRequest.getClass();
            this.request_ = participantEgressRequest;
            this.requestCase_ = 19;
        }

        private void setRoomComposite(RoomCompositeEgressRequest roomCompositeEgressRequest) {
            roomCompositeEgressRequest.getClass();
            this.request_ = roomCompositeEgressRequest;
            this.requestCase_ = 4;
        }

        private void setRoomId(String str) {
            str.getClass();
            this.roomId_ = str;
        }

        private void setRoomIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomId_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setSegmentResults(int i, SegmentsInfo segmentsInfo) {
            segmentsInfo.getClass();
            ensureSegmentResultsIsMutable();
            this.segmentResults_.set(i, segmentsInfo);
        }

        private void setSegments(SegmentsInfo segmentsInfo) {
            segmentsInfo.getClass();
            this.result_ = segmentsInfo;
            this.resultCase_ = 12;
        }

        private void setSourceType(EgressSourceType egressSourceType) {
            this.sourceType_ = egressSourceType.getNumber();
        }

        private void setSourceTypeValue(int i) {
            this.sourceType_ = i;
        }

        private void setStartedAt(long j) {
            this.startedAt_ = j;
        }

        private void setStatus(EgressStatus egressStatus) {
            this.status_ = egressStatus.getNumber();
        }

        private void setStatusValue(int i) {
            this.status_ = i;
        }

        private void setStream(StreamInfoList streamInfoList) {
            streamInfoList.getClass();
            this.result_ = streamInfoList;
            this.resultCase_ = 7;
        }

        private void setStreamResults(int i, StreamInfo streamInfo) {
            streamInfo.getClass();
            ensureStreamResultsIsMutable();
            this.streamResults_.set(i, streamInfo);
        }

        private void setTrack(TrackEgressRequest trackEgressRequest) {
            trackEgressRequest.getClass();
            this.request_ = trackEgressRequest;
            this.requestCase_ = 6;
        }

        private void setTrackComposite(TrackCompositeEgressRequest trackCompositeEgressRequest) {
            trackCompositeEgressRequest.getClass();
            this.request_ = trackCompositeEgressRequest;
            this.requestCase_ = 5;
        }

        private void setUpdatedAt(long j) {
            this.updatedAt_ = j;
        }

        private void setWeb(WebEgressRequest webEgressRequest) {
            webEgressRequest.getClass();
            this.request_ = webEgressRequest;
            this.requestCase_ = 14;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new EgressInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0019\u0002\u0000\u0001\u001a\u0019\u0000\u0004\u0000\u0001Ȉ\u0002Ȉ\u0003\f\u0004<\u0000\u0005<\u0000\u0006<\u0000\u0007<\u0001\b<\u0001\tȈ\n\u0002\u000b\u0002\f<\u0001\rȈ\u000e<\u0000\u000f\u001b\u0010\u001b\u0011\u001b\u0012\u0002\u0013<\u0000\u0014\u001b\u0015Ȉ\u0016\u0004\u0017Ȉ\u0019\u0007\u001a\f", new Object[]{"request_", "requestCase_", "result_", "resultCase_", "egressId_", "roomId_", "status_", RoomCompositeEgressRequest.class, TrackCompositeEgressRequest.class, TrackEgressRequest.class, StreamInfoList.class, FileInfo.class, "error_", "startedAt_", "endedAt_", SegmentsInfo.class, "roomName_", WebEgressRequest.class, "streamResults_", StreamInfo.class, "fileResults_", FileInfo.class, "segmentResults_", SegmentsInfo.class, "updatedAt_", ParticipantEgressRequest.class, "imageResults_", ImagesInfo.class, "details_", "errorCode_", "manifestLocation_", "backupStorageUsed_", "sourceType_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<EgressInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (EgressInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getBackupStorageUsed() {
            return this.backupStorageUsed_;
        }

        public String getDetails() {
            return this.details_;
        }

        public ByteString getDetailsBytes() {
            return ByteString.n(this.details_);
        }

        public String getEgressId() {
            return this.egressId_;
        }

        public ByteString getEgressIdBytes() {
            return ByteString.n(this.egressId_);
        }

        public long getEndedAt() {
            return this.endedAt_;
        }

        public String getError() {
            return this.error_;
        }

        public ByteString getErrorBytes() {
            return ByteString.n(this.error_);
        }

        public int getErrorCode() {
            return this.errorCode_;
        }

        @Deprecated
        public FileInfo getFile() {
            return this.resultCase_ == 8 ? (FileInfo) this.result_ : FileInfo.getDefaultInstance();
        }

        public FileInfo getFileResults(int i) {
            return (FileInfo) this.fileResults_.get(i);
        }

        public int getFileResultsCount() {
            return this.fileResults_.size();
        }

        public List<FileInfo> getFileResultsList() {
            return this.fileResults_;
        }

        public FileInfoOrBuilder getFileResultsOrBuilder(int i) {
            return (FileInfoOrBuilder) this.fileResults_.get(i);
        }

        public List<? extends FileInfoOrBuilder> getFileResultsOrBuilderList() {
            return this.fileResults_;
        }

        public ImagesInfo getImageResults(int i) {
            return (ImagesInfo) this.imageResults_.get(i);
        }

        public int getImageResultsCount() {
            return this.imageResults_.size();
        }

        public List<ImagesInfo> getImageResultsList() {
            return this.imageResults_;
        }

        public ImagesInfoOrBuilder getImageResultsOrBuilder(int i) {
            return (ImagesInfoOrBuilder) this.imageResults_.get(i);
        }

        public List<? extends ImagesInfoOrBuilder> getImageResultsOrBuilderList() {
            return this.imageResults_;
        }

        public String getManifestLocation() {
            return this.manifestLocation_;
        }

        public ByteString getManifestLocationBytes() {
            return ByteString.n(this.manifestLocation_);
        }

        public ParticipantEgressRequest getParticipant() {
            return this.requestCase_ == 19 ? (ParticipantEgressRequest) this.request_ : ParticipantEgressRequest.getDefaultInstance();
        }

        public RequestCase getRequestCase() {
            return RequestCase.b(this.requestCase_);
        }

        public ResultCase getResultCase() {
            return ResultCase.b(this.resultCase_);
        }

        public RoomCompositeEgressRequest getRoomComposite() {
            return this.requestCase_ == 4 ? (RoomCompositeEgressRequest) this.request_ : RoomCompositeEgressRequest.getDefaultInstance();
        }

        public String getRoomId() {
            return this.roomId_;
        }

        public ByteString getRoomIdBytes() {
            return ByteString.n(this.roomId_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public SegmentsInfo getSegmentResults(int i) {
            return (SegmentsInfo) this.segmentResults_.get(i);
        }

        public int getSegmentResultsCount() {
            return this.segmentResults_.size();
        }

        public List<SegmentsInfo> getSegmentResultsList() {
            return this.segmentResults_;
        }

        public SegmentsInfoOrBuilder getSegmentResultsOrBuilder(int i) {
            return (SegmentsInfoOrBuilder) this.segmentResults_.get(i);
        }

        public List<? extends SegmentsInfoOrBuilder> getSegmentResultsOrBuilderList() {
            return this.segmentResults_;
        }

        @Deprecated
        public SegmentsInfo getSegments() {
            return this.resultCase_ == 12 ? (SegmentsInfo) this.result_ : SegmentsInfo.getDefaultInstance();
        }

        public EgressSourceType getSourceType() {
            EgressSourceType egressSourceTypeB = EgressSourceType.b(this.sourceType_);
            return egressSourceTypeB == null ? EgressSourceType.d : egressSourceTypeB;
        }

        public int getSourceTypeValue() {
            return this.sourceType_;
        }

        public long getStartedAt() {
            return this.startedAt_;
        }

        public EgressStatus getStatus() {
            EgressStatus egressStatusB = EgressStatus.b(this.status_);
            return egressStatusB == null ? EgressStatus.i : egressStatusB;
        }

        public int getStatusValue() {
            return this.status_;
        }

        @Deprecated
        public StreamInfoList getStream() {
            return this.resultCase_ == 7 ? (StreamInfoList) this.result_ : StreamInfoList.getDefaultInstance();
        }

        public StreamInfo getStreamResults(int i) {
            return (StreamInfo) this.streamResults_.get(i);
        }

        public int getStreamResultsCount() {
            return this.streamResults_.size();
        }

        public List<StreamInfo> getStreamResultsList() {
            return this.streamResults_;
        }

        public StreamInfoOrBuilder getStreamResultsOrBuilder(int i) {
            return (StreamInfoOrBuilder) this.streamResults_.get(i);
        }

        public List<? extends StreamInfoOrBuilder> getStreamResultsOrBuilderList() {
            return this.streamResults_;
        }

        public TrackEgressRequest getTrack() {
            return this.requestCase_ == 6 ? (TrackEgressRequest) this.request_ : TrackEgressRequest.getDefaultInstance();
        }

        public TrackCompositeEgressRequest getTrackComposite() {
            return this.requestCase_ == 5 ? (TrackCompositeEgressRequest) this.request_ : TrackCompositeEgressRequest.getDefaultInstance();
        }

        public long getUpdatedAt() {
            return this.updatedAt_;
        }

        public WebEgressRequest getWeb() {
            return this.requestCase_ == 14 ? (WebEgressRequest) this.request_ : WebEgressRequest.getDefaultInstance();
        }

        @Deprecated
        public boolean hasFile() {
            return this.resultCase_ == 8;
        }

        public boolean hasParticipant() {
            return this.requestCase_ == 19;
        }

        public boolean hasRoomComposite() {
            return this.requestCase_ == 4;
        }

        @Deprecated
        public boolean hasSegments() {
            return this.resultCase_ == 12;
        }

        @Deprecated
        public boolean hasStream() {
            return this.resultCase_ == 7;
        }

        public boolean hasTrack() {
            return this.requestCase_ == 6;
        }

        public boolean hasTrackComposite() {
            return this.requestCase_ == 5;
        }

        public boolean hasWeb() {
            return this.requestCase_ == 14;
        }

        public static Builder newBuilder(EgressInfo egressInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(egressInfo);
        }

        public static EgressInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EgressInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EgressInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (EgressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static EgressInfo parseFrom(ByteString byteString) {
            return (EgressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addFileResults(int i, FileInfo fileInfo) {
            fileInfo.getClass();
            ensureFileResultsIsMutable();
            this.fileResults_.add(i, fileInfo);
        }

        private void addImageResults(int i, ImagesInfo imagesInfo) {
            imagesInfo.getClass();
            ensureImageResultsIsMutable();
            this.imageResults_.add(i, imagesInfo);
        }

        private void addSegmentResults(int i, SegmentsInfo segmentsInfo) {
            segmentsInfo.getClass();
            ensureSegmentResultsIsMutable();
            this.segmentResults_.add(i, segmentsInfo);
        }

        private void addStreamResults(int i, StreamInfo streamInfo) {
            streamInfo.getClass();
            ensureStreamResultsIsMutable();
            this.streamResults_.add(i, streamInfo);
        }

        public static EgressInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (EgressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static EgressInfo parseFrom(byte[] bArr) {
            return (EgressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static EgressInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (EgressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static EgressInfo parseFrom(InputStream inputStream) {
            return (EgressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EgressInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EgressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EgressInfo parseFrom(CodedInputStream codedInputStream) {
            return (EgressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static EgressInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EgressInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface EgressInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum EgressSourceType implements Internal.EnumLite {
        b(0),
        c(1),
        d(-1);

        private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<EgressSourceType>() { // from class: livekit.LivekitEgress.EgressSourceType.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public EgressSourceType findValueByNumber(int i) {
                return EgressSourceType.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class EgressSourceTypeVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new EgressSourceTypeVerifier();

            private EgressSourceTypeVerifier() {
            }

            public boolean isInRange(int i) {
                return EgressSourceType.b(i) != null;
            }
        }

        EgressSourceType(int i) {
            this.a = i;
        }

        public static EgressSourceType b(int i) {
            if (i == 0) {
                return b;
            }
            if (i != 1) {
                return null;
            }
            return c;
        }

        public final int getNumber() {
            if (this != d) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum EgressStatus implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(4),
        g(5),
        h(6),
        i(-1);

        private static final Internal.EnumLiteMap j = new Internal.EnumLiteMap<EgressStatus>() { // from class: livekit.LivekitEgress.EgressStatus.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public EgressStatus findValueByNumber(int i2) {
                return EgressStatus.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class EgressStatusVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new EgressStatusVerifier();

            private EgressStatusVerifier() {
            }

            public boolean isInRange(int i) {
                return EgressStatus.b(i) != null;
            }
        }

        EgressStatus(int i2) {
            this.a = i2;
        }

        public static EgressStatus b(int i2) {
            switch (i2) {
                case 0:
                    return b;
                case 1:
                    return c;
                case 2:
                    return d;
                case 3:
                    return e;
                case 4:
                    return f;
                case 5:
                    return g;
                case 6:
                    return h;
                default:
                    return null;
            }
        }

        public final int getNumber() {
            if (this != i) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class EncodedFileOutput extends GeneratedMessageLite<EncodedFileOutput, Builder> implements EncodedFileOutputOrBuilder {
        public static final int ALIOSS_FIELD_NUMBER = 7;
        public static final int AZURE_FIELD_NUMBER = 5;
        private static final EncodedFileOutput DEFAULT_INSTANCE;
        public static final int DISABLE_MANIFEST_FIELD_NUMBER = 6;
        public static final int FILEPATH_FIELD_NUMBER = 2;
        public static final int FILE_TYPE_FIELD_NUMBER = 1;
        public static final int GCP_FIELD_NUMBER = 4;
        private static volatile Parser<EncodedFileOutput> PARSER = null;
        public static final int S3_FIELD_NUMBER = 3;
        private boolean disableManifest_;
        private int fileType_;
        private Object output_;
        private int outputCase_ = 0;
        private String filepath_ = ap.a(283564355);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<EncodedFileOutput, Builder> implements EncodedFileOutputOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(EncodedFileOutput.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OutputCase {
            b(3),
            c(4),
            d(5),
            e(7),
            f(0);

            private final int a;

            OutputCase(int i) {
                this.a = i;
            }

            public static OutputCase b(int i) {
                if (i == 0) {
                    return f;
                }
                if (i == 7) {
                    return e;
                }
                if (i == 3) {
                    return b;
                }
                if (i == 4) {
                    return c;
                }
                if (i != 5) {
                    return null;
                }
                return d;
            }
        }

        static {
            EncodedFileOutput encodedFileOutput = new EncodedFileOutput();
            DEFAULT_INSTANCE = encodedFileOutput;
            GeneratedMessageLite.registerDefaultInstance(EncodedFileOutput.class, encodedFileOutput);
        }

        private EncodedFileOutput() {
        }

        private void clearAliOSS() {
            if (this.outputCase_ == 7) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearAzure() {
            if (this.outputCase_ == 5) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearDisableManifest() {
            this.disableManifest_ = false;
        }

        private void clearFileType() {
            this.fileType_ = 0;
        }

        private void clearFilepath() {
            this.filepath_ = getDefaultInstance().getFilepath();
        }

        private void clearGcp() {
            if (this.outputCase_ == 4) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearOutput() {
            this.outputCase_ = 0;
            this.output_ = null;
        }

        private void clearS3() {
            if (this.outputCase_ == 3) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        public static EncodedFileOutput getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAliOSS(AliOSSUpload aliOSSUpload) {
            aliOSSUpload.getClass();
            if (this.outputCase_ != 7 || this.output_ == AliOSSUpload.getDefaultInstance()) {
                this.output_ = aliOSSUpload;
            } else {
                this.output_ = ((AliOSSUpload.Builder) AliOSSUpload.newBuilder((AliOSSUpload) this.output_).v(aliOSSUpload)).o();
            }
            this.outputCase_ = 7;
        }

        private void mergeAzure(AzureBlobUpload azureBlobUpload) {
            azureBlobUpload.getClass();
            if (this.outputCase_ != 5 || this.output_ == AzureBlobUpload.getDefaultInstance()) {
                this.output_ = azureBlobUpload;
            } else {
                this.output_ = ((AzureBlobUpload.Builder) AzureBlobUpload.newBuilder((AzureBlobUpload) this.output_).v(azureBlobUpload)).o();
            }
            this.outputCase_ = 5;
        }

        private void mergeGcp(GCPUpload gCPUpload) {
            gCPUpload.getClass();
            if (this.outputCase_ != 4 || this.output_ == GCPUpload.getDefaultInstance()) {
                this.output_ = gCPUpload;
            } else {
                this.output_ = ((GCPUpload.Builder) GCPUpload.newBuilder((GCPUpload) this.output_).v(gCPUpload)).o();
            }
            this.outputCase_ = 4;
        }

        private void mergeS3(S3Upload s3Upload) {
            s3Upload.getClass();
            if (this.outputCase_ != 3 || this.output_ == S3Upload.getDefaultInstance()) {
                this.output_ = s3Upload;
            } else {
                this.output_ = ((S3Upload.Builder) S3Upload.newBuilder((S3Upload) this.output_).v(s3Upload)).o();
            }
            this.outputCase_ = 3;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static EncodedFileOutput parseDelimitedFrom(InputStream inputStream) {
            return (EncodedFileOutput) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EncodedFileOutput parseFrom(ByteBuffer byteBuffer) {
            return (EncodedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<EncodedFileOutput> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAliOSS(AliOSSUpload aliOSSUpload) {
            aliOSSUpload.getClass();
            this.output_ = aliOSSUpload;
            this.outputCase_ = 7;
        }

        private void setAzure(AzureBlobUpload azureBlobUpload) {
            azureBlobUpload.getClass();
            this.output_ = azureBlobUpload;
            this.outputCase_ = 5;
        }

        private void setDisableManifest(boolean z) {
            this.disableManifest_ = z;
        }

        private void setFileType(EncodedFileType encodedFileType) {
            this.fileType_ = encodedFileType.getNumber();
        }

        private void setFileTypeValue(int i) {
            this.fileType_ = i;
        }

        private void setFilepath(String str) {
            str.getClass();
            this.filepath_ = str;
        }

        private void setFilepathBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.filepath_ = byteString.L();
        }

        private void setGcp(GCPUpload gCPUpload) {
            gCPUpload.getClass();
            this.output_ = gCPUpload;
            this.outputCase_ = 4;
        }

        private void setS3(S3Upload s3Upload) {
            s3Upload.getClass();
            this.output_ = s3Upload;
            this.outputCase_ = 3;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new EncodedFileOutput();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0001\u0000\u0001\u0007\u0007\u0000\u0000\u0000\u0001\f\u0002Ȉ\u0003<\u0000\u0004<\u0000\u0005<\u0000\u0006\u0007\u0007<\u0000", new Object[]{"output_", "outputCase_", "fileType_", "filepath_", S3Upload.class, GCPUpload.class, AzureBlobUpload.class, "disableManifest_", AliOSSUpload.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<EncodedFileOutput> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (EncodedFileOutput.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AliOSSUpload getAliOSS() {
            return this.outputCase_ == 7 ? (AliOSSUpload) this.output_ : AliOSSUpload.getDefaultInstance();
        }

        public AzureBlobUpload getAzure() {
            return this.outputCase_ == 5 ? (AzureBlobUpload) this.output_ : AzureBlobUpload.getDefaultInstance();
        }

        public boolean getDisableManifest() {
            return this.disableManifest_;
        }

        public EncodedFileType getFileType() {
            EncodedFileType encodedFileTypeB = EncodedFileType.b(this.fileType_);
            return encodedFileTypeB == null ? EncodedFileType.f : encodedFileTypeB;
        }

        public int getFileTypeValue() {
            return this.fileType_;
        }

        public String getFilepath() {
            return this.filepath_;
        }

        public ByteString getFilepathBytes() {
            return ByteString.n(this.filepath_);
        }

        public GCPUpload getGcp() {
            return this.outputCase_ == 4 ? (GCPUpload) this.output_ : GCPUpload.getDefaultInstance();
        }

        public OutputCase getOutputCase() {
            return OutputCase.b(this.outputCase_);
        }

        public S3Upload getS3() {
            return this.outputCase_ == 3 ? (S3Upload) this.output_ : S3Upload.getDefaultInstance();
        }

        public boolean hasAliOSS() {
            return this.outputCase_ == 7;
        }

        public boolean hasAzure() {
            return this.outputCase_ == 5;
        }

        public boolean hasGcp() {
            return this.outputCase_ == 4;
        }

        public boolean hasS3() {
            return this.outputCase_ == 3;
        }

        public static Builder newBuilder(EncodedFileOutput encodedFileOutput) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(encodedFileOutput);
        }

        public static EncodedFileOutput parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodedFileOutput) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EncodedFileOutput parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static EncodedFileOutput parseFrom(ByteString byteString) {
            return (EncodedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static EncodedFileOutput parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static EncodedFileOutput parseFrom(byte[] bArr) {
            return (EncodedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static EncodedFileOutput parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static EncodedFileOutput parseFrom(InputStream inputStream) {
            return (EncodedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EncodedFileOutput parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EncodedFileOutput parseFrom(CodedInputStream codedInputStream) {
            return (EncodedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static EncodedFileOutput parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface EncodedFileOutputOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum EncodedFileType implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(-1);

        private static final Internal.EnumLiteMap g = new Internal.EnumLiteMap<EncodedFileType>() { // from class: livekit.LivekitEgress.EncodedFileType.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public EncodedFileType findValueByNumber(int i) {
                return EncodedFileType.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class EncodedFileTypeVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new EncodedFileTypeVerifier();

            private EncodedFileTypeVerifier() {
            }

            public boolean isInRange(int i) {
                return EncodedFileType.b(i) != null;
            }
        }

        EncodedFileType(int i) {
            this.a = i;
        }

        public static EncodedFileType b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i == 2) {
                return d;
            }
            if (i != 3) {
                return null;
            }
            return e;
        }

        public final int getNumber() {
            if (this != f) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class EncodingOptions extends GeneratedMessageLite<EncodingOptions, Builder> implements EncodingOptionsOrBuilder {
        public static final int AUDIO_BITRATE_FIELD_NUMBER = 6;
        public static final int AUDIO_CODEC_FIELD_NUMBER = 5;
        public static final int AUDIO_FREQUENCY_FIELD_NUMBER = 7;
        public static final int AUDIO_QUALITY_FIELD_NUMBER = 11;
        private static final EncodingOptions DEFAULT_INSTANCE;
        public static final int DEPTH_FIELD_NUMBER = 3;
        public static final int FRAMERATE_FIELD_NUMBER = 4;
        public static final int HEIGHT_FIELD_NUMBER = 2;
        public static final int KEY_FRAME_INTERVAL_FIELD_NUMBER = 10;
        private static volatile Parser<EncodingOptions> PARSER = null;
        public static final int VIDEO_BITRATE_FIELD_NUMBER = 9;
        public static final int VIDEO_CODEC_FIELD_NUMBER = 8;
        public static final int VIDEO_QUALITY_FIELD_NUMBER = 12;
        public static final int WIDTH_FIELD_NUMBER = 1;
        private int audioBitrate_;
        private int audioCodec_;
        private int audioFrequency_;
        private int audioQuality_;
        private int depth_;
        private int framerate_;
        private int height_;
        private double keyFrameInterval_;
        private int videoBitrate_;
        private int videoCodec_;
        private int videoQuality_;
        private int width_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<EncodingOptions, Builder> implements EncodingOptionsOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(EncodingOptions.DEFAULT_INSTANCE);
            }
        }

        static {
            EncodingOptions encodingOptions = new EncodingOptions();
            DEFAULT_INSTANCE = encodingOptions;
            GeneratedMessageLite.registerDefaultInstance(EncodingOptions.class, encodingOptions);
        }

        private EncodingOptions() {
        }

        private void clearAudioBitrate() {
            this.audioBitrate_ = 0;
        }

        private void clearAudioCodec() {
            this.audioCodec_ = 0;
        }

        private void clearAudioFrequency() {
            this.audioFrequency_ = 0;
        }

        private void clearAudioQuality() {
            this.audioQuality_ = 0;
        }

        private void clearDepth() {
            this.depth_ = 0;
        }

        private void clearFramerate() {
            this.framerate_ = 0;
        }

        private void clearHeight() {
            this.height_ = 0;
        }

        private void clearKeyFrameInterval() {
            this.keyFrameInterval_ = 0.0d;
        }

        private void clearVideoBitrate() {
            this.videoBitrate_ = 0;
        }

        private void clearVideoCodec() {
            this.videoCodec_ = 0;
        }

        private void clearVideoQuality() {
            this.videoQuality_ = 0;
        }

        private void clearWidth() {
            this.width_ = 0;
        }

        public static EncodingOptions getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static EncodingOptions parseDelimitedFrom(InputStream inputStream) {
            return (EncodingOptions) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EncodingOptions parseFrom(ByteBuffer byteBuffer) {
            return (EncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<EncodingOptions> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAudioBitrate(int i) {
            this.audioBitrate_ = i;
        }

        private void setAudioCodec(LivekitModels.AudioCodec audioCodec) {
            this.audioCodec_ = audioCodec.getNumber();
        }

        private void setAudioCodecValue(int i) {
            this.audioCodec_ = i;
        }

        private void setAudioFrequency(int i) {
            this.audioFrequency_ = i;
        }

        private void setAudioQuality(int i) {
            this.audioQuality_ = i;
        }

        private void setDepth(int i) {
            this.depth_ = i;
        }

        private void setFramerate(int i) {
            this.framerate_ = i;
        }

        private void setHeight(int i) {
            this.height_ = i;
        }

        private void setKeyFrameInterval(double d) {
            this.keyFrameInterval_ = d;
        }

        private void setVideoBitrate(int i) {
            this.videoBitrate_ = i;
        }

        private void setVideoCodec(LivekitModels.VideoCodec videoCodec) {
            this.videoCodec_ = videoCodec.getNumber();
        }

        private void setVideoCodecValue(int i) {
            this.videoCodec_ = i;
        }

        private void setVideoQuality(int i) {
            this.videoQuality_ = i;
        }

        private void setWidth(int i) {
            this.width_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new EncodingOptions();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\f\u0000\u0000\u0001\f\f\u0000\u0000\u0000\u0001\u0004\u0002\u0004\u0003\u0004\u0004\u0004\u0005\f\u0006\u0004\u0007\u0004\b\f\t\u0004\n\u0000\u000b\u0004\f\u0004", new Object[]{ap.a(2059854867), ap.a(82111293), ap.a(40609652), ap.a(1089316122), ap.a(2048858483), ap.a(1073607235), ap.a(2080871306), ap.a(98187038), ap.a(1248767854), ap.a(2121040782), ap.a(1018535233), ap.a(936485735)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<EncodingOptions> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (EncodingOptions.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public int getAudioBitrate() {
            return this.audioBitrate_;
        }

        public LivekitModels.AudioCodec getAudioCodec() {
            LivekitModels.AudioCodec audioCodecB = LivekitModels.AudioCodec.b(this.audioCodec_);
            return audioCodecB == null ? LivekitModels.AudioCodec.f : audioCodecB;
        }

        public int getAudioCodecValue() {
            return this.audioCodec_;
        }

        public int getAudioFrequency() {
            return this.audioFrequency_;
        }

        public int getAudioQuality() {
            return this.audioQuality_;
        }

        public int getDepth() {
            return this.depth_;
        }

        public int getFramerate() {
            return this.framerate_;
        }

        public int getHeight() {
            return this.height_;
        }

        public double getKeyFrameInterval() {
            return this.keyFrameInterval_;
        }

        public int getVideoBitrate() {
            return this.videoBitrate_;
        }

        public LivekitModels.VideoCodec getVideoCodec() {
            LivekitModels.VideoCodec videoCodecB = LivekitModels.VideoCodec.b(this.videoCodec_);
            return videoCodecB == null ? LivekitModels.VideoCodec.g : videoCodecB;
        }

        public int getVideoCodecValue() {
            return this.videoCodec_;
        }

        public int getVideoQuality() {
            return this.videoQuality_;
        }

        public int getWidth() {
            return this.width_;
        }

        public static Builder newBuilder(EncodingOptions encodingOptions) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(encodingOptions);
        }

        public static EncodingOptions parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodingOptions) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EncodingOptions parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static EncodingOptions parseFrom(ByteString byteString) {
            return (EncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static EncodingOptions parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static EncodingOptions parseFrom(byte[] bArr) {
            return (EncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static EncodingOptions parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static EncodingOptions parseFrom(InputStream inputStream) {
            return (EncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static EncodingOptions parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static EncodingOptions parseFrom(CodedInputStream codedInputStream) {
            return (EncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static EncodingOptions parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (EncodingOptions) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface EncodingOptionsOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum EncodingOptionsPreset implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(3),
        f(4),
        g(5),
        h(6),
        i(7),
        j(-1);

        private static final Internal.EnumLiteMap k = new Internal.EnumLiteMap<EncodingOptionsPreset>() { // from class: livekit.LivekitEgress.EncodingOptionsPreset.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public EncodingOptionsPreset findValueByNumber(int i2) {
                return EncodingOptionsPreset.b(i2);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class EncodingOptionsPresetVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new EncodingOptionsPresetVerifier();

            private EncodingOptionsPresetVerifier() {
            }

            public boolean isInRange(int i) {
                return EncodingOptionsPreset.b(i) != null;
            }
        }

        EncodingOptionsPreset(int i2) {
            this.a = i2;
        }

        public static EncodingOptionsPreset b(int i2) {
            switch (i2) {
                case 0:
                    return b;
                case 1:
                    return c;
                case 2:
                    return d;
                case 3:
                    return e;
                case 4:
                    return f;
                case 5:
                    return g;
                case 6:
                    return h;
                case 7:
                    return i;
                default:
                    return null;
            }
        }

        public final int getNumber() {
            if (this != j) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class FileInfo extends GeneratedMessageLite<FileInfo, Builder> implements FileInfoOrBuilder {
        private static final FileInfo DEFAULT_INSTANCE;
        public static final int DURATION_FIELD_NUMBER = 6;
        public static final int ENDED_AT_FIELD_NUMBER = 3;
        public static final int FILENAME_FIELD_NUMBER = 1;
        public static final int LOCATION_FIELD_NUMBER = 5;
        private static volatile Parser<FileInfo> PARSER = null;
        public static final int SIZE_FIELD_NUMBER = 4;
        public static final int STARTED_AT_FIELD_NUMBER = 2;
        private long duration_;
        private long endedAt_;
        private String filename_;
        private String location_;
        private long size_;
        private long startedAt_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<FileInfo, Builder> implements FileInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(FileInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            FileInfo fileInfo = new FileInfo();
            DEFAULT_INSTANCE = fileInfo;
            GeneratedMessageLite.registerDefaultInstance(FileInfo.class, fileInfo);
        }

        private FileInfo() {
            String strA = ap.a(1843507225);
            this.filename_ = strA;
            this.location_ = strA;
        }

        private void clearDuration() {
            this.duration_ = 0L;
        }

        private void clearEndedAt() {
            this.endedAt_ = 0L;
        }

        private void clearFilename() {
            this.filename_ = getDefaultInstance().getFilename();
        }

        private void clearLocation() {
            this.location_ = getDefaultInstance().getLocation();
        }

        private void clearSize() {
            this.size_ = 0L;
        }

        private void clearStartedAt() {
            this.startedAt_ = 0L;
        }

        public static FileInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static FileInfo parseDelimitedFrom(InputStream inputStream) {
            return (FileInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static FileInfo parseFrom(ByteBuffer byteBuffer) {
            return (FileInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<FileInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDuration(long j) {
            this.duration_ = j;
        }

        private void setEndedAt(long j) {
            this.endedAt_ = j;
        }

        private void setFilename(String str) {
            str.getClass();
            this.filename_ = str;
        }

        private void setFilenameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.filename_ = byteString.L();
        }

        private void setLocation(String str) {
            str.getClass();
            this.location_ = str;
        }

        private void setLocationBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.location_ = byteString.L();
        }

        private void setSize(long j) {
            this.size_ = j;
        }

        private void setStartedAt(long j) {
            this.startedAt_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new FileInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001Ȉ\u0002\u0002\u0003\u0002\u0004\u0002\u0005Ȉ\u0006\u0002", new Object[]{"filename_", "startedAt_", "endedAt_", "size_", "location_", "duration_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<FileInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (FileInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getDuration() {
            return this.duration_;
        }

        public long getEndedAt() {
            return this.endedAt_;
        }

        public String getFilename() {
            return this.filename_;
        }

        public ByteString getFilenameBytes() {
            return ByteString.n(this.filename_);
        }

        public String getLocation() {
            return this.location_;
        }

        public ByteString getLocationBytes() {
            return ByteString.n(this.location_);
        }

        public long getSize() {
            return this.size_;
        }

        public long getStartedAt() {
            return this.startedAt_;
        }

        public static Builder newBuilder(FileInfo fileInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(fileInfo);
        }

        public static FileInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (FileInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static FileInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (FileInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static FileInfo parseFrom(ByteString byteString) {
            return (FileInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static FileInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (FileInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static FileInfo parseFrom(byte[] bArr) {
            return (FileInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static FileInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (FileInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static FileInfo parseFrom(InputStream inputStream) {
            return (FileInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static FileInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (FileInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static FileInfo parseFrom(CodedInputStream codedInputStream) {
            return (FileInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static FileInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (FileInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface FileInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class GCPUpload extends GeneratedMessageLite<GCPUpload, Builder> implements GCPUploadOrBuilder {
        public static final int BUCKET_FIELD_NUMBER = 2;
        public static final int CREDENTIALS_FIELD_NUMBER = 1;
        private static final GCPUpload DEFAULT_INSTANCE;
        private static volatile Parser<GCPUpload> PARSER = null;
        public static final int PROXY_FIELD_NUMBER = 3;
        private String bucket_;
        private String credentials_;
        private ProxyConfig proxy_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<GCPUpload, Builder> implements GCPUploadOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(GCPUpload.DEFAULT_INSTANCE);
            }
        }

        static {
            GCPUpload gCPUpload = new GCPUpload();
            DEFAULT_INSTANCE = gCPUpload;
            GeneratedMessageLite.registerDefaultInstance(GCPUpload.class, gCPUpload);
        }

        private GCPUpload() {
            String strA = ap.a(1984803039);
            this.credentials_ = strA;
            this.bucket_ = strA;
        }

        private void clearBucket() {
            this.bucket_ = getDefaultInstance().getBucket();
        }

        private void clearCredentials() {
            this.credentials_ = getDefaultInstance().getCredentials();
        }

        private void clearProxy() {
            this.proxy_ = null;
        }

        public static GCPUpload getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeProxy(ProxyConfig proxyConfig) {
            proxyConfig.getClass();
            ProxyConfig proxyConfig2 = this.proxy_;
            if (proxyConfig2 == null || proxyConfig2 == ProxyConfig.getDefaultInstance()) {
                this.proxy_ = proxyConfig;
            } else {
                this.proxy_ = (ProxyConfig) ((ProxyConfig.Builder) ProxyConfig.newBuilder(this.proxy_).v(proxyConfig)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static GCPUpload parseDelimitedFrom(InputStream inputStream) {
            return (GCPUpload) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GCPUpload parseFrom(ByteBuffer byteBuffer) {
            return (GCPUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<GCPUpload> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setBucket(String str) {
            str.getClass();
            this.bucket_ = str;
        }

        private void setBucketBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.bucket_ = byteString.L();
        }

        private void setCredentials(String str) {
            str.getClass();
            this.credentials_ = str;
        }

        private void setCredentialsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.credentials_ = byteString.L();
        }

        private void setProxy(ProxyConfig proxyConfig) {
            proxyConfig.getClass();
            this.proxy_ = proxyConfig;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new GCPUpload();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\t", new Object[]{"credentials_", "bucket_", "proxy_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<GCPUpload> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (GCPUpload.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getBucket() {
            return this.bucket_;
        }

        public ByteString getBucketBytes() {
            return ByteString.n(this.bucket_);
        }

        public String getCredentials() {
            return this.credentials_;
        }

        public ByteString getCredentialsBytes() {
            return ByteString.n(this.credentials_);
        }

        public ProxyConfig getProxy() {
            ProxyConfig proxyConfig = this.proxy_;
            return proxyConfig == null ? ProxyConfig.getDefaultInstance() : proxyConfig;
        }

        public boolean hasProxy() {
            return this.proxy_ != null;
        }

        public static Builder newBuilder(GCPUpload gCPUpload) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(gCPUpload);
        }

        public static GCPUpload parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GCPUpload) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GCPUpload parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (GCPUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static GCPUpload parseFrom(ByteString byteString) {
            return (GCPUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static GCPUpload parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (GCPUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static GCPUpload parseFrom(byte[] bArr) {
            return (GCPUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static GCPUpload parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (GCPUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static GCPUpload parseFrom(InputStream inputStream) {
            return (GCPUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static GCPUpload parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GCPUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static GCPUpload parseFrom(CodedInputStream codedInputStream) {
            return (GCPUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static GCPUpload parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (GCPUpload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface GCPUploadOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum ImageFileSuffix implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<ImageFileSuffix>() { // from class: livekit.LivekitEgress.ImageFileSuffix.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public ImageFileSuffix findValueByNumber(int i) {
                return ImageFileSuffix.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class ImageFileSuffixVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new ImageFileSuffixVerifier();

            private ImageFileSuffixVerifier() {
            }

            public boolean isInRange(int i) {
                return ImageFileSuffix.b(i) != null;
            }
        }

        ImageFileSuffix(int i) {
            this.a = i;
        }

        public static ImageFileSuffix b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ImageOutput extends GeneratedMessageLite<ImageOutput, Builder> implements ImageOutputOrBuilder {
        public static final int ALIOSS_FIELD_NUMBER = 11;
        public static final int AZURE_FIELD_NUMBER = 10;
        public static final int CAPTURE_INTERVAL_FIELD_NUMBER = 1;
        private static final ImageOutput DEFAULT_INSTANCE;
        public static final int DISABLE_MANIFEST_FIELD_NUMBER = 7;
        public static final int FILENAME_PREFIX_FIELD_NUMBER = 4;
        public static final int FILENAME_SUFFIX_FIELD_NUMBER = 5;
        public static final int GCP_FIELD_NUMBER = 9;
        public static final int HEIGHT_FIELD_NUMBER = 3;
        public static final int IMAGE_CODEC_FIELD_NUMBER = 6;
        private static volatile Parser<ImageOutput> PARSER = null;
        public static final int S3_FIELD_NUMBER = 8;
        public static final int WIDTH_FIELD_NUMBER = 2;
        private int captureInterval_;
        private boolean disableManifest_;
        private int filenameSuffix_;
        private int height_;
        private int imageCodec_;
        private Object output_;
        private int width_;
        private int outputCase_ = 0;
        private String filenamePrefix_ = ap.a(1278922864);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ImageOutput, Builder> implements ImageOutputOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ImageOutput.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OutputCase {
            b(8),
            c(9),
            d(10),
            e(11),
            f(0);

            private final int a;

            OutputCase(int i) {
                this.a = i;
            }

            public static OutputCase b(int i) {
                if (i == 0) {
                    return f;
                }
                switch (i) {
                    case 8:
                        return b;
                    case 9:
                        return c;
                    case 10:
                        return d;
                    case 11:
                        return e;
                    default:
                        return null;
                }
            }
        }

        static {
            ImageOutput imageOutput = new ImageOutput();
            DEFAULT_INSTANCE = imageOutput;
            GeneratedMessageLite.registerDefaultInstance(ImageOutput.class, imageOutput);
        }

        private ImageOutput() {
        }

        private void clearAliOSS() {
            if (this.outputCase_ == 11) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearAzure() {
            if (this.outputCase_ == 10) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearCaptureInterval() {
            this.captureInterval_ = 0;
        }

        private void clearDisableManifest() {
            this.disableManifest_ = false;
        }

        private void clearFilenamePrefix() {
            this.filenamePrefix_ = getDefaultInstance().getFilenamePrefix();
        }

        private void clearFilenameSuffix() {
            this.filenameSuffix_ = 0;
        }

        private void clearGcp() {
            if (this.outputCase_ == 9) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearHeight() {
            this.height_ = 0;
        }

        private void clearImageCodec() {
            this.imageCodec_ = 0;
        }

        private void clearOutput() {
            this.outputCase_ = 0;
            this.output_ = null;
        }

        private void clearS3() {
            if (this.outputCase_ == 8) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearWidth() {
            this.width_ = 0;
        }

        public static ImageOutput getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAliOSS(AliOSSUpload aliOSSUpload) {
            aliOSSUpload.getClass();
            if (this.outputCase_ != 11 || this.output_ == AliOSSUpload.getDefaultInstance()) {
                this.output_ = aliOSSUpload;
            } else {
                this.output_ = ((AliOSSUpload.Builder) AliOSSUpload.newBuilder((AliOSSUpload) this.output_).v(aliOSSUpload)).o();
            }
            this.outputCase_ = 11;
        }

        private void mergeAzure(AzureBlobUpload azureBlobUpload) {
            azureBlobUpload.getClass();
            if (this.outputCase_ != 10 || this.output_ == AzureBlobUpload.getDefaultInstance()) {
                this.output_ = azureBlobUpload;
            } else {
                this.output_ = ((AzureBlobUpload.Builder) AzureBlobUpload.newBuilder((AzureBlobUpload) this.output_).v(azureBlobUpload)).o();
            }
            this.outputCase_ = 10;
        }

        private void mergeGcp(GCPUpload gCPUpload) {
            gCPUpload.getClass();
            if (this.outputCase_ != 9 || this.output_ == GCPUpload.getDefaultInstance()) {
                this.output_ = gCPUpload;
            } else {
                this.output_ = ((GCPUpload.Builder) GCPUpload.newBuilder((GCPUpload) this.output_).v(gCPUpload)).o();
            }
            this.outputCase_ = 9;
        }

        private void mergeS3(S3Upload s3Upload) {
            s3Upload.getClass();
            if (this.outputCase_ != 8 || this.output_ == S3Upload.getDefaultInstance()) {
                this.output_ = s3Upload;
            } else {
                this.output_ = ((S3Upload.Builder) S3Upload.newBuilder((S3Upload) this.output_).v(s3Upload)).o();
            }
            this.outputCase_ = 8;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ImageOutput parseDelimitedFrom(InputStream inputStream) {
            return (ImageOutput) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ImageOutput parseFrom(ByteBuffer byteBuffer) {
            return (ImageOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ImageOutput> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAliOSS(AliOSSUpload aliOSSUpload) {
            aliOSSUpload.getClass();
            this.output_ = aliOSSUpload;
            this.outputCase_ = 11;
        }

        private void setAzure(AzureBlobUpload azureBlobUpload) {
            azureBlobUpload.getClass();
            this.output_ = azureBlobUpload;
            this.outputCase_ = 10;
        }

        private void setCaptureInterval(int i) {
            this.captureInterval_ = i;
        }

        private void setDisableManifest(boolean z) {
            this.disableManifest_ = z;
        }

        private void setFilenamePrefix(String str) {
            str.getClass();
            this.filenamePrefix_ = str;
        }

        private void setFilenamePrefixBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.filenamePrefix_ = byteString.L();
        }

        private void setFilenameSuffix(ImageFileSuffix imageFileSuffix) {
            this.filenameSuffix_ = imageFileSuffix.getNumber();
        }

        private void setFilenameSuffixValue(int i) {
            this.filenameSuffix_ = i;
        }

        private void setGcp(GCPUpload gCPUpload) {
            gCPUpload.getClass();
            this.output_ = gCPUpload;
            this.outputCase_ = 9;
        }

        private void setHeight(int i) {
            this.height_ = i;
        }

        private void setImageCodec(LivekitModels.ImageCodec imageCodec) {
            this.imageCodec_ = imageCodec.getNumber();
        }

        private void setImageCodecValue(int i) {
            this.imageCodec_ = i;
        }

        private void setS3(S3Upload s3Upload) {
            s3Upload.getClass();
            this.output_ = s3Upload;
            this.outputCase_ = 8;
        }

        private void setWidth(int i) {
            this.width_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ImageOutput();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000b\u0001\u0000\u0001\u000b\u000b\u0000\u0000\u0000\u0001\u000b\u0002\u0004\u0003\u0004\u0004Ȉ\u0005\f\u0006\f\u0007\u0007\b<\u0000\t<\u0000\n<\u0000\u000b<\u0000", new Object[]{"output_", "outputCase_", "captureInterval_", "width_", "height_", "filenamePrefix_", "filenameSuffix_", "imageCodec_", "disableManifest_", S3Upload.class, GCPUpload.class, AzureBlobUpload.class, AliOSSUpload.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ImageOutput> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ImageOutput.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AliOSSUpload getAliOSS() {
            return this.outputCase_ == 11 ? (AliOSSUpload) this.output_ : AliOSSUpload.getDefaultInstance();
        }

        public AzureBlobUpload getAzure() {
            return this.outputCase_ == 10 ? (AzureBlobUpload) this.output_ : AzureBlobUpload.getDefaultInstance();
        }

        public int getCaptureInterval() {
            return this.captureInterval_;
        }

        public boolean getDisableManifest() {
            return this.disableManifest_;
        }

        public String getFilenamePrefix() {
            return this.filenamePrefix_;
        }

        public ByteString getFilenamePrefixBytes() {
            return ByteString.n(this.filenamePrefix_);
        }

        public ImageFileSuffix getFilenameSuffix() {
            ImageFileSuffix imageFileSuffixB = ImageFileSuffix.b(this.filenameSuffix_);
            return imageFileSuffixB == null ? ImageFileSuffix.e : imageFileSuffixB;
        }

        public int getFilenameSuffixValue() {
            return this.filenameSuffix_;
        }

        public GCPUpload getGcp() {
            return this.outputCase_ == 9 ? (GCPUpload) this.output_ : GCPUpload.getDefaultInstance();
        }

        public int getHeight() {
            return this.height_;
        }

        public LivekitModels.ImageCodec getImageCodec() {
            LivekitModels.ImageCodec imageCodecB = LivekitModels.ImageCodec.b(this.imageCodec_);
            return imageCodecB == null ? LivekitModels.ImageCodec.d : imageCodecB;
        }

        public int getImageCodecValue() {
            return this.imageCodec_;
        }

        public OutputCase getOutputCase() {
            return OutputCase.b(this.outputCase_);
        }

        public S3Upload getS3() {
            return this.outputCase_ == 8 ? (S3Upload) this.output_ : S3Upload.getDefaultInstance();
        }

        public int getWidth() {
            return this.width_;
        }

        public boolean hasAliOSS() {
            return this.outputCase_ == 11;
        }

        public boolean hasAzure() {
            return this.outputCase_ == 10;
        }

        public boolean hasGcp() {
            return this.outputCase_ == 9;
        }

        public boolean hasS3() {
            return this.outputCase_ == 8;
        }

        public static Builder newBuilder(ImageOutput imageOutput) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(imageOutput);
        }

        public static ImageOutput parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ImageOutput) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ImageOutput parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ImageOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ImageOutput parseFrom(ByteString byteString) {
            return (ImageOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ImageOutput parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ImageOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ImageOutput parseFrom(byte[] bArr) {
            return (ImageOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ImageOutput parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ImageOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ImageOutput parseFrom(InputStream inputStream) {
            return (ImageOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ImageOutput parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ImageOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ImageOutput parseFrom(CodedInputStream codedInputStream) {
            return (ImageOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ImageOutput parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ImageOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ImageOutputOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ImagesInfo extends GeneratedMessageLite<ImagesInfo, Builder> implements ImagesInfoOrBuilder {
        private static final ImagesInfo DEFAULT_INSTANCE;
        public static final int ENDED_AT_FIELD_NUMBER = 3;
        public static final int FILENAME_PREFIX_FIELD_NUMBER = 4;
        public static final int IMAGE_COUNT_FIELD_NUMBER = 1;
        private static volatile Parser<ImagesInfo> PARSER = null;
        public static final int STARTED_AT_FIELD_NUMBER = 2;
        private long endedAt_;
        private String filenamePrefix_ = ap.a(1049380311);
        private long imageCount_;
        private long startedAt_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ImagesInfo, Builder> implements ImagesInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ImagesInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            ImagesInfo imagesInfo = new ImagesInfo();
            DEFAULT_INSTANCE = imagesInfo;
            GeneratedMessageLite.registerDefaultInstance(ImagesInfo.class, imagesInfo);
        }

        private ImagesInfo() {
        }

        private void clearEndedAt() {
            this.endedAt_ = 0L;
        }

        private void clearFilenamePrefix() {
            this.filenamePrefix_ = getDefaultInstance().getFilenamePrefix();
        }

        private void clearImageCount() {
            this.imageCount_ = 0L;
        }

        private void clearStartedAt() {
            this.startedAt_ = 0L;
        }

        public static ImagesInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ImagesInfo parseDelimitedFrom(InputStream inputStream) {
            return (ImagesInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ImagesInfo parseFrom(ByteBuffer byteBuffer) {
            return (ImagesInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ImagesInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setEndedAt(long j) {
            this.endedAt_ = j;
        }

        private void setFilenamePrefix(String str) {
            str.getClass();
            this.filenamePrefix_ = str;
        }

        private void setFilenamePrefixBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.filenamePrefix_ = byteString.L();
        }

        private void setImageCount(long j) {
            this.imageCount_ = j;
        }

        private void setStartedAt(long j) {
            this.startedAt_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ImagesInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0000\u0000\u0001\u0002\u0002\u0002\u0003\u0002\u0004Ȉ", new Object[]{"imageCount_", "startedAt_", "endedAt_", "filenamePrefix_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ImagesInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ImagesInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getEndedAt() {
            return this.endedAt_;
        }

        public String getFilenamePrefix() {
            return this.filenamePrefix_;
        }

        public ByteString getFilenamePrefixBytes() {
            return ByteString.n(this.filenamePrefix_);
        }

        public long getImageCount() {
            return this.imageCount_;
        }

        public long getStartedAt() {
            return this.startedAt_;
        }

        public static Builder newBuilder(ImagesInfo imagesInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(imagesInfo);
        }

        public static ImagesInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ImagesInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ImagesInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ImagesInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ImagesInfo parseFrom(ByteString byteString) {
            return (ImagesInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ImagesInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ImagesInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ImagesInfo parseFrom(byte[] bArr) {
            return (ImagesInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ImagesInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ImagesInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ImagesInfo parseFrom(InputStream inputStream) {
            return (ImagesInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ImagesInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ImagesInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ImagesInfo parseFrom(CodedInputStream codedInputStream) {
            return (ImagesInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ImagesInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ImagesInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ImagesInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListEgressRequest extends GeneratedMessageLite<ListEgressRequest, Builder> implements ListEgressRequestOrBuilder {
        public static final int ACTIVE_FIELD_NUMBER = 3;
        private static final ListEgressRequest DEFAULT_INSTANCE;
        public static final int EGRESS_ID_FIELD_NUMBER = 2;
        private static volatile Parser<ListEgressRequest> PARSER = null;
        public static final int ROOM_NAME_FIELD_NUMBER = 1;
        private boolean active_;
        private String egressId_;
        private String roomName_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListEgressRequest, Builder> implements ListEgressRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListEgressRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListEgressRequest listEgressRequest = new ListEgressRequest();
            DEFAULT_INSTANCE = listEgressRequest;
            GeneratedMessageLite.registerDefaultInstance(ListEgressRequest.class, listEgressRequest);
        }

        private ListEgressRequest() {
            String strA = ap.a(1634884656);
            this.roomName_ = strA;
            this.egressId_ = strA;
        }

        private void clearActive() {
            this.active_ = false;
        }

        private void clearEgressId() {
            this.egressId_ = getDefaultInstance().getEgressId();
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        public static ListEgressRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListEgressRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListEgressRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListEgressRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setActive(boolean z) {
            this.active_ = z;
        }

        private void setEgressId(String str) {
            str.getClass();
            this.egressId_ = str;
        }

        private void setEgressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.egressId_ = byteString.L();
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListEgressRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003\u0007", new Object[]{"roomName_", "egressId_", "active_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListEgressRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListEgressRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public boolean getActive() {
            return this.active_;
        }

        public String getEgressId() {
            return this.egressId_;
        }

        public ByteString getEgressIdBytes() {
            return ByteString.n(this.egressId_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public static Builder newBuilder(ListEgressRequest listEgressRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listEgressRequest);
        }

        public static ListEgressRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListEgressRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListEgressRequest parseFrom(ByteString byteString) {
            return (ListEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListEgressRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListEgressRequest parseFrom(byte[] bArr) {
            return (ListEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListEgressRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListEgressRequest parseFrom(InputStream inputStream) {
            return (ListEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListEgressRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListEgressRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListEgressRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListEgressRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListEgressResponse extends GeneratedMessageLite<ListEgressResponse, Builder> implements ListEgressResponseOrBuilder {
        private static final ListEgressResponse DEFAULT_INSTANCE;
        public static final int ITEMS_FIELD_NUMBER = 1;
        private static volatile Parser<ListEgressResponse> PARSER;
        private Internal.ProtobufList<EgressInfo> items_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListEgressResponse, Builder> implements ListEgressResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListEgressResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListEgressResponse listEgressResponse = new ListEgressResponse();
            DEFAULT_INSTANCE = listEgressResponse;
            GeneratedMessageLite.registerDefaultInstance(ListEgressResponse.class, listEgressResponse);
        }

        private ListEgressResponse() {
        }

        private void addAllItems(Iterable<? extends EgressInfo> iterable) {
            ensureItemsIsMutable();
            AbstractMessageLite.addAll(iterable, this.items_);
        }

        private void addItems(EgressInfo egressInfo) {
            egressInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(egressInfo);
        }

        private void clearItems() {
            this.items_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureItemsIsMutable() {
            Internal.ProtobufList<EgressInfo> protobufList = this.items_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.items_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListEgressResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListEgressResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListEgressResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListEgressResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListEgressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListEgressResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeItems(int i) {
            ensureItemsIsMutable();
            this.items_.remove(i);
        }

        private void setItems(int i, EgressInfo egressInfo) {
            egressInfo.getClass();
            ensureItemsIsMutable();
            this.items_.set(i, egressInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListEgressResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1660044931), EgressInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListEgressResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListEgressResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public EgressInfo getItems(int i) {
            return (EgressInfo) this.items_.get(i);
        }

        public int getItemsCount() {
            return this.items_.size();
        }

        public List<EgressInfo> getItemsList() {
            return this.items_;
        }

        public EgressInfoOrBuilder getItemsOrBuilder(int i) {
            return (EgressInfoOrBuilder) this.items_.get(i);
        }

        public List<? extends EgressInfoOrBuilder> getItemsOrBuilderList() {
            return this.items_;
        }

        public static Builder newBuilder(ListEgressResponse listEgressResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listEgressResponse);
        }

        public static ListEgressResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListEgressResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListEgressResponse parseFrom(ByteString byteString) {
            return (ListEgressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addItems(int i, EgressInfo egressInfo) {
            egressInfo.getClass();
            ensureItemsIsMutable();
            this.items_.add(i, egressInfo);
        }

        public static ListEgressResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListEgressResponse parseFrom(byte[] bArr) {
            return (ListEgressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListEgressResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListEgressResponse parseFrom(InputStream inputStream) {
            return (ListEgressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListEgressResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListEgressResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListEgressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListEgressResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListEgressResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListEgressResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ParticipantEgressRequest extends GeneratedMessageLite<ParticipantEgressRequest, Builder> implements ParticipantEgressRequestOrBuilder {
        public static final int ADVANCED_FIELD_NUMBER = 5;
        private static final ParticipantEgressRequest DEFAULT_INSTANCE;
        public static final int FILE_OUTPUTS_FIELD_NUMBER = 6;
        public static final int IDENTITY_FIELD_NUMBER = 2;
        public static final int IMAGE_OUTPUTS_FIELD_NUMBER = 9;
        private static volatile Parser<ParticipantEgressRequest> PARSER = null;
        public static final int PRESET_FIELD_NUMBER = 4;
        public static final int ROOM_NAME_FIELD_NUMBER = 1;
        public static final int SCREEN_SHARE_FIELD_NUMBER = 3;
        public static final int SEGMENT_OUTPUTS_FIELD_NUMBER = 8;
        public static final int STREAM_OUTPUTS_FIELD_NUMBER = 7;
        public static final int WEBHOOKS_FIELD_NUMBER = 10;
        private Internal.ProtobufList<EncodedFileOutput> fileOutputs_;
        private String identity_;
        private Internal.ProtobufList<ImageOutput> imageOutputs_;
        private int optionsCase_ = 0;
        private Object options_;
        private String roomName_;
        private boolean screenShare_;
        private Internal.ProtobufList<SegmentedFileOutput> segmentOutputs_;
        private Internal.ProtobufList<StreamOutput> streamOutputs_;
        private Internal.ProtobufList<LivekitModels.WebhookConfig> webhooks_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ParticipantEgressRequest, Builder> implements ParticipantEgressRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ParticipantEgressRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OptionsCase {
            b(4),
            c(5),
            d(0);

            private final int a;

            OptionsCase(int i) {
                this.a = i;
            }

            public static OptionsCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 4) {
                    return b;
                }
                if (i != 5) {
                    return null;
                }
                return c;
            }
        }

        static {
            ParticipantEgressRequest participantEgressRequest = new ParticipantEgressRequest();
            DEFAULT_INSTANCE = participantEgressRequest;
            GeneratedMessageLite.registerDefaultInstance(ParticipantEgressRequest.class, participantEgressRequest);
        }

        private ParticipantEgressRequest() {
            String strA = ap.a(489362923);
            this.roomName_ = strA;
            this.identity_ = strA;
            this.fileOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.streamOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.segmentOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.imageOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.webhooks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllFileOutputs(Iterable<? extends EncodedFileOutput> iterable) {
            ensureFileOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.fileOutputs_);
        }

        private void addAllImageOutputs(Iterable<? extends ImageOutput> iterable) {
            ensureImageOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.imageOutputs_);
        }

        private void addAllSegmentOutputs(Iterable<? extends SegmentedFileOutput> iterable) {
            ensureSegmentOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.segmentOutputs_);
        }

        private void addAllStreamOutputs(Iterable<? extends StreamOutput> iterable) {
            ensureStreamOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.streamOutputs_);
        }

        private void addAllWebhooks(Iterable<? extends LivekitModels.WebhookConfig> iterable) {
            ensureWebhooksIsMutable();
            AbstractMessageLite.addAll(iterable, this.webhooks_);
        }

        private void addFileOutputs(EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.add(encodedFileOutput);
        }

        private void addImageOutputs(ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.add(imageOutput);
        }

        private void addSegmentOutputs(SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.add(segmentedFileOutput);
        }

        private void addStreamOutputs(StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.add(streamOutput);
        }

        private void addWebhooks(LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.add(webhookConfig);
        }

        private void clearAdvanced() {
            if (this.optionsCase_ == 5) {
                this.optionsCase_ = 0;
                this.options_ = null;
            }
        }

        private void clearFileOutputs() {
            this.fileOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearIdentity() {
            this.identity_ = getDefaultInstance().getIdentity();
        }

        private void clearImageOutputs() {
            this.imageOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearOptions() {
            this.optionsCase_ = 0;
            this.options_ = null;
        }

        private void clearPreset() {
            if (this.optionsCase_ == 4) {
                this.optionsCase_ = 0;
                this.options_ = null;
            }
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearScreenShare() {
            this.screenShare_ = false;
        }

        private void clearSegmentOutputs() {
            this.segmentOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearStreamOutputs() {
            this.streamOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearWebhooks() {
            this.webhooks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureFileOutputsIsMutable() {
            Internal.ProtobufList<EncodedFileOutput> protobufList = this.fileOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.fileOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureImageOutputsIsMutable() {
            Internal.ProtobufList<ImageOutput> protobufList = this.imageOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.imageOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSegmentOutputsIsMutable() {
            Internal.ProtobufList<SegmentedFileOutput> protobufList = this.segmentOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.segmentOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureStreamOutputsIsMutable() {
            Internal.ProtobufList<StreamOutput> protobufList = this.streamOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.streamOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureWebhooksIsMutable() {
            Internal.ProtobufList<LivekitModels.WebhookConfig> protobufList = this.webhooks_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.webhooks_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ParticipantEgressRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAdvanced(EncodingOptions encodingOptions) {
            encodingOptions.getClass();
            if (this.optionsCase_ != 5 || this.options_ == EncodingOptions.getDefaultInstance()) {
                this.options_ = encodingOptions;
            } else {
                this.options_ = ((EncodingOptions.Builder) EncodingOptions.newBuilder((EncodingOptions) this.options_).v(encodingOptions)).o();
            }
            this.optionsCase_ = 5;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ParticipantEgressRequest parseDelimitedFrom(InputStream inputStream) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ParticipantEgressRequest parseFrom(ByteBuffer byteBuffer) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ParticipantEgressRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeFileOutputs(int i) {
            ensureFileOutputsIsMutable();
            this.fileOutputs_.remove(i);
        }

        private void removeImageOutputs(int i) {
            ensureImageOutputsIsMutable();
            this.imageOutputs_.remove(i);
        }

        private void removeSegmentOutputs(int i) {
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.remove(i);
        }

        private void removeStreamOutputs(int i) {
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.remove(i);
        }

        private void removeWebhooks(int i) {
            ensureWebhooksIsMutable();
            this.webhooks_.remove(i);
        }

        private void setAdvanced(EncodingOptions encodingOptions) {
            encodingOptions.getClass();
            this.options_ = encodingOptions;
            this.optionsCase_ = 5;
        }

        private void setFileOutputs(int i, EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.set(i, encodedFileOutput);
        }

        private void setIdentity(String str) {
            str.getClass();
            this.identity_ = str;
        }

        private void setIdentityBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.identity_ = byteString.L();
        }

        private void setImageOutputs(int i, ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.set(i, imageOutput);
        }

        private void setPreset(EncodingOptionsPreset encodingOptionsPreset) {
            this.options_ = Integer.valueOf(encodingOptionsPreset.getNumber());
            this.optionsCase_ = 4;
        }

        private void setPresetValue(int i) {
            this.optionsCase_ = 4;
            this.options_ = Integer.valueOf(i);
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setScreenShare(boolean z) {
            this.screenShare_ = z;
        }

        private void setSegmentOutputs(int i, SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.set(i, segmentedFileOutput);
        }

        private void setStreamOutputs(int i, StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.set(i, streamOutput);
        }

        private void setWebhooks(int i, LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.set(i, webhookConfig);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new ParticipantEgressRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\n\u0001\u0000\u0001\n\n\u0000\u0005\u0000\u0001Ȉ\u0002Ȉ\u0003\u0007\u0004?\u0000\u0005<\u0000\u0006\u001b\u0007\u001b\b\u001b\t\u001b\n\u001b", new Object[]{"options_", "optionsCase_", "roomName_", "identity_", "screenShare_", EncodingOptions.class, "fileOutputs_", EncodedFileOutput.class, "streamOutputs_", StreamOutput.class, "segmentOutputs_", SegmentedFileOutput.class, "imageOutputs_", ImageOutput.class, "webhooks_", LivekitModels.WebhookConfig.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ParticipantEgressRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ParticipantEgressRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public EncodingOptions getAdvanced() {
            return this.optionsCase_ == 5 ? (EncodingOptions) this.options_ : EncodingOptions.getDefaultInstance();
        }

        public EncodedFileOutput getFileOutputs(int i) {
            return (EncodedFileOutput) this.fileOutputs_.get(i);
        }

        public int getFileOutputsCount() {
            return this.fileOutputs_.size();
        }

        public List<EncodedFileOutput> getFileOutputsList() {
            return this.fileOutputs_;
        }

        public EncodedFileOutputOrBuilder getFileOutputsOrBuilder(int i) {
            return (EncodedFileOutputOrBuilder) this.fileOutputs_.get(i);
        }

        public List<? extends EncodedFileOutputOrBuilder> getFileOutputsOrBuilderList() {
            return this.fileOutputs_;
        }

        public String getIdentity() {
            return this.identity_;
        }

        public ByteString getIdentityBytes() {
            return ByteString.n(this.identity_);
        }

        public ImageOutput getImageOutputs(int i) {
            return (ImageOutput) this.imageOutputs_.get(i);
        }

        public int getImageOutputsCount() {
            return this.imageOutputs_.size();
        }

        public List<ImageOutput> getImageOutputsList() {
            return this.imageOutputs_;
        }

        public ImageOutputOrBuilder getImageOutputsOrBuilder(int i) {
            return (ImageOutputOrBuilder) this.imageOutputs_.get(i);
        }

        public List<? extends ImageOutputOrBuilder> getImageOutputsOrBuilderList() {
            return this.imageOutputs_;
        }

        public OptionsCase getOptionsCase() {
            return OptionsCase.b(this.optionsCase_);
        }

        public EncodingOptionsPreset getPreset() {
            if (this.optionsCase_ != 4) {
                return EncodingOptionsPreset.b;
            }
            EncodingOptionsPreset encodingOptionsPresetB = EncodingOptionsPreset.b(((Integer) this.options_).intValue());
            return encodingOptionsPresetB == null ? EncodingOptionsPreset.j : encodingOptionsPresetB;
        }

        public int getPresetValue() {
            if (this.optionsCase_ == 4) {
                return ((Integer) this.options_).intValue();
            }
            return 0;
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public boolean getScreenShare() {
            return this.screenShare_;
        }

        public SegmentedFileOutput getSegmentOutputs(int i) {
            return (SegmentedFileOutput) this.segmentOutputs_.get(i);
        }

        public int getSegmentOutputsCount() {
            return this.segmentOutputs_.size();
        }

        public List<SegmentedFileOutput> getSegmentOutputsList() {
            return this.segmentOutputs_;
        }

        public SegmentedFileOutputOrBuilder getSegmentOutputsOrBuilder(int i) {
            return (SegmentedFileOutputOrBuilder) this.segmentOutputs_.get(i);
        }

        public List<? extends SegmentedFileOutputOrBuilder> getSegmentOutputsOrBuilderList() {
            return this.segmentOutputs_;
        }

        public StreamOutput getStreamOutputs(int i) {
            return (StreamOutput) this.streamOutputs_.get(i);
        }

        public int getStreamOutputsCount() {
            return this.streamOutputs_.size();
        }

        public List<StreamOutput> getStreamOutputsList() {
            return this.streamOutputs_;
        }

        public StreamOutputOrBuilder getStreamOutputsOrBuilder(int i) {
            return (StreamOutputOrBuilder) this.streamOutputs_.get(i);
        }

        public List<? extends StreamOutputOrBuilder> getStreamOutputsOrBuilderList() {
            return this.streamOutputs_;
        }

        public LivekitModels.WebhookConfig getWebhooks(int i) {
            return (LivekitModels.WebhookConfig) this.webhooks_.get(i);
        }

        public int getWebhooksCount() {
            return this.webhooks_.size();
        }

        public List<LivekitModels.WebhookConfig> getWebhooksList() {
            return this.webhooks_;
        }

        public LivekitModels.WebhookConfigOrBuilder getWebhooksOrBuilder(int i) {
            return (LivekitModels.WebhookConfigOrBuilder) this.webhooks_.get(i);
        }

        public List<? extends LivekitModels.WebhookConfigOrBuilder> getWebhooksOrBuilderList() {
            return this.webhooks_;
        }

        public boolean hasAdvanced() {
            return this.optionsCase_ == 5;
        }

        public boolean hasPreset() {
            return this.optionsCase_ == 4;
        }

        public static Builder newBuilder(ParticipantEgressRequest participantEgressRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(participantEgressRequest);
        }

        public static ParticipantEgressRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ParticipantEgressRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ParticipantEgressRequest parseFrom(ByteString byteString) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addFileOutputs(int i, EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.add(i, encodedFileOutput);
        }

        private void addImageOutputs(int i, ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.add(i, imageOutput);
        }

        private void addSegmentOutputs(int i, SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.add(i, segmentedFileOutput);
        }

        private void addStreamOutputs(int i, StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.add(i, streamOutput);
        }

        private void addWebhooks(int i, LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.add(i, webhookConfig);
        }

        public static ParticipantEgressRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ParticipantEgressRequest parseFrom(byte[] bArr) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ParticipantEgressRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ParticipantEgressRequest parseFrom(InputStream inputStream) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ParticipantEgressRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ParticipantEgressRequest parseFrom(CodedInputStream codedInputStream) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ParticipantEgressRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ParticipantEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ParticipantEgressRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ProxyConfig extends GeneratedMessageLite<ProxyConfig, Builder> implements ProxyConfigOrBuilder {
        private static final ProxyConfig DEFAULT_INSTANCE;
        private static volatile Parser<ProxyConfig> PARSER = null;
        public static final int PASSWORD_FIELD_NUMBER = 3;
        public static final int URL_FIELD_NUMBER = 1;
        public static final int USERNAME_FIELD_NUMBER = 2;
        private String password_;
        private String url_;
        private String username_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ProxyConfig, Builder> implements ProxyConfigOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ProxyConfig.DEFAULT_INSTANCE);
            }
        }

        static {
            ProxyConfig proxyConfig = new ProxyConfig();
            DEFAULT_INSTANCE = proxyConfig;
            GeneratedMessageLite.registerDefaultInstance(ProxyConfig.class, proxyConfig);
        }

        private ProxyConfig() {
            String strA = ap.a(1579613077);
            this.url_ = strA;
            this.username_ = strA;
            this.password_ = strA;
        }

        private void clearPassword() {
            this.password_ = getDefaultInstance().getPassword();
        }

        private void clearUrl() {
            this.url_ = getDefaultInstance().getUrl();
        }

        private void clearUsername() {
            this.username_ = getDefaultInstance().getUsername();
        }

        public static ProxyConfig getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ProxyConfig parseDelimitedFrom(InputStream inputStream) {
            return (ProxyConfig) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ProxyConfig parseFrom(ByteBuffer byteBuffer) {
            return (ProxyConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ProxyConfig> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setPassword(String str) {
            str.getClass();
            this.password_ = str;
        }

        private void setPasswordBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.password_ = byteString.L();
        }

        private void setUrl(String str) {
            str.getClass();
            this.url_ = str;
        }

        private void setUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.url_ = byteString.L();
        }

        private void setUsername(String str) {
            str.getClass();
            this.username_ = str;
        }

        private void setUsernameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.username_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ProxyConfig();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ", new Object[]{"url_", "username_", "password_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ProxyConfig> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ProxyConfig.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getPassword() {
            return this.password_;
        }

        public ByteString getPasswordBytes() {
            return ByteString.n(this.password_);
        }

        public String getUrl() {
            return this.url_;
        }

        public ByteString getUrlBytes() {
            return ByteString.n(this.url_);
        }

        public String getUsername() {
            return this.username_;
        }

        public ByteString getUsernameBytes() {
            return ByteString.n(this.username_);
        }

        public static Builder newBuilder(ProxyConfig proxyConfig) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(proxyConfig);
        }

        public static ProxyConfig parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ProxyConfig) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ProxyConfig parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ProxyConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ProxyConfig parseFrom(ByteString byteString) {
            return (ProxyConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ProxyConfig parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ProxyConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ProxyConfig parseFrom(byte[] bArr) {
            return (ProxyConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ProxyConfig parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ProxyConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ProxyConfig parseFrom(InputStream inputStream) {
            return (ProxyConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ProxyConfig parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ProxyConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ProxyConfig parseFrom(CodedInputStream codedInputStream) {
            return (ProxyConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ProxyConfig parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ProxyConfig) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ProxyConfigOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RoomCompositeEgressRequest extends GeneratedMessageLite<RoomCompositeEgressRequest, Builder> implements RoomCompositeEgressRequestOrBuilder {
        public static final int ADVANCED_FIELD_NUMBER = 9;
        public static final int AUDIO_MIXING_FIELD_NUMBER = 15;
        public static final int AUDIO_ONLY_FIELD_NUMBER = 3;
        public static final int CUSTOM_BASE_URL_FIELD_NUMBER = 5;
        private static final RoomCompositeEgressRequest DEFAULT_INSTANCE;
        public static final int FILE_FIELD_NUMBER = 6;
        public static final int FILE_OUTPUTS_FIELD_NUMBER = 11;
        public static final int IMAGE_OUTPUTS_FIELD_NUMBER = 14;
        public static final int LAYOUT_FIELD_NUMBER = 2;
        private static volatile Parser<RoomCompositeEgressRequest> PARSER = null;
        public static final int PRESET_FIELD_NUMBER = 8;
        public static final int ROOM_NAME_FIELD_NUMBER = 1;
        public static final int SEGMENTS_FIELD_NUMBER = 10;
        public static final int SEGMENT_OUTPUTS_FIELD_NUMBER = 13;
        public static final int STREAM_FIELD_NUMBER = 7;
        public static final int STREAM_OUTPUTS_FIELD_NUMBER = 12;
        public static final int VIDEO_ONLY_FIELD_NUMBER = 4;
        public static final int WEBHOOKS_FIELD_NUMBER = 16;
        private int audioMixing_;
        private boolean audioOnly_;
        private String customBaseUrl_;
        private Internal.ProtobufList<EncodedFileOutput> fileOutputs_;
        private Internal.ProtobufList<ImageOutput> imageOutputs_;
        private String layout_;
        private Object options_;
        private Object output_;
        private String roomName_;
        private Internal.ProtobufList<SegmentedFileOutput> segmentOutputs_;
        private Internal.ProtobufList<StreamOutput> streamOutputs_;
        private boolean videoOnly_;
        private Internal.ProtobufList<LivekitModels.WebhookConfig> webhooks_;
        private int outputCase_ = 0;
        private int optionsCase_ = 0;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RoomCompositeEgressRequest, Builder> implements RoomCompositeEgressRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RoomCompositeEgressRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OptionsCase {
            b(8),
            c(9),
            d(0);

            private final int a;

            OptionsCase(int i) {
                this.a = i;
            }

            public static OptionsCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 8) {
                    return b;
                }
                if (i != 9) {
                    return null;
                }
                return c;
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OutputCase {
            b(6),
            c(7),
            d(10),
            e(0);

            private final int a;

            OutputCase(int i) {
                this.a = i;
            }

            public static OutputCase b(int i) {
                if (i == 0) {
                    return e;
                }
                if (i == 10) {
                    return d;
                }
                if (i == 6) {
                    return b;
                }
                if (i != 7) {
                    return null;
                }
                return c;
            }
        }

        static {
            RoomCompositeEgressRequest roomCompositeEgressRequest = new RoomCompositeEgressRequest();
            DEFAULT_INSTANCE = roomCompositeEgressRequest;
            GeneratedMessageLite.registerDefaultInstance(RoomCompositeEgressRequest.class, roomCompositeEgressRequest);
        }

        private RoomCompositeEgressRequest() {
            String strA = ap.a(1301719943);
            this.roomName_ = strA;
            this.layout_ = strA;
            this.customBaseUrl_ = strA;
            this.fileOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.streamOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.segmentOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.imageOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.webhooks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllFileOutputs(Iterable<? extends EncodedFileOutput> iterable) {
            ensureFileOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.fileOutputs_);
        }

        private void addAllImageOutputs(Iterable<? extends ImageOutput> iterable) {
            ensureImageOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.imageOutputs_);
        }

        private void addAllSegmentOutputs(Iterable<? extends SegmentedFileOutput> iterable) {
            ensureSegmentOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.segmentOutputs_);
        }

        private void addAllStreamOutputs(Iterable<? extends StreamOutput> iterable) {
            ensureStreamOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.streamOutputs_);
        }

        private void addAllWebhooks(Iterable<? extends LivekitModels.WebhookConfig> iterable) {
            ensureWebhooksIsMutable();
            AbstractMessageLite.addAll(iterable, this.webhooks_);
        }

        private void addFileOutputs(EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.add(encodedFileOutput);
        }

        private void addImageOutputs(ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.add(imageOutput);
        }

        private void addSegmentOutputs(SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.add(segmentedFileOutput);
        }

        private void addStreamOutputs(StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.add(streamOutput);
        }

        private void addWebhooks(LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.add(webhookConfig);
        }

        private void clearAdvanced() {
            if (this.optionsCase_ == 9) {
                this.optionsCase_ = 0;
                this.options_ = null;
            }
        }

        private void clearAudioMixing() {
            this.audioMixing_ = 0;
        }

        private void clearAudioOnly() {
            this.audioOnly_ = false;
        }

        private void clearCustomBaseUrl() {
            this.customBaseUrl_ = getDefaultInstance().getCustomBaseUrl();
        }

        private void clearFile() {
            if (this.outputCase_ == 6) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearFileOutputs() {
            this.fileOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearImageOutputs() {
            this.imageOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearLayout() {
            this.layout_ = getDefaultInstance().getLayout();
        }

        private void clearOptions() {
            this.optionsCase_ = 0;
            this.options_ = null;
        }

        private void clearOutput() {
            this.outputCase_ = 0;
            this.output_ = null;
        }

        private void clearPreset() {
            if (this.optionsCase_ == 8) {
                this.optionsCase_ = 0;
                this.options_ = null;
            }
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearSegmentOutputs() {
            this.segmentOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSegments() {
            if (this.outputCase_ == 10) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearStream() {
            if (this.outputCase_ == 7) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearStreamOutputs() {
            this.streamOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearVideoOnly() {
            this.videoOnly_ = false;
        }

        private void clearWebhooks() {
            this.webhooks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureFileOutputsIsMutable() {
            Internal.ProtobufList<EncodedFileOutput> protobufList = this.fileOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.fileOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureImageOutputsIsMutable() {
            Internal.ProtobufList<ImageOutput> protobufList = this.imageOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.imageOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSegmentOutputsIsMutable() {
            Internal.ProtobufList<SegmentedFileOutput> protobufList = this.segmentOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.segmentOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureStreamOutputsIsMutable() {
            Internal.ProtobufList<StreamOutput> protobufList = this.streamOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.streamOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureWebhooksIsMutable() {
            Internal.ProtobufList<LivekitModels.WebhookConfig> protobufList = this.webhooks_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.webhooks_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static RoomCompositeEgressRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAdvanced(EncodingOptions encodingOptions) {
            encodingOptions.getClass();
            if (this.optionsCase_ != 9 || this.options_ == EncodingOptions.getDefaultInstance()) {
                this.options_ = encodingOptions;
            } else {
                this.options_ = ((EncodingOptions.Builder) EncodingOptions.newBuilder((EncodingOptions) this.options_).v(encodingOptions)).o();
            }
            this.optionsCase_ = 9;
        }

        private void mergeFile(EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            if (this.outputCase_ != 6 || this.output_ == EncodedFileOutput.getDefaultInstance()) {
                this.output_ = encodedFileOutput;
            } else {
                this.output_ = ((EncodedFileOutput.Builder) EncodedFileOutput.newBuilder((EncodedFileOutput) this.output_).v(encodedFileOutput)).o();
            }
            this.outputCase_ = 6;
        }

        private void mergeSegments(SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            if (this.outputCase_ != 10 || this.output_ == SegmentedFileOutput.getDefaultInstance()) {
                this.output_ = segmentedFileOutput;
            } else {
                this.output_ = ((SegmentedFileOutput.Builder) SegmentedFileOutput.newBuilder((SegmentedFileOutput) this.output_).v(segmentedFileOutput)).o();
            }
            this.outputCase_ = 10;
        }

        private void mergeStream(StreamOutput streamOutput) {
            streamOutput.getClass();
            if (this.outputCase_ != 7 || this.output_ == StreamOutput.getDefaultInstance()) {
                this.output_ = streamOutput;
            } else {
                this.output_ = ((StreamOutput.Builder) StreamOutput.newBuilder((StreamOutput) this.output_).v(streamOutput)).o();
            }
            this.outputCase_ = 7;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RoomCompositeEgressRequest parseDelimitedFrom(InputStream inputStream) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomCompositeEgressRequest parseFrom(ByteBuffer byteBuffer) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RoomCompositeEgressRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeFileOutputs(int i) {
            ensureFileOutputsIsMutable();
            this.fileOutputs_.remove(i);
        }

        private void removeImageOutputs(int i) {
            ensureImageOutputsIsMutable();
            this.imageOutputs_.remove(i);
        }

        private void removeSegmentOutputs(int i) {
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.remove(i);
        }

        private void removeStreamOutputs(int i) {
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.remove(i);
        }

        private void removeWebhooks(int i) {
            ensureWebhooksIsMutable();
            this.webhooks_.remove(i);
        }

        private void setAdvanced(EncodingOptions encodingOptions) {
            encodingOptions.getClass();
            this.options_ = encodingOptions;
            this.optionsCase_ = 9;
        }

        private void setAudioMixing(AudioMixing audioMixing) {
            this.audioMixing_ = audioMixing.getNumber();
        }

        private void setAudioMixingValue(int i) {
            this.audioMixing_ = i;
        }

        private void setAudioOnly(boolean z) {
            this.audioOnly_ = z;
        }

        private void setCustomBaseUrl(String str) {
            str.getClass();
            this.customBaseUrl_ = str;
        }

        private void setCustomBaseUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.customBaseUrl_ = byteString.L();
        }

        private void setFile(EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            this.output_ = encodedFileOutput;
            this.outputCase_ = 6;
        }

        private void setFileOutputs(int i, EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.set(i, encodedFileOutput);
        }

        private void setImageOutputs(int i, ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.set(i, imageOutput);
        }

        private void setLayout(String str) {
            str.getClass();
            this.layout_ = str;
        }

        private void setLayoutBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.layout_ = byteString.L();
        }

        private void setPreset(EncodingOptionsPreset encodingOptionsPreset) {
            this.options_ = Integer.valueOf(encodingOptionsPreset.getNumber());
            this.optionsCase_ = 8;
        }

        private void setPresetValue(int i) {
            this.optionsCase_ = 8;
            this.options_ = Integer.valueOf(i);
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setSegmentOutputs(int i, SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.set(i, segmentedFileOutput);
        }

        private void setSegments(SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            this.output_ = segmentedFileOutput;
            this.outputCase_ = 10;
        }

        private void setStream(StreamOutput streamOutput) {
            streamOutput.getClass();
            this.output_ = streamOutput;
            this.outputCase_ = 7;
        }

        private void setStreamOutputs(int i, StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.set(i, streamOutput);
        }

        private void setVideoOnly(boolean z) {
            this.videoOnly_ = z;
        }

        private void setWebhooks(int i, LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.set(i, webhookConfig);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new RoomCompositeEgressRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0010\u0002\u0000\u0001\u0010\u0010\u0000\u0005\u0000\u0001Ȉ\u0002Ȉ\u0003\u0007\u0004\u0007\u0005Ȉ\u0006<\u0000\u0007<\u0000\b?\u0001\t<\u0001\n<\u0000\u000b\u001b\f\u001b\r\u001b\u000e\u001b\u000f\f\u0010\u001b", new Object[]{"output_", "outputCase_", "options_", "optionsCase_", "roomName_", "layout_", "audioOnly_", "videoOnly_", "customBaseUrl_", EncodedFileOutput.class, StreamOutput.class, EncodingOptions.class, SegmentedFileOutput.class, "fileOutputs_", EncodedFileOutput.class, "streamOutputs_", StreamOutput.class, "segmentOutputs_", SegmentedFileOutput.class, "imageOutputs_", ImageOutput.class, "audioMixing_", "webhooks_", LivekitModels.WebhookConfig.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RoomCompositeEgressRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RoomCompositeEgressRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public EncodingOptions getAdvanced() {
            return this.optionsCase_ == 9 ? (EncodingOptions) this.options_ : EncodingOptions.getDefaultInstance();
        }

        public AudioMixing getAudioMixing() {
            AudioMixing audioMixingB = AudioMixing.b(this.audioMixing_);
            return audioMixingB == null ? AudioMixing.e : audioMixingB;
        }

        public int getAudioMixingValue() {
            return this.audioMixing_;
        }

        public boolean getAudioOnly() {
            return this.audioOnly_;
        }

        public String getCustomBaseUrl() {
            return this.customBaseUrl_;
        }

        public ByteString getCustomBaseUrlBytes() {
            return ByteString.n(this.customBaseUrl_);
        }

        @Deprecated
        public EncodedFileOutput getFile() {
            return this.outputCase_ == 6 ? (EncodedFileOutput) this.output_ : EncodedFileOutput.getDefaultInstance();
        }

        public EncodedFileOutput getFileOutputs(int i) {
            return (EncodedFileOutput) this.fileOutputs_.get(i);
        }

        public int getFileOutputsCount() {
            return this.fileOutputs_.size();
        }

        public List<EncodedFileOutput> getFileOutputsList() {
            return this.fileOutputs_;
        }

        public EncodedFileOutputOrBuilder getFileOutputsOrBuilder(int i) {
            return (EncodedFileOutputOrBuilder) this.fileOutputs_.get(i);
        }

        public List<? extends EncodedFileOutputOrBuilder> getFileOutputsOrBuilderList() {
            return this.fileOutputs_;
        }

        public ImageOutput getImageOutputs(int i) {
            return (ImageOutput) this.imageOutputs_.get(i);
        }

        public int getImageOutputsCount() {
            return this.imageOutputs_.size();
        }

        public List<ImageOutput> getImageOutputsList() {
            return this.imageOutputs_;
        }

        public ImageOutputOrBuilder getImageOutputsOrBuilder(int i) {
            return (ImageOutputOrBuilder) this.imageOutputs_.get(i);
        }

        public List<? extends ImageOutputOrBuilder> getImageOutputsOrBuilderList() {
            return this.imageOutputs_;
        }

        public String getLayout() {
            return this.layout_;
        }

        public ByteString getLayoutBytes() {
            return ByteString.n(this.layout_);
        }

        public OptionsCase getOptionsCase() {
            return OptionsCase.b(this.optionsCase_);
        }

        public OutputCase getOutputCase() {
            return OutputCase.b(this.outputCase_);
        }

        public EncodingOptionsPreset getPreset() {
            if (this.optionsCase_ != 8) {
                return EncodingOptionsPreset.b;
            }
            EncodingOptionsPreset encodingOptionsPresetB = EncodingOptionsPreset.b(((Integer) this.options_).intValue());
            return encodingOptionsPresetB == null ? EncodingOptionsPreset.j : encodingOptionsPresetB;
        }

        public int getPresetValue() {
            if (this.optionsCase_ == 8) {
                return ((Integer) this.options_).intValue();
            }
            return 0;
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public SegmentedFileOutput getSegmentOutputs(int i) {
            return (SegmentedFileOutput) this.segmentOutputs_.get(i);
        }

        public int getSegmentOutputsCount() {
            return this.segmentOutputs_.size();
        }

        public List<SegmentedFileOutput> getSegmentOutputsList() {
            return this.segmentOutputs_;
        }

        public SegmentedFileOutputOrBuilder getSegmentOutputsOrBuilder(int i) {
            return (SegmentedFileOutputOrBuilder) this.segmentOutputs_.get(i);
        }

        public List<? extends SegmentedFileOutputOrBuilder> getSegmentOutputsOrBuilderList() {
            return this.segmentOutputs_;
        }

        @Deprecated
        public SegmentedFileOutput getSegments() {
            return this.outputCase_ == 10 ? (SegmentedFileOutput) this.output_ : SegmentedFileOutput.getDefaultInstance();
        }

        @Deprecated
        public StreamOutput getStream() {
            return this.outputCase_ == 7 ? (StreamOutput) this.output_ : StreamOutput.getDefaultInstance();
        }

        public StreamOutput getStreamOutputs(int i) {
            return (StreamOutput) this.streamOutputs_.get(i);
        }

        public int getStreamOutputsCount() {
            return this.streamOutputs_.size();
        }

        public List<StreamOutput> getStreamOutputsList() {
            return this.streamOutputs_;
        }

        public StreamOutputOrBuilder getStreamOutputsOrBuilder(int i) {
            return (StreamOutputOrBuilder) this.streamOutputs_.get(i);
        }

        public List<? extends StreamOutputOrBuilder> getStreamOutputsOrBuilderList() {
            return this.streamOutputs_;
        }

        public boolean getVideoOnly() {
            return this.videoOnly_;
        }

        public LivekitModels.WebhookConfig getWebhooks(int i) {
            return (LivekitModels.WebhookConfig) this.webhooks_.get(i);
        }

        public int getWebhooksCount() {
            return this.webhooks_.size();
        }

        public List<LivekitModels.WebhookConfig> getWebhooksList() {
            return this.webhooks_;
        }

        public LivekitModels.WebhookConfigOrBuilder getWebhooksOrBuilder(int i) {
            return (LivekitModels.WebhookConfigOrBuilder) this.webhooks_.get(i);
        }

        public List<? extends LivekitModels.WebhookConfigOrBuilder> getWebhooksOrBuilderList() {
            return this.webhooks_;
        }

        public boolean hasAdvanced() {
            return this.optionsCase_ == 9;
        }

        @Deprecated
        public boolean hasFile() {
            return this.outputCase_ == 6;
        }

        public boolean hasPreset() {
            return this.optionsCase_ == 8;
        }

        @Deprecated
        public boolean hasSegments() {
            return this.outputCase_ == 10;
        }

        @Deprecated
        public boolean hasStream() {
            return this.outputCase_ == 7;
        }

        public static Builder newBuilder(RoomCompositeEgressRequest roomCompositeEgressRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(roomCompositeEgressRequest);
        }

        public static RoomCompositeEgressRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomCompositeEgressRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RoomCompositeEgressRequest parseFrom(ByteString byteString) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addFileOutputs(int i, EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.add(i, encodedFileOutput);
        }

        private void addImageOutputs(int i, ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.add(i, imageOutput);
        }

        private void addSegmentOutputs(int i, SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.add(i, segmentedFileOutput);
        }

        private void addStreamOutputs(int i, StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.add(i, streamOutput);
        }

        private void addWebhooks(int i, LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.add(i, webhookConfig);
        }

        public static RoomCompositeEgressRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RoomCompositeEgressRequest parseFrom(byte[] bArr) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RoomCompositeEgressRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RoomCompositeEgressRequest parseFrom(InputStream inputStream) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RoomCompositeEgressRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RoomCompositeEgressRequest parseFrom(CodedInputStream codedInputStream) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RoomCompositeEgressRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RoomCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RoomCompositeEgressRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class S3Upload extends GeneratedMessageLite<S3Upload, Builder> implements S3UploadOrBuilder {
        public static final int ACCESS_KEY_FIELD_NUMBER = 1;
        public static final int ASSUME_ROLE_ARN_FIELD_NUMBER = 12;
        public static final int ASSUME_ROLE_EXTERNAL_ID_FIELD_NUMBER = 13;
        public static final int BUCKET_FIELD_NUMBER = 5;
        public static final int CONTENT_DISPOSITION_FIELD_NUMBER = 9;
        private static final S3Upload DEFAULT_INSTANCE;
        public static final int ENDPOINT_FIELD_NUMBER = 4;
        public static final int FORCE_PATH_STYLE_FIELD_NUMBER = 6;
        public static final int METADATA_FIELD_NUMBER = 7;
        private static volatile Parser<S3Upload> PARSER = null;
        public static final int PROXY_FIELD_NUMBER = 10;
        public static final int REGION_FIELD_NUMBER = 3;
        public static final int SECRET_FIELD_NUMBER = 2;
        public static final int SESSION_TOKEN_FIELD_NUMBER = 11;
        public static final int TAGGING_FIELD_NUMBER = 8;
        private String accessKey_;
        private String assumeRoleArn_;
        private String assumeRoleExternalId_;
        private String bucket_;
        private String contentDisposition_;
        private String endpoint_;
        private boolean forcePathStyle_;
        private MapFieldLite<String, String> metadata_ = MapFieldLite.f();
        private ProxyConfig proxy_;
        private String region_;
        private String secret_;
        private String sessionToken_;
        private String tagging_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<S3Upload, Builder> implements S3UploadOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(S3Upload.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class MetadataDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(215694125);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private MetadataDefaultEntryHolder() {
            }
        }

        static {
            S3Upload s3Upload = new S3Upload();
            DEFAULT_INSTANCE = s3Upload;
            GeneratedMessageLite.registerDefaultInstance(S3Upload.class, s3Upload);
        }

        private S3Upload() {
            String strA = ap.a(688871300);
            this.accessKey_ = strA;
            this.secret_ = strA;
            this.sessionToken_ = strA;
            this.assumeRoleArn_ = strA;
            this.assumeRoleExternalId_ = strA;
            this.region_ = strA;
            this.endpoint_ = strA;
            this.bucket_ = strA;
            this.tagging_ = strA;
            this.contentDisposition_ = strA;
        }

        private void clearAccessKey() {
            this.accessKey_ = getDefaultInstance().getAccessKey();
        }

        private void clearAssumeRoleArn() {
            this.assumeRoleArn_ = getDefaultInstance().getAssumeRoleArn();
        }

        private void clearAssumeRoleExternalId() {
            this.assumeRoleExternalId_ = getDefaultInstance().getAssumeRoleExternalId();
        }

        private void clearBucket() {
            this.bucket_ = getDefaultInstance().getBucket();
        }

        private void clearContentDisposition() {
            this.contentDisposition_ = getDefaultInstance().getContentDisposition();
        }

        private void clearEndpoint() {
            this.endpoint_ = getDefaultInstance().getEndpoint();
        }

        private void clearForcePathStyle() {
            this.forcePathStyle_ = false;
        }

        private void clearProxy() {
            this.proxy_ = null;
        }

        private void clearRegion() {
            this.region_ = getDefaultInstance().getRegion();
        }

        private void clearSecret() {
            this.secret_ = getDefaultInstance().getSecret();
        }

        private void clearSessionToken() {
            this.sessionToken_ = getDefaultInstance().getSessionToken();
        }

        private void clearTagging() {
            this.tagging_ = getDefaultInstance().getTagging();
        }

        public static S3Upload getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableMetadataMap() {
            return internalGetMutableMetadata();
        }

        private MapFieldLite<String, String> internalGetMetadata() {
            return this.metadata_;
        }

        private MapFieldLite<String, String> internalGetMutableMetadata() {
            if (!this.metadata_.k()) {
                this.metadata_ = this.metadata_.n();
            }
            return this.metadata_;
        }

        private void mergeProxy(ProxyConfig proxyConfig) {
            proxyConfig.getClass();
            ProxyConfig proxyConfig2 = this.proxy_;
            if (proxyConfig2 == null || proxyConfig2 == ProxyConfig.getDefaultInstance()) {
                this.proxy_ = proxyConfig;
            } else {
                this.proxy_ = (ProxyConfig) ((ProxyConfig.Builder) ProxyConfig.newBuilder(this.proxy_).v(proxyConfig)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static S3Upload parseDelimitedFrom(InputStream inputStream) {
            return (S3Upload) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static S3Upload parseFrom(ByteBuffer byteBuffer) {
            return (S3Upload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<S3Upload> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAccessKey(String str) {
            str.getClass();
            this.accessKey_ = str;
        }

        private void setAccessKeyBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.accessKey_ = byteString.L();
        }

        private void setAssumeRoleArn(String str) {
            str.getClass();
            this.assumeRoleArn_ = str;
        }

        private void setAssumeRoleArnBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.assumeRoleArn_ = byteString.L();
        }

        private void setAssumeRoleExternalId(String str) {
            str.getClass();
            this.assumeRoleExternalId_ = str;
        }

        private void setAssumeRoleExternalIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.assumeRoleExternalId_ = byteString.L();
        }

        private void setBucket(String str) {
            str.getClass();
            this.bucket_ = str;
        }

        private void setBucketBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.bucket_ = byteString.L();
        }

        private void setContentDisposition(String str) {
            str.getClass();
            this.contentDisposition_ = str;
        }

        private void setContentDispositionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.contentDisposition_ = byteString.L();
        }

        private void setEndpoint(String str) {
            str.getClass();
            this.endpoint_ = str;
        }

        private void setEndpointBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.endpoint_ = byteString.L();
        }

        private void setForcePathStyle(boolean z) {
            this.forcePathStyle_ = z;
        }

        private void setProxy(ProxyConfig proxyConfig) {
            proxyConfig.getClass();
            this.proxy_ = proxyConfig;
        }

        private void setRegion(String str) {
            str.getClass();
            this.region_ = str;
        }

        private void setRegionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.region_ = byteString.L();
        }

        private void setSecret(String str) {
            str.getClass();
            this.secret_ = str;
        }

        private void setSecretBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.secret_ = byteString.L();
        }

        private void setSessionToken(String str) {
            str.getClass();
            this.sessionToken_ = str;
        }

        private void setSessionTokenBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.sessionToken_ = byteString.L();
        }

        private void setTagging(String str) {
            str.getClass();
            this.tagging_ = str;
        }

        private void setTaggingBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.tagging_ = byteString.L();
        }

        public boolean containsMetadata(String str) {
            str.getClass();
            return internalGetMetadata().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new S3Upload();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\r\u0000\u0000\u0001\r\r\u0001\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005Ȉ\u0006\u0007\u00072\bȈ\tȈ\n\t\u000bȈ\fȈ\rȈ", new Object[]{"accessKey_", "secret_", "region_", "endpoint_", "bucket_", "forcePathStyle_", "metadata_", MetadataDefaultEntryHolder.a, "tagging_", "contentDisposition_", "proxy_", "sessionToken_", "assumeRoleArn_", "assumeRoleExternalId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<S3Upload> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (S3Upload.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAccessKey() {
            return this.accessKey_;
        }

        public ByteString getAccessKeyBytes() {
            return ByteString.n(this.accessKey_);
        }

        public String getAssumeRoleArn() {
            return this.assumeRoleArn_;
        }

        public ByteString getAssumeRoleArnBytes() {
            return ByteString.n(this.assumeRoleArn_);
        }

        public String getAssumeRoleExternalId() {
            return this.assumeRoleExternalId_;
        }

        public ByteString getAssumeRoleExternalIdBytes() {
            return ByteString.n(this.assumeRoleExternalId_);
        }

        public String getBucket() {
            return this.bucket_;
        }

        public ByteString getBucketBytes() {
            return ByteString.n(this.bucket_);
        }

        public String getContentDisposition() {
            return this.contentDisposition_;
        }

        public ByteString getContentDispositionBytes() {
            return ByteString.n(this.contentDisposition_);
        }

        public String getEndpoint() {
            return this.endpoint_;
        }

        public ByteString getEndpointBytes() {
            return ByteString.n(this.endpoint_);
        }

        public boolean getForcePathStyle() {
            return this.forcePathStyle_;
        }

        @Deprecated
        public Map<String, String> getMetadata() {
            return getMetadataMap();
        }

        public int getMetadataCount() {
            return internalGetMetadata().size();
        }

        public Map<String, String> getMetadataMap() {
            return Collections.unmodifiableMap(internalGetMetadata());
        }

        public String getMetadataOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetMetadata = internalGetMetadata();
            return mapFieldLiteInternalGetMetadata.containsKey(str) ? (String) mapFieldLiteInternalGetMetadata.get(str) : str2;
        }

        public String getMetadataOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetMetadata = internalGetMetadata();
            if (mapFieldLiteInternalGetMetadata.containsKey(str)) {
                return (String) mapFieldLiteInternalGetMetadata.get(str);
            }
            throw new IllegalArgumentException();
        }

        public ProxyConfig getProxy() {
            ProxyConfig proxyConfig = this.proxy_;
            return proxyConfig == null ? ProxyConfig.getDefaultInstance() : proxyConfig;
        }

        public String getRegion() {
            return this.region_;
        }

        public ByteString getRegionBytes() {
            return ByteString.n(this.region_);
        }

        public String getSecret() {
            return this.secret_;
        }

        public ByteString getSecretBytes() {
            return ByteString.n(this.secret_);
        }

        public String getSessionToken() {
            return this.sessionToken_;
        }

        public ByteString getSessionTokenBytes() {
            return ByteString.n(this.sessionToken_);
        }

        public String getTagging() {
            return this.tagging_;
        }

        public ByteString getTaggingBytes() {
            return ByteString.n(this.tagging_);
        }

        public boolean hasProxy() {
            return this.proxy_ != null;
        }

        public static Builder newBuilder(S3Upload s3Upload) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(s3Upload);
        }

        public static S3Upload parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (S3Upload) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static S3Upload parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (S3Upload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static S3Upload parseFrom(ByteString byteString) {
            return (S3Upload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static S3Upload parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (S3Upload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static S3Upload parseFrom(byte[] bArr) {
            return (S3Upload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static S3Upload parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (S3Upload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static S3Upload parseFrom(InputStream inputStream) {
            return (S3Upload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static S3Upload parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (S3Upload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static S3Upload parseFrom(CodedInputStream codedInputStream) {
            return (S3Upload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static S3Upload parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (S3Upload) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface S3UploadOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SegmentedFileOutput extends GeneratedMessageLite<SegmentedFileOutput, Builder> implements SegmentedFileOutputOrBuilder {
        public static final int ALIOSS_FIELD_NUMBER = 9;
        public static final int AZURE_FIELD_NUMBER = 7;
        private static final SegmentedFileOutput DEFAULT_INSTANCE;
        public static final int DISABLE_MANIFEST_FIELD_NUMBER = 8;
        public static final int FILENAME_PREFIX_FIELD_NUMBER = 2;
        public static final int FILENAME_SUFFIX_FIELD_NUMBER = 10;
        public static final int GCP_FIELD_NUMBER = 6;
        public static final int LIVE_PLAYLIST_NAME_FIELD_NUMBER = 11;
        private static volatile Parser<SegmentedFileOutput> PARSER = null;
        public static final int PLAYLIST_NAME_FIELD_NUMBER = 3;
        public static final int PROTOCOL_FIELD_NUMBER = 1;
        public static final int S3_FIELD_NUMBER = 5;
        public static final int SEGMENT_DURATION_FIELD_NUMBER = 4;
        private boolean disableManifest_;
        private String filenamePrefix_;
        private int filenameSuffix_;
        private String livePlaylistName_;
        private int outputCase_ = 0;
        private Object output_;
        private String playlistName_;
        private int protocol_;
        private int segmentDuration_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SegmentedFileOutput, Builder> implements SegmentedFileOutputOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SegmentedFileOutput.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OutputCase {
            b(5),
            c(6),
            d(7),
            e(9),
            f(0);

            private final int a;

            OutputCase(int i) {
                this.a = i;
            }

            public static OutputCase b(int i) {
                if (i == 0) {
                    return f;
                }
                if (i == 9) {
                    return e;
                }
                if (i == 5) {
                    return b;
                }
                if (i == 6) {
                    return c;
                }
                if (i != 7) {
                    return null;
                }
                return d;
            }
        }

        static {
            SegmentedFileOutput segmentedFileOutput = new SegmentedFileOutput();
            DEFAULT_INSTANCE = segmentedFileOutput;
            GeneratedMessageLite.registerDefaultInstance(SegmentedFileOutput.class, segmentedFileOutput);
        }

        private SegmentedFileOutput() {
            String strA = ap.a(667010174);
            this.filenamePrefix_ = strA;
            this.playlistName_ = strA;
            this.livePlaylistName_ = strA;
        }

        private void clearAliOSS() {
            if (this.outputCase_ == 9) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearAzure() {
            if (this.outputCase_ == 7) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearDisableManifest() {
            this.disableManifest_ = false;
        }

        private void clearFilenamePrefix() {
            this.filenamePrefix_ = getDefaultInstance().getFilenamePrefix();
        }

        private void clearFilenameSuffix() {
            this.filenameSuffix_ = 0;
        }

        private void clearGcp() {
            if (this.outputCase_ == 6) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearLivePlaylistName() {
            this.livePlaylistName_ = getDefaultInstance().getLivePlaylistName();
        }

        private void clearOutput() {
            this.outputCase_ = 0;
            this.output_ = null;
        }

        private void clearPlaylistName() {
            this.playlistName_ = getDefaultInstance().getPlaylistName();
        }

        private void clearProtocol() {
            this.protocol_ = 0;
        }

        private void clearS3() {
            if (this.outputCase_ == 5) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearSegmentDuration() {
            this.segmentDuration_ = 0;
        }

        public static SegmentedFileOutput getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAliOSS(AliOSSUpload aliOSSUpload) {
            aliOSSUpload.getClass();
            if (this.outputCase_ != 9 || this.output_ == AliOSSUpload.getDefaultInstance()) {
                this.output_ = aliOSSUpload;
            } else {
                this.output_ = ((AliOSSUpload.Builder) AliOSSUpload.newBuilder((AliOSSUpload) this.output_).v(aliOSSUpload)).o();
            }
            this.outputCase_ = 9;
        }

        private void mergeAzure(AzureBlobUpload azureBlobUpload) {
            azureBlobUpload.getClass();
            if (this.outputCase_ != 7 || this.output_ == AzureBlobUpload.getDefaultInstance()) {
                this.output_ = azureBlobUpload;
            } else {
                this.output_ = ((AzureBlobUpload.Builder) AzureBlobUpload.newBuilder((AzureBlobUpload) this.output_).v(azureBlobUpload)).o();
            }
            this.outputCase_ = 7;
        }

        private void mergeGcp(GCPUpload gCPUpload) {
            gCPUpload.getClass();
            if (this.outputCase_ != 6 || this.output_ == GCPUpload.getDefaultInstance()) {
                this.output_ = gCPUpload;
            } else {
                this.output_ = ((GCPUpload.Builder) GCPUpload.newBuilder((GCPUpload) this.output_).v(gCPUpload)).o();
            }
            this.outputCase_ = 6;
        }

        private void mergeS3(S3Upload s3Upload) {
            s3Upload.getClass();
            if (this.outputCase_ != 5 || this.output_ == S3Upload.getDefaultInstance()) {
                this.output_ = s3Upload;
            } else {
                this.output_ = ((S3Upload.Builder) S3Upload.newBuilder((S3Upload) this.output_).v(s3Upload)).o();
            }
            this.outputCase_ = 5;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SegmentedFileOutput parseDelimitedFrom(InputStream inputStream) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SegmentedFileOutput parseFrom(ByteBuffer byteBuffer) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SegmentedFileOutput> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAliOSS(AliOSSUpload aliOSSUpload) {
            aliOSSUpload.getClass();
            this.output_ = aliOSSUpload;
            this.outputCase_ = 9;
        }

        private void setAzure(AzureBlobUpload azureBlobUpload) {
            azureBlobUpload.getClass();
            this.output_ = azureBlobUpload;
            this.outputCase_ = 7;
        }

        private void setDisableManifest(boolean z) {
            this.disableManifest_ = z;
        }

        private void setFilenamePrefix(String str) {
            str.getClass();
            this.filenamePrefix_ = str;
        }

        private void setFilenamePrefixBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.filenamePrefix_ = byteString.L();
        }

        private void setFilenameSuffix(SegmentedFileSuffix segmentedFileSuffix) {
            this.filenameSuffix_ = segmentedFileSuffix.getNumber();
        }

        private void setFilenameSuffixValue(int i) {
            this.filenameSuffix_ = i;
        }

        private void setGcp(GCPUpload gCPUpload) {
            gCPUpload.getClass();
            this.output_ = gCPUpload;
            this.outputCase_ = 6;
        }

        private void setLivePlaylistName(String str) {
            str.getClass();
            this.livePlaylistName_ = str;
        }

        private void setLivePlaylistNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.livePlaylistName_ = byteString.L();
        }

        private void setPlaylistName(String str) {
            str.getClass();
            this.playlistName_ = str;
        }

        private void setPlaylistNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.playlistName_ = byteString.L();
        }

        private void setProtocol(SegmentedFileProtocol segmentedFileProtocol) {
            this.protocol_ = segmentedFileProtocol.getNumber();
        }

        private void setProtocolValue(int i) {
            this.protocol_ = i;
        }

        private void setS3(S3Upload s3Upload) {
            s3Upload.getClass();
            this.output_ = s3Upload;
            this.outputCase_ = 5;
        }

        private void setSegmentDuration(int i) {
            this.segmentDuration_ = i;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SegmentedFileOutput();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000b\u0001\u0000\u0001\u000b\u000b\u0000\u0000\u0000\u0001\f\u0002Ȉ\u0003Ȉ\u0004\u000b\u0005<\u0000\u0006<\u0000\u0007<\u0000\b\u0007\t<\u0000\n\f\u000bȈ", new Object[]{"output_", "outputCase_", "protocol_", "filenamePrefix_", "playlistName_", "segmentDuration_", S3Upload.class, GCPUpload.class, AzureBlobUpload.class, "disableManifest_", AliOSSUpload.class, "filenameSuffix_", "livePlaylistName_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SegmentedFileOutput> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SegmentedFileOutput.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AliOSSUpload getAliOSS() {
            return this.outputCase_ == 9 ? (AliOSSUpload) this.output_ : AliOSSUpload.getDefaultInstance();
        }

        public AzureBlobUpload getAzure() {
            return this.outputCase_ == 7 ? (AzureBlobUpload) this.output_ : AzureBlobUpload.getDefaultInstance();
        }

        public boolean getDisableManifest() {
            return this.disableManifest_;
        }

        public String getFilenamePrefix() {
            return this.filenamePrefix_;
        }

        public ByteString getFilenamePrefixBytes() {
            return ByteString.n(this.filenamePrefix_);
        }

        public SegmentedFileSuffix getFilenameSuffix() {
            SegmentedFileSuffix segmentedFileSuffixB = SegmentedFileSuffix.b(this.filenameSuffix_);
            return segmentedFileSuffixB == null ? SegmentedFileSuffix.d : segmentedFileSuffixB;
        }

        public int getFilenameSuffixValue() {
            return this.filenameSuffix_;
        }

        public GCPUpload getGcp() {
            return this.outputCase_ == 6 ? (GCPUpload) this.output_ : GCPUpload.getDefaultInstance();
        }

        public String getLivePlaylistName() {
            return this.livePlaylistName_;
        }

        public ByteString getLivePlaylistNameBytes() {
            return ByteString.n(this.livePlaylistName_);
        }

        public OutputCase getOutputCase() {
            return OutputCase.b(this.outputCase_);
        }

        public String getPlaylistName() {
            return this.playlistName_;
        }

        public ByteString getPlaylistNameBytes() {
            return ByteString.n(this.playlistName_);
        }

        public SegmentedFileProtocol getProtocol() {
            SegmentedFileProtocol segmentedFileProtocolB = SegmentedFileProtocol.b(this.protocol_);
            return segmentedFileProtocolB == null ? SegmentedFileProtocol.d : segmentedFileProtocolB;
        }

        public int getProtocolValue() {
            return this.protocol_;
        }

        public S3Upload getS3() {
            return this.outputCase_ == 5 ? (S3Upload) this.output_ : S3Upload.getDefaultInstance();
        }

        public int getSegmentDuration() {
            return this.segmentDuration_;
        }

        public boolean hasAliOSS() {
            return this.outputCase_ == 9;
        }

        public boolean hasAzure() {
            return this.outputCase_ == 7;
        }

        public boolean hasGcp() {
            return this.outputCase_ == 6;
        }

        public boolean hasS3() {
            return this.outputCase_ == 5;
        }

        public static Builder newBuilder(SegmentedFileOutput segmentedFileOutput) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(segmentedFileOutput);
        }

        public static SegmentedFileOutput parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SegmentedFileOutput parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SegmentedFileOutput parseFrom(ByteString byteString) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SegmentedFileOutput parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SegmentedFileOutput parseFrom(byte[] bArr) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SegmentedFileOutput parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SegmentedFileOutput parseFrom(InputStream inputStream) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SegmentedFileOutput parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SegmentedFileOutput parseFrom(CodedInputStream codedInputStream) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SegmentedFileOutput parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentedFileOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SegmentedFileOutputOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SegmentedFileProtocol implements Internal.EnumLite {
        b(0),
        c(1),
        d(-1);

        private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<SegmentedFileProtocol>() { // from class: livekit.LivekitEgress.SegmentedFileProtocol.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SegmentedFileProtocol findValueByNumber(int i) {
                return SegmentedFileProtocol.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SegmentedFileProtocolVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SegmentedFileProtocolVerifier();

            private SegmentedFileProtocolVerifier() {
            }

            public boolean isInRange(int i) {
                return SegmentedFileProtocol.b(i) != null;
            }
        }

        SegmentedFileProtocol(int i) {
            this.a = i;
        }

        public static SegmentedFileProtocol b(int i) {
            if (i == 0) {
                return b;
            }
            if (i != 1) {
                return null;
            }
            return c;
        }

        public final int getNumber() {
            if (this != d) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum SegmentedFileSuffix implements Internal.EnumLite {
        b(0),
        c(1),
        d(-1);

        private static final Internal.EnumLiteMap e = new Internal.EnumLiteMap<SegmentedFileSuffix>() { // from class: livekit.LivekitEgress.SegmentedFileSuffix.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public SegmentedFileSuffix findValueByNumber(int i) {
                return SegmentedFileSuffix.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class SegmentedFileSuffixVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new SegmentedFileSuffixVerifier();

            private SegmentedFileSuffixVerifier() {
            }

            public boolean isInRange(int i) {
                return SegmentedFileSuffix.b(i) != null;
            }
        }

        SegmentedFileSuffix(int i) {
            this.a = i;
        }

        public static SegmentedFileSuffix b(int i) {
            if (i == 0) {
                return b;
            }
            if (i != 1) {
                return null;
            }
            return c;
        }

        public final int getNumber() {
            if (this != d) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SegmentsInfo extends GeneratedMessageLite<SegmentsInfo, Builder> implements SegmentsInfoOrBuilder {
        private static final SegmentsInfo DEFAULT_INSTANCE;
        public static final int DURATION_FIELD_NUMBER = 2;
        public static final int ENDED_AT_FIELD_NUMBER = 7;
        public static final int LIVE_PLAYLIST_LOCATION_FIELD_NUMBER = 9;
        public static final int LIVE_PLAYLIST_NAME_FIELD_NUMBER = 8;
        private static volatile Parser<SegmentsInfo> PARSER = null;
        public static final int PLAYLIST_LOCATION_FIELD_NUMBER = 4;
        public static final int PLAYLIST_NAME_FIELD_NUMBER = 1;
        public static final int SEGMENT_COUNT_FIELD_NUMBER = 5;
        public static final int SIZE_FIELD_NUMBER = 3;
        public static final int STARTED_AT_FIELD_NUMBER = 6;
        private long duration_;
        private long endedAt_;
        private String livePlaylistLocation_;
        private String livePlaylistName_;
        private String playlistLocation_;
        private String playlistName_;
        private long segmentCount_;
        private long size_;
        private long startedAt_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SegmentsInfo, Builder> implements SegmentsInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SegmentsInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            SegmentsInfo segmentsInfo = new SegmentsInfo();
            DEFAULT_INSTANCE = segmentsInfo;
            GeneratedMessageLite.registerDefaultInstance(SegmentsInfo.class, segmentsInfo);
        }

        private SegmentsInfo() {
            String strA = ap.a(1431572052);
            this.playlistName_ = strA;
            this.livePlaylistName_ = strA;
            this.playlistLocation_ = strA;
            this.livePlaylistLocation_ = strA;
        }

        private void clearDuration() {
            this.duration_ = 0L;
        }

        private void clearEndedAt() {
            this.endedAt_ = 0L;
        }

        private void clearLivePlaylistLocation() {
            this.livePlaylistLocation_ = getDefaultInstance().getLivePlaylistLocation();
        }

        private void clearLivePlaylistName() {
            this.livePlaylistName_ = getDefaultInstance().getLivePlaylistName();
        }

        private void clearPlaylistLocation() {
            this.playlistLocation_ = getDefaultInstance().getPlaylistLocation();
        }

        private void clearPlaylistName() {
            this.playlistName_ = getDefaultInstance().getPlaylistName();
        }

        private void clearSegmentCount() {
            this.segmentCount_ = 0L;
        }

        private void clearSize() {
            this.size_ = 0L;
        }

        private void clearStartedAt() {
            this.startedAt_ = 0L;
        }

        public static SegmentsInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SegmentsInfo parseDelimitedFrom(InputStream inputStream) {
            return (SegmentsInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SegmentsInfo parseFrom(ByteBuffer byteBuffer) {
            return (SegmentsInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SegmentsInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDuration(long j) {
            this.duration_ = j;
        }

        private void setEndedAt(long j) {
            this.endedAt_ = j;
        }

        private void setLivePlaylistLocation(String str) {
            str.getClass();
            this.livePlaylistLocation_ = str;
        }

        private void setLivePlaylistLocationBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.livePlaylistLocation_ = byteString.L();
        }

        private void setLivePlaylistName(String str) {
            str.getClass();
            this.livePlaylistName_ = str;
        }

        private void setLivePlaylistNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.livePlaylistName_ = byteString.L();
        }

        private void setPlaylistLocation(String str) {
            str.getClass();
            this.playlistLocation_ = str;
        }

        private void setPlaylistLocationBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.playlistLocation_ = byteString.L();
        }

        private void setPlaylistName(String str) {
            str.getClass();
            this.playlistName_ = str;
        }

        private void setPlaylistNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.playlistName_ = byteString.L();
        }

        private void setSegmentCount(long j) {
            this.segmentCount_ = j;
        }

        private void setSize(long j) {
            this.size_ = j;
        }

        private void setStartedAt(long j) {
            this.startedAt_ = j;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SegmentsInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\t\u0000\u0000\u0001\t\t\u0000\u0000\u0000\u0001Ȉ\u0002\u0002\u0003\u0002\u0004Ȉ\u0005\u0002\u0006\u0002\u0007\u0002\bȈ\tȈ", new Object[]{"playlistName_", "duration_", "size_", "playlistLocation_", "segmentCount_", "startedAt_", "endedAt_", "livePlaylistName_", "livePlaylistLocation_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SegmentsInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SegmentsInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getDuration() {
            return this.duration_;
        }

        public long getEndedAt() {
            return this.endedAt_;
        }

        public String getLivePlaylistLocation() {
            return this.livePlaylistLocation_;
        }

        public ByteString getLivePlaylistLocationBytes() {
            return ByteString.n(this.livePlaylistLocation_);
        }

        public String getLivePlaylistName() {
            return this.livePlaylistName_;
        }

        public ByteString getLivePlaylistNameBytes() {
            return ByteString.n(this.livePlaylistName_);
        }

        public String getPlaylistLocation() {
            return this.playlistLocation_;
        }

        public ByteString getPlaylistLocationBytes() {
            return ByteString.n(this.playlistLocation_);
        }

        public String getPlaylistName() {
            return this.playlistName_;
        }

        public ByteString getPlaylistNameBytes() {
            return ByteString.n(this.playlistName_);
        }

        public long getSegmentCount() {
            return this.segmentCount_;
        }

        public long getSize() {
            return this.size_;
        }

        public long getStartedAt() {
            return this.startedAt_;
        }

        public static Builder newBuilder(SegmentsInfo segmentsInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(segmentsInfo);
        }

        public static SegmentsInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentsInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SegmentsInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentsInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SegmentsInfo parseFrom(ByteString byteString) {
            return (SegmentsInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SegmentsInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentsInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SegmentsInfo parseFrom(byte[] bArr) {
            return (SegmentsInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SegmentsInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentsInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SegmentsInfo parseFrom(InputStream inputStream) {
            return (SegmentsInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SegmentsInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentsInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SegmentsInfo parseFrom(CodedInputStream codedInputStream) {
            return (SegmentsInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SegmentsInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SegmentsInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SegmentsInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class StopEgressRequest extends GeneratedMessageLite<StopEgressRequest, Builder> implements StopEgressRequestOrBuilder {
        private static final StopEgressRequest DEFAULT_INSTANCE;
        public static final int EGRESS_ID_FIELD_NUMBER = 1;
        private static volatile Parser<StopEgressRequest> PARSER;
        private String egressId_ = ap.a(949422226);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<StopEgressRequest, Builder> implements StopEgressRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(StopEgressRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            StopEgressRequest stopEgressRequest = new StopEgressRequest();
            DEFAULT_INSTANCE = stopEgressRequest;
            GeneratedMessageLite.registerDefaultInstance(StopEgressRequest.class, stopEgressRequest);
        }

        private StopEgressRequest() {
        }

        private void clearEgressId() {
            this.egressId_ = getDefaultInstance().getEgressId();
        }

        public static StopEgressRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static StopEgressRequest parseDelimitedFrom(InputStream inputStream) {
            return (StopEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StopEgressRequest parseFrom(ByteBuffer byteBuffer) {
            return (StopEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<StopEgressRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setEgressId(String str) {
            str.getClass();
            this.egressId_ = str;
        }

        private void setEgressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.egressId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new StopEgressRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"egressId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<StopEgressRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (StopEgressRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getEgressId() {
            return this.egressId_;
        }

        public ByteString getEgressIdBytes() {
            return ByteString.n(this.egressId_);
        }

        public static Builder newBuilder(StopEgressRequest stopEgressRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(stopEgressRequest);
        }

        public static StopEgressRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StopEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StopEgressRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (StopEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static StopEgressRequest parseFrom(ByteString byteString) {
            return (StopEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static StopEgressRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (StopEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static StopEgressRequest parseFrom(byte[] bArr) {
            return (StopEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static StopEgressRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (StopEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static StopEgressRequest parseFrom(InputStream inputStream) {
            return (StopEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StopEgressRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StopEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StopEgressRequest parseFrom(CodedInputStream codedInputStream) {
            return (StopEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static StopEgressRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StopEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface StopEgressRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class StreamInfo extends GeneratedMessageLite<StreamInfo, Builder> implements StreamInfoOrBuilder {
        private static final StreamInfo DEFAULT_INSTANCE;
        public static final int DURATION_FIELD_NUMBER = 4;
        public static final int ENDED_AT_FIELD_NUMBER = 3;
        public static final int ERROR_FIELD_NUMBER = 6;
        private static volatile Parser<StreamInfo> PARSER = null;
        public static final int STARTED_AT_FIELD_NUMBER = 2;
        public static final int STATUS_FIELD_NUMBER = 5;
        public static final int URL_FIELD_NUMBER = 1;
        private long duration_;
        private long endedAt_;
        private String error_;
        private long startedAt_;
        private int status_;
        private String url_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<StreamInfo, Builder> implements StreamInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(StreamInfo.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum Status implements Internal.EnumLite {
            b(0),
            c(1),
            d(2),
            e(-1);

            private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<Status>() { // from class: livekit.LivekitEgress.StreamInfo.Status.1
                /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
                public Status findValueByNumber(int i) {
                    return Status.b(i);
                }
            };
            private final int a;

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            private static final class StatusVerifier implements Internal.EnumVerifier {
                static final Internal.EnumVerifier a = new StatusVerifier();

                private StatusVerifier() {
                }

                public boolean isInRange(int i) {
                    return Status.b(i) != null;
                }
            }

            Status(int i) {
                this.a = i;
            }

            public static Status b(int i) {
                if (i == 0) {
                    return b;
                }
                if (i == 1) {
                    return c;
                }
                if (i != 2) {
                    return null;
                }
                return d;
            }

            public final int getNumber() {
                if (this != e) {
                    return this.a;
                }
                throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
            }
        }

        static {
            StreamInfo streamInfo = new StreamInfo();
            DEFAULT_INSTANCE = streamInfo;
            GeneratedMessageLite.registerDefaultInstance(StreamInfo.class, streamInfo);
        }

        private StreamInfo() {
            String strA = ap.a(47114508);
            this.url_ = strA;
            this.error_ = strA;
        }

        private void clearDuration() {
            this.duration_ = 0L;
        }

        private void clearEndedAt() {
            this.endedAt_ = 0L;
        }

        private void clearError() {
            this.error_ = getDefaultInstance().getError();
        }

        private void clearStartedAt() {
            this.startedAt_ = 0L;
        }

        private void clearStatus() {
            this.status_ = 0;
        }

        private void clearUrl() {
            this.url_ = getDefaultInstance().getUrl();
        }

        public static StreamInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static StreamInfo parseDelimitedFrom(InputStream inputStream) {
            return (StreamInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StreamInfo parseFrom(ByteBuffer byteBuffer) {
            return (StreamInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<StreamInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setDuration(long j) {
            this.duration_ = j;
        }

        private void setEndedAt(long j) {
            this.endedAt_ = j;
        }

        private void setError(String str) {
            str.getClass();
            this.error_ = str;
        }

        private void setErrorBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.error_ = byteString.L();
        }

        private void setStartedAt(long j) {
            this.startedAt_ = j;
        }

        private void setStatus(Status status) {
            this.status_ = status.getNumber();
        }

        private void setStatusValue(int i) {
            this.status_ = i;
        }

        private void setUrl(String str) {
            str.getClass();
            this.url_ = str;
        }

        private void setUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.url_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new StreamInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001Ȉ\u0002\u0002\u0003\u0002\u0004\u0002\u0005\f\u0006Ȉ", new Object[]{"url_", "startedAt_", "endedAt_", "duration_", "status_", "error_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<StreamInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (StreamInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getDuration() {
            return this.duration_;
        }

        public long getEndedAt() {
            return this.endedAt_;
        }

        public String getError() {
            return this.error_;
        }

        public ByteString getErrorBytes() {
            return ByteString.n(this.error_);
        }

        public long getStartedAt() {
            return this.startedAt_;
        }

        public Status getStatus() {
            Status statusB = Status.b(this.status_);
            return statusB == null ? Status.e : statusB;
        }

        public int getStatusValue() {
            return this.status_;
        }

        public String getUrl() {
            return this.url_;
        }

        public ByteString getUrlBytes() {
            return ByteString.n(this.url_);
        }

        public static Builder newBuilder(StreamInfo streamInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(streamInfo);
        }

        public static StreamInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StreamInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static StreamInfo parseFrom(ByteString byteString) {
            return (StreamInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static StreamInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static StreamInfo parseFrom(byte[] bArr) {
            return (StreamInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static StreamInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static StreamInfo parseFrom(InputStream inputStream) {
            return (StreamInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StreamInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StreamInfo parseFrom(CodedInputStream codedInputStream) {
            return (StreamInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static StreamInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public static final class StreamInfoList extends GeneratedMessageLite<StreamInfoList, Builder> implements StreamInfoListOrBuilder {
        private static final StreamInfoList DEFAULT_INSTANCE;
        public static final int INFO_FIELD_NUMBER = 1;
        private static volatile Parser<StreamInfoList> PARSER;
        private Internal.ProtobufList<StreamInfo> info_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<StreamInfoList, Builder> implements StreamInfoListOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(StreamInfoList.DEFAULT_INSTANCE);
            }
        }

        static {
            StreamInfoList streamInfoList = new StreamInfoList();
            DEFAULT_INSTANCE = streamInfoList;
            GeneratedMessageLite.registerDefaultInstance(StreamInfoList.class, streamInfoList);
        }

        private StreamInfoList() {
        }

        private void addAllInfo(Iterable<? extends StreamInfo> iterable) {
            ensureInfoIsMutable();
            AbstractMessageLite.addAll(iterable, this.info_);
        }

        private void addInfo(StreamInfo streamInfo) {
            streamInfo.getClass();
            ensureInfoIsMutable();
            this.info_.add(streamInfo);
        }

        private void clearInfo() {
            this.info_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureInfoIsMutable() {
            Internal.ProtobufList<StreamInfo> protobufList = this.info_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.info_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static StreamInfoList getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static StreamInfoList parseDelimitedFrom(InputStream inputStream) {
            return (StreamInfoList) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StreamInfoList parseFrom(ByteBuffer byteBuffer) {
            return (StreamInfoList) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<StreamInfoList> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeInfo(int i) {
            ensureInfoIsMutable();
            this.info_.remove(i);
        }

        private void setInfo(int i, StreamInfo streamInfo) {
            streamInfo.getClass();
            ensureInfoIsMutable();
            this.info_.set(i, streamInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new StreamInfoList();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1172115734), StreamInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<StreamInfoList> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (StreamInfoList.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public StreamInfo getInfo(int i) {
            return (StreamInfo) this.info_.get(i);
        }

        public int getInfoCount() {
            return this.info_.size();
        }

        public List<StreamInfo> getInfoList() {
            return this.info_;
        }

        public StreamInfoOrBuilder getInfoOrBuilder(int i) {
            return (StreamInfoOrBuilder) this.info_.get(i);
        }

        public List<? extends StreamInfoOrBuilder> getInfoOrBuilderList() {
            return this.info_;
        }

        public static Builder newBuilder(StreamInfoList streamInfoList) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(streamInfoList);
        }

        public static StreamInfoList parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfoList) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StreamInfoList parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfoList) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static StreamInfoList parseFrom(ByteString byteString) {
            return (StreamInfoList) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addInfo(int i, StreamInfo streamInfo) {
            streamInfo.getClass();
            ensureInfoIsMutable();
            this.info_.add(i, streamInfo);
        }

        public static StreamInfoList parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfoList) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static StreamInfoList parseFrom(byte[] bArr) {
            return (StreamInfoList) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static StreamInfoList parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfoList) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static StreamInfoList parseFrom(InputStream inputStream) {
            return (StreamInfoList) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StreamInfoList parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfoList) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StreamInfoList parseFrom(CodedInputStream codedInputStream) {
            return (StreamInfoList) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static StreamInfoList parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamInfoList) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public interface StreamInfoListOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface StreamInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class StreamOutput extends GeneratedMessageLite<StreamOutput, Builder> implements StreamOutputOrBuilder {
        private static final StreamOutput DEFAULT_INSTANCE;
        private static volatile Parser<StreamOutput> PARSER = null;
        public static final int PROTOCOL_FIELD_NUMBER = 1;
        public static final int URLS_FIELD_NUMBER = 2;
        private int protocol_;
        private Internal.ProtobufList<String> urls_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<StreamOutput, Builder> implements StreamOutputOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(StreamOutput.DEFAULT_INSTANCE);
            }
        }

        static {
            StreamOutput streamOutput = new StreamOutput();
            DEFAULT_INSTANCE = streamOutput;
            GeneratedMessageLite.registerDefaultInstance(StreamOutput.class, streamOutput);
        }

        private StreamOutput() {
        }

        private void addAllUrls(Iterable<String> iterable) {
            ensureUrlsIsMutable();
            AbstractMessageLite.addAll(iterable, this.urls_);
        }

        private void addUrls(String str) {
            str.getClass();
            ensureUrlsIsMutable();
            this.urls_.add(str);
        }

        private void addUrlsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureUrlsIsMutable();
            this.urls_.add(byteString.L());
        }

        private void clearProtocol() {
            this.protocol_ = 0;
        }

        private void clearUrls() {
            this.urls_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureUrlsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.urls_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.urls_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static StreamOutput getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static StreamOutput parseDelimitedFrom(InputStream inputStream) {
            return (StreamOutput) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StreamOutput parseFrom(ByteBuffer byteBuffer) {
            return (StreamOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<StreamOutput> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setProtocol(StreamProtocol streamProtocol) {
            this.protocol_ = streamProtocol.getNumber();
        }

        private void setProtocolValue(int i) {
            this.protocol_ = i;
        }

        private void setUrls(int i, String str) {
            str.getClass();
            ensureUrlsIsMutable();
            this.urls_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new StreamOutput();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0001\u0000\u0001\f\u0002Ț", new Object[]{ap.a(476772411), ap.a(1939671937)});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<StreamOutput> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (StreamOutput.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public StreamProtocol getProtocol() {
            StreamProtocol streamProtocolB = StreamProtocol.b(this.protocol_);
            return streamProtocolB == null ? StreamProtocol.e : streamProtocolB;
        }

        public int getProtocolValue() {
            return this.protocol_;
        }

        public String getUrls(int i) {
            return (String) this.urls_.get(i);
        }

        public ByteString getUrlsBytes(int i) {
            return ByteString.n((String) this.urls_.get(i));
        }

        public int getUrlsCount() {
            return this.urls_.size();
        }

        public List<String> getUrlsList() {
            return this.urls_;
        }

        public static Builder newBuilder(StreamOutput streamOutput) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(streamOutput);
        }

        public static StreamOutput parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamOutput) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StreamOutput parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static StreamOutput parseFrom(ByteString byteString) {
            return (StreamOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static StreamOutput parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static StreamOutput parseFrom(byte[] bArr) {
            return (StreamOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static StreamOutput parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static StreamOutput parseFrom(InputStream inputStream) {
            return (StreamOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static StreamOutput parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static StreamOutput parseFrom(CodedInputStream codedInputStream) {
            return (StreamOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static StreamOutput parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (StreamOutput) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface StreamOutputOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum StreamProtocol implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<StreamProtocol>() { // from class: livekit.LivekitEgress.StreamProtocol.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public StreamProtocol findValueByNumber(int i) {
                return StreamProtocol.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class StreamProtocolVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new StreamProtocolVerifier();

            private StreamProtocolVerifier() {
            }

            public boolean isInRange(int i) {
                return StreamProtocol.b(i) != null;
            }
        }

        StreamProtocol(int i) {
            this.a = i;
        }

        public static StreamProtocol b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TrackCompositeEgressRequest extends GeneratedMessageLite<TrackCompositeEgressRequest, Builder> implements TrackCompositeEgressRequestOrBuilder {
        public static final int ADVANCED_FIELD_NUMBER = 7;
        public static final int AUDIO_TRACK_ID_FIELD_NUMBER = 2;
        private static final TrackCompositeEgressRequest DEFAULT_INSTANCE;
        public static final int FILE_FIELD_NUMBER = 4;
        public static final int FILE_OUTPUTS_FIELD_NUMBER = 11;
        public static final int IMAGE_OUTPUTS_FIELD_NUMBER = 14;
        private static volatile Parser<TrackCompositeEgressRequest> PARSER = null;
        public static final int PRESET_FIELD_NUMBER = 6;
        public static final int ROOM_NAME_FIELD_NUMBER = 1;
        public static final int SEGMENTS_FIELD_NUMBER = 8;
        public static final int SEGMENT_OUTPUTS_FIELD_NUMBER = 13;
        public static final int STREAM_FIELD_NUMBER = 5;
        public static final int STREAM_OUTPUTS_FIELD_NUMBER = 12;
        public static final int VIDEO_TRACK_ID_FIELD_NUMBER = 3;
        public static final int WEBHOOKS_FIELD_NUMBER = 15;
        private String audioTrackId_;
        private Internal.ProtobufList<EncodedFileOutput> fileOutputs_;
        private Internal.ProtobufList<ImageOutput> imageOutputs_;
        private Object options_;
        private Object output_;
        private String roomName_;
        private Internal.ProtobufList<SegmentedFileOutput> segmentOutputs_;
        private Internal.ProtobufList<StreamOutput> streamOutputs_;
        private String videoTrackId_;
        private Internal.ProtobufList<LivekitModels.WebhookConfig> webhooks_;
        private int outputCase_ = 0;
        private int optionsCase_ = 0;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TrackCompositeEgressRequest, Builder> implements TrackCompositeEgressRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TrackCompositeEgressRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OptionsCase {
            b(6),
            c(7),
            d(0);

            private final int a;

            OptionsCase(int i) {
                this.a = i;
            }

            public static OptionsCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 6) {
                    return b;
                }
                if (i != 7) {
                    return null;
                }
                return c;
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OutputCase {
            b(4),
            c(5),
            d(8),
            e(0);

            private final int a;

            OutputCase(int i) {
                this.a = i;
            }

            public static OutputCase b(int i) {
                if (i == 0) {
                    return e;
                }
                if (i == 8) {
                    return d;
                }
                if (i == 4) {
                    return b;
                }
                if (i != 5) {
                    return null;
                }
                return c;
            }
        }

        static {
            TrackCompositeEgressRequest trackCompositeEgressRequest = new TrackCompositeEgressRequest();
            DEFAULT_INSTANCE = trackCompositeEgressRequest;
            GeneratedMessageLite.registerDefaultInstance(TrackCompositeEgressRequest.class, trackCompositeEgressRequest);
        }

        private TrackCompositeEgressRequest() {
            String strA = ap.a(1827782728);
            this.roomName_ = strA;
            this.audioTrackId_ = strA;
            this.videoTrackId_ = strA;
            this.fileOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.streamOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.segmentOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.imageOutputs_ = GeneratedMessageLite.emptyProtobufList();
            this.webhooks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllFileOutputs(Iterable<? extends EncodedFileOutput> iterable) {
            ensureFileOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.fileOutputs_);
        }

        private void addAllImageOutputs(Iterable<? extends ImageOutput> iterable) {
            ensureImageOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.imageOutputs_);
        }

        private void addAllSegmentOutputs(Iterable<? extends SegmentedFileOutput> iterable) {
            ensureSegmentOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.segmentOutputs_);
        }

        private void addAllStreamOutputs(Iterable<? extends StreamOutput> iterable) {
            ensureStreamOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.streamOutputs_);
        }

        private void addAllWebhooks(Iterable<? extends LivekitModels.WebhookConfig> iterable) {
            ensureWebhooksIsMutable();
            AbstractMessageLite.addAll(iterable, this.webhooks_);
        }

        private void addFileOutputs(EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.add(encodedFileOutput);
        }

        private void addImageOutputs(ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.add(imageOutput);
        }

        private void addSegmentOutputs(SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.add(segmentedFileOutput);
        }

        private void addStreamOutputs(StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.add(streamOutput);
        }

        private void addWebhooks(LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.add(webhookConfig);
        }

        private void clearAdvanced() {
            if (this.optionsCase_ == 7) {
                this.optionsCase_ = 0;
                this.options_ = null;
            }
        }

        private void clearAudioTrackId() {
            this.audioTrackId_ = getDefaultInstance().getAudioTrackId();
        }

        private void clearFile() {
            if (this.outputCase_ == 4) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearFileOutputs() {
            this.fileOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearImageOutputs() {
            this.imageOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearOptions() {
            this.optionsCase_ = 0;
            this.options_ = null;
        }

        private void clearOutput() {
            this.outputCase_ = 0;
            this.output_ = null;
        }

        private void clearPreset() {
            if (this.optionsCase_ == 6) {
                this.optionsCase_ = 0;
                this.options_ = null;
            }
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearSegmentOutputs() {
            this.segmentOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSegments() {
            if (this.outputCase_ == 8) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearStream() {
            if (this.outputCase_ == 5) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearStreamOutputs() {
            this.streamOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearVideoTrackId() {
            this.videoTrackId_ = getDefaultInstance().getVideoTrackId();
        }

        private void clearWebhooks() {
            this.webhooks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureFileOutputsIsMutable() {
            Internal.ProtobufList<EncodedFileOutput> protobufList = this.fileOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.fileOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureImageOutputsIsMutable() {
            Internal.ProtobufList<ImageOutput> protobufList = this.imageOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.imageOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSegmentOutputsIsMutable() {
            Internal.ProtobufList<SegmentedFileOutput> protobufList = this.segmentOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.segmentOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureStreamOutputsIsMutable() {
            Internal.ProtobufList<StreamOutput> protobufList = this.streamOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.streamOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureWebhooksIsMutable() {
            Internal.ProtobufList<LivekitModels.WebhookConfig> protobufList = this.webhooks_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.webhooks_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static TrackCompositeEgressRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAdvanced(EncodingOptions encodingOptions) {
            encodingOptions.getClass();
            if (this.optionsCase_ != 7 || this.options_ == EncodingOptions.getDefaultInstance()) {
                this.options_ = encodingOptions;
            } else {
                this.options_ = ((EncodingOptions.Builder) EncodingOptions.newBuilder((EncodingOptions) this.options_).v(encodingOptions)).o();
            }
            this.optionsCase_ = 7;
        }

        private void mergeFile(EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            if (this.outputCase_ != 4 || this.output_ == EncodedFileOutput.getDefaultInstance()) {
                this.output_ = encodedFileOutput;
            } else {
                this.output_ = ((EncodedFileOutput.Builder) EncodedFileOutput.newBuilder((EncodedFileOutput) this.output_).v(encodedFileOutput)).o();
            }
            this.outputCase_ = 4;
        }

        private void mergeSegments(SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            if (this.outputCase_ != 8 || this.output_ == SegmentedFileOutput.getDefaultInstance()) {
                this.output_ = segmentedFileOutput;
            } else {
                this.output_ = ((SegmentedFileOutput.Builder) SegmentedFileOutput.newBuilder((SegmentedFileOutput) this.output_).v(segmentedFileOutput)).o();
            }
            this.outputCase_ = 8;
        }

        private void mergeStream(StreamOutput streamOutput) {
            streamOutput.getClass();
            if (this.outputCase_ != 5 || this.output_ == StreamOutput.getDefaultInstance()) {
                this.output_ = streamOutput;
            } else {
                this.output_ = ((StreamOutput.Builder) StreamOutput.newBuilder((StreamOutput) this.output_).v(streamOutput)).o();
            }
            this.outputCase_ = 5;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TrackCompositeEgressRequest parseDelimitedFrom(InputStream inputStream) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackCompositeEgressRequest parseFrom(ByteBuffer byteBuffer) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TrackCompositeEgressRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeFileOutputs(int i) {
            ensureFileOutputsIsMutable();
            this.fileOutputs_.remove(i);
        }

        private void removeImageOutputs(int i) {
            ensureImageOutputsIsMutable();
            this.imageOutputs_.remove(i);
        }

        private void removeSegmentOutputs(int i) {
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.remove(i);
        }

        private void removeStreamOutputs(int i) {
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.remove(i);
        }

        private void removeWebhooks(int i) {
            ensureWebhooksIsMutable();
            this.webhooks_.remove(i);
        }

        private void setAdvanced(EncodingOptions encodingOptions) {
            encodingOptions.getClass();
            this.options_ = encodingOptions;
            this.optionsCase_ = 7;
        }

        private void setAudioTrackId(String str) {
            str.getClass();
            this.audioTrackId_ = str;
        }

        private void setAudioTrackIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.audioTrackId_ = byteString.L();
        }

        private void setFile(EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            this.output_ = encodedFileOutput;
            this.outputCase_ = 4;
        }

        private void setFileOutputs(int i, EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.set(i, encodedFileOutput);
        }

        private void setImageOutputs(int i, ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.set(i, imageOutput);
        }

        private void setPreset(EncodingOptionsPreset encodingOptionsPreset) {
            this.options_ = Integer.valueOf(encodingOptionsPreset.getNumber());
            this.optionsCase_ = 6;
        }

        private void setPresetValue(int i) {
            this.optionsCase_ = 6;
            this.options_ = Integer.valueOf(i);
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setSegmentOutputs(int i, SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.set(i, segmentedFileOutput);
        }

        private void setSegments(SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            this.output_ = segmentedFileOutput;
            this.outputCase_ = 8;
        }

        private void setStream(StreamOutput streamOutput) {
            streamOutput.getClass();
            this.output_ = streamOutput;
            this.outputCase_ = 5;
        }

        private void setStreamOutputs(int i, StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.set(i, streamOutput);
        }

        private void setVideoTrackId(String str) {
            str.getClass();
            this.videoTrackId_ = str;
        }

        private void setVideoTrackIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.videoTrackId_ = byteString.L();
        }

        private void setWebhooks(int i, LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.set(i, webhookConfig);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new TrackCompositeEgressRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\r\u0002\u0000\u0001\u000f\r\u0000\u0005\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004<\u0000\u0005<\u0000\u0006?\u0001\u0007<\u0001\b<\u0000\u000b\u001b\f\u001b\r\u001b\u000e\u001b\u000f\u001b", new Object[]{"output_", "outputCase_", "options_", "optionsCase_", "roomName_", "audioTrackId_", "videoTrackId_", EncodedFileOutput.class, StreamOutput.class, EncodingOptions.class, SegmentedFileOutput.class, "fileOutputs_", EncodedFileOutput.class, "streamOutputs_", StreamOutput.class, "segmentOutputs_", SegmentedFileOutput.class, "imageOutputs_", ImageOutput.class, "webhooks_", LivekitModels.WebhookConfig.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TrackCompositeEgressRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TrackCompositeEgressRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public EncodingOptions getAdvanced() {
            return this.optionsCase_ == 7 ? (EncodingOptions) this.options_ : EncodingOptions.getDefaultInstance();
        }

        public String getAudioTrackId() {
            return this.audioTrackId_;
        }

        public ByteString getAudioTrackIdBytes() {
            return ByteString.n(this.audioTrackId_);
        }

        @Deprecated
        public EncodedFileOutput getFile() {
            return this.outputCase_ == 4 ? (EncodedFileOutput) this.output_ : EncodedFileOutput.getDefaultInstance();
        }

        public EncodedFileOutput getFileOutputs(int i) {
            return (EncodedFileOutput) this.fileOutputs_.get(i);
        }

        public int getFileOutputsCount() {
            return this.fileOutputs_.size();
        }

        public List<EncodedFileOutput> getFileOutputsList() {
            return this.fileOutputs_;
        }

        public EncodedFileOutputOrBuilder getFileOutputsOrBuilder(int i) {
            return (EncodedFileOutputOrBuilder) this.fileOutputs_.get(i);
        }

        public List<? extends EncodedFileOutputOrBuilder> getFileOutputsOrBuilderList() {
            return this.fileOutputs_;
        }

        public ImageOutput getImageOutputs(int i) {
            return (ImageOutput) this.imageOutputs_.get(i);
        }

        public int getImageOutputsCount() {
            return this.imageOutputs_.size();
        }

        public List<ImageOutput> getImageOutputsList() {
            return this.imageOutputs_;
        }

        public ImageOutputOrBuilder getImageOutputsOrBuilder(int i) {
            return (ImageOutputOrBuilder) this.imageOutputs_.get(i);
        }

        public List<? extends ImageOutputOrBuilder> getImageOutputsOrBuilderList() {
            return this.imageOutputs_;
        }

        public OptionsCase getOptionsCase() {
            return OptionsCase.b(this.optionsCase_);
        }

        public OutputCase getOutputCase() {
            return OutputCase.b(this.outputCase_);
        }

        public EncodingOptionsPreset getPreset() {
            if (this.optionsCase_ != 6) {
                return EncodingOptionsPreset.b;
            }
            EncodingOptionsPreset encodingOptionsPresetB = EncodingOptionsPreset.b(((Integer) this.options_).intValue());
            return encodingOptionsPresetB == null ? EncodingOptionsPreset.j : encodingOptionsPresetB;
        }

        public int getPresetValue() {
            if (this.optionsCase_ == 6) {
                return ((Integer) this.options_).intValue();
            }
            return 0;
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public SegmentedFileOutput getSegmentOutputs(int i) {
            return (SegmentedFileOutput) this.segmentOutputs_.get(i);
        }

        public int getSegmentOutputsCount() {
            return this.segmentOutputs_.size();
        }

        public List<SegmentedFileOutput> getSegmentOutputsList() {
            return this.segmentOutputs_;
        }

        public SegmentedFileOutputOrBuilder getSegmentOutputsOrBuilder(int i) {
            return (SegmentedFileOutputOrBuilder) this.segmentOutputs_.get(i);
        }

        public List<? extends SegmentedFileOutputOrBuilder> getSegmentOutputsOrBuilderList() {
            return this.segmentOutputs_;
        }

        @Deprecated
        public SegmentedFileOutput getSegments() {
            return this.outputCase_ == 8 ? (SegmentedFileOutput) this.output_ : SegmentedFileOutput.getDefaultInstance();
        }

        @Deprecated
        public StreamOutput getStream() {
            return this.outputCase_ == 5 ? (StreamOutput) this.output_ : StreamOutput.getDefaultInstance();
        }

        public StreamOutput getStreamOutputs(int i) {
            return (StreamOutput) this.streamOutputs_.get(i);
        }

        public int getStreamOutputsCount() {
            return this.streamOutputs_.size();
        }

        public List<StreamOutput> getStreamOutputsList() {
            return this.streamOutputs_;
        }

        public StreamOutputOrBuilder getStreamOutputsOrBuilder(int i) {
            return (StreamOutputOrBuilder) this.streamOutputs_.get(i);
        }

        public List<? extends StreamOutputOrBuilder> getStreamOutputsOrBuilderList() {
            return this.streamOutputs_;
        }

        public String getVideoTrackId() {
            return this.videoTrackId_;
        }

        public ByteString getVideoTrackIdBytes() {
            return ByteString.n(this.videoTrackId_);
        }

        public LivekitModels.WebhookConfig getWebhooks(int i) {
            return (LivekitModels.WebhookConfig) this.webhooks_.get(i);
        }

        public int getWebhooksCount() {
            return this.webhooks_.size();
        }

        public List<LivekitModels.WebhookConfig> getWebhooksList() {
            return this.webhooks_;
        }

        public LivekitModels.WebhookConfigOrBuilder getWebhooksOrBuilder(int i) {
            return (LivekitModels.WebhookConfigOrBuilder) this.webhooks_.get(i);
        }

        public List<? extends LivekitModels.WebhookConfigOrBuilder> getWebhooksOrBuilderList() {
            return this.webhooks_;
        }

        public boolean hasAdvanced() {
            return this.optionsCase_ == 7;
        }

        @Deprecated
        public boolean hasFile() {
            return this.outputCase_ == 4;
        }

        public boolean hasPreset() {
            return this.optionsCase_ == 6;
        }

        @Deprecated
        public boolean hasSegments() {
            return this.outputCase_ == 8;
        }

        @Deprecated
        public boolean hasStream() {
            return this.outputCase_ == 5;
        }

        public static Builder newBuilder(TrackCompositeEgressRequest trackCompositeEgressRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(trackCompositeEgressRequest);
        }

        public static TrackCompositeEgressRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackCompositeEgressRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TrackCompositeEgressRequest parseFrom(ByteString byteString) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addFileOutputs(int i, EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.add(i, encodedFileOutput);
        }

        private void addImageOutputs(int i, ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.add(i, imageOutput);
        }

        private void addSegmentOutputs(int i, SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.add(i, segmentedFileOutput);
        }

        private void addStreamOutputs(int i, StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.add(i, streamOutput);
        }

        private void addWebhooks(int i, LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.add(i, webhookConfig);
        }

        public static TrackCompositeEgressRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TrackCompositeEgressRequest parseFrom(byte[] bArr) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TrackCompositeEgressRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TrackCompositeEgressRequest parseFrom(InputStream inputStream) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackCompositeEgressRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackCompositeEgressRequest parseFrom(CodedInputStream codedInputStream) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TrackCompositeEgressRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackCompositeEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TrackCompositeEgressRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class TrackEgressRequest extends GeneratedMessageLite<TrackEgressRequest, Builder> implements TrackEgressRequestOrBuilder {
        private static final TrackEgressRequest DEFAULT_INSTANCE;
        public static final int FILE_FIELD_NUMBER = 3;
        private static volatile Parser<TrackEgressRequest> PARSER = null;
        public static final int ROOM_NAME_FIELD_NUMBER = 1;
        public static final int TRACK_ID_FIELD_NUMBER = 2;
        public static final int WEBHOOKS_FIELD_NUMBER = 5;
        public static final int WEBSOCKET_URL_FIELD_NUMBER = 4;
        private int outputCase_ = 0;
        private Object output_;
        private String roomName_;
        private String trackId_;
        private Internal.ProtobufList<LivekitModels.WebhookConfig> webhooks_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<TrackEgressRequest, Builder> implements TrackEgressRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(TrackEgressRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OutputCase {
            b(3),
            c(4),
            d(0);

            private final int a;

            OutputCase(int i) {
                this.a = i;
            }

            public static OutputCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 3) {
                    return b;
                }
                if (i != 4) {
                    return null;
                }
                return c;
            }
        }

        static {
            TrackEgressRequest trackEgressRequest = new TrackEgressRequest();
            DEFAULT_INSTANCE = trackEgressRequest;
            GeneratedMessageLite.registerDefaultInstance(TrackEgressRequest.class, trackEgressRequest);
        }

        private TrackEgressRequest() {
            String strA = ap.a(2038446360);
            this.roomName_ = strA;
            this.trackId_ = strA;
            this.webhooks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllWebhooks(Iterable<? extends LivekitModels.WebhookConfig> iterable) {
            ensureWebhooksIsMutable();
            AbstractMessageLite.addAll(iterable, this.webhooks_);
        }

        private void addWebhooks(LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.add(webhookConfig);
        }

        private void clearFile() {
            if (this.outputCase_ == 3) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearOutput() {
            this.outputCase_ = 0;
            this.output_ = null;
        }

        private void clearRoomName() {
            this.roomName_ = getDefaultInstance().getRoomName();
        }

        private void clearTrackId() {
            this.trackId_ = getDefaultInstance().getTrackId();
        }

        private void clearWebhooks() {
            this.webhooks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearWebsocketUrl() {
            if (this.outputCase_ == 4) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void ensureWebhooksIsMutable() {
            Internal.ProtobufList<LivekitModels.WebhookConfig> protobufList = this.webhooks_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.webhooks_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static TrackEgressRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeFile(DirectFileOutput directFileOutput) {
            directFileOutput.getClass();
            if (this.outputCase_ != 3 || this.output_ == DirectFileOutput.getDefaultInstance()) {
                this.output_ = directFileOutput;
            } else {
                this.output_ = ((DirectFileOutput.Builder) DirectFileOutput.newBuilder((DirectFileOutput) this.output_).v(directFileOutput)).o();
            }
            this.outputCase_ = 3;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static TrackEgressRequest parseDelimitedFrom(InputStream inputStream) {
            return (TrackEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackEgressRequest parseFrom(ByteBuffer byteBuffer) {
            return (TrackEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<TrackEgressRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeWebhooks(int i) {
            ensureWebhooksIsMutable();
            this.webhooks_.remove(i);
        }

        private void setFile(DirectFileOutput directFileOutput) {
            directFileOutput.getClass();
            this.output_ = directFileOutput;
            this.outputCase_ = 3;
        }

        private void setRoomName(String str) {
            str.getClass();
            this.roomName_ = str;
        }

        private void setRoomNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.roomName_ = byteString.L();
        }

        private void setTrackId(String str) {
            str.getClass();
            this.trackId_ = str;
        }

        private void setTrackIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.trackId_ = byteString.L();
        }

        private void setWebhooks(int i, LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.set(i, webhookConfig);
        }

        private void setWebsocketUrl(String str) {
            str.getClass();
            this.outputCase_ = 4;
            this.output_ = str;
        }

        private void setWebsocketUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.output_ = byteString.L();
            this.outputCase_ = 4;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new TrackEgressRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0001\u0000\u0001\u0005\u0005\u0000\u0001\u0000\u0001Ȉ\u0002Ȉ\u0003<\u0000\u0004Ȼ\u0000\u0005\u001b", new Object[]{"output_", "outputCase_", "roomName_", "trackId_", DirectFileOutput.class, "webhooks_", LivekitModels.WebhookConfig.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<TrackEgressRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (TrackEgressRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public DirectFileOutput getFile() {
            return this.outputCase_ == 3 ? (DirectFileOutput) this.output_ : DirectFileOutput.getDefaultInstance();
        }

        public OutputCase getOutputCase() {
            return OutputCase.b(this.outputCase_);
        }

        public String getRoomName() {
            return this.roomName_;
        }

        public ByteString getRoomNameBytes() {
            return ByteString.n(this.roomName_);
        }

        public String getTrackId() {
            return this.trackId_;
        }

        public ByteString getTrackIdBytes() {
            return ByteString.n(this.trackId_);
        }

        public LivekitModels.WebhookConfig getWebhooks(int i) {
            return (LivekitModels.WebhookConfig) this.webhooks_.get(i);
        }

        public int getWebhooksCount() {
            return this.webhooks_.size();
        }

        public List<LivekitModels.WebhookConfig> getWebhooksList() {
            return this.webhooks_;
        }

        public LivekitModels.WebhookConfigOrBuilder getWebhooksOrBuilder(int i) {
            return (LivekitModels.WebhookConfigOrBuilder) this.webhooks_.get(i);
        }

        public List<? extends LivekitModels.WebhookConfigOrBuilder> getWebhooksOrBuilderList() {
            return this.webhooks_;
        }

        public String getWebsocketUrl() {
            return this.outputCase_ == 4 ? (String) this.output_ : StringUtils.EMPTY;
        }

        public ByteString getWebsocketUrlBytes() {
            return ByteString.n(this.outputCase_ == 4 ? (String) this.output_ : StringUtils.EMPTY);
        }

        public boolean hasFile() {
            return this.outputCase_ == 3;
        }

        public boolean hasWebsocketUrl() {
            return this.outputCase_ == 4;
        }

        public static Builder newBuilder(TrackEgressRequest trackEgressRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(trackEgressRequest);
        }

        public static TrackEgressRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackEgressRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static TrackEgressRequest parseFrom(ByteString byteString) {
            return (TrackEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addWebhooks(int i, LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.add(i, webhookConfig);
        }

        public static TrackEgressRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static TrackEgressRequest parseFrom(byte[] bArr) {
            return (TrackEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static TrackEgressRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static TrackEgressRequest parseFrom(InputStream inputStream) {
            return (TrackEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static TrackEgressRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static TrackEgressRequest parseFrom(CodedInputStream codedInputStream) {
            return (TrackEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static TrackEgressRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (TrackEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface TrackEgressRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateLayoutRequest extends GeneratedMessageLite<UpdateLayoutRequest, Builder> implements UpdateLayoutRequestOrBuilder {
        private static final UpdateLayoutRequest DEFAULT_INSTANCE;
        public static final int EGRESS_ID_FIELD_NUMBER = 1;
        public static final int LAYOUT_FIELD_NUMBER = 2;
        private static volatile Parser<UpdateLayoutRequest> PARSER;
        private String egressId_;
        private String layout_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateLayoutRequest, Builder> implements UpdateLayoutRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateLayoutRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateLayoutRequest updateLayoutRequest = new UpdateLayoutRequest();
            DEFAULT_INSTANCE = updateLayoutRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdateLayoutRequest.class, updateLayoutRequest);
        }

        private UpdateLayoutRequest() {
            String strA = ap.a(2063614766);
            this.egressId_ = strA;
            this.layout_ = strA;
        }

        private void clearEgressId() {
            this.egressId_ = getDefaultInstance().getEgressId();
        }

        private void clearLayout() {
            this.layout_ = getDefaultInstance().getLayout();
        }

        public static UpdateLayoutRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateLayoutRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateLayoutRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateLayoutRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setEgressId(String str) {
            str.getClass();
            this.egressId_ = str;
        }

        private void setEgressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.egressId_ = byteString.L();
        }

        private void setLayout(String str) {
            str.getClass();
            this.layout_ = str;
        }

        private void setLayoutBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.layout_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateLayoutRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"egressId_", "layout_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateLayoutRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateLayoutRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getEgressId() {
            return this.egressId_;
        }

        public ByteString getEgressIdBytes() {
            return ByteString.n(this.egressId_);
        }

        public String getLayout() {
            return this.layout_;
        }

        public ByteString getLayoutBytes() {
            return ByteString.n(this.layout_);
        }

        public static Builder newBuilder(UpdateLayoutRequest updateLayoutRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateLayoutRequest);
        }

        public static UpdateLayoutRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateLayoutRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateLayoutRequest parseFrom(ByteString byteString) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateLayoutRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateLayoutRequest parseFrom(byte[] bArr) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateLayoutRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateLayoutRequest parseFrom(InputStream inputStream) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateLayoutRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateLayoutRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateLayoutRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateLayoutRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateLayoutRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateStreamRequest extends GeneratedMessageLite<UpdateStreamRequest, Builder> implements UpdateStreamRequestOrBuilder {
        public static final int ADD_OUTPUT_URLS_FIELD_NUMBER = 2;
        private static final UpdateStreamRequest DEFAULT_INSTANCE;
        public static final int EGRESS_ID_FIELD_NUMBER = 1;
        private static volatile Parser<UpdateStreamRequest> PARSER = null;
        public static final int REMOVE_OUTPUT_URLS_FIELD_NUMBER = 3;
        private String egressId_ = ap.a(1772371377);
        private Internal.ProtobufList<String> addOutputUrls_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<String> removeOutputUrls_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateStreamRequest, Builder> implements UpdateStreamRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateStreamRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateStreamRequest updateStreamRequest = new UpdateStreamRequest();
            DEFAULT_INSTANCE = updateStreamRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdateStreamRequest.class, updateStreamRequest);
        }

        private UpdateStreamRequest() {
        }

        private void addAddOutputUrls(String str) {
            str.getClass();
            ensureAddOutputUrlsIsMutable();
            this.addOutputUrls_.add(str);
        }

        private void addAddOutputUrlsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureAddOutputUrlsIsMutable();
            this.addOutputUrls_.add(byteString.L());
        }

        private void addAllAddOutputUrls(Iterable<String> iterable) {
            ensureAddOutputUrlsIsMutable();
            AbstractMessageLite.addAll(iterable, this.addOutputUrls_);
        }

        private void addAllRemoveOutputUrls(Iterable<String> iterable) {
            ensureRemoveOutputUrlsIsMutable();
            AbstractMessageLite.addAll(iterable, this.removeOutputUrls_);
        }

        private void addRemoveOutputUrls(String str) {
            str.getClass();
            ensureRemoveOutputUrlsIsMutable();
            this.removeOutputUrls_.add(str);
        }

        private void addRemoveOutputUrlsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureRemoveOutputUrlsIsMutable();
            this.removeOutputUrls_.add(byteString.L());
        }

        private void clearAddOutputUrls() {
            this.addOutputUrls_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearEgressId() {
            this.egressId_ = getDefaultInstance().getEgressId();
        }

        private void clearRemoveOutputUrls() {
            this.removeOutputUrls_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureAddOutputUrlsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.addOutputUrls_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.addOutputUrls_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureRemoveOutputUrlsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.removeOutputUrls_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.removeOutputUrls_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static UpdateStreamRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateStreamRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateStreamRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateStreamRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAddOutputUrls(int i, String str) {
            str.getClass();
            ensureAddOutputUrlsIsMutable();
            this.addOutputUrls_.set(i, str);
        }

        private void setEgressId(String str) {
            str.getClass();
            this.egressId_ = str;
        }

        private void setEgressIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.egressId_ = byteString.L();
        }

        private void setRemoveOutputUrls(int i, String str) {
            str.getClass();
            ensureRemoveOutputUrlsIsMutable();
            this.removeOutputUrls_.set(i, str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateStreamRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0002\u0000\u0001Ȉ\u0002Ț\u0003Ț", new Object[]{"egressId_", "addOutputUrls_", "removeOutputUrls_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateStreamRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateStreamRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAddOutputUrls(int i) {
            return (String) this.addOutputUrls_.get(i);
        }

        public ByteString getAddOutputUrlsBytes(int i) {
            return ByteString.n((String) this.addOutputUrls_.get(i));
        }

        public int getAddOutputUrlsCount() {
            return this.addOutputUrls_.size();
        }

        public List<String> getAddOutputUrlsList() {
            return this.addOutputUrls_;
        }

        public String getEgressId() {
            return this.egressId_;
        }

        public ByteString getEgressIdBytes() {
            return ByteString.n(this.egressId_);
        }

        public String getRemoveOutputUrls(int i) {
            return (String) this.removeOutputUrls_.get(i);
        }

        public ByteString getRemoveOutputUrlsBytes(int i) {
            return ByteString.n((String) this.removeOutputUrls_.get(i));
        }

        public int getRemoveOutputUrlsCount() {
            return this.removeOutputUrls_.size();
        }

        public List<String> getRemoveOutputUrlsList() {
            return this.removeOutputUrls_;
        }

        public static Builder newBuilder(UpdateStreamRequest updateStreamRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateStreamRequest);
        }

        public static UpdateStreamRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateStreamRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateStreamRequest parseFrom(ByteString byteString) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateStreamRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateStreamRequest parseFrom(byte[] bArr) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateStreamRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateStreamRequest parseFrom(InputStream inputStream) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateStreamRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateStreamRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateStreamRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateStreamRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateStreamRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class WebEgressRequest extends GeneratedMessageLite<WebEgressRequest, Builder> implements WebEgressRequestOrBuilder {
        public static final int ADVANCED_FIELD_NUMBER = 8;
        public static final int AUDIO_ONLY_FIELD_NUMBER = 2;
        public static final int AWAIT_START_SIGNAL_FIELD_NUMBER = 12;
        private static final WebEgressRequest DEFAULT_INSTANCE;
        public static final int FILE_FIELD_NUMBER = 4;
        public static final int FILE_OUTPUTS_FIELD_NUMBER = 9;
        public static final int IMAGE_OUTPUTS_FIELD_NUMBER = 13;
        private static volatile Parser<WebEgressRequest> PARSER = null;
        public static final int PRESET_FIELD_NUMBER = 7;
        public static final int SEGMENTS_FIELD_NUMBER = 6;
        public static final int SEGMENT_OUTPUTS_FIELD_NUMBER = 11;
        public static final int STREAM_FIELD_NUMBER = 5;
        public static final int STREAM_OUTPUTS_FIELD_NUMBER = 10;
        public static final int URL_FIELD_NUMBER = 1;
        public static final int VIDEO_ONLY_FIELD_NUMBER = 3;
        public static final int WEBHOOKS_FIELD_NUMBER = 14;
        private boolean audioOnly_;
        private boolean awaitStartSignal_;
        private Object options_;
        private Object output_;
        private boolean videoOnly_;
        private int outputCase_ = 0;
        private int optionsCase_ = 0;
        private String url_ = ap.a(880983431);
        private Internal.ProtobufList<EncodedFileOutput> fileOutputs_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<StreamOutput> streamOutputs_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<SegmentedFileOutput> segmentOutputs_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<ImageOutput> imageOutputs_ = GeneratedMessageLite.emptyProtobufList();
        private Internal.ProtobufList<LivekitModels.WebhookConfig> webhooks_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<WebEgressRequest, Builder> implements WebEgressRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(WebEgressRequest.DEFAULT_INSTANCE);
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OptionsCase {
            b(7),
            c(8),
            d(0);

            private final int a;

            OptionsCase(int i) {
                this.a = i;
            }

            public static OptionsCase b(int i) {
                if (i == 0) {
                    return d;
                }
                if (i == 7) {
                    return b;
                }
                if (i != 8) {
                    return null;
                }
                return c;
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public enum OutputCase {
            b(4),
            c(5),
            d(6),
            e(0);

            private final int a;

            OutputCase(int i) {
                this.a = i;
            }

            public static OutputCase b(int i) {
                if (i == 0) {
                    return e;
                }
                if (i == 4) {
                    return b;
                }
                if (i == 5) {
                    return c;
                }
                if (i != 6) {
                    return null;
                }
                return d;
            }
        }

        static {
            WebEgressRequest webEgressRequest = new WebEgressRequest();
            DEFAULT_INSTANCE = webEgressRequest;
            GeneratedMessageLite.registerDefaultInstance(WebEgressRequest.class, webEgressRequest);
        }

        private WebEgressRequest() {
        }

        private void addAllFileOutputs(Iterable<? extends EncodedFileOutput> iterable) {
            ensureFileOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.fileOutputs_);
        }

        private void addAllImageOutputs(Iterable<? extends ImageOutput> iterable) {
            ensureImageOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.imageOutputs_);
        }

        private void addAllSegmentOutputs(Iterable<? extends SegmentedFileOutput> iterable) {
            ensureSegmentOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.segmentOutputs_);
        }

        private void addAllStreamOutputs(Iterable<? extends StreamOutput> iterable) {
            ensureStreamOutputsIsMutable();
            AbstractMessageLite.addAll(iterable, this.streamOutputs_);
        }

        private void addAllWebhooks(Iterable<? extends LivekitModels.WebhookConfig> iterable) {
            ensureWebhooksIsMutable();
            AbstractMessageLite.addAll(iterable, this.webhooks_);
        }

        private void addFileOutputs(EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.add(encodedFileOutput);
        }

        private void addImageOutputs(ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.add(imageOutput);
        }

        private void addSegmentOutputs(SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.add(segmentedFileOutput);
        }

        private void addStreamOutputs(StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.add(streamOutput);
        }

        private void addWebhooks(LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.add(webhookConfig);
        }

        private void clearAdvanced() {
            if (this.optionsCase_ == 8) {
                this.optionsCase_ = 0;
                this.options_ = null;
            }
        }

        private void clearAudioOnly() {
            this.audioOnly_ = false;
        }

        private void clearAwaitStartSignal() {
            this.awaitStartSignal_ = false;
        }

        private void clearFile() {
            if (this.outputCase_ == 4) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearFileOutputs() {
            this.fileOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearImageOutputs() {
            this.imageOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearOptions() {
            this.optionsCase_ = 0;
            this.options_ = null;
        }

        private void clearOutput() {
            this.outputCase_ = 0;
            this.output_ = null;
        }

        private void clearPreset() {
            if (this.optionsCase_ == 7) {
                this.optionsCase_ = 0;
                this.options_ = null;
            }
        }

        private void clearSegmentOutputs() {
            this.segmentOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearSegments() {
            if (this.outputCase_ == 6) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearStream() {
            if (this.outputCase_ == 5) {
                this.outputCase_ = 0;
                this.output_ = null;
            }
        }

        private void clearStreamOutputs() {
            this.streamOutputs_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearUrl() {
            this.url_ = getDefaultInstance().getUrl();
        }

        private void clearVideoOnly() {
            this.videoOnly_ = false;
        }

        private void clearWebhooks() {
            this.webhooks_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureFileOutputsIsMutable() {
            Internal.ProtobufList<EncodedFileOutput> protobufList = this.fileOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.fileOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureImageOutputsIsMutable() {
            Internal.ProtobufList<ImageOutput> protobufList = this.imageOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.imageOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSegmentOutputsIsMutable() {
            Internal.ProtobufList<SegmentedFileOutput> protobufList = this.segmentOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.segmentOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureStreamOutputsIsMutable() {
            Internal.ProtobufList<StreamOutput> protobufList = this.streamOutputs_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.streamOutputs_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureWebhooksIsMutable() {
            Internal.ProtobufList<LivekitModels.WebhookConfig> protobufList = this.webhooks_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.webhooks_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static WebEgressRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeAdvanced(EncodingOptions encodingOptions) {
            encodingOptions.getClass();
            if (this.optionsCase_ != 8 || this.options_ == EncodingOptions.getDefaultInstance()) {
                this.options_ = encodingOptions;
            } else {
                this.options_ = ((EncodingOptions.Builder) EncodingOptions.newBuilder((EncodingOptions) this.options_).v(encodingOptions)).o();
            }
            this.optionsCase_ = 8;
        }

        private void mergeFile(EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            if (this.outputCase_ != 4 || this.output_ == EncodedFileOutput.getDefaultInstance()) {
                this.output_ = encodedFileOutput;
            } else {
                this.output_ = ((EncodedFileOutput.Builder) EncodedFileOutput.newBuilder((EncodedFileOutput) this.output_).v(encodedFileOutput)).o();
            }
            this.outputCase_ = 4;
        }

        private void mergeSegments(SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            if (this.outputCase_ != 6 || this.output_ == SegmentedFileOutput.getDefaultInstance()) {
                this.output_ = segmentedFileOutput;
            } else {
                this.output_ = ((SegmentedFileOutput.Builder) SegmentedFileOutput.newBuilder((SegmentedFileOutput) this.output_).v(segmentedFileOutput)).o();
            }
            this.outputCase_ = 6;
        }

        private void mergeStream(StreamOutput streamOutput) {
            streamOutput.getClass();
            if (this.outputCase_ != 5 || this.output_ == StreamOutput.getDefaultInstance()) {
                this.output_ = streamOutput;
            } else {
                this.output_ = ((StreamOutput.Builder) StreamOutput.newBuilder((StreamOutput) this.output_).v(streamOutput)).o();
            }
            this.outputCase_ = 5;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static WebEgressRequest parseDelimitedFrom(InputStream inputStream) {
            return (WebEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WebEgressRequest parseFrom(ByteBuffer byteBuffer) {
            return (WebEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<WebEgressRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeFileOutputs(int i) {
            ensureFileOutputsIsMutable();
            this.fileOutputs_.remove(i);
        }

        private void removeImageOutputs(int i) {
            ensureImageOutputsIsMutable();
            this.imageOutputs_.remove(i);
        }

        private void removeSegmentOutputs(int i) {
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.remove(i);
        }

        private void removeStreamOutputs(int i) {
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.remove(i);
        }

        private void removeWebhooks(int i) {
            ensureWebhooksIsMutable();
            this.webhooks_.remove(i);
        }

        private void setAdvanced(EncodingOptions encodingOptions) {
            encodingOptions.getClass();
            this.options_ = encodingOptions;
            this.optionsCase_ = 8;
        }

        private void setAudioOnly(boolean z) {
            this.audioOnly_ = z;
        }

        private void setAwaitStartSignal(boolean z) {
            this.awaitStartSignal_ = z;
        }

        private void setFile(EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            this.output_ = encodedFileOutput;
            this.outputCase_ = 4;
        }

        private void setFileOutputs(int i, EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.set(i, encodedFileOutput);
        }

        private void setImageOutputs(int i, ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.set(i, imageOutput);
        }

        private void setPreset(EncodingOptionsPreset encodingOptionsPreset) {
            this.options_ = Integer.valueOf(encodingOptionsPreset.getNumber());
            this.optionsCase_ = 7;
        }

        private void setPresetValue(int i) {
            this.optionsCase_ = 7;
            this.options_ = Integer.valueOf(i);
        }

        private void setSegmentOutputs(int i, SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.set(i, segmentedFileOutput);
        }

        private void setSegments(SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            this.output_ = segmentedFileOutput;
            this.outputCase_ = 6;
        }

        private void setStream(StreamOutput streamOutput) {
            streamOutput.getClass();
            this.output_ = streamOutput;
            this.outputCase_ = 5;
        }

        private void setStreamOutputs(int i, StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.set(i, streamOutput);
        }

        private void setUrl(String str) {
            str.getClass();
            this.url_ = str;
        }

        private void setUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.url_ = byteString.L();
        }

        private void setVideoOnly(boolean z) {
            this.videoOnly_ = z;
        }

        private void setWebhooks(int i, LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.set(i, webhookConfig);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            AnonymousClass1 anonymousClass1 = null;
            switch (AnonymousClass1.a[methodToInvoke.ordinal()]) {
                case 1:
                    return new WebEgressRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u000e\u0002\u0000\u0001\u000e\u000e\u0000\u0005\u0000\u0001Ȉ\u0002\u0007\u0003\u0007\u0004<\u0000\u0005<\u0000\u0006<\u0000\u0007?\u0001\b<\u0001\t\u001b\n\u001b\u000b\u001b\f\u0007\r\u001b\u000e\u001b", new Object[]{"output_", "outputCase_", "options_", "optionsCase_", "url_", "audioOnly_", "videoOnly_", EncodedFileOutput.class, StreamOutput.class, SegmentedFileOutput.class, EncodingOptions.class, "fileOutputs_", EncodedFileOutput.class, "streamOutputs_", StreamOutput.class, "segmentOutputs_", SegmentedFileOutput.class, "awaitStartSignal_", "imageOutputs_", ImageOutput.class, "webhooks_", LivekitModels.WebhookConfig.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<WebEgressRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (WebEgressRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public EncodingOptions getAdvanced() {
            return this.optionsCase_ == 8 ? (EncodingOptions) this.options_ : EncodingOptions.getDefaultInstance();
        }

        public boolean getAudioOnly() {
            return this.audioOnly_;
        }

        public boolean getAwaitStartSignal() {
            return this.awaitStartSignal_;
        }

        @Deprecated
        public EncodedFileOutput getFile() {
            return this.outputCase_ == 4 ? (EncodedFileOutput) this.output_ : EncodedFileOutput.getDefaultInstance();
        }

        public EncodedFileOutput getFileOutputs(int i) {
            return (EncodedFileOutput) this.fileOutputs_.get(i);
        }

        public int getFileOutputsCount() {
            return this.fileOutputs_.size();
        }

        public List<EncodedFileOutput> getFileOutputsList() {
            return this.fileOutputs_;
        }

        public EncodedFileOutputOrBuilder getFileOutputsOrBuilder(int i) {
            return (EncodedFileOutputOrBuilder) this.fileOutputs_.get(i);
        }

        public List<? extends EncodedFileOutputOrBuilder> getFileOutputsOrBuilderList() {
            return this.fileOutputs_;
        }

        public ImageOutput getImageOutputs(int i) {
            return (ImageOutput) this.imageOutputs_.get(i);
        }

        public int getImageOutputsCount() {
            return this.imageOutputs_.size();
        }

        public List<ImageOutput> getImageOutputsList() {
            return this.imageOutputs_;
        }

        public ImageOutputOrBuilder getImageOutputsOrBuilder(int i) {
            return (ImageOutputOrBuilder) this.imageOutputs_.get(i);
        }

        public List<? extends ImageOutputOrBuilder> getImageOutputsOrBuilderList() {
            return this.imageOutputs_;
        }

        public OptionsCase getOptionsCase() {
            return OptionsCase.b(this.optionsCase_);
        }

        public OutputCase getOutputCase() {
            return OutputCase.b(this.outputCase_);
        }

        public EncodingOptionsPreset getPreset() {
            if (this.optionsCase_ != 7) {
                return EncodingOptionsPreset.b;
            }
            EncodingOptionsPreset encodingOptionsPresetB = EncodingOptionsPreset.b(((Integer) this.options_).intValue());
            return encodingOptionsPresetB == null ? EncodingOptionsPreset.j : encodingOptionsPresetB;
        }

        public int getPresetValue() {
            if (this.optionsCase_ == 7) {
                return ((Integer) this.options_).intValue();
            }
            return 0;
        }

        public SegmentedFileOutput getSegmentOutputs(int i) {
            return (SegmentedFileOutput) this.segmentOutputs_.get(i);
        }

        public int getSegmentOutputsCount() {
            return this.segmentOutputs_.size();
        }

        public List<SegmentedFileOutput> getSegmentOutputsList() {
            return this.segmentOutputs_;
        }

        public SegmentedFileOutputOrBuilder getSegmentOutputsOrBuilder(int i) {
            return (SegmentedFileOutputOrBuilder) this.segmentOutputs_.get(i);
        }

        public List<? extends SegmentedFileOutputOrBuilder> getSegmentOutputsOrBuilderList() {
            return this.segmentOutputs_;
        }

        @Deprecated
        public SegmentedFileOutput getSegments() {
            return this.outputCase_ == 6 ? (SegmentedFileOutput) this.output_ : SegmentedFileOutput.getDefaultInstance();
        }

        @Deprecated
        public StreamOutput getStream() {
            return this.outputCase_ == 5 ? (StreamOutput) this.output_ : StreamOutput.getDefaultInstance();
        }

        public StreamOutput getStreamOutputs(int i) {
            return (StreamOutput) this.streamOutputs_.get(i);
        }

        public int getStreamOutputsCount() {
            return this.streamOutputs_.size();
        }

        public List<StreamOutput> getStreamOutputsList() {
            return this.streamOutputs_;
        }

        public StreamOutputOrBuilder getStreamOutputsOrBuilder(int i) {
            return (StreamOutputOrBuilder) this.streamOutputs_.get(i);
        }

        public List<? extends StreamOutputOrBuilder> getStreamOutputsOrBuilderList() {
            return this.streamOutputs_;
        }

        public String getUrl() {
            return this.url_;
        }

        public ByteString getUrlBytes() {
            return ByteString.n(this.url_);
        }

        public boolean getVideoOnly() {
            return this.videoOnly_;
        }

        public LivekitModels.WebhookConfig getWebhooks(int i) {
            return (LivekitModels.WebhookConfig) this.webhooks_.get(i);
        }

        public int getWebhooksCount() {
            return this.webhooks_.size();
        }

        public List<LivekitModels.WebhookConfig> getWebhooksList() {
            return this.webhooks_;
        }

        public LivekitModels.WebhookConfigOrBuilder getWebhooksOrBuilder(int i) {
            return (LivekitModels.WebhookConfigOrBuilder) this.webhooks_.get(i);
        }

        public List<? extends LivekitModels.WebhookConfigOrBuilder> getWebhooksOrBuilderList() {
            return this.webhooks_;
        }

        public boolean hasAdvanced() {
            return this.optionsCase_ == 8;
        }

        @Deprecated
        public boolean hasFile() {
            return this.outputCase_ == 4;
        }

        public boolean hasPreset() {
            return this.optionsCase_ == 7;
        }

        @Deprecated
        public boolean hasSegments() {
            return this.outputCase_ == 6;
        }

        @Deprecated
        public boolean hasStream() {
            return this.outputCase_ == 5;
        }

        public static Builder newBuilder(WebEgressRequest webEgressRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(webEgressRequest);
        }

        public static WebEgressRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebEgressRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WebEgressRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (WebEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static WebEgressRequest parseFrom(ByteString byteString) {
            return (WebEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addFileOutputs(int i, EncodedFileOutput encodedFileOutput) {
            encodedFileOutput.getClass();
            ensureFileOutputsIsMutable();
            this.fileOutputs_.add(i, encodedFileOutput);
        }

        private void addImageOutputs(int i, ImageOutput imageOutput) {
            imageOutput.getClass();
            ensureImageOutputsIsMutable();
            this.imageOutputs_.add(i, imageOutput);
        }

        private void addSegmentOutputs(int i, SegmentedFileOutput segmentedFileOutput) {
            segmentedFileOutput.getClass();
            ensureSegmentOutputsIsMutable();
            this.segmentOutputs_.add(i, segmentedFileOutput);
        }

        private void addStreamOutputs(int i, StreamOutput streamOutput) {
            streamOutput.getClass();
            ensureStreamOutputsIsMutable();
            this.streamOutputs_.add(i, streamOutput);
        }

        private void addWebhooks(int i, LivekitModels.WebhookConfig webhookConfig) {
            webhookConfig.getClass();
            ensureWebhooksIsMutable();
            this.webhooks_.add(i, webhookConfig);
        }

        public static WebEgressRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (WebEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static WebEgressRequest parseFrom(byte[] bArr) {
            return (WebEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static WebEgressRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (WebEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static WebEgressRequest parseFrom(InputStream inputStream) {
            return (WebEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WebEgressRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WebEgressRequest parseFrom(CodedInputStream codedInputStream) {
            return (WebEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static WebEgressRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebEgressRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface WebEgressRequestOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitEgress() {
    }
}