package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import livekit.LivekitEgress;
import livekit.LivekitIngress;
import livekit.LivekitModels;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitWebhook {

    /* JADX INFO: renamed from: livekit.LivekitWebhook$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class WebhookEvent extends GeneratedMessageLite<WebhookEvent, Builder> implements WebhookEventOrBuilder {
        public static final int CREATED_AT_FIELD_NUMBER = 7;
        private static final WebhookEvent DEFAULT_INSTANCE;
        public static final int EGRESS_INFO_FIELD_NUMBER = 9;
        public static final int EVENT_FIELD_NUMBER = 1;
        public static final int ID_FIELD_NUMBER = 6;
        public static final int INGRESS_INFO_FIELD_NUMBER = 10;
        public static final int NUM_DROPPED_FIELD_NUMBER = 11;
        private static volatile Parser<WebhookEvent> PARSER = null;
        public static final int PARTICIPANT_FIELD_NUMBER = 3;
        public static final int ROOM_FIELD_NUMBER = 2;
        public static final int TRACK_FIELD_NUMBER = 8;
        private long createdAt_;
        private LivekitEgress.EgressInfo egressInfo_;
        private String event_;
        private String id_;
        private LivekitIngress.IngressInfo ingressInfo_;
        private int numDropped_;
        private LivekitModels.ParticipantInfo participant_;
        private LivekitModels.Room room_;
        private LivekitModels.TrackInfo track_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<WebhookEvent, Builder> implements WebhookEventOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(WebhookEvent.DEFAULT_INSTANCE);
            }
        }

        static {
            WebhookEvent webhookEvent = new WebhookEvent();
            DEFAULT_INSTANCE = webhookEvent;
            GeneratedMessageLite.registerDefaultInstance(WebhookEvent.class, webhookEvent);
        }

        private WebhookEvent() {
            String strA = ap.a(508776710);
            this.event_ = strA;
            this.id_ = strA;
        }

        private void clearCreatedAt() {
            this.createdAt_ = 0L;
        }

        private void clearEgressInfo() {
            this.egressInfo_ = null;
        }

        private void clearEvent() {
            this.event_ = getDefaultInstance().getEvent();
        }

        private void clearId() {
            this.id_ = getDefaultInstance().getId();
        }

        private void clearIngressInfo() {
            this.ingressInfo_ = null;
        }

        private void clearNumDropped() {
            this.numDropped_ = 0;
        }

        private void clearParticipant() {
            this.participant_ = null;
        }

        private void clearRoom() {
            this.room_ = null;
        }

        private void clearTrack() {
            this.track_ = null;
        }

        public static WebhookEvent getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeEgressInfo(LivekitEgress.EgressInfo egressInfo) {
            egressInfo.getClass();
            LivekitEgress.EgressInfo egressInfo2 = this.egressInfo_;
            if (egressInfo2 == null || egressInfo2 == LivekitEgress.EgressInfo.getDefaultInstance()) {
                this.egressInfo_ = egressInfo;
            } else {
                this.egressInfo_ = (LivekitEgress.EgressInfo) ((LivekitEgress.EgressInfo.Builder) LivekitEgress.EgressInfo.newBuilder(this.egressInfo_).v(egressInfo)).o();
            }
        }

        private void mergeIngressInfo(LivekitIngress.IngressInfo ingressInfo) {
            ingressInfo.getClass();
            LivekitIngress.IngressInfo ingressInfo2 = this.ingressInfo_;
            if (ingressInfo2 == null || ingressInfo2 == LivekitIngress.IngressInfo.getDefaultInstance()) {
                this.ingressInfo_ = ingressInfo;
            } else {
                this.ingressInfo_ = (LivekitIngress.IngressInfo) ((LivekitIngress.IngressInfo.Builder) LivekitIngress.IngressInfo.newBuilder(this.ingressInfo_).v(ingressInfo)).o();
            }
        }

        private void mergeParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            LivekitModels.ParticipantInfo participantInfo2 = this.participant_;
            if (participantInfo2 == null || participantInfo2 == LivekitModels.ParticipantInfo.getDefaultInstance()) {
                this.participant_ = participantInfo;
            } else {
                this.participant_ = (LivekitModels.ParticipantInfo) ((LivekitModels.ParticipantInfo.Builder) LivekitModels.ParticipantInfo.newBuilder(this.participant_).v(participantInfo)).o();
            }
        }

        private void mergeRoom(LivekitModels.Room room) {
            room.getClass();
            LivekitModels.Room room2 = this.room_;
            if (room2 == null || room2 == LivekitModels.Room.getDefaultInstance()) {
                this.room_ = room;
            } else {
                this.room_ = (LivekitModels.Room) ((LivekitModels.Room.Builder) LivekitModels.Room.newBuilder(this.room_).v(room)).o();
            }
        }

        private void mergeTrack(LivekitModels.TrackInfo trackInfo) {
            trackInfo.getClass();
            LivekitModels.TrackInfo trackInfo2 = this.track_;
            if (trackInfo2 == null || trackInfo2 == LivekitModels.TrackInfo.getDefaultInstance()) {
                this.track_ = trackInfo;
            } else {
                this.track_ = (LivekitModels.TrackInfo) ((LivekitModels.TrackInfo.Builder) LivekitModels.TrackInfo.newBuilder(this.track_).v(trackInfo)).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static WebhookEvent parseDelimitedFrom(InputStream inputStream) {
            return (WebhookEvent) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WebhookEvent parseFrom(ByteBuffer byteBuffer) {
            return (WebhookEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<WebhookEvent> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCreatedAt(long j) {
            this.createdAt_ = j;
        }

        private void setEgressInfo(LivekitEgress.EgressInfo egressInfo) {
            egressInfo.getClass();
            this.egressInfo_ = egressInfo;
        }

        private void setEvent(String str) {
            str.getClass();
            this.event_ = str;
        }

        private void setEventBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.event_ = byteString.L();
        }

        private void setId(String str) {
            str.getClass();
            this.id_ = str;
        }

        private void setIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.id_ = byteString.L();
        }

        private void setIngressInfo(LivekitIngress.IngressInfo ingressInfo) {
            ingressInfo.getClass();
            this.ingressInfo_ = ingressInfo;
        }

        private void setNumDropped(int i) {
            this.numDropped_ = i;
        }

        private void setParticipant(LivekitModels.ParticipantInfo participantInfo) {
            participantInfo.getClass();
            this.participant_ = participantInfo;
        }

        private void setRoom(LivekitModels.Room room) {
            room.getClass();
            this.room_ = room;
        }

        private void setTrack(LivekitModels.TrackInfo trackInfo) {
            trackInfo.getClass();
            this.track_ = trackInfo;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new WebhookEvent();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\t\u0000\u0000\u0001\u000b\t\u0000\u0000\u0000\u0001Ȉ\u0002\t\u0003\t\u0006Ȉ\u0007\u0002\b\t\t\t\n\t\u000b\u0004", new Object[]{"event_", "room_", "participant_", "id_", "createdAt_", "track_", "egressInfo_", "ingressInfo_", "numDropped_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<WebhookEvent> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (WebhookEvent.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public long getCreatedAt() {
            return this.createdAt_;
        }

        public LivekitEgress.EgressInfo getEgressInfo() {
            LivekitEgress.EgressInfo egressInfo = this.egressInfo_;
            return egressInfo == null ? LivekitEgress.EgressInfo.getDefaultInstance() : egressInfo;
        }

        public String getEvent() {
            return this.event_;
        }

        public ByteString getEventBytes() {
            return ByteString.n(this.event_);
        }

        public String getId() {
            return this.id_;
        }

        public ByteString getIdBytes() {
            return ByteString.n(this.id_);
        }

        public LivekitIngress.IngressInfo getIngressInfo() {
            LivekitIngress.IngressInfo ingressInfo = this.ingressInfo_;
            return ingressInfo == null ? LivekitIngress.IngressInfo.getDefaultInstance() : ingressInfo;
        }

        @Deprecated
        public int getNumDropped() {
            return this.numDropped_;
        }

        public LivekitModels.ParticipantInfo getParticipant() {
            LivekitModels.ParticipantInfo participantInfo = this.participant_;
            return participantInfo == null ? LivekitModels.ParticipantInfo.getDefaultInstance() : participantInfo;
        }

        public LivekitModels.Room getRoom() {
            LivekitModels.Room room = this.room_;
            return room == null ? LivekitModels.Room.getDefaultInstance() : room;
        }

        public LivekitModels.TrackInfo getTrack() {
            LivekitModels.TrackInfo trackInfo = this.track_;
            return trackInfo == null ? LivekitModels.TrackInfo.getDefaultInstance() : trackInfo;
        }

        public boolean hasEgressInfo() {
            return this.egressInfo_ != null;
        }

        public boolean hasIngressInfo() {
            return this.ingressInfo_ != null;
        }

        public boolean hasParticipant() {
            return this.participant_ != null;
        }

        public boolean hasRoom() {
            return this.room_ != null;
        }

        public boolean hasTrack() {
            return this.track_ != null;
        }

        public static Builder newBuilder(WebhookEvent webhookEvent) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(webhookEvent);
        }

        public static WebhookEvent parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookEvent) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WebhookEvent parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static WebhookEvent parseFrom(ByteString byteString) {
            return (WebhookEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static WebhookEvent parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static WebhookEvent parseFrom(byte[] bArr) {
            return (WebhookEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static WebhookEvent parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static WebhookEvent parseFrom(InputStream inputStream) {
            return (WebhookEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static WebhookEvent parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static WebhookEvent parseFrom(CodedInputStream codedInputStream) {
            return (WebhookEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static WebhookEvent parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (WebhookEvent) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface WebhookEventOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitWebhook() {
    }
}