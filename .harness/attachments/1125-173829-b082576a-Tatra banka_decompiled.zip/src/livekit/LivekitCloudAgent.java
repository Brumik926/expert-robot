package livekit;

import com.google.protobuf.AbstractMessageLite;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageLite;
import com.google.protobuf.Internal;
import com.google.protobuf.MapEntryLite;
import com.google.protobuf.MapFieldLite;
import com.google.protobuf.MessageLiteOrBuilder;
import com.google.protobuf.Parser;
import com.google.protobuf.Timestamp;
import com.google.protobuf.WireFormat;
import h.ap;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class LivekitCloudAgent {

    /* JADX INFO: renamed from: livekit.LivekitCloudAgent$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[GeneratedMessageLite.MethodToInvoke.values().length];
            a = iArr;
            try {
                iArr[GeneratedMessageLite.MethodToInvoke.d.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.e.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.c.ordinal()] = 3;
            } catch (NoSuchFieldError unused3) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.f.ordinal()] = 4;
            } catch (NoSuchFieldError unused4) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.g.ordinal()] = 5;
            } catch (NoSuchFieldError unused5) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.a.ordinal()] = 6;
            } catch (NoSuchFieldError unused6) {
            }
            try {
                a[GeneratedMessageLite.MethodToInvoke.b.ordinal()] = 7;
            } catch (NoSuchFieldError unused7) {
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AgentDeployment extends GeneratedMessageLite<AgentDeployment, Builder> implements AgentDeploymentOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 2;
        public static final int CPU_LIMIT_FIELD_NUMBER = 12;
        public static final int CPU_REQ_FIELD_NUMBER = 7;
        public static final int CUR_CPU_FIELD_NUMBER = 8;
        public static final int CUR_MEM_FIELD_NUMBER = 9;
        private static final AgentDeployment DEFAULT_INSTANCE;
        public static final int MAX_REPLICAS_FIELD_NUMBER = 6;
        public static final int MEM_LIMIT_FIELD_NUMBER = 11;
        public static final int MEM_REQ_FIELD_NUMBER = 10;
        public static final int MIN_REPLICAS_FIELD_NUMBER = 5;
        private static volatile Parser<AgentDeployment> PARSER = null;
        public static final int REGION_FIELD_NUMBER = 1;
        public static final int REPLICAS_FIELD_NUMBER = 4;
        public static final int STATUS_FIELD_NUMBER = 3;
        private String agentId_;
        private String cpuLimit_;
        private String cpuReq_;
        private String curCpu_;
        private String curMem_;
        private int maxReplicas_;
        private String memLimit_;
        private String memReq_;
        private int minReplicas_;
        private String region_;
        private int replicas_;
        private String status_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AgentDeployment, Builder> implements AgentDeploymentOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AgentDeployment.DEFAULT_INSTANCE);
            }
        }

        static {
            AgentDeployment agentDeployment = new AgentDeployment();
            DEFAULT_INSTANCE = agentDeployment;
            GeneratedMessageLite.registerDefaultInstance(AgentDeployment.class, agentDeployment);
        }

        private AgentDeployment() {
            String strA = ap.a(765909394);
            this.region_ = strA;
            this.agentId_ = strA;
            this.status_ = strA;
            this.cpuReq_ = strA;
            this.curCpu_ = strA;
            this.curMem_ = strA;
            this.memReq_ = strA;
            this.memLimit_ = strA;
            this.cpuLimit_ = strA;
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearCpuLimit() {
            this.cpuLimit_ = getDefaultInstance().getCpuLimit();
        }

        private void clearCpuReq() {
            this.cpuReq_ = getDefaultInstance().getCpuReq();
        }

        private void clearCurCpu() {
            this.curCpu_ = getDefaultInstance().getCurCpu();
        }

        private void clearCurMem() {
            this.curMem_ = getDefaultInstance().getCurMem();
        }

        private void clearMaxReplicas() {
            this.maxReplicas_ = 0;
        }

        private void clearMemLimit() {
            this.memLimit_ = getDefaultInstance().getMemLimit();
        }

        private void clearMemReq() {
            this.memReq_ = getDefaultInstance().getMemReq();
        }

        private void clearMinReplicas() {
            this.minReplicas_ = 0;
        }

        private void clearRegion() {
            this.region_ = getDefaultInstance().getRegion();
        }

        private void clearReplicas() {
            this.replicas_ = 0;
        }

        private void clearStatus() {
            this.status_ = getDefaultInstance().getStatus();
        }

        public static AgentDeployment getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AgentDeployment parseDelimitedFrom(InputStream inputStream) {
            return (AgentDeployment) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentDeployment parseFrom(ByteBuffer byteBuffer) {
            return (AgentDeployment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AgentDeployment> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setCpuLimit(String str) {
            str.getClass();
            this.cpuLimit_ = str;
        }

        private void setCpuLimitBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.cpuLimit_ = byteString.L();
        }

        private void setCpuReq(String str) {
            str.getClass();
            this.cpuReq_ = str;
        }

        private void setCpuReqBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.cpuReq_ = byteString.L();
        }

        private void setCurCpu(String str) {
            str.getClass();
            this.curCpu_ = str;
        }

        private void setCurCpuBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.curCpu_ = byteString.L();
        }

        private void setCurMem(String str) {
            str.getClass();
            this.curMem_ = str;
        }

        private void setCurMemBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.curMem_ = byteString.L();
        }

        private void setMaxReplicas(int i) {
            this.maxReplicas_ = i;
        }

        private void setMemLimit(String str) {
            str.getClass();
            this.memLimit_ = str;
        }

        private void setMemLimitBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.memLimit_ = byteString.L();
        }

        private void setMemReq(String str) {
            str.getClass();
            this.memReq_ = str;
        }

        private void setMemReqBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.memReq_ = byteString.L();
        }

        private void setMinReplicas(int i) {
            this.minReplicas_ = i;
        }

        private void setRegion(String str) {
            str.getClass();
            this.region_ = str;
        }

        private void setRegionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.region_ = byteString.L();
        }

        private void setReplicas(int i) {
            this.replicas_ = i;
        }

        private void setStatus(String str) {
            str.getClass();
            this.status_ = str;
        }

        private void setStatusBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.status_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AgentDeployment();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\f\u0000\u0000\u0001\f\f\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\u0004\u0005\u0004\u0006\u0004\u0007Ȉ\bȈ\tȈ\nȈ\u000bȈ\fȈ", new Object[]{"region_", "agentId_", "status_", "replicas_", "minReplicas_", "maxReplicas_", "cpuReq_", "curCpu_", "curMem_", "memReq_", "memLimit_", "cpuLimit_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AgentDeployment> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AgentDeployment.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public String getCpuLimit() {
            return this.cpuLimit_;
        }

        public ByteString getCpuLimitBytes() {
            return ByteString.n(this.cpuLimit_);
        }

        public String getCpuReq() {
            return this.cpuReq_;
        }

        public ByteString getCpuReqBytes() {
            return ByteString.n(this.cpuReq_);
        }

        public String getCurCpu() {
            return this.curCpu_;
        }

        public ByteString getCurCpuBytes() {
            return ByteString.n(this.curCpu_);
        }

        public String getCurMem() {
            return this.curMem_;
        }

        public ByteString getCurMemBytes() {
            return ByteString.n(this.curMem_);
        }

        public int getMaxReplicas() {
            return this.maxReplicas_;
        }

        public String getMemLimit() {
            return this.memLimit_;
        }

        public ByteString getMemLimitBytes() {
            return ByteString.n(this.memLimit_);
        }

        public String getMemReq() {
            return this.memReq_;
        }

        public ByteString getMemReqBytes() {
            return ByteString.n(this.memReq_);
        }

        public int getMinReplicas() {
            return this.minReplicas_;
        }

        public String getRegion() {
            return this.region_;
        }

        public ByteString getRegionBytes() {
            return ByteString.n(this.region_);
        }

        public int getReplicas() {
            return this.replicas_;
        }

        public String getStatus() {
            return this.status_;
        }

        public ByteString getStatusBytes() {
            return ByteString.n(this.status_);
        }

        public static Builder newBuilder(AgentDeployment agentDeployment) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(agentDeployment);
        }

        public static AgentDeployment parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDeployment) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentDeployment parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDeployment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AgentDeployment parseFrom(ByteString byteString) {
            return (AgentDeployment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AgentDeployment parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDeployment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AgentDeployment parseFrom(byte[] bArr) {
            return (AgentDeployment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AgentDeployment parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDeployment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AgentDeployment parseFrom(InputStream inputStream) {
            return (AgentDeployment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentDeployment parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDeployment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentDeployment parseFrom(CodedInputStream codedInputStream) {
            return (AgentDeployment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AgentDeployment parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentDeployment) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AgentDeploymentOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AgentInfo extends GeneratedMessageLite<AgentInfo, Builder> implements AgentInfoOrBuilder {
        public static final int AGENT_DEPLOYMENTS_FIELD_NUMBER = 4;
        public static final int AGENT_ID_FIELD_NUMBER = 1;
        public static final int AGENT_NAME_FIELD_NUMBER = 2;
        private static final AgentInfo DEFAULT_INSTANCE;
        public static final int DEPLOYED_AT_FIELD_NUMBER = 6;
        private static volatile Parser<AgentInfo> PARSER = null;
        public static final int SECRETS_FIELD_NUMBER = 5;
        public static final int VERSION_FIELD_NUMBER = 3;
        private Internal.ProtobufList<AgentDeployment> agentDeployments_;
        private String agentId_;
        private String agentName_;
        private Timestamp deployedAt_;
        private Internal.ProtobufList<AgentSecret> secrets_;
        private String version_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AgentInfo, Builder> implements AgentInfoOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AgentInfo.DEFAULT_INSTANCE);
            }
        }

        static {
            AgentInfo agentInfo = new AgentInfo();
            DEFAULT_INSTANCE = agentInfo;
            GeneratedMessageLite.registerDefaultInstance(AgentInfo.class, agentInfo);
        }

        private AgentInfo() {
            String strA = ap.a(2050843810);
            this.agentId_ = strA;
            this.agentName_ = strA;
            this.version_ = strA;
            this.agentDeployments_ = GeneratedMessageLite.emptyProtobufList();
            this.secrets_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAgentDeployments(AgentDeployment agentDeployment) {
            agentDeployment.getClass();
            ensureAgentDeploymentsIsMutable();
            this.agentDeployments_.add(agentDeployment);
        }

        private void addAllAgentDeployments(Iterable<? extends AgentDeployment> iterable) {
            ensureAgentDeploymentsIsMutable();
            AbstractMessageLite.addAll(iterable, this.agentDeployments_);
        }

        private void addAllSecrets(Iterable<? extends AgentSecret> iterable) {
            ensureSecretsIsMutable();
            AbstractMessageLite.addAll(iterable, this.secrets_);
        }

        private void addSecrets(AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(agentSecret);
        }

        private void clearAgentDeployments() {
            this.agentDeployments_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearDeployedAt() {
            this.deployedAt_ = null;
        }

        private void clearSecrets() {
            this.secrets_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearVersion() {
            this.version_ = getDefaultInstance().getVersion();
        }

        private void ensureAgentDeploymentsIsMutable() {
            Internal.ProtobufList<AgentDeployment> protobufList = this.agentDeployments_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.agentDeployments_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSecretsIsMutable() {
            Internal.ProtobufList<AgentSecret> protobufList = this.secrets_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.secrets_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static AgentInfo getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeDeployedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.deployedAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.deployedAt_ = timestamp;
            } else {
                this.deployedAt_ = Timestamp.newBuilder(this.deployedAt_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AgentInfo parseDelimitedFrom(InputStream inputStream) {
            return (AgentInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentInfo parseFrom(ByteBuffer byteBuffer) {
            return (AgentInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AgentInfo> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeAgentDeployments(int i) {
            ensureAgentDeploymentsIsMutable();
            this.agentDeployments_.remove(i);
        }

        private void removeSecrets(int i) {
            ensureSecretsIsMutable();
            this.secrets_.remove(i);
        }

        private void setAgentDeployments(int i, AgentDeployment agentDeployment) {
            agentDeployment.getClass();
            ensureAgentDeploymentsIsMutable();
            this.agentDeployments_.set(i, agentDeployment);
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setDeployedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.deployedAt_ = timestamp;
        }

        private void setSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.set(i, agentSecret);
        }

        private void setVersion(String str) {
            str.getClass();
            this.version_ = str;
        }

        private void setVersionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.version_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AgentInfo();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0002\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004\u001b\u0005\u001b\u0006\t", new Object[]{"agentId_", "agentName_", "version_", "agentDeployments_", AgentDeployment.class, "secrets_", AgentSecret.class, "deployedAt_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AgentInfo> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AgentInfo.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AgentDeployment getAgentDeployments(int i) {
            return (AgentDeployment) this.agentDeployments_.get(i);
        }

        public int getAgentDeploymentsCount() {
            return this.agentDeployments_.size();
        }

        public List<AgentDeployment> getAgentDeploymentsList() {
            return this.agentDeployments_;
        }

        public AgentDeploymentOrBuilder getAgentDeploymentsOrBuilder(int i) {
            return (AgentDeploymentOrBuilder) this.agentDeployments_.get(i);
        }

        public List<? extends AgentDeploymentOrBuilder> getAgentDeploymentsOrBuilderList() {
            return this.agentDeployments_;
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public Timestamp getDeployedAt() {
            Timestamp timestamp = this.deployedAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public AgentSecret getSecrets(int i) {
            return (AgentSecret) this.secrets_.get(i);
        }

        public int getSecretsCount() {
            return this.secrets_.size();
        }

        public List<AgentSecret> getSecretsList() {
            return this.secrets_;
        }

        public AgentSecretOrBuilder getSecretsOrBuilder(int i) {
            return (AgentSecretOrBuilder) this.secrets_.get(i);
        }

        public List<? extends AgentSecretOrBuilder> getSecretsOrBuilderList() {
            return this.secrets_;
        }

        public String getVersion() {
            return this.version_;
        }

        public ByteString getVersionBytes() {
            return ByteString.n(this.version_);
        }

        public boolean hasDeployedAt() {
            return this.deployedAt_ != null;
        }

        public static Builder newBuilder(AgentInfo agentInfo) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(agentInfo);
        }

        public static AgentInfo parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentInfo) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentInfo parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AgentInfo parseFrom(ByteString byteString) {
            return (AgentInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addAgentDeployments(int i, AgentDeployment agentDeployment) {
            agentDeployment.getClass();
            ensureAgentDeploymentsIsMutable();
            this.agentDeployments_.add(i, agentDeployment);
        }

        private void addSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(i, agentSecret);
        }

        public static AgentInfo parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AgentInfo parseFrom(byte[] bArr) {
            return (AgentInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AgentInfo parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AgentInfo parseFrom(InputStream inputStream) {
            return (AgentInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentInfo parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentInfo parseFrom(CodedInputStream codedInputStream) {
            return (AgentInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AgentInfo parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentInfo) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AgentInfoOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AgentSecret extends GeneratedMessageLite<AgentSecret, Builder> implements AgentSecretOrBuilder {
        public static final int CREATED_AT_FIELD_NUMBER = 3;
        private static final AgentSecret DEFAULT_INSTANCE;
        public static final int KIND_FIELD_NUMBER = 5;
        public static final int NAME_FIELD_NUMBER = 1;
        private static volatile Parser<AgentSecret> PARSER = null;
        public static final int UPDATED_AT_FIELD_NUMBER = 4;
        public static final int VALUE_FIELD_NUMBER = 2;
        private Timestamp createdAt_;
        private int kind_;
        private Timestamp updatedAt_;
        private String name_ = ap.a(786835733);
        private ByteString value_ = ByteString.b;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AgentSecret, Builder> implements AgentSecretOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AgentSecret.DEFAULT_INSTANCE);
            }
        }

        static {
            AgentSecret agentSecret = new AgentSecret();
            DEFAULT_INSTANCE = agentSecret;
            GeneratedMessageLite.registerDefaultInstance(AgentSecret.class, agentSecret);
        }

        private AgentSecret() {
        }

        private void clearCreatedAt() {
            this.createdAt_ = null;
        }

        private void clearKind() {
            this.kind_ = 0;
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearUpdatedAt() {
            this.updatedAt_ = null;
        }

        private void clearValue() {
            this.value_ = getDefaultInstance().getValue();
        }

        public static AgentSecret getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private void mergeCreatedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.createdAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.createdAt_ = timestamp;
            } else {
                this.createdAt_ = Timestamp.newBuilder(this.createdAt_).v(timestamp).o();
            }
        }

        private void mergeUpdatedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.updatedAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.updatedAt_ = timestamp;
            } else {
                this.updatedAt_ = Timestamp.newBuilder(this.updatedAt_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AgentSecret parseDelimitedFrom(InputStream inputStream) {
            return (AgentSecret) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentSecret parseFrom(ByteBuffer byteBuffer) {
            return (AgentSecret) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AgentSecret> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCreatedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.createdAt_ = timestamp;
        }

        private void setKind(AgentSecretKind agentSecretKind) {
            this.kind_ = agentSecretKind.getNumber();
        }

        private void setKindValue(int i) {
            this.kind_ = i;
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setUpdatedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.updatedAt_ = timestamp;
        }

        private void setValue(ByteString byteString) {
            byteString.getClass();
            this.value_ = byteString;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AgentSecret();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001Ȉ\u0002\n\u0003\t\u0004\t\u0005\f", new Object[]{"name_", "value_", "createdAt_", "updatedAt_", "kind_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AgentSecret> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AgentSecret.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public Timestamp getCreatedAt() {
            Timestamp timestamp = this.createdAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public AgentSecretKind getKind() {
            AgentSecretKind agentSecretKindB = AgentSecretKind.b(this.kind_);
            return agentSecretKindB == null ? AgentSecretKind.e : agentSecretKindB;
        }

        public int getKindValue() {
            return this.kind_;
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public Timestamp getUpdatedAt() {
            Timestamp timestamp = this.updatedAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public ByteString getValue() {
            return this.value_;
        }

        public boolean hasCreatedAt() {
            return this.createdAt_ != null;
        }

        public boolean hasUpdatedAt() {
            return this.updatedAt_ != null;
        }

        public static Builder newBuilder(AgentSecret agentSecret) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(agentSecret);
        }

        public static AgentSecret parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentSecret) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentSecret parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentSecret) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AgentSecret parseFrom(ByteString byteString) {
            return (AgentSecret) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AgentSecret parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentSecret) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AgentSecret parseFrom(byte[] bArr) {
            return (AgentSecret) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AgentSecret parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentSecret) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AgentSecret parseFrom(InputStream inputStream) {
            return (AgentSecret) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentSecret parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentSecret) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentSecret parseFrom(CodedInputStream codedInputStream) {
            return (AgentSecret) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AgentSecret parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentSecret) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public enum AgentSecretKind implements Internal.EnumLite {
        b(0),
        c(1),
        d(2),
        e(-1);

        private static final Internal.EnumLiteMap f = new Internal.EnumLiteMap<AgentSecretKind>() { // from class: livekit.LivekitCloudAgent.AgentSecretKind.1
            /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
            public AgentSecretKind findValueByNumber(int i) {
                return AgentSecretKind.b(i);
            }
        };
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AgentSecretKindVerifier implements Internal.EnumVerifier {
            static final Internal.EnumVerifier a = new AgentSecretKindVerifier();

            private AgentSecretKindVerifier() {
            }

            public boolean isInRange(int i) {
                return AgentSecretKind.b(i) != null;
            }
        }

        AgentSecretKind(int i) {
            this.a = i;
        }

        public static AgentSecretKind b(int i) {
            if (i == 0) {
                return b;
            }
            if (i == 1) {
                return c;
            }
            if (i != 2) {
                return null;
            }
            return d;
        }

        public final int getNumber() {
            if (this != e) {
                return this.a;
            }
            throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AgentSecretOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class AgentVersion extends GeneratedMessageLite<AgentVersion, Builder> implements AgentVersionOrBuilder {
        public static final int ATTRIBUTES_FIELD_NUMBER = 5;
        public static final int CREATED_AT_FIELD_NUMBER = 3;
        public static final int CURRENT_FIELD_NUMBER = 2;
        private static final AgentVersion DEFAULT_INSTANCE;
        public static final int DEPLOYED_AT_FIELD_NUMBER = 4;
        private static volatile Parser<AgentVersion> PARSER = null;
        public static final int VERSION_FIELD_NUMBER = 1;
        private Timestamp createdAt_;
        private boolean current_;
        private Timestamp deployedAt_;
        private MapFieldLite<String, String> attributes_ = MapFieldLite.f();
        private String version_ = ap.a(1065076856);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        private static final class AttributesDefaultEntryHolder {
            static final MapEntryLite a;

            static {
                WireFormat.FieldType fieldType = WireFormat.FieldType.k;
                String strA = ap.a(55490917);
                a = MapEntryLite.d(fieldType, strA, fieldType, strA);
            }

            private AttributesDefaultEntryHolder() {
            }
        }

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<AgentVersion, Builder> implements AgentVersionOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(AgentVersion.DEFAULT_INSTANCE);
            }
        }

        static {
            AgentVersion agentVersion = new AgentVersion();
            DEFAULT_INSTANCE = agentVersion;
            GeneratedMessageLite.registerDefaultInstance(AgentVersion.class, agentVersion);
        }

        private AgentVersion() {
        }

        private void clearCreatedAt() {
            this.createdAt_ = null;
        }

        private void clearCurrent() {
            this.current_ = false;
        }

        private void clearDeployedAt() {
            this.deployedAt_ = null;
        }

        private void clearVersion() {
            this.version_ = getDefaultInstance().getVersion();
        }

        public static AgentVersion getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        private Map<String, String> getMutableAttributesMap() {
            return internalGetMutableAttributes();
        }

        private MapFieldLite<String, String> internalGetAttributes() {
            return this.attributes_;
        }

        private MapFieldLite<String, String> internalGetMutableAttributes() {
            if (!this.attributes_.k()) {
                this.attributes_ = this.attributes_.n();
            }
            return this.attributes_;
        }

        private void mergeCreatedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.createdAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.createdAt_ = timestamp;
            } else {
                this.createdAt_ = Timestamp.newBuilder(this.createdAt_).v(timestamp).o();
            }
        }

        private void mergeDeployedAt(Timestamp timestamp) {
            timestamp.getClass();
            Timestamp timestamp2 = this.deployedAt_;
            if (timestamp2 == null || timestamp2 == Timestamp.getDefaultInstance()) {
                this.deployedAt_ = timestamp;
            } else {
                this.deployedAt_ = Timestamp.newBuilder(this.deployedAt_).v(timestamp).o();
            }
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static AgentVersion parseDelimitedFrom(InputStream inputStream) {
            return (AgentVersion) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentVersion parseFrom(ByteBuffer byteBuffer) {
            return (AgentVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<AgentVersion> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setCreatedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.createdAt_ = timestamp;
        }

        private void setCurrent(boolean z) {
            this.current_ = z;
        }

        private void setDeployedAt(Timestamp timestamp) {
            timestamp.getClass();
            this.deployedAt_ = timestamp;
        }

        private void setVersion(String str) {
            str.getClass();
            this.version_ = str;
        }

        private void setVersionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.version_ = byteString.L();
        }

        public boolean containsAttributes(String str) {
            str.getClass();
            return internalGetAttributes().containsKey(str);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new AgentVersion();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0001\u0000\u0000\u0001Ȉ\u0002\u0007\u0003\t\u0004\t\u00052", new Object[]{"version_", "current_", "createdAt_", "deployedAt_", "attributes_", AttributesDefaultEntryHolder.a});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<AgentVersion> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (AgentVersion.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public Map<String, String> getAttributes() {
            return getAttributesMap();
        }

        public int getAttributesCount() {
            return internalGetAttributes().size();
        }

        public Map<String, String> getAttributesMap() {
            return Collections.unmodifiableMap(internalGetAttributes());
        }

        public String getAttributesOrDefault(String str, String str2) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            return mapFieldLiteInternalGetAttributes.containsKey(str) ? (String) mapFieldLiteInternalGetAttributes.get(str) : str2;
        }

        public String getAttributesOrThrow(String str) {
            str.getClass();
            MapFieldLite<String, String> mapFieldLiteInternalGetAttributes = internalGetAttributes();
            if (mapFieldLiteInternalGetAttributes.containsKey(str)) {
                return (String) mapFieldLiteInternalGetAttributes.get(str);
            }
            throw new IllegalArgumentException();
        }

        public Timestamp getCreatedAt() {
            Timestamp timestamp = this.createdAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public boolean getCurrent() {
            return this.current_;
        }

        public Timestamp getDeployedAt() {
            Timestamp timestamp = this.deployedAt_;
            return timestamp == null ? Timestamp.getDefaultInstance() : timestamp;
        }

        public String getVersion() {
            return this.version_;
        }

        public ByteString getVersionBytes() {
            return ByteString.n(this.version_);
        }

        public boolean hasCreatedAt() {
            return this.createdAt_ != null;
        }

        public boolean hasDeployedAt() {
            return this.deployedAt_ != null;
        }

        public static Builder newBuilder(AgentVersion agentVersion) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(agentVersion);
        }

        public static AgentVersion parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentVersion) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentVersion parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static AgentVersion parseFrom(ByteString byteString) {
            return (AgentVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static AgentVersion parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static AgentVersion parseFrom(byte[] bArr) {
            return (AgentVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static AgentVersion parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static AgentVersion parseFrom(InputStream inputStream) {
            return (AgentVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static AgentVersion parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static AgentVersion parseFrom(CodedInputStream codedInputStream) {
            return (AgentVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static AgentVersion parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (AgentVersion) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface AgentVersionOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ClientSettingsRequest extends GeneratedMessageLite<ClientSettingsRequest, Builder> implements ClientSettingsRequestOrBuilder {
        private static final ClientSettingsRequest DEFAULT_INSTANCE;
        private static volatile Parser<ClientSettingsRequest> PARSER;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ClientSettingsRequest, Builder> implements ClientSettingsRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ClientSettingsRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ClientSettingsRequest clientSettingsRequest = new ClientSettingsRequest();
            DEFAULT_INSTANCE = clientSettingsRequest;
            GeneratedMessageLite.registerDefaultInstance(ClientSettingsRequest.class, clientSettingsRequest);
        }

        private ClientSettingsRequest() {
        }

        public static ClientSettingsRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ClientSettingsRequest parseDelimitedFrom(InputStream inputStream) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ClientSettingsRequest parseFrom(ByteBuffer byteBuffer) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ClientSettingsRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ClientSettingsRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0000", (Object[]) null);
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ClientSettingsRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ClientSettingsRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public static Builder newBuilder(ClientSettingsRequest clientSettingsRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(clientSettingsRequest);
        }

        public static ClientSettingsRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ClientSettingsRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ClientSettingsRequest parseFrom(ByteString byteString) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ClientSettingsRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ClientSettingsRequest parseFrom(byte[] bArr) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ClientSettingsRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ClientSettingsRequest parseFrom(InputStream inputStream) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ClientSettingsRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ClientSettingsRequest parseFrom(CodedInputStream codedInputStream) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ClientSettingsRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ClientSettingsRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ClientSettingsResponse extends GeneratedMessageLite<ClientSettingsResponse, Builder> implements ClientSettingsResponseOrBuilder {
        private static final ClientSettingsResponse DEFAULT_INSTANCE;
        public static final int PARAMS_FIELD_NUMBER = 1;
        private static volatile Parser<ClientSettingsResponse> PARSER;
        private Internal.ProtobufList<SettingsParam> params_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ClientSettingsResponse, Builder> implements ClientSettingsResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ClientSettingsResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ClientSettingsResponse clientSettingsResponse = new ClientSettingsResponse();
            DEFAULT_INSTANCE = clientSettingsResponse;
            GeneratedMessageLite.registerDefaultInstance(ClientSettingsResponse.class, clientSettingsResponse);
        }

        private ClientSettingsResponse() {
        }

        private void addAllParams(Iterable<? extends SettingsParam> iterable) {
            ensureParamsIsMutable();
            AbstractMessageLite.addAll(iterable, this.params_);
        }

        private void addParams(SettingsParam settingsParam) {
            settingsParam.getClass();
            ensureParamsIsMutable();
            this.params_.add(settingsParam);
        }

        private void clearParams() {
            this.params_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureParamsIsMutable() {
            Internal.ProtobufList<SettingsParam> protobufList = this.params_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.params_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ClientSettingsResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ClientSettingsResponse parseDelimitedFrom(InputStream inputStream) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ClientSettingsResponse parseFrom(ByteBuffer byteBuffer) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ClientSettingsResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeParams(int i) {
            ensureParamsIsMutable();
            this.params_.remove(i);
        }

        private void setParams(int i, SettingsParam settingsParam) {
            settingsParam.getClass();
            ensureParamsIsMutable();
            this.params_.set(i, settingsParam);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ClientSettingsResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1045984025), SettingsParam.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ClientSettingsResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ClientSettingsResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public SettingsParam getParams(int i) {
            return (SettingsParam) this.params_.get(i);
        }

        public int getParamsCount() {
            return this.params_.size();
        }

        public List<SettingsParam> getParamsList() {
            return this.params_;
        }

        public SettingsParamOrBuilder getParamsOrBuilder(int i) {
            return (SettingsParamOrBuilder) this.params_.get(i);
        }

        public List<? extends SettingsParamOrBuilder> getParamsOrBuilderList() {
            return this.params_;
        }

        public static Builder newBuilder(ClientSettingsResponse clientSettingsResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(clientSettingsResponse);
        }

        public static ClientSettingsResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ClientSettingsResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ClientSettingsResponse parseFrom(ByteString byteString) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addParams(int i, SettingsParam settingsParam) {
            settingsParam.getClass();
            ensureParamsIsMutable();
            this.params_.add(i, settingsParam);
        }

        public static ClientSettingsResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ClientSettingsResponse parseFrom(byte[] bArr) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ClientSettingsResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ClientSettingsResponse parseFrom(InputStream inputStream) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ClientSettingsResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ClientSettingsResponse parseFrom(CodedInputStream codedInputStream) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ClientSettingsResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ClientSettingsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ClientSettingsResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class CreateAgentRequest extends GeneratedMessageLite<CreateAgentRequest, Builder> implements CreateAgentRequestOrBuilder {
        public static final int AGENT_NAME_FIELD_NUMBER = 1;
        public static final int CPU_REQ_FIELD_NUMBER = 5;
        private static final CreateAgentRequest DEFAULT_INSTANCE;
        public static final int MAX_REPLICAS_FIELD_NUMBER = 4;
        private static volatile Parser<CreateAgentRequest> PARSER = null;
        public static final int REGIONS_FIELD_NUMBER = 6;
        public static final int REPLICAS_FIELD_NUMBER = 3;
        public static final int SECRETS_FIELD_NUMBER = 2;
        private String agentName_;
        private String cpuReq_;
        private int maxReplicas_;
        private Internal.ProtobufList<String> regions_;
        private int replicas_;
        private Internal.ProtobufList<AgentSecret> secrets_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<CreateAgentRequest, Builder> implements CreateAgentRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(CreateAgentRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            CreateAgentRequest createAgentRequest = new CreateAgentRequest();
            DEFAULT_INSTANCE = createAgentRequest;
            GeneratedMessageLite.registerDefaultInstance(CreateAgentRequest.class, createAgentRequest);
        }

        private CreateAgentRequest() {
            String strA = ap.a(1067412069);
            this.agentName_ = strA;
            this.secrets_ = GeneratedMessageLite.emptyProtobufList();
            this.cpuReq_ = strA;
            this.regions_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllRegions(Iterable<String> iterable) {
            ensureRegionsIsMutable();
            AbstractMessageLite.addAll(iterable, this.regions_);
        }

        private void addAllSecrets(Iterable<? extends AgentSecret> iterable) {
            ensureSecretsIsMutable();
            AbstractMessageLite.addAll(iterable, this.secrets_);
        }

        private void addRegions(String str) {
            str.getClass();
            ensureRegionsIsMutable();
            this.regions_.add(str);
        }

        private void addRegionsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureRegionsIsMutable();
            this.regions_.add(byteString.L());
        }

        private void addSecrets(AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(agentSecret);
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearCpuReq() {
            this.cpuReq_ = getDefaultInstance().getCpuReq();
        }

        private void clearMaxReplicas() {
            this.maxReplicas_ = 0;
        }

        private void clearRegions() {
            this.regions_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearReplicas() {
            this.replicas_ = 0;
        }

        private void clearSecrets() {
            this.secrets_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureRegionsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.regions_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.regions_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSecretsIsMutable() {
            Internal.ProtobufList<AgentSecret> protobufList = this.secrets_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.secrets_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static CreateAgentRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static CreateAgentRequest parseDelimitedFrom(InputStream inputStream) {
            return (CreateAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateAgentRequest parseFrom(ByteBuffer byteBuffer) {
            return (CreateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<CreateAgentRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSecrets(int i) {
            ensureSecretsIsMutable();
            this.secrets_.remove(i);
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setCpuReq(String str) {
            str.getClass();
            this.cpuReq_ = str;
        }

        private void setCpuReqBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.cpuReq_ = byteString.L();
        }

        private void setMaxReplicas(int i) {
            this.maxReplicas_ = i;
        }

        private void setRegions(int i, String str) {
            str.getClass();
            ensureRegionsIsMutable();
            this.regions_.set(i, str);
        }

        private void setReplicas(int i) {
            this.replicas_ = i;
        }

        private void setSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.set(i, agentSecret);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new CreateAgentRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0002\u0000\u0001Ȉ\u0002\u001b\u0003\u0004\u0004\u0004\u0005Ȉ\u0006Ț", new Object[]{"agentName_", "secrets_", AgentSecret.class, "replicas_", "maxReplicas_", "cpuReq_", "regions_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<CreateAgentRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (CreateAgentRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        @Deprecated
        public String getAgentName() {
            return this.agentName_;
        }

        @Deprecated
        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        @Deprecated
        public String getCpuReq() {
            return this.cpuReq_;
        }

        @Deprecated
        public ByteString getCpuReqBytes() {
            return ByteString.n(this.cpuReq_);
        }

        @Deprecated
        public int getMaxReplicas() {
            return this.maxReplicas_;
        }

        public String getRegions(int i) {
            return (String) this.regions_.get(i);
        }

        public ByteString getRegionsBytes(int i) {
            return ByteString.n((String) this.regions_.get(i));
        }

        public int getRegionsCount() {
            return this.regions_.size();
        }

        public List<String> getRegionsList() {
            return this.regions_;
        }

        @Deprecated
        public int getReplicas() {
            return this.replicas_;
        }

        public AgentSecret getSecrets(int i) {
            return (AgentSecret) this.secrets_.get(i);
        }

        public int getSecretsCount() {
            return this.secrets_.size();
        }

        public List<AgentSecret> getSecretsList() {
            return this.secrets_;
        }

        public AgentSecretOrBuilder getSecretsOrBuilder(int i) {
            return (AgentSecretOrBuilder) this.secrets_.get(i);
        }

        public List<? extends AgentSecretOrBuilder> getSecretsOrBuilderList() {
            return this.secrets_;
        }

        public static Builder newBuilder(CreateAgentRequest createAgentRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(createAgentRequest);
        }

        public static CreateAgentRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateAgentRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static CreateAgentRequest parseFrom(ByteString byteString) {
            return (CreateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(i, agentSecret);
        }

        public static CreateAgentRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static CreateAgentRequest parseFrom(byte[] bArr) {
            return (CreateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static CreateAgentRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static CreateAgentRequest parseFrom(InputStream inputStream) {
            return (CreateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateAgentRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateAgentRequest parseFrom(CodedInputStream codedInputStream) {
            return (CreateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static CreateAgentRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface CreateAgentRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class CreateAgentResponse extends GeneratedMessageLite<CreateAgentResponse, Builder> implements CreateAgentResponseOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 1;
        public static final int AGENT_NAME_FIELD_NUMBER = 2;
        private static final CreateAgentResponse DEFAULT_INSTANCE;
        private static volatile Parser<CreateAgentResponse> PARSER = null;
        public static final int PRESIGNED_URL_FIELD_NUMBER = 5;
        public static final int STATUS_FIELD_NUMBER = 3;
        public static final int TAG_FIELD_NUMBER = 6;
        public static final int VERSION_FIELD_NUMBER = 4;
        private String agentId_;
        private String agentName_;
        private String presignedUrl_;
        private String status_;
        private String tag_;
        private String version_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<CreateAgentResponse, Builder> implements CreateAgentResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(CreateAgentResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            CreateAgentResponse createAgentResponse = new CreateAgentResponse();
            DEFAULT_INSTANCE = createAgentResponse;
            GeneratedMessageLite.registerDefaultInstance(CreateAgentResponse.class, createAgentResponse);
        }

        private CreateAgentResponse() {
            String strA = ap.a(43715754);
            this.agentId_ = strA;
            this.agentName_ = strA;
            this.status_ = strA;
            this.version_ = strA;
            this.presignedUrl_ = strA;
            this.tag_ = strA;
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearPresignedUrl() {
            this.presignedUrl_ = getDefaultInstance().getPresignedUrl();
        }

        private void clearStatus() {
            this.status_ = getDefaultInstance().getStatus();
        }

        private void clearTag() {
            this.tag_ = getDefaultInstance().getTag();
        }

        private void clearVersion() {
            this.version_ = getDefaultInstance().getVersion();
        }

        public static CreateAgentResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static CreateAgentResponse parseDelimitedFrom(InputStream inputStream) {
            return (CreateAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateAgentResponse parseFrom(ByteBuffer byteBuffer) {
            return (CreateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<CreateAgentResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setPresignedUrl(String str) {
            str.getClass();
            this.presignedUrl_ = str;
        }

        private void setPresignedUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.presignedUrl_ = byteString.L();
        }

        private void setStatus(String str) {
            str.getClass();
            this.status_ = str;
        }

        private void setStatusBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.status_ = byteString.L();
        }

        private void setTag(String str) {
            str.getClass();
            this.tag_ = str;
        }

        private void setTagBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.tag_ = byteString.L();
        }

        private void setVersion(String str) {
            str.getClass();
            this.version_ = str;
        }

        private void setVersionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.version_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new CreateAgentResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005Ȉ\u0006Ȉ", new Object[]{"agentId_", "agentName_", "status_", "version_", "presignedUrl_", "tag_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<CreateAgentResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (CreateAgentResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public String getPresignedUrl() {
            return this.presignedUrl_;
        }

        public ByteString getPresignedUrlBytes() {
            return ByteString.n(this.presignedUrl_);
        }

        public String getStatus() {
            return this.status_;
        }

        public ByteString getStatusBytes() {
            return ByteString.n(this.status_);
        }

        public String getTag() {
            return this.tag_;
        }

        public ByteString getTagBytes() {
            return ByteString.n(this.tag_);
        }

        public String getVersion() {
            return this.version_;
        }

        public ByteString getVersionBytes() {
            return ByteString.n(this.version_);
        }

        public static Builder newBuilder(CreateAgentResponse createAgentResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(createAgentResponse);
        }

        public static CreateAgentResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateAgentResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static CreateAgentResponse parseFrom(ByteString byteString) {
            return (CreateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static CreateAgentResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static CreateAgentResponse parseFrom(byte[] bArr) {
            return (CreateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static CreateAgentResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static CreateAgentResponse parseFrom(InputStream inputStream) {
            return (CreateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static CreateAgentResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static CreateAgentResponse parseFrom(CodedInputStream codedInputStream) {
            return (CreateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static CreateAgentResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (CreateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface CreateAgentResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DeleteAgentRequest extends GeneratedMessageLite<DeleteAgentRequest, Builder> implements DeleteAgentRequestOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 1;
        public static final int AGENT_NAME_FIELD_NUMBER = 2;
        private static final DeleteAgentRequest DEFAULT_INSTANCE;
        private static volatile Parser<DeleteAgentRequest> PARSER;
        private String agentId_;
        private String agentName_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DeleteAgentRequest, Builder> implements DeleteAgentRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DeleteAgentRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            DeleteAgentRequest deleteAgentRequest = new DeleteAgentRequest();
            DEFAULT_INSTANCE = deleteAgentRequest;
            GeneratedMessageLite.registerDefaultInstance(DeleteAgentRequest.class, deleteAgentRequest);
        }

        private DeleteAgentRequest() {
            String strA = ap.a(1175200560);
            this.agentId_ = strA;
            this.agentName_ = strA;
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        public static DeleteAgentRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DeleteAgentRequest parseDelimitedFrom(InputStream inputStream) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteAgentRequest parseFrom(ByteBuffer byteBuffer) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DeleteAgentRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DeleteAgentRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"agentId_", "agentName_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DeleteAgentRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DeleteAgentRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public static Builder newBuilder(DeleteAgentRequest deleteAgentRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(deleteAgentRequest);
        }

        public static DeleteAgentRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteAgentRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DeleteAgentRequest parseFrom(ByteString byteString) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DeleteAgentRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DeleteAgentRequest parseFrom(byte[] bArr) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DeleteAgentRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DeleteAgentRequest parseFrom(InputStream inputStream) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteAgentRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteAgentRequest parseFrom(CodedInputStream codedInputStream) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DeleteAgentRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DeleteAgentRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DeleteAgentResponse extends GeneratedMessageLite<DeleteAgentResponse, Builder> implements DeleteAgentResponseOrBuilder {
        private static final DeleteAgentResponse DEFAULT_INSTANCE;
        public static final int MESSAGE_FIELD_NUMBER = 2;
        private static volatile Parser<DeleteAgentResponse> PARSER = null;
        public static final int SUCCESS_FIELD_NUMBER = 1;
        private String message_ = ap.a(1819859556);
        private boolean success_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DeleteAgentResponse, Builder> implements DeleteAgentResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DeleteAgentResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            DeleteAgentResponse deleteAgentResponse = new DeleteAgentResponse();
            DEFAULT_INSTANCE = deleteAgentResponse;
            GeneratedMessageLite.registerDefaultInstance(DeleteAgentResponse.class, deleteAgentResponse);
        }

        private DeleteAgentResponse() {
        }

        private void clearMessage() {
            this.message_ = getDefaultInstance().getMessage();
        }

        private void clearSuccess() {
            this.success_ = false;
        }

        public static DeleteAgentResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DeleteAgentResponse parseDelimitedFrom(InputStream inputStream) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteAgentResponse parseFrom(ByteBuffer byteBuffer) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DeleteAgentResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setMessage(String str) {
            str.getClass();
            this.message_ = str;
        }

        private void setMessageBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.message_ = byteString.L();
        }

        private void setSuccess(boolean z) {
            this.success_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DeleteAgentResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0007\u0002Ȉ", new Object[]{"success_", "message_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DeleteAgentResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DeleteAgentResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getMessage() {
            return this.message_;
        }

        public ByteString getMessageBytes() {
            return ByteString.n(this.message_);
        }

        public boolean getSuccess() {
            return this.success_;
        }

        public static Builder newBuilder(DeleteAgentResponse deleteAgentResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(deleteAgentResponse);
        }

        public static DeleteAgentResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteAgentResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DeleteAgentResponse parseFrom(ByteString byteString) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DeleteAgentResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DeleteAgentResponse parseFrom(byte[] bArr) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DeleteAgentResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DeleteAgentResponse parseFrom(InputStream inputStream) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeleteAgentResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeleteAgentResponse parseFrom(CodedInputStream codedInputStream) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DeleteAgentResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeleteAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DeleteAgentResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DeployAgentRequest extends GeneratedMessageLite<DeployAgentRequest, Builder> implements DeployAgentRequestOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 1;
        public static final int AGENT_NAME_FIELD_NUMBER = 2;
        public static final int CPU_REQ_FIELD_NUMBER = 6;
        private static final DeployAgentRequest DEFAULT_INSTANCE;
        public static final int MAX_REPLICAS_FIELD_NUMBER = 5;
        private static volatile Parser<DeployAgentRequest> PARSER = null;
        public static final int REPLICAS_FIELD_NUMBER = 4;
        public static final int SECRETS_FIELD_NUMBER = 3;
        private String agentId_;
        private String agentName_;
        private String cpuReq_;
        private int maxReplicas_;
        private int replicas_;
        private Internal.ProtobufList<AgentSecret> secrets_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DeployAgentRequest, Builder> implements DeployAgentRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DeployAgentRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            DeployAgentRequest deployAgentRequest = new DeployAgentRequest();
            DEFAULT_INSTANCE = deployAgentRequest;
            GeneratedMessageLite.registerDefaultInstance(DeployAgentRequest.class, deployAgentRequest);
        }

        private DeployAgentRequest() {
            String strA = ap.a(2142552252);
            this.agentId_ = strA;
            this.agentName_ = strA;
            this.secrets_ = GeneratedMessageLite.emptyProtobufList();
            this.cpuReq_ = strA;
        }

        private void addAllSecrets(Iterable<? extends AgentSecret> iterable) {
            ensureSecretsIsMutable();
            AbstractMessageLite.addAll(iterable, this.secrets_);
        }

        private void addSecrets(AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(agentSecret);
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearCpuReq() {
            this.cpuReq_ = getDefaultInstance().getCpuReq();
        }

        private void clearMaxReplicas() {
            this.maxReplicas_ = 0;
        }

        private void clearReplicas() {
            this.replicas_ = 0;
        }

        private void clearSecrets() {
            this.secrets_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureSecretsIsMutable() {
            Internal.ProtobufList<AgentSecret> protobufList = this.secrets_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.secrets_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static DeployAgentRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DeployAgentRequest parseDelimitedFrom(InputStream inputStream) {
            return (DeployAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeployAgentRequest parseFrom(ByteBuffer byteBuffer) {
            return (DeployAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DeployAgentRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSecrets(int i) {
            ensureSecretsIsMutable();
            this.secrets_.remove(i);
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setCpuReq(String str) {
            str.getClass();
            this.cpuReq_ = str;
        }

        private void setCpuReqBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.cpuReq_ = byteString.L();
        }

        private void setMaxReplicas(int i) {
            this.maxReplicas_ = i;
        }

        private void setReplicas(int i) {
            this.replicas_ = i;
        }

        private void setSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.set(i, agentSecret);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DeployAgentRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0006\u0000\u0000\u0001\u0006\u0006\u0000\u0001\u0000\u0001Ȉ\u0002Ȉ\u0003\u001b\u0004\u0004\u0005\u0004\u0006Ȉ", new Object[]{"agentId_", "agentName_", "secrets_", AgentSecret.class, "replicas_", "maxReplicas_", "cpuReq_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DeployAgentRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DeployAgentRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        @Deprecated
        public String getAgentName() {
            return this.agentName_;
        }

        @Deprecated
        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        @Deprecated
        public String getCpuReq() {
            return this.cpuReq_;
        }

        @Deprecated
        public ByteString getCpuReqBytes() {
            return ByteString.n(this.cpuReq_);
        }

        @Deprecated
        public int getMaxReplicas() {
            return this.maxReplicas_;
        }

        @Deprecated
        public int getReplicas() {
            return this.replicas_;
        }

        public AgentSecret getSecrets(int i) {
            return (AgentSecret) this.secrets_.get(i);
        }

        public int getSecretsCount() {
            return this.secrets_.size();
        }

        public List<AgentSecret> getSecretsList() {
            return this.secrets_;
        }

        public AgentSecretOrBuilder getSecretsOrBuilder(int i) {
            return (AgentSecretOrBuilder) this.secrets_.get(i);
        }

        public List<? extends AgentSecretOrBuilder> getSecretsOrBuilderList() {
            return this.secrets_;
        }

        public static Builder newBuilder(DeployAgentRequest deployAgentRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(deployAgentRequest);
        }

        public static DeployAgentRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeployAgentRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DeployAgentRequest parseFrom(ByteString byteString) {
            return (DeployAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(i, agentSecret);
        }

        public static DeployAgentRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DeployAgentRequest parseFrom(byte[] bArr) {
            return (DeployAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DeployAgentRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DeployAgentRequest parseFrom(InputStream inputStream) {
            return (DeployAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeployAgentRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeployAgentRequest parseFrom(CodedInputStream codedInputStream) {
            return (DeployAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DeployAgentRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DeployAgentRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class DeployAgentResponse extends GeneratedMessageLite<DeployAgentResponse, Builder> implements DeployAgentResponseOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 3;
        private static final DeployAgentResponse DEFAULT_INSTANCE;
        public static final int MESSAGE_FIELD_NUMBER = 2;
        private static volatile Parser<DeployAgentResponse> PARSER = null;
        public static final int PRESIGNED_URL_FIELD_NUMBER = 4;
        public static final int SUCCESS_FIELD_NUMBER = 1;
        public static final int TAG_FIELD_NUMBER = 5;
        private String agentId_;
        private String message_;
        private String presignedUrl_;
        private boolean success_;
        private String tag_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<DeployAgentResponse, Builder> implements DeployAgentResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(DeployAgentResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            DeployAgentResponse deployAgentResponse = new DeployAgentResponse();
            DEFAULT_INSTANCE = deployAgentResponse;
            GeneratedMessageLite.registerDefaultInstance(DeployAgentResponse.class, deployAgentResponse);
        }

        private DeployAgentResponse() {
            String strA = ap.a(57162993);
            this.message_ = strA;
            this.agentId_ = strA;
            this.presignedUrl_ = strA;
            this.tag_ = strA;
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearMessage() {
            this.message_ = getDefaultInstance().getMessage();
        }

        private void clearPresignedUrl() {
            this.presignedUrl_ = getDefaultInstance().getPresignedUrl();
        }

        private void clearSuccess() {
            this.success_ = false;
        }

        private void clearTag() {
            this.tag_ = getDefaultInstance().getTag();
        }

        public static DeployAgentResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static DeployAgentResponse parseDelimitedFrom(InputStream inputStream) {
            return (DeployAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeployAgentResponse parseFrom(ByteBuffer byteBuffer) {
            return (DeployAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<DeployAgentResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setMessage(String str) {
            str.getClass();
            this.message_ = str;
        }

        private void setMessageBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.message_ = byteString.L();
        }

        private void setPresignedUrl(String str) {
            str.getClass();
            this.presignedUrl_ = str;
        }

        private void setPresignedUrlBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.presignedUrl_ = byteString.L();
        }

        private void setSuccess(boolean z) {
            this.success_ = z;
        }

        private void setTag(String str) {
            str.getClass();
            this.tag_ = str;
        }

        private void setTagBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.tag_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new DeployAgentResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0005\u0000\u0000\u0001\u0005\u0005\u0000\u0000\u0000\u0001\u0007\u0002Ȉ\u0003Ȉ\u0004Ȉ\u0005Ȉ", new Object[]{"success_", "message_", "agentId_", "presignedUrl_", "tag_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<DeployAgentResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (DeployAgentResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public String getMessage() {
            return this.message_;
        }

        public ByteString getMessageBytes() {
            return ByteString.n(this.message_);
        }

        public String getPresignedUrl() {
            return this.presignedUrl_;
        }

        public ByteString getPresignedUrlBytes() {
            return ByteString.n(this.presignedUrl_);
        }

        public boolean getSuccess() {
            return this.success_;
        }

        public String getTag() {
            return this.tag_;
        }

        public ByteString getTagBytes() {
            return ByteString.n(this.tag_);
        }

        public static Builder newBuilder(DeployAgentResponse deployAgentResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(deployAgentResponse);
        }

        public static DeployAgentResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeployAgentResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static DeployAgentResponse parseFrom(ByteString byteString) {
            return (DeployAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static DeployAgentResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static DeployAgentResponse parseFrom(byte[] bArr) {
            return (DeployAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static DeployAgentResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static DeployAgentResponse parseFrom(InputStream inputStream) {
            return (DeployAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static DeployAgentResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static DeployAgentResponse parseFrom(CodedInputStream codedInputStream) {
            return (DeployAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static DeployAgentResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (DeployAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface DeployAgentResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListAgentSecretsRequest extends GeneratedMessageLite<ListAgentSecretsRequest, Builder> implements ListAgentSecretsRequestOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 1;
        public static final int AGENT_NAME_FIELD_NUMBER = 2;
        private static final ListAgentSecretsRequest DEFAULT_INSTANCE;
        private static volatile Parser<ListAgentSecretsRequest> PARSER;
        private String agentId_;
        private String agentName_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListAgentSecretsRequest, Builder> implements ListAgentSecretsRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListAgentSecretsRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListAgentSecretsRequest listAgentSecretsRequest = new ListAgentSecretsRequest();
            DEFAULT_INSTANCE = listAgentSecretsRequest;
            GeneratedMessageLite.registerDefaultInstance(ListAgentSecretsRequest.class, listAgentSecretsRequest);
        }

        private ListAgentSecretsRequest() {
            String strA = ap.a(1330197518);
            this.agentId_ = strA;
            this.agentName_ = strA;
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        public static ListAgentSecretsRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListAgentSecretsRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentSecretsRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListAgentSecretsRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListAgentSecretsRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"agentId_", "agentName_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListAgentSecretsRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListAgentSecretsRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public static Builder newBuilder(ListAgentSecretsRequest listAgentSecretsRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listAgentSecretsRequest);
        }

        public static ListAgentSecretsRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentSecretsRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListAgentSecretsRequest parseFrom(ByteString byteString) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListAgentSecretsRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListAgentSecretsRequest parseFrom(byte[] bArr) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListAgentSecretsRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListAgentSecretsRequest parseFrom(InputStream inputStream) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentSecretsRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentSecretsRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListAgentSecretsRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListAgentSecretsRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListAgentSecretsResponse extends GeneratedMessageLite<ListAgentSecretsResponse, Builder> implements ListAgentSecretsResponseOrBuilder {
        private static final ListAgentSecretsResponse DEFAULT_INSTANCE;
        private static volatile Parser<ListAgentSecretsResponse> PARSER = null;
        public static final int SECRETS_FIELD_NUMBER = 1;
        private Internal.ProtobufList<AgentSecret> secrets_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListAgentSecretsResponse, Builder> implements ListAgentSecretsResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListAgentSecretsResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListAgentSecretsResponse listAgentSecretsResponse = new ListAgentSecretsResponse();
            DEFAULT_INSTANCE = listAgentSecretsResponse;
            GeneratedMessageLite.registerDefaultInstance(ListAgentSecretsResponse.class, listAgentSecretsResponse);
        }

        private ListAgentSecretsResponse() {
        }

        private void addAllSecrets(Iterable<? extends AgentSecret> iterable) {
            ensureSecretsIsMutable();
            AbstractMessageLite.addAll(iterable, this.secrets_);
        }

        private void addSecrets(AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(agentSecret);
        }

        private void clearSecrets() {
            this.secrets_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureSecretsIsMutable() {
            Internal.ProtobufList<AgentSecret> protobufList = this.secrets_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.secrets_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListAgentSecretsResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListAgentSecretsResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentSecretsResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListAgentSecretsResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSecrets(int i) {
            ensureSecretsIsMutable();
            this.secrets_.remove(i);
        }

        private void setSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.set(i, agentSecret);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListAgentSecretsResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(242605834), AgentSecret.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListAgentSecretsResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListAgentSecretsResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AgentSecret getSecrets(int i) {
            return (AgentSecret) this.secrets_.get(i);
        }

        public int getSecretsCount() {
            return this.secrets_.size();
        }

        public List<AgentSecret> getSecretsList() {
            return this.secrets_;
        }

        public AgentSecretOrBuilder getSecretsOrBuilder(int i) {
            return (AgentSecretOrBuilder) this.secrets_.get(i);
        }

        public List<? extends AgentSecretOrBuilder> getSecretsOrBuilderList() {
            return this.secrets_;
        }

        public static Builder newBuilder(ListAgentSecretsResponse listAgentSecretsResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listAgentSecretsResponse);
        }

        public static ListAgentSecretsResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentSecretsResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListAgentSecretsResponse parseFrom(ByteString byteString) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(i, agentSecret);
        }

        public static ListAgentSecretsResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListAgentSecretsResponse parseFrom(byte[] bArr) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListAgentSecretsResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListAgentSecretsResponse parseFrom(InputStream inputStream) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentSecretsResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentSecretsResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListAgentSecretsResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListAgentSecretsResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListAgentVersionsRequest extends GeneratedMessageLite<ListAgentVersionsRequest, Builder> implements ListAgentVersionsRequestOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 1;
        public static final int AGENT_NAME_FIELD_NUMBER = 2;
        private static final ListAgentVersionsRequest DEFAULT_INSTANCE;
        private static volatile Parser<ListAgentVersionsRequest> PARSER;
        private String agentId_;
        private String agentName_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListAgentVersionsRequest, Builder> implements ListAgentVersionsRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListAgentVersionsRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListAgentVersionsRequest listAgentVersionsRequest = new ListAgentVersionsRequest();
            DEFAULT_INSTANCE = listAgentVersionsRequest;
            GeneratedMessageLite.registerDefaultInstance(ListAgentVersionsRequest.class, listAgentVersionsRequest);
        }

        private ListAgentVersionsRequest() {
            String strA = ap.a(78165246);
            this.agentId_ = strA;
            this.agentName_ = strA;
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        public static ListAgentVersionsRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListAgentVersionsRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentVersionsRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListAgentVersionsRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListAgentVersionsRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"agentId_", "agentName_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListAgentVersionsRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListAgentVersionsRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public static Builder newBuilder(ListAgentVersionsRequest listAgentVersionsRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listAgentVersionsRequest);
        }

        public static ListAgentVersionsRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentVersionsRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListAgentVersionsRequest parseFrom(ByteString byteString) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListAgentVersionsRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListAgentVersionsRequest parseFrom(byte[] bArr) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListAgentVersionsRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListAgentVersionsRequest parseFrom(InputStream inputStream) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentVersionsRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentVersionsRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListAgentVersionsRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListAgentVersionsRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListAgentVersionsResponse extends GeneratedMessageLite<ListAgentVersionsResponse, Builder> implements ListAgentVersionsResponseOrBuilder {
        private static final ListAgentVersionsResponse DEFAULT_INSTANCE;
        private static volatile Parser<ListAgentVersionsResponse> PARSER = null;
        public static final int VERSIONS_FIELD_NUMBER = 1;
        private Internal.ProtobufList<AgentVersion> versions_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListAgentVersionsResponse, Builder> implements ListAgentVersionsResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListAgentVersionsResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListAgentVersionsResponse listAgentVersionsResponse = new ListAgentVersionsResponse();
            DEFAULT_INSTANCE = listAgentVersionsResponse;
            GeneratedMessageLite.registerDefaultInstance(ListAgentVersionsResponse.class, listAgentVersionsResponse);
        }

        private ListAgentVersionsResponse() {
        }

        private void addAllVersions(Iterable<? extends AgentVersion> iterable) {
            ensureVersionsIsMutable();
            AbstractMessageLite.addAll(iterable, this.versions_);
        }

        private void addVersions(AgentVersion agentVersion) {
            agentVersion.getClass();
            ensureVersionsIsMutable();
            this.versions_.add(agentVersion);
        }

        private void clearVersions() {
            this.versions_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureVersionsIsMutable() {
            Internal.ProtobufList<AgentVersion> protobufList = this.versions_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.versions_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListAgentVersionsResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListAgentVersionsResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentVersionsResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListAgentVersionsResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeVersions(int i) {
            ensureVersionsIsMutable();
            this.versions_.remove(i);
        }

        private void setVersions(int i, AgentVersion agentVersion) {
            agentVersion.getClass();
            ensureVersionsIsMutable();
            this.versions_.set(i, agentVersion);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListAgentVersionsResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1609369918), AgentVersion.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListAgentVersionsResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListAgentVersionsResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AgentVersion getVersions(int i) {
            return (AgentVersion) this.versions_.get(i);
        }

        public int getVersionsCount() {
            return this.versions_.size();
        }

        public List<AgentVersion> getVersionsList() {
            return this.versions_;
        }

        public AgentVersionOrBuilder getVersionsOrBuilder(int i) {
            return (AgentVersionOrBuilder) this.versions_.get(i);
        }

        public List<? extends AgentVersionOrBuilder> getVersionsOrBuilderList() {
            return this.versions_;
        }

        public static Builder newBuilder(ListAgentVersionsResponse listAgentVersionsResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listAgentVersionsResponse);
        }

        public static ListAgentVersionsResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentVersionsResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListAgentVersionsResponse parseFrom(ByteString byteString) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addVersions(int i, AgentVersion agentVersion) {
            agentVersion.getClass();
            ensureVersionsIsMutable();
            this.versions_.add(i, agentVersion);
        }

        public static ListAgentVersionsResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListAgentVersionsResponse parseFrom(byte[] bArr) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListAgentVersionsResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListAgentVersionsResponse parseFrom(InputStream inputStream) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentVersionsResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentVersionsResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListAgentVersionsResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentVersionsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListAgentVersionsResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListAgentsRequest extends GeneratedMessageLite<ListAgentsRequest, Builder> implements ListAgentsRequestOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 2;
        public static final int AGENT_NAME_FIELD_NUMBER = 1;
        private static final ListAgentsRequest DEFAULT_INSTANCE;
        private static volatile Parser<ListAgentsRequest> PARSER;
        private String agentId_;
        private String agentName_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListAgentsRequest, Builder> implements ListAgentsRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListAgentsRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            ListAgentsRequest listAgentsRequest = new ListAgentsRequest();
            DEFAULT_INSTANCE = listAgentsRequest;
            GeneratedMessageLite.registerDefaultInstance(ListAgentsRequest.class, listAgentsRequest);
        }

        private ListAgentsRequest() {
            String strA = ap.a(905161319);
            this.agentName_ = strA;
            this.agentId_ = strA;
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        public static ListAgentsRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListAgentsRequest parseDelimitedFrom(InputStream inputStream) {
            return (ListAgentsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentsRequest parseFrom(ByteBuffer byteBuffer) {
            return (ListAgentsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListAgentsRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListAgentsRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"agentName_", "agentId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListAgentsRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListAgentsRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public static Builder newBuilder(ListAgentsRequest listAgentsRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listAgentsRequest);
        }

        public static ListAgentsRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentsRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListAgentsRequest parseFrom(ByteString byteString) {
            return (ListAgentsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static ListAgentsRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListAgentsRequest parseFrom(byte[] bArr) {
            return (ListAgentsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListAgentsRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListAgentsRequest parseFrom(InputStream inputStream) {
            return (ListAgentsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentsRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentsRequest parseFrom(CodedInputStream codedInputStream) {
            return (ListAgentsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListAgentsRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListAgentsRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class ListAgentsResponse extends GeneratedMessageLite<ListAgentsResponse, Builder> implements ListAgentsResponseOrBuilder {
        public static final int AGENTS_FIELD_NUMBER = 1;
        private static final ListAgentsResponse DEFAULT_INSTANCE;
        private static volatile Parser<ListAgentsResponse> PARSER;
        private Internal.ProtobufList<AgentInfo> agents_ = GeneratedMessageLite.emptyProtobufList();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<ListAgentsResponse, Builder> implements ListAgentsResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(ListAgentsResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            ListAgentsResponse listAgentsResponse = new ListAgentsResponse();
            DEFAULT_INSTANCE = listAgentsResponse;
            GeneratedMessageLite.registerDefaultInstance(ListAgentsResponse.class, listAgentsResponse);
        }

        private ListAgentsResponse() {
        }

        private void addAgents(AgentInfo agentInfo) {
            agentInfo.getClass();
            ensureAgentsIsMutable();
            this.agents_.add(agentInfo);
        }

        private void addAllAgents(Iterable<? extends AgentInfo> iterable) {
            ensureAgentsIsMutable();
            AbstractMessageLite.addAll(iterable, this.agents_);
        }

        private void clearAgents() {
            this.agents_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureAgentsIsMutable() {
            Internal.ProtobufList<AgentInfo> protobufList = this.agents_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.agents_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static ListAgentsResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static ListAgentsResponse parseDelimitedFrom(InputStream inputStream) {
            return (ListAgentsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentsResponse parseFrom(ByteBuffer byteBuffer) {
            return (ListAgentsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<ListAgentsResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeAgents(int i) {
            ensureAgentsIsMutable();
            this.agents_.remove(i);
        }

        private void setAgents(int i, AgentInfo agentInfo) {
            agentInfo.getClass();
            ensureAgentsIsMutable();
            this.agents_.set(i, agentInfo);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new ListAgentsResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0001\u0000\u0001\u001b", new Object[]{ap.a(1152232185), AgentInfo.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<ListAgentsResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (ListAgentsResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public AgentInfo getAgents(int i) {
            return (AgentInfo) this.agents_.get(i);
        }

        public int getAgentsCount() {
            return this.agents_.size();
        }

        public List<AgentInfo> getAgentsList() {
            return this.agents_;
        }

        public AgentInfoOrBuilder getAgentsOrBuilder(int i) {
            return (AgentInfoOrBuilder) this.agents_.get(i);
        }

        public List<? extends AgentInfoOrBuilder> getAgentsOrBuilderList() {
            return this.agents_;
        }

        public static Builder newBuilder(ListAgentsResponse listAgentsResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(listAgentsResponse);
        }

        public static ListAgentsResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentsResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static ListAgentsResponse parseFrom(ByteString byteString) {
            return (ListAgentsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addAgents(int i, AgentInfo agentInfo) {
            agentInfo.getClass();
            ensureAgentsIsMutable();
            this.agents_.add(i, agentInfo);
        }

        public static ListAgentsResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static ListAgentsResponse parseFrom(byte[] bArr) {
            return (ListAgentsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static ListAgentsResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static ListAgentsResponse parseFrom(InputStream inputStream) {
            return (ListAgentsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static ListAgentsResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static ListAgentsResponse parseFrom(CodedInputStream codedInputStream) {
            return (ListAgentsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static ListAgentsResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (ListAgentsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ListAgentsResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RestartAgentRequest extends GeneratedMessageLite<RestartAgentRequest, Builder> implements RestartAgentRequestOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 1;
        private static final RestartAgentRequest DEFAULT_INSTANCE;
        private static volatile Parser<RestartAgentRequest> PARSER;
        private String agentId_ = ap.a(1408709702);

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RestartAgentRequest, Builder> implements RestartAgentRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RestartAgentRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            RestartAgentRequest restartAgentRequest = new RestartAgentRequest();
            DEFAULT_INSTANCE = restartAgentRequest;
            GeneratedMessageLite.registerDefaultInstance(RestartAgentRequest.class, restartAgentRequest);
        }

        private RestartAgentRequest() {
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        public static RestartAgentRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RestartAgentRequest parseDelimitedFrom(InputStream inputStream) {
            return (RestartAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RestartAgentRequest parseFrom(ByteBuffer byteBuffer) {
            return (RestartAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RestartAgentRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RestartAgentRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0001\u0000\u0000\u0001\u0001\u0001\u0000\u0000\u0000\u0001Ȉ", new Object[]{"agentId_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RestartAgentRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RestartAgentRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public static Builder newBuilder(RestartAgentRequest restartAgentRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(restartAgentRequest);
        }

        public static RestartAgentRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RestartAgentRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RestartAgentRequest parseFrom(ByteString byteString) {
            return (RestartAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RestartAgentRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RestartAgentRequest parseFrom(byte[] bArr) {
            return (RestartAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RestartAgentRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RestartAgentRequest parseFrom(InputStream inputStream) {
            return (RestartAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RestartAgentRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RestartAgentRequest parseFrom(CodedInputStream codedInputStream) {
            return (RestartAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RestartAgentRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RestartAgentRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RestartAgentResponse extends GeneratedMessageLite<RestartAgentResponse, Builder> implements RestartAgentResponseOrBuilder {
        private static final RestartAgentResponse DEFAULT_INSTANCE;
        public static final int MESSAGE_FIELD_NUMBER = 2;
        private static volatile Parser<RestartAgentResponse> PARSER = null;
        public static final int SUCCESS_FIELD_NUMBER = 1;
        private String message_ = ap.a(1966936836);
        private boolean success_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RestartAgentResponse, Builder> implements RestartAgentResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RestartAgentResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            RestartAgentResponse restartAgentResponse = new RestartAgentResponse();
            DEFAULT_INSTANCE = restartAgentResponse;
            GeneratedMessageLite.registerDefaultInstance(RestartAgentResponse.class, restartAgentResponse);
        }

        private RestartAgentResponse() {
        }

        private void clearMessage() {
            this.message_ = getDefaultInstance().getMessage();
        }

        private void clearSuccess() {
            this.success_ = false;
        }

        public static RestartAgentResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RestartAgentResponse parseDelimitedFrom(InputStream inputStream) {
            return (RestartAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RestartAgentResponse parseFrom(ByteBuffer byteBuffer) {
            return (RestartAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RestartAgentResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setMessage(String str) {
            str.getClass();
            this.message_ = str;
        }

        private void setMessageBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.message_ = byteString.L();
        }

        private void setSuccess(boolean z) {
            this.success_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RestartAgentResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0007\u0002Ȉ", new Object[]{"success_", "message_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RestartAgentResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RestartAgentResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getMessage() {
            return this.message_;
        }

        public ByteString getMessageBytes() {
            return ByteString.n(this.message_);
        }

        public boolean getSuccess() {
            return this.success_;
        }

        public static Builder newBuilder(RestartAgentResponse restartAgentResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(restartAgentResponse);
        }

        public static RestartAgentResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RestartAgentResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RestartAgentResponse parseFrom(ByteString byteString) {
            return (RestartAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RestartAgentResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RestartAgentResponse parseFrom(byte[] bArr) {
            return (RestartAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RestartAgentResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RestartAgentResponse parseFrom(InputStream inputStream) {
            return (RestartAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RestartAgentResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RestartAgentResponse parseFrom(CodedInputStream codedInputStream) {
            return (RestartAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RestartAgentResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RestartAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RestartAgentResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RollbackAgentRequest extends GeneratedMessageLite<RollbackAgentRequest, Builder> implements RollbackAgentRequestOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 1;
        public static final int AGENT_NAME_FIELD_NUMBER = 2;
        private static final RollbackAgentRequest DEFAULT_INSTANCE;
        private static volatile Parser<RollbackAgentRequest> PARSER = null;
        public static final int VERSION_FIELD_NUMBER = 3;
        private String agentId_;
        private String agentName_;
        private String version_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RollbackAgentRequest, Builder> implements RollbackAgentRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RollbackAgentRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            RollbackAgentRequest rollbackAgentRequest = new RollbackAgentRequest();
            DEFAULT_INSTANCE = rollbackAgentRequest;
            GeneratedMessageLite.registerDefaultInstance(RollbackAgentRequest.class, rollbackAgentRequest);
        }

        private RollbackAgentRequest() {
            String strA = ap.a(166351243);
            this.agentId_ = strA;
            this.agentName_ = strA;
            this.version_ = strA;
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearVersion() {
            this.version_ = getDefaultInstance().getVersion();
        }

        public static RollbackAgentRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RollbackAgentRequest parseDelimitedFrom(InputStream inputStream) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RollbackAgentRequest parseFrom(ByteBuffer byteBuffer) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RollbackAgentRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setVersion(String str) {
            str.getClass();
            this.version_ = str;
        }

        private void setVersionBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.version_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RollbackAgentRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0003\u0000\u0000\u0001\u0003\u0003\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ\u0003Ȉ", new Object[]{"agentId_", "agentName_", "version_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RollbackAgentRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RollbackAgentRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public String getVersion() {
            return this.version_;
        }

        public ByteString getVersionBytes() {
            return ByteString.n(this.version_);
        }

        public static Builder newBuilder(RollbackAgentRequest rollbackAgentRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(rollbackAgentRequest);
        }

        public static RollbackAgentRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RollbackAgentRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RollbackAgentRequest parseFrom(ByteString byteString) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RollbackAgentRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RollbackAgentRequest parseFrom(byte[] bArr) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RollbackAgentRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RollbackAgentRequest parseFrom(InputStream inputStream) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RollbackAgentRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RollbackAgentRequest parseFrom(CodedInputStream codedInputStream) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RollbackAgentRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RollbackAgentRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class RollbackAgentResponse extends GeneratedMessageLite<RollbackAgentResponse, Builder> implements RollbackAgentResponseOrBuilder {
        private static final RollbackAgentResponse DEFAULT_INSTANCE;
        public static final int MESSAGE_FIELD_NUMBER = 2;
        private static volatile Parser<RollbackAgentResponse> PARSER = null;
        public static final int SUCCESS_FIELD_NUMBER = 1;
        private String message_ = ap.a(543483070);
        private boolean success_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<RollbackAgentResponse, Builder> implements RollbackAgentResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(RollbackAgentResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            RollbackAgentResponse rollbackAgentResponse = new RollbackAgentResponse();
            DEFAULT_INSTANCE = rollbackAgentResponse;
            GeneratedMessageLite.registerDefaultInstance(RollbackAgentResponse.class, rollbackAgentResponse);
        }

        private RollbackAgentResponse() {
        }

        private void clearMessage() {
            this.message_ = getDefaultInstance().getMessage();
        }

        private void clearSuccess() {
            this.success_ = false;
        }

        public static RollbackAgentResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static RollbackAgentResponse parseDelimitedFrom(InputStream inputStream) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RollbackAgentResponse parseFrom(ByteBuffer byteBuffer) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<RollbackAgentResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setMessage(String str) {
            str.getClass();
            this.message_ = str;
        }

        private void setMessageBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.message_ = byteString.L();
        }

        private void setSuccess(boolean z) {
            this.success_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new RollbackAgentResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0007\u0002Ȉ", new Object[]{"success_", "message_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<RollbackAgentResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (RollbackAgentResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getMessage() {
            return this.message_;
        }

        public ByteString getMessageBytes() {
            return ByteString.n(this.message_);
        }

        public boolean getSuccess() {
            return this.success_;
        }

        public static Builder newBuilder(RollbackAgentResponse rollbackAgentResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(rollbackAgentResponse);
        }

        public static RollbackAgentResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RollbackAgentResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static RollbackAgentResponse parseFrom(ByteString byteString) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static RollbackAgentResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static RollbackAgentResponse parseFrom(byte[] bArr) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static RollbackAgentResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static RollbackAgentResponse parseFrom(InputStream inputStream) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static RollbackAgentResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static RollbackAgentResponse parseFrom(CodedInputStream codedInputStream) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static RollbackAgentResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (RollbackAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface RollbackAgentResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class SettingsParam extends GeneratedMessageLite<SettingsParam, Builder> implements SettingsParamOrBuilder {
        private static final SettingsParam DEFAULT_INSTANCE;
        public static final int NAME_FIELD_NUMBER = 1;
        private static volatile Parser<SettingsParam> PARSER = null;
        public static final int VALUE_FIELD_NUMBER = 2;
        private String name_;
        private String value_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<SettingsParam, Builder> implements SettingsParamOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(SettingsParam.DEFAULT_INSTANCE);
            }
        }

        static {
            SettingsParam settingsParam = new SettingsParam();
            DEFAULT_INSTANCE = settingsParam;
            GeneratedMessageLite.registerDefaultInstance(SettingsParam.class, settingsParam);
        }

        private SettingsParam() {
            String strA = ap.a(1815271397);
            this.name_ = strA;
            this.value_ = strA;
        }

        private void clearName() {
            this.name_ = getDefaultInstance().getName();
        }

        private void clearValue() {
            this.value_ = getDefaultInstance().getValue();
        }

        public static SettingsParam getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static SettingsParam parseDelimitedFrom(InputStream inputStream) {
            return (SettingsParam) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SettingsParam parseFrom(ByteBuffer byteBuffer) {
            return (SettingsParam) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<SettingsParam> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setName(String str) {
            str.getClass();
            this.name_ = str;
        }

        private void setNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.name_ = byteString.L();
        }

        private void setValue(String str) {
            str.getClass();
            this.value_ = str;
        }

        private void setValueBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.value_ = byteString.L();
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new SettingsParam();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001Ȉ\u0002Ȉ", new Object[]{"name_", "value_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<SettingsParam> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (SettingsParam.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getName() {
            return this.name_;
        }

        public ByteString getNameBytes() {
            return ByteString.n(this.name_);
        }

        public String getValue() {
            return this.value_;
        }

        public ByteString getValueBytes() {
            return ByteString.n(this.value_);
        }

        public static Builder newBuilder(SettingsParam settingsParam) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(settingsParam);
        }

        public static SettingsParam parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SettingsParam) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SettingsParam parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (SettingsParam) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static SettingsParam parseFrom(ByteString byteString) {
            return (SettingsParam) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static SettingsParam parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (SettingsParam) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static SettingsParam parseFrom(byte[] bArr) {
            return (SettingsParam) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static SettingsParam parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (SettingsParam) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static SettingsParam parseFrom(InputStream inputStream) {
            return (SettingsParam) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static SettingsParam parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SettingsParam) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static SettingsParam parseFrom(CodedInputStream codedInputStream) {
            return (SettingsParam) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static SettingsParam parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (SettingsParam) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface SettingsParamOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateAgentRequest extends GeneratedMessageLite<UpdateAgentRequest, Builder> implements UpdateAgentRequestOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 1;
        public static final int AGENT_NAME_FIELD_NUMBER = 2;
        public static final int CPU_REQ_FIELD_NUMBER = 5;
        private static final UpdateAgentRequest DEFAULT_INSTANCE;
        public static final int MAX_REPLICAS_FIELD_NUMBER = 4;
        private static volatile Parser<UpdateAgentRequest> PARSER = null;
        public static final int REGIONS_FIELD_NUMBER = 6;
        public static final int REPLICAS_FIELD_NUMBER = 3;
        public static final int SECRETS_FIELD_NUMBER = 7;
        private String agentId_;
        private String agentName_;
        private String cpuReq_;
        private int maxReplicas_;
        private Internal.ProtobufList<String> regions_;
        private int replicas_;
        private Internal.ProtobufList<AgentSecret> secrets_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateAgentRequest, Builder> implements UpdateAgentRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateAgentRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateAgentRequest updateAgentRequest = new UpdateAgentRequest();
            DEFAULT_INSTANCE = updateAgentRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdateAgentRequest.class, updateAgentRequest);
        }

        private UpdateAgentRequest() {
            String strA = ap.a(634098054);
            this.agentId_ = strA;
            this.agentName_ = strA;
            this.cpuReq_ = strA;
            this.regions_ = GeneratedMessageLite.emptyProtobufList();
            this.secrets_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllRegions(Iterable<String> iterable) {
            ensureRegionsIsMutable();
            AbstractMessageLite.addAll(iterable, this.regions_);
        }

        private void addAllSecrets(Iterable<? extends AgentSecret> iterable) {
            ensureSecretsIsMutable();
            AbstractMessageLite.addAll(iterable, this.secrets_);
        }

        private void addRegions(String str) {
            str.getClass();
            ensureRegionsIsMutable();
            this.regions_.add(str);
        }

        private void addRegionsBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            ensureRegionsIsMutable();
            this.regions_.add(byteString.L());
        }

        private void addSecrets(AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(agentSecret);
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearCpuReq() {
            this.cpuReq_ = getDefaultInstance().getCpuReq();
        }

        private void clearMaxReplicas() {
            this.maxReplicas_ = 0;
        }

        private void clearRegions() {
            this.regions_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void clearReplicas() {
            this.replicas_ = 0;
        }

        private void clearSecrets() {
            this.secrets_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureRegionsIsMutable() {
            Internal.ProtobufList<String> protobufList = this.regions_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.regions_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        private void ensureSecretsIsMutable() {
            Internal.ProtobufList<AgentSecret> protobufList = this.secrets_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.secrets_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static UpdateAgentRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateAgentRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateAgentRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateAgentRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSecrets(int i) {
            ensureSecretsIsMutable();
            this.secrets_.remove(i);
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setCpuReq(String str) {
            str.getClass();
            this.cpuReq_ = str;
        }

        private void setCpuReqBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.cpuReq_ = byteString.L();
        }

        private void setMaxReplicas(int i) {
            this.maxReplicas_ = i;
        }

        private void setRegions(int i, String str) {
            str.getClass();
            ensureRegionsIsMutable();
            this.regions_.set(i, str);
        }

        private void setReplicas(int i) {
            this.replicas_ = i;
        }

        private void setSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.set(i, agentSecret);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateAgentRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0007\u0000\u0000\u0001\u0007\u0007\u0000\u0002\u0000\u0001Ȉ\u0002Ȉ\u0003\u0004\u0004\u0004\u0005Ȉ\u0006Ț\u0007\u001b", new Object[]{"agentId_", "agentName_", "replicas_", "maxReplicas_", "cpuReq_", "regions_", "secrets_", AgentSecret.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateAgentRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateAgentRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        @Deprecated
        public String getAgentName() {
            return this.agentName_;
        }

        @Deprecated
        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        @Deprecated
        public String getCpuReq() {
            return this.cpuReq_;
        }

        @Deprecated
        public ByteString getCpuReqBytes() {
            return ByteString.n(this.cpuReq_);
        }

        @Deprecated
        public int getMaxReplicas() {
            return this.maxReplicas_;
        }

        public String getRegions(int i) {
            return (String) this.regions_.get(i);
        }

        public ByteString getRegionsBytes(int i) {
            return ByteString.n((String) this.regions_.get(i));
        }

        public int getRegionsCount() {
            return this.regions_.size();
        }

        public List<String> getRegionsList() {
            return this.regions_;
        }

        @Deprecated
        public int getReplicas() {
            return this.replicas_;
        }

        public AgentSecret getSecrets(int i) {
            return (AgentSecret) this.secrets_.get(i);
        }

        public int getSecretsCount() {
            return this.secrets_.size();
        }

        public List<AgentSecret> getSecretsList() {
            return this.secrets_;
        }

        public AgentSecretOrBuilder getSecretsOrBuilder(int i) {
            return (AgentSecretOrBuilder) this.secrets_.get(i);
        }

        public List<? extends AgentSecretOrBuilder> getSecretsOrBuilderList() {
            return this.secrets_;
        }

        public static Builder newBuilder(UpdateAgentRequest updateAgentRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateAgentRequest);
        }

        public static UpdateAgentRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateAgentRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateAgentRequest parseFrom(ByteString byteString) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(i, agentSecret);
        }

        public static UpdateAgentRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateAgentRequest parseFrom(byte[] bArr) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateAgentRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateAgentRequest parseFrom(InputStream inputStream) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateAgentRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateAgentRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateAgentRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateAgentRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateAgentResponse extends GeneratedMessageLite<UpdateAgentResponse, Builder> implements UpdateAgentResponseOrBuilder {
        private static final UpdateAgentResponse DEFAULT_INSTANCE;
        public static final int MESSAGE_FIELD_NUMBER = 2;
        private static volatile Parser<UpdateAgentResponse> PARSER = null;
        public static final int SUCCESS_FIELD_NUMBER = 1;
        private String message_ = ap.a(548273403);
        private boolean success_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateAgentResponse, Builder> implements UpdateAgentResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateAgentResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateAgentResponse updateAgentResponse = new UpdateAgentResponse();
            DEFAULT_INSTANCE = updateAgentResponse;
            GeneratedMessageLite.registerDefaultInstance(UpdateAgentResponse.class, updateAgentResponse);
        }

        private UpdateAgentResponse() {
        }

        private void clearMessage() {
            this.message_ = getDefaultInstance().getMessage();
        }

        private void clearSuccess() {
            this.success_ = false;
        }

        public static UpdateAgentResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateAgentResponse parseDelimitedFrom(InputStream inputStream) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateAgentResponse parseFrom(ByteBuffer byteBuffer) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateAgentResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setMessage(String str) {
            str.getClass();
            this.message_ = str;
        }

        private void setMessageBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.message_ = byteString.L();
        }

        private void setSuccess(boolean z) {
            this.success_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateAgentResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0007\u0002Ȉ", new Object[]{"success_", "message_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateAgentResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateAgentResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getMessage() {
            return this.message_;
        }

        public ByteString getMessageBytes() {
            return ByteString.n(this.message_);
        }

        public boolean getSuccess() {
            return this.success_;
        }

        public static Builder newBuilder(UpdateAgentResponse updateAgentResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateAgentResponse);
        }

        public static UpdateAgentResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateAgentResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateAgentResponse parseFrom(ByteString byteString) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateAgentResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateAgentResponse parseFrom(byte[] bArr) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateAgentResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateAgentResponse parseFrom(InputStream inputStream) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateAgentResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateAgentResponse parseFrom(CodedInputStream codedInputStream) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateAgentResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateAgentResponseOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateAgentSecretsRequest extends GeneratedMessageLite<UpdateAgentSecretsRequest, Builder> implements UpdateAgentSecretsRequestOrBuilder {
        public static final int AGENT_ID_FIELD_NUMBER = 1;
        public static final int AGENT_NAME_FIELD_NUMBER = 2;
        private static final UpdateAgentSecretsRequest DEFAULT_INSTANCE;
        public static final int OVERWRITE_FIELD_NUMBER = 3;
        private static volatile Parser<UpdateAgentSecretsRequest> PARSER = null;
        public static final int SECRETS_FIELD_NUMBER = 4;
        private String agentId_;
        private String agentName_;
        private boolean overwrite_;
        private Internal.ProtobufList<AgentSecret> secrets_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateAgentSecretsRequest, Builder> implements UpdateAgentSecretsRequestOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateAgentSecretsRequest.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateAgentSecretsRequest updateAgentSecretsRequest = new UpdateAgentSecretsRequest();
            DEFAULT_INSTANCE = updateAgentSecretsRequest;
            GeneratedMessageLite.registerDefaultInstance(UpdateAgentSecretsRequest.class, updateAgentSecretsRequest);
        }

        private UpdateAgentSecretsRequest() {
            String strA = ap.a(519466683);
            this.agentId_ = strA;
            this.agentName_ = strA;
            this.secrets_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void addAllSecrets(Iterable<? extends AgentSecret> iterable) {
            ensureSecretsIsMutable();
            AbstractMessageLite.addAll(iterable, this.secrets_);
        }

        private void addSecrets(AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(agentSecret);
        }

        private void clearAgentId() {
            this.agentId_ = getDefaultInstance().getAgentId();
        }

        private void clearAgentName() {
            this.agentName_ = getDefaultInstance().getAgentName();
        }

        private void clearOverwrite() {
            this.overwrite_ = false;
        }

        private void clearSecrets() {
            this.secrets_ = GeneratedMessageLite.emptyProtobufList();
        }

        private void ensureSecretsIsMutable() {
            Internal.ProtobufList<AgentSecret> protobufList = this.secrets_;
            if (protobufList.isModifiable()) {
                return;
            }
            this.secrets_ = GeneratedMessageLite.mutableCopy(protobufList);
        }

        public static UpdateAgentSecretsRequest getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateAgentSecretsRequest parseDelimitedFrom(InputStream inputStream) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateAgentSecretsRequest parseFrom(ByteBuffer byteBuffer) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateAgentSecretsRequest> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void removeSecrets(int i) {
            ensureSecretsIsMutable();
            this.secrets_.remove(i);
        }

        private void setAgentId(String str) {
            str.getClass();
            this.agentId_ = str;
        }

        private void setAgentIdBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentId_ = byteString.L();
        }

        private void setAgentName(String str) {
            str.getClass();
            this.agentName_ = str;
        }

        private void setAgentNameBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.agentName_ = byteString.L();
        }

        private void setOverwrite(boolean z) {
            this.overwrite_ = z;
        }

        private void setSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.set(i, agentSecret);
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateAgentSecretsRequest();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0004\u0000\u0000\u0001\u0004\u0004\u0000\u0001\u0000\u0001Ȉ\u0002Ȉ\u0003\u0007\u0004\u001b", new Object[]{"agentId_", "agentName_", "overwrite_", "secrets_", AgentSecret.class});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateAgentSecretsRequest> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateAgentSecretsRequest.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getAgentId() {
            return this.agentId_;
        }

        public ByteString getAgentIdBytes() {
            return ByteString.n(this.agentId_);
        }

        public String getAgentName() {
            return this.agentName_;
        }

        public ByteString getAgentNameBytes() {
            return ByteString.n(this.agentName_);
        }

        public boolean getOverwrite() {
            return this.overwrite_;
        }

        public AgentSecret getSecrets(int i) {
            return (AgentSecret) this.secrets_.get(i);
        }

        public int getSecretsCount() {
            return this.secrets_.size();
        }

        public List<AgentSecret> getSecretsList() {
            return this.secrets_;
        }

        public AgentSecretOrBuilder getSecretsOrBuilder(int i) {
            return (AgentSecretOrBuilder) this.secrets_.get(i);
        }

        public List<? extends AgentSecretOrBuilder> getSecretsOrBuilderList() {
            return this.secrets_;
        }

        public static Builder newBuilder(UpdateAgentSecretsRequest updateAgentSecretsRequest) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateAgentSecretsRequest);
        }

        public static UpdateAgentSecretsRequest parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateAgentSecretsRequest parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateAgentSecretsRequest parseFrom(ByteString byteString) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        private void addSecrets(int i, AgentSecret agentSecret) {
            agentSecret.getClass();
            ensureSecretsIsMutable();
            this.secrets_.add(i, agentSecret);
        }

        public static UpdateAgentSecretsRequest parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateAgentSecretsRequest parseFrom(byte[] bArr) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateAgentSecretsRequest parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateAgentSecretsRequest parseFrom(InputStream inputStream) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateAgentSecretsRequest parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateAgentSecretsRequest parseFrom(CodedInputStream codedInputStream) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateAgentSecretsRequest parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsRequest) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateAgentSecretsRequestOrBuilder extends MessageLiteOrBuilder {
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public static final class UpdateAgentSecretsResponse extends GeneratedMessageLite<UpdateAgentSecretsResponse, Builder> implements UpdateAgentSecretsResponseOrBuilder {
        private static final UpdateAgentSecretsResponse DEFAULT_INSTANCE;
        public static final int MESSAGE_FIELD_NUMBER = 2;
        private static volatile Parser<UpdateAgentSecretsResponse> PARSER = null;
        public static final int SUCCESS_FIELD_NUMBER = 1;
        private String message_ = ap.a(797446027);
        private boolean success_;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        public static final class Builder extends GeneratedMessageLite.Builder<UpdateAgentSecretsResponse, Builder> implements UpdateAgentSecretsResponseOrBuilder {
            /* synthetic */ Builder(AnonymousClass1 anonymousClass1) {
                this();
            }

            private Builder() {
                super(UpdateAgentSecretsResponse.DEFAULT_INSTANCE);
            }
        }

        static {
            UpdateAgentSecretsResponse updateAgentSecretsResponse = new UpdateAgentSecretsResponse();
            DEFAULT_INSTANCE = updateAgentSecretsResponse;
            GeneratedMessageLite.registerDefaultInstance(UpdateAgentSecretsResponse.class, updateAgentSecretsResponse);
        }

        private UpdateAgentSecretsResponse() {
        }

        private void clearMessage() {
            this.message_ = getDefaultInstance().getMessage();
        }

        private void clearSuccess() {
            this.success_ = false;
        }

        public static UpdateAgentSecretsResponse getDefaultInstance() {
            return DEFAULT_INSTANCE;
        }

        public static Builder newBuilder() {
            return (Builder) DEFAULT_INSTANCE.createBuilder();
        }

        public static UpdateAgentSecretsResponse parseDelimitedFrom(InputStream inputStream) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateAgentSecretsResponse parseFrom(ByteBuffer byteBuffer) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer);
        }

        public static Parser<UpdateAgentSecretsResponse> parser() {
            return DEFAULT_INSTANCE.getParserForType();
        }

        private void setMessage(String str) {
            str.getClass();
            this.message_ = str;
        }

        private void setMessageBytes(ByteString byteString) {
            AbstractMessageLite.checkByteStringIsUtf8(byteString);
            this.message_ = byteString.L();
        }

        private void setSuccess(boolean z) {
            this.success_ = z;
        }

        protected final Object dynamicMethod(GeneratedMessageLite.MethodToInvoke methodToInvoke, Object obj, Object obj2) {
            GeneratedMessageLite.DefaultInstanceBasedParser defaultInstanceBasedParser;
            int i = AnonymousClass1.a[methodToInvoke.ordinal()];
            AnonymousClass1 anonymousClass1 = null;
            switch (i) {
                case 1:
                    return new UpdateAgentSecretsResponse();
                case 2:
                    return new Builder(anonymousClass1);
                case 3:
                    return GeneratedMessageLite.newMessageInfo(DEFAULT_INSTANCE, "\u0000\u0002\u0000\u0000\u0001\u0002\u0002\u0000\u0000\u0000\u0001\u0007\u0002Ȉ", new Object[]{"success_", "message_"});
                case 4:
                    return DEFAULT_INSTANCE;
                case 5:
                    Parser<UpdateAgentSecretsResponse> parser = PARSER;
                    if (parser != null) {
                        return parser;
                    }
                    synchronized (UpdateAgentSecretsResponse.class) {
                        try {
                            defaultInstanceBasedParser = PARSER;
                            if (defaultInstanceBasedParser == null) {
                                defaultInstanceBasedParser = new GeneratedMessageLite.DefaultInstanceBasedParser(DEFAULT_INSTANCE);
                                PARSER = defaultInstanceBasedParser;
                            }
                        } catch (Throwable th) {
                            throw th;
                        }
                        break;
                    }
                    return defaultInstanceBasedParser;
                case 6:
                    return (byte) 1;
                case 7:
                    return null;
                default:
                    throw new UnsupportedOperationException();
            }
        }

        public String getMessage() {
            return this.message_;
        }

        public ByteString getMessageBytes() {
            return ByteString.n(this.message_);
        }

        public boolean getSuccess() {
            return this.success_;
        }

        public static Builder newBuilder(UpdateAgentSecretsResponse updateAgentSecretsResponse) {
            return (Builder) DEFAULT_INSTANCE.createBuilder(updateAgentSecretsResponse);
        }

        public static UpdateAgentSecretsResponse parseDelimitedFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseDelimitedFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateAgentSecretsResponse parseFrom(ByteBuffer byteBuffer, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteBuffer, extensionRegistryLite);
        }

        public static UpdateAgentSecretsResponse parseFrom(ByteString byteString) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString);
        }

        public static UpdateAgentSecretsResponse parseFrom(ByteString byteString, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, byteString, extensionRegistryLite);
        }

        public static UpdateAgentSecretsResponse parseFrom(byte[] bArr) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr);
        }

        public static UpdateAgentSecretsResponse parseFrom(byte[] bArr, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, bArr, extensionRegistryLite);
        }

        public static UpdateAgentSecretsResponse parseFrom(InputStream inputStream) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream);
        }

        public static UpdateAgentSecretsResponse parseFrom(InputStream inputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, inputStream, extensionRegistryLite);
        }

        public static UpdateAgentSecretsResponse parseFrom(CodedInputStream codedInputStream) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream);
        }

        public static UpdateAgentSecretsResponse parseFrom(CodedInputStream codedInputStream, ExtensionRegistryLite extensionRegistryLite) {
            return (UpdateAgentSecretsResponse) GeneratedMessageLite.parseFrom(DEFAULT_INSTANCE, codedInputStream, extensionRegistryLite);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface UpdateAgentSecretsResponseOrBuilder extends MessageLiteOrBuilder {
    }

    private LivekitCloudAgent() {
    }
}