package _COROUTINE;

import kotlin.Metadata;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\r\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006J\r\u0010\u0007\u001a\u00020\u0004¢\u0006\u0004\b\u0007\u0010\u0006¨\u0006\b"}, d2 = {"L_COROUTINE/ArtificialStackFrames;", "", "<init>", "()V", "Ljava/lang/StackTraceElement;", "b", "()Ljava/lang/StackTraceElement;", "a", "kotlinx-coroutines-core"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class ArtificialStackFrames {
    public final StackTraceElement a() {
        return CoroutineDebuggingKt.b(new Exception(), _BOUNDARY.class.getSimpleName());
    }

    public final StackTraceElement b() {
        return CoroutineDebuggingKt.b(new Exception(), _CREATION.class.getSimpleName());
    }
}