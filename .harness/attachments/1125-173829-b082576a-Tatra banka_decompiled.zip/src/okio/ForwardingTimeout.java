package okio;

import h.ap;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u0007\b\u0016\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\u0005\u001a\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0004\b\u0005\u0010\u0006J\u001f\u0010\u000b\u001a\u00020\u00012\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\r\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\r\u0010\u000eJ\u000f\u0010\u0010\u001a\u00020\u000fH\u0016¢\u0006\u0004\b\u0010\u0010\u0011J\u000f\u0010\u0012\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0012\u0010\u000eJ\u0017\u0010\u0014\u001a\u00020\u00012\u0006\u0010\u0013\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0014\u0010\u0015J\u000f\u0010\u0016\u001a\u00020\u0001H\u0016¢\u0006\u0004\b\u0016\u0010\u0017J\u000f\u0010\u0018\u001a\u00020\u0001H\u0016¢\u0006\u0004\b\u0018\u0010\u0017J\u000f\u0010\u001a\u001a\u00020\u0019H\u0016¢\u0006\u0004\b\u001a\u0010\u001bJ\u0017\u0010\u001e\u001a\u00020\u00192\u0006\u0010\u001d\u001a\u00020\u001cH\u0016¢\u0006\u0004\b\u001e\u0010\u001fJ\u0017\u0010\"\u001a\u00020\u00192\u0006\u0010!\u001a\u00020 H\u0016¢\u0006\u0004\b\"\u0010#R\"\u0010\u0002\u001a\u00020\u00018\u0007@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u001a\u0010$\u001a\u0004\b%\u0010\u0017\"\u0004\b&\u0010\u0004¨\u0006'"}, d2 = {"Lokio/ForwardingTimeout;", "Lokio/Timeout;", "delegate", "<init>", "(Lokio/Timeout;)V", "l", "(Lokio/Timeout;)Lokio/ForwardingTimeout;", StringUtils.EMPTY, "timeout", "Ljava/util/concurrent/TimeUnit;", "unit", "h", "(JLjava/util/concurrent/TimeUnit;)Lokio/Timeout;", "i", "()J", StringUtils.EMPTY, "f", "()Z", "d", "deadlineNanoTime", "e", "(J)Lokio/Timeout;", "c", "()Lokio/Timeout;", "b", StringUtils.EMPTY, "g", "()V", "Ljava/util/concurrent/locks/Condition;", "condition", "a", "(Ljava/util/concurrent/locks/Condition;)V", StringUtils.EMPTY, "monitor", "j", "(Ljava/lang/Object;)V", "Lokio/Timeout;", "k", "setDelegate", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
public class ForwardingTimeout extends Timeout {
    private Timeout g;

    public ForwardingTimeout(Timeout timeout) {
        Intrinsics.checkNotNullParameter(timeout, ap.a(942966508));
        this.g = timeout;
    }

    @Override // okio.Timeout
    public void a(Condition condition) throws InterruptedIOException {
        Intrinsics.checkNotNullParameter(condition, "condition");
        this.g.a(condition);
    }

    @Override // okio.Timeout
    public Timeout b() {
        return this.g.b();
    }

    @Override // okio.Timeout
    public Timeout c() {
        return this.g.c();
    }

    @Override // okio.Timeout
    public long d() {
        return this.g.d();
    }

    @Override // okio.Timeout
    public Timeout e(long j) {
        return this.g.e(j);
    }

    @Override // okio.Timeout
    public boolean f() {
        return this.g.f();
    }

    @Override // okio.Timeout
    public void g() throws InterruptedIOException {
        this.g.g();
    }

    @Override // okio.Timeout
    public Timeout h(long j, TimeUnit timeUnit) {
        Intrinsics.checkNotNullParameter(timeUnit, "unit");
        return this.g.h(j, timeUnit);
    }

    @Override // okio.Timeout
    public long i() {
        return this.g.i();
    }

    @Override // okio.Timeout
    public void j(Object obj) throws InterruptedIOException {
        Intrinsics.checkNotNullParameter(obj, "monitor");
        this.g.j(obj);
    }

    public final Timeout k() {
        return this.g;
    }

    public final ForwardingTimeout l(Timeout timeout) {
        Intrinsics.checkNotNullParameter(timeout, "delegate");
        this.g = timeout;
        return this;
    }
}