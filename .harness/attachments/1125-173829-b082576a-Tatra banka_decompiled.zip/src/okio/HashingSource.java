package okio;

import h.ap;
import java.security.MessageDigest;
import javax.crypto.Mac;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u0000 \u00112\u00020\u00012\u00020\u0002:\u0001\u0012J\u001f\u0010\u0007\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0007\u0010\bR\u0016\u0010\f\u001a\u0004\u0018\u00010\t8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\n\u0010\u000bR\u0016\u0010\u0010\u001a\u0004\u0018\u00010\r8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000e\u0010\u000f¨\u0006\u0013"}, d2 = {"Lokio/HashingSource;", "Lokio/ForwardingSource;", "Lokio/Source;", "Lokio/Buffer;", "sink", StringUtils.EMPTY, "byteCount", "k3", "(Lokio/Buffer;J)J", "Ljava/security/MessageDigest;", "b", "Ljava/security/MessageDigest;", "messageDigest", "Ljavax/crypto/Mac;", "c", "Ljavax/crypto/Mac;", "mac", "d", "Companion", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class HashingSource extends ForwardingSource implements Source {
    public static final Companion d = new Companion(null);
    private final MessageDigest b;
    private final Mac c;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lokio/HashingSource$Companion;", StringUtils.EMPTY, "<init>", "()V", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    @Override // okio.ForwardingSource, okio.Source
    public long k3(Buffer buffer, long j) {
        Intrinsics.checkNotNullParameter(buffer, ap.a(1833762037));
        long jK3 = super.k3(buffer, j);
        if (jK3 != -1) {
            long size = buffer.size() - jK3;
            long size2 = buffer.size();
            Segment segment = buffer.a;
            Intrinsics.checkNotNull(segment);
            while (size2 > size) {
                segment = segment.g;
                Intrinsics.checkNotNull(segment);
                size2 -= (long) (segment.c - segment.b);
            }
            while (size2 < buffer.size()) {
                int i = (int) ((((long) segment.b) + size) - size2);
                MessageDigest messageDigest = this.b;
                if (messageDigest != null) {
                    messageDigest.update(segment.a, i, segment.c - i);
                } else {
                    Mac mac = this.c;
                    Intrinsics.checkNotNull(mac);
                    mac.update(segment.a, i, segment.c - i);
                }
                size2 += (long) (segment.c - segment.b);
                segment = segment.f;
                Intrinsics.checkNotNull(segment);
                size = size2;
            }
        }
        return jK3;
    }
}