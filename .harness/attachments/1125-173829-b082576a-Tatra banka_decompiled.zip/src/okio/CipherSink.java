package okio;

import h.ap;
import javax.crypto.Cipher;
import javax.crypto.ShortBufferException;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0004\u0018\u00002\u00020\u0001J\u001f\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0007\u0010\bJ\u0011\u0010\n\u001a\u0004\u0018\u00010\tH\u0002¢\u0006\u0004\b\n\u0010\u000bJ\u001f\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\f\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0010\u001a\u00020\rH\u0016¢\u0006\u0004\b\u0010\u0010\u0011J\u000f\u0010\u0013\u001a\u00020\u0012H\u0016¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010\u0015\u001a\u00020\rH\u0016¢\u0006\u0004\b\u0015\u0010\u0011R\u0014\u0010\u0019\u001a\u00020\u00168\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0017\u0010\u0018R\u0017\u0010\u001f\u001a\u00020\u001a8\u0006¢\u0006\f\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u001d\u0010\u001eR\u0014\u0010\"\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b \u0010!R\u0016\u0010&\u001a\u00020#8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b$\u0010%¨\u0006'"}, d2 = {"Lokio/CipherSink;", "Lokio/Sink;", "Lokio/Buffer;", ClimateForcast.SOURCE, StringUtils.EMPTY, "remaining", StringUtils.EMPTY, "k", "(Lokio/Buffer;J)I", StringUtils.EMPTY, "j", "()Ljava/lang/Throwable;", "byteCount", StringUtils.EMPTY, "a2", "(Lokio/Buffer;J)V", "flush", "()V", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", "close", "Lokio/BufferedSink;", "a", "Lokio/BufferedSink;", "sink", "Ljavax/crypto/Cipher;", "b", "Ljavax/crypto/Cipher;", "getCipher", "()Ljavax/crypto/Cipher;", "cipher", "c", "I", "blockSize", StringUtils.EMPTY, "d", "Z", "closed", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nCipherSink.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CipherSink.kt\nokio/CipherSink\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Util.kt\nokio/-SegmentedByteString\n*L\n1#1,148:1\n1#2:149\n87#3:150\n*S KotlinDebug\n*F\n+ 1 CipherSink.kt\nokio/CipherSink\n*L\n47#1:150\n*E\n"})
public final class CipherSink implements Sink {
    private final BufferedSink a;
    private final Cipher b;
    private final int c;
    private boolean d;

    private final Throwable j() {
        int outputSize = this.b.getOutputSize(0);
        Throwable th = null;
        if (outputSize == 0) {
            return null;
        }
        if (outputSize > 8192) {
            try {
                BufferedSink bufferedSink = this.a;
                byte[] bArrDoFinal = this.b.doFinal();
                Intrinsics.checkNotNullExpressionValue(bArrDoFinal, ap.a(467842654));
                bufferedSink.write(bArrDoFinal);
                return null;
            } catch (Throwable th2) {
                return th2;
            }
        }
        Buffer buffer = this.a.getBuffer();
        Segment segmentJ0 = buffer.j0(outputSize);
        try {
            int iDoFinal = this.b.doFinal(segmentJ0.a, segmentJ0.c);
            segmentJ0.c += iDoFinal;
            buffer.b0(buffer.size() + ((long) iDoFinal));
        } catch (Throwable th3) {
            th = th3;
        }
        if (segmentJ0.b == segmentJ0.c) {
            buffer.a = segmentJ0.b();
            SegmentPool.b(segmentJ0);
        }
        return th;
    }

    private final int k(Buffer buffer, long j) throws ShortBufferException {
        Segment segment = buffer.a;
        Intrinsics.checkNotNull(segment);
        int iMin = (int) Math.min(j, segment.c - segment.b);
        Buffer buffer2 = this.a.getBuffer();
        int outputSize = this.b.getOutputSize(iMin);
        int i = iMin;
        while (outputSize > 8192) {
            int i2 = this.c;
            if (i <= i2) {
                BufferedSink bufferedSink = this.a;
                byte[] bArrUpdate = this.b.update(buffer.l2(j));
                Intrinsics.checkNotNullExpressionValue(bArrUpdate, "update(...)");
                bufferedSink.write(bArrUpdate);
                return (int) j;
            }
            i -= i2;
            outputSize = this.b.getOutputSize(i);
        }
        Segment segmentJ0 = buffer2.j0(outputSize);
        int iUpdate = this.b.update(segment.a, segment.b, i, segmentJ0.a, segmentJ0.c);
        segmentJ0.c += iUpdate;
        buffer2.b0(buffer2.size() + ((long) iUpdate));
        if (segmentJ0.b == segmentJ0.c) {
            buffer2.a = segmentJ0.b();
            SegmentPool.b(segmentJ0);
        }
        this.a.P1();
        buffer.b0(buffer.size() - ((long) i));
        int i3 = segment.b + i;
        segment.b = i3;
        if (i3 == segment.c) {
            buffer.a = segment.b();
            SegmentPool.b(segment);
        }
        return i;
    }

    @Override // okio.Sink
    public void a2(Buffer buffer, long j) {
        Intrinsics.checkNotNullParameter(buffer, ClimateForcast.SOURCE);
        SegmentedByteString.b(buffer.size(), 0L, j);
        if (this.d) {
            throw new IllegalStateException("closed");
        }
        long jK = j;
        while (jK > 0) {
            jK -= (long) k(buffer, jK);
        }
    }

    @Override // okio.Sink, java.io.Closeable, java.lang.AutoCloseable
    public void close() throws Throwable {
        if (this.d) {
            return;
        }
        this.d = true;
        Throwable thJ = j();
        try {
            this.a.close();
        } catch (Throwable th) {
            if (thJ == null) {
                thJ = th;
            }
        }
        if (thJ != null) {
            throw thJ;
        }
    }

    @Override // okio.Sink, java.io.Flushable
    public void flush() {
        this.a.flush();
    }

    @Override // okio.Sink
    public Timeout timeout() {
        return this.a.timeout();
    }
}