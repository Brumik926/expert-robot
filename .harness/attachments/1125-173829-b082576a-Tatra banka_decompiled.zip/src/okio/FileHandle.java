package okio;

import h.ap;
import java.io.Closeable;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\b\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\b&\u0018\u00002\u00060\u0001j\u0002`\u0002:\u000289B\u000f\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J'\u0010\f\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\f\u0010\rJ'\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u000e\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\u0010\u0010\u0011J\r\u0010\u0012\u001a\u00020\u0007¢\u0006\u0004\b\u0012\u0010\u0013J\r\u0010\u0014\u001a\u00020\u000f¢\u0006\u0004\b\u0014\u0010\u0015J\u0017\u0010\u0017\u001a\u00020\u00162\b\b\u0002\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\u0017\u0010\u0018J\u0017\u0010\u001a\u001a\u00020\u00192\b\b\u0002\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\u001a\u0010\u001bJ\r\u0010\u001c\u001a\u00020\u000f¢\u0006\u0004\b\u001c\u0010\u0015J/\u0010!\u001a\u00020\u001f2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u001e\u001a\u00020\u001d2\u0006\u0010 \u001a\u00020\u001f2\u0006\u0010\u000b\u001a\u00020\u001fH$¢\u0006\u0004\b!\u0010\"J/\u0010#\u001a\u00020\u000f2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u001e\u001a\u00020\u001d2\u0006\u0010 \u001a\u00020\u001f2\u0006\u0010\u000b\u001a\u00020\u001fH$¢\u0006\u0004\b#\u0010$J\u000f\u0010%\u001a\u00020\u000fH$¢\u0006\u0004\b%\u0010\u0015J\u000f\u0010&\u001a\u00020\u0007H$¢\u0006\u0004\b&\u0010\u0013J\u000f\u0010'\u001a\u00020\u000fH$¢\u0006\u0004\b'\u0010\u0015R\u0017\u0010\u0004\u001a\u00020\u00038\u0006¢\u0006\f\n\u0004\b(\u0010)\u001a\u0004\b*\u0010+R\u0016\u0010-\u001a\u00020\u00038\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b,\u0010)R\u0016\u00100\u001a\u00020\u001f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b.\u0010/R\u001b\u00107\u001a\u000601j\u0002`28\u0006¢\u0006\f\n\u0004\b3\u00104\u001a\u0004\b5\u00106¨\u0006:"}, d2 = {"Lokio/FileHandle;", "Ljava/io/Closeable;", "Lokio/Closeable;", StringUtils.EMPTY, "readWrite", "<init>", "(Z)V", StringUtils.EMPTY, "fileOffset", "Lokio/Buffer;", "sink", "byteCount", "B", "(JLokio/Buffer;J)J", ClimateForcast.SOURCE, StringUtils.EMPTY, "O", "(JLokio/Buffer;J)V", "size", "()J", "flush", "()V", "Lokio/Source;", "J", "(J)Lokio/Source;", "Lokio/Sink;", "D", "(J)Lokio/Sink;", "close", StringUtils.EMPTY, "array", StringUtils.EMPTY, "arrayOffset", "r", "(J[BII)I", "A", "(J[BII)V", "q", "u", "o", "a", "Z", "getReadWrite", "()Z", "b", "closed", "c", "I", "openStreamCount", "Ljava/util/concurrent/locks/ReentrantLock;", "Lokio/Lock;", "d", "Ljava/util/concurrent/locks/ReentrantLock;", "k", "()Ljava/util/concurrent/locks/ReentrantLock;", "lock", "FileHandleSink", "FileHandleSource", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nFileHandle.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FileHandle.kt\nokio/FileHandle\n+ 2 -JvmPlatform.kt\nokio/_JvmPlatformKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 RealBufferedSource.kt\nokio/RealBufferedSource\n+ 5 RealBufferedSink.kt\nokio/RealBufferedSink\n+ 6 Util.kt\nokio/-SegmentedByteString\n*L\n1#1,444:1\n40#2:445\n40#2:447\n40#2:448\n40#2:449\n40#2:450\n40#2:451\n40#2:452\n40#2:453\n40#2:457\n40#2:459\n1#3:446\n63#4:454\n63#4:455\n63#4:456\n51#5:458\n87#6:460\n87#6:461\n*S KotlinDebug\n*F\n+ 1 FileHandle.kt\nokio/FileHandle\n*L\n69#1:445\n81#1:447\n92#1:448\n105#1:449\n119#1:450\n129#1:451\n139#1:452\n151#1:453\n221#1:457\n287#1:459\n169#1:454\n195#1:455\n202#1:456\n248#1:458\n345#1:460\n374#1:461\n*E\n"})
public abstract class FileHandle implements Closeable {
    private final boolean a;
    private boolean b;
    private int c;
    private final ReentrantLock d = _JvmPlatformKt.b();

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\u000b\n\u0002\b\b\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u001f\u0010\f\u001a\u00020\u000b2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\f\u0010\rJ\u000f\u0010\u000e\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0013\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u0013\u0010\u000fR\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0014\u0010\u0015\u001a\u0004\b\u0016\u0010\u0017R\"\u0010\u0005\u001a\u00020\u00048\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0018\u0010\u0019\u001a\u0004\b\u001a\u0010\u001b\"\u0004\b\u001c\u0010\u001dR\"\u0010%\u001a\u00020\u001e8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u001f\u0010 \u001a\u0004\b!\u0010\"\"\u0004\b#\u0010$¨\u0006&"}, d2 = {"Lokio/FileHandle$FileHandleSink;", "Lokio/Sink;", "Lokio/FileHandle;", "fileHandle", StringUtils.EMPTY, "position", "<init>", "(Lokio/FileHandle;J)V", "Lokio/Buffer;", ClimateForcast.SOURCE, "byteCount", StringUtils.EMPTY, "a2", "(Lokio/Buffer;J)V", "flush", "()V", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", "close", "a", "Lokio/FileHandle;", "getFileHandle", "()Lokio/FileHandle;", "b", "J", "getPosition", "()J", "setPosition", "(J)V", StringUtils.EMPTY, "c", "Z", "getClosed", "()Z", "setClosed", "(Z)V", "closed", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nFileHandle.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FileHandle.kt\nokio/FileHandle$FileHandleSink\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 -JvmPlatform.kt\nokio/_JvmPlatformKt\n*L\n1#1,444:1\n1#2:445\n40#3:446\n*S KotlinDebug\n*F\n+ 1 FileHandle.kt\nokio/FileHandle$FileHandleSink\n*L\n410#1:446\n*E\n"})
    private static final class FileHandleSink implements Sink {
        private final FileHandle a;
        private long b;
        private boolean c;

        public FileHandleSink(FileHandle fileHandle, long j) {
            Intrinsics.checkNotNullParameter(fileHandle, ap.a(226798034));
            this.a = fileHandle;
            this.b = j;
        }

        @Override // okio.Sink
        public void a2(Buffer buffer, long j) {
            Intrinsics.checkNotNullParameter(buffer, ClimateForcast.SOURCE);
            if (this.c) {
                throw new IllegalStateException("closed");
            }
            this.a.O(this.b, buffer, j);
            this.b += j;
        }

        @Override // okio.Sink, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (this.c) {
                return;
            }
            this.c = true;
            ReentrantLock reentrantLockK = this.a.k();
            reentrantLockK.lock();
            try {
                FileHandle fileHandle = this.a;
                fileHandle.c--;
                if (this.a.c == 0 && this.a.b) {
                    Unit unit = Unit.INSTANCE;
                    reentrantLockK.unlock();
                    this.a.o();
                }
            } finally {
                reentrantLockK.unlock();
            }
        }

        @Override // okio.Sink, java.io.Flushable
        public void flush() {
            if (this.c) {
                throw new IllegalStateException("closed");
            }
            this.a.q();
        }

        @Override // okio.Sink
        public Timeout timeout() {
            return Timeout.f;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\f\n\u0002\u0010\u000b\n\u0002\b\b\b\u0002\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u001f\u0010\u000b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\u000e\u001a\u00020\rH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0011\u0010\u0012R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0013\u0010\u0014\u001a\u0004\b\u0015\u0010\u0016R\"\u0010\u0005\u001a\u00020\u00048\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0017\u0010\u0018\u001a\u0004\b\u0019\u0010\u001a\"\u0004\b\u001b\u0010\u001cR\"\u0010$\u001a\u00020\u001d8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u001e\u0010\u001f\u001a\u0004\b \u0010!\"\u0004\b\"\u0010#¨\u0006%"}, d2 = {"Lokio/FileHandle$FileHandleSource;", "Lokio/Source;", "Lokio/FileHandle;", "fileHandle", StringUtils.EMPTY, "position", "<init>", "(Lokio/FileHandle;J)V", "Lokio/Buffer;", "sink", "byteCount", "k3", "(Lokio/Buffer;J)J", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", StringUtils.EMPTY, "close", "()V", "a", "Lokio/FileHandle;", "getFileHandle", "()Lokio/FileHandle;", "b", "J", "getPosition", "()J", "setPosition", "(J)V", StringUtils.EMPTY, "c", "Z", "getClosed", "()Z", "setClosed", "(Z)V", "closed", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nFileHandle.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FileHandle.kt\nokio/FileHandle$FileHandleSource\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 -JvmPlatform.kt\nokio/_JvmPlatformKt\n*L\n1#1,444:1\n1#2:445\n40#3:446\n*S KotlinDebug\n*F\n+ 1 FileHandle.kt\nokio/FileHandle$FileHandleSource\n*L\n436#1:446\n*E\n"})
    private static final class FileHandleSource implements Source {
        private final FileHandle a;
        private long b;
        private boolean c;

        public FileHandleSource(FileHandle fileHandle, long j) {
            Intrinsics.checkNotNullParameter(fileHandle, ap.a(800973438));
            this.a = fileHandle;
            this.b = j;
        }

        @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (this.c) {
                return;
            }
            this.c = true;
            ReentrantLock reentrantLockK = this.a.k();
            reentrantLockK.lock();
            try {
                FileHandle fileHandle = this.a;
                fileHandle.c--;
                if (this.a.c == 0 && this.a.b) {
                    Unit unit = Unit.INSTANCE;
                    reentrantLockK.unlock();
                    this.a.o();
                }
            } finally {
                reentrantLockK.unlock();
            }
        }

        @Override // okio.Source
        public long k3(Buffer buffer, long j) {
            Intrinsics.checkNotNullParameter(buffer, "sink");
            if (this.c) {
                throw new IllegalStateException("closed");
            }
            long jB = this.a.B(this.b, buffer, j);
            if (jB != -1) {
                this.b += jB;
            }
            return jB;
        }

        @Override // okio.Source
        public Timeout timeout() {
            return Timeout.f;
        }
    }

    public FileHandle(boolean z) {
        this.a = z;
    }

    private final long B(long j, Buffer buffer, long j2) {
        if (j2 < 0) {
            throw new IllegalArgumentException((ap.a(1089715748) + j2).toString());
        }
        long j3 = j2 + j;
        long j4 = j;
        while (true) {
            if (j4 >= j3) {
                break;
            }
            Segment segmentJ0 = buffer.j0(1);
            int iR = r(j4, segmentJ0.a, segmentJ0.c, (int) Math.min(j3 - j4, 8192 - r7));
            if (iR == -1) {
                if (segmentJ0.b == segmentJ0.c) {
                    buffer.a = segmentJ0.b();
                    SegmentPool.b(segmentJ0);
                }
                if (j == j4) {
                    return -1L;
                }
            } else {
                segmentJ0.c += iR;
                long j5 = iR;
                j4 += j5;
                buffer.b0(buffer.size() + j5);
            }
        }
        return j4 - j;
    }

    public static /* synthetic */ Sink I(FileHandle fileHandle, long j, int i, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: sink");
        }
        if ((i & 1) != 0) {
            j = 0;
        }
        return fileHandle.D(j);
    }

    private final void O(long j, Buffer buffer, long j2) {
        SegmentedByteString.b(buffer.size(), 0L, j2);
        long j3 = j + j2;
        long j4 = j;
        while (j4 < j3) {
            Segment segment = buffer.a;
            Intrinsics.checkNotNull(segment);
            int iMin = (int) Math.min(j3 - j4, segment.c - segment.b);
            FileHandle fileHandle = this;
            fileHandle.A(j4, segment.a, segment.b, iMin);
            segment.b += iMin;
            long j5 = iMin;
            j4 += j5;
            buffer.b0(buffer.size() - j5);
            if (segment.b == segment.c) {
                buffer.a = segment.b();
                SegmentPool.b(segment);
            }
            this = fileHandle;
        }
    }

    protected abstract void A(long j, byte[] bArr, int i, int i2);

    public final Sink D(long j) {
        if (!this.a) {
            throw new IllegalStateException("file handle is read-only");
        }
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            if (this.b) {
                throw new IllegalStateException("closed");
            }
            this.c++;
            reentrantLock.unlock();
            return new FileHandleSink(this, j);
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }

    public final Source J(long j) {
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            if (this.b) {
                throw new IllegalStateException("closed");
            }
            this.c++;
            reentrantLock.unlock();
            return new FileHandleSource(this, j);
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public final void close() {
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            if (this.b) {
                return;
            }
            this.b = true;
            if (this.c != 0) {
                return;
            }
            Unit unit = Unit.INSTANCE;
            reentrantLock.unlock();
            o();
        } finally {
            reentrantLock.unlock();
        }
    }

    public final void flush() {
        if (!this.a) {
            throw new IllegalStateException("file handle is read-only");
        }
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            if (this.b) {
                throw new IllegalStateException("closed");
            }
            Unit unit = Unit.INSTANCE;
            reentrantLock.unlock();
            q();
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }

    public final ReentrantLock k() {
        return this.d;
    }

    protected abstract void o();

    protected abstract void q();

    protected abstract int r(long j, byte[] bArr, int i, int i2);

    public final long size() {
        ReentrantLock reentrantLock = this.d;
        reentrantLock.lock();
        try {
            if (this.b) {
                throw new IllegalStateException("closed");
            }
            Unit unit = Unit.INSTANCE;
            reentrantLock.unlock();
            return u();
        } catch (Throwable th) {
            reentrantLock.unlock();
            throw th;
        }
    }

    protected abstract long u();
}