package okio;

import h.ap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u000e\n\u0002\b\u0003\b\u0010\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J'\u0010\t\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\t\u0010\nJ\u0013\u0010\f\u001a\u00020\u000b*\u00020\u0004H\u0002¢\u0006\u0004\b\f\u0010\rJ\u0013\u0010\u000e\u001a\u00020\u000b*\u00020\u0004H\u0002¢\u0006\u0004\b\u000e\u0010\rJ\u0019\u0010\u0011\u001a\u0004\u0018\u00010\u00102\u0006\u0010\u000f\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0011\u0010\u0012J\u001d\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00040\b2\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0013\u0010\u0014J\u001f\u0010\u0015\u001a\n\u0012\u0004\u0012\u00020\u0004\u0018\u00010\b2\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0015\u0010\u0014J\u0017\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0018\u0010\u0019J'\u0010\u001c\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u00042\u0006\u0010\u001a\u001a\u00020\u00062\u0006\u0010\u001b\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u001c\u0010\u001dJ\u0017\u0010\u001f\u001a\u00020\u001e2\u0006\u0010\u0016\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u001f\u0010 J\u001f\u0010\"\u001a\u00020!2\u0006\u0010\u0016\u001a\u00020\u00042\u0006\u0010\u001a\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\"\u0010#J\u001f\u0010$\u001a\u00020!2\u0006\u0010\u0016\u001a\u00020\u00042\u0006\u0010\u001b\u001a\u00020\u0006H\u0016¢\u0006\u0004\b$\u0010#J\u001f\u0010%\u001a\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u001a\u001a\u00020\u0006H\u0016¢\u0006\u0004\b%\u0010&J\u001f\u0010)\u001a\u00020\u000b2\u0006\u0010'\u001a\u00020\u00042\u0006\u0010(\u001a\u00020\u0004H\u0016¢\u0006\u0004\b)\u0010*J\u001f\u0010+\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u00042\u0006\u0010\u001b\u001a\u00020\u0006H\u0016¢\u0006\u0004\b+\u0010&J\u000f\u0010-\u001a\u00020,H\u0016¢\u0006\u0004\b-\u0010.¨\u0006/"}, d2 = {"Lokio/JvmSystemFileSystem;", "Lokio/FileSystem;", "<init>", "()V", "Lokio/Path;", "dir", StringUtils.EMPTY, "throwOnFailure", StringUtils.EMPTY, "X", "(Lokio/Path;Z)Ljava/util/List;", StringUtils.EMPTY, "b0", "(Lokio/Path;)V", "a0", "path", "Lokio/FileMetadata;", "I", "(Lokio/Path;)Lokio/FileMetadata;", "A", "(Lokio/Path;)Ljava/util/List;", "B", "file", "Lokio/FileHandle;", "J", "(Lokio/Path;)Lokio/FileHandle;", "mustCreate", "mustExist", "P", "(Lokio/Path;ZZ)Lokio/FileHandle;", "Lokio/Source;", "W", "(Lokio/Path;)Lokio/Source;", "Lokio/Sink;", "V", "(Lokio/Path;Z)Lokio/Sink;", "d", "k", "(Lokio/Path;Z)V", ClimateForcast.SOURCE, "target", "e", "(Lokio/Path;Lokio/Path;)V", "r", StringUtils.EMPTY, "toString", "()Ljava/lang/String;", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nJvmSystemFileSystem.kt\nKotlin\n*S Kotlin\n*F\n+ 1 JvmSystemFileSystem.kt\nokio/JvmSystemFileSystem\n+ 2 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,158:1\n11563#2,3:159\n*S KotlinDebug\n*F\n+ 1 JvmSystemFileSystem.kt\nokio/JvmSystemFileSystem\n*L\n77#1:159,3\n*E\n"})
public class JvmSystemFileSystem extends FileSystem {
    private final List X(Path path, boolean z) throws IOException {
        File file = path.toFile();
        String[] list = file.list();
        if (list != null) {
            ArrayList arrayList = new ArrayList();
            for (String str : list) {
                Intrinsics.checkNotNull(str);
                arrayList.add(path.j(str));
            }
            CollectionsKt.sort(arrayList);
            return arrayList;
        }
        if (!z) {
            return null;
        }
        if (file.exists()) {
            throw new IOException(ap.a(1321053977) + path);
        }
        throw new FileNotFoundException(ap.a(1536305563) + path);
    }

    private final void a0(Path path) throws IOException {
        if (u(path)) {
            throw new IOException(path + " already exists.");
        }
    }

    private final void b0(Path path) throws IOException {
        if (u(path)) {
            return;
        }
        throw new IOException(path + " doesn't exist.");
    }

    @Override // okio.FileSystem
    public List A(Path path) throws IOException {
        Intrinsics.checkNotNullParameter(path, "dir");
        List listX = X(path, true);
        Intrinsics.checkNotNull(listX);
        return listX;
    }

    @Override // okio.FileSystem
    public List B(Path path) {
        Intrinsics.checkNotNullParameter(path, "dir");
        return X(path, false);
    }

    @Override // okio.FileSystem
    public FileMetadata I(Path path) {
        Intrinsics.checkNotNullParameter(path, "path");
        File file = path.toFile();
        boolean zIsFile = file.isFile();
        boolean zIsDirectory = file.isDirectory();
        long jLastModified = file.lastModified();
        long length = file.length();
        if (zIsFile || zIsDirectory || jLastModified != 0 || length != 0 || file.exists()) {
            return new FileMetadata(zIsFile, zIsDirectory, null, Long.valueOf(length), null, Long.valueOf(jLastModified), null, null, 128, null);
        }
        return null;
    }

    @Override // okio.FileSystem
    public FileHandle J(Path path) {
        Intrinsics.checkNotNullParameter(path, "file");
        return new JvmFileHandle(false, new RandomAccessFile(path.toFile(), "r"));
    }

    @Override // okio.FileSystem
    public FileHandle P(Path path, boolean z, boolean z2) throws IOException {
        Intrinsics.checkNotNullParameter(path, "file");
        if (z && z2) {
            throw new IllegalArgumentException("Cannot require mustCreate and mustExist at the same time.");
        }
        if (z) {
            a0(path);
        }
        if (z2) {
            b0(path);
        }
        return new JvmFileHandle(true, new RandomAccessFile(path.toFile(), "rw"));
    }

    @Override // okio.FileSystem
    public Sink V(Path path, boolean z) throws IOException {
        Intrinsics.checkNotNullParameter(path, "file");
        if (z) {
            a0(path);
        }
        return Okio__JvmOkioKt.d(path.toFile(), false, 1, null);
    }

    @Override // okio.FileSystem
    public Source W(Path path) {
        Intrinsics.checkNotNullParameter(path, "file");
        return Okio.h(path.toFile());
    }

    @Override // okio.FileSystem
    public Sink d(Path path, boolean z) throws IOException {
        Intrinsics.checkNotNullParameter(path, "file");
        if (z) {
            b0(path);
        }
        return Okio.d(path.toFile(), true);
    }

    @Override // okio.FileSystem
    public void e(Path path, Path path2) throws IOException {
        Intrinsics.checkNotNullParameter(path, ClimateForcast.SOURCE);
        Intrinsics.checkNotNullParameter(path2, "target");
        if (path.toFile().renameTo(path2.toFile())) {
            return;
        }
        throw new IOException("failed to move " + path + " to " + path2);
    }

    @Override // okio.FileSystem
    public void k(Path path, boolean z) throws IOException {
        Intrinsics.checkNotNullParameter(path, "dir");
        if (path.toFile().mkdir()) {
            return;
        }
        FileMetadata fileMetadataI = I(path);
        if (fileMetadataI == null || !fileMetadataI.e()) {
            throw new IOException("failed to create directory: " + path);
        }
        if (z) {
            throw new IOException(path + " already exists.");
        }
    }

    @Override // okio.FileSystem
    public void r(Path path, boolean z) throws IOException {
        Intrinsics.checkNotNullParameter(path, "path");
        if (Thread.interrupted()) {
            throw new InterruptedIOException("interrupted");
        }
        File file = path.toFile();
        if (file.delete()) {
            return;
        }
        if (file.exists()) {
            throw new IOException("failed to delete " + path);
        }
        if (z) {
            throw new FileNotFoundException("no such file: " + path);
        }
    }

    public String toString() {
        return "JvmSystemFileSystem";
    }
}