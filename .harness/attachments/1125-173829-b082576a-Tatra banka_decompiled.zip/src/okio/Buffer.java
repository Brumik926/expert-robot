package okio;

import h.ap;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.charset.Charset;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.Charsets;
import kotlin.text.Typography;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import org.apache.tika.fork.ForkServer;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000¶\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u001a\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\u0005\n\u0002\b\u0005\n\u0002\u0010\n\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0012\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0018\n\u0002\u0018\u0002\n\u0002\b\u0012\n\u0002\u0018\u0002\n\u0002\b\u001d\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\r\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u0004:\u0002Â\u0001B\u0007¢\u0006\u0004\b\u0005\u0010\u0006J\u000f\u0010\u0007\u001a\u00020\u0000H\u0016¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\f\u001a\u00020\u0000H\u0016¢\u0006\u0004\b\f\u0010\bJ\u000f\u0010\r\u001a\u00020\u0000H\u0016¢\u0006\u0004\b\r\u0010\bJ\u000f\u0010\u000f\u001a\u00020\u000eH\u0016¢\u0006\u0004\b\u000f\u0010\u0010J\u0017\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\b\u0014\u0010\u0015J\u0017\u0010\u0016\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\b\u0016\u0010\u0017J\u000f\u0010\u0018\u001a\u00020\u0001H\u0016¢\u0006\u0004\b\u0018\u0010\u0019J\u000f\u0010\u001b\u001a\u00020\u001aH\u0016¢\u0006\u0004\b\u001b\u0010\u001cJ'\u0010\u001f\u001a\u00020\u00002\u0006\u0010\u001d\u001a\u00020\u00002\b\b\u0002\u0010\u001e\u001a\u00020\u00112\u0006\u0010\u0012\u001a\u00020\u0011¢\u0006\u0004\b\u001f\u0010 J!\u0010!\u001a\u00020\u00002\u0006\u0010\u001d\u001a\u00020\t2\b\b\u0002\u0010\u0012\u001a\u00020\u0011H\u0007¢\u0006\u0004\b!\u0010\"J\r\u0010#\u001a\u00020\u0011¢\u0006\u0004\b#\u0010$J\u000f\u0010&\u001a\u00020%H\u0016¢\u0006\u0004\b&\u0010'J\u0018\u0010)\u001a\u00020%2\u0006\u0010(\u001a\u00020\u0011H\u0087\u0002¢\u0006\u0004\b)\u0010*J\u000f\u0010,\u001a\u00020+H\u0016¢\u0006\u0004\b,\u0010-J\u000f\u0010/\u001a\u00020.H\u0016¢\u0006\u0004\b/\u00100J\u000f\u00101\u001a\u00020\u0011H\u0016¢\u0006\u0004\b1\u0010$J\u000f\u00102\u001a\u00020+H\u0016¢\u0006\u0004\b2\u0010-J\u000f\u00103\u001a\u00020.H\u0016¢\u0006\u0004\b3\u00100J\u000f\u00104\u001a\u00020\u0011H\u0016¢\u0006\u0004\b4\u0010$J\u000f\u00105\u001a\u00020\u0011H\u0016¢\u0006\u0004\b5\u0010$J\u000f\u00106\u001a\u00020\u0011H\u0016¢\u0006\u0004\b6\u0010$J\u000f\u00108\u001a\u000207H\u0016¢\u0006\u0004\b8\u00109J\u0017\u0010:\u001a\u0002072\u0006\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\b:\u0010;J\u0017\u0010>\u001a\u00020.2\u0006\u0010=\u001a\u00020<H\u0016¢\u0006\u0004\b>\u0010?J\u001f\u0010A\u001a\u00020\u00132\u0006\u0010@\u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\bA\u0010BJ\u0017\u0010D\u001a\u00020\u00112\u0006\u0010@\u001a\u00020CH\u0016¢\u0006\u0004\bD\u0010EJ\u000f\u0010G\u001a\u00020FH\u0016¢\u0006\u0004\bG\u0010HJ\u0017\u0010I\u001a\u00020F2\u0006\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\bI\u0010JJ\u0017\u0010M\u001a\u00020F2\u0006\u0010L\u001a\u00020KH\u0016¢\u0006\u0004\bM\u0010NJ\u001f\u0010O\u001a\u00020F2\u0006\u0010\u0012\u001a\u00020\u00112\u0006\u0010L\u001a\u00020KH\u0016¢\u0006\u0004\bO\u0010PJ\u000f\u0010Q\u001a\u00020FH\u0016¢\u0006\u0004\bQ\u0010HJ\u0017\u0010S\u001a\u00020F2\u0006\u0010R\u001a\u00020\u0011H\u0016¢\u0006\u0004\bS\u0010JJ\u000f\u0010T\u001a\u00020.H\u0016¢\u0006\u0004\bT\u00100J\u000f\u0010V\u001a\u00020UH\u0016¢\u0006\u0004\bV\u0010WJ\u0017\u0010X\u001a\u00020U2\u0006\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\bX\u0010YJ\u0017\u0010Z\u001a\u00020\u00132\u0006\u0010@\u001a\u00020UH\u0016¢\u0006\u0004\bZ\u0010[J'\u0010\\\u001a\u00020.2\u0006\u0010@\u001a\u00020U2\u0006\u0010\u001e\u001a\u00020.2\u0006\u0010\u0012\u001a\u00020.H\u0016¢\u0006\u0004\b\\\u0010]J\u0017\u0010\\\u001a\u00020.2\u0006\u0010@\u001a\u00020^H\u0016¢\u0006\u0004\b\\\u0010_J\r\u0010`\u001a\u00020\u0013¢\u0006\u0004\b`\u0010\u0006J\u0017\u0010a\u001a\u00020\u00132\u0006\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\ba\u0010\u0015J\u0017\u0010c\u001a\u00020\u00002\u0006\u0010b\u001a\u000207H\u0016¢\u0006\u0004\bc\u0010dJ\u0017\u0010f\u001a\u00020\u00002\u0006\u0010e\u001a\u00020FH\u0016¢\u0006\u0004\bf\u0010gJ'\u0010j\u001a\u00020\u00002\u0006\u0010e\u001a\u00020F2\u0006\u0010h\u001a\u00020.2\u0006\u0010i\u001a\u00020.H\u0016¢\u0006\u0004\bj\u0010kJ\u0017\u0010m\u001a\u00020\u00002\u0006\u0010l\u001a\u00020.H\u0016¢\u0006\u0004\bm\u0010nJ/\u0010o\u001a\u00020\u00002\u0006\u0010e\u001a\u00020F2\u0006\u0010h\u001a\u00020.2\u0006\u0010i\u001a\u00020.2\u0006\u0010L\u001a\u00020KH\u0016¢\u0006\u0004\bo\u0010pJ\u0017\u0010r\u001a\u00020\u00002\u0006\u0010q\u001a\u00020UH\u0016¢\u0006\u0004\br\u0010sJ'\u0010t\u001a\u00020\u00002\u0006\u0010q\u001a\u00020U2\u0006\u0010\u001e\u001a\u00020.2\u0006\u0010\u0012\u001a\u00020.H\u0016¢\u0006\u0004\bt\u0010uJ\u0017\u0010v\u001a\u00020.2\u0006\u0010q\u001a\u00020^H\u0016¢\u0006\u0004\bv\u0010_J\u0017\u0010x\u001a\u00020\u00112\u0006\u0010q\u001a\u00020wH\u0016¢\u0006\u0004\bx\u0010yJ\u001f\u0010z\u001a\u00020\u00002\u0006\u0010q\u001a\u00020w2\u0006\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\bz\u0010{J\u0017\u0010}\u001a\u00020\u00002\u0006\u0010|\u001a\u00020.H\u0016¢\u0006\u0004\b}\u0010nJ\u0017\u0010\u007f\u001a\u00020\u00002\u0006\u0010~\u001a\u00020.H\u0016¢\u0006\u0004\b\u007f\u0010nJ\u001a\u0010\u0081\u0001\u001a\u00020\u00002\u0007\u0010\u0080\u0001\u001a\u00020.H\u0016¢\u0006\u0005\b\u0081\u0001\u0010nJ\u001a\u0010\u0082\u0001\u001a\u00020\u00002\u0007\u0010\u0080\u0001\u001a\u00020.H\u0016¢\u0006\u0005\b\u0082\u0001\u0010nJ\u001b\u0010\u0084\u0001\u001a\u00020\u00002\u0007\u0010\u0083\u0001\u001a\u00020\u0011H\u0016¢\u0006\u0006\b\u0084\u0001\u0010\u0085\u0001J\u001b\u0010\u0086\u0001\u001a\u00020\u00002\u0007\u0010\u0083\u0001\u001a\u00020\u0011H\u0016¢\u0006\u0006\b\u0086\u0001\u0010\u0085\u0001J\u001b\u0010\u0087\u0001\u001a\u00020\u00002\u0007\u0010\u0083\u0001\u001a\u00020\u0011H\u0016¢\u0006\u0006\b\u0087\u0001\u0010\u0085\u0001J\u001b\u0010\u0088\u0001\u001a\u00020\u00002\u0007\u0010\u0083\u0001\u001a\u00020\u0011H\u0016¢\u0006\u0006\b\u0088\u0001\u0010\u0085\u0001J\u001c\u0010\u008b\u0001\u001a\u00030\u008a\u00012\u0007\u0010\u0089\u0001\u001a\u00020.H\u0000¢\u0006\u0006\b\u008b\u0001\u0010\u008c\u0001J!\u0010\u008d\u0001\u001a\u00020\u00132\u0006\u0010q\u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0005\b\u008d\u0001\u0010BJ\"\u0010\u008e\u0001\u001a\u00020\u00112\u0006\u0010@\u001a\u00020\u00002\u0006\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0006\b\u008e\u0001\u0010\u008f\u0001J#\u0010\u0091\u0001\u001a\u00020\u00112\u0006\u0010|\u001a\u00020%2\u0007\u0010\u0090\u0001\u001a\u00020\u0011H\u0016¢\u0006\u0006\b\u0091\u0001\u0010\u0092\u0001J,\u0010\u0094\u0001\u001a\u00020\u00112\u0006\u0010|\u001a\u00020%2\u0007\u0010\u0090\u0001\u001a\u00020\u00112\u0007\u0010\u0093\u0001\u001a\u00020\u0011H\u0016¢\u0006\u0006\b\u0094\u0001\u0010\u0095\u0001J\u001b\u0010\u0097\u0001\u001a\u00020\u00112\u0007\u0010\u0096\u0001\u001a\u000207H\u0016¢\u0006\u0006\b\u0097\u0001\u0010\u0098\u0001J$\u0010\u0099\u0001\u001a\u00020\u00112\u0007\u0010\u0096\u0001\u001a\u0002072\u0007\u0010\u0090\u0001\u001a\u00020\u0011H\u0016¢\u0006\u0006\b\u0099\u0001\u0010\u009a\u0001J-\u0010\u009b\u0001\u001a\u00020\u00112\u0007\u0010\u0096\u0001\u001a\u0002072\u0007\u0010\u0090\u0001\u001a\u00020\u00112\u0007\u0010\u0093\u0001\u001a\u00020\u0011H\u0016¢\u0006\u0006\b\u009b\u0001\u0010\u009c\u0001J\u001b\u0010\u009e\u0001\u001a\u00020\u00112\u0007\u0010\u009d\u0001\u001a\u000207H\u0016¢\u0006\u0006\b\u009e\u0001\u0010\u0098\u0001J$\u0010\u009f\u0001\u001a\u00020\u00112\u0007\u0010\u009d\u0001\u001a\u0002072\u0007\u0010\u0090\u0001\u001a\u00020\u0011H\u0016¢\u0006\u0006\b\u009f\u0001\u0010\u009a\u0001J#\u0010 \u0001\u001a\u00020\u000e2\u0006\u0010\u001e\u001a\u00020\u00112\u0007\u0010\u0096\u0001\u001a\u000207H\u0016¢\u0006\u0006\b \u0001\u0010¡\u0001J4\u0010£\u0001\u001a\u00020\u000e2\u0006\u0010\u001e\u001a\u00020\u00112\u0007\u0010\u0096\u0001\u001a\u0002072\u0007\u0010¢\u0001\u001a\u00020.2\u0006\u0010\u0012\u001a\u00020.H\u0016¢\u0006\u0006\b£\u0001\u0010¤\u0001J\u0011\u0010¥\u0001\u001a\u00020\u0013H\u0016¢\u0006\u0005\b¥\u0001\u0010\u0006J\u0011\u0010¦\u0001\u001a\u00020\u000eH\u0016¢\u0006\u0005\b¦\u0001\u0010\u0010J\u0011\u0010§\u0001\u001a\u00020\u0013H\u0016¢\u0006\u0005\b§\u0001\u0010\u0006J\u0013\u0010©\u0001\u001a\u00030¨\u0001H\u0016¢\u0006\u0006\b©\u0001\u0010ª\u0001J\u001f\u0010\u00ad\u0001\u001a\u00020\u000e2\n\u0010¬\u0001\u001a\u0005\u0018\u00010«\u0001H\u0096\u0002¢\u0006\u0006\b\u00ad\u0001\u0010®\u0001J\u0011\u0010¯\u0001\u001a\u00020.H\u0016¢\u0006\u0005\b¯\u0001\u00100J\u0011\u0010°\u0001\u001a\u00020FH\u0016¢\u0006\u0005\b°\u0001\u0010HJ\u000f\u0010±\u0001\u001a\u00020\u0000¢\u0006\u0005\b±\u0001\u0010\bJ\u0011\u0010²\u0001\u001a\u00020\u0000H\u0016¢\u0006\u0005\b²\u0001\u0010\bJ\u000f\u0010³\u0001\u001a\u000207¢\u0006\u0005\b³\u0001\u00109J\u0018\u0010´\u0001\u001a\u0002072\u0006\u0010\u0012\u001a\u00020.¢\u0006\u0006\b´\u0001\u0010µ\u0001J\u001f\u0010¸\u0001\u001a\u00030¶\u00012\n\b\u0002\u0010·\u0001\u001a\u00030¶\u0001H\u0007¢\u0006\u0006\b¸\u0001\u0010¹\u0001R\u001c\u0010¼\u0001\u001a\u0005\u0018\u00010\u008a\u00018\u0000@\u0000X\u0081\u000e¢\u0006\b\n\u0006\bº\u0001\u0010»\u0001R/\u0010¾\u0001\u001a\u00020\u00112\u0007\u0010½\u0001\u001a\u00020\u00118\u0007@@X\u0086\u000e¢\u0006\u0015\n\u0005\b|\u0010\u009f\u0001\u001a\u0005\b¾\u0001\u0010$\"\u0005\b¿\u0001\u0010\u0015R\u0016\u0010Á\u0001\u001a\u00020\u00008VX\u0096\u0004¢\u0006\u0007\u001a\u0005\bÀ\u0001\u0010\b¨\u0006Ã\u0001"}, d2 = {"Lokio/Buffer;", "Lokio/BufferedSource;", "Lokio/BufferedSink;", StringUtils.EMPTY, "Ljava/nio/channels/ByteChannel;", "<init>", "()V", "x1", "()Lokio/Buffer;", "Ljava/io/OutputStream;", "s3", "()Ljava/io/OutputStream;", "A", "u", StringUtils.EMPTY, "H2", "()Z", StringUtils.EMPTY, "byteCount", StringUtils.EMPTY, "s2", "(J)V", "request", "(J)Z", "peek", "()Lokio/BufferedSource;", "Ljava/io/InputStream;", "inputStream", "()Ljava/io/InputStream;", "out", MimeTypesReaderMetKeys.MATCH_OFFSET_ATTR, "r", "(Lokio/Buffer;JJ)Lokio/Buffer;", "S0", "(Ljava/io/OutputStream;J)Lokio/Buffer;", "o", "()J", StringUtils.EMPTY, "readByte", "()B", "pos", "B", "(J)B", StringUtils.EMPTY, "readShort", "()S", StringUtils.EMPTY, "readInt", "()I", "readLong", "t0", "c3", "u0", "L2", "s1", "Lokio/ByteString;", "V", "()Lokio/ByteString;", "F0", "(J)Lokio/ByteString;", "Lokio/Options;", "options", "u3", "(Lokio/Options;)I", "sink", "N1", "(Lokio/Buffer;J)V", "Lokio/Sink;", "n1", "(Lokio/Sink;)J", StringUtils.EMPTY, "X", "()Ljava/lang/String;", "B0", "(J)Ljava/lang/String;", "Ljava/nio/charset/Charset;", "charset", "X0", "(Ljava/nio/charset/Charset;)Ljava/lang/String;", "W", "(JLjava/nio/charset/Charset;)Ljava/lang/String;", "j2", "limit", "R1", "a0", StringUtils.EMPTY, "K0", "()[B", "l2", "(J)[B", "readFully", "([B)V", "read", "([BII)I", "Ljava/nio/ByteBuffer;", "(Ljava/nio/ByteBuffer;)I", "j", "skip", "byteString", "m0", "(Lokio/ByteString;)Lokio/Buffer;", "string", "V0", "(Ljava/lang/String;)Lokio/Buffer;", "beginIndex", "endIndex", "W0", "(Ljava/lang/String;II)Lokio/Buffer;", "codePoint", "d1", "(I)Lokio/Buffer;", "O0", "(Ljava/lang/String;IILjava/nio/charset/Charset;)Lokio/Buffer;", ClimateForcast.SOURCE, "v0", "([B)Lokio/Buffer;", "w0", "([BII)Lokio/Buffer;", "write", "Lokio/Source;", "d2", "(Lokio/Source;)J", "o0", "(Lokio/Source;J)Lokio/Buffer;", "b", "x0", "s", "N0", "i", "E0", "H0", "v", "J0", "(J)Lokio/Buffer;", "M0", "z0", "C0", "minimumCapacity", "Lokio/Segment;", "j0", "(I)Lokio/Segment;", "a2", "k3", "(Lokio/Buffer;J)J", "fromIndex", "D", "(BJ)J", "toIndex", "O1", "(BJJ)J", "bytes", "L", "(Lokio/ByteString;)J", "I", "(Lokio/ByteString;J)J", "I2", "(Lokio/ByteString;JJ)J", "targetBytes", "R", "J", "Y", "(JLokio/ByteString;)Z", "bytesOffset", "O", "(JLokio/ByteString;II)Z", "flush", "isOpen", "close", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", StringUtils.EMPTY, "other", "equals", "(Ljava/lang/Object;)Z", "hashCode", "toString", "q", "k", "d0", "e0", "(I)Lokio/ByteString;", "Lokio/Buffer$UnsafeCursor;", "unsafeCursor", "P", "(Lokio/Buffer$UnsafeCursor;)Lokio/Buffer$UnsafeCursor;", "a", "Lokio/Segment;", "head", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "size", "b0", "getBuffer", "buffer", "UnsafeCursor", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nBuffer.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Buffer.kt\nokio/Buffer\n+ 2 Util.kt\nokio/-SegmentedByteString\n+ 3 Buffer.kt\nokio/internal/-Buffer\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 5 BufferedSource.kt\nokio/internal/-BufferedSource\n*L\n1#1,649:1\n90#2:650\n87#2:683\n87#2:685\n75#2:745\n75#2:771\n84#2:810\n78#2:821\n90#2:1014\n75#2:1029\n87#2:1133\n241#3,32:651\n276#3,10:686\n289#3,18:696\n411#3,2:714\n109#3:716\n413#3:717\n111#3,18:718\n310#3,9:736\n319#3,15:746\n337#3,10:761\n347#3,3:772\n345#3,25:775\n373#3,10:800\n383#3:811\n381#3,9:812\n390#3,7:822\n388#3,20:829\n651#3,60:849\n714#3,56:909\n772#3:965\n775#3:966\n776#3,6:968\n786#3,7:974\n796#3,6:984\n804#3,5:990\n836#3,6:995\n846#3:1001\n847#3,11:1003\n858#3,5:1015\n867#3,9:1020\n877#3,61:1030\n602#3:1091\n605#3:1092\n606#3,5:1094\n613#3:1099\n616#3,7:1100\n625#3,20:1107\n417#3:1127\n420#3,5:1128\n425#3,10:1134\n436#3,7:1144\n441#3,2:1151\n942#3:1153\n943#3,87:1155\n1033#3,48:1242\n572#3:1290\n579#3,21:1291\n1084#3,7:1312\n1094#3,7:1319\n1104#3,4:1326\n1111#3,8:1330\n1122#3,10:1338\n1135#3,14:1348\n446#3,35:1362\n512#3,40:1397\n555#3:1437\n557#3,13:1439\n1152#3:1452\n1203#3:1453\n1204#3,39:1455\n1245#3,2:1494\n1247#3,4:1497\n1254#3,3:1501\n1258#3,4:1505\n109#3:1509\n1262#3,22:1510\n111#3,18:1532\n1337#3,2:1550\n1340#3:1553\n109#3:1554\n1341#3,50:1555\n111#3,18:1605\n1400#3,12:1623\n1415#3,32:1635\n1450#3,12:1667\n1465#3,18:1679\n1487#3:1697\n1488#3:1699\n1493#3,34:1700\n1#4:684\n1#4:967\n1#4:1002\n1#4:1093\n1#4:1154\n1#4:1438\n1#4:1454\n1#4:1496\n1#4:1504\n1#4:1552\n1#4:1698\n27#5,3:981\n*S KotlinDebug\n*F\n+ 1 Buffer.kt\nokio/Buffer\n*L\n167#1:650\n197#1:683\n235#1:685\n261#1:745\n264#1:771\n267#1:810\n267#1:821\n337#1:1014\n340#1:1029\n376#1:1133\n181#1:651,32\n252#1:686,10\n255#1:696,18\n258#1:714,2\n258#1:716\n258#1:717\n258#1:718,18\n261#1:736,9\n261#1:746,15\n264#1:761,10\n264#1:772,3\n264#1:775,25\n267#1:800,10\n267#1:811\n267#1:812,9\n267#1:822,7\n267#1:829,20\n279#1:849,60\n282#1:909,56\n284#1:965\n287#1:966\n287#1:968,6\n289#1:974,7\n294#1:984,6\n297#1:990,5\n331#1:995,6\n337#1:1001\n337#1:1003,11\n337#1:1015,5\n340#1:1020,9\n340#1:1030,61\n342#1:1091\n345#1:1092\n345#1:1094,5\n347#1:1099\n350#1:1100,7\n353#1:1107,20\n373#1:1127\n376#1:1128,5\n376#1:1134,10\n378#1:1144,7\n381#1:1151,2\n386#1:1153\n386#1:1155,87\n389#1:1242,48\n412#1:1290\n418#1:1291,21\n439#1:1312,7\n443#1:1319,7\n445#1:1326,4\n447#1:1330,8\n451#1:1338,10\n455#1:1348,14\n459#1:1362,35\n462#1:1397,40\n465#1:1437\n465#1:1439,13\n467#1:1452\n467#1:1453\n467#1:1455,39\n469#1:1494,2\n469#1:1497,4\n480#1:1501,3\n480#1:1505,4\n480#1:1509\n480#1:1510,22\n480#1:1532,18\n496#1:1550,2\n496#1:1553\n496#1:1554\n496#1:1555,50\n496#1:1605,18\n506#1:1623,12\n576#1:1635,32\n578#1:1667,12\n586#1:1679,18\n594#1:1697\n594#1:1699\n596#1:1700,34\n287#1:967\n337#1:1002\n345#1:1093\n386#1:1154\n465#1:1438\n467#1:1454\n469#1:1496\n480#1:1504\n496#1:1552\n594#1:1698\n291#1:981,3\n*E\n"})
public final class Buffer implements BufferedSource, BufferedSink, Cloneable, ByteChannel {
    public Segment a;
    private long b;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0012\n\u0002\b\t\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\r\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006J\u0015\u0010\t\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\t\u0010\nJ\u0015\u0010\f\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\u0007¢\u0006\u0004\b\f\u0010\rJ\u0015\u0010\u000f\u001a\u00020\u00072\u0006\u0010\u000e\u001a\u00020\u0004¢\u0006\u0004\b\u000f\u0010\u0010J\u000f\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\b\u0012\u0010\u0003R\u0018\u0010\u0015\u001a\u0004\u0018\u00010\u00138\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b\u000f\u0010\u0014R\u0016\u0010\u0019\u001a\u00020\u00168\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b\u0017\u0010\u0018R$\u0010!\u001a\u0004\u0018\u00010\u001a8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u001d\u0010\u001e\"\u0004\b\u001f\u0010 R\u0016\u0010\b\u001a\u00020\u00078\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b\"\u0010#R\u0018\u0010'\u001a\u0004\u0018\u00010$8\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b%\u0010&R\u0016\u0010*\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b(\u0010)R\u0016\u0010,\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b+\u0010)¨\u0006-"}, d2 = {"Lokio/Buffer$UnsafeCursor;", "Ljava/io/Closeable;", "<init>", "()V", StringUtils.EMPTY, "k", "()I", StringUtils.EMPTY, MimeTypesReaderMetKeys.MATCH_OFFSET_ATTR, "q", "(J)I", "newSize", "o", "(J)J", "minByteCount", "a", "(I)J", StringUtils.EMPTY, "close", "Lokio/Buffer;", "Lokio/Buffer;", "buffer", StringUtils.EMPTY, "b", "Z", "readWrite", "Lokio/Segment;", "c", "Lokio/Segment;", "j", "()Lokio/Segment;", "r", "(Lokio/Segment;)V", "segment", "d", "J", StringUtils.EMPTY, "e", "[B", "data", "f", "I", "start", "g", "end", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nBuffer.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Buffer.kt\nokio/Buffer$UnsafeCursor\n+ 2 Buffer.kt\nokio/internal/-Buffer\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 Util.kt\nokio/-SegmentedByteString\n*L\n1#1,649:1\n1546#2:650\n1547#2:652\n1551#2:653\n1552#2,68:655\n1623#2:723\n1624#2,32:725\n1656#2,18:758\n1677#2:776\n1678#2,18:778\n1700#2:796\n1702#2,7:798\n1#3:651\n1#3:654\n1#3:724\n1#3:777\n1#3:797\n87#4:757\n*S KotlinDebug\n*F\n+ 1 Buffer.kt\nokio/Buffer$UnsafeCursor\n*L\n636#1:650\n636#1:652\n638#1:653\n638#1:655,68\n640#1:723\n640#1:725,32\n640#1:758,18\n642#1:776\n642#1:778,18\n645#1:796\n645#1:798,7\n636#1:651\n638#1:654\n640#1:724\n642#1:777\n645#1:797\n640#1:757\n*E\n"})
    public static final class UnsafeCursor implements Closeable {
        public Buffer a;
        public boolean b;
        private Segment c;
        public byte[] e;
        public long d = -1;
        public int f = -1;
        public int g = -1;

        public final long a(int i) {
            if (i <= 0) {
                throw new IllegalArgumentException((ap.a(633874813) + i).toString());
            }
            if (i > 8192) {
                throw new IllegalArgumentException((ap.a(512130940) + i).toString());
            }
            Buffer buffer = this.a;
            if (buffer == null) {
                throw new IllegalStateException(ap.a(840273644));
            }
            if (!this.b) {
                throw new IllegalStateException(ap.a(1508785419));
            }
            long size = buffer.size();
            Segment segmentJ0 = buffer.j0(i);
            int i2 = 8192 - segmentJ0.c;
            segmentJ0.c = 8192;
            long j = i2;
            buffer.b0(size + j);
            r(segmentJ0);
            this.d = size;
            this.e = segmentJ0.a;
            this.f = 8192 - i2;
            this.g = 8192;
            return j;
        }

        @Override // java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (this.a == null) {
                throw new IllegalStateException("not attached to a buffer");
            }
            this.a = null;
            r(null);
            this.d = -1L;
            this.e = null;
            this.f = -1;
            this.g = -1;
        }

        public final Segment j() {
            return this.c;
        }

        public final int k() {
            long j = this.d;
            Buffer buffer = this.a;
            Intrinsics.checkNotNull(buffer);
            if (j == buffer.size()) {
                throw new IllegalStateException("no more bytes");
            }
            long j2 = this.d;
            return q(j2 == -1 ? 0L : j2 + ((long) (this.g - this.f)));
        }

        public final long o(long j) {
            Buffer buffer = this.a;
            if (buffer == null) {
                throw new IllegalStateException("not attached to a buffer");
            }
            if (!this.b) {
                throw new IllegalStateException("resizeBuffer() only permitted for read/write buffers");
            }
            long size = buffer.size();
            if (j <= size) {
                if (j < 0) {
                    throw new IllegalArgumentException(("newSize < 0: " + j).toString());
                }
                long j2 = size - j;
                while (true) {
                    if (j2 <= 0) {
                        break;
                    }
                    Segment segment = buffer.a;
                    Intrinsics.checkNotNull(segment);
                    Segment segment2 = segment.g;
                    Intrinsics.checkNotNull(segment2);
                    int i = segment2.c;
                    long j3 = i - segment2.b;
                    if (j3 > j2) {
                        segment2.c = i - ((int) j2);
                        break;
                    }
                    buffer.a = segment2.b();
                    SegmentPool.b(segment2);
                    j2 -= j3;
                }
                r(null);
                this.d = j;
                this.e = null;
                this.f = -1;
                this.g = -1;
            } else if (j > size) {
                long j4 = j - size;
                boolean z = true;
                while (j4 > 0) {
                    Segment segmentJ0 = buffer.j0(1);
                    int iMin = (int) Math.min(j4, 8192 - segmentJ0.c);
                    segmentJ0.c += iMin;
                    j4 -= (long) iMin;
                    if (z) {
                        r(segmentJ0);
                        this.d = size;
                        this.e = segmentJ0.a;
                        int i2 = segmentJ0.c;
                        this.f = i2 - iMin;
                        this.g = i2;
                        z = false;
                    }
                }
            }
            buffer.b0(j);
            return size;
        }

        public final int q(long j) {
            Segment segmentC;
            Buffer buffer = this.a;
            if (buffer == null) {
                throw new IllegalStateException("not attached to a buffer");
            }
            if (j < -1 || j > buffer.size()) {
                throw new ArrayIndexOutOfBoundsException("offset=" + j + " > size=" + buffer.size());
            }
            if (j == -1 || j == buffer.size()) {
                r(null);
                this.d = j;
                this.e = null;
                this.f = -1;
                this.g = -1;
                return -1;
            }
            long size = buffer.size();
            Segment segmentJ = buffer.a;
            long j2 = 0;
            if (j() != null) {
                long j3 = this.d;
                int i = this.f;
                Segment segmentJ2 = j();
                Intrinsics.checkNotNull(segmentJ2);
                long j4 = j3 - ((long) (i - segmentJ2.b));
                if (j4 > j) {
                    segmentC = segmentJ;
                    segmentJ = j();
                    size = j4;
                } else {
                    segmentC = j();
                    j2 = j4;
                }
            } else {
                segmentC = segmentJ;
            }
            if (size - j > j - j2) {
                while (true) {
                    Intrinsics.checkNotNull(segmentC);
                    int i2 = segmentC.c;
                    int i3 = segmentC.b;
                    if (j < ((long) (i2 - i3)) + j2) {
                        break;
                    }
                    j2 += (long) (i2 - i3);
                    segmentC = segmentC.f;
                }
            } else {
                while (size > j) {
                    Intrinsics.checkNotNull(segmentJ);
                    segmentJ = segmentJ.g;
                    Intrinsics.checkNotNull(segmentJ);
                    size -= (long) (segmentJ.c - segmentJ.b);
                }
                j2 = size;
                segmentC = segmentJ;
            }
            if (this.b) {
                Intrinsics.checkNotNull(segmentC);
                if (segmentC.d) {
                    Segment segmentF = segmentC.f();
                    if (buffer.a == segmentC) {
                        buffer.a = segmentF;
                    }
                    segmentC = segmentC.c(segmentF);
                    Segment segment = segmentC.g;
                    Intrinsics.checkNotNull(segment);
                    segment.b();
                }
            }
            r(segmentC);
            this.d = j;
            Intrinsics.checkNotNull(segmentC);
            this.e = segmentC.a;
            int i4 = segmentC.b + ((int) (j - j2));
            this.f = i4;
            int i5 = segmentC.c;
            this.g = i5;
            return i5 - i4;
        }

        public final void r(Segment segment) {
            this.c = segment;
        }
    }

    public static /* synthetic */ UnsafeCursor Q(Buffer buffer, UnsafeCursor unsafeCursor, int i, Object obj) {
        if ((i & 1) != 0) {
            unsafeCursor = new UnsafeCursor();
        }
        return buffer.P(unsafeCursor);
    }

    public static /* synthetic */ Buffer U0(Buffer buffer, OutputStream outputStream, long j, int i, Object obj) {
        if ((i & 2) != 0) {
            j = buffer.b;
        }
        return buffer.S0(outputStream, j);
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: A, reason: merged with bridge method [inline-methods] */
    public Buffer P1() {
        return this;
    }

    public final byte B(long j) {
        SegmentedByteString.b(size(), j, 1L);
        Segment segment = this.a;
        if (segment == null) {
            Intrinsics.checkNotNull((Object) null);
            throw null;
        }
        if (size() - j < j) {
            long size = size();
            while (size > j) {
                segment = segment.g;
                Intrinsics.checkNotNull(segment);
                size -= (long) (segment.c - segment.b);
            }
            Intrinsics.checkNotNull(segment);
            return segment.a[(int) ((((long) segment.b) + j) - size)];
        }
        long j2 = 0;
        while (true) {
            long j3 = ((long) (segment.c - segment.b)) + j2;
            if (j3 > j) {
                Intrinsics.checkNotNull(segment);
                return segment.a[(int) ((((long) segment.b) + j) - j2)];
            }
            segment = segment.f;
            Intrinsics.checkNotNull(segment);
            j2 = j3;
        }
    }

    @Override // okio.BufferedSource
    public String B0(long j) throws EOFException {
        return W(j, Charsets.UTF_8);
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: C0, reason: merged with bridge method [inline-methods] */
    public Buffer b1(long j) {
        if (j == 0) {
            return writeByte(48);
        }
        long j2 = (j >>> 1) | j;
        long j3 = j2 | (j2 >>> 2);
        long j4 = j3 | (j3 >>> 4);
        long j5 = j4 | (j4 >>> 8);
        long j6 = j5 | (j5 >>> 16);
        long j7 = j6 | (j6 >>> 32);
        long j8 = j7 - ((j7 >>> 1) & 6148914691236517205L);
        long j9 = ((j8 >>> 2) & 3689348814741910323L) + (j8 & 3689348814741910323L);
        long j10 = ((j9 >>> 4) + j9) & 1085102592571150095L;
        long j11 = j10 + (j10 >>> 8);
        long j12 = j11 + (j11 >>> 16);
        int i = (int) ((((j12 & 63) + ((j12 >>> 32) & 63)) + ((long) 3)) / ((long) 4));
        Segment segmentJ0 = j0(i);
        byte[] bArr = segmentJ0.a;
        int i2 = segmentJ0.c;
        for (int i3 = (i2 + i) - 1; i3 >= i2; i3--) {
            bArr[i3] = okio.internal.Buffer.f()[(int) (15 & j)];
            j >>>= 4;
        }
        segmentJ0.c += i;
        b0(size() + ((long) i));
        return this;
    }

    public long D(byte b, long j) {
        return O1(b, j, Long.MAX_VALUE);
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: E0, reason: merged with bridge method [inline-methods] */
    public Buffer writeInt(int i) {
        Segment segmentJ0 = j0(4);
        byte[] bArr = segmentJ0.a;
        int i2 = segmentJ0.c;
        bArr[i2] = (byte) ((i >>> 24) & 255);
        bArr[i2 + 1] = (byte) ((i >>> 16) & 255);
        bArr[i2 + 2] = (byte) ((i >>> 8) & 255);
        bArr[i2 + 3] = (byte) (i & 255);
        segmentJ0.c = i2 + 4;
        b0(size() + 4);
        return this;
    }

    @Override // okio.BufferedSource
    public ByteString F0(long j) throws EOFException {
        if (j < 0 || j > 2147483647L) {
            throw new IllegalArgumentException((ap.a(185039730) + j).toString());
        }
        if (size() < j) {
            throw new EOFException();
        }
        if (j < 4096) {
            return new ByteString(l2(j));
        }
        ByteString byteStringE0 = e0((int) j);
        skip(j);
        return byteStringE0;
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: H0, reason: merged with bridge method [inline-methods] */
    public Buffer L0(int i) {
        return writeInt(SegmentedByteString.c(i));
    }

    @Override // okio.BufferedSource
    public boolean H2() {
        return this.b == 0;
    }

    public long I(ByteString byteString, long j) {
        Intrinsics.checkNotNullParameter(byteString, "bytes");
        return I2(byteString, j, Long.MAX_VALUE);
    }

    @Override // okio.BufferedSource
    public long I2(ByteString byteString, long j, long j2) {
        Intrinsics.checkNotNullParameter(byteString, "bytes");
        return okio.internal.Buffer.c(this, byteString, j, j2, 0, 0, 24, null);
    }

    public long J(ByteString byteString, long j) {
        int i;
        int i2;
        Intrinsics.checkNotNullParameter(byteString, "targetBytes");
        long size = 0;
        if (j < 0) {
            throw new IllegalArgumentException(("fromIndex < 0: " + j).toString());
        }
        Segment segment = this.a;
        if (segment == null) {
            return -1L;
        }
        if (size() - j < j) {
            size = size();
            while (size > j) {
                segment = segment.g;
                Intrinsics.checkNotNull(segment);
                size -= (long) (segment.c - segment.b);
            }
            if (byteString.size() == 2) {
                byte bG = byteString.g(0);
                byte bG2 = byteString.g(1);
                while (size < size()) {
                    byte[] bArr = segment.a;
                    i = (int) ((((long) segment.b) + j) - size);
                    int i3 = segment.c;
                    while (i < i3) {
                        byte b = bArr[i];
                        if (b == bG || b == bG2) {
                            i2 = segment.b;
                        } else {
                            i++;
                        }
                    }
                    size += (long) (segment.c - segment.b);
                    segment = segment.f;
                    Intrinsics.checkNotNull(segment);
                    j = size;
                }
            } else {
                byte[] bArrP = byteString.p();
                while (size < size()) {
                    byte[] bArr2 = segment.a;
                    i = (int) ((((long) segment.b) + j) - size);
                    int i4 = segment.c;
                    while (i < i4) {
                        byte b2 = bArr2[i];
                        for (byte b3 : bArrP) {
                            if (b2 == b3) {
                                i2 = segment.b;
                            }
                        }
                        i++;
                    }
                    size += (long) (segment.c - segment.b);
                    segment = segment.f;
                    Intrinsics.checkNotNull(segment);
                    j = size;
                }
            }
            return -1L;
        }
        while (true) {
            long j2 = ((long) (segment.c - segment.b)) + size;
            if (j2 > j) {
                break;
            }
            segment = segment.f;
            Intrinsics.checkNotNull(segment);
            size = j2;
        }
        if (byteString.size() == 2) {
            byte bG3 = byteString.g(0);
            byte bG4 = byteString.g(1);
            while (size < size()) {
                byte[] bArr3 = segment.a;
                i = (int) ((((long) segment.b) + j) - size);
                int i5 = segment.c;
                while (i < i5) {
                    byte b4 = bArr3[i];
                    if (b4 == bG3 || b4 == bG4) {
                        i2 = segment.b;
                    } else {
                        i++;
                    }
                }
                size += (long) (segment.c - segment.b);
                segment = segment.f;
                Intrinsics.checkNotNull(segment);
                j = size;
            }
        } else {
            byte[] bArrP2 = byteString.p();
            while (size < size()) {
                byte[] bArr4 = segment.a;
                i = (int) ((((long) segment.b) + j) - size);
                int i6 = segment.c;
                while (i < i6) {
                    byte b5 = bArr4[i];
                    for (byte b6 : bArrP2) {
                        if (b5 == b6) {
                            i2 = segment.b;
                        }
                    }
                    i++;
                }
                size += (long) (segment.c - segment.b);
                segment = segment.f;
                Intrinsics.checkNotNull(segment);
                j = size;
            }
        }
        return -1L;
        return ((long) (i - i2)) + size;
    }

    public Buffer J0(long j) {
        Segment segmentJ0 = j0(8);
        byte[] bArr = segmentJ0.a;
        int i = segmentJ0.c;
        bArr[i] = (byte) ((j >>> 56) & 255);
        bArr[i + 1] = (byte) ((j >>> 48) & 255);
        bArr[i + 2] = (byte) ((j >>> 40) & 255);
        bArr[i + 3] = (byte) ((j >>> 32) & 255);
        bArr[i + 4] = (byte) ((j >>> 24) & 255);
        bArr[i + 5] = (byte) ((j >>> 16) & 255);
        bArr[i + 6] = (byte) ((j >>> 8) & 255);
        bArr[i + 7] = (byte) (j & 255);
        segmentJ0.c = i + 8;
        b0(size() + 8);
        return this;
    }

    @Override // okio.BufferedSource
    public byte[] K0() {
        return l2(size());
    }

    @Override // okio.BufferedSource
    public long L(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "bytes");
        return I(byteString, 0L);
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x0045, code lost:
    
        r0 = new okio.Buffer().z0(r8).x0(r15);
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0052, code lost:
    
        if (r2 != false) goto L22;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0054, code lost:
    
        r0.readByte();
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0071, code lost:
    
        throw new java.lang.NumberFormatException("Number too large: " + r0.X());
     */
    @Override // okio.BufferedSource
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public long L2() throws java.io.EOFException {
        /*
            Method dump skipped, instruction units count: 246
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: okio.Buffer.L2():long");
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: M0, reason: merged with bridge method [inline-methods] */
    public Buffer H(long j) {
        return J0(SegmentedByteString.d(j));
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: N0, reason: merged with bridge method [inline-methods] */
    public Buffer writeShort(int i) {
        Segment segmentJ0 = j0(2);
        byte[] bArr = segmentJ0.a;
        int i2 = segmentJ0.c;
        bArr[i2] = (byte) ((i >>> 8) & 255);
        bArr[i2 + 1] = (byte) (i & 255);
        segmentJ0.c = i2 + 2;
        b0(size() + 2);
        return this;
    }

    @Override // okio.BufferedSource
    public void N1(Buffer buffer, long j) throws EOFException {
        Intrinsics.checkNotNullParameter(buffer, "sink");
        if (size() >= j) {
            buffer.a2(this, j);
        } else {
            buffer.a2(this, size());
            throw new EOFException();
        }
    }

    public boolean O(long j, ByteString byteString, int i, int i2) {
        Intrinsics.checkNotNullParameter(byteString, "bytes");
        return i2 >= 0 && j >= 0 && ((long) i2) + j <= size() && i >= 0 && i + i2 <= byteString.size() && (i2 == 0 || okio.internal.Buffer.b(this, byteString, j, j + 1, i, i2) != -1);
    }

    public Buffer O0(String str, int i, int i2, Charset charset) {
        Intrinsics.checkNotNullParameter(str, "string");
        Intrinsics.checkNotNullParameter(charset, "charset");
        if (i < 0) {
            throw new IllegalArgumentException(("beginIndex < 0: " + i).toString());
        }
        if (i2 < i) {
            throw new IllegalArgumentException(("endIndex < beginIndex: " + i2 + " < " + i).toString());
        }
        if (i2 > str.length()) {
            throw new IllegalArgumentException(("endIndex > string.length: " + i2 + " > " + str.length()).toString());
        }
        if (Intrinsics.areEqual(charset, Charsets.UTF_8)) {
            return f0(str, i, i2);
        }
        String strSubstring = str.substring(i, i2);
        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        byte[] bytes = strSubstring.getBytes(charset);
        Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
        return write(bytes, 0, bytes.length);
    }

    @Override // okio.BufferedSource
    public long O1(byte b, long j, long j2) {
        Segment segment;
        int i;
        long size = 0;
        if (0 > j || j > j2) {
            throw new IllegalArgumentException(("size=" + size() + " fromIndex=" + j + " toIndex=" + j2).toString());
        }
        if (j2 > size()) {
            j2 = size();
        }
        if (j == j2 || (segment = this.a) == null) {
            return -1L;
        }
        if (size() - j < j) {
            size = size();
            while (size > j) {
                segment = segment.g;
                Intrinsics.checkNotNull(segment);
                size -= (long) (segment.c - segment.b);
            }
            while (size < j2) {
                byte[] bArr = segment.a;
                int iMin = (int) Math.min(segment.c, (((long) segment.b) + j2) - size);
                i = (int) ((((long) segment.b) + j) - size);
                while (i < iMin) {
                    if (bArr[i] != b) {
                        i++;
                    }
                }
                size += (long) (segment.c - segment.b);
                segment = segment.f;
                Intrinsics.checkNotNull(segment);
                j = size;
            }
            return -1L;
        }
        while (true) {
            long j3 = ((long) (segment.c - segment.b)) + size;
            if (j3 > j) {
                break;
            }
            segment = segment.f;
            Intrinsics.checkNotNull(segment);
            size = j3;
        }
        while (size < j2) {
            byte[] bArr2 = segment.a;
            int iMin2 = (int) Math.min(segment.c, (((long) segment.b) + j2) - size);
            i = (int) ((((long) segment.b) + j) - size);
            while (i < iMin2) {
                if (bArr2[i] != b) {
                    i++;
                }
            }
            size += (long) (segment.c - segment.b);
            segment = segment.f;
            Intrinsics.checkNotNull(segment);
            j = size;
        }
        return -1L;
        return ((long) (i - segment.b)) + size;
    }

    public final UnsafeCursor P(UnsafeCursor unsafeCursor) {
        Intrinsics.checkNotNullParameter(unsafeCursor, "unsafeCursor");
        return okio.internal.Buffer.d(this, unsafeCursor);
    }

    @Override // okio.BufferedSource
    public long R(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "targetBytes");
        return J(byteString, 0L);
    }

    @Override // okio.BufferedSource
    public String R1(long j) throws EOFException {
        if (j < 0) {
            throw new IllegalArgumentException(("limit < 0: " + j).toString());
        }
        long j2 = j != Long.MAX_VALUE ? j + 1 : Long.MAX_VALUE;
        long jO1 = O1((byte) 10, 0L, j2);
        if (jO1 != -1) {
            return okio.internal.Buffer.h(this, jO1);
        }
        if (j2 < size() && B(j2 - 1) == 13 && B(j2) == 10) {
            return okio.internal.Buffer.h(this, j2);
        }
        Buffer buffer = new Buffer();
        r(buffer, 0L, Math.min(32, size()));
        throw new EOFException("\\n not found: limit=" + Math.min(size(), j) + " content=" + buffer.V().l() + Typography.ellipsis);
    }

    public final Buffer S0(OutputStream outputStream, long j) throws IOException {
        Intrinsics.checkNotNullParameter(outputStream, "out");
        SegmentedByteString.b(this.b, 0L, j);
        Segment segment = this.a;
        long j2 = j;
        while (j2 > 0) {
            Intrinsics.checkNotNull(segment);
            int iMin = (int) Math.min(j2, segment.c - segment.b);
            outputStream.write(segment.a, segment.b, iMin);
            int i = segment.b + iMin;
            segment.b = i;
            long j3 = iMin;
            this.b -= j3;
            j2 -= j3;
            if (i == segment.c) {
                Segment segmentB = segment.b();
                this.a = segmentB;
                SegmentPool.b(segment);
                segment = segmentB;
            }
        }
        return this;
    }

    public ByteString V() {
        return F0(size());
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: V0, reason: merged with bridge method [inline-methods] */
    public Buffer V1(String str) {
        Intrinsics.checkNotNullParameter(str, "string");
        return f0(str, 0, str.length());
    }

    public String W(long j, Charset charset) throws EOFException {
        Intrinsics.checkNotNullParameter(charset, "charset");
        if (j < 0 || j > 2147483647L) {
            throw new IllegalArgumentException(("byteCount: " + j).toString());
        }
        if (this.b < j) {
            throw new EOFException();
        }
        if (j == 0) {
            return StringUtils.EMPTY;
        }
        Segment segment = this.a;
        Intrinsics.checkNotNull(segment);
        int i = segment.b;
        if (((long) i) + j > segment.c) {
            return new String(l2(j), charset);
        }
        int i2 = (int) j;
        String str = new String(segment.a, i, i2, charset);
        int i3 = segment.b + i2;
        segment.b = i3;
        this.b -= j;
        if (i3 == segment.c) {
            this.a = segment.b();
            SegmentPool.b(segment);
        }
        return str;
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: W0, reason: merged with bridge method [inline-methods] */
    public Buffer f0(String str, int i, int i2) {
        char cCharAt;
        Intrinsics.checkNotNullParameter(str, "string");
        if (i < 0) {
            throw new IllegalArgumentException(("beginIndex < 0: " + i).toString());
        }
        if (i2 < i) {
            throw new IllegalArgumentException(("endIndex < beginIndex: " + i2 + " < " + i).toString());
        }
        if (i2 > str.length()) {
            throw new IllegalArgumentException(("endIndex > string.length: " + i2 + " > " + str.length()).toString());
        }
        while (i < i2) {
            char cCharAt2 = str.charAt(i);
            if (cCharAt2 < 128) {
                Segment segmentJ0 = j0(1);
                byte[] bArr = segmentJ0.a;
                int i3 = segmentJ0.c - i;
                int iMin = Math.min(i2, 8192 - i3);
                int i4 = i + 1;
                bArr[i + i3] = (byte) cCharAt2;
                while (true) {
                    i = i4;
                    if (i >= iMin || (cCharAt = str.charAt(i)) >= 128) {
                        break;
                    }
                    i4 = i + 1;
                    bArr[i + i3] = (byte) cCharAt;
                }
                int i5 = segmentJ0.c;
                int i6 = (i3 + i) - i5;
                segmentJ0.c = i5 + i6;
                b0(size() + ((long) i6));
            } else {
                if (cCharAt2 < 2048) {
                    Segment segmentJ02 = j0(2);
                    byte[] bArr2 = segmentJ02.a;
                    int i7 = segmentJ02.c;
                    bArr2[i7] = (byte) ((cCharAt2 >> 6) | 192);
                    bArr2[i7 + 1] = (byte) ((cCharAt2 & '?') | 128);
                    segmentJ02.c = i7 + 2;
                    b0(size() + 2);
                } else if (cCharAt2 < 55296 || cCharAt2 > 57343) {
                    Segment segmentJ03 = j0(3);
                    byte[] bArr3 = segmentJ03.a;
                    int i8 = segmentJ03.c;
                    bArr3[i8] = (byte) ((cCharAt2 >> '\f') | 224);
                    bArr3[i8 + 1] = (byte) ((63 & (cCharAt2 >> 6)) | 128);
                    bArr3[i8 + 2] = (byte) ((cCharAt2 & '?') | 128);
                    segmentJ03.c = i8 + 3;
                    b0(size() + 3);
                } else {
                    int i9 = i + 1;
                    char cCharAt3 = i9 < i2 ? str.charAt(i9) : (char) 0;
                    if (cCharAt2 > 56319 || 56320 > cCharAt3 || cCharAt3 >= 57344) {
                        writeByte(63);
                        i = i9;
                    } else {
                        int i10 = (((cCharAt2 & 1023) << 10) | (cCharAt3 & 1023)) + 65536;
                        Segment segmentJ04 = j0(4);
                        byte[] bArr4 = segmentJ04.a;
                        int i11 = segmentJ04.c;
                        bArr4[i11] = (byte) ((i10 >> 18) | 240);
                        bArr4[i11 + 1] = (byte) (((i10 >> 12) & 63) | 128);
                        bArr4[i11 + 2] = (byte) (((i10 >> 6) & 63) | 128);
                        bArr4[i11 + 3] = (byte) ((i10 & 63) | 128);
                        segmentJ04.c = i11 + 4;
                        b0(size() + 4);
                        i += 2;
                    }
                }
                i++;
            }
        }
        return this;
    }

    public String X() {
        return W(this.b, Charsets.UTF_8);
    }

    @Override // okio.BufferedSource
    public String X0(Charset charset) {
        Intrinsics.checkNotNullParameter(charset, "charset");
        return W(this.b, charset);
    }

    @Override // okio.BufferedSource
    public boolean Y(long j, ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "bytes");
        return O(j, byteString, 0, byteString.size());
    }

    public int a0() throws EOFException {
        int i;
        int i2;
        int i3;
        if (size() == 0) {
            throw new EOFException();
        }
        byte B = B(0L);
        if ((B & 128) == 0) {
            i = B & AbstractJsonLexerKt.TC_INVALID;
            i3 = 0;
            i2 = 1;
        } else if ((B & 224) == 192) {
            i = B & 31;
            i2 = 2;
            i3 = 128;
        } else if ((B & 240) == 224) {
            i = B & 15;
            i2 = 3;
            i3 = 2048;
        } else {
            if ((B & 248) != 240) {
                skip(1L);
                return 65533;
            }
            i = B & 7;
            i2 = 4;
            i3 = 65536;
        }
        long j = i2;
        if (size() < j) {
            throw new EOFException("size < " + i2 + ": " + size() + " (to read code point prefixed 0x" + SegmentedByteString.f(B) + ')');
        }
        for (int i4 = 1; i4 < i2; i4++) {
            long j2 = i4;
            byte B2 = B(j2);
            if ((B2 & 192) != 128) {
                skip(j2);
                return 65533;
            }
            i = (i << 6) | (B2 & 63);
        }
        skip(j);
        if (i > 1114111) {
            return 65533;
        }
        if ((55296 > i || i >= 57344) && i >= i3) {
            return i;
        }
        return 65533;
    }

    @Override // okio.Sink
    public void a2(Buffer buffer, long j) {
        Segment segment;
        Intrinsics.checkNotNullParameter(buffer, ClimateForcast.SOURCE);
        if (buffer == this) {
            throw new IllegalArgumentException("source == this");
        }
        SegmentedByteString.b(buffer.size(), 0L, j);
        while (j > 0) {
            Segment segment2 = buffer.a;
            Intrinsics.checkNotNull(segment2);
            int i = segment2.c;
            Intrinsics.checkNotNull(buffer.a);
            if (j < i - r1.b) {
                Segment segment3 = this.a;
                if (segment3 != null) {
                    Intrinsics.checkNotNull(segment3);
                    segment = segment3.g;
                } else {
                    segment = null;
                }
                if (segment != null && segment.e) {
                    if ((((long) segment.c) + j) - ((long) (segment.d ? 0 : segment.b)) <= 8192) {
                        Segment segment4 = buffer.a;
                        Intrinsics.checkNotNull(segment4);
                        segment4.g(segment, (int) j);
                        buffer.b0(buffer.size() - j);
                        b0(size() + j);
                        return;
                    }
                }
                Segment segment5 = buffer.a;
                Intrinsics.checkNotNull(segment5);
                buffer.a = segment5.e((int) j);
            }
            Segment segment6 = buffer.a;
            Intrinsics.checkNotNull(segment6);
            long j2 = segment6.c - segment6.b;
            buffer.a = segment6.b();
            Segment segment7 = this.a;
            if (segment7 == null) {
                this.a = segment6;
                segment6.g = segment6;
                segment6.f = segment6;
            } else {
                Intrinsics.checkNotNull(segment7);
                Segment segment8 = segment7.g;
                Intrinsics.checkNotNull(segment8);
                segment8.c(segment6).a();
            }
            buffer.b0(buffer.size() - j2);
            b0(size() + j2);
            j -= j2;
        }
    }

    public final void b0(long j) {
        this.b = j;
    }

    @Override // okio.BufferedSource
    public int c3() {
        return SegmentedByteString.c(readInt());
    }

    @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
    }

    public final ByteString d0() {
        if (size() <= 2147483647L) {
            return e0((int) size());
        }
        throw new IllegalStateException(("size > Int.MAX_VALUE: " + size()).toString());
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: d1, reason: merged with bridge method [inline-methods] */
    public Buffer C1(int i) {
        if (i < 128) {
            writeByte(i);
            return this;
        }
        if (i < 2048) {
            Segment segmentJ0 = j0(2);
            byte[] bArr = segmentJ0.a;
            int i2 = segmentJ0.c;
            bArr[i2] = (byte) ((i >> 6) | 192);
            bArr[i2 + 1] = (byte) ((i & 63) | 128);
            segmentJ0.c = i2 + 2;
            b0(size() + 2);
            return this;
        }
        if (55296 <= i && i < 57344) {
            writeByte(63);
            return this;
        }
        if (i < 65536) {
            Segment segmentJ02 = j0(3);
            byte[] bArr2 = segmentJ02.a;
            int i3 = segmentJ02.c;
            bArr2[i3] = (byte) ((i >> 12) | 224);
            bArr2[i3 + 1] = (byte) (((i >> 6) & 63) | 128);
            bArr2[i3 + 2] = (byte) ((i & 63) | 128);
            segmentJ02.c = i3 + 3;
            b0(size() + 3);
            return this;
        }
        if (i > 1114111) {
            throw new IllegalArgumentException("Unexpected code point: 0x" + SegmentedByteString.g(i));
        }
        Segment segmentJ03 = j0(4);
        byte[] bArr3 = segmentJ03.a;
        int i4 = segmentJ03.c;
        bArr3[i4] = (byte) ((i >> 18) | 240);
        bArr3[i4 + 1] = (byte) (((i >> 12) & 63) | 128);
        bArr3[i4 + 2] = (byte) (((i >> 6) & 63) | 128);
        bArr3[i4 + 3] = (byte) ((i & 63) | 128);
        segmentJ03.c = i4 + 4;
        b0(size() + 4);
        return this;
    }

    @Override // okio.BufferedSink
    public long d2(Source source) {
        Intrinsics.checkNotNullParameter(source, ClimateForcast.SOURCE);
        long j = 0;
        while (true) {
            long jK3 = source.k3(this, 8192L);
            if (jK3 == -1) {
                return j;
            }
            j += jK3;
        }
    }

    public final ByteString e0(int i) {
        if (i == 0) {
            return ByteString.e;
        }
        SegmentedByteString.b(size(), 0L, i);
        Segment segment = this.a;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (i3 < i) {
            Intrinsics.checkNotNull(segment);
            int i5 = segment.c;
            int i6 = segment.b;
            if (i5 == i6) {
                throw new AssertionError("s.limit == s.pos");
            }
            i3 += i5 - i6;
            i4++;
            segment = segment.f;
        }
        byte[][] bArr = new byte[i4][];
        int[] iArr = new int[i4 * 2];
        Segment segment2 = this.a;
        int i7 = 0;
        while (i2 < i) {
            Intrinsics.checkNotNull(segment2);
            bArr[i7] = segment2.a;
            i2 += segment2.c - segment2.b;
            iArr[i7] = Math.min(i2, i);
            iArr[i7 + i4] = segment2.b;
            segment2.d = true;
            i7++;
            segment2 = segment2.f;
        }
        return new C0104SegmentedByteString(bArr, iArr);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Buffer)) {
            return false;
        }
        Buffer buffer = (Buffer) obj;
        if (size() != buffer.size()) {
            return false;
        }
        if (size() == 0) {
            return true;
        }
        Segment segment = this.a;
        Intrinsics.checkNotNull(segment);
        Segment segment2 = buffer.a;
        Intrinsics.checkNotNull(segment2);
        int i = segment.b;
        int i2 = segment2.b;
        long j = 0;
        while (j < size()) {
            long jMin = Math.min(segment.c - i, segment2.c - i2);
            long j2 = 0;
            while (j2 < jMin) {
                int i3 = i + 1;
                int i4 = i2 + 1;
                if (segment.a[i] != segment2.a[i2]) {
                    return false;
                }
                j2++;
                i = i3;
                i2 = i4;
            }
            if (i == segment.c) {
                segment = segment.f;
                Intrinsics.checkNotNull(segment);
                i = segment.b;
            }
            if (i2 == segment2.c) {
                segment2 = segment2.f;
                Intrinsics.checkNotNull(segment2);
                i2 = segment2.b;
            }
            j += jMin;
        }
        return true;
    }

    @Override // okio.BufferedSink, okio.Sink, java.io.Flushable
    public void flush() {
    }

    @Override // okio.BufferedSource, okio.BufferedSink
    public Buffer getBuffer() {
        return this;
    }

    public int hashCode() {
        Segment segment = this.a;
        if (segment == null) {
            return 0;
        }
        int i = 1;
        do {
            int i2 = segment.c;
            for (int i3 = segment.b; i3 < i2; i3++) {
                i = (i * 31) + segment.a[i3];
            }
            segment = segment.f;
            Intrinsics.checkNotNull(segment);
        } while (segment != this.a);
        return i;
    }

    @Override // okio.BufferedSource
    public InputStream inputStream() {
        return new InputStream() { // from class: okio.Buffer.inputStream.1
            @Override // java.io.InputStream
            public int available() {
                return (int) Math.min(Buffer.this.size(), Integer.MAX_VALUE);
            }

            @Override // java.io.InputStream, java.io.Closeable, java.lang.AutoCloseable
            public void close() {
            }

            @Override // java.io.InputStream
            public int read() {
                if (Buffer.this.size() > 0) {
                    return Buffer.this.readByte() & ForkServer.ERROR;
                }
                return -1;
            }

            public String toString() {
                return Buffer.this + ".inputStream()";
            }

            @Override // java.io.InputStream
            public int read(byte[] bArr, int i, int i2) {
                Intrinsics.checkNotNullParameter(bArr, ap.a(2106253876));
                return Buffer.this.read(bArr, i, i2);
            }
        };
    }

    @Override // java.nio.channels.Channel
    public boolean isOpen() {
        return true;
    }

    public final void j() throws EOFException {
        skip(size());
    }

    public final Segment j0(int i) {
        if (i < 1 || i > 8192) {
            throw new IllegalArgumentException("unexpected capacity");
        }
        Segment segment = this.a;
        if (segment != null) {
            Intrinsics.checkNotNull(segment);
            Segment segment2 = segment.g;
            Intrinsics.checkNotNull(segment2);
            return (segment2.c + i > 8192 || !segment2.e) ? segment2.c(SegmentPool.c()) : segment2;
        }
        Segment segmentC = SegmentPool.c();
        this.a = segmentC;
        segmentC.g = segmentC;
        segmentC.f = segmentC;
        return segmentC;
    }

    @Override // okio.BufferedSource
    public String j2() {
        return R1(Long.MAX_VALUE);
    }

    /* JADX INFO: renamed from: k, reason: merged with bridge method [inline-methods] */
    public Buffer clone() {
        return q();
    }

    @Override // okio.Source
    public long k3(Buffer buffer, long j) {
        Intrinsics.checkNotNullParameter(buffer, "sink");
        if (j < 0) {
            throw new IllegalArgumentException(("byteCount < 0: " + j).toString());
        }
        if (size() == 0) {
            return -1L;
        }
        if (j > size()) {
            j = size();
        }
        buffer.a2(this, j);
        return j;
    }

    @Override // okio.BufferedSource
    public byte[] l2(long j) throws EOFException {
        if (j < 0 || j > 2147483647L) {
            throw new IllegalArgumentException(("byteCount: " + j).toString());
        }
        if (size() < j) {
            throw new EOFException();
        }
        byte[] bArr = new byte[(int) j];
        readFully(bArr);
        return bArr;
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: m0, reason: merged with bridge method [inline-methods] */
    public Buffer l1(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "byteString");
        byteString.N(this, 0, byteString.size());
        return this;
    }

    @Override // okio.BufferedSource
    public long n1(Sink sink) {
        Intrinsics.checkNotNullParameter(sink, "sink");
        long size = size();
        if (size > 0) {
            sink.a2(this, size);
        }
        return size;
    }

    public final long o() {
        long size = size();
        if (size == 0) {
            return 0L;
        }
        Segment segment = this.a;
        Intrinsics.checkNotNull(segment);
        Segment segment2 = segment.g;
        Intrinsics.checkNotNull(segment2);
        int i = segment2.c;
        return (i >= 8192 || !segment2.e) ? size : size - ((long) (i - segment2.b));
    }

    public Buffer o0(Source source, long j) {
        Intrinsics.checkNotNullParameter(source, ClimateForcast.SOURCE);
        while (j > 0) {
            long jK3 = source.k3(this, j);
            if (jK3 == -1) {
                throw new EOFException();
            }
            j -= jK3;
        }
        return this;
    }

    @Override // okio.BufferedSource
    public BufferedSource peek() {
        return Okio.c(new PeekSource(this));
    }

    public final Buffer q() {
        Buffer buffer = new Buffer();
        if (size() == 0) {
            return buffer;
        }
        Segment segment = this.a;
        Intrinsics.checkNotNull(segment);
        Segment segmentD = segment.d();
        buffer.a = segmentD;
        segmentD.g = segmentD;
        segmentD.f = segmentD;
        for (Segment segment2 = segment.f; segment2 != segment; segment2 = segment2.f) {
            Segment segment3 = segmentD.g;
            Intrinsics.checkNotNull(segment3);
            Intrinsics.checkNotNull(segment2);
            segment3.c(segment2.d());
        }
        buffer.b0(size());
        return buffer;
    }

    public final Buffer r(Buffer buffer, long j, long j2) {
        Intrinsics.checkNotNullParameter(buffer, "out");
        long j3 = j;
        SegmentedByteString.b(size(), j3, j2);
        if (j2 != 0) {
            buffer.b0(buffer.size() + j2);
            Segment segment = this.a;
            while (true) {
                Intrinsics.checkNotNull(segment);
                int i = segment.c;
                int i2 = segment.b;
                if (j3 < i - i2) {
                    break;
                }
                j3 -= (long) (i - i2);
                segment = segment.f;
            }
            Segment segment2 = segment;
            long j4 = j2;
            while (j4 > 0) {
                Intrinsics.checkNotNull(segment2);
                Segment segmentD = segment2.d();
                int i3 = segmentD.b + ((int) j3);
                segmentD.b = i3;
                segmentD.c = Math.min(i3 + ((int) j4), segmentD.c);
                Segment segment3 = buffer.a;
                if (segment3 == null) {
                    segmentD.g = segmentD;
                    segmentD.f = segmentD;
                    buffer.a = segmentD;
                } else {
                    Intrinsics.checkNotNull(segment3);
                    Segment segment4 = segment3.g;
                    Intrinsics.checkNotNull(segment4);
                    segment4.c(segmentD);
                }
                j4 -= (long) (segmentD.c - segmentD.b);
                segment2 = segment2.f;
                j3 = 0;
            }
        }
        return this;
    }

    @Override // java.nio.channels.ReadableByteChannel
    public int read(ByteBuffer byteBuffer) {
        Intrinsics.checkNotNullParameter(byteBuffer, "sink");
        Segment segment = this.a;
        if (segment == null) {
            return -1;
        }
        int iMin = Math.min(byteBuffer.remaining(), segment.c - segment.b);
        byteBuffer.put(segment.a, segment.b, iMin);
        int i = segment.b + iMin;
        segment.b = i;
        this.b -= (long) iMin;
        if (i == segment.c) {
            this.a = segment.b();
            SegmentPool.b(segment);
        }
        return iMin;
    }

    @Override // okio.BufferedSource
    public byte readByte() {
        if (size() == 0) {
            throw new EOFException();
        }
        Segment segment = this.a;
        Intrinsics.checkNotNull(segment);
        int i = segment.b;
        int i2 = segment.c;
        int i3 = i + 1;
        byte b = segment.a[i];
        b0(size() - 1);
        if (i3 != i2) {
            segment.b = i3;
            return b;
        }
        this.a = segment.b();
        SegmentPool.b(segment);
        return b;
    }

    @Override // okio.BufferedSource
    public void readFully(byte[] bArr) throws EOFException {
        Intrinsics.checkNotNullParameter(bArr, "sink");
        int i = 0;
        while (i < bArr.length) {
            int i2 = read(bArr, i, bArr.length - i);
            if (i2 == -1) {
                throw new EOFException();
            }
            i += i2;
        }
    }

    @Override // okio.BufferedSource
    public int readInt() throws EOFException {
        if (size() < 4) {
            throw new EOFException();
        }
        Segment segment = this.a;
        Intrinsics.checkNotNull(segment);
        int i = segment.b;
        int i2 = segment.c;
        if (i2 - i < 4) {
            return (readByte() & ForkServer.ERROR) | ((readByte() & ForkServer.ERROR) << 24) | ((readByte() & ForkServer.ERROR) << 16) | ((readByte() & ForkServer.ERROR) << 8);
        }
        byte[] bArr = segment.a;
        int i3 = i + 3;
        int i4 = ((bArr[i + 1] & ForkServer.ERROR) << 16) | ((bArr[i] & ForkServer.ERROR) << 24) | ((bArr[i + 2] & ForkServer.ERROR) << 8);
        int i5 = i + 4;
        int i6 = (bArr[i3] & ForkServer.ERROR) | i4;
        b0(size() - 4);
        if (i5 != i2) {
            segment.b = i5;
            return i6;
        }
        this.a = segment.b();
        SegmentPool.b(segment);
        return i6;
    }

    @Override // okio.BufferedSource
    public long readLong() throws EOFException {
        if (size() < 8) {
            throw new EOFException();
        }
        Segment segment = this.a;
        Intrinsics.checkNotNull(segment);
        int i = segment.b;
        int i2 = segment.c;
        if (i2 - i < 8) {
            return ((((long) readInt()) & 4294967295L) << 32) | (4294967295L & ((long) readInt()));
        }
        byte[] bArr = segment.a;
        int i3 = i + 7;
        long j = ((((long) bArr[i]) & 255) << 56) | ((((long) bArr[i + 1]) & 255) << 48) | ((((long) bArr[i + 2]) & 255) << 40) | ((((long) bArr[i + 3]) & 255) << 32) | ((((long) bArr[i + 4]) & 255) << 24) | ((((long) bArr[i + 5]) & 255) << 16) | ((((long) bArr[i + 6]) & 255) << 8);
        int i4 = i + 8;
        long j2 = j | (((long) bArr[i3]) & 255);
        b0(size() - 8);
        if (i4 != i2) {
            segment.b = i4;
            return j2;
        }
        this.a = segment.b();
        SegmentPool.b(segment);
        return j2;
    }

    @Override // okio.BufferedSource
    public short readShort() throws EOFException {
        if (size() < 2) {
            throw new EOFException();
        }
        Segment segment = this.a;
        Intrinsics.checkNotNull(segment);
        int i = segment.b;
        int i2 = segment.c;
        if (i2 - i < 2) {
            return (short) ((readByte() & ForkServer.ERROR) | ((readByte() & ForkServer.ERROR) << 8));
        }
        byte[] bArr = segment.a;
        int i3 = i + 1;
        int i4 = (bArr[i] & ForkServer.ERROR) << 8;
        int i5 = i + 2;
        int i6 = (bArr[i3] & ForkServer.ERROR) | i4;
        b0(size() - 2);
        if (i5 == i2) {
            this.a = segment.b();
            SegmentPool.b(segment);
        } else {
            segment.b = i5;
        }
        return (short) i6;
    }

    @Override // okio.BufferedSource
    public boolean request(long j) {
        return this.b >= j;
    }

    /* JADX WARN: Removed duplicated region for block: B:32:0x0095  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00a3  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00a7 A[EDGE_INSN: B:43:0x00a7->B:37:0x00a7 BREAK  A[LOOP:0: B:5:0x000d->B:45:?], SYNTHETIC] */
    @Override // okio.BufferedSource
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public long s1() throws java.io.EOFException {
        /*
            r14 = this;
            long r0 = r14.size()
            r2 = 0
            int r0 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r0 == 0) goto Lb1
            r0 = 0
            r1 = r0
            r4 = r2
        Ld:
            okio.Segment r6 = r14.a
            kotlin.jvm.internal.Intrinsics.checkNotNull(r6)
            byte[] r7 = r6.a
            int r8 = r6.b
            int r9 = r6.c
        L18:
            if (r8 >= r9) goto L93
            r10 = r7[r8]
            r11 = 48
            if (r10 < r11) goto L27
            r11 = 57
            if (r10 > r11) goto L27
            int r11 = r10 + (-48)
            goto L3c
        L27:
            r11 = 97
            if (r10 < r11) goto L32
            r11 = 102(0x66, float:1.43E-43)
            if (r10 > r11) goto L32
            int r11 = r10 + (-87)
            goto L3c
        L32:
            r11 = 65
            if (r10 < r11) goto L74
            r11 = 70
            if (r10 > r11) goto L74
            int r11 = r10 + (-55)
        L3c:
            r12 = -1152921504606846976(0xf000000000000000, double:-3.105036184601418E231)
            long r12 = r12 & r4
            int r12 = (r12 > r2 ? 1 : (r12 == r2 ? 0 : -1))
            if (r12 != 0) goto L4c
            r10 = 4
            long r4 = r4 << r10
            long r10 = (long) r11
            long r4 = r4 | r10
            int r8 = r8 + 1
            int r0 = r0 + 1
            goto L18
        L4c:
            okio.Buffer r14 = new okio.Buffer
            r14.<init>()
            okio.Buffer r14 = r14.b1(r4)
            okio.Buffer r14 = r14.writeByte(r10)
            java.lang.NumberFormatException r0 = new java.lang.NumberFormatException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "Number too large: "
            r1.append(r2)
            java.lang.String r14 = r14.X()
            r1.append(r14)
            java.lang.String r14 = r1.toString()
            r0.<init>(r14)
            throw r0
        L74:
            if (r0 == 0) goto L78
            r1 = 1
            goto L93
        L78:
            java.lang.NumberFormatException r14 = new java.lang.NumberFormatException
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            r0.<init>()
            java.lang.String r1 = "Expected leading [0-9a-fA-F] character but was 0x"
            r0.append(r1)
            java.lang.String r1 = okio.SegmentedByteString.f(r10)
            r0.append(r1)
            java.lang.String r0 = r0.toString()
            r14.<init>(r0)
            throw r14
        L93:
            if (r8 != r9) goto L9f
            okio.Segment r7 = r6.b()
            r14.a = r7
            okio.SegmentPool.b(r6)
            goto La1
        L9f:
            r6.b = r8
        La1:
            if (r1 != 0) goto La7
            okio.Segment r6 = r14.a
            if (r6 != 0) goto Ld
        La7:
            long r1 = r14.size()
            long r6 = (long) r0
            long r1 = r1 - r6
            r14.b0(r1)
            return r4
        Lb1:
            java.io.EOFException r14 = new java.io.EOFException
            r14.<init>()
            throw r14
        */
        throw new UnsupportedOperationException("Method not decompiled: okio.Buffer.s1():long");
    }

    @Override // okio.BufferedSource
    public void s2(long j) throws EOFException {
        if (this.b < j) {
            throw new EOFException();
        }
    }

    @Override // okio.BufferedSink
    public OutputStream s3() {
        return new OutputStream() { // from class: okio.Buffer$outputStream$1
            @Override // java.io.OutputStream, java.io.Closeable, java.lang.AutoCloseable
            public void close() {
            }

            @Override // java.io.OutputStream, java.io.Flushable
            public void flush() {
            }

            public String toString() {
                return this.a + ap.a(874023663);
            }

            @Override // java.io.OutputStream
            public void write(int i) {
                this.a.writeByte(i);
            }

            @Override // java.io.OutputStream
            public void write(byte[] bArr, int i, int i2) {
                Intrinsics.checkNotNullParameter(bArr, "data");
                this.a.write(bArr, i, i2);
            }
        };
    }

    public final long size() {
        return this.b;
    }

    @Override // okio.BufferedSource
    public void skip(long j) throws EOFException {
        while (j > 0) {
            Segment segment = this.a;
            if (segment == null) {
                throw new EOFException();
            }
            int iMin = (int) Math.min(j, segment.c - segment.b);
            long j2 = iMin;
            b0(size() - j2);
            j -= j2;
            int i = segment.b + iMin;
            segment.b = i;
            if (i == segment.c) {
                this.a = segment.b();
                SegmentPool.b(segment);
            }
        }
    }

    @Override // okio.BufferedSource
    public short t0() {
        return SegmentedByteString.e(readShort());
    }

    @Override // okio.Source
    public Timeout timeout() {
        return Timeout.f;
    }

    public String toString() {
        return d0().toString();
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: u, reason: merged with bridge method [inline-methods] */
    public Buffer A1() {
        return this;
    }

    @Override // okio.BufferedSource
    public long u0() {
        return SegmentedByteString.d(readLong());
    }

    @Override // okio.BufferedSource
    public int u3(Options options) throws EOFException {
        Intrinsics.checkNotNullParameter(options, "options");
        int iJ = okio.internal.Buffer.j(this, options, false, 2, null);
        if (iJ == -1) {
            return -1;
        }
        skip(options.e()[iJ].size());
        return iJ;
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: v0, reason: merged with bridge method [inline-methods] */
    public Buffer write(byte[] bArr) {
        Intrinsics.checkNotNullParameter(bArr, ClimateForcast.SOURCE);
        return write(bArr, 0, bArr.length);
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: w0, reason: merged with bridge method [inline-methods] */
    public Buffer write(byte[] bArr, int i, int i2) {
        Intrinsics.checkNotNullParameter(bArr, ClimateForcast.SOURCE);
        long j = i2;
        SegmentedByteString.b(bArr.length, i, j);
        int i3 = i2 + i;
        while (i < i3) {
            Segment segmentJ0 = j0(1);
            int iMin = Math.min(i3 - i, 8192 - segmentJ0.c);
            int i4 = i + iMin;
            ArraysKt.copyInto(bArr, segmentJ0.a, segmentJ0.c, i, i4);
            segmentJ0.c += iMin;
            i = i4;
        }
        b0(size() + j);
        return this;
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: x0, reason: merged with bridge method [inline-methods] */
    public Buffer writeByte(int i) {
        Segment segmentJ0 = j0(1);
        byte[] bArr = segmentJ0.a;
        int i2 = segmentJ0.c;
        segmentJ0.c = i2 + 1;
        bArr[i2] = (byte) i;
        b0(size() + 1);
        return this;
    }

    @Override // okio.BufferedSource
    public Buffer x1() {
        return this;
    }

    @Override // okio.BufferedSink
    /* JADX INFO: renamed from: z0, reason: merged with bridge method [inline-methods] */
    public Buffer A0(long j) {
        boolean z;
        if (j == 0) {
            return writeByte(48);
        }
        if (j < 0) {
            j = -j;
            if (j < 0) {
                return V1("-9223372036854775808");
            }
            z = true;
        } else {
            z = false;
        }
        int iE = okio.internal.Buffer.e(j);
        if (z) {
            iE++;
        }
        Segment segmentJ0 = j0(iE);
        byte[] bArr = segmentJ0.a;
        int i = segmentJ0.c + iE;
        while (j != 0) {
            long j2 = 10;
            i--;
            bArr[i] = okio.internal.Buffer.f()[(int) (j % j2)];
            j /= j2;
        }
        if (z) {
            bArr[i - 1] = 45;
        }
        segmentJ0.c += iE;
        b0(size() + ((long) iE));
        return this;
    }

    @Override // java.nio.channels.WritableByteChannel
    public int write(ByteBuffer byteBuffer) {
        Intrinsics.checkNotNullParameter(byteBuffer, ClimateForcast.SOURCE);
        int iRemaining = byteBuffer.remaining();
        int i = iRemaining;
        while (i > 0) {
            Segment segmentJ0 = j0(1);
            int iMin = Math.min(i, 8192 - segmentJ0.c);
            byteBuffer.get(segmentJ0.a, segmentJ0.c, iMin);
            i -= iMin;
            segmentJ0.c += iMin;
        }
        this.b += (long) iRemaining;
        return iRemaining;
    }

    public int read(byte[] bArr, int i, int i2) {
        Intrinsics.checkNotNullParameter(bArr, "sink");
        SegmentedByteString.b(bArr.length, i, i2);
        Segment segment = this.a;
        if (segment == null) {
            return -1;
        }
        int iMin = Math.min(i2, segment.c - segment.b);
        byte[] bArr2 = segment.a;
        int i3 = segment.b;
        ArraysKt.copyInto(bArr2, bArr, i, i3, i3 + iMin);
        segment.b += iMin;
        b0(size() - ((long) iMin));
        if (segment.b == segment.c) {
            this.a = segment.b();
            SegmentPool.b(segment);
        }
        return iMin;
    }
}