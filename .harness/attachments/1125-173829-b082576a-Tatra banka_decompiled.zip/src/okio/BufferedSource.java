package okio;

import java.io.InputStream;
import java.nio.channels.ReadableByteChannel;
import java.nio.charset.Charset;
import kotlin.Metadata;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0080\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u0005\n\u0002\b\u0002\n\u0002\u0010\n\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0014\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\bv\u0018\u00002\u00020\u00012\u00020\u0002J\u000f\u0010\u0004\u001a\u00020\u0003H'¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0007\u001a\u00020\u0006H&¢\u0006\u0004\b\u0007\u0010\bJ\u0017\u0010\f\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\tH&¢\u0006\u0004\b\f\u0010\rJ\u0017\u0010\u000e\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\tH&¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0011\u001a\u00020\u0010H&¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0014\u001a\u00020\u0013H&¢\u0006\u0004\b\u0014\u0010\u0015J\u000f\u0010\u0016\u001a\u00020\u0013H&¢\u0006\u0004\b\u0016\u0010\u0015J\u000f\u0010\u0018\u001a\u00020\u0017H&¢\u0006\u0004\b\u0018\u0010\u0019J\u000f\u0010\u001a\u001a\u00020\u0017H&¢\u0006\u0004\b\u001a\u0010\u0019J\u000f\u0010\u001b\u001a\u00020\tH&¢\u0006\u0004\b\u001b\u0010\u001cJ\u000f\u0010\u001d\u001a\u00020\tH&¢\u0006\u0004\b\u001d\u0010\u001cJ\u000f\u0010\u001e\u001a\u00020\tH&¢\u0006\u0004\b\u001e\u0010\u001cJ\u000f\u0010\u001f\u001a\u00020\tH&¢\u0006\u0004\b\u001f\u0010\u001cJ\u0017\u0010 \u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\tH&¢\u0006\u0004\b \u0010\rJ\u0017\u0010\"\u001a\u00020!2\u0006\u0010\n\u001a\u00020\tH&¢\u0006\u0004\b\"\u0010#J\u0017\u0010&\u001a\u00020\u00172\u0006\u0010%\u001a\u00020$H&¢\u0006\u0004\b&\u0010'J\u000f\u0010)\u001a\u00020(H&¢\u0006\u0004\b)\u0010*J\u0017\u0010+\u001a\u00020(2\u0006\u0010\n\u001a\u00020\tH&¢\u0006\u0004\b+\u0010,J\u0017\u0010.\u001a\u00020\u000b2\u0006\u0010-\u001a\u00020(H&¢\u0006\u0004\b.\u0010/J\u001f\u00100\u001a\u00020\u000b2\u0006\u0010-\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\tH&¢\u0006\u0004\b0\u00101J\u0017\u00103\u001a\u00020\t2\u0006\u0010-\u001a\u000202H&¢\u0006\u0004\b3\u00104J\u0017\u00106\u001a\u0002052\u0006\u0010\n\u001a\u00020\tH&¢\u0006\u0004\b6\u00107J\u000f\u00108\u001a\u000205H&¢\u0006\u0004\b8\u00109J\u0017\u0010;\u001a\u0002052\u0006\u0010:\u001a\u00020\tH&¢\u0006\u0004\b;\u00107J\u0017\u0010>\u001a\u0002052\u0006\u0010=\u001a\u00020<H&¢\u0006\u0004\b>\u0010?J'\u0010C\u001a\u00020\t2\u0006\u0010@\u001a\u00020\u00102\u0006\u0010A\u001a\u00020\t2\u0006\u0010B\u001a\u00020\tH&¢\u0006\u0004\bC\u0010DJ\u0017\u0010F\u001a\u00020\t2\u0006\u0010E\u001a\u00020!H&¢\u0006\u0004\bF\u0010GJ'\u0010H\u001a\u00020\t2\u0006\u0010E\u001a\u00020!2\u0006\u0010A\u001a\u00020\t2\u0006\u0010B\u001a\u00020\tH&¢\u0006\u0004\bH\u0010IJ\u0017\u0010K\u001a\u00020\t2\u0006\u0010J\u001a\u00020!H&¢\u0006\u0004\bK\u0010GJ\u001f\u0010M\u001a\u00020\u00062\u0006\u0010L\u001a\u00020\t2\u0006\u0010E\u001a\u00020!H&¢\u0006\u0004\bM\u0010NJ\u000f\u0010O\u001a\u00020\u0000H&¢\u0006\u0004\bO\u0010PJ\u000f\u0010R\u001a\u00020QH&¢\u0006\u0004\bR\u0010SR\u0014\u0010U\u001a\u00020\u00038&X¦\u0004¢\u0006\u0006\u001a\u0004\bT\u0010\u0005\u0082\u0001\u0002\u0003Vø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006WÀ\u0006\u0001"}, d2 = {"Lokio/BufferedSource;", "Lokio/Source;", "Ljava/nio/channels/ReadableByteChannel;", "Lokio/Buffer;", "x1", "()Lokio/Buffer;", StringUtils.EMPTY, "H2", "()Z", StringUtils.EMPTY, "byteCount", StringUtils.EMPTY, "s2", "(J)V", "request", "(J)Z", StringUtils.EMPTY, "readByte", "()B", StringUtils.EMPTY, "readShort", "()S", "t0", StringUtils.EMPTY, "readInt", "()I", "c3", "readLong", "()J", "u0", "L2", "s1", "skip", "Lokio/ByteString;", "F0", "(J)Lokio/ByteString;", "Lokio/Options;", "options", "u3", "(Lokio/Options;)I", StringUtils.EMPTY, "K0", "()[B", "l2", "(J)[B", "sink", "readFully", "([B)V", "N1", "(Lokio/Buffer;J)V", "Lokio/Sink;", "n1", "(Lokio/Sink;)J", StringUtils.EMPTY, "B0", "(J)Ljava/lang/String;", "j2", "()Ljava/lang/String;", "limit", "R1", "Ljava/nio/charset/Charset;", "charset", "X0", "(Ljava/nio/charset/Charset;)Ljava/lang/String;", "b", "fromIndex", "toIndex", "O1", "(BJJ)J", "bytes", "L", "(Lokio/ByteString;)J", "I2", "(Lokio/ByteString;JJ)J", "targetBytes", "R", MimeTypesReaderMetKeys.MATCH_OFFSET_ATTR, "Y", "(JLokio/ByteString;)Z", "peek", "()Lokio/BufferedSource;", "Ljava/io/InputStream;", "inputStream", "()Ljava/io/InputStream;", "getBuffer", "buffer", "Lokio/RealBufferedSource;", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
public interface BufferedSource extends Source, ReadableByteChannel {
    String B0(long j);

    ByteString F0(long j);

    boolean H2();

    long I2(ByteString byteString, long j, long j2);

    byte[] K0();

    long L(ByteString byteString);

    long L2();

    void N1(Buffer buffer, long j);

    long O1(byte b, long j, long j2);

    long R(ByteString byteString);

    String R1(long j);

    String X0(Charset charset);

    boolean Y(long j, ByteString byteString);

    int c3();

    Buffer getBuffer();

    InputStream inputStream();

    String j2();

    byte[] l2(long j);

    long n1(Sink sink);

    BufferedSource peek();

    byte readByte();

    void readFully(byte[] bArr);

    int readInt();

    long readLong();

    short readShort();

    boolean request(long j);

    long s1();

    void s2(long j);

    void skip(long j);

    short t0();

    long u0();

    int u3(Options options);

    Buffer x1();
}