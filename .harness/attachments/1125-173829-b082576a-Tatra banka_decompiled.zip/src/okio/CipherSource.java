package okio;

import h.ap;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.ShortBufferException;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0006\u0018\u00002\u00020\u0001J\u000f\u0010\u0003\u001a\u00020\u0002H\u0002¢\u0006\u0004\b\u0003\u0010\u0004J\u000f\u0010\u0005\u001a\u00020\u0002H\u0002¢\u0006\u0004\b\u0005\u0010\u0004J\u000f\u0010\u0006\u001a\u00020\u0002H\u0002¢\u0006\u0004\b\u0006\u0010\u0004J\u001f\u0010\u000b\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\u000e\u001a\u00020\rH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0010\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0010\u0010\u0004R\u0014\u0010\u0014\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010\u0013R\u0017\u0010\u001a\u001a\u00020\u00158\u0006¢\u0006\f\n\u0004\b\u0016\u0010\u0017\u001a\u0004\b\u0018\u0010\u0019R\u0014\u0010\u001e\u001a\u00020\u001b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001c\u0010\u001dR\u0014\u0010!\u001a\u00020\u00078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001f\u0010 R\u0016\u0010%\u001a\u00020\"8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b#\u0010$R\u0016\u0010'\u001a\u00020\"8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b&\u0010$¨\u0006("}, d2 = {"Lokio/CipherSource;", "Lokio/Source;", StringUtils.EMPTY, "k", "()V", "o", "j", "Lokio/Buffer;", "sink", StringUtils.EMPTY, "byteCount", "k3", "(Lokio/Buffer;J)J", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", "close", "Lokio/BufferedSource;", "a", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "Ljavax/crypto/Cipher;", "b", "Ljavax/crypto/Cipher;", "getCipher", "()Ljavax/crypto/Cipher;", "cipher", StringUtils.EMPTY, "c", "I", "blockSize", "d", "Lokio/Buffer;", "buffer", StringUtils.EMPTY, "e", "Z", "final", "f", "closed", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nCipherSource.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CipherSource.kt\nokio/CipherSource\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,120:1\n1#2:121\n*E\n"})
public final class CipherSource implements Source {
    private final BufferedSource a;
    private final Cipher b;
    private final int c;
    private final Buffer d;
    private boolean e;
    private boolean f;

    private final void j() throws BadPaddingException, IllegalBlockSizeException, ShortBufferException {
        int outputSize = this.b.getOutputSize(0);
        if (outputSize == 0) {
            return;
        }
        Segment segmentJ0 = this.d.j0(outputSize);
        int iDoFinal = this.b.doFinal(segmentJ0.a, segmentJ0.b);
        segmentJ0.c += iDoFinal;
        Buffer buffer = this.d;
        buffer.b0(buffer.size() + ((long) iDoFinal));
        if (segmentJ0.b == segmentJ0.c) {
            this.d.a = segmentJ0.b();
            SegmentPool.b(segmentJ0);
        }
    }

    private final void k() throws BadPaddingException, IllegalBlockSizeException, ShortBufferException {
        while (this.d.size() == 0 && !this.e) {
            if (this.a.H2()) {
                this.e = true;
                j();
                return;
            }
            o();
        }
    }

    private final void o() throws BadPaddingException, IllegalBlockSizeException, ShortBufferException {
        Segment segment = this.a.getBuffer().a;
        Intrinsics.checkNotNull(segment);
        int i = segment.c - segment.b;
        int outputSize = this.b.getOutputSize(i);
        int i2 = i;
        while (outputSize > 8192) {
            int i3 = this.c;
            if (i2 <= i3) {
                this.e = true;
                Buffer buffer = this.d;
                byte[] bArrDoFinal = this.b.doFinal(this.a.K0());
                Intrinsics.checkNotNullExpressionValue(bArrDoFinal, ap.a(691024776));
                buffer.write(bArrDoFinal);
                return;
            }
            i2 -= i3;
            outputSize = this.b.getOutputSize(i2);
        }
        Segment segmentJ0 = this.d.j0(outputSize);
        int iUpdate = this.b.update(segment.a, segment.b, i2, segmentJ0.a, segmentJ0.b);
        this.a.skip(i2);
        segmentJ0.c += iUpdate;
        Buffer buffer2 = this.d;
        buffer2.b0(buffer2.size() + ((long) iUpdate));
        if (segmentJ0.b == segmentJ0.c) {
            this.d.a = segmentJ0.b();
            SegmentPool.b(segmentJ0);
        }
    }

    @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.f = true;
        this.a.close();
    }

    @Override // okio.Source
    public long k3(Buffer buffer, long j) throws BadPaddingException, IllegalBlockSizeException, ShortBufferException {
        Intrinsics.checkNotNullParameter(buffer, "sink");
        if (j < 0) {
            throw new IllegalArgumentException(("byteCount < 0: " + j).toString());
        }
        if (this.f) {
            throw new IllegalStateException("closed");
        }
        if (j == 0) {
            return 0L;
        }
        k();
        return this.d.k3(buffer, j);
    }

    @Override // okio.Source
    public Timeout timeout() {
        return this.a.timeout();
    }
}