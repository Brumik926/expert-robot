package okio;

import h.ap;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u000f\b\u0016\u0018\u0000 )2\u00020\u0001:\u0002*+B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\r\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0003J\r\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\u0007\u0010\bJ\u0017\u0010\u000b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\tH\u0000¢\u0006\u0004\b\u000b\u0010\fJ\u0019\u0010\r\u001a\u00020\u00042\b\b\u0002\u0010\n\u001a\u00020\tH\u0000¢\u0006\u0004\b\r\u0010\u000eJ\u000f\u0010\u000f\u001a\u00020\u0004H\u0014¢\u0006\u0004\b\u000f\u0010\u0003J\u0015\u0010\u0012\u001a\u00020\u00102\u0006\u0010\u0011\u001a\u00020\u0010¢\u0006\u0004\b\u0012\u0010\u0013J\u0015\u0010\u0016\u001a\u00020\u00142\u0006\u0010\u0015\u001a\u00020\u0014¢\u0006\u0004\b\u0016\u0010\u0017J\u0019\u0010\u001a\u001a\u00020\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u0018H\u0001¢\u0006\u0004\b\u001a\u0010\u001bJ\u0019\u0010\u001c\u001a\u00020\u00182\b\u0010\u0019\u001a\u0004\u0018\u00010\u0018H\u0014¢\u0006\u0004\b\u001c\u0010\u001bR\u0016\u0010 \u001a\u00020\u001d8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001e\u0010\u001fR\u0016\u0010\"\u001a\u00020\u001d8\u0000@\u0000X\u0081\u000e¢\u0006\u0006\n\u0004\b!\u0010\u001fR$\u0010(\u001a\u00020\t2\u0006\u0010#\u001a\u00020\t8\u0000@BX\u0080\u000e¢\u0006\f\n\u0004\b$\u0010%\u001a\u0004\b&\u0010'¨\u0006,"}, d2 = {"Lokio/AsyncTimeout;", "Lokio/Timeout;", "<init>", "()V", StringUtils.EMPTY, "u", StringUtils.EMPTY, "v", "()Z", StringUtils.EMPTY, "now", "y", "(J)J", "z", "(J)V", "D", "Lokio/Sink;", "sink", "B", "(Lokio/Sink;)Lokio/Sink;", "Lokio/Source;", ClimateForcast.SOURCE, "C", "(Lokio/Source;)Lokio/Source;", "Ljava/io/IOException;", "cause", "r", "(Ljava/io/IOException;)Ljava/io/IOException;", "x", StringUtils.EMPTY, "g", "I", "state", "h", "index", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "i", "J", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "()J", "timeoutAt", "j", "Watchdog", "Companion", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nAsyncTimeout.kt\nKotlin\n*S Kotlin\n*F\n+ 1 AsyncTimeout.kt\nokio/AsyncTimeout\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,514:1\n1#2:515\n*E\n"})
public class AsyncTimeout extends Timeout {
    private static final Companion j = new Companion(null);
    private static final PriorityQueue k = new PriorityQueue();
    private static AsyncTimeout l;
    private static final ReentrantLock m;
    private static final Condition n;
    private static final long o;
    private static final long p;
    private int g;
    public int h = -1;
    private long i;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\b\b\u0082\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\t\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\t\u0010\nR\u0017\u0010\f\u001a\u00020\u000b8\u0006¢\u0006\f\n\u0004\b\f\u0010\r\u001a\u0004\b\u000e\u0010\u000fR$\u0010\u0010\u001a\u0004\u0018\u00010\u00048\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0010\u0010\u0011\u001a\u0004\b\u0012\u0010\n\"\u0004\b\u0013\u0010\bR\u0017\u0010\u0015\u001a\u00020\u00148\u0006¢\u0006\f\n\u0004\b\u0015\u0010\u0016\u001a\u0004\b\u0017\u0010\u0018R\u0017\u0010\u001a\u001a\u00020\u00198\u0006¢\u0006\f\n\u0004\b\u001a\u0010\u001b\u001a\u0004\b\u001c\u0010\u001dR\u0014\u0010\u001f\u001a\u00020\u001e8\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u001f\u0010 R\u0014\u0010\"\u001a\u00020!8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\"\u0010#R\u0014\u0010$\u001a\u00020!8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b$\u0010#R\u0014\u0010%\u001a\u00020\u001e8\u0002X\u0082T¢\u0006\u0006\n\u0004\b%\u0010 R\u0014\u0010&\u001a\u00020\u001e8\u0002X\u0082T¢\u0006\u0006\n\u0004\b&\u0010 R\u0014\u0010'\u001a\u00020\u001e8\u0002X\u0082T¢\u0006\u0006\n\u0004\b'\u0010 R\u0014\u0010(\u001a\u00020\u001e8\u0002X\u0082T¢\u0006\u0006\n\u0004\b(\u0010 ¨\u0006)"}, d2 = {"Lokio/AsyncTimeout$Companion;", StringUtils.EMPTY, "<init>", "()V", "Lokio/AsyncTimeout;", "node", StringUtils.EMPTY, "g", "(Lokio/AsyncTimeout;)V", "b", "()Lokio/AsyncTimeout;", "Lokio/PriorityQueue;", "queue", "Lokio/PriorityQueue;", "f", "()Lokio/PriorityQueue;", "idleSentinel", "Lokio/AsyncTimeout;", "d", "h", "Ljava/util/concurrent/locks/ReentrantLock;", "lock", "Ljava/util/concurrent/locks/ReentrantLock;", "e", "()Ljava/util/concurrent/locks/ReentrantLock;", "Ljava/util/concurrent/locks/Condition;", "condition", "Ljava/util/concurrent/locks/Condition;", "c", "()Ljava/util/concurrent/locks/Condition;", StringUtils.EMPTY, "TIMEOUT_WRITE_SIZE", "I", StringUtils.EMPTY, "IDLE_TIMEOUT_MILLIS", "J", "IDLE_TIMEOUT_NANOS", "STATE_IDLE", "STATE_IN_QUEUE", "STATE_TIMED_OUT", "STATE_CANCELED", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
    private static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private final void g(AsyncTimeout asyncTimeout) {
            if (d() == null) {
                h(new AsyncTimeout());
                new Watchdog().start();
            }
            AsyncTimeout.A(asyncTimeout, 0L, 1, null);
            f().a(asyncTimeout);
            if (asyncTimeout.h == 1) {
                c().signal();
            }
        }

        public final AsyncTimeout b() throws InterruptedException {
            AsyncTimeout asyncTimeoutB = f().b();
            if (asyncTimeoutB == null) {
                long jNanoTime = System.nanoTime();
                c().await(AsyncTimeout.o, TimeUnit.MILLISECONDS);
                if (f().b() != null || System.nanoTime() - jNanoTime < AsyncTimeout.p) {
                    return null;
                }
                return d();
            }
            long jY = asyncTimeoutB.y(System.nanoTime());
            if (jY > 0) {
                c().await(jY, TimeUnit.NANOSECONDS);
                return null;
            }
            f().e(asyncTimeoutB);
            asyncTimeoutB.g = 2;
            return asyncTimeoutB;
        }

        public final Condition c() {
            return AsyncTimeout.n;
        }

        public final AsyncTimeout d() {
            return AsyncTimeout.l;
        }

        public final ReentrantLock e() {
            return AsyncTimeout.m;
        }

        public final PriorityQueue f() {
            return AsyncTimeout.k;
        }

        public final void h(AsyncTimeout asyncTimeout) {
            AsyncTimeout.l = asyncTimeout;
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\b\u0010\u0004\u001a\u00020\u0005H\u0016¨\u0006\u0006"}, d2 = {"Lokio/AsyncTimeout$Watchdog;", "Ljava/lang/Thread;", "<init>", "()V", "run", StringUtils.EMPTY, "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
    private static final class Watchdog extends Thread {
        public Watchdog() {
            super(ap.a(1075826035));
            setDaemon(true);
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            ReentrantLock reentrantLockE;
            AsyncTimeout asyncTimeoutB;
            while (true) {
                try {
                    reentrantLockE = AsyncTimeout.j.e();
                    reentrantLockE.lock();
                    try {
                        asyncTimeoutB = AsyncTimeout.j.b();
                    } finally {
                        reentrantLockE.unlock();
                    }
                } catch (InterruptedException unused) {
                }
                if (asyncTimeoutB == AsyncTimeout.j.d()) {
                    AsyncTimeout.j.h(null);
                    return;
                }
                Unit unit = Unit.INSTANCE;
                reentrantLockE.unlock();
                if (asyncTimeoutB != null) {
                    asyncTimeoutB.D();
                }
            }
        }
    }

    static {
        ReentrantLock reentrantLock = new ReentrantLock();
        m = reentrantLock;
        Condition conditionNewCondition = reentrantLock.newCondition();
        Intrinsics.checkNotNullExpressionValue(conditionNewCondition, ap.a(348908855));
        n = conditionNewCondition;
        long millis = TimeUnit.SECONDS.toMillis(60L);
        o = millis;
        p = TimeUnit.MILLISECONDS.toNanos(millis);
    }

    public static /* synthetic */ void A(AsyncTimeout asyncTimeout, long j2, int i, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: setTimeoutAt");
        }
        if ((i & 1) != 0) {
            j2 = System.nanoTime();
        }
        asyncTimeout.z(j2);
    }

    public final Sink B(final Sink sink) {
        Intrinsics.checkNotNullParameter(sink, "sink");
        return new Sink() { // from class: okio.AsyncTimeout$sink$1
            @Override // okio.Sink
            public void a2(Buffer buffer, long j2) throws IOException {
                Intrinsics.checkNotNullParameter(buffer, ap.a(1067025910));
                SegmentedByteString.b(buffer.size(), 0L, j2);
                while (true) {
                    long j3 = 0;
                    if (j2 <= 0) {
                        return;
                    }
                    Segment segment = buffer.a;
                    Intrinsics.checkNotNull(segment);
                    while (true) {
                        if (j3 >= 65536) {
                            break;
                        }
                        j3 += (long) (segment.c - segment.b);
                        if (j3 >= j2) {
                            j3 = j2;
                            break;
                        } else {
                            segment = segment.f;
                            Intrinsics.checkNotNull(segment);
                        }
                    }
                    AsyncTimeout asyncTimeout = this.a;
                    Sink sink2 = sink;
                    asyncTimeout.u();
                    try {
                        try {
                            sink2.a2(buffer, j3);
                            Unit unit = Unit.INSTANCE;
                            if (asyncTimeout.v()) {
                                throw asyncTimeout.r(null);
                            }
                            j2 -= j3;
                        } catch (IOException e) {
                            if (!asyncTimeout.v()) {
                                throw e;
                            }
                            throw asyncTimeout.r(e);
                        }
                    } catch (Throwable th) {
                        asyncTimeout.v();
                        throw th;
                    }
                }
            }

            @Override // okio.Sink, java.io.Closeable, java.lang.AutoCloseable
            public void close() throws IOException {
                AsyncTimeout asyncTimeout = this.a;
                Sink sink2 = sink;
                asyncTimeout.u();
                try {
                    sink2.close();
                    Unit unit = Unit.INSTANCE;
                    if (asyncTimeout.v()) {
                        throw asyncTimeout.r(null);
                    }
                } catch (IOException e) {
                    if (!asyncTimeout.v()) {
                        throw e;
                    }
                    throw asyncTimeout.r(e);
                } finally {
                    asyncTimeout.v();
                }
            }

            @Override // okio.Sink, java.io.Flushable
            public void flush() throws IOException {
                AsyncTimeout asyncTimeout = this.a;
                Sink sink2 = sink;
                asyncTimeout.u();
                try {
                    sink2.flush();
                    Unit unit = Unit.INSTANCE;
                    if (asyncTimeout.v()) {
                        throw asyncTimeout.r(null);
                    }
                } catch (IOException e) {
                    if (!asyncTimeout.v()) {
                        throw e;
                    }
                    throw asyncTimeout.r(e);
                } finally {
                    asyncTimeout.v();
                }
            }

            @Override // okio.Sink
            /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
            public AsyncTimeout timeout() {
                return this.a;
            }

            public String toString() {
                return "AsyncTimeout.sink(" + sink + ')';
            }
        };
    }

    public final Source C(final Source source) {
        Intrinsics.checkNotNullParameter(source, ClimateForcast.SOURCE);
        return new Source() { // from class: okio.AsyncTimeout$source$1
            @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
            public void close() throws IOException {
                AsyncTimeout asyncTimeout = this.a;
                Source source2 = source;
                asyncTimeout.u();
                try {
                    source2.close();
                    Unit unit = Unit.INSTANCE;
                    if (asyncTimeout.v()) {
                        throw asyncTimeout.r(null);
                    }
                } catch (IOException e) {
                    if (!asyncTimeout.v()) {
                        throw e;
                    }
                    throw asyncTimeout.r(e);
                } finally {
                    asyncTimeout.v();
                }
            }

            @Override // okio.Source
            /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
            public AsyncTimeout timeout() {
                return this.a;
            }

            @Override // okio.Source
            public long k3(Buffer buffer, long j2) throws IOException {
                Intrinsics.checkNotNullParameter(buffer, ap.a(352579030));
                AsyncTimeout asyncTimeout = this.a;
                Source source2 = source;
                asyncTimeout.u();
                try {
                    long jK3 = source2.k3(buffer, j2);
                    if (asyncTimeout.v()) {
                        throw asyncTimeout.r(null);
                    }
                    return jK3;
                } catch (IOException e) {
                    if (asyncTimeout.v()) {
                        throw asyncTimeout.r(e);
                    }
                    throw e;
                } finally {
                    asyncTimeout.v();
                }
            }

            public String toString() {
                return "AsyncTimeout.source(" + source + ')';
            }
        };
    }

    protected void D() {
    }

    public final IOException r(IOException iOException) {
        return x(iOException);
    }

    public final void u() {
        long jI = i();
        boolean zF = f();
        if (jI != 0 || zF) {
            ReentrantLock reentrantLock = m;
            reentrantLock.lock();
            try {
                if (this.g != 0) {
                    throw new IllegalStateException("Unbalanced enter/exit");
                }
                this.g = 1;
                j.g(this);
                Unit unit = Unit.INSTANCE;
            } finally {
                reentrantLock.unlock();
            }
        }
    }

    public final boolean v() {
        ReentrantLock reentrantLock = m;
        reentrantLock.lock();
        try {
            int i = this.g;
            this.g = 0;
            if (i != 1) {
                return i == 2;
            }
            k.e(this);
            return false;
        } finally {
            reentrantLock.unlock();
        }
    }

    public final long w() {
        return this.i;
    }

    protected IOException x(IOException iOException) {
        InterruptedIOException interruptedIOException = new InterruptedIOException("timeout");
        if (iOException != null) {
            interruptedIOException.initCause(iOException);
        }
        return interruptedIOException;
    }

    public final long y(long j2) {
        return this.i - j2;
    }

    public final void z(long j2) {
        long jI = i();
        boolean zF = f();
        if (i() != 0 && f()) {
            this.i = j2 + Math.min(jI, d() - j2);
        } else if (jI != 0) {
            this.i = j2 + jI;
        } else {
            if (!zF) {
                throw new AssertionError();
            }
            this.i = d();
        }
    }
}