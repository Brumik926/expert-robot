package okio;

import h.ap;
import java.io.IOException;
import java.util.zip.Deflater;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okio.internal._ZlibJvmKt;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\t\u0018\u00002\u00020\u0001B\u0019\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007B\u0019\b\u0016\u0012\u0006\u0010\u0003\u001a\u00020\u0001\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\bJ\u0017\u0010\f\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\tH\u0002¢\u0006\u0004\b\f\u0010\rJ\u001f\u0010\u0012\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0014\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u0014\u0010\u0015J\u000f\u0010\u0016\u001a\u00020\u000bH\u0000¢\u0006\u0004\b\u0016\u0010\u0015J\u000f\u0010\u0017\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u0017\u0010\u0015J\u000f\u0010\u0019\u001a\u00020\u0018H\u0016¢\u0006\u0004\b\u0019\u0010\u001aJ\u000f\u0010\u001c\u001a\u00020\u001bH\u0016¢\u0006\u0004\b\u001c\u0010\u001dR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\f\u0010\u001eR\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001f\u0010 R\u0016\u0010#\u001a\u00020\t8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b!\u0010\"¨\u0006$"}, d2 = {"Lokio/DeflaterSink;", "Lokio/Sink;", "Lokio/BufferedSink;", "sink", "Ljava/util/zip/Deflater;", "deflater", "<init>", "(Lokio/BufferedSink;Ljava/util/zip/Deflater;)V", "(Lokio/Sink;Ljava/util/zip/Deflater;)V", StringUtils.EMPTY, "syncFlush", StringUtils.EMPTY, "a", "(Z)V", "Lokio/Buffer;", ClimateForcast.SOURCE, StringUtils.EMPTY, "byteCount", "a2", "(Lokio/Buffer;J)V", "flush", "()V", "j", "close", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", StringUtils.EMPTY, "toString", "()Ljava/lang/String;", "Lokio/BufferedSink;", "b", "Ljava/util/zip/Deflater;", "c", "Z", "closed", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nDeflaterSink.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DeflaterSink.kt\nokio/DeflaterSink\n+ 2 Util.kt\nokio/-SegmentedByteString\n*L\n1#1,144:1\n87#2:145\n*S KotlinDebug\n*F\n+ 1 DeflaterSink.kt\nokio/DeflaterSink\n*L\n39#1:145\n*E\n"})
public final class DeflaterSink implements Sink {
    private final BufferedSink a;
    private final Deflater b;
    private boolean c;

    public DeflaterSink(BufferedSink bufferedSink, Deflater deflater) {
        Intrinsics.checkNotNullParameter(bufferedSink, ap.a(1211344950));
        Intrinsics.checkNotNullParameter(deflater, ap.a(1368182099));
        this.a = bufferedSink;
        this.b = deflater;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r2v0, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v1, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v2, types: [java.lang.String] */
    /* JADX WARN: Type inference failed for: r2v3, types: [int] */
    /* JADX WARN: Type inference failed for: r2v4, types: [int] */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r2v9 */
    private final void a(boolean z) throws IOException {
        Segment segmentJ0;
        ?? Deflate;
        Buffer buffer = this.a.getBuffer();
        while (true) {
            segmentJ0 = buffer.j0(1);
            ?? Deflate2 = "Deflater already closed";
            if (z) {
                try {
                    Deflater deflater = this.b;
                    byte[] bArr = segmentJ0.a;
                    int i = segmentJ0.c;
                    Deflate2 = deflater.deflate(bArr, i, 8192 - i, 2);
                    Deflate = Deflate2;
                } catch (IllegalStateException e) {
                    throw new IOException(Deflate2, e);
                } catch (NullPointerException e2) {
                    throw new IOException(Deflate2, e2);
                }
            } else {
                Deflater deflater2 = this.b;
                byte[] bArr2 = segmentJ0.a;
                int i2 = segmentJ0.c;
                Deflate = deflater2.deflate(bArr2, i2, 8192 - i2);
            }
            if (Deflate > 0) {
                segmentJ0.c += Deflate;
                buffer.b0(buffer.size() + ((long) Deflate));
                this.a.P1();
            } else if (this.b.needsInput()) {
                break;
            }
        }
        if (segmentJ0.b == segmentJ0.c) {
            buffer.a = segmentJ0.b();
            SegmentPool.b(segmentJ0);
        }
    }

    @Override // okio.Sink
    public void a2(Buffer buffer, long j) {
        Intrinsics.checkNotNullParameter(buffer, ClimateForcast.SOURCE);
        SegmentedByteString.b(buffer.size(), 0L, j);
        while (j > 0) {
            Segment segment = buffer.a;
            Intrinsics.checkNotNull(segment);
            int iMin = (int) Math.min(j, segment.c - segment.b);
            this.b.setInput(segment.a, segment.b, iMin);
            a(false);
            long j2 = iMin;
            buffer.b0(buffer.size() - j2);
            int i = segment.b + iMin;
            segment.b = i;
            if (i == segment.c) {
                buffer.a = segment.b();
                SegmentPool.b(segment);
            }
            j -= j2;
        }
        this.b.setInput(_ZlibJvmKt.c(), 0, 0);
    }

    @Override // okio.Sink, java.io.Closeable, java.lang.AutoCloseable
    public void close() throws Throwable {
        if (this.c) {
            return;
        }
        try {
            j();
            th = null;
        } catch (Throwable th) {
            th = th;
        }
        try {
            this.b.end();
        } catch (Throwable th2) {
            if (th == null) {
                th = th2;
            }
        }
        try {
            this.a.close();
        } catch (Throwable th3) {
            if (th == null) {
                th = th3;
            }
        }
        this.c = true;
        if (th != null) {
            throw th;
        }
    }

    @Override // okio.Sink, java.io.Flushable
    public void flush() {
        a(true);
        this.a.flush();
    }

    public final void j() throws IOException {
        this.b.finish();
        a(false);
    }

    @Override // okio.Sink
    public Timeout timeout() {
        return this.a.timeout();
    }

    public String toString() {
        return "DeflaterSink(" + this.a + ')';
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public DeflaterSink(Sink sink, Deflater deflater) {
        this(Okio.b(sink), deflater);
        Intrinsics.checkNotNullParameter(sink, "sink");
        Intrinsics.checkNotNullParameter(deflater, "deflater");
    }
}