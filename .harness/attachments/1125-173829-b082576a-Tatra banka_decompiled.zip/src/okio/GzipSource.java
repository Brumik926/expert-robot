package okio;

import h.ap;
import java.io.EOFException;
import java.io.IOException;
import java.util.zip.CRC32;
import java.util.zip.Inflater;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000h\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0005\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0004\b\u0003\u0010\u0004J\u000f\u0010\u0006\u001a\u00020\u0005H\u0002¢\u0006\u0004\b\u0006\u0010\u0007J\u000f\u0010\b\u001a\u00020\u0005H\u0002¢\u0006\u0004\b\b\u0010\u0007J'\u0010\u000e\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000bH\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ'\u0010\u0015\u001a\u00020\u00052\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0014\u001a\u00020\u0012H\u0002¢\u0006\u0004\b\u0015\u0010\u0016J\u001f\u0010\u0018\u001a\u00020\u000b2\u0006\u0010\u0017\u001a\u00020\t2\u0006\u0010\r\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u0018\u0010\u0019J\u000f\u0010\u001b\u001a\u00020\u001aH\u0016¢\u0006\u0004\b\u001b\u0010\u001cJ\u000f\u0010\u001d\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u001d\u0010\u0007R\u0016\u0010 \u001a\u00020\u001e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0015\u0010\u001fR\u0014\u0010\u0002\u001a\u00020!8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\"\u0010#R\u0018\u0010(\u001a\u00060$j\u0002`%8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b&\u0010'R\u0014\u0010,\u001a\u00020)8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b*\u0010+R\u0018\u00101\u001a\u00060-j\u0002`.8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b/\u00100¨\u00062"}, d2 = {"Lokio/GzipSource;", "Lokio/Source;", ClimateForcast.SOURCE, "<init>", "(Lokio/Source;)V", StringUtils.EMPTY, "j", "()V", "k", "Lokio/Buffer;", "buffer", StringUtils.EMPTY, MimeTypesReaderMetKeys.MATCH_OFFSET_ATTR, "byteCount", "o", "(Lokio/Buffer;JJ)V", StringUtils.EMPTY, "name", StringUtils.EMPTY, "expected", "actual", "a", "(Ljava/lang/String;II)V", "sink", "k3", "(Lokio/Buffer;J)J", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", "close", StringUtils.EMPTY, "B", "section", "Lokio/RealBufferedSource;", "b", "Lokio/RealBufferedSource;", "Ljava/util/zip/Inflater;", "Lokio/Inflater;", "c", "Ljava/util/zip/Inflater;", "inflater", "Lokio/InflaterSource;", "d", "Lokio/InflaterSource;", "inflaterSource", "Ljava/util/zip/CRC32;", "Lokio/internal/CRC32;", "e", "Ljava/util/zip/CRC32;", "crc", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nGzipSource.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GzipSource.kt\nokio/GzipSource\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 RealBufferedSource.kt\nokio/RealBufferedSource\n+ 4 GzipSource.kt\nokio/-GzipSourceExtensions\n+ 5 Util.kt\nokio/-SegmentedByteString\n*L\n1#1,222:1\n1#2:223\n63#3:224\n63#3:226\n63#3:228\n63#3:229\n63#3:230\n63#3:232\n63#3:234\n204#4:225\n204#4:227\n204#4:231\n204#4:233\n90#5:235\n*S KotlinDebug\n*F\n+ 1 GzipSource.kt\nokio/GzipSource\n*L\n103#1:224\n105#1:226\n117#1:228\n118#1:229\n120#1:230\n131#1:232\n142#1:234\n104#1:225\n115#1:227\n128#1:231\n139#1:233\n185#1:235\n*E\n"})
public final class GzipSource implements Source {
    private byte a;
    private final RealBufferedSource b;
    private final Inflater c;
    private final InflaterSource d;
    private final CRC32 e;

    public GzipSource(Source source) {
        Intrinsics.checkNotNullParameter(source, ap.a(8803813));
        RealBufferedSource realBufferedSource = new RealBufferedSource(source);
        this.b = realBufferedSource;
        Inflater inflater = new Inflater(true);
        this.c = inflater;
        this.d = new InflaterSource((BufferedSource) realBufferedSource, inflater);
        this.e = new CRC32();
    }

    private final void a(String str, int i, int i2) throws IOException {
        if (i2 == i) {
            return;
        }
        throw new IOException(str + ": actual 0x" + StringsKt.padStart(SegmentedByteString.g(i2), 8, '0') + " != expected 0x" + StringsKt.padStart(SegmentedByteString.g(i), 8, '0'));
    }

    private final void j() throws IOException {
        this.b.s2(10L);
        byte B = this.b.b.B(3L);
        boolean z = ((B >> 1) & 1) == 1;
        if (z) {
            o(this.b.b, 0L, 10L);
        }
        a("ID1ID2", 8075, this.b.readShort());
        this.b.skip(8L);
        if (((B >> 2) & 1) == 1) {
            this.b.s2(2L);
            if (z) {
                o(this.b.b, 0L, 2L);
            }
            long jT0 = this.b.b.t0() & 65535;
            this.b.s2(jT0);
            if (z) {
                o(this.b.b, 0L, jT0);
            }
            this.b.skip(jT0);
        }
        if (((B >> 3) & 1) == 1) {
            long jA = this.b.a((byte) 0);
            if (jA == -1) {
                throw new EOFException();
            }
            if (z) {
                o(this.b.b, 0L, jA + 1);
            }
            this.b.skip(jA + 1);
        }
        if (((B >> 4) & 1) == 1) {
            long jA2 = this.b.a((byte) 0);
            if (jA2 == -1) {
                throw new EOFException();
            }
            if (z) {
                o(this.b.b, 0L, jA2 + 1);
            }
            this.b.skip(jA2 + 1);
        }
        if (z) {
            a("FHCRC", this.b.t0(), (short) this.e.getValue());
            this.e.reset();
        }
    }

    private final void k() throws IOException {
        a("CRC", this.b.c3(), (int) this.e.getValue());
        a("ISIZE", this.b.c3(), (int) this.c.getBytesWritten());
    }

    private final void o(Buffer buffer, long j, long j2) {
        Segment segment = buffer.a;
        Intrinsics.checkNotNull(segment);
        while (true) {
            int i = segment.c;
            int i2 = segment.b;
            if (j < i - i2) {
                break;
            }
            j -= (long) (i - i2);
            segment = segment.f;
            Intrinsics.checkNotNull(segment);
        }
        while (j2 > 0) {
            int i3 = (int) (((long) segment.b) + j);
            int iMin = (int) Math.min(segment.c - i3, j2);
            this.e.update(segment.a, i3, iMin);
            j2 -= (long) iMin;
            segment = segment.f;
            Intrinsics.checkNotNull(segment);
            j = 0;
        }
    }

    @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.d.close();
    }

    @Override // okio.Source
    public long k3(Buffer buffer, long j) throws IOException {
        GzipSource gzipSource;
        Intrinsics.checkNotNullParameter(buffer, "sink");
        if (j < 0) {
            throw new IllegalArgumentException(("byteCount < 0: " + j).toString());
        }
        if (j == 0) {
            return 0L;
        }
        if (this.a == 0) {
            j();
            this.a = (byte) 1;
        }
        if (this.a == 1) {
            long size = buffer.size();
            long jK3 = this.d.k3(buffer, j);
            if (jK3 != -1) {
                o(buffer, size, jK3);
                return jK3;
            }
            gzipSource = this;
            gzipSource.a = (byte) 2;
        } else {
            gzipSource = this;
        }
        if (gzipSource.a == 2) {
            gzipSource.k();
            gzipSource.a = (byte) 3;
            if (!gzipSource.b.H2()) {
                throw new IOException("gzip finished without exhausting source");
            }
        }
        return -1L;
    }

    @Override // okio.Source
    public Timeout timeout() {
        return this.b.timeout();
    }
}