package okio;

import h.ap;
import java.io.Closeable;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okio.Path;
import okio.internal.ResourceFileSystem;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u000e\b&\u0018\u0000 %2\u00060\u0001j\u0002`\u0002:\u00013B\u0007¢\u0006\u0004\b\u0003\u0010\u0004J\u0015\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\b\u0010\tJ\u0019\u0010\n\u001a\u0004\u0018\u00010\u00072\u0006\u0010\u0006\u001a\u00020\u0005H&¢\u0006\u0004\b\n\u0010\tJ\u0015\u0010\f\u001a\u00020\u000b2\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\f\u0010\rJ\u001d\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00050\u000f2\u0006\u0010\u000e\u001a\u00020\u0005H&¢\u0006\u0004\b\u0010\u0010\u0011J\u001f\u0010\u0012\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u000f2\u0006\u0010\u000e\u001a\u00020\u0005H&¢\u0006\u0004\b\u0012\u0010\u0011J\u0017\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0013\u001a\u00020\u0005H&¢\u0006\u0004\b\u0015\u0010\u0016J+\u0010\u0019\u001a\u00020\u00142\u0006\u0010\u0013\u001a\u00020\u00052\b\b\u0002\u0010\u0017\u001a\u00020\u000b2\b\b\u0002\u0010\u0018\u001a\u00020\u000bH&¢\u0006\u0004\b\u0019\u0010\u001aJ\u0015\u0010\u001b\u001a\u00020\u00142\u0006\u0010\u0013\u001a\u00020\u0005¢\u0006\u0004\b\u001b\u0010\u0016J\u0017\u0010\u001d\u001a\u00020\u001c2\u0006\u0010\u0013\u001a\u00020\u0005H&¢\u0006\u0004\b\u001d\u0010\u001eJ!\u0010 \u001a\u00020\u001f2\u0006\u0010\u0013\u001a\u00020\u00052\b\b\u0002\u0010\u0017\u001a\u00020\u000bH&¢\u0006\u0004\b \u0010!J\u0015\u0010\"\u001a\u00020\u001f2\u0006\u0010\u0013\u001a\u00020\u0005¢\u0006\u0004\b\"\u0010#J!\u0010$\u001a\u00020\u001f2\u0006\u0010\u0013\u001a\u00020\u00052\b\b\u0002\u0010\u0018\u001a\u00020\u000bH&¢\u0006\u0004\b$\u0010!J\u0015\u0010%\u001a\u00020\u001f2\u0006\u0010\u0013\u001a\u00020\u0005¢\u0006\u0004\b%\u0010#J!\u0010'\u001a\u00020&2\u0006\u0010\u000e\u001a\u00020\u00052\b\b\u0002\u0010\u0017\u001a\u00020\u000bH&¢\u0006\u0004\b'\u0010(J\u001f\u0010)\u001a\u00020&2\u0006\u0010\u000e\u001a\u00020\u00052\b\b\u0002\u0010\u0017\u001a\u00020\u000b¢\u0006\u0004\b)\u0010(J\u0015\u0010*\u001a\u00020&2\u0006\u0010\u000e\u001a\u00020\u0005¢\u0006\u0004\b*\u0010+J\u001f\u0010.\u001a\u00020&2\u0006\u0010,\u001a\u00020\u00052\u0006\u0010-\u001a\u00020\u0005H&¢\u0006\u0004\b.\u0010/J!\u00100\u001a\u00020&2\u0006\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\u0018\u001a\u00020\u000bH&¢\u0006\u0004\b0\u0010(J\u0015\u00101\u001a\u00020&2\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b1\u0010+J\u000f\u00102\u001a\u00020&H\u0016¢\u0006\u0004\b2\u0010\u0004¨\u00064"}, d2 = {"Lokio/FileSystem;", "Ljava/io/Closeable;", "Lokio/Closeable;", "<init>", "()V", "Lokio/Path;", "path", "Lokio/FileMetadata;", "D", "(Lokio/Path;)Lokio/FileMetadata;", "I", StringUtils.EMPTY, "u", "(Lokio/Path;)Z", "dir", StringUtils.EMPTY, "A", "(Lokio/Path;)Ljava/util/List;", "B", "file", "Lokio/FileHandle;", "J", "(Lokio/Path;)Lokio/FileHandle;", "mustCreate", "mustExist", "P", "(Lokio/Path;ZZ)Lokio/FileHandle;", "O", "Lokio/Source;", "W", "(Lokio/Path;)Lokio/Source;", "Lokio/Sink;", "V", "(Lokio/Path;Z)Lokio/Sink;", "Q", "(Lokio/Path;)Lokio/Sink;", "d", "a", StringUtils.EMPTY, "k", "(Lokio/Path;Z)V", "j", "g", "(Lokio/Path;)V", ClimateForcast.SOURCE, "target", "e", "(Lokio/Path;Lokio/Path;)V", "r", "q", "close", "Companion", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nFileSystem.kt\nKotlin\n*S Kotlin\n*F\n+ 1 FileSystem.kt\nokio/FileSystem\n+ 2 Okio.kt\nokio/Okio__OkioKt\n*L\n1#1,191:1\n58#2,22:192\n58#2,22:214\n*S KotlinDebug\n*F\n+ 1 FileSystem.kt\nokio/FileSystem\n*L\n73#1:192,22\n95#1:214,22\n*E\n"})
public abstract class FileSystem implements Closeable {
    public static final Companion a = new Companion(null);
    public static final FileSystem b;
    public static final Path c;
    public static final FileSystem d;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0014\u0010\u0005\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0005\u0010\u0006R\u0014\u0010\b\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\b\u0010\tR\u0014\u0010\n\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\n\u0010\u0006¨\u0006\u000b"}, d2 = {"Lokio/FileSystem$Companion;", StringUtils.EMPTY, "<init>", "()V", "Lokio/FileSystem;", "SYSTEM", "Lokio/FileSystem;", "Lokio/Path;", "SYSTEM_TEMPORARY_DIRECTORY", "Lokio/Path;", "RESOURCES", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        FileSystem jvmSystemFileSystem;
        try {
            Class.forName(ap.a(1647046967));
            jvmSystemFileSystem = new NioSystemFileSystem();
        } catch (ClassNotFoundException unused) {
            jvmSystemFileSystem = new JvmSystemFileSystem();
        }
        b = jvmSystemFileSystem;
        Path.Companion companion = Path.b;
        String property = System.getProperty(ap.a(245260832));
        Intrinsics.checkNotNullExpressionValue(property, ap.a(466210149));
        c = Path.Companion.e(companion, property, false, 1, null);
        ClassLoader classLoader = ResourceFileSystem.class.getClassLoader();
        Intrinsics.checkNotNullExpressionValue(classLoader, ap.a(2061854466));
        d = new ResourceFileSystem(classLoader, false, null, 4, null);
    }

    public static /* synthetic */ void o(FileSystem fileSystem, Path path, boolean z, int i, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: createDirectory");
        }
        if ((i & 2) != 0) {
            z = false;
        }
        fileSystem.k(path, z);
    }

    public abstract List A(Path path);

    public abstract List B(Path path);

    public final FileMetadata D(Path path) {
        Intrinsics.checkNotNullParameter(path, "path");
        return okio.internal.FileSystem.d(this, path);
    }

    public abstract FileMetadata I(Path path);

    public abstract FileHandle J(Path path);

    public final FileHandle O(Path path) {
        Intrinsics.checkNotNullParameter(path, "file");
        return P(path, false, false);
    }

    public abstract FileHandle P(Path path, boolean z, boolean z2);

    public final Sink Q(Path path) {
        Intrinsics.checkNotNullParameter(path, "file");
        return V(path, false);
    }

    public abstract Sink V(Path path, boolean z);

    public abstract Source W(Path path);

    public final Sink a(Path path) {
        Intrinsics.checkNotNullParameter(path, "file");
        return d(path, false);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
    }

    public abstract Sink d(Path path, boolean z);

    public abstract void e(Path path, Path path2);

    public final void g(Path path) {
        Intrinsics.checkNotNullParameter(path, "dir");
        j(path, false);
    }

    public final void j(Path path, boolean z) {
        Intrinsics.checkNotNullParameter(path, "dir");
        okio.internal.FileSystem.b(this, path, z);
    }

    public abstract void k(Path path, boolean z);

    public final void q(Path path) {
        Intrinsics.checkNotNullParameter(path, "path");
        r(path, false);
    }

    public abstract void r(Path path, boolean z);

    public final boolean u(Path path) {
        Intrinsics.checkNotNullParameter(path, "path");
        return okio.internal.FileSystem.c(this, path);
    }
}