package okio;

import kotlin.Deprecated;
import kotlin.Metadata;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: renamed from: okio.-DeprecatedOkio, reason: invalid class name */
/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Deprecated(message = "changed in Okio 2.x")
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lokio/-DeprecatedOkio;", StringUtils.EMPTY, "<init>", "()V", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class DeprecatedOkio {
    public static final DeprecatedOkio a = new DeprecatedOkio();

    private DeprecatedOkio() {
    }
}