package okio;

import h.ap;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okio.internal.ByteStringNonJs;
import org.apache.tika.fork.ForkServer;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0005\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0014\n\u0002\u0010\u0000\n\u0002\b\u0014\b\u0016\u0018\u0000 \u00142\u00020\u00012\b\u0012\u0004\u0012\u00020\u00000\u0002:\u0001YB\u0011\b\u0000\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\u000f\u0010\b\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\b\u0010\tJ\u0017\u0010\f\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\f\u0010\rJ\u000f\u0010\u000e\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u000e\u0010\tJ\r\u0010\u000f\u001a\u00020\u0000¢\u0006\u0004\b\u000f\u0010\u0010J\r\u0010\u0011\u001a\u00020\u0000¢\u0006\u0004\b\u0011\u0010\u0010J\r\u0010\u0012\u001a\u00020\u0000¢\u0006\u0004\b\u0012\u0010\u0010J\u0017\u0010\u0014\u001a\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u0007H\u0010¢\u0006\u0004\b\u0014\u0010\u0015J\u000f\u0010\u0016\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0016\u0010\tJ\u000f\u0010\u0017\u001a\u00020\u0000H\u0016¢\u0006\u0004\b\u0017\u0010\u0010J#\u0010\u001b\u001a\u00020\u00002\b\b\u0002\u0010\u0019\u001a\u00020\u00182\b\b\u0002\u0010\u001a\u001a\u00020\u0018H\u0017¢\u0006\u0004\b\u001b\u0010\u001cJ\u0017\u0010\u001f\u001a\u00020\u001e2\u0006\u0010\u001d\u001a\u00020\u0018H\u0010¢\u0006\u0004\b\u001f\u0010 J\u0018\u0010\"\u001a\u00020\u001e2\u0006\u0010!\u001a\u00020\u0018H\u0087\u0002¢\u0006\u0004\b\"\u0010 J\u000f\u0010#\u001a\u00020\u0018H\u0010¢\u0006\u0004\b#\u0010$J\u000f\u0010%\u001a\u00020\u0003H\u0016¢\u0006\u0004\b%\u0010&J\u000f\u0010'\u001a\u00020\u0003H\u0010¢\u0006\u0004\b'\u0010&J'\u0010-\u001a\u00020,2\u0006\u0010)\u001a\u00020(2\u0006\u0010*\u001a\u00020\u00182\u0006\u0010+\u001a\u00020\u0018H\u0010¢\u0006\u0004\b-\u0010.J/\u00102\u001a\u0002012\u0006\u0010*\u001a\u00020\u00182\u0006\u0010/\u001a\u00020\u00002\u0006\u00100\u001a\u00020\u00182\u0006\u0010+\u001a\u00020\u0018H\u0016¢\u0006\u0004\b2\u00103J/\u00104\u001a\u0002012\u0006\u0010*\u001a\u00020\u00182\u0006\u0010/\u001a\u00020\u00032\u0006\u00100\u001a\u00020\u00182\u0006\u0010+\u001a\u00020\u0018H\u0016¢\u0006\u0004\b4\u00105J3\u00108\u001a\u00020,2\b\b\u0002\u0010*\u001a\u00020\u00182\u0006\u00106\u001a\u00020\u00032\b\b\u0002\u00107\u001a\u00020\u00182\u0006\u0010+\u001a\u00020\u0018H\u0016¢\u0006\u0004\b8\u00109J\u0015\u0010;\u001a\u0002012\u0006\u0010:\u001a\u00020\u0000¢\u0006\u0004\b;\u0010<J\u0015\u0010>\u001a\u0002012\u0006\u0010=\u001a\u00020\u0000¢\u0006\u0004\b>\u0010<J!\u0010@\u001a\u00020\u00182\u0006\u0010/\u001a\u00020\u00002\b\b\u0002\u0010?\u001a\u00020\u0018H\u0007¢\u0006\u0004\b@\u0010AJ!\u0010B\u001a\u00020\u00182\u0006\u0010/\u001a\u00020\u00032\b\b\u0002\u0010?\u001a\u00020\u0018H\u0017¢\u0006\u0004\bB\u0010CJ!\u0010D\u001a\u00020\u00182\u0006\u0010/\u001a\u00020\u00002\b\b\u0002\u0010?\u001a\u00020\u0018H\u0007¢\u0006\u0004\bD\u0010AJ!\u0010E\u001a\u00020\u00182\u0006\u0010/\u001a\u00020\u00032\b\b\u0002\u0010?\u001a\u00020\u0018H\u0017¢\u0006\u0004\bE\u0010CJ\u001a\u0010G\u001a\u0002012\b\u0010/\u001a\u0004\u0018\u00010FH\u0096\u0002¢\u0006\u0004\bG\u0010HJ\u000f\u0010I\u001a\u00020\u0018H\u0016¢\u0006\u0004\bI\u0010$J\u0018\u0010J\u001a\u00020\u00182\u0006\u0010/\u001a\u00020\u0000H\u0096\u0002¢\u0006\u0004\bJ\u0010KJ\u000f\u0010L\u001a\u00020\u0007H\u0016¢\u0006\u0004\bL\u0010\tR\u001a\u0010\u0004\u001a\u00020\u00038\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u000e\u0010M\u001a\u0004\bN\u0010&R\"\u0010I\u001a\u00020\u00188\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bJ\u0010O\u001a\u0004\bP\u0010$\"\u0004\bQ\u0010RR$\u0010W\u001a\u0004\u0018\u00010\u00078\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b8\u0010S\u001a\u0004\bT\u0010\t\"\u0004\bU\u0010VR\u0011\u0010X\u001a\u00020\u00188G¢\u0006\u0006\u001a\u0004\bX\u0010$¨\u0006Z"}, d2 = {"Lokio/ByteString;", "Ljava/io/Serializable;", StringUtils.EMPTY, StringUtils.EMPTY, "data", "<init>", "([B)V", StringUtils.EMPTY, "M", "()Ljava/lang/String;", "Ljava/nio/charset/Charset;", "charset", "G", "(Ljava/nio/charset/Charset;)Ljava/lang/String;", "a", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "()Lokio/ByteString;", "C", "E", "algorithm", "d", "(Ljava/lang/String;)Lokio/ByteString;", "l", "K", StringUtils.EMPTY, "beginIndex", "endIndex", "H", "(II)Lokio/ByteString;", "pos", StringUtils.EMPTY, "q", "(I)B", "index", "g", "j", "()I", "L", "()[B", "p", "Lokio/Buffer;", "buffer", MimeTypesReaderMetKeys.MATCH_OFFSET_ATTR, "byteCount", StringUtils.EMPTY, "N", "(Lokio/Buffer;II)V", "other", "otherOffset", StringUtils.EMPTY, "y", "(ILokio/ByteString;II)Z", "z", "(I[BII)Z", "target", "targetOffset", "c", "(I[BII)V", "prefix", "F", "(Lokio/ByteString;)Z", "suffix", "f", "fromIndex", "m", "(Lokio/ByteString;I)I", "n", "([BI)I", "s", "t", StringUtils.EMPTY, "equals", "(Ljava/lang/Object;)Z", "hashCode", "b", "(Lokio/ByteString;)I", "toString", "[B", "h", "I", "i", "A", "(I)V", "Ljava/lang/String;", "k", "B", "(Ljava/lang/String;)V", "utf8", "size", "Companion", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nByteString.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ByteString.kt\nokio/ByteString\n+ 2 ByteString.kt\nokio/internal/-ByteString\n+ 3 Util.kt\nokio/-SegmentedByteString\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,364:1\n41#2,7:365\n51#2:372\n54#2:373\n61#2,4:374\n65#2:379\n67#2:381\n73#2,23:382\n101#2,23:405\n128#2:428\n129#2,9:430\n141#2:439\n144#2:440\n147#2:441\n150#2:442\n158#2:443\n168#2,3:444\n167#2:447\n181#2,2:448\n186#2:450\n190#2:451\n194#2:452\n198#2:453\n202#2,7:454\n215#2:461\n219#2,7:462\n230#2,4:469\n239#2,5:473\n248#2,6:478\n254#2,9:485\n297#2,8:494\n128#2:502\n129#2,9:504\n308#2,9:513\n69#3:378\n75#3:380\n75#3:484\n1#4:429\n1#4:503\n*S KotlinDebug\n*F\n+ 1 ByteString.kt\nokio/ByteString\n*L\n66#1:365,7\n71#1:372\n108#1:373\n110#1:374,4\n110#1:379\n110#1:381\n112#1:382,23\n114#1:405,23\n118#1:428\n118#1:430,9\n120#1:439\n129#1:440\n131#1:441\n133#1:442\n152#1:443\n159#1:444,3\n159#1:447\n166#1:448,2\n168#1:450\n170#1:451\n172#1:452\n174#1:453\n180#1:454,7\n183#1:461\n186#1:462,7\n188#1:469,4\n190#1:473,5\n192#1:478,6\n192#1:485,9\n194#1:494,8\n194#1:502\n194#1:504,9\n194#1:513,9\n110#1:378\n110#1:380\n192#1:484\n118#1:429\n194#1:503\n*E\n"})
public class ByteString implements Serializable, Comparable<ByteString> {
    public static final Companion d = new Companion(null);
    public static final ByteString e = new ByteString(new byte[0]);
    private final byte[] a;
    private transient int b;
    private transient String c;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0002\u0010\u0005\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\t\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001b\u0010\b\u001a\u00020\u00072\n\u0010\u0006\u001a\u00020\u0004\"\u00020\u0005H\u0007¢\u0006\u0004\b\b\u0010\tJ'\u0010\r\u001a\u00020\u0007*\u00020\u00042\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\f\u001a\u00020\nH\u0007¢\u0006\u0004\b\r\u0010\u000eJ\u0013\u0010\u0010\u001a\u00020\u0007*\u00020\u000fH\u0007¢\u0006\u0004\b\u0010\u0010\u0011J\u001d\u0010\u0014\u001a\u00020\u0007*\u00020\u000f2\b\b\u0002\u0010\u0013\u001a\u00020\u0012H\u0007¢\u0006\u0004\b\u0014\u0010\u0015J\u0015\u0010\u0016\u001a\u0004\u0018\u00010\u0007*\u00020\u000fH\u0007¢\u0006\u0004\b\u0016\u0010\u0011J\u0013\u0010\u0017\u001a\u00020\u0007*\u00020\u000fH\u0007¢\u0006\u0004\b\u0017\u0010\u0011R\u0014\u0010\u0019\u001a\u00020\u00188\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0019\u0010\u001aR\u0014\u0010\u001b\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u001b\u0010\u001c¨\u0006\u001d"}, d2 = {"Lokio/ByteString$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, StringUtils.EMPTY, "data", "Lokio/ByteString;", "e", "([B)Lokio/ByteString;", StringUtils.EMPTY, MimeTypesReaderMetKeys.MATCH_OFFSET_ATTR, "byteCount", "f", "([BII)Lokio/ByteString;", StringUtils.EMPTY, "d", "(Ljava/lang/String;)Lokio/ByteString;", "Ljava/nio/charset/Charset;", "charset", "c", "(Ljava/lang/String;Ljava/nio/charset/Charset;)Lokio/ByteString;", "a", "b", StringUtils.EMPTY, "serialVersionUID", "J", "EMPTY", "Lokio/ByteString;", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nByteString.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ByteString.kt\nokio/ByteString$Companion\n+ 2 ByteString.kt\nokio/internal/-ByteString\n+ 3 ByteStringNonJs.kt\nokio/internal/-ByteStringNonJs\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,364:1\n266#2:365\n270#2,2:366\n276#2,3:368\n283#2,2:371\n25#3:373\n27#3,7:375\n1#4:374\n1#4:382\n*S KotlinDebug\n*F\n+ 1 ByteString.kt\nokio/ByteString$Companion\n*L\n234#1:365\n239#1:366,2\n251#1:368,3\n259#1:371,2\n262#1:373\n262#1:375,7\n262#1:374\n*E\n"})
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public static /* synthetic */ ByteString g(Companion companion, byte[] bArr, int i, int i2, int i3, Object obj) {
            if ((i3 & 1) != 0) {
                i = 0;
            }
            if ((i3 & 2) != 0) {
                i2 = bArr.length;
            }
            return companion.f(bArr, i, i2);
        }

        public final ByteString a(String str) {
            Intrinsics.checkNotNullParameter(str, ap.a(823990412));
            byte[] bArrA = Base64.a(str);
            if (bArrA != null) {
                return new ByteString(bArrA);
            }
            return null;
        }

        public final ByteString b(String str) {
            Intrinsics.checkNotNullParameter(str, "<this>");
            if (str.length() % 2 != 0) {
                throw new IllegalArgumentException(("Unexpected hex string: " + str).toString());
            }
            int length = str.length() / 2;
            byte[] bArr = new byte[length];
            for (int i = 0; i < length; i++) {
                int i2 = i * 2;
                bArr[i] = (byte) ((ByteStringNonJs.b(str.charAt(i2)) << 4) + ByteStringNonJs.b(str.charAt(i2 + 1)));
            }
            return new ByteString(bArr);
        }

        public final ByteString c(String str, Charset charset) {
            Intrinsics.checkNotNullParameter(str, "<this>");
            Intrinsics.checkNotNullParameter(charset, "charset");
            byte[] bytes = str.getBytes(charset);
            Intrinsics.checkNotNullExpressionValue(bytes, "getBytes(...)");
            return new ByteString(bytes);
        }

        public final ByteString d(String str) {
            Intrinsics.checkNotNullParameter(str, "<this>");
            ByteString byteString = new ByteString(_JvmPlatformKt.a(str));
            byteString.B(str);
            return byteString;
        }

        public final ByteString e(byte... bArr) {
            Intrinsics.checkNotNullParameter(bArr, "data");
            byte[] bArrCopyOf = Arrays.copyOf(bArr, bArr.length);
            Intrinsics.checkNotNullExpressionValue(bArrCopyOf, "copyOf(...)");
            return new ByteString(bArrCopyOf);
        }

        public final ByteString f(byte[] bArr, int i, int i2) {
            Intrinsics.checkNotNullParameter(bArr, "<this>");
            SegmentedByteString.b(bArr.length, i, i2);
            return new ByteString(ArraysKt.copyOfRange(bArr, i, i2 + i));
        }

        private Companion() {
        }
    }

    public ByteString(byte[] bArr) {
        Intrinsics.checkNotNullParameter(bArr, ap.a(1413601292));
        this.a = bArr;
    }

    public static /* synthetic */ ByteString I(ByteString byteString, int i, int i2, int i3, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: substring");
        }
        if ((i3 & 1) != 0) {
            i = 0;
        }
        if ((i3 & 2) != 0) {
            i2 = byteString.size();
        }
        return byteString.H(i, i2);
    }

    public static final ByteString e(String str) {
        return d.d(str);
    }

    public static /* synthetic */ int o(ByteString byteString, ByteString byteString2, int i, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: indexOf");
        }
        if ((i2 & 2) != 0) {
            i = 0;
        }
        return byteString.m(byteString2, i);
    }

    public static /* synthetic */ int v(ByteString byteString, ByteString byteString2, int i, int i2, Object obj) {
        if (obj != null) {
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: lastIndexOf");
        }
        if ((i2 & 2) != 0) {
            i = byteString.size();
        }
        return byteString.s(byteString2, i);
    }

    public static final ByteString x(byte... bArr) {
        return d.e(bArr);
    }

    public final void A(int i) {
        this.b = i;
    }

    public final void B(String str) {
        this.c = str;
    }

    public final ByteString C() {
        return d("SHA-1");
    }

    public final ByteString E() {
        return d("SHA-256");
    }

    public final boolean F(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "prefix");
        return y(0, byteString, 0, byteString.size());
    }

    public String G(Charset charset) {
        Intrinsics.checkNotNullParameter(charset, "charset");
        return new String(this.a, charset);
    }

    public ByteString H(int i, int i2) {
        if (i < 0) {
            throw new IllegalArgumentException("beginIndex < 0");
        }
        if (i2 <= h().length) {
            if (i2 - i >= 0) {
                return (i == 0 && i2 == h().length) ? this : new ByteString(ArraysKt.copyOfRange(h(), i, i2));
            }
            throw new IllegalArgumentException("endIndex < beginIndex");
        }
        throw new IllegalArgumentException(("endIndex > length(" + h().length + ')').toString());
    }

    public ByteString K() {
        for (int i = 0; i < h().length; i++) {
            byte b = h()[i];
            if (b >= 65 && b <= 90) {
                byte[] bArrH = h();
                byte[] bArrCopyOf = Arrays.copyOf(bArrH, bArrH.length);
                Intrinsics.checkNotNullExpressionValue(bArrCopyOf, "copyOf(...)");
                bArrCopyOf[i] = (byte) (b + 32);
                for (int i2 = i + 1; i2 < bArrCopyOf.length; i2++) {
                    byte b2 = bArrCopyOf[i2];
                    if (b2 >= 65 && b2 <= 90) {
                        bArrCopyOf[i2] = (byte) (b2 + 32);
                    }
                }
                return new ByteString(bArrCopyOf);
            }
        }
        return this;
    }

    public byte[] L() {
        byte[] bArrH = h();
        byte[] bArrCopyOf = Arrays.copyOf(bArrH, bArrH.length);
        Intrinsics.checkNotNullExpressionValue(bArrCopyOf, "copyOf(...)");
        return bArrCopyOf;
    }

    public String M() {
        String strK = k();
        if (strK != null) {
            return strK;
        }
        String strC = _JvmPlatformKt.c(p());
        B(strC);
        return strC;
    }

    public void N(Buffer buffer, int i, int i2) {
        Intrinsics.checkNotNullParameter(buffer, "buffer");
        okio.internal.ByteString.c(this, buffer, i, i2);
    }

    public String a() {
        return Base64.c(h(), null, 1, null);
    }

    @Override // java.lang.Comparable
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public int compareTo(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "other");
        int size = size();
        int size2 = byteString.size();
        int iMin = Math.min(size, size2);
        for (int i = 0; i < iMin; i++) {
            int iG = g(i) & ForkServer.ERROR;
            int iG2 = byteString.g(i) & ForkServer.ERROR;
            if (iG != iG2) {
                return iG < iG2 ? -1 : 1;
            }
        }
        if (size == size2) {
            return 0;
        }
        return size < size2 ? -1 : 1;
    }

    public void c(int i, byte[] bArr, int i2, int i3) {
        Intrinsics.checkNotNullParameter(bArr, "target");
        ArraysKt.copyInto(h(), bArr, i2, i, i3 + i);
    }

    public ByteString d(String str) throws NoSuchAlgorithmException {
        Intrinsics.checkNotNullParameter(str, "algorithm");
        MessageDigest messageDigest = MessageDigest.getInstance(str);
        messageDigest.update(this.a, 0, size());
        byte[] bArrDigest = messageDigest.digest();
        Intrinsics.checkNotNull(bArrDigest);
        return new ByteString(bArrDigest);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof ByteString) {
            ByteString byteString = (ByteString) obj;
            if (byteString.size() == h().length && byteString.z(0, h(), 0, h().length)) {
                return true;
            }
        }
        return false;
    }

    public final boolean f(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "suffix");
        return y(size() - byteString.size(), byteString, 0, byteString.size());
    }

    public final byte g(int i) {
        return q(i);
    }

    public final byte[] h() {
        return this.a;
    }

    public int hashCode() {
        int i = i();
        if (i != 0) {
            return i;
        }
        int iHashCode = Arrays.hashCode(h());
        A(iHashCode);
        return iHashCode;
    }

    public final int i() {
        return this.b;
    }

    public int j() {
        return h().length;
    }

    public final String k() {
        return this.c;
    }

    public String l() {
        char[] cArr = new char[h().length * 2];
        int i = 0;
        for (byte b : h()) {
            int i2 = i + 1;
            cArr[i] = okio.internal.ByteString.d()[(b >> 4) & 15];
            i += 2;
            cArr[i2] = okio.internal.ByteString.d()[b & 15];
        }
        return StringsKt.concatToString(cArr);
    }

    public final int m(ByteString byteString, int i) {
        Intrinsics.checkNotNullParameter(byteString, "other");
        return n(byteString.p(), i);
    }

    public int n(byte[] bArr, int i) {
        Intrinsics.checkNotNullParameter(bArr, "other");
        int length = h().length - bArr.length;
        int iMax = Math.max(i, 0);
        if (iMax > length) {
            return -1;
        }
        while (!SegmentedByteString.a(h(), iMax, bArr, 0, bArr.length)) {
            if (iMax == length) {
                return -1;
            }
            iMax++;
        }
        return iMax;
    }

    public byte[] p() {
        return h();
    }

    public byte q(int i) {
        return h()[i];
    }

    public final int s(ByteString byteString, int i) {
        Intrinsics.checkNotNullParameter(byteString, "other");
        return t(byteString.p(), i);
    }

    public final int size() {
        return j();
    }

    public int t(byte[] bArr, int i) {
        Intrinsics.checkNotNullParameter(bArr, "other");
        for (int iMin = Math.min(i, h().length - bArr.length); -1 < iMin; iMin--) {
            if (SegmentedByteString.a(h(), iMin, bArr, 0, bArr.length)) {
                return iMin;
            }
        }
        return -1;
    }

    public String toString() {
        if (h().length == 0) {
            return "[size=0]";
        }
        int iB = okio.internal.ByteString.b(h(), 64);
        if (iB != -1) {
            String strM = M();
            String strSubstring = strM.substring(0, iB);
            Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
            String strReplace$default = StringsKt.replace$default(StringsKt.replace$default(StringsKt.replace$default(strSubstring, "\\", "\\\\", false, 4, (Object) null), "\n", "\\n", false, 4, (Object) null), "\r", "\\r", false, 4, (Object) null);
            if (iB >= strM.length()) {
                return "[text=" + strReplace$default + AbstractJsonLexerKt.END_LIST;
            }
            return "[size=" + h().length + " text=" + strReplace$default + "…]";
        }
        if (h().length <= 64) {
            return "[hex=" + l() + AbstractJsonLexerKt.END_LIST;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("[size=");
        sb.append(h().length);
        sb.append(" hex=");
        if (64 <= h().length) {
            sb.append((64 == h().length ? this : new ByteString(ArraysKt.copyOfRange(h(), 0, 64))).l());
            sb.append("…]");
            return sb.toString();
        }
        throw new IllegalArgumentException(("endIndex > length(" + h().length + ')').toString());
    }

    public final ByteString w() {
        return d("MD5");
    }

    public boolean y(int i, ByteString byteString, int i2, int i3) {
        Intrinsics.checkNotNullParameter(byteString, "other");
        return byteString.z(i2, h(), i, i3);
    }

    public boolean z(int i, byte[] bArr, int i2, int i3) {
        Intrinsics.checkNotNullParameter(bArr, "other");
        return i >= 0 && i <= h().length - i3 && i2 >= 0 && i2 <= bArr.length - i3 && SegmentedByteString.a(h(), i, bArr, i2, i3);
    }
}