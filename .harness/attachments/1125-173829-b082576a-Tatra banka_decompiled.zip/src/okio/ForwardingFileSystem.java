package okio;

import h.ap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u000e\b&\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0001¢\u0006\u0004\b\u0003\u0010\u0004J'\u0010\n\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\t\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\n\u0010\u000bJ\u001f\u0010\f\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\f\u0010\rJ\u0019\u0010\u000f\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0006\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u000f\u0010\u0010J\u001d\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\u00050\u00122\u0006\u0010\u0011\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0013\u0010\u0014J\u001f\u0010\u0015\u001a\n\u0012\u0004\u0012\u00020\u0005\u0018\u00010\u00122\u0006\u0010\u0011\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0015\u0010\u0014J\u0017\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0018\u0010\u0019J'\u0010\u001d\u001a\u00020\u00172\u0006\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u001c\u001a\u00020\u001aH\u0016¢\u0006\u0004\b\u001d\u0010\u001eJ\u0017\u0010 \u001a\u00020\u001f2\u0006\u0010\u0016\u001a\u00020\u0005H\u0016¢\u0006\u0004\b \u0010!J\u001f\u0010#\u001a\u00020\"2\u0006\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u001b\u001a\u00020\u001aH\u0016¢\u0006\u0004\b#\u0010$J\u001f\u0010%\u001a\u00020\"2\u0006\u0010\u0016\u001a\u00020\u00052\u0006\u0010\u001c\u001a\u00020\u001aH\u0016¢\u0006\u0004\b%\u0010$J\u001f\u0010'\u001a\u00020&2\u0006\u0010\u0011\u001a\u00020\u00052\u0006\u0010\u001b\u001a\u00020\u001aH\u0016¢\u0006\u0004\b'\u0010(J\u001f\u0010+\u001a\u00020&2\u0006\u0010)\u001a\u00020\u00052\u0006\u0010*\u001a\u00020\u0005H\u0016¢\u0006\u0004\b+\u0010,J\u001f\u0010-\u001a\u00020&2\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u001c\u001a\u00020\u001aH\u0016¢\u0006\u0004\b-\u0010(J\u000f\u0010.\u001a\u00020&H\u0016¢\u0006\u0004\b.\u0010/J\u000f\u00100\u001a\u00020\u0007H\u0016¢\u0006\u0004\b0\u00101R\u0017\u0010\u0002\u001a\u00020\u00018\u0007¢\u0006\f\n\u0004\b+\u00102\u001a\u0004\b\u0002\u00103¨\u00064"}, d2 = {"Lokio/ForwardingFileSystem;", "Lokio/FileSystem;", "delegate", "<init>", "(Lokio/FileSystem;)V", "Lokio/Path;", "path", StringUtils.EMPTY, "functionName", "parameterName", "X", "(Lokio/Path;Ljava/lang/String;Ljava/lang/String;)Lokio/Path;", "a0", "(Lokio/Path;Ljava/lang/String;)Lokio/Path;", "Lokio/FileMetadata;", "I", "(Lokio/Path;)Lokio/FileMetadata;", "dir", StringUtils.EMPTY, "A", "(Lokio/Path;)Ljava/util/List;", "B", "file", "Lokio/FileHandle;", "J", "(Lokio/Path;)Lokio/FileHandle;", StringUtils.EMPTY, "mustCreate", "mustExist", "P", "(Lokio/Path;ZZ)Lokio/FileHandle;", "Lokio/Source;", "W", "(Lokio/Path;)Lokio/Source;", "Lokio/Sink;", "V", "(Lokio/Path;Z)Lokio/Sink;", "d", StringUtils.EMPTY, "k", "(Lokio/Path;Z)V", ClimateForcast.SOURCE, "target", "e", "(Lokio/Path;Lokio/Path;)V", "r", "close", "()V", "toString", "()Ljava/lang/String;", "Lokio/FileSystem;", "()Lokio/FileSystem;", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nForwardingFileSystem.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ForwardingFileSystem.kt\nokio/ForwardingFileSystem\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,252:1\n1634#2,3:253\n1634#2,3:256\n*S KotlinDebug\n*F\n+ 1 ForwardingFileSystem.kt\nokio/ForwardingFileSystem\n*L\n170#1:253,3\n178#1:256,3\n*E\n"})
public abstract class ForwardingFileSystem extends FileSystem {
    private final FileSystem e;

    public ForwardingFileSystem(FileSystem fileSystem) {
        Intrinsics.checkNotNullParameter(fileSystem, ap.a(52785730));
        this.e = fileSystem;
    }

    @Override // okio.FileSystem
    public List A(Path path) {
        Intrinsics.checkNotNullParameter(path, "dir");
        List listA = this.e.A(X(path, "list", "dir"));
        ArrayList arrayList = new ArrayList();
        Iterator it = listA.iterator();
        while (it.hasNext()) {
            arrayList.add(a0((Path) it.next(), "list"));
        }
        CollectionsKt.sort(arrayList);
        return arrayList;
    }

    @Override // okio.FileSystem
    public List B(Path path) {
        Intrinsics.checkNotNullParameter(path, "dir");
        List listB = this.e.B(X(path, "listOrNull", "dir"));
        if (listB == null) {
            return null;
        }
        ArrayList arrayList = new ArrayList();
        Iterator it = listB.iterator();
        while (it.hasNext()) {
            arrayList.add(a0((Path) it.next(), "listOrNull"));
        }
        CollectionsKt.sort(arrayList);
        return arrayList;
    }

    @Override // okio.FileSystem
    public FileMetadata I(Path path) {
        Intrinsics.checkNotNullParameter(path, "path");
        FileMetadata fileMetadataI = this.e.I(X(path, "metadataOrNull", "path"));
        if (fileMetadataI == null) {
            return null;
        }
        return fileMetadataI.d() == null ? fileMetadataI : FileMetadata.b(fileMetadataI, false, false, a0(fileMetadataI.d(), "metadataOrNull"), null, null, null, null, null, 251, null);
    }

    @Override // okio.FileSystem
    public FileHandle J(Path path) {
        Intrinsics.checkNotNullParameter(path, "file");
        return this.e.J(X(path, "openReadOnly", "file"));
    }

    @Override // okio.FileSystem
    public FileHandle P(Path path, boolean z, boolean z2) {
        Intrinsics.checkNotNullParameter(path, "file");
        return this.e.P(X(path, "openReadWrite", "file"), z, z2);
    }

    @Override // okio.FileSystem
    public Sink V(Path path, boolean z) {
        Intrinsics.checkNotNullParameter(path, "file");
        return this.e.V(X(path, "sink", "file"), z);
    }

    @Override // okio.FileSystem
    public Source W(Path path) {
        Intrinsics.checkNotNullParameter(path, "file");
        return this.e.W(X(path, ClimateForcast.SOURCE, "file"));
    }

    public Path X(Path path, String str, String str2) {
        Intrinsics.checkNotNullParameter(path, "path");
        Intrinsics.checkNotNullParameter(str, "functionName");
        Intrinsics.checkNotNullParameter(str2, "parameterName");
        return path;
    }

    public Path a0(Path path, String str) {
        Intrinsics.checkNotNullParameter(path, "path");
        Intrinsics.checkNotNullParameter(str, "functionName");
        return path;
    }

    @Override // okio.FileSystem, java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.e.close();
    }

    @Override // okio.FileSystem
    public Sink d(Path path, boolean z) {
        Intrinsics.checkNotNullParameter(path, "file");
        return this.e.d(X(path, "appendingSink", "file"), z);
    }

    @Override // okio.FileSystem
    public void e(Path path, Path path2) {
        Intrinsics.checkNotNullParameter(path, ClimateForcast.SOURCE);
        Intrinsics.checkNotNullParameter(path2, "target");
        this.e.e(X(path, "atomicMove", ClimateForcast.SOURCE), X(path2, "atomicMove", "target"));
    }

    @Override // okio.FileSystem
    public void k(Path path, boolean z) {
        Intrinsics.checkNotNullParameter(path, "dir");
        this.e.k(X(path, "createDirectory", "dir"), z);
    }

    @Override // okio.FileSystem
    public void r(Path path, boolean z) {
        Intrinsics.checkNotNullParameter(path, "path");
        this.e.r(X(path, "delete", "path"), z);
    }

    public String toString() {
        return Reflection.getOrCreateKotlinClass(getClass()).getSimpleName() + '(' + this.e + ')';
    }
}