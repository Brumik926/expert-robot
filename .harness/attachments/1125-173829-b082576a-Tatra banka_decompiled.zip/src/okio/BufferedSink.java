package okio;

import java.io.OutputStream;
import java.nio.channels.WritableByteChannel;
import kotlin.Metadata;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0016\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\bv\u0018\u00002\u00020\u00012\u00020\u0002J\u0017\u0010\u0005\u001a\u00020\u00002\u0006\u0010\u0004\u001a\u00020\u0003H&¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\t\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u0007H&¢\u0006\u0004\b\t\u0010\nJ'\u0010\t\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000bH&¢\u0006\u0004\b\t\u0010\u000eJ\u0017\u0010\u0011\u001a\u00020\u00102\u0006\u0010\b\u001a\u00020\u000fH&¢\u0006\u0004\b\u0011\u0010\u0012J\u0017\u0010\u0015\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\u0013H&¢\u0006\u0004\b\u0015\u0010\u0016J'\u0010\u0019\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u000b2\u0006\u0010\u0018\u001a\u00020\u000bH&¢\u0006\u0004\b\u0019\u0010\u001aJ\u0017\u0010\u001c\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\u000bH&¢\u0006\u0004\b\u001c\u0010\u001dJ\u0017\u0010\u001f\u001a\u00020\u00002\u0006\u0010\u001e\u001a\u00020\u000bH&¢\u0006\u0004\b\u001f\u0010\u001dJ\u0017\u0010!\u001a\u00020\u00002\u0006\u0010 \u001a\u00020\u000bH&¢\u0006\u0004\b!\u0010\u001dJ\u0017\u0010#\u001a\u00020\u00002\u0006\u0010\"\u001a\u00020\u000bH&¢\u0006\u0004\b#\u0010\u001dJ\u0017\u0010$\u001a\u00020\u00002\u0006\u0010\"\u001a\u00020\u000bH&¢\u0006\u0004\b$\u0010\u001dJ\u0017\u0010&\u001a\u00020\u00002\u0006\u0010%\u001a\u00020\u0010H&¢\u0006\u0004\b&\u0010'J\u0017\u0010(\u001a\u00020\u00002\u0006\u0010%\u001a\u00020\u0010H&¢\u0006\u0004\b(\u0010'J\u0017\u0010)\u001a\u00020\u00002\u0006\u0010%\u001a\u00020\u0010H&¢\u0006\u0004\b)\u0010'J\u000f\u0010+\u001a\u00020*H&¢\u0006\u0004\b+\u0010,J\u000f\u0010-\u001a\u00020\u0000H&¢\u0006\u0004\b-\u0010.J\u000f\u0010/\u001a\u00020\u0000H&¢\u0006\u0004\b/\u0010.J\u000f\u00101\u001a\u000200H&¢\u0006\u0004\b1\u00102R\u0014\u00106\u001a\u0002038&X¦\u0004¢\u0006\u0006\u001a\u0004\b4\u00105\u0082\u0001\u000237ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u00068À\u0006\u0001"}, d2 = {"Lokio/BufferedSink;", "Lokio/Sink;", "Ljava/nio/channels/WritableByteChannel;", "Lokio/ByteString;", "byteString", "l1", "(Lokio/ByteString;)Lokio/BufferedSink;", StringUtils.EMPTY, ClimateForcast.SOURCE, "write", "([B)Lokio/BufferedSink;", StringUtils.EMPTY, MimeTypesReaderMetKeys.MATCH_OFFSET_ATTR, "byteCount", "([BII)Lokio/BufferedSink;", "Lokio/Source;", StringUtils.EMPTY, "d2", "(Lokio/Source;)J", StringUtils.EMPTY, "string", "V1", "(Ljava/lang/String;)Lokio/BufferedSink;", "beginIndex", "endIndex", "f0", "(Ljava/lang/String;II)Lokio/BufferedSink;", "codePoint", "C1", "(I)Lokio/BufferedSink;", "b", "writeByte", "s", "writeShort", "i", "writeInt", "L0", "v", "H", "(J)Lokio/BufferedSink;", "A0", "b1", StringUtils.EMPTY, "flush", "()V", "A1", "()Lokio/BufferedSink;", "P1", "Ljava/io/OutputStream;", "s3", "()Ljava/io/OutputStream;", "Lokio/Buffer;", "getBuffer", "()Lokio/Buffer;", "buffer", "Lokio/RealBufferedSink;", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
public interface BufferedSink extends Sink, WritableByteChannel {
    BufferedSink A0(long j);

    BufferedSink A1();

    BufferedSink C1(int i);

    BufferedSink H(long j);

    BufferedSink L0(int i);

    BufferedSink P1();

    BufferedSink V1(String str);

    BufferedSink b1(long j);

    long d2(Source source);

    BufferedSink f0(String str, int i, int i2);

    @Override // okio.Sink, java.io.Flushable
    void flush();

    Buffer getBuffer();

    BufferedSink l1(ByteString byteString);

    OutputStream s3();

    BufferedSink write(byte[] bArr);

    BufferedSink write(byte[] bArr, int i, int i2);

    BufferedSink writeByte(int i);

    BufferedSink writeInt(int i);

    BufferedSink writeShort(int i);
}