package me.tatarka.bindingcollectionadapter2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ObservableList;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import java.lang.ref.WeakReference;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class BindingListViewAdapter<T> extends BaseAdapter implements BindingCollectionAdapter<T> {
    private final int a;
    private ItemBinding b;
    private int c;
    private List d;
    private int[] e;
    private LayoutInflater f;
    private ItemIds g;
    private ItemIsEnabled h;
    private LifecycleOwner i;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ItemIds<T> {
        long a(int i, Object obj);
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ItemIsEnabled<T> {
        boolean a(int i, Object obj);
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static class WeakReferenceOnListChangedCallback<T> extends ObservableList.OnListChangedCallback<ObservableList<T>> {
        final WeakReference a;

        public void d(ObservableList observableList) {
            BindingListViewAdapter bindingListViewAdapter = (BindingListViewAdapter) this.a.get();
            if (bindingListViewAdapter == null) {
                return;
            }
            Utils.a();
            bindingListViewAdapter.notifyDataSetChanged();
        }

        public void e(ObservableList observableList, int i, int i2) {
            d(observableList);
        }

        public void f(ObservableList observableList, int i, int i2) {
            d(observableList);
        }

        public void g(ObservableList observableList, int i, int i2, int i3) {
            d(observableList);
        }

        public void h(ObservableList observableList, int i, int i2) {
            d(observableList);
        }
    }

    private int a() {
        int i = this.a;
        if (this.e == null) {
            this.e = new int[i];
        }
        return i;
    }

    private void d(View view) {
        LifecycleOwner lifecycleOwner = this.i;
        if (lifecycleOwner == null || lifecycleOwner.getLifecycle().d() == Lifecycle.State.a) {
            this.i = Utils.b(view);
        }
    }

    public void b(ViewDataBinding viewDataBinding, int i, int i2, int i3, Object obj) {
        if (this.b.a(viewDataBinding, obj)) {
            viewDataBinding.s();
            LifecycleOwner lifecycleOwner = this.i;
            if (lifecycleOwner != null) {
                viewDataBinding.U(lifecycleOwner);
            }
        }
    }

    public ViewDataBinding c(LayoutInflater layoutInflater, int i, ViewGroup viewGroup) {
        return DataBindingUtil.j(layoutInflater, i, viewGroup, false);
    }

    @Override // android.widget.Adapter
    public int getCount() {
        List list = this.d;
        if (list == null) {
            return 0;
        }
        return list.size();
    }

    @Override // android.widget.BaseAdapter, android.widget.SpinnerAdapter
    public final View getDropDownView(int i, View view, ViewGroup viewGroup) {
        if (this.f == null) {
            this.f = LayoutInflater.from(viewGroup.getContext());
        }
        d(viewGroup);
        int i2 = this.c;
        if (i2 == 0) {
            return super.getDropDownView(i, view, viewGroup);
        }
        ViewDataBinding viewDataBindingC = view == null ? c(this.f, i2, viewGroup) : DataBindingUtil.h(view);
        View root = viewDataBindingC.getRoot();
        b(viewDataBindingC, this.b.g(), i2, i, this.d.get(i));
        return root;
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return this.d.get(i);
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        ItemIds itemIds = this.g;
        return itemIds == null ? i : itemIds.a(i, this.d.get(i));
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getItemViewType(int i) {
        a();
        this.b.e(i, this.d.get(i));
        int i2 = 0;
        int i3 = 0;
        while (true) {
            int[] iArr = this.e;
            if (i2 >= iArr.length) {
                iArr[i3] = this.b.b();
                return i3;
            }
            int iB = this.b.b();
            int i4 = this.e[i2];
            if (iB == i4) {
                return i2;
            }
            if (i4 == 0) {
                i3 = i2;
            }
            i2++;
        }
    }

    @Override // android.widget.Adapter
    public final View getView(int i, View view, ViewGroup viewGroup) {
        ViewDataBinding viewDataBindingH;
        if (this.f == null) {
            this.f = LayoutInflater.from(viewGroup.getContext());
        }
        d(viewGroup);
        int i2 = this.e[getItemViewType(i)];
        if (view == null) {
            viewDataBindingH = c(this.f, i2, viewGroup);
            viewDataBindingH.getRoot();
        } else {
            viewDataBindingH = DataBindingUtil.h(view);
        }
        ViewDataBinding viewDataBinding = viewDataBindingH;
        View root = viewDataBinding.getRoot();
        b(viewDataBinding, this.b.g(), i2, i, this.d.get(i));
        return root;
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public int getViewTypeCount() {
        return a();
    }

    @Override // android.widget.BaseAdapter, android.widget.Adapter
    public boolean hasStableIds() {
        return this.g != null;
    }

    @Override // android.widget.BaseAdapter, android.widget.ListAdapter
    public boolean isEnabled(int i) {
        ItemIsEnabled itemIsEnabled = this.h;
        return itemIsEnabled == null || itemIsEnabled.a(i, this.d.get(i));
    }
}