package me.tatarka.bindingcollectionadapter2.collections;

import androidx.databinding.ListChangeRegistry;
import androidx.databinding.ObservableList;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class MergeObservableList<T> extends AbstractList<T> implements ObservableList<T> {
    private final ArrayList a = new ArrayList();
    private final ListChangeCallback b = new ListChangeCallback();
    private final ListChangeRegistry c = new ListChangeRegistry();

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    class ListChangeCallback extends ObservableList.OnListChangedCallback {
        ListChangeCallback() {
        }

        public void d(ObservableList observableList) {
            ((AbstractList) MergeObservableList.this).modCount++;
            MergeObservableList.this.c.o(MergeObservableList.this);
        }

        public void e(ObservableList observableList, int i, int i2) {
            int size = MergeObservableList.this.a.size();
            int size2 = 0;
            for (int i3 = 0; i3 < size; i3++) {
                List list = (List) MergeObservableList.this.a.get(i3);
                if (list == observableList) {
                    MergeObservableList.this.c.p(MergeObservableList.this, size2 + i, i2);
                    return;
                }
                size2 += list.size();
            }
        }

        public void f(ObservableList observableList, int i, int i2) {
            ((AbstractList) MergeObservableList.this).modCount++;
            int size = MergeObservableList.this.a.size();
            int size2 = 0;
            for (int i3 = 0; i3 < size; i3++) {
                List list = (List) MergeObservableList.this.a.get(i3);
                if (list == observableList) {
                    MergeObservableList.this.c.q(MergeObservableList.this, size2 + i, i2);
                    return;
                }
                size2 += list.size();
            }
        }

        public void g(ObservableList observableList, int i, int i2, int i3) {
            int size = MergeObservableList.this.a.size();
            int size2 = 0;
            for (int i4 = 0; i4 < size; i4++) {
                List list = (List) MergeObservableList.this.a.get(i4);
                if (list == observableList) {
                    MergeObservableList.this.c.r(MergeObservableList.this, i + size2, size2 + i2, i3);
                    return;
                }
                size2 += list.size();
            }
        }

        public void h(ObservableList observableList, int i, int i2) {
            ((AbstractList) MergeObservableList.this).modCount++;
            int size = MergeObservableList.this.a.size();
            int size2 = 0;
            for (int i3 = 0; i3 < size; i3++) {
                List list = (List) MergeObservableList.this.a.get(i3);
                if (list == observableList) {
                    MergeObservableList.this.c.s(MergeObservableList.this, size2 + i, i2);
                    return;
                }
                size2 += list.size();
            }
        }
    }

    public void g1(ObservableList.OnListChangedCallback onListChangedCallback) {
        this.c.a(onListChangedCallback);
    }

    @Override // java.util.AbstractList, java.util.List
    public Object get(int i) {
        if (i < 0) {
            throw new IndexOutOfBoundsException();
        }
        int size = this.a.size();
        int size2 = 0;
        for (int i2 = 0; i2 < size; i2++) {
            List list = (List) this.a.get(i2);
            int i3 = i - size2;
            if (i3 < list.size()) {
                return list.get(i3);
            }
            size2 += list.size();
        }
        throw new IndexOutOfBoundsException();
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public int size() {
        int size = this.a.size();
        int size2 = 0;
        for (int i = 0; i < size; i++) {
            size2 += ((List) this.a.get(i)).size();
        }
        return size2;
    }

    public void w1(ObservableList.OnListChangedCallback onListChangedCallback) {
        this.c.j(onListChangedCallback);
    }
}