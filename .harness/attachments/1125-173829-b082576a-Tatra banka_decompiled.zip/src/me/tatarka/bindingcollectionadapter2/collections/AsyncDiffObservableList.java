package me.tatarka.bindingcollectionadapter2.collections;

import androidx.databinding.ListChangeRegistry;
import androidx.databinding.ObservableList;
import androidx.recyclerview.widget.AsyncDifferConfig;
import androidx.recyclerview.widget.AsyncListDiffer;
import androidx.recyclerview.widget.ListUpdateCallback;
import java.util.AbstractList;
import java.util.List;
import java.util.ListIterator;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class AsyncDiffObservableList<T> extends AbstractList<T> implements ObservableList<T> {
    private final AsyncListDiffer a;
    private final ListChangeRegistry b = new ListChangeRegistry();

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    class ObservableListUpdateCallback implements ListUpdateCallback {
        ObservableListUpdateCallback() {
        }

        public void a(int i, int i2, Object obj) {
            AsyncDiffObservableList.this.b.p(AsyncDiffObservableList.this, i, i2);
        }

        public void b(int i, int i2) {
            AsyncDiffObservableList.this.b.q(AsyncDiffObservableList.this, i, i2);
        }

        public void c(int i, int i2) {
            AsyncDiffObservableList.this.b.s(AsyncDiffObservableList.this, i, i2);
        }

        public void d(int i, int i2) {
            AsyncDiffObservableList.this.b.r(AsyncDiffObservableList.this, i, i2, 1);
        }
    }

    public AsyncDiffObservableList(AsyncDifferConfig asyncDifferConfig) {
        this.a = new AsyncListDiffer(new ObservableListUpdateCallback(), asyncDifferConfig);
    }

    public void b(List list) {
        this.a.d(list);
    }

    @Override // java.util.AbstractList, java.util.Collection, java.util.List
    public boolean equals(Object obj) {
        if (obj instanceof AsyncDiffObservableList) {
            return this.a.a().equals(((AsyncDiffObservableList) obj).a.a());
        }
        return false;
    }

    public void g1(ObservableList.OnListChangedCallback onListChangedCallback) {
        this.b.a(onListChangedCallback);
    }

    @Override // java.util.AbstractList, java.util.List
    public Object get(int i) {
        return this.a.a().get(i);
    }

    @Override // java.util.AbstractList, java.util.Collection, java.util.List
    public int hashCode() {
        return this.a.a().hashCode();
    }

    @Override // java.util.AbstractList, java.util.List
    public int indexOf(Object obj) {
        return this.a.a().indexOf(obj);
    }

    @Override // java.util.AbstractList, java.util.List
    public int lastIndexOf(Object obj) {
        return this.a.a().lastIndexOf(obj);
    }

    @Override // java.util.AbstractList, java.util.List
    public ListIterator listIterator(int i) {
        return this.a.a().listIterator(i);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public int size() {
        return this.a.a().size();
    }

    @Override // java.util.AbstractList, java.util.List
    public List subList(int i, int i2) {
        return this.a.a().subList(i, i2);
    }

    public void w1(ObservableList.OnListChangedCallback onListChangedCallback) {
        this.b.j(onListChangedCallback);
    }
}