package me.tatarka.bindingcollectionadapter2.collections;

import androidx.databinding.ListChangeRegistry;
import androidx.databinding.ObservableList;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListUpdateCallback;
import java.util.AbstractList;
import java.util.Collections;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class DiffObservableList<T> extends AbstractList<T> implements ObservableList<T> {
    private final Object a;
    private List b;
    private final DiffUtil.ItemCallback c;
    private final boolean d;
    private final ListChangeRegistry e;
    private final ObservableListUpdateCallback f;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Deprecated
    public interface Callback<T> {
        boolean a(Object obj, Object obj2);

        boolean b(Object obj, Object obj2);
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static class ItemCallbackAdapter<T> extends DiffUtil.ItemCallback<T> {
        final Callback a;

        ItemCallbackAdapter(Callback callback) {
            this.a = callback;
        }

        public boolean b(Object obj, Object obj2) {
            return this.a.b(obj, obj2);
        }

        public boolean c(Object obj, Object obj2) {
            return this.a.a(obj, obj2);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    class ObservableListUpdateCallback implements ListUpdateCallback {
        ObservableListUpdateCallback() {
        }

        public void a(int i, int i2, Object obj) {
            DiffObservableList.this.e.p(DiffObservableList.this, i, i2);
        }

        public void b(int i, int i2) {
            ((AbstractList) DiffObservableList.this).modCount++;
            DiffObservableList.this.e.q(DiffObservableList.this, i, i2);
        }

        public void c(int i, int i2) {
            ((AbstractList) DiffObservableList.this).modCount++;
            DiffObservableList.this.e.s(DiffObservableList.this, i, i2);
        }

        public void d(int i, int i2) {
            DiffObservableList.this.e.r(DiffObservableList.this, i, i2, 1);
        }
    }

    public DiffObservableList(Callback callback) {
        this(new ItemCallbackAdapter(callback), true);
    }

    private DiffUtil.DiffResult g(final List list, final List list2) {
        return DiffUtil.c(new DiffUtil.Callback() { // from class: me.tatarka.bindingcollectionadapter2.collections.DiffObservableList.1
            public boolean a(int i, int i2) {
                Object obj = list.get(i);
                Object obj2 = list2.get(i2);
                if (obj == null || obj2 == null) {
                    return true;
                }
                return DiffObservableList.this.c.b(obj, obj2);
            }

            public boolean b(int i, int i2) {
                Object obj = list.get(i);
                Object obj2 = list2.get(i2);
                return (obj == null || obj2 == null) ? obj == null && obj2 == null : DiffObservableList.this.c.c(obj, obj2);
            }

            public Object c(int i, int i2) {
                return DiffObservableList.this.c.d(list.get(i), list2.get(i2));
            }

            public int d() {
                List list3 = list2;
                if (list3 != null) {
                    return list3.size();
                }
                return 0;
            }

            public int e() {
                return list.size();
            }
        }, this.d);
    }

    public void g1(ObservableList.OnListChangedCallback onListChangedCallback) {
        this.e.a(onListChangedCallback);
    }

    @Override // java.util.AbstractList, java.util.List
    public Object get(int i) {
        return this.b.get(i);
    }

    public void h(List list) {
        DiffUtil.DiffResult diffResultG = g(this.b, list);
        this.b = list;
        diffResultG.c(this.f);
    }

    @Override // java.util.AbstractCollection, java.util.Collection, java.util.List
    public int size() {
        return this.b.size();
    }

    public void w1(ObservableList.OnListChangedCallback onListChangedCallback) {
        this.e.j(onListChangedCallback);
    }

    public DiffObservableList(DiffUtil.ItemCallback itemCallback) {
        this(itemCallback, true);
    }

    public DiffObservableList(DiffUtil.ItemCallback itemCallback, boolean z) {
        this.a = new Object();
        this.b = Collections.EMPTY_LIST;
        this.e = new ListChangeRegistry();
        this.f = new ObservableListUpdateCallback();
        this.c = itemCallback;
        this.d = z;
    }
}