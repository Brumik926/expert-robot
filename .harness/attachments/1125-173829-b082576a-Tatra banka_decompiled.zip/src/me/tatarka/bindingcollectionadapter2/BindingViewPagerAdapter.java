package me.tatarka.bindingcollectionadapter2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ObservableList;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.viewpager.widget.PagerAdapter;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class BindingViewPagerAdapter<T> extends PagerAdapter implements BindingCollectionAdapter<T> {
    private ItemBinding a;
    private WeakReferenceOnListChangedCallback b;
    private List c;
    private LayoutInflater d;
    private PageTitles e;
    private LifecycleOwner f;
    private List g = new ArrayList();

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface PageTitles<T> {
        CharSequence a(int i, Object obj);
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    private static class WeakReferenceOnListChangedCallback<T> extends ObservableList.OnListChangedCallback<ObservableList<T>> {
        final WeakReference a;

        WeakReferenceOnListChangedCallback(BindingViewPagerAdapter bindingViewPagerAdapter, ObservableList observableList) {
            this.a = AdapterReferenceCollector.a(bindingViewPagerAdapter, observableList, this);
        }

        public void d(ObservableList observableList) {
            BindingViewPagerAdapter bindingViewPagerAdapter = (BindingViewPagerAdapter) this.a.get();
            if (bindingViewPagerAdapter == null) {
                return;
            }
            Utils.a();
            bindingViewPagerAdapter.notifyDataSetChanged();
        }

        public void e(ObservableList observableList, int i, int i2) {
            d(observableList);
        }

        public void f(ObservableList observableList, int i, int i2) {
            d(observableList);
        }

        public void g(ObservableList observableList, int i, int i2, int i3) {
            d(observableList);
        }

        public void h(ObservableList observableList, int i, int i2) {
            d(observableList);
        }
    }

    private void n(View view) {
        LifecycleOwner lifecycleOwner = this.f;
        if (lifecycleOwner == null || lifecycleOwner.getLifecycle().d() == Lifecycle.State.a) {
            this.f = Utils.b(view);
        }
    }

    public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
        View view = (View) obj;
        this.g.remove(view);
        viewGroup.removeView(view);
    }

    public int getCount() {
        List list = this.c;
        if (list == null) {
            return 0;
        }
        return list.size();
    }

    public int getItemPosition(Object obj) {
        Object tag = ((View) obj).getTag();
        if (this.c == null) {
            return -2;
        }
        for (int i = 0; i < this.c.size(); i++) {
            if (tag == this.c.get(i)) {
                return i;
            }
        }
        return -2;
    }

    public CharSequence getPageTitle(int i) {
        PageTitles pageTitles = this.e;
        if (pageTitles == null) {
            return null;
        }
        return pageTitles.a(i, this.c.get(i));
    }

    public void i(ViewDataBinding viewDataBinding, int i, int i2, int i3, Object obj) {
        if (this.a.a(viewDataBinding, obj)) {
            viewDataBinding.s();
            LifecycleOwner lifecycleOwner = this.f;
            if (lifecycleOwner != null) {
                viewDataBinding.U(lifecycleOwner);
            }
        }
    }

    public Object instantiateItem(ViewGroup viewGroup, int i) {
        if (this.d == null) {
            this.d = LayoutInflater.from(viewGroup.getContext());
        }
        n(viewGroup);
        Object obj = this.c.get(i);
        this.a.e(i, obj);
        ViewDataBinding viewDataBindingJ = j(this.d, this.a.b(), viewGroup);
        View root = viewDataBindingJ.getRoot();
        i(viewDataBindingJ, this.a.g(), this.a.b(), i, obj);
        viewGroup.addView(root);
        root.setTag(obj);
        this.g.add(root);
        return root;
    }

    public boolean isViewFromObject(View view, Object obj) {
        return view == obj;
    }

    public ViewDataBinding j(LayoutInflater layoutInflater, int i, ViewGroup viewGroup) {
        return DataBindingUtil.j(layoutInflater, i, viewGroup, false);
    }

    public void k(ItemBinding itemBinding) {
        this.a = itemBinding;
    }

    public void l(List list) {
        ObservableList observableList = this.c;
        if (observableList == list) {
            return;
        }
        if (observableList instanceof ObservableList) {
            observableList.w1(this.b);
            this.b = null;
        }
        if (list instanceof ObservableList) {
            ObservableList observableList2 = (ObservableList) list;
            WeakReferenceOnListChangedCallback weakReferenceOnListChangedCallback = new WeakReferenceOnListChangedCallback(this, observableList2);
            this.b = weakReferenceOnListChangedCallback;
            observableList2.g1(weakReferenceOnListChangedCallback);
        }
        this.c = list;
        notifyDataSetChanged();
    }

    public void m(PageTitles pageTitles) {
        this.e = pageTitles;
    }
}