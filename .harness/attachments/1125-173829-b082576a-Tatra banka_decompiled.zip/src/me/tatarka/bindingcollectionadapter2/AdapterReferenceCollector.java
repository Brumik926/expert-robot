package me.tatarka.bindingcollectionadapter2;

import androidx.databinding.ObservableList;
import java.lang.ref.Reference;
import java.lang.ref.ReferenceQueue;
import java.lang.ref.WeakReference;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
class AdapterReferenceCollector {
    static final ReferenceQueue a = new ReferenceQueue();
    static PollReferenceThread b;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    static class AdapterRef<T, A extends BindingCollectionAdapter<T>> extends WeakReference<A> {
        private final ObservableList a;
        private final ObservableList.OnListChangedCallback b;

        AdapterRef(BindingCollectionAdapter bindingCollectionAdapter, ObservableList observableList, ObservableList.OnListChangedCallback onListChangedCallback) {
            super(bindingCollectionAdapter, AdapterReferenceCollector.a);
            this.a = observableList;
            this.b = onListChangedCallback;
        }

        void a() {
            this.a.w1(this.b);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    private static class PollReferenceThread extends Thread {
        private PollReferenceThread() {
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            while (true) {
                try {
                    Reference referenceRemove = AdapterReferenceCollector.a.remove();
                    if (referenceRemove instanceof AdapterRef) {
                        ((AdapterRef) referenceRemove).a();
                    }
                } catch (InterruptedException unused) {
                    return;
                }
            }
        }
    }

    AdapterReferenceCollector() {
    }

    static WeakReference a(BindingCollectionAdapter bindingCollectionAdapter, ObservableList observableList, ObservableList.OnListChangedCallback onListChangedCallback) {
        PollReferenceThread pollReferenceThread = b;
        if (pollReferenceThread == null || !pollReferenceThread.isAlive()) {
            PollReferenceThread pollReferenceThread2 = new PollReferenceThread();
            b = pollReferenceThread2;
            pollReferenceThread2.start();
        }
        return new AdapterRef(bindingCollectionAdapter, observableList, onListChangedCallback);
    }
}