package me.tatarka.bindingcollectionadapter2;

import androidx.recyclerview.widget.AsyncDifferConfig;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import me.tatarka.bindingcollectionadapter2.BindingRecyclerViewAdapter;
import me.tatarka.bindingcollectionadapter2.collections.AsyncDiffObservableList;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class BindingRecyclerViewAdapters {
    public static void a(RecyclerView recyclerView, ItemBinding itemBinding, List list, BindingRecyclerViewAdapter bindingRecyclerViewAdapter, BindingRecyclerViewAdapter.ItemIds itemIds, BindingRecyclerViewAdapter.ViewHolderFactory viewHolderFactory, AsyncDifferConfig asyncDifferConfig) {
        if (itemBinding == null) {
            recyclerView.setAdapter((RecyclerView.Adapter) null);
            return;
        }
        BindingRecyclerViewAdapter bindingRecyclerViewAdapter2 = (BindingRecyclerViewAdapter) recyclerView.getAdapter();
        if (bindingRecyclerViewAdapter == null) {
            bindingRecyclerViewAdapter = bindingRecyclerViewAdapter2 == null ? new BindingRecyclerViewAdapter() : bindingRecyclerViewAdapter2;
        }
        bindingRecyclerViewAdapter.v(itemBinding);
        if (asyncDifferConfig == null || list == null) {
            bindingRecyclerViewAdapter.x(list);
        } else {
            int i = me.tatarka.bindingcollectionadapter2.recyclerview.R.id.bindingcollectiondapter_list_id;
            AsyncDiffObservableList asyncDiffObservableList = (AsyncDiffObservableList) recyclerView.getTag(i);
            if (asyncDiffObservableList == null) {
                asyncDiffObservableList = new AsyncDiffObservableList(asyncDifferConfig);
                recyclerView.setTag(i, asyncDiffObservableList);
                bindingRecyclerViewAdapter.x(asyncDiffObservableList);
            }
            asyncDiffObservableList.b(list);
        }
        bindingRecyclerViewAdapter.w(itemIds);
        bindingRecyclerViewAdapter.y(viewHolderFactory);
        if (bindingRecyclerViewAdapter2 != bindingRecyclerViewAdapter) {
            recyclerView.setAdapter(bindingRecyclerViewAdapter);
        }
    }
}