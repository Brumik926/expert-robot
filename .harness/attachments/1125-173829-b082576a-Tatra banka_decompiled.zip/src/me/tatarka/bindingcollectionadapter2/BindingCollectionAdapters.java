package me.tatarka.bindingcollectionadapter2;

import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import java.util.List;
import me.tatarka.bindingcollectionadapter2.BindingViewPagerAdapter;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class BindingCollectionAdapters {
    public static void a(ViewPager viewPager, ItemBinding itemBinding, List list, BindingViewPagerAdapter bindingViewPagerAdapter, BindingViewPagerAdapter.PageTitles pageTitles) {
        if (itemBinding == null) {
            viewPager.setAdapter((PagerAdapter) null);
            return;
        }
        BindingViewPagerAdapter bindingViewPagerAdapter2 = (BindingViewPagerAdapter) viewPager.getAdapter();
        if (bindingViewPagerAdapter == null) {
            bindingViewPagerAdapter = bindingViewPagerAdapter2 == null ? new BindingViewPagerAdapter() : bindingViewPagerAdapter2;
        }
        bindingViewPagerAdapter.k(itemBinding);
        bindingViewPagerAdapter.l(list);
        bindingViewPagerAdapter.m(pageTitles);
        if (bindingViewPagerAdapter2 != bindingViewPagerAdapter) {
            viewPager.setAdapter(bindingViewPagerAdapter);
        }
    }

    public static ItemBinding b(OnItemBind onItemBind) {
        return ItemBinding.d(onItemBind);
    }
}