package me.tatarka.bindingcollectionadapter2;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ObservableList;
import androidx.databinding.OnRebindCallback;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.recyclerview.widget.RecyclerView;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class BindingRecyclerViewAdapter<T> extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements BindingCollectionAdapter<T> {
    private static final Object i = new Object();
    private ItemBinding a;
    private WeakReferenceOnListChangedCallback b;
    private List c;
    private LayoutInflater d;
    private ItemIds e;
    private ViewHolderFactory f;
    private RecyclerView g;
    private LifecycleOwner h;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    private static class BindingViewHolder extends RecyclerView.ViewHolder {
        BindingViewHolder(ViewDataBinding viewDataBinding) {
            super(viewDataBinding.getRoot());
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ItemIds<T> {
        long a(int i, Object obj);
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    public interface ViewHolderFactory {
        RecyclerView.ViewHolder a(ViewDataBinding viewDataBinding);
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    private static class WeakReferenceOnListChangedCallback<T> extends ObservableList.OnListChangedCallback<ObservableList<T>> {
        final WeakReference a;

        WeakReferenceOnListChangedCallback(BindingRecyclerViewAdapter bindingRecyclerViewAdapter, ObservableList observableList) {
            this.a = AdapterReferenceCollector.a(bindingRecyclerViewAdapter, observableList, this);
        }

        public void d(ObservableList observableList) {
            BindingRecyclerViewAdapter bindingRecyclerViewAdapter = (BindingRecyclerViewAdapter) this.a.get();
            if (bindingRecyclerViewAdapter == null) {
                return;
            }
            Utils.a();
            bindingRecyclerViewAdapter.notifyDataSetChanged();
        }

        public void e(ObservableList observableList, int i, int i2) {
            BindingRecyclerViewAdapter bindingRecyclerViewAdapter = (BindingRecyclerViewAdapter) this.a.get();
            if (bindingRecyclerViewAdapter == null) {
                return;
            }
            Utils.a();
            bindingRecyclerViewAdapter.notifyItemRangeChanged(i, i2);
        }

        public void f(ObservableList observableList, int i, int i2) {
            BindingRecyclerViewAdapter bindingRecyclerViewAdapter = (BindingRecyclerViewAdapter) this.a.get();
            if (bindingRecyclerViewAdapter == null) {
                return;
            }
            Utils.a();
            bindingRecyclerViewAdapter.notifyItemRangeInserted(i, i2);
        }

        public void g(ObservableList observableList, int i, int i2, int i3) {
            BindingRecyclerViewAdapter bindingRecyclerViewAdapter = (BindingRecyclerViewAdapter) this.a.get();
            if (bindingRecyclerViewAdapter == null) {
                return;
            }
            Utils.a();
            for (int i4 = 0; i4 < i3; i4++) {
                bindingRecyclerViewAdapter.notifyItemMoved(i + i4, i2 + i4);
            }
        }

        public void h(ObservableList observableList, int i, int i2) {
            BindingRecyclerViewAdapter bindingRecyclerViewAdapter = (BindingRecyclerViewAdapter) this.a.get();
            if (bindingRecyclerViewAdapter == null) {
                return;
            }
            Utils.a();
            bindingRecyclerViewAdapter.notifyItemRangeRemoved(i, i2);
        }
    }

    private boolean r(List list) {
        if (list == null || list.size() == 0) {
            return false;
        }
        for (int i2 = 0; i2 < list.size(); i2++) {
            if (list.get(i2) != i) {
                return false;
            }
        }
        return true;
    }

    private void z() {
        LifecycleOwner lifecycleOwner = this.h;
        if (lifecycleOwner == null || lifecycleOwner.getLifecycle().d() == Lifecycle.State.a) {
            this.h = Utils.b(this.g);
        }
    }

    public int getItemCount() {
        List list = this.c;
        if (list == null) {
            return 0;
        }
        return list.size();
    }

    public long getItemId(int i2) {
        ItemIds itemIds = this.e;
        return itemIds == null ? i2 : itemIds.a(i2, this.c.get(i2));
    }

    public int getItemViewType(int i2) {
        this.a.e(i2, this.c.get(i2));
        return this.a.b();
    }

    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
        if (this.g == null) {
            ObservableList observableList = this.c;
            if (observableList instanceof ObservableList) {
                WeakReferenceOnListChangedCallback weakReferenceOnListChangedCallback = new WeakReferenceOnListChangedCallback(this, observableList);
                this.b = weakReferenceOnListChangedCallback;
                this.c.g1(weakReferenceOnListChangedCallback);
            }
        }
        this.g = recyclerView;
    }

    public final void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i2) {
        onBindViewHolder(viewHolder, i2, Collections.EMPTY_LIST);
    }

    public final RecyclerView.ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i2) {
        if (this.d == null) {
            this.d = LayoutInflater.from(viewGroup.getContext());
        }
        ViewDataBinding viewDataBindingT = t(this.d, i2, viewGroup);
        final RecyclerView.ViewHolder viewHolderU = u(viewDataBindingT);
        viewDataBindingT.m(new OnRebindCallback() { // from class: me.tatarka.bindingcollectionadapter2.BindingRecyclerViewAdapter.1
            public void b(ViewDataBinding viewDataBinding) {
                int adapterPosition;
                if (BindingRecyclerViewAdapter.this.g == null || BindingRecyclerViewAdapter.this.g.isComputingLayout() || (adapterPosition = viewHolderU.getAdapterPosition()) == -1) {
                    return;
                }
                try {
                    BindingRecyclerViewAdapter.this.notifyItemChanged(adapterPosition, BindingRecyclerViewAdapter.i);
                } catch (IllegalStateException unused) {
                }
            }

            public boolean c(ViewDataBinding viewDataBinding) {
                return BindingRecyclerViewAdapter.this.g != null && BindingRecyclerViewAdapter.this.g.isComputingLayout();
            }
        });
        return viewHolderU;
    }

    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
        if (this.g != null) {
            ObservableList observableList = this.c;
            if (observableList instanceof ObservableList) {
                observableList.w1(this.b);
                this.b = null;
            }
        }
        this.g = null;
    }

    public void s(ViewDataBinding viewDataBinding, int i2, int i3, int i4, Object obj) {
        z();
        if (this.a.a(viewDataBinding, obj)) {
            viewDataBinding.s();
            LifecycleOwner lifecycleOwner = this.h;
            if (lifecycleOwner != null) {
                viewDataBinding.U(lifecycleOwner);
            }
        }
    }

    public ViewDataBinding t(LayoutInflater layoutInflater, int i2, ViewGroup viewGroup) {
        return DataBindingUtil.j(layoutInflater, i2, viewGroup, false);
    }

    public RecyclerView.ViewHolder u(ViewDataBinding viewDataBinding) {
        ViewHolderFactory viewHolderFactory = this.f;
        return viewHolderFactory != null ? viewHolderFactory.a(viewDataBinding) : new BindingViewHolder(viewDataBinding);
    }

    public void v(ItemBinding itemBinding) {
        this.a = itemBinding;
    }

    public void w(ItemIds itemIds) {
        if (this.e != itemIds) {
            this.e = itemIds;
            setHasStableIds(itemIds != null);
        }
    }

    public void x(List list) {
        ObservableList observableList = this.c;
        if (observableList == list) {
            return;
        }
        if (this.g != null) {
            if (observableList instanceof ObservableList) {
                observableList.w1(this.b);
                this.b = null;
            }
            if (list instanceof ObservableList) {
                ObservableList observableList2 = (ObservableList) list;
                WeakReferenceOnListChangedCallback weakReferenceOnListChangedCallback = new WeakReferenceOnListChangedCallback(this, observableList2);
                this.b = weakReferenceOnListChangedCallback;
                observableList2.g1(weakReferenceOnListChangedCallback);
            }
        }
        this.c = list;
        notifyDataSetChanged();
    }

    public void y(ViewHolderFactory viewHolderFactory) {
        this.f = viewHolderFactory;
    }

    public void onBindViewHolder(RecyclerView.ViewHolder viewHolder, int i2, List list) {
        ViewDataBinding viewDataBindingH = DataBindingUtil.h(viewHolder.itemView);
        if (r(list)) {
            viewDataBindingH.s();
        } else {
            s(viewDataBindingH, this.a.g(), this.a.b(), i2, this.c.get(i2));
        }
    }
}