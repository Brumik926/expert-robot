package me.tatarka.bindingcollectionadapter2;

import android.os.Looper;
import android.view.View;
import androidx.databinding.DataBindingUtil;
import androidx.databinding.ViewDataBinding;
import androidx.lifecycle.LifecycleOwner;
import h.ap;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
class Utils {
    Utils() {
    }

    static void a() {
        if (Thread.currentThread() != Looper.getMainLooper().getThread()) {
            throw new IllegalStateException(ap.a(7788941));
        }
    }

    static LifecycleOwner b(View view) {
        ViewDataBinding viewDataBindingG = DataBindingUtil.g(view);
        LifecycleOwner lifecycleOwnerY = viewDataBindingG != null ? viewDataBindingG.y() : null;
        LifecycleOwner context = view.getContext();
        return (lifecycleOwnerY == null && (context instanceof LifecycleOwner)) ? context : lifecycleOwnerY;
    }

    static void c(ViewDataBinding viewDataBinding, int i, int i2) {
        String resourceName = viewDataBinding.getRoot().getContext().getResources().getResourceName(i2);
        throw new IllegalStateException("Could not bind variable '" + DataBindingUtil.f(i) + "' in layout '" + resourceName + "'");
    }
}