package me.tatarka.bindingcollectionadapter2;

import android.util.SparseArray;
import androidx.databinding.ViewDataBinding;
import h.ap;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class ItemBinding<T> {
    private final OnItemBind a;
    private int b;
    private int c;
    private SparseArray d;

    private ItemBinding(OnItemBind onItemBind) {
        this.a = onItemBind;
    }

    public static ItemBinding c(int i, int i2) {
        return new ItemBinding(null).f(i, i2);
    }

    public static ItemBinding d(OnItemBind onItemBind) {
        if (onItemBind != null) {
            return new ItemBinding(onItemBind);
        }
        throw new NullPointerException(ap.a(1541613853));
    }

    public boolean a(ViewDataBinding viewDataBinding, Object obj) {
        int i = this.b;
        if (i == 0) {
            return false;
        }
        if (!viewDataBinding.Y(i, obj)) {
            Utils.c(viewDataBinding, this.b, this.c);
        }
        SparseArray sparseArray = this.d;
        if (sparseArray == null) {
            return true;
        }
        int size = sparseArray.size();
        for (int i2 = 0; i2 < size; i2++) {
            int iKeyAt = this.d.keyAt(i2);
            Object objValueAt = this.d.valueAt(i2);
            if (iKeyAt != 0) {
                viewDataBinding.Y(iKeyAt, objValueAt);
            }
        }
        return true;
    }

    public final int b() {
        return this.c;
    }

    public void e(int i, Object obj) {
        OnItemBind onItemBind = this.a;
        if (onItemBind != null) {
            this.b = -1;
            this.c = 0;
            onItemBind.a(this, i, obj);
            if (this.b == -1) {
                throw new IllegalStateException("variableId not set in onItemBind()");
            }
            if (this.c == 0) {
                throw new IllegalStateException("layoutRes not set in onItemBind()");
            }
        }
    }

    public final ItemBinding f(int i, int i2) {
        this.b = i;
        this.c = i2;
        return this;
    }

    public final int g() {
        return this.b;
    }
}