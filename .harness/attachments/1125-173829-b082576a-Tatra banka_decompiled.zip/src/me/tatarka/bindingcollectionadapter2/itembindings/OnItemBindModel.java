package me.tatarka.bindingcollectionadapter2.itembindings;

import me.tatarka.bindingcollectionadapter2.ItemBinding;
import me.tatarka.bindingcollectionadapter2.OnItemBind;
import me.tatarka.bindingcollectionadapter2.itembindings.ItemBindingModel;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class OnItemBindModel<T extends ItemBindingModel> implements OnItemBind<T> {
    @Override // me.tatarka.bindingcollectionadapter2.OnItemBind
    /* JADX INFO: renamed from: b, reason: merged with bridge method [inline-methods] */
    public void a(ItemBinding itemBinding, int i, ItemBindingModel itemBindingModel) {
        itemBindingModel.a(itemBinding);
    }
}