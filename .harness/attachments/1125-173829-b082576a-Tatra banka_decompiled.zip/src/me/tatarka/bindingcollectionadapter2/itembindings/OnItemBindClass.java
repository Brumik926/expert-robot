package me.tatarka.bindingcollectionadapter2.itembindings;

import h.ap;
import java.util.ArrayList;
import java.util.List;
import me.tatarka.bindingcollectionadapter2.ItemBinding;
import me.tatarka.bindingcollectionadapter2.OnItemBind;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class OnItemBindClass<T> implements OnItemBind<T> {
    private final List a = new ArrayList(2);
    private final List b = new ArrayList(2);

    /* JADX INFO: renamed from: me.tatarka.bindingcollectionadapter2.itembindings.OnItemBindClass$1, reason: invalid class name */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    class AnonymousClass1 implements OnItemBind<Object> {
        final /* synthetic */ int a;
        final /* synthetic */ int b;

        @Override // me.tatarka.bindingcollectionadapter2.OnItemBind
        public void a(ItemBinding itemBinding, int i, Object obj) {
            itemBinding.f(this.a, this.b);
        }
    }

    @Override // me.tatarka.bindingcollectionadapter2.OnItemBind
    public void a(ItemBinding itemBinding, int i, Object obj) {
        for (int i2 = 0; i2 < this.a.size(); i2++) {
            if (((Class) this.a.get(i2)).isInstance(obj)) {
                ((OnItemBind) this.b.get(i2)).a(itemBinding, i, obj);
                return;
            }
        }
        throw new IllegalArgumentException(ap.a(478830555) + obj);
    }
}