package me.tatarka.bindingcollectionadapter2;

/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class R {

    public static final class attr {
        public static final int alpha = 0x7f040063;
        public static final int coordinatorLayoutStyle = 0x7f040253;
        public static final int font = 0x7f04039b;
        public static final int fontProviderAuthority = 0x7f04039e;
        public static final int fontProviderCerts = 0x7f04039f;
        public static final int fontProviderFetchStrategy = 0x7f0403a1;
        public static final int fontProviderFetchTimeout = 0x7f0403a2;
        public static final int fontProviderPackage = 0x7f0403a3;
        public static final int fontProviderQuery = 0x7f0403a4;
        public static final int fontStyle = 0x7f0403a6;
        public static final int fontVariationSettings = 0x7f0403a7;
        public static final int fontWeight = 0x7f0403a8;
        public static final int keylines = 0x7f040463;
        public static final int layout_anchor = 0x7f04047e;
        public static final int layout_anchorGravity = 0x7f04047f;
        public static final int layout_behavior = 0x7f040481;
        public static final int layout_dodgeInsetEdges = 0x7f0404b2;
        public static final int layout_insetEdge = 0x7f0404c3;
        public static final int layout_keyline = 0x7f0404c4;
        public static final int statusBarBackground = 0x7f040754;
        public static final int ttcIndex = 0x7f040888;

        private attr() {
        }
    }

    public static final class color {
        public static final int notification_action_color_filter = 0x7f0604ca;
        public static final int notification_icon_bg_color = 0x7f0604cb;
        public static final int ripple_material_light = 0x7f0604ff;
        public static final int secondary_text_default_material_light = 0x7f060504;

        private color() {
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 0x7f070098;
        public static final int compat_button_inset_vertical_material = 0x7f070099;
        public static final int compat_button_padding_horizontal_material = 0x7f07009a;
        public static final int compat_button_padding_vertical_material = 0x7f07009b;
        public static final int compat_control_corner_material = 0x7f07009c;
        public static final int compat_notification_large_icon_max_height = 0x7f07009d;
        public static final int compat_notification_large_icon_max_width = 0x7f07009e;
        public static final int notification_action_icon_size = 0x7f0704ee;
        public static final int notification_action_text_size = 0x7f0704ef;
        public static final int notification_big_circle_margin = 0x7f0704f0;
        public static final int notification_content_margin_start = 0x7f0704f1;
        public static final int notification_large_icon_height = 0x7f0704f2;
        public static final int notification_large_icon_width = 0x7f0704f3;
        public static final int notification_main_column_padding_top = 0x7f0704f4;
        public static final int notification_media_narrow_margin = 0x7f0704f5;
        public static final int notification_right_icon_size = 0x7f0704f6;
        public static final int notification_right_side_padding_top = 0x7f0704f7;
        public static final int notification_small_icon_background_padding = 0x7f0704f8;
        public static final int notification_small_icon_size_as_large = 0x7f0704f9;
        public static final int notification_subtext_size = 0x7f0704fa;
        public static final int notification_top_pad = 0x7f0704fb;
        public static final int notification_top_pad_large_text = 0x7f0704fc;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int notification_action_background = 0x7f0805ea;
        public static final int notification_bg = 0x7f0805eb;
        public static final int notification_bg_low = 0x7f0805ec;
        public static final int notification_bg_low_normal = 0x7f0805ed;
        public static final int notification_bg_low_pressed = 0x7f0805ee;
        public static final int notification_bg_normal = 0x7f0805ef;
        public static final int notification_bg_normal_pressed = 0x7f0805f0;
        public static final int notification_icon_background = 0x7f0805f1;
        public static final int notification_template_icon_bg = 0x7f0805f3;
        public static final int notification_template_icon_low_bg = 0x7f0805f4;
        public static final int notification_tile_bg = 0x7f0805f5;
        public static final int notify_panel_notification_icon_bg = 0x7f0805f6;

        private drawable() {
        }
    }

    public static final class id {
        public static final int action_container = 0x7f0a00cf;
        public static final int action_divider = 0x7f0a00d6;
        public static final int action_image = 0x7f0a00e2;
        public static final int action_text = 0x7f0a0108;
        public static final int actions = 0x7f0a0111;
        public static final int async = 0x7f0a018f;
        public static final int blocking = 0x7f0a022b;
        public static final int bottom = 0x7f0a0233;
        public static final int chronometer = 0x7f0a03ba;
        public static final int dataBinding = 0x7f0a0515;
        public static final int end = 0x7f0a0648;
        public static final int forever = 0x7f0a0753;
        public static final int icon = 0x7f0a085d;
        public static final int icon_group = 0x7f0a0865;
        public static final int info = 0x7f0a08cf;
        public static final int italic = 0x7f0a0940;
        public static final int left = 0x7f0a09d3;
        public static final int line1 = 0x7f0a09f1;
        public static final int line3 = 0x7f0a09f2;
        public static final int none = 0x7f0a0bde;
        public static final int normal = 0x7f0a0be0;
        public static final int notification_background = 0x7f0a0be3;
        public static final int notification_main_column = 0x7f0a0be4;
        public static final int notification_main_column_container = 0x7f0a0be5;
        public static final int onAttachStateChangeListener = 0x7f0a0c0a;
        public static final int onDateChanged = 0x7f0a0c0b;
        public static final int right = 0x7f0a0e72;
        public static final int right_icon = 0x7f0a0e7c;
        public static final int right_side = 0x7f0a0e7e;
        public static final int start = 0x7f0a107c;
        public static final int tag_transition_group = 0x7f0a1112;
        public static final int tag_unhandled_key_event_manager = 0x7f0a1113;
        public static final int tag_unhandled_key_listeners = 0x7f0a1114;
        public static final int text = 0x7f0a118f;
        public static final int text2 = 0x7f0a1190;
        public static final int textWatcher = 0x7f0a119d;
        public static final int time = 0x7f0a11c3;
        public static final int title = 0x7f0a11c6;
        public static final int top = 0x7f0a120f;

        private id() {
        }
    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 0x7f0b0061;

        private integer() {
        }
    }

    public static final class layout {
        public static final int notification_action = 0x7f0d03a1;
        public static final int notification_action_tombstone = 0x7f0d03a2;
        public static final int notification_template_custom_big = 0x7f0d03aa;
        public static final int notification_template_icon_group = 0x7f0d03ab;
        public static final int notification_template_part_chronometer = 0x7f0d03af;
        public static final int notification_template_part_time = 0x7f0d03b0;

        private layout() {
        }
    }

    public static final class string {
        public static final int status_bar_notification_info_overflow = 0x7f13162d;

        private string() {
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 0x7f140419;
        public static final int TextAppearance_Compat_Notification_Info = 0x7f14041a;
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7f14041c;
        public static final int TextAppearance_Compat_Notification_Time = 0x7f14041f;
        public static final int TextAppearance_Compat_Notification_Title = 0x7f140421;
        public static final int Widget_Compat_NotificationActionContainer = 0x7f1405f0;
        public static final int Widget_Compat_NotificationActionText = 0x7f1405f1;
        public static final int Widget_Support_CoordinatorLayout = 0x7f140743;

        private style() {
        }
    }

    public static final class styleable {
        public static final int ColorStateListItem_alpha = 0x00000003;
        public static final int ColorStateListItem_android_alpha = 0x00000001;
        public static final int ColorStateListItem_android_color = 0x00000000;
        public static final int ColorStateListItem_android_lStar = 0x00000002;
        public static final int ColorStateListItem_lStar = 0x00000004;
        public static final int CoordinatorLayout_Layout_android_layout_gravity = 0x00000000;
        public static final int CoordinatorLayout_Layout_layout_anchor = 0x00000001;
        public static final int CoordinatorLayout_Layout_layout_anchorGravity = 0x00000002;
        public static final int CoordinatorLayout_Layout_layout_behavior = 0x00000003;
        public static final int CoordinatorLayout_Layout_layout_dodgeInsetEdges = 0x00000004;
        public static final int CoordinatorLayout_Layout_layout_insetEdge = 0x00000005;
        public static final int CoordinatorLayout_Layout_layout_keyline = 0x00000006;
        public static final int CoordinatorLayout_keylines = 0x00000000;
        public static final int CoordinatorLayout_statusBarBackground = 0x00000001;
        public static final int FontFamilyFont_android_font = 0x00000000;
        public static final int FontFamilyFont_android_fontStyle = 0x00000002;
        public static final int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static final int FontFamilyFont_android_fontWeight = 0x00000001;
        public static final int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static final int FontFamilyFont_font = 0x00000005;
        public static final int FontFamilyFont_fontStyle = 0x00000006;
        public static final int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static final int FontFamilyFont_fontWeight = 0x00000008;
        public static final int FontFamilyFont_ttcIndex = 0x00000009;
        public static final int FontFamily_fontProviderAuthority = 0x00000000;
        public static final int FontFamily_fontProviderCerts = 0x00000001;
        public static final int FontFamily_fontProviderFallbackQuery = 0x00000002;
        public static final int FontFamily_fontProviderFetchStrategy = 0x00000003;
        public static final int FontFamily_fontProviderFetchTimeout = 0x00000004;
        public static final int FontFamily_fontProviderPackage = 0x00000005;
        public static final int FontFamily_fontProviderQuery = 0x00000006;
        public static final int FontFamily_fontProviderSystemFontFamily = 0x00000007;
        public static final int GradientColorItem_android_color = 0x00000000;
        public static final int GradientColorItem_android_offset = 0x00000001;
        public static final int GradientColor_android_centerColor = 0x00000007;
        public static final int GradientColor_android_centerX = 0x00000003;
        public static final int GradientColor_android_centerY = 0x00000004;
        public static final int GradientColor_android_endColor = 0x00000001;
        public static final int GradientColor_android_endX = 0x0000000a;
        public static final int GradientColor_android_endY = 0x0000000b;
        public static final int GradientColor_android_gradientRadius = 0x00000005;
        public static final int GradientColor_android_startColor = 0x00000000;
        public static final int GradientColor_android_startX = 0x00000008;
        public static final int GradientColor_android_startY = 0x00000009;
        public static final int GradientColor_android_tileMode = 0x00000006;
        public static final int GradientColor_android_type = 0x00000002;
        public static final int[] ColorStateListItem = {android.R.attr.color, android.R.attr.alpha, android.R.attr.lStar, 2130968675, 2130969700};
        public static final int[] CoordinatorLayout = {2130969699, 2130970452};
        public static final int[] CoordinatorLayout_Layout = {android.R.attr.layout_gravity, 2130969726, 2130969727, 2130969729, 2130969778, 2130969795, 2130969796};
        public static final int[] FontFamily = {2130969502, 2130969503, 2130969504, 2130969505, 2130969506, 2130969507, 2130969508, 2130969509};
        public static final int[] FontFamilyFont = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, 2130969499, 2130969510, 2130969511, 2130969512, 2130970760};
        public static final int[] GradientColor = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
        public static final int[] GradientColorItem = {android.R.attr.color, android.R.attr.offset};

        private styleable() {
        }
    }

    private R() {
    }
}