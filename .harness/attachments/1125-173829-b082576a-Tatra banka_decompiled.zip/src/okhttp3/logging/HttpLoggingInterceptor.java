package okhttp3.logging;

import h.ap;
import java.util.Set;
import kotlin.Metadata;
import kotlin.collections.SetsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Response;
import okhttp3.internal.platform.Platform;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000Z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\"\n\u0002\b\r\u0018\u0000 \u000b2\u00020\u0001:\u0003,-.B\u0013\b\u0007\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u001f\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\bH\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u0017\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0007\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\u0017\u0010\u0012\u001a\u00020\r2\u0006\u0010\u0011\u001a\u00020\u0010H\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u0015\u0010\u0016\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u0014¢\u0006\u0004\b\u0016\u0010\u0017J\u0017\u0010\u001a\u001a\u00020\u00102\u0006\u0010\u0019\u001a\u00020\u0018H\u0016¢\u0006\u0004\b\u001a\u0010\u001bJ\u0017\u0010\u001f\u001a\u00020\u001e2\u0006\u0010\u001d\u001a\u00020\u001cH\u0000¢\u0006\u0004\b\u001f\u0010 R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010!R\u001c\u0010%\u001a\b\u0012\u0004\u0012\u00020\u001e0\"8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b#\u0010$R\u001c\u0010&\u001a\b\u0012\u0004\u0012\u00020\u001e0\"8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u000e\u0010$R*\u0010\u0015\u001a\u00020\u00142\u0006\u0010'\u001a\u00020\u00148\u0006@GX\u0086\u000e¢\u0006\u0012\n\u0004\b\u0012\u0010(\u001a\u0004\b)\u0010*\"\u0004\b\u0015\u0010+¨\u0006/"}, d2 = {"Lokhttp3/logging/HttpLoggingInterceptor;", "Lokhttp3/Interceptor;", "Lokhttp3/logging/HttpLoggingInterceptor$Logger;", "logger", "<init>", "(Lokhttp3/logging/HttpLoggingInterceptor$Logger;)V", "Lokhttp3/Headers;", "headers", StringUtils.EMPTY, "i", StringUtils.EMPTY, "e", "(Lokhttp3/Headers;I)V", StringUtils.EMPTY, "c", "(Lokhttp3/Headers;)Z", "Lokhttp3/Response;", "response", "d", "(Lokhttp3/Response;)Z", "Lokhttp3/logging/HttpLoggingInterceptor$Level;", "level", "g", "(Lokhttp3/logging/HttpLoggingInterceptor$Level;)Lokhttp3/logging/HttpLoggingInterceptor;", "Lokhttp3/Interceptor$Chain;", "chain", "a", "(Lokhttp3/Interceptor$Chain;)Lokhttp3/Response;", "Lokhttp3/HttpUrl;", "url", StringUtils.EMPTY, "f", "(Lokhttp3/HttpUrl;)Ljava/lang/String;", "Lokhttp3/logging/HttpLoggingInterceptor$Logger;", StringUtils.EMPTY, "b", "Ljava/util/Set;", "headersToRedact", "queryParamsNameToRedact", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "Lokhttp3/logging/HttpLoggingInterceptor$Level;", "getLevel", "()Lokhttp3/logging/HttpLoggingInterceptor$Level;", "(Lokhttp3/logging/HttpLoggingInterceptor$Level;)V", "Level", "Logger", "Companion", "logging-interceptor"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class HttpLoggingInterceptor implements Interceptor {
    public static final Companion e = new Companion(null);
    private final Logger a;
    private volatile Set b;
    private volatile Set c;
    private volatile Level d;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lokhttp3/logging/HttpLoggingInterceptor$Companion;", StringUtils.EMPTY, "<init>", "()V", "logging-interceptor"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0007\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005j\u0002\b\u0006j\u0002\b\u0007¨\u0006\b"}, d2 = {"Lokhttp3/logging/HttpLoggingInterceptor$Level;", StringUtils.EMPTY, "<init>", "(Ljava/lang/String;I)V", "a", "b", "c", "d", "logging-interceptor"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Level {
        public static final Level a = new Level(ap.a(700631), 0);
        public static final Level b = new Level(ap.a(1490283967), 1);
        public static final Level c = new Level(ap.a(382997772), 2);
        public static final Level d = new Level(ap.a(1420629085), 3);
        private static final /* synthetic */ Level[] e;
        private static final /* synthetic */ EnumEntries f;

        static {
            Level[] levelArrA = a();
            e = levelArrA;
            f = EnumEntriesKt.enumEntries(levelArrA);
        }

        private Level(String str, int i) {
        }

        private static final /* synthetic */ Level[] a() {
            return new Level[]{a, b, c, d};
        }

        public static Level valueOf(String str) {
            return (Level) Enum.valueOf(Level.class, str);
        }

        public static Level[] values() {
            return (Level[]) e.clone();
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\bæ\u0080\u0001\u0018\u0000 \u00052\u00020\u0001:\u0001\u0007J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H&¢\u0006\u0004\b\u0005\u0010\u0006ø\u0001\u0000\u0082\u0002\u0006\n\u0004\b!0\u0001¨\u0006\bÀ\u0006\u0001"}, d2 = {"Lokhttp3/logging/HttpLoggingInterceptor$Logger;", StringUtils.EMPTY, StringUtils.EMPTY, "message", StringUtils.EMPTY, "a", "(Ljava/lang/String;)V", "Companion", "logging-interceptor"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public interface Logger {
        public static final Companion a = Companion.a;
        public static final Logger b = new Companion.DefaultLogger();

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001:\u0001\u0006B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0013\u0010\u0004\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u0001¨\u0006\u0007"}, d2 = {"Lokhttp3/logging/HttpLoggingInterceptor$Logger$Companion;", StringUtils.EMPTY, "<init>", "()V", "DEFAULT", "Lokhttp3/logging/HttpLoggingInterceptor$Logger;", "DefaultLogger", "logging-interceptor"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class Companion {
            static final /* synthetic */ Companion a = new Companion();

            /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
            @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lokhttp3/logging/HttpLoggingInterceptor$Logger$Companion$DefaultLogger;", "Lokhttp3/logging/HttpLoggingInterceptor$Logger;", "<init>", "()V", StringUtils.EMPTY, "message", StringUtils.EMPTY, "a", "(Ljava/lang/String;)V", "logging-interceptor"}, k = 1, mv = {2, 2, 0}, xi = 48)
            private static final class DefaultLogger implements Logger {
                @Override // okhttp3.logging.HttpLoggingInterceptor.Logger
                public void a(String str) {
                    Intrinsics.checkNotNullParameter(str, ap.a(2139092132));
                    Platform.o(Platform.a.e(), str, 0, null, 6, null);
                }
            }

            private Companion() {
            }
        }

        void a(String str);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    @JvmOverloads
    public HttpLoggingInterceptor() {
        Logger logger = null;
        this(logger, 1, logger);
    }

    private final boolean c(Headers headers) {
        String strA = headers.a(HttpHeaders.CONTENT_ENCODING);
        return (strA == null || StringsKt.equals(strA, "identity", true) || StringsKt.equals(strA, "gzip", true)) ? false : true;
    }

    private final boolean d(Response response) {
        MediaType mediaTypeU = response.j().u();
        return mediaTypeU != null && Intrinsics.areEqual(mediaTypeU.i(), "text") && Intrinsics.areEqual(mediaTypeU.h(), "event-stream");
    }

    private final void e(Headers headers, int i) {
        String strK = this.b.contains(headers.e(i)) ? "██" : headers.k(i);
        this.a.a(headers.e(i) + ": " + strK);
    }

    /* JADX WARN: Removed duplicated region for block: B:43:0x010b A[LOOP:0: B:42:0x0109->B:43:0x010b, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:47:0x0117  */
    @Override // okhttp3.Interceptor
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public okhttp3.Response a(okhttp3.Interceptor.Chain r22) throws java.lang.Exception {
        /*
            Method dump skipped, instruction units count: 1178
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.logging.HttpLoggingInterceptor.a(okhttp3.Interceptor$Chain):okhttp3.Response");
    }

    public final String f(HttpUrl httpUrl) {
        Intrinsics.checkNotNullParameter(httpUrl, "url");
        if (this.c.isEmpty() || httpUrl.p() == 0) {
            return httpUrl.toString();
        }
        HttpUrl.Builder builderQ = httpUrl.i().q(null);
        int iP = httpUrl.p();
        for (int i = 0; i < iP; i++) {
            String strN = httpUrl.n(i);
            builderQ.a(strN, this.c.contains(strN) ? "██" : httpUrl.o(i));
        }
        return builderQ.toString();
    }

    public final HttpLoggingInterceptor g(Level level) {
        Intrinsics.checkNotNullParameter(level, "level");
        this.d = level;
        return this;
    }

    public HttpLoggingInterceptor(Logger logger) {
        Intrinsics.checkNotNullParameter(logger, ap.a(2126240937));
        this.a = logger;
        this.b = SetsKt.emptySet();
        this.c = SetsKt.emptySet();
        this.d = Level.a;
    }

    public /* synthetic */ HttpLoggingInterceptor(Logger logger, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? Logger.b : logger);
    }
}