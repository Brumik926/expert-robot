package okhttp3;

import h.ap;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.internal._HostnamesCommonKt;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\f\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\r\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\u000b\u0010\fJ\u001a\u0010\u000e\u001a\u00020\n2\b\u0010\r\u001a\u0004\u0018\u00010\u0001H\u0096\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0014\u001a\u00020\u0013H\u0016¢\u0006\u0004\b\u0014\u0010\u0015R\u0017\u0010\u0003\u001a\u00020\u00028G¢\u0006\f\n\u0004\b\u0016\u0010\u0017\u001a\u0004\b\u0016\u0010\u0018R\u0017\u0010\u0005\u001a\u00020\u00048G¢\u0006\f\n\u0004\b\u0019\u0010\u001a\u001a\u0004\b\u0019\u0010\u001bR\u0017\u0010\u0007\u001a\u00020\u00068G¢\u0006\f\n\u0004\b\u000b\u0010\u001c\u001a\u0004\b\u001d\u0010\u001e¨\u0006\u001f"}, d2 = {"Lokhttp3/Route;", StringUtils.EMPTY, "Lokhttp3/Address;", "address", "Ljava/net/Proxy;", "proxy", "Ljava/net/InetSocketAddress;", "socketAddress", "<init>", "(Lokhttp3/Address;Ljava/net/Proxy;Ljava/net/InetSocketAddress;)V", StringUtils.EMPTY, "c", "()Z", "other", "equals", "(Ljava/lang/Object;)Z", StringUtils.EMPTY, "hashCode", "()I", StringUtils.EMPTY, "toString", "()Ljava/lang/String;", "a", "Lokhttp3/Address;", "()Lokhttp3/Address;", "b", "Ljava/net/Proxy;", "()Ljava/net/Proxy;", "Ljava/net/InetSocketAddress;", "d", "()Ljava/net/InetSocketAddress;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Route {
    private final Address a;
    private final Proxy b;
    private final InetSocketAddress c;

    public Route(Address address, Proxy proxy, InetSocketAddress inetSocketAddress) {
        Intrinsics.checkNotNullParameter(address, ap.a(48906275));
        Intrinsics.checkNotNullParameter(proxy, ap.a(35314491));
        Intrinsics.checkNotNullParameter(inetSocketAddress, ap.a(353011780));
        this.a = address;
        this.b = proxy;
        this.c = inetSocketAddress;
    }

    public final Address a() {
        return this.a;
    }

    public final Proxy b() {
        return this.b;
    }

    public final boolean c() {
        if (this.b.type() != Proxy.Type.HTTP) {
            return false;
        }
        return this.a.k() != null || this.a.f().contains(Protocol.g);
    }

    public final InetSocketAddress d() {
        return this.c;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Route)) {
            return false;
        }
        Route route = (Route) obj;
        return Intrinsics.areEqual(route.a, this.a) && Intrinsics.areEqual(route.b, this.b) && Intrinsics.areEqual(route.c, this.c);
    }

    public int hashCode() {
        return ((((527 + this.a.hashCode()) * 31) + this.b.hashCode()) * 31) + this.c.hashCode();
    }

    public String toString() {
        String hostAddress;
        StringBuilder sb = new StringBuilder();
        String strG = this.a.l().g();
        InetAddress address = this.c.getAddress();
        String strK = (address == null || (hostAddress = address.getHostAddress()) == null) ? null : _HostnamesCommonKt.k(hostAddress);
        if (StringsKt.contains$default((CharSequence) strG, AbstractJsonLexerKt.COLON, false, 2, (Object) null)) {
            sb.append("[");
            sb.append(strG);
            sb.append("]");
        } else {
            sb.append(strG);
        }
        if (this.a.l().l() != this.c.getPort() || Intrinsics.areEqual(strG, strK)) {
            sb.append(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
            sb.append(this.a.l().l());
        }
        if (!Intrinsics.areEqual(strG, strK)) {
            if (Intrinsics.areEqual(this.b, Proxy.NO_PROXY)) {
                sb.append(" at ");
            } else {
                sb.append(" via proxy ");
            }
            if (strK == null) {
                sb.append("<unresolved>");
            } else if (StringsKt.contains$default((CharSequence) strK, AbstractJsonLexerKt.COLON, false, 2, (Object) null)) {
                sb.append("[");
                sb.append(strK);
                sb.append("]");
            } else {
                sb.append(strK);
            }
            sb.append(TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER);
            sb.append(this.c.getPort());
        }
        return sb.toString();
    }
}