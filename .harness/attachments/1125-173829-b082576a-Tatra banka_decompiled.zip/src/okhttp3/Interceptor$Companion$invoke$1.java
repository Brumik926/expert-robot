package okhttp3;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.Interceptor;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(k = 3, mv = {2, 2, 0}, xi = 176)
@SourceDebugExtension({"SMAP\nInterceptor.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Interceptor.kt\nokhttp3/Interceptor$Companion$invoke$1\n*L\n1#1,113:1\n*E\n"})
public final class Interceptor$Companion$invoke$1 implements Interceptor {
    final /* synthetic */ Function1 a;

    @Override // okhttp3.Interceptor
    public final Response a(Interceptor.Chain chain) {
        Intrinsics.checkNotNullParameter(chain, ap.a(341236538));
        return (Response) this.a.invoke(chain);
    }
}