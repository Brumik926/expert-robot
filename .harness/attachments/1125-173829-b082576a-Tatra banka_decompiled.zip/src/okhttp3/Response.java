package okhttp3;

import h.ap;
import java.io.Closeable;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.Headers;
import okhttp3.internal.connection.Exchange;
import okhttp3.internal.http.HttpHeaders;
import okio.Buffer;
import okio.BufferedSource;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000z\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b0\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\b\u0018\u00002\u00020\u0001:\u0001kB\u0083\u0001\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\n\u0012\u0006\u0010\r\u001a\u00020\f\u0012\u0006\u0010\u000f\u001a\u00020\u000e\u0012\b\u0010\u0010\u001a\u0004\u0018\u00010\u0000\u0012\b\u0010\u0011\u001a\u0004\u0018\u00010\u0000\u0012\b\u0010\u0012\u001a\u0004\u0018\u00010\u0000\u0012\u0006\u0010\u0014\u001a\u00020\u0013\u0012\u0006\u0010\u0015\u001a\u00020\u0013\u0012\b\u0010\u0017\u001a\u0004\u0018\u00010\u0016\u0012\u0006\u0010\u0019\u001a\u00020\u0018¢\u0006\u0004\b\u001a\u0010\u001bJ\u001b\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u00060\u001d2\u0006\u0010\u001c\u001a\u00020\u0006¢\u0006\u0004\b\u001e\u0010\u001fJ%\u0010!\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u001c\u001a\u00020\u00062\n\b\u0002\u0010 \u001a\u0004\u0018\u00010\u0006H\u0007¢\u0006\u0004\b!\u0010\"J\u0015\u0010$\u001a\u00020\u000e2\u0006\u0010#\u001a\u00020\u0013¢\u0006\u0004\b$\u0010%J\r\u0010'\u001a\u00020&¢\u0006\u0004\b'\u0010(J\u0013\u0010*\u001a\b\u0012\u0004\u0012\u00020)0\u001d¢\u0006\u0004\b*\u0010+J\u000f\u0010-\u001a\u00020,H\u0016¢\u0006\u0004\b-\u0010.J\u000f\u0010/\u001a\u00020\u0006H\u0016¢\u0006\u0004\b/\u00100R\u0017\u0010\u0003\u001a\u00020\u00028G¢\u0006\f\n\u0004\b1\u00102\u001a\u0004\b3\u00104R\u0017\u0010\u0005\u001a\u00020\u00048G¢\u0006\f\n\u0004\b5\u00106\u001a\u0004\b7\u00108R\u0017\u0010\u0007\u001a\u00020\u00068G¢\u0006\f\n\u0004\b9\u0010:\u001a\u0004\b;\u00100R\u0017\u0010\t\u001a\u00020\b8G¢\u0006\f\n\u0004\b<\u0010\u001e\u001a\u0004\b=\u0010>R\u0019\u0010\u000b\u001a\u0004\u0018\u00010\n8G¢\u0006\f\n\u0004\b?\u0010@\u001a\u0004\bA\u0010BR\u0017\u0010\r\u001a\u00020\f8G¢\u0006\f\n\u0004\bC\u0010D\u001a\u0004\bE\u0010FR\u0017\u0010\u000f\u001a\u00020\u000e8G¢\u0006\f\n\u0004\bG\u0010H\u001a\u0004\bI\u0010JR\u0019\u0010\u0010\u001a\u0004\u0018\u00010\u00008G¢\u0006\f\n\u0004\bK\u0010L\u001a\u0004\bM\u0010NR\u0019\u0010\u0011\u001a\u0004\u0018\u00010\u00008G¢\u0006\f\n\u0004\bO\u0010L\u001a\u0004\bP\u0010NR\u0019\u0010\u0012\u001a\u0004\u0018\u00010\u00008G¢\u0006\f\n\u0004\bI\u0010L\u001a\u0004\bQ\u0010NR\u0017\u0010\u0014\u001a\u00020\u00138G¢\u0006\f\n\u0004\bR\u0010E\u001a\u0004\bS\u0010TR\u0017\u0010\u0015\u001a\u00020\u00138G¢\u0006\f\n\u0004\bU\u0010E\u001a\u0004\bV\u0010TR\u001c\u0010\u0017\u001a\u0004\u0018\u00010\u00168AX\u0080\u0004¢\u0006\f\n\u0004\bW\u0010X\u001a\u0004\bY\u0010ZR\u0016\u0010\u0019\u001a\u00020\u00188\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b[\u0010\\R$\u0010c\u001a\u0004\u0018\u00010]8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bP\u0010^\u001a\u0004\b_\u0010`\"\u0004\ba\u0010bR\u0017\u0010g\u001a\u00020d8\u0006¢\u0006\f\n\u0004\be\u0010f\u001a\u0004\bg\u0010hR\u0017\u0010i\u001a\u00020d8\u0006¢\u0006\f\n\u0004\b*\u0010f\u001a\u0004\bi\u0010hR\u0011\u0010j\u001a\u00020]8G¢\u0006\u0006\u001a\u0004\bR\u0010`¨\u0006l"}, d2 = {"Lokhttp3/Response;", "Ljava/io/Closeable;", "Lokhttp3/Request;", "request", "Lokhttp3/Protocol;", "protocol", StringUtils.EMPTY, "message", StringUtils.EMPTY, "code", "Lokhttp3/Handshake;", "handshake", "Lokhttp3/Headers;", "headers", "Lokhttp3/ResponseBody;", "body", "networkResponse", "cacheResponse", "priorResponse", StringUtils.EMPTY, "sentRequestAtMillis", "receivedResponseAtMillis", "Lokhttp3/internal/connection/Exchange;", "exchange", "Lokhttp3/TrailersSource;", "trailersSource", "<init>", "(Lokhttp3/Request;Lokhttp3/Protocol;Ljava/lang/String;ILokhttp3/Handshake;Lokhttp3/Headers;Lokhttp3/ResponseBody;Lokhttp3/Response;Lokhttp3/Response;Lokhttp3/Response;JJLokhttp3/internal/connection/Exchange;Lokhttp3/TrailersSource;)V", "name", StringUtils.EMPTY, "I", "(Ljava/lang/String;)Ljava/util/List;", "defaultValue", "B", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", "byteCount", "V", "(J)Lokhttp3/ResponseBody;", "Lokhttp3/Response$Builder;", "Q", "()Lokhttp3/Response$Builder;", "Lokhttp3/Challenge;", "q", "()Ljava/util/List;", StringUtils.EMPTY, "close", "()V", "toString", "()Ljava/lang/String;", "a", "Lokhttp3/Request;", "b0", "()Lokhttp3/Request;", "b", "Lokhttp3/Protocol;", "X", "()Lokhttp3/Protocol;", "c", "Ljava/lang/String;", "O", "d", "r", "()I", "e", "Lokhttp3/Handshake;", "A", "()Lokhttp3/Handshake;", "f", "Lokhttp3/Headers;", "J", "()Lokhttp3/Headers;", "g", "Lokhttp3/ResponseBody;", "j", "()Lokhttp3/ResponseBody;", "h", "Lokhttp3/Response;", "P", "()Lokhttp3/Response;", "i", "o", "W", "k", "d0", "()J", "l", "a0", "m", "Lokhttp3/internal/connection/Exchange;", "u", "()Lokhttp3/internal/connection/Exchange;", "n", "Lokhttp3/TrailersSource;", "Lokhttp3/CacheControl;", "Lokhttp3/CacheControl;", "getLazyCacheControl$okhttp", "()Lokhttp3/CacheControl;", "setLazyCacheControl$okhttp", "(Lokhttp3/CacheControl;)V", "lazyCacheControl", StringUtils.EMPTY, "p", "Z", "isSuccessful", "()Z", "isRedirect", "cacheControl", "Builder", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Response implements Closeable {
    private final Request a;
    private final Protocol b;
    private final String c;
    private final int d;
    private final Handshake e;
    private final Headers f;
    private final ResponseBody g;
    private final Response h;
    private final Response i;
    private final Response j;
    private final long k;
    private final long l;
    private final Exchange m;
    private TrailersSource n;
    private CacheControl o;
    private final boolean p;
    private final boolean q;

    public Response(Request request, Protocol protocol, String str, int i, Handshake handshake, Headers headers, ResponseBody responseBody, Response response, Response response2, Response response3, long j, long j2, Exchange exchange, TrailersSource trailersSource) {
        Intrinsics.checkNotNullParameter(request, ap.a(1986556725));
        Intrinsics.checkNotNullParameter(protocol, ap.a(147194679));
        Intrinsics.checkNotNullParameter(str, ap.a(980245987));
        Intrinsics.checkNotNullParameter(headers, ap.a(674418773));
        Intrinsics.checkNotNullParameter(responseBody, ap.a(1234898351));
        Intrinsics.checkNotNullParameter(trailersSource, ap.a(829749249));
        this.a = request;
        this.b = protocol;
        this.c = str;
        this.d = i;
        this.e = handshake;
        this.f = headers;
        this.g = responseBody;
        this.h = response;
        this.i = response2;
        this.j = response3;
        this.k = j;
        this.l = j2;
        this.m = exchange;
        this.n = trailersSource;
        boolean z = true;
        this.p = 200 <= i && i < 300;
        if (i != 307 && i != 308) {
            switch (i) {
                case 300:
                case 301:
                case 302:
                case 303:
                    break;
                default:
                    z = false;
                    break;
            }
        }
        this.q = z;
    }

    public static /* synthetic */ String D(Response response, String str, String str2, int i, Object obj) {
        if ((i & 2) != 0) {
            str2 = null;
        }
        return response.B(str, str2);
    }

    public final Handshake A() {
        return this.e;
    }

    public final String B(String str, String str2) {
        Intrinsics.checkNotNullParameter(str, "name");
        String strA = this.f.a(str);
        return strA == null ? str2 : strA;
    }

    public final List I(String str) {
        Intrinsics.checkNotNullParameter(str, "name");
        return this.f.l(str);
    }

    public final Headers J() {
        return this.f;
    }

    public final String O() {
        return this.c;
    }

    public final Response P() {
        return this.h;
    }

    public final Builder Q() {
        return new Builder(this);
    }

    public final ResponseBody V(long j) {
        BufferedSource bufferedSourcePeek = this.g.A().peek();
        Buffer buffer = new Buffer();
        bufferedSourcePeek.request(j);
        buffer.o0(bufferedSourcePeek, Math.min(j, bufferedSourcePeek.getBuffer().size()));
        return ResponseBody.b.a(buffer, this.g.u(), buffer.size());
    }

    public final Response W() {
        return this.j;
    }

    public final Protocol X() {
        return this.b;
    }

    public final long a0() {
        return this.l;
    }

    public final Request b0() {
        return this.a;
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.g.close();
    }

    public final long d0() {
        return this.k;
    }

    public final boolean isSuccessful() {
        return this.p;
    }

    public final ResponseBody j() {
        return this.g;
    }

    public final CacheControl k() {
        CacheControl cacheControl = this.o;
        if (cacheControl != null) {
            return cacheControl;
        }
        CacheControl cacheControlA = CacheControl.n.a(this.f);
        this.o = cacheControlA;
        return cacheControlA;
    }

    public final Response o() {
        return this.i;
    }

    public final List q() {
        String str;
        Headers headers = this.f;
        int i = this.d;
        if (i == 401) {
            str = "WWW-Authenticate";
        } else {
            if (i != 407) {
                return CollectionsKt.emptyList();
            }
            str = "Proxy-Authenticate";
        }
        return HttpHeaders.a(headers, str);
    }

    public final int r() {
        return this.d;
    }

    public String toString() {
        return "Response{protocol=" + this.b + ", code=" + this.d + ", message=" + this.c + ", url=" + this.a.m() + AbstractJsonLexerKt.END_OBJ;
    }

    public final Exchange u() {
        return this.m;
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000r\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u001e\n\u0002\u0018\u0002\n\u0002\b\"\b\u0016\u0018\u00002\u00020\u0001B\t\b\u0016¢\u0006\u0004\b\u0002\u0010\u0003B\u0011\b\u0010\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0002\u0010\u0006J!\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u00072\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004H\u0002¢\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\u000e\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u0017\u0010\u0012\u001a\u00020\u00002\u0006\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0012\u0010\u0013J\u0017\u0010\u0016\u001a\u00020\u00002\u0006\u0010\u0015\u001a\u00020\u0014H\u0016¢\u0006\u0004\b\u0016\u0010\u0017J\u0017\u0010\u0019\u001a\u00020\u00002\u0006\u0010\u0018\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0019\u0010\u001aJ\u0019\u0010\u001d\u001a\u00020\u00002\b\u0010\u001c\u001a\u0004\u0018\u00010\u001bH\u0016¢\u0006\u0004\b\u001d\u0010\u001eJ\u001f\u0010 \u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u0007H\u0016¢\u0006\u0004\b \u0010!J\u001f\u0010\"\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u001f\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\"\u0010!J\u0017\u0010%\u001a\u00020\u00002\u0006\u0010$\u001a\u00020#H\u0016¢\u0006\u0004\b%\u0010&J\u0017\u0010)\u001a\u00020\u00002\u0006\u0010(\u001a\u00020'H\u0016¢\u0006\u0004\b)\u0010*J\u0019\u0010,\u001a\u00020\u00002\b\u0010+\u001a\u0004\u0018\u00010\u0004H\u0016¢\u0006\u0004\b,\u0010-J\u0019\u0010/\u001a\u00020\u00002\b\u0010.\u001a\u0004\u0018\u00010\u0004H\u0016¢\u0006\u0004\b/\u0010-J\u0019\u00101\u001a\u00020\u00002\b\u00100\u001a\u0004\u0018\u00010\u0004H\u0016¢\u0006\u0004\b1\u0010-J\u0017\u00104\u001a\u00020\u00002\u0006\u00103\u001a\u000202H\u0016¢\u0006\u0004\b4\u00105J\u0017\u00108\u001a\u00020\u00002\u0006\u00107\u001a\u000206H\u0016¢\u0006\u0004\b8\u00109J\u0017\u0010;\u001a\u00020\u00002\u0006\u0010:\u001a\u000206H\u0016¢\u0006\u0004\b;\u00109J\u0017\u0010>\u001a\u00020\t2\u0006\u0010=\u001a\u00020<H\u0000¢\u0006\u0004\b>\u0010?J\u000f\u0010@\u001a\u00020\u0004H\u0016¢\u0006\u0004\b@\u0010AR$\u0010\r\u001a\u0004\u0018\u00010\f8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\"\u0010B\u001a\u0004\bC\u0010D\"\u0004\bE\u0010FR$\u0010\u0011\u001a\u0004\u0018\u00010\u00108\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b)\u0010G\u001a\u0004\bH\u0010I\"\u0004\bJ\u0010KR\"\u0010\u0015\u001a\u00020\u00148\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b@\u0010L\u001a\u0004\bM\u0010N\"\u0004\bO\u0010PR$\u0010\u0018\u001a\u0004\u0018\u00010\u00078\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b/\u0010Q\u001a\u0004\bR\u0010S\"\u0004\bT\u0010UR$\u0010\u001c\u001a\u0004\u0018\u00010\u001b8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\n\u0010V\u001a\u0004\bW\u0010X\"\u0004\bY\u0010ZR\"\u0010$\u001a\u00020[8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0016\u0010\\\u001a\u0004\b]\u0010^\"\u0004\b_\u0010`R\"\u0010(\u001a\u00020'8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bM\u0010a\u001a\u0004\bb\u0010c\"\u0004\bd\u0010eR$\u0010+\u001a\u0004\u0018\u00010\u00048\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u001d\u0010f\u001a\u0004\bg\u0010A\"\u0004\bh\u0010\u0006R$\u0010.\u001a\u0004\u0018\u00010\u00048\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b \u0010f\u001a\u0004\bi\u0010A\"\u0004\bj\u0010\u0006R$\u00100\u001a\u0004\u0018\u00010\u00048\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b%\u0010f\u001a\u0004\bk\u0010A\"\u0004\bl\u0010\u0006R\"\u00107\u001a\u0002068\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b>\u0010m\u001a\u0004\bn\u0010o\"\u0004\bp\u0010qR\"\u0010:\u001a\u0002068\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0019\u0010m\u001a\u0004\br\u0010o\"\u0004\bs\u0010qR$\u0010=\u001a\u0004\u0018\u00010<8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b,\u0010t\u001a\u0004\bu\u0010v\"\u0004\bw\u0010?R\"\u00103\u001a\u0002028\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b1\u0010x\u001a\u0004\by\u0010z\"\u0004\b{\u0010|¨\u0006}"}, d2 = {"Lokhttp3/Response$Builder;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/Response;", "response", "(Lokhttp3/Response;)V", StringUtils.EMPTY, "name", StringUtils.EMPTY, "e", "(Ljava/lang/String;Lokhttp3/Response;)V", "Lokhttp3/Request;", "request", "q", "(Lokhttp3/Request;)Lokhttp3/Response$Builder;", "Lokhttp3/Protocol;", "protocol", "o", "(Lokhttp3/Protocol;)Lokhttp3/Response$Builder;", StringUtils.EMPTY, "code", "f", "(I)Lokhttp3/Response$Builder;", "message", "l", "(Ljava/lang/String;)Lokhttp3/Response$Builder;", "Lokhttp3/Handshake;", "handshake", "h", "(Lokhttp3/Handshake;)Lokhttp3/Response$Builder;", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "i", "(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Response$Builder;", "a", "Lokhttp3/Headers;", "headers", "j", "(Lokhttp3/Headers;)Lokhttp3/Response$Builder;", "Lokhttp3/ResponseBody;", "body", "b", "(Lokhttp3/ResponseBody;)Lokhttp3/Response$Builder;", "networkResponse", "m", "(Lokhttp3/Response;)Lokhttp3/Response$Builder;", "cacheResponse", "d", "priorResponse", "n", "Lokhttp3/TrailersSource;", "trailersSource", "s", "(Lokhttp3/TrailersSource;)Lokhttp3/Response$Builder;", StringUtils.EMPTY, "sentRequestAtMillis", "r", "(J)Lokhttp3/Response$Builder;", "receivedResponseAtMillis", "p", "Lokhttp3/internal/connection/Exchange;", "exchange", "k", "(Lokhttp3/internal/connection/Exchange;)V", "c", "()Lokhttp3/Response;", "Lokhttp3/Request;", "getRequest$okhttp", "()Lokhttp3/Request;", "setRequest$okhttp", "(Lokhttp3/Request;)V", "Lokhttp3/Protocol;", "getProtocol$okhttp", "()Lokhttp3/Protocol;", "setProtocol$okhttp", "(Lokhttp3/Protocol;)V", "I", "g", "()I", "setCode$okhttp", "(I)V", "Ljava/lang/String;", "getMessage$okhttp", "()Ljava/lang/String;", "setMessage$okhttp", "(Ljava/lang/String;)V", "Lokhttp3/Handshake;", "getHandshake$okhttp", "()Lokhttp3/Handshake;", "setHandshake$okhttp", "(Lokhttp3/Handshake;)V", "Lokhttp3/Headers$Builder;", "Lokhttp3/Headers$Builder;", "getHeaders$okhttp", "()Lokhttp3/Headers$Builder;", "setHeaders$okhttp", "(Lokhttp3/Headers$Builder;)V", "Lokhttp3/ResponseBody;", "getBody$okhttp", "()Lokhttp3/ResponseBody;", "setBody$okhttp", "(Lokhttp3/ResponseBody;)V", "Lokhttp3/Response;", "getNetworkResponse$okhttp", "setNetworkResponse$okhttp", "getCacheResponse$okhttp", "setCacheResponse$okhttp", "getPriorResponse$okhttp", "setPriorResponse$okhttp", "J", "getSentRequestAtMillis$okhttp", "()J", "setSentRequestAtMillis$okhttp", "(J)V", "getReceivedResponseAtMillis$okhttp", "setReceivedResponseAtMillis$okhttp", "Lokhttp3/internal/connection/Exchange;", "getExchange$okhttp", "()Lokhttp3/internal/connection/Exchange;", "setExchange$okhttp", "Lokhttp3/TrailersSource;", "getTrailersSource$okhttp", "()Lokhttp3/TrailersSource;", "setTrailersSource$okhttp", "(Lokhttp3/TrailersSource;)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nResponse.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Response.kt\nokhttp3/Response$Builder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,517:1\n1#2:518\n*E\n"})
    public static class Builder {
        private Request a;
        private Protocol b;
        private int c;
        private String d;
        private Handshake e;
        private Headers.Builder f;
        private ResponseBody g;
        private Response h;
        private Response i;
        private Response j;
        private long k;
        private long l;
        private Exchange m;
        private TrailersSource n;

        public Builder() {
            this.c = -1;
            this.g = ResponseBody.c;
            this.n = TrailersSource.b;
            this.f = new Headers.Builder();
        }

        private final void e(String str, Response response) {
            if (response != null) {
                if (response.P() != null) {
                    throw new IllegalArgumentException((str + ".networkResponse != null").toString());
                }
                if (response.o() != null) {
                    throw new IllegalArgumentException((str + ".cacheResponse != null").toString());
                }
                if (response.W() == null) {
                    return;
                }
                throw new IllegalArgumentException((str + ".priorResponse != null").toString());
            }
        }

        public Builder a(String str, String str2) {
            Intrinsics.checkNotNullParameter(str, "name");
            Intrinsics.checkNotNullParameter(str2, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
            this.f.a(str, str2);
            return this;
        }

        public Builder b(ResponseBody responseBody) {
            Intrinsics.checkNotNullParameter(responseBody, "body");
            this.g = responseBody;
            return this;
        }

        public Response c() {
            int i = this.c;
            if (i < 0) {
                throw new IllegalStateException(("code < 0: " + this.c).toString());
            }
            Request request = this.a;
            if (request == null) {
                throw new IllegalStateException("request == null");
            }
            Protocol protocol = this.b;
            if (protocol == null) {
                throw new IllegalStateException("protocol == null");
            }
            String str = this.d;
            if (str != null) {
                return new Response(request, protocol, str, i, this.e, this.f.e(), this.g, this.h, this.i, this.j, this.k, this.l, this.m, this.n);
            }
            throw new IllegalStateException("message == null");
        }

        public Builder d(Response response) {
            e("cacheResponse", response);
            this.i = response;
            return this;
        }

        public Builder f(int i) {
            this.c = i;
            return this;
        }

        public final int g() {
            return this.c;
        }

        public Builder h(Handshake handshake) {
            this.e = handshake;
            return this;
        }

        public Builder i(String str, String str2) {
            Intrinsics.checkNotNullParameter(str, "name");
            Intrinsics.checkNotNullParameter(str2, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
            this.f.i(str, str2);
            return this;
        }

        public Builder j(Headers headers) {
            Intrinsics.checkNotNullParameter(headers, "headers");
            this.f = headers.f();
            return this;
        }

        public final void k(Exchange exchange) {
            Intrinsics.checkNotNullParameter(exchange, "exchange");
            this.m = exchange;
        }

        public Builder l(String str) {
            Intrinsics.checkNotNullParameter(str, "message");
            this.d = str;
            return this;
        }

        public Builder m(Response response) {
            e("networkResponse", response);
            this.h = response;
            return this;
        }

        public Builder n(Response response) {
            this.j = response;
            return this;
        }

        public Builder o(Protocol protocol) {
            Intrinsics.checkNotNullParameter(protocol, "protocol");
            this.b = protocol;
            return this;
        }

        public Builder p(long j) {
            this.l = j;
            return this;
        }

        public Builder q(Request request) {
            Intrinsics.checkNotNullParameter(request, "request");
            this.a = request;
            return this;
        }

        public Builder r(long j) {
            this.k = j;
            return this;
        }

        public Builder s(TrailersSource trailersSource) {
            Intrinsics.checkNotNullParameter(trailersSource, "trailersSource");
            this.n = trailersSource;
            return this;
        }

        public Builder(Response response) {
            Intrinsics.checkNotNullParameter(response, ap.a(1901412351));
            this.c = -1;
            this.g = ResponseBody.c;
            this.n = TrailersSource.b;
            this.a = response.b0();
            this.b = response.X();
            this.c = response.r();
            this.d = response.O();
            this.e = response.A();
            this.f = response.J().f();
            this.g = response.j();
            this.h = response.P();
            this.i = response.o();
            this.j = response.W();
            this.k = response.d0();
            this.l = response.a0();
            this.m = response.u();
            this.n = response.n;
        }
    }
}