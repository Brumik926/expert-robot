package okhttp3;

import h.ap;
import kotlin.Metadata;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okio.BufferedSink;
import okio.FileSystem;
import okio.Path;
import okio.Source;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000$\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\b\n\u0018\u00002\u00020\u0001J\u0011\u0010\u0003\u001a\u0004\u0018\u00010\u0002H\u0016¢\u0006\u0004\b\u0003\u0010\u0004J\u000f\u0010\u0006\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0006\u0010\u0007J\u0017\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\bH\u0016¢\u0006\u0004\b\u000b\u0010\f¨\u0006\r"}, d2 = {"okhttp3/RequestBody$Companion$asRequestBody$2", "Lokhttp3/RequestBody;", "Lokhttp3/MediaType;", "b", "()Lokhttp3/MediaType;", StringUtils.EMPTY, "a", "()J", "Lokio/BufferedSink;", "sink", StringUtils.EMPTY, "h", "(Lokio/BufferedSink;)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nRequestBody.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RequestBody.kt\nokhttp3/RequestBody$Companion$asRequestBody$2\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,260:1\n1#2:261\n*E\n"})
public final class RequestBody$Companion$asRequestBody$2 extends RequestBody {
    final /* synthetic */ MediaType c;
    final /* synthetic */ FileSystem d;
    final /* synthetic */ Path e;

    @Override // okhttp3.RequestBody
    public long a() {
        Long lC = this.d.D(this.e).c();
        if (lC != null) {
            return lC.longValue();
        }
        return -1L;
    }

    @Override // okhttp3.RequestBody
    public MediaType b() {
        return this.c;
    }

    @Override // okhttp3.RequestBody
    public void h(BufferedSink bufferedSink) {
        Intrinsics.checkNotNullParameter(bufferedSink, ap.a(1327145829));
        Source sourceW = this.d.W(this.e);
        try {
            bufferedSink.d2(sourceW);
            CloseableKt.closeFinally(sourceW, (Throwable) null);
        } finally {
        }
    }
}