package okhttp3;

import h.ap;
import java.io.Closeable;
import java.io.File;
import java.io.Flushable;
import java.io.IOException;
import java.security.cert.Certificate;
import java.security.cert.CertificateEncodingException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.SetsKt;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.Headers;
import okhttp3.Response;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal.cache.CacheRequest;
import okhttp3.internal.cache.CacheStrategy;
import okhttp3.internal.cache.DiskLruCache;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.http.HttpMethod;
import okhttp3.internal.http.StatusLine;
import okhttp3.internal.platform.Platform;
import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.ByteString;
import okio.FileSystem;
import okio.ForwardingSink;
import okio.ForwardingSource;
import okio.Okio;
import okio.Path;
import okio.Sink;
import okio.Source;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\b\n\u0002\b\u0016\u0018\u0000 B2\u00020\u00012\u00020\u0002:\u0004CDEFB)\b\u0000\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\n\u001a\u00020\t¢\u0006\u0004\b\u000b\u0010\fB!\b\u0016\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u000b\u0010\rB\u0019\b\u0016\u0012\u0006\u0010\u0004\u001a\u00020\u000e\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u000b\u0010\u000fJ\u001d\u0010\u0014\u001a\u00020\u00132\f\u0010\u0012\u001a\b\u0018\u00010\u0010R\u00020\u0011H\u0002¢\u0006\u0004\b\u0014\u0010\u0015J\u0019\u0010\u0019\u001a\u0004\u0018\u00010\u00182\u0006\u0010\u0017\u001a\u00020\u0016H\u0000¢\u0006\u0004\b\u0019\u0010\u001aJ\u0019\u0010\u001d\u001a\u0004\u0018\u00010\u001c2\u0006\u0010\u001b\u001a\u00020\u0018H\u0000¢\u0006\u0004\b\u001d\u0010\u001eJ\u0017\u0010\u001f\u001a\u00020\u00132\u0006\u0010\u0017\u001a\u00020\u0016H\u0000¢\u0006\u0004\b\u001f\u0010 J\u001f\u0010#\u001a\u00020\u00132\u0006\u0010!\u001a\u00020\u00182\u0006\u0010\"\u001a\u00020\u0018H\u0000¢\u0006\u0004\b#\u0010$J\u000f\u0010%\u001a\u00020\u0013H\u0016¢\u0006\u0004\b%\u0010&J\u000f\u0010'\u001a\u00020\u0013H\u0016¢\u0006\u0004\b'\u0010&J\u0017\u0010*\u001a\u00020\u00132\u0006\u0010)\u001a\u00020(H\u0000¢\u0006\u0004\b*\u0010+J\u000f\u0010,\u001a\u00020\u0013H\u0000¢\u0006\u0004\b,\u0010&R\u001a\u00100\u001a\u00020\u00118\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u0014\u0010-\u001a\u0004\b.\u0010/R\"\u00108\u001a\u0002018\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b2\u00103\u001a\u0004\b4\u00105\"\u0004\b6\u00107R\"\u0010<\u001a\u0002018\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b9\u00103\u001a\u0004\b:\u00105\"\u0004\b;\u00107R\u0016\u0010=\u001a\u0002018\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0019\u00103R\u0016\u0010?\u001a\u0002018\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b>\u00103R\u0016\u0010A\u001a\u0002018\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b@\u00103¨\u0006G"}, d2 = {"Lokhttp3/Cache;", "Ljava/io/Closeable;", "Ljava/io/Flushable;", "Lokio/Path;", "directory", StringUtils.EMPTY, "maxSize", "Lokio/FileSystem;", "fileSystem", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", "<init>", "(Lokio/Path;JLokio/FileSystem;Lokhttp3/internal/concurrent/TaskRunner;)V", "(Lokio/FileSystem;Lokio/Path;J)V", "Ljava/io/File;", "(Ljava/io/File;J)V", "Lokhttp3/internal/cache/DiskLruCache$Editor;", "Lokhttp3/internal/cache/DiskLruCache;", "editor", StringUtils.EMPTY, "a", "(Lokhttp3/internal/cache/DiskLruCache$Editor;)V", "Lokhttp3/Request;", "request", "Lokhttp3/Response;", "d", "(Lokhttp3/Request;)Lokhttp3/Response;", "response", "Lokhttp3/internal/cache/CacheRequest;", "o", "(Lokhttp3/Response;)Lokhttp3/internal/cache/CacheRequest;", "q", "(Lokhttp3/Request;)V", "cached", "network", "D", "(Lokhttp3/Response;Lokhttp3/Response;)V", "flush", "()V", "close", "Lokhttp3/internal/cache/CacheStrategy;", "cacheStrategy", "B", "(Lokhttp3/internal/cache/CacheStrategy;)V", "A", "Lokhttp3/internal/cache/DiskLruCache;", "getCache$okhttp", "()Lokhttp3/internal/cache/DiskLruCache;", "cache", StringUtils.EMPTY, "b", "I", "k", "()I", "u", "(I)V", "writeSuccessCount", "c", "j", "r", "writeAbortCount", "networkCount", "e", "hitCount", "f", "requestCount", "g", "RealCacheRequest", "Entry", "CacheResponseBody", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Cache implements Closeable, Flushable {
    public static final Companion g = new Companion(null);
    private final DiskLruCache a;
    private int b;
    private int c;
    private int d;
    private int e;
    private int f;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\r\b\u0002\u0018\u00002\u00020\u0001B'\u0012\n\u0010\u0004\u001a\u00060\u0002R\u00020\u0003\u0012\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0005¢\u0006\u0004\b\b\u0010\tJ\u0011\u0010\u000b\u001a\u0004\u0018\u00010\nH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\u000e\u001a\u00020\rH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0011\u0010\u0012R\u001b\u0010\u0004\u001a\u00060\u0002R\u00020\u00038\u0006¢\u0006\f\n\u0004\b\u0013\u0010\u0014\u001a\u0004\b\u0015\u0010\u0016R\u0016\u0010\u0006\u001a\u0004\u0018\u00010\u00058\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0017\u0010\u0018R\u0016\u0010\u0007\u001a\u0004\u0018\u00010\u00058\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0019\u0010\u0018R\u0014\u0010\u001c\u001a\u00020\u00108\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010\u001b¨\u0006\u001d"}, d2 = {"Lokhttp3/Cache$CacheResponseBody;", "Lokhttp3/ResponseBody;", "Lokhttp3/internal/cache/DiskLruCache$Snapshot;", "Lokhttp3/internal/cache/DiskLruCache;", "snapshot", StringUtils.EMPTY, "contentType", "contentLength", "<init>", "(Lokhttp3/internal/cache/DiskLruCache$Snapshot;Ljava/lang/String;Ljava/lang/String;)V", "Lokhttp3/MediaType;", "u", "()Lokhttp3/MediaType;", StringUtils.EMPTY, "r", "()J", "Lokio/BufferedSource;", "A", "()Lokio/BufferedSource;", "d", "Lokhttp3/internal/cache/DiskLruCache$Snapshot;", "D", "()Lokhttp3/internal/cache/DiskLruCache$Snapshot;", "e", "Ljava/lang/String;", "f", "g", "Lokio/BufferedSource;", "bodySource", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private static final class CacheResponseBody extends ResponseBody {
        private final DiskLruCache.Snapshot d;
        private final String e;
        private final String f;
        private final BufferedSource g;

        public CacheResponseBody(DiskLruCache.Snapshot snapshot, String str, String str2) {
            Intrinsics.checkNotNullParameter(snapshot, ap.a(725670112));
            this.d = snapshot;
            this.e = str;
            this.f = str2;
            this.g = Okio.c(new ForwardingSource(snapshot.k(1)) { // from class: okhttp3.Cache.CacheResponseBody.1
                @Override // okio.ForwardingSource, okio.Source, java.io.Closeable, java.lang.AutoCloseable
                public void close() {
                    this.D().close();
                    super.close();
                }
            });
        }

        @Override // okhttp3.ResponseBody
        public BufferedSource A() {
            return this.g;
        }

        public final DiskLruCache.Snapshot D() {
            return this.d;
        }

        @Override // okhttp3.ResponseBody
        public long r() {
            String str = this.f;
            if (str != null) {
                return _UtilCommonKt.C(str, -1L);
            }
            return -1L;
        }

        @Override // okhttp3.ResponseBody
        public MediaType u() {
            String str = this.e;
            if (str != null) {
                return MediaType.e.b(str);
            }
            return null;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\"\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\f\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0019\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005*\u00020\u0004H\u0002¢\u0006\u0004\b\u0007\u0010\bJ\u001f\u0010\u000b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u0017\u0010\u000f\u001a\u00020\u00062\u0006\u0010\u000e\u001a\u00020\rH\u0007¢\u0006\u0004\b\u000f\u0010\u0010J\u0017\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u0012\u001a\u00020\u0011H\u0000¢\u0006\u0004\b\u0014\u0010\u0015J%\u0010\u001c\u001a\u00020\u001b2\u0006\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0018\u001a\u00020\u00042\u0006\u0010\u001a\u001a\u00020\u0019¢\u0006\u0004\b\u001c\u0010\u001dJ\u0011\u0010\u001e\u001a\u00020\u001b*\u00020\u0016¢\u0006\u0004\b\u001e\u0010\u001fJ\u0011\u0010 \u001a\u00020\u0004*\u00020\u0016¢\u0006\u0004\b \u0010!R\u0014\u0010\"\u001a\u00020\u00138\u0002X\u0082T¢\u0006\u0006\n\u0004\b\"\u0010#R\u0014\u0010$\u001a\u00020\u00138\u0002X\u0082T¢\u0006\u0006\n\u0004\b$\u0010#R\u0014\u0010%\u001a\u00020\u00138\u0002X\u0082T¢\u0006\u0006\n\u0004\b%\u0010#R\u0014\u0010&\u001a\u00020\u00138\u0002X\u0082T¢\u0006\u0006\n\u0004\b&\u0010#¨\u0006'"}, d2 = {"Lokhttp3/Cache$Companion;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/Headers;", StringUtils.EMPTY, StringUtils.EMPTY, "d", "(Lokhttp3/Headers;)Ljava/util/Set;", "requestHeaders", "responseHeaders", "e", "(Lokhttp3/Headers;Lokhttp3/Headers;)Lokhttp3/Headers;", "Lokhttp3/HttpUrl;", "url", "b", "(Lokhttp3/HttpUrl;)Ljava/lang/String;", "Lokio/BufferedSource;", ClimateForcast.SOURCE, StringUtils.EMPTY, "c", "(Lokio/BufferedSource;)I", "Lokhttp3/Response;", "cachedResponse", "cachedRequest", "Lokhttp3/Request;", "newRequest", StringUtils.EMPTY, "g", "(Lokhttp3/Response;Lokhttp3/Headers;Lokhttp3/Request;)Z", "a", "(Lokhttp3/Response;)Z", "f", "(Lokhttp3/Response;)Lokhttp3/Headers;", "VERSION", "I", "ENTRY_METADATA", "ENTRY_BODY", "ENTRY_COUNT", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nCache.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Cache.kt\nokhttp3/Cache$Companion\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,838:1\n2746#2,3:839\n*S KotlinDebug\n*F\n+ 1 Cache.kt\nokhttp3/Cache$Companion\n*L\n777#1:839,3\n*E\n"})
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private final Set d(Headers headers) {
            int size = headers.size();
            TreeSet treeSet = null;
            for (int i = 0; i < size; i++) {
                if (StringsKt.equals(ap.a(553112481), headers.e(i), true)) {
                    String strK = headers.k(i);
                    if (treeSet == null) {
                        treeSet = new TreeSet(StringsKt.getCASE_INSENSITIVE_ORDER(StringCompanionObject.INSTANCE));
                    }
                    Iterator it = StringsKt.split$default((CharSequence) strK, new char[]{AbstractJsonLexerKt.COMMA}, false, 0, 6, (Object) null).iterator();
                    while (it.hasNext()) {
                        treeSet.add(StringsKt.trim((CharSequence) it.next()).toString());
                    }
                }
            }
            return treeSet == null ? SetsKt.emptySet() : treeSet;
        }

        private final Headers e(Headers headers, Headers headers2) {
            Set setD = d(headers2);
            if (setD.isEmpty()) {
                return Headers.c;
            }
            Headers.Builder builder = new Headers.Builder();
            int size = headers.size();
            for (int i = 0; i < size; i++) {
                String strE = headers.e(i);
                if (setD.contains(strE)) {
                    builder.a(strE, headers.k(i));
                }
            }
            return builder.e();
        }

        public final boolean a(Response response) {
            Intrinsics.checkNotNullParameter(response, "<this>");
            return d(response.J()).contains("*");
        }

        public final String b(HttpUrl httpUrl) {
            Intrinsics.checkNotNullParameter(httpUrl, "url");
            return ByteString.d.d(httpUrl.toString()).w().l();
        }

        public final int c(BufferedSource bufferedSource) throws IOException {
            Intrinsics.checkNotNullParameter(bufferedSource, ClimateForcast.SOURCE);
            try {
                long jL2 = bufferedSource.L2();
                String strJ2 = bufferedSource.j2();
                if (jL2 >= 0 && jL2 <= 2147483647L && strJ2.length() <= 0) {
                    return (int) jL2;
                }
                throw new IOException("expected an int but was \"" + jL2 + strJ2 + '\"');
            } catch (NumberFormatException e) {
                throw new IOException(e.getMessage());
            }
        }

        public final Headers f(Response response) {
            Intrinsics.checkNotNullParameter(response, "<this>");
            Response responseP = response.P();
            Intrinsics.checkNotNull(responseP);
            return e(responseP.b0().g(), response.J());
        }

        public final boolean g(Response response, Headers headers, Request request) {
            Intrinsics.checkNotNullParameter(response, "cachedResponse");
            Intrinsics.checkNotNullParameter(headers, "cachedRequest");
            Intrinsics.checkNotNullParameter(request, "newRequest");
            Set<String> setD = d(response.J());
            if ((setD instanceof Collection) && setD.isEmpty()) {
                return true;
            }
            for (String str : setD) {
                if (!Intrinsics.areEqual(headers.l(str), request.f(str))) {
                    return false;
                }
            }
            return true;
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0006\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0013\u0012\n\u0010\u0004\u001a\u00060\u0002R\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\u000f\u0010\b\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\u000b\u0010\fR\u0018\u0010\u0004\u001a\u00060\u0002R\u00020\u00038\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\r\u0010\u000eR\u0014\u0010\u0011\u001a\u00020\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\u0010R\u0014\u0010\u000b\u001a\u00020\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010\u0010R\"\u0010\u0018\u001a\u00020\u00138\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0014\u0010\u0015\u001a\u0004\b\u000f\u0010\u0016\"\u0004\b\u0012\u0010\u0017¨\u0006\u0019"}, d2 = {"Lokhttp3/Cache$RealCacheRequest;", "Lokhttp3/internal/cache/CacheRequest;", "Lokhttp3/internal/cache/DiskLruCache$Editor;", "Lokhttp3/internal/cache/DiskLruCache;", "editor", "<init>", "(Lokhttp3/Cache;Lokhttp3/internal/cache/DiskLruCache$Editor;)V", StringUtils.EMPTY, "abort", "()V", "Lokio/Sink;", "body", "()Lokio/Sink;", "a", "Lokhttp3/internal/cache/DiskLruCache$Editor;", "b", "Lokio/Sink;", "cacheOut", "c", StringUtils.EMPTY, "d", "Z", "()Z", "(Z)V", "done", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private final class RealCacheRequest implements CacheRequest {
        private final DiskLruCache.Editor a;
        private final Sink b;
        private final Sink c;
        private boolean d;
        final /* synthetic */ Cache e;

        public RealCacheRequest(final Cache cache, DiskLruCache.Editor editor) {
            Intrinsics.checkNotNullParameter(editor, ap.a(1611934460));
            this.e = cache;
            this.a = editor;
            Sink sinkG = editor.g(1);
            this.b = sinkG;
            this.c = new ForwardingSink(sinkG) { // from class: okhttp3.Cache.RealCacheRequest.1
                @Override // okio.ForwardingSink, okio.Sink, java.io.Closeable, java.lang.AutoCloseable
                public void close() {
                    Cache cache2 = cache;
                    RealCacheRequest realCacheRequest = this;
                    synchronized (cache2) {
                        if (realCacheRequest.b()) {
                            return;
                        }
                        realCacheRequest.c(true);
                        cache2.u(cache2.k() + 1);
                        super.close();
                        this.a.c();
                    }
                }
            };
        }

        @Override // okhttp3.internal.cache.CacheRequest
        public void abort() {
            Cache cache = this.e;
            synchronized (cache) {
                if (this.d) {
                    return;
                }
                this.d = true;
                cache.r(cache.j() + 1);
                _UtilCommonKt.f(this.b);
                try {
                    this.a.b();
                } catch (IOException unused) {
                }
            }
        }

        public final boolean b() {
            return this.d;
        }

        @Override // okhttp3.internal.cache.CacheRequest
        public Sink body() {
            return this.c;
        }

        public final void c(boolean z) {
            this.d = z;
        }
    }

    public Cache(Path path, long j, FileSystem fileSystem, TaskRunner taskRunner) {
        Intrinsics.checkNotNullParameter(path, "directory");
        Intrinsics.checkNotNullParameter(fileSystem, "fileSystem");
        Intrinsics.checkNotNullParameter(taskRunner, "taskRunner");
        this.a = new DiskLruCache(fileSystem, path, 201105, 2, j, taskRunner);
    }

    private final void a(DiskLruCache.Editor editor) {
        if (editor != null) {
            try {
                editor.b();
            } catch (IOException unused) {
            }
        }
    }

    public final synchronized void A() {
        this.e++;
    }

    public final synchronized void B(CacheStrategy cacheStrategy) {
        try {
            Intrinsics.checkNotNullParameter(cacheStrategy, "cacheStrategy");
            this.f++;
            if (cacheStrategy.b() != null) {
                this.d++;
            } else if (cacheStrategy.a() != null) {
                this.e++;
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public final void D(Response response, Response response2) {
        DiskLruCache.Editor editorJ;
        Intrinsics.checkNotNullParameter(response, "cached");
        Intrinsics.checkNotNullParameter(response2, "network");
        Entry entry = new Entry(response2);
        ResponseBody responseBodyJ = response.j();
        Intrinsics.checkNotNull(responseBodyJ, "null cannot be cast to non-null type okhttp3.Cache.CacheResponseBody");
        try {
            editorJ = ((CacheResponseBody) responseBodyJ).D().j();
            if (editorJ == null) {
                return;
            }
            try {
                entry.e(editorJ);
                editorJ.c();
            } catch (IOException unused) {
                a(editorJ);
            }
        } catch (IOException unused2) {
            editorJ = null;
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.a.close();
    }

    public final Response d(Request request) {
        Intrinsics.checkNotNullParameter(request, "request");
        try {
            DiskLruCache.Snapshot snapshotJ = this.a.J(g.b(request.m()));
            if (snapshotJ == null) {
                return null;
            }
            try {
                Entry entry = new Entry(snapshotJ.k(0));
                Response responseC = entry.c(snapshotJ);
                if (entry.a(request, responseC)) {
                    return responseC;
                }
                _UtilCommonKt.f(responseC.j());
                return null;
            } catch (IOException unused) {
                _UtilCommonKt.f(snapshotJ);
                return null;
            }
        } catch (IOException unused2) {
        }
    }

    @Override // java.io.Flushable
    public void flush() {
        this.a.flush();
    }

    public final int j() {
        return this.c;
    }

    public final int k() {
        return this.b;
    }

    public final CacheRequest o(Response response) {
        DiskLruCache.Editor editorI;
        Intrinsics.checkNotNullParameter(response, "response");
        String strI = response.b0().i();
        if (HttpMethod.a(response.b0().i())) {
            try {
                q(response.b0());
            } catch (IOException unused) {
            }
            return null;
        }
        if (!Intrinsics.areEqual(strI, "GET")) {
            return null;
        }
        Companion companion = g;
        if (companion.a(response)) {
            return null;
        }
        Entry entry = new Entry(response);
        try {
            editorI = DiskLruCache.I(this.a, companion.b(response.b0().m()), 0L, 2, null);
            if (editorI == null) {
                return null;
            }
            try {
                entry.e(editorI);
                return new RealCacheRequest(this, editorI);
            } catch (IOException unused2) {
                a(editorI);
                return null;
            }
        } catch (IOException unused3) {
            editorI = null;
        }
    }

    public final void q(Request request) {
        Intrinsics.checkNotNullParameter(request, "request");
        this.a.m0(g.b(request.m()));
    }

    public final void r(int i) {
        this.c = i;
    }

    public final void u(int i) {
        this.b = i;
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public Cache(FileSystem fileSystem, Path path, long j) {
        this(path, j, fileSystem, TaskRunner.m);
        Intrinsics.checkNotNullParameter(fileSystem, "fileSystem");
        Intrinsics.checkNotNullParameter(path, "directory");
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public Cache(File file, long j) {
        this(FileSystem.b, Path.Companion.d(Path.b, file, false, 1, null), j);
        Intrinsics.checkNotNullParameter(file, ap.a(2047054317));
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0094\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\b\b\u0002\u0018\u0000 @2\u00020\u0001:\u0001AB\u0011\b\u0016\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005B\u0011\b\u0016\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\u0004\u0010\bJ\u001d\u0010\r\u001a\b\u0012\u0004\u0012\u00020\f0\u000b2\u0006\u0010\n\u001a\u00020\tH\u0002¢\u0006\u0004\b\r\u0010\u000eJ%\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u0010\u001a\u00020\u000f2\f\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\f0\u000bH\u0002¢\u0006\u0004\b\u0013\u0010\u0014J\u0019\u0010\u0018\u001a\u00020\u00122\n\u0010\u0017\u001a\u00060\u0015R\u00020\u0016¢\u0006\u0004\b\u0018\u0010\u0019J\u001d\u0010\u001d\u001a\u00020\u001c2\u0006\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\u001d\u0010\u001eJ\u0019\u0010!\u001a\u00020\u00062\n\u0010 \u001a\u00060\u001fR\u00020\u0016¢\u0006\u0004\b!\u0010\"R\u0014\u0010%\u001a\u00020#8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010$R\u0014\u0010(\u001a\u00020&8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\r\u0010'R\u0014\u0010+\u001a\u00020)8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b!\u0010*R\u0014\u0010.\u001a\u00020,8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0013\u0010-R\u0014\u00101\u001a\u00020/8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0018\u00100R\u0014\u00103\u001a\u00020)8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b2\u0010*R\u0014\u00105\u001a\u00020&8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b4\u0010'R\u0016\u00109\u001a\u0004\u0018\u0001068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b7\u00108R\u0014\u0010=\u001a\u00020:8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b;\u0010<R\u0014\u0010?\u001a\u00020:8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b>\u0010<¨\u0006B"}, d2 = {"Lokhttp3/Cache$Entry;", StringUtils.EMPTY, "Lokio/Source;", "rawSource", "<init>", "(Lokio/Source;)V", "Lokhttp3/Response;", "response", "(Lokhttp3/Response;)V", "Lokio/BufferedSource;", ClimateForcast.SOURCE, StringUtils.EMPTY, "Ljava/security/cert/Certificate;", "b", "(Lokio/BufferedSource;)Ljava/util/List;", "Lokio/BufferedSink;", "sink", "certificates", StringUtils.EMPTY, "d", "(Lokio/BufferedSink;Ljava/util/List;)V", "Lokhttp3/internal/cache/DiskLruCache$Editor;", "Lokhttp3/internal/cache/DiskLruCache;", "editor", "e", "(Lokhttp3/internal/cache/DiskLruCache$Editor;)V", "Lokhttp3/Request;", "request", StringUtils.EMPTY, "a", "(Lokhttp3/Request;Lokhttp3/Response;)Z", "Lokhttp3/internal/cache/DiskLruCache$Snapshot;", "snapshot", "c", "(Lokhttp3/internal/cache/DiskLruCache$Snapshot;)Lokhttp3/Response;", "Lokhttp3/HttpUrl;", "Lokhttp3/HttpUrl;", "url", "Lokhttp3/Headers;", "Lokhttp3/Headers;", "varyHeaders", StringUtils.EMPTY, "Ljava/lang/String;", "requestMethod", "Lokhttp3/Protocol;", "Lokhttp3/Protocol;", "protocol", StringUtils.EMPTY, "I", "code", "f", "message", "g", "responseHeaders", "Lokhttp3/Handshake;", "h", "Lokhttp3/Handshake;", "handshake", StringUtils.EMPTY, "i", "J", "sentRequestMillis", "j", "receivedResponseMillis", "k", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private static final class Entry {
        public static final Companion k = new Companion(null);
        private static final String l;
        private static final String m;
        private final HttpUrl a;
        private final Headers b;
        private final String c;
        private final Protocol d;
        private final int e;
        private final String f;
        private final Headers g;
        private final Handshake h;
        private final long i;
        private final long j;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Lokhttp3/Cache$Entry$Companion;", StringUtils.EMPTY, "<init>", "()V", "SENT_MILLIS", StringUtils.EMPTY, "RECEIVED_MILLIS", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class Companion {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            private Companion() {
            }
        }

        static {
            StringBuilder sb = new StringBuilder();
            Platform.Companion companion = Platform.a;
            sb.append(companion.e().j());
            sb.append(ap.a(1755568452));
            l = sb.toString();
            m = companion.e().j() + ap.a(994388076);
        }

        public Entry(Source source) {
            Intrinsics.checkNotNullParameter(source, "rawSource");
            try {
                BufferedSource bufferedSourceC = Okio.c(source);
                String strJ2 = bufferedSourceC.j2();
                HttpUrl httpUrlD = HttpUrl.j.d(strJ2);
                if (httpUrlD == null) {
                    IOException iOException = new IOException("Cache corruption for " + strJ2);
                    Platform.a.e().n("cache corruption", 5, iOException);
                    throw iOException;
                }
                this.a = httpUrlD;
                this.c = bufferedSourceC.j2();
                Headers.Builder builder = new Headers.Builder();
                int iC = Cache.g.c(bufferedSourceC);
                for (int i = 0; i < iC; i++) {
                    builder.b(bufferedSourceC.j2());
                }
                this.b = builder.e();
                StatusLine statusLineA = StatusLine.d.a(bufferedSourceC.j2());
                this.d = statusLineA.a;
                this.e = statusLineA.b;
                this.f = statusLineA.c;
                Headers.Builder builder2 = new Headers.Builder();
                int iC2 = Cache.g.c(bufferedSourceC);
                for (int i2 = 0; i2 < iC2; i2++) {
                    builder2.b(bufferedSourceC.j2());
                }
                String str = l;
                String strF = builder2.f(str);
                String str2 = m;
                String strF2 = builder2.f(str2);
                builder2.h(str);
                builder2.h(str2);
                this.i = strF != null ? Long.parseLong(strF) : 0L;
                this.j = strF2 != null ? Long.parseLong(strF2) : 0L;
                this.g = builder2.e();
                if (this.a.h()) {
                    String strJ22 = bufferedSourceC.j2();
                    if (strJ22.length() > 0) {
                        throw new IOException("expected \"\" but was \"" + strJ22 + '\"');
                    }
                    this.h = Handshake.e.d(!bufferedSourceC.H2() ? TlsVersion.b.a(bufferedSourceC.j2()) : TlsVersion.g, CipherSuite.b.b(bufferedSourceC.j2()), b(bufferedSourceC), b(bufferedSourceC));
                } else {
                    this.h = null;
                }
                Unit unit = Unit.INSTANCE;
                CloseableKt.closeFinally(source, (Throwable) null);
            } catch (Throwable th) {
                try {
                    throw th;
                } catch (Throwable th2) {
                    CloseableKt.closeFinally(source, th);
                    throw th2;
                }
            }
        }

        private final List b(BufferedSource bufferedSource) throws IOException {
            int iC = Cache.g.c(bufferedSource);
            if (iC == -1) {
                return CollectionsKt.emptyList();
            }
            try {
                CertificateFactory certificateFactory = CertificateFactory.getInstance("X.509");
                ArrayList arrayList = new ArrayList(iC);
                for (int i = 0; i < iC; i++) {
                    String strJ2 = bufferedSource.j2();
                    Buffer buffer = new Buffer();
                    ByteString byteStringA = ByteString.d.a(strJ2);
                    if (byteStringA == null) {
                        throw new IOException("Corrupt certificate in cache entry");
                    }
                    buffer.l1(byteStringA);
                    arrayList.add(certificateFactory.generateCertificate(buffer.inputStream()));
                }
                return arrayList;
            } catch (CertificateException e) {
                throw new IOException(e.getMessage());
            }
        }

        private final void d(BufferedSink bufferedSink, List list) throws IOException {
            try {
                bufferedSink.A0(list.size()).writeByte(10);
                Iterator it = list.iterator();
                while (it.hasNext()) {
                    byte[] encoded = ((Certificate) it.next()).getEncoded();
                    ByteString.Companion companion = ByteString.d;
                    Intrinsics.checkNotNull(encoded);
                    bufferedSink.V1(ByteString.Companion.g(companion, encoded, 0, 0, 3, null).a()).writeByte(10);
                }
            } catch (CertificateEncodingException e) {
                throw new IOException(e.getMessage());
            }
        }

        public final boolean a(Request request, Response response) {
            Intrinsics.checkNotNullParameter(request, "request");
            Intrinsics.checkNotNullParameter(response, "response");
            return Intrinsics.areEqual(this.a, request.m()) && Intrinsics.areEqual(this.c, request.i()) && Cache.g.g(response, this.b, request);
        }

        public final Response c(DiskLruCache.Snapshot snapshot) {
            Intrinsics.checkNotNullParameter(snapshot, "snapshot");
            String strA = this.g.a(HttpHeaders.CONTENT_TYPE);
            String strA2 = this.g.a(HttpHeaders.CONTENT_LENGTH);
            return new Response.Builder().q(new Request(this.a, this.b, this.c, null, 8, null)).o(this.d).f(this.e).l(this.f).j(this.g).b(new CacheResponseBody(snapshot, strA, strA2)).h(this.h).r(this.i).p(this.j).c();
        }

        public final void e(DiskLruCache.Editor editor) {
            Intrinsics.checkNotNullParameter(editor, "editor");
            BufferedSink bufferedSinkB = Okio.b(editor.g(0));
            try {
                bufferedSinkB.V1(this.a.toString()).writeByte(10);
                bufferedSinkB.V1(this.c).writeByte(10);
                bufferedSinkB.A0(this.b.size()).writeByte(10);
                int size = this.b.size();
                for (int i = 0; i < size; i++) {
                    bufferedSinkB.V1(this.b.e(i)).V1(": ").V1(this.b.k(i)).writeByte(10);
                }
                bufferedSinkB.V1(new StatusLine(this.d, this.e, this.f).toString()).writeByte(10);
                bufferedSinkB.A0(this.g.size() + 2).writeByte(10);
                int size2 = this.g.size();
                for (int i2 = 0; i2 < size2; i2++) {
                    bufferedSinkB.V1(this.g.e(i2)).V1(": ").V1(this.g.k(i2)).writeByte(10);
                }
                bufferedSinkB.V1(l).V1(": ").A0(this.i).writeByte(10);
                bufferedSinkB.V1(m).V1(": ").A0(this.j).writeByte(10);
                if (this.a.h()) {
                    bufferedSinkB.writeByte(10);
                    Handshake handshake = this.h;
                    Intrinsics.checkNotNull(handshake);
                    bufferedSinkB.V1(handshake.b().c()).writeByte(10);
                    d(bufferedSinkB, this.h.e());
                    d(bufferedSinkB, this.h.d());
                    bufferedSinkB.V1(this.h.g().b()).writeByte(10);
                }
                Unit unit = Unit.INSTANCE;
                CloseableKt.closeFinally(bufferedSinkB, (Throwable) null);
            } finally {
            }
        }

        public Entry(Response response) {
            Intrinsics.checkNotNullParameter(response, "response");
            this.a = response.b0().m();
            this.b = Cache.g.f(response);
            this.c = response.b0().i();
            this.d = response.X();
            this.e = response.r();
            this.f = response.O();
            this.g = response.J();
            this.h = response.A();
            this.i = response.d0();
            this.j = response.a0();
        }
    }
}