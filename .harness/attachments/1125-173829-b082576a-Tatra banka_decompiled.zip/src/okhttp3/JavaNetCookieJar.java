package okhttp3;

import android.util.Log;
import h.ap;
import java.io.IOException;
import java.net.CookieHandler;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import okhttp3.Cookie;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal.platform.Platform;
import org.apache.tika.utils.StringUtils;
import sk.tb.ib.tatraandroid.temp.HelloRequestHistoryService;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class JavaNetCookieJar implements CookieJar {
    private final CookieHandler c;

    public JavaNetCookieJar(CookieHandler cookieHandler) {
        this.c = cookieHandler;
    }

    private List c(HttpUrl httpUrl, String str) {
        ArrayList arrayList = new ArrayList();
        int length = str.length();
        int i = 0;
        while (i < length) {
            int iK = _UtilCommonKt.k(str, ap.a(1938977786), i, length);
            int iJ = _UtilCommonKt.j(str, '=', i, iK);
            String strE = _UtilCommonKt.E(str, i, iJ);
            if (!strE.startsWith(ap.a(922000672))) {
                String strE2 = iJ < iK ? _UtilCommonKt.E(str, iJ + 1, iK) : ap.a(1211133691);
                String strA = ap.a(1292673573);
                if (strE2.startsWith(strA) && strE2.endsWith(strA)) {
                    strE2 = strE2.substring(1, strE2.length() - 1);
                }
                arrayList.add(new Cookie.Builder().d(strE).e(strE2).b(httpUrl.g()).a());
            }
            i = iK + 1;
        }
        return arrayList;
    }

    @Override // okhttp3.CookieJar
    public List a(HttpUrl httpUrl) {
        try {
            ArrayList arrayList = null;
            for (Map.Entry<String, List<String>> entry : this.c.get(httpUrl.t(), Collections.EMPTY_MAP).entrySet()) {
                String key = entry.getKey();
                if ("Cookie".equalsIgnoreCase(key) || "Cookie2".equalsIgnoreCase(key)) {
                    if (!entry.getValue().isEmpty()) {
                        Log.d("loadRequest entry", entry.getValue() + StringUtils.EMPTY);
                        for (String str : entry.getValue()) {
                            if (arrayList == null) {
                                arrayList = new ArrayList();
                            }
                            arrayList.addAll(c(httpUrl, str));
                        }
                    }
                }
            }
            if (arrayList == null) {
                HelloRequestHistoryService.a.c(httpUrl.toString(), 2);
            } else if (arrayList.isEmpty()) {
                HelloRequestHistoryService.a.c(httpUrl.toString(), 3);
            }
            return arrayList != null ? Collections.unmodifiableList(arrayList) : Collections.EMPTY_LIST;
        } catch (IOException e) {
            Platform.i().n("Loading cookies failed for " + httpUrl.r("/..."), 5, e);
            HelloRequestHistoryService.a.c(httpUrl.toString(), 1);
            return Collections.EMPTY_LIST;
        }
    }

    @Override // okhttp3.CookieJar
    public void b(HttpUrl httpUrl, List list) {
        if (this.c != null) {
            ArrayList arrayList = new ArrayList();
            Iterator it = list.iterator();
            while (it.hasNext()) {
                arrayList.add(((Cookie) it.next()).toString());
            }
            try {
                this.c.put(httpUrl.t(), Collections.singletonMap("Set-Cookie", arrayList));
            } catch (IOException e) {
                Platform.i().n("Saving cookies failed for " + httpUrl.r("/..."), 5, e);
            }
        }
    }
}