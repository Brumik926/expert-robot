package okhttp3;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.time.Duration;
import okhttp3.internal._CacheControlCommonKt;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0010\u000e\n\u0002\b\u001c\u0018\u0000 (2\u00020\u0001:\u0002*+Bs\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0002\u0012\u0006\u0010\t\u001a\u00020\u0002\u0012\u0006\u0010\n\u001a\u00020\u0002\u0012\u0006\u0010\u000b\u001a\u00020\u0005\u0012\u0006\u0010\f\u001a\u00020\u0005\u0012\u0006\u0010\r\u001a\u00020\u0002\u0012\u0006\u0010\u000e\u001a\u00020\u0002\u0012\u0006\u0010\u000f\u001a\u00020\u0002\u0012\b\u0010\u0011\u001a\u0004\u0018\u00010\u0010¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0014\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0014\u0010\u0015R\u0017\u0010\u0003\u001a\u00020\u00028G¢\u0006\f\n\u0004\b\u0016\u0010\u0017\u001a\u0004\b\u0018\u0010\u0019R\u0017\u0010\u0004\u001a\u00020\u00028G¢\u0006\f\n\u0004\b\u001a\u0010\u0017\u001a\u0004\b\u001b\u0010\u0019R\u0017\u0010\u0006\u001a\u00020\u00058G¢\u0006\f\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001e\u0010\u001fR\u0017\u0010\u0007\u001a\u00020\u00058G¢\u0006\f\n\u0004\b \u0010\u001d\u001a\u0004\b!\u0010\u001fR\u0017\u0010\b\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u001e\u0010\u0017\u001a\u0004\b\u001c\u0010\u0019R\u0017\u0010\t\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\"\u0010\u0017\u001a\u0004\b \u0010\u0019R\u0017\u0010\n\u001a\u00020\u00028G¢\u0006\f\n\u0004\b#\u0010\u0017\u001a\u0004\b$\u0010\u0019R\u0017\u0010\u000b\u001a\u00020\u00058G¢\u0006\f\n\u0004\b$\u0010\u001d\u001a\u0004\b\"\u0010\u001fR\u0017\u0010\f\u001a\u00020\u00058G¢\u0006\f\n\u0004\b\u0018\u0010\u001d\u001a\u0004\b#\u0010\u001fR\u0017\u0010\r\u001a\u00020\u00028G¢\u0006\f\n\u0004\b\u001b\u0010\u0017\u001a\u0004\b%\u0010\u0019R\u0017\u0010\u000e\u001a\u00020\u00028G¢\u0006\f\n\u0004\b&\u0010\u0017\u001a\u0004\b&\u0010\u0019R\u0017\u0010\u000f\u001a\u00020\u00028G¢\u0006\f\n\u0004\b%\u0010\u0017\u001a\u0004\b\u001a\u0010\u0019R$\u0010\u0011\u001a\u0004\u0018\u00010\u00108\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b!\u0010'\u001a\u0004\b\u0016\u0010\u0015\"\u0004\b(\u0010)¨\u0006,"}, d2 = {"Lokhttp3/CacheControl;", StringUtils.EMPTY, StringUtils.EMPTY, "noCache", "noStore", StringUtils.EMPTY, "maxAgeSeconds", "sMaxAgeSeconds", "isPrivate", "isPublic", "mustRevalidate", "maxStaleSeconds", "minFreshSeconds", "onlyIfCached", "noTransform", "immutable", StringUtils.EMPTY, "headerValue", "<init>", "(ZZIIZZZIIZZZLjava/lang/String;)V", "toString", "()Ljava/lang/String;", "a", "Z", "i", "()Z", "b", "j", "c", "I", "e", "()I", "d", "m", "f", "g", "h", "l", "k", "Ljava/lang/String;", "n", "(Ljava/lang/String;)V", "Builder", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class CacheControl {
    public static final Companion n;
    public static final CacheControl o;
    public static final CacheControl p;
    private final boolean a;
    private final boolean b;
    private final int c;
    private final int d;
    private final boolean e;
    private final boolean f;
    private final boolean g;
    private final int h;
    private final int i;
    private final boolean j;
    private final boolean k;
    private final boolean l;
    private String m;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0010\b\n\u0002\b\u0015\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\r\u0010\u0004\u001a\u00020\u0000¢\u0006\u0004\b\u0004\u0010\u0005J\r\u0010\u0006\u001a\u00020\u0000¢\u0006\u0004\b\u0006\u0010\u0005J\r\u0010\u0007\u001a\u00020\u0000¢\u0006\u0004\b\u0007\u0010\u0005J\u0015\u0010\n\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\b¢\u0006\u0004\b\n\u0010\u000bJ\r\u0010\r\u001a\u00020\f¢\u0006\u0004\b\r\u0010\u000eR\"\u0010\u0015\u001a\u00020\u000f8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\r\u0010\u0010\u001a\u0004\b\u0011\u0010\u0012\"\u0004\b\u0013\u0010\u0014R\"\u0010\u0019\u001a\u00020\u000f8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0016\u0010\u0010\u001a\u0004\b\u0017\u0010\u0012\"\u0004\b\u0018\u0010\u0014R\"\u0010 \u001a\u00020\u001a8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u001b\u0010\u001d\"\u0004\b\u001e\u0010\u001fR\"\u0010#\u001a\u00020\u001a8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b!\u0010\u001c\u001a\u0004\b!\u0010\u001d\"\u0004\b\"\u0010\u001fR\"\u0010&\u001a\u00020\u001a8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b$\u0010\u001c\u001a\u0004\b$\u0010\u001d\"\u0004\b%\u0010\u001fR\"\u0010)\u001a\u00020\u000f8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0011\u0010\u0010\u001a\u0004\b'\u0010\u0012\"\u0004\b(\u0010\u0014R\"\u0010,\u001a\u00020\u000f8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0017\u0010\u0010\u001a\u0004\b*\u0010\u0012\"\u0004\b+\u0010\u0014R\"\u0010.\u001a\u00020\u000f8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b*\u0010\u0010\u001a\u0004\b\u0016\u0010\u0012\"\u0004\b-\u0010\u0014¨\u0006/"}, d2 = {"Lokhttp3/CacheControl$Builder;", StringUtils.EMPTY, "<init>", "()V", "k", "()Lokhttp3/CacheControl$Builder;", "l", "m", "Lkotlin/time/Duration;", "maxStale", "j", "(J)Lokhttp3/CacheControl$Builder;", "Lokhttp3/CacheControl;", "a", "()Lokhttp3/CacheControl;", StringUtils.EMPTY, "Z", "f", "()Z", "n", "(Z)V", "noCache", "b", "g", "o", "noStore", StringUtils.EMPTY, "c", "I", "()I", "setMaxAgeSeconds$okhttp", "(I)V", "maxAgeSeconds", "d", "setMaxStaleSeconds$okhttp", "maxStaleSeconds", "e", "setMinFreshSeconds$okhttp", "minFreshSeconds", "i", "p", "onlyIfCached", "h", "setNoTransform$okhttp", "noTransform", "setImmutable$okhttp", "immutable", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nCacheControl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 CacheControl.kt\nokhttp3/CacheControl$Builder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,286:1\n1#2:287\n*E\n"})
    public static final class Builder {
        private boolean a;
        private boolean b;
        private int c = -1;
        private int d = -1;
        private int e = -1;
        private boolean f;
        private boolean g;
        private boolean h;

        public final CacheControl a() {
            return _CacheControlCommonKt.a(this);
        }

        public final boolean b() {
            return this.h;
        }

        public final int c() {
            return this.c;
        }

        public final int d() {
            return this.d;
        }

        public final int e() {
            return this.e;
        }

        public final boolean f() {
            return this.a;
        }

        public final boolean g() {
            return this.b;
        }

        public final boolean h() {
            return this.g;
        }

        public final boolean i() {
            return this.f;
        }

        public final Builder j(long j) {
            long jM291getInWholeSecondsimpl = Duration.m291getInWholeSecondsimpl(j);
            if (jM291getInWholeSecondsimpl >= 0) {
                this.d = _CacheControlCommonKt.b(jM291getInWholeSecondsimpl);
                return this;
            }
            throw new IllegalArgumentException((ap.a(1884068797) + jM291getInWholeSecondsimpl).toString());
        }

        public final Builder k() {
            return _CacheControlCommonKt.e(this);
        }

        public final Builder l() {
            return _CacheControlCommonKt.f(this);
        }

        public final Builder m() {
            return _CacheControlCommonKt.g(this);
        }

        public final void n(boolean z) {
            this.a = z;
        }

        public final void o(boolean z) {
            this.b = z;
        }

        public final void p(boolean z) {
            this.f = z;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\u0007\u0010\bR\u0014\u0010\t\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\t\u0010\nR\u0014\u0010\u000b\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u000b\u0010\n¨\u0006\f"}, d2 = {"Lokhttp3/CacheControl$Companion;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/Headers;", "headers", "Lokhttp3/CacheControl;", "a", "(Lokhttp3/Headers;)Lokhttp3/CacheControl;", "FORCE_NETWORK", "Lokhttp3/CacheControl;", "FORCE_CACHE", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final CacheControl a(Headers headers) {
            Intrinsics.checkNotNullParameter(headers, ap.a(1481892746));
            return _CacheControlCommonKt.h(this, headers);
        }

        private Companion() {
        }
    }

    static {
        Companion companion = new Companion(null);
        n = companion;
        o = _CacheControlCommonKt.d(companion);
        p = _CacheControlCommonKt.c(companion);
    }

    public CacheControl(boolean z, boolean z2, int i, int i2, boolean z3, boolean z4, boolean z5, int i3, int i4, boolean z6, boolean z7, boolean z8, String str) {
        this.a = z;
        this.b = z2;
        this.c = i;
        this.d = i2;
        this.e = z3;
        this.f = z4;
        this.g = z5;
        this.h = i3;
        this.i = i4;
        this.j = z6;
        this.k = z7;
        this.l = z8;
        this.m = str;
    }

    public final String a() {
        return this.m;
    }

    public final boolean b() {
        return this.l;
    }

    public final boolean c() {
        return this.e;
    }

    public final boolean d() {
        return this.f;
    }

    public final int e() {
        return this.c;
    }

    public final int f() {
        return this.h;
    }

    public final int g() {
        return this.i;
    }

    public final boolean h() {
        return this.g;
    }

    public final boolean i() {
        return this.a;
    }

    public final boolean j() {
        return this.b;
    }

    public final boolean k() {
        return this.k;
    }

    public final boolean l() {
        return this.j;
    }

    public final int m() {
        return this.d;
    }

    public final void n(String str) {
        this.m = str;
    }

    public String toString() {
        return _CacheControlCommonKt.i(this);
    }
}