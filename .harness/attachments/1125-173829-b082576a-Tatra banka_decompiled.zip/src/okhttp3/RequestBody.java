package okhttp3;

import h.ap;
import java.nio.charset.Charset;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal.Internal;
import okhttp3.internal._UtilCommonKt;
import okio.BufferedSink;
import okio.ByteString;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0005\b&\u0018\u0000 \b2\u00020\u0001:\u0001\u0013B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0011\u0010\u0005\u001a\u0004\u0018\u00010\u0004H&¢\u0006\u0004\b\u0005\u0010\u0006J\u000f\u0010\b\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\b\u0010\tJ\u0017\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\nH&¢\u0006\u0004\b\r\u0010\u000eJ\u000f\u0010\u0010\u001a\u00020\u000fH\u0016¢\u0006\u0004\b\u0010\u0010\u0011J\u000f\u0010\u0012\u001a\u00020\u000fH\u0016¢\u0006\u0004\b\u0012\u0010\u0011¨\u0006\u0014"}, d2 = {"Lokhttp3/RequestBody;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/MediaType;", "b", "()Lokhttp3/MediaType;", StringUtils.EMPTY, "a", "()J", "Lokio/BufferedSink;", "sink", StringUtils.EMPTY, "h", "(Lokio/BufferedSink;)V", StringUtils.EMPTY, "f", "()Z", "g", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public abstract class RequestBody {
    public static final Companion a;
    public static final RequestBody b;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0002\u0010\b\n\u0002\b\f\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001f\u0010\b\u001a\u00020\u0007*\u00020\u00042\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\u0007¢\u0006\u0004\b\b\u0010\tJ\u001f\u0010\u000b\u001a\u00020\u0007*\u00020\n2\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\u0007¢\u0006\u0004\b\u000b\u0010\fJ3\u0010\u0011\u001a\u00020\u0007*\u00020\r2\n\b\u0002\u0010\u0006\u001a\u0004\u0018\u00010\u00052\b\b\u0002\u0010\u000f\u001a\u00020\u000e2\b\b\u0002\u0010\u0010\u001a\u00020\u000eH\u0007¢\u0006\u0004\b\u0011\u0010\u0012J!\u0010\u0014\u001a\u00020\u00072\b\u0010\u0006\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0013\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\u0014\u0010\u0015J5\u0010\u0016\u001a\u00020\u00072\b\u0010\u0006\u001a\u0004\u0018\u00010\u00052\u0006\u0010\u0013\u001a\u00020\r2\b\b\u0002\u0010\u000f\u001a\u00020\u000e2\b\b\u0002\u0010\u0010\u001a\u00020\u000eH\u0007¢\u0006\u0004\b\u0016\u0010\u0017R\u0014\u0010\u0018\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0018\u0010\u0019¨\u0006\u001a"}, d2 = {"Lokhttp3/RequestBody$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "Lokhttp3/MediaType;", "contentType", "Lokhttp3/RequestBody;", "a", "(Ljava/lang/String;Lokhttp3/MediaType;)Lokhttp3/RequestBody;", "Lokio/ByteString;", "e", "(Lokio/ByteString;Lokhttp3/MediaType;)Lokhttp3/RequestBody;", StringUtils.EMPTY, StringUtils.EMPTY, MimeTypesReaderMetKeys.MATCH_OFFSET_ATTR, "byteCount", "g", "([BLokhttp3/MediaType;II)Lokhttp3/RequestBody;", "content", "b", "(Lokhttp3/MediaType;Ljava/lang/String;)Lokhttp3/RequestBody;", "d", "(Lokhttp3/MediaType;[BII)Lokhttp3/RequestBody;", "EMPTY", "Lokhttp3/RequestBody;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public static /* synthetic */ RequestBody h(Companion companion, String str, MediaType mediaType, int i, Object obj) {
            if ((i & 1) != 0) {
                mediaType = null;
            }
            return companion.a(str, mediaType);
        }

        public static /* synthetic */ RequestBody i(Companion companion, MediaType mediaType, byte[] bArr, int i, int i2, int i3, Object obj) {
            if ((i3 & 4) != 0) {
                i = 0;
            }
            if ((i3 & 8) != 0) {
                i2 = bArr.length;
            }
            return companion.d(mediaType, bArr, i, i2);
        }

        public static /* synthetic */ RequestBody j(Companion companion, ByteString byteString, MediaType mediaType, int i, Object obj) {
            if ((i & 1) != 0) {
                mediaType = null;
            }
            return companion.e(byteString, mediaType);
        }

        public static /* synthetic */ RequestBody k(Companion companion, byte[] bArr, MediaType mediaType, int i, int i2, int i3, Object obj) {
            if ((i3 & 1) != 0) {
                mediaType = null;
            }
            if ((i3 & 2) != 0) {
                i = 0;
            }
            if ((i3 & 4) != 0) {
                i2 = bArr.length;
            }
            return companion.g(bArr, mediaType, i, i2);
        }

        public final RequestBody a(String str, MediaType mediaType) {
            Intrinsics.checkNotNullParameter(str, ap.a(1247892668));
            Pair pairB = Internal.b(mediaType);
            Charset charset = (Charset) pairB.component1();
            MediaType mediaType2 = (MediaType) pairB.component2();
            byte[] bytes = str.getBytes(charset);
            Intrinsics.checkNotNullExpressionValue(bytes, ap.a(1211133502));
            return g(bytes, mediaType2, 0, bytes.length);
        }

        public final RequestBody b(MediaType mediaType, String str) {
            Intrinsics.checkNotNullParameter(str, "content");
            return a(str, mediaType);
        }

        public final RequestBody c(MediaType mediaType, byte[] bArr) {
            Intrinsics.checkNotNullParameter(bArr, "content");
            return i(this, mediaType, bArr, 0, 0, 12, null);
        }

        public final RequestBody d(MediaType mediaType, byte[] bArr, int i, int i2) {
            Intrinsics.checkNotNullParameter(bArr, "content");
            return g(bArr, mediaType, i, i2);
        }

        public final RequestBody e(final ByteString byteString, final MediaType mediaType) {
            Intrinsics.checkNotNullParameter(byteString, "<this>");
            return new RequestBody() { // from class: okhttp3.RequestBody$Companion$toRequestBody$1
                @Override // okhttp3.RequestBody
                public long a() {
                    return byteString.size();
                }

                @Override // okhttp3.RequestBody
                public MediaType b() {
                    return mediaType;
                }

                @Override // okhttp3.RequestBody
                public void h(BufferedSink bufferedSink) {
                    Intrinsics.checkNotNullParameter(bufferedSink, ap.a(502961278));
                    bufferedSink.l1(byteString);
                }
            };
        }

        public final RequestBody f(byte[] bArr, MediaType mediaType) {
            Intrinsics.checkNotNullParameter(bArr, "<this>");
            return k(this, bArr, mediaType, 0, 0, 6, null);
        }

        public final RequestBody g(final byte[] bArr, final MediaType mediaType, final int i, final int i2) {
            Intrinsics.checkNotNullParameter(bArr, "<this>");
            _UtilCommonKt.e(bArr.length, i, i2);
            return new RequestBody() { // from class: okhttp3.RequestBody$Companion$toRequestBody$3
                @Override // okhttp3.RequestBody
                public long a() {
                    return i2;
                }

                @Override // okhttp3.RequestBody
                public MediaType b() {
                    return mediaType;
                }

                @Override // okhttp3.RequestBody
                public void h(BufferedSink bufferedSink) {
                    Intrinsics.checkNotNullParameter(bufferedSink, ap.a(562001772));
                    bufferedSink.write(bArr, i, i2);
                }
            };
        }

        private Companion() {
        }
    }

    static {
        Companion companion = new Companion(null);
        a = companion;
        b = Companion.j(companion, ByteString.e, null, 1, null);
    }

    public static final RequestBody c(String str, MediaType mediaType) {
        return a.a(str, mediaType);
    }

    public static final RequestBody d(MediaType mediaType, byte[] bArr) {
        return a.c(mediaType, bArr);
    }

    public static final RequestBody e(byte[] bArr, MediaType mediaType) {
        return a.f(bArr, mediaType);
    }

    public long a() {
        return -1L;
    }

    public abstract MediaType b();

    public boolean f() {
        return false;
    }

    public boolean g() {
        return false;
    }

    public abstract void h(BufferedSink bufferedSink);
}