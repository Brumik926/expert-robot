package okhttp3.internal.http;

import h.ap;
import java.net.ProtocolException;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.Protocol;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u000e\u0018\u0000 \u00122\u00020\u0001:\u0001\u0013B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\n\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\n\u0010\u000bR\u0014\u0010\u0003\u001a\u00020\u00028\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\f\u0010\rR\u0014\u0010\u0005\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u000e\u0010\u000fR\u0014\u0010\u0007\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0010\u0010\u0011¨\u0006\u0014"}, d2 = {"Lokhttp3/internal/http/StatusLine;", StringUtils.EMPTY, "Lokhttp3/Protocol;", "protocol", StringUtils.EMPTY, "code", StringUtils.EMPTY, "message", "<init>", "(Lokhttp3/Protocol;ILjava/lang/String;)V", "toString", "()Ljava/lang/String;", "a", "Lokhttp3/Protocol;", "b", "I", "c", "Ljava/lang/String;", "d", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class StatusLine {
    public static final Companion d = new Companion(null);
    public final Protocol a;
    public final int b;
    public final String c;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0015\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lokhttp3/internal/http/StatusLine$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "statusLine", "Lokhttp3/internal/http/StatusLine;", "a", "(Ljava/lang/String;)Lokhttp3/internal/http/StatusLine;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final StatusLine a(String str) throws ProtocolException {
            Protocol protocol;
            int i;
            String strA;
            Intrinsics.checkNotNullParameter(str, ap.a(57122266));
            boolean zStartsWith$default = StringsKt.startsWith$default(str, ap.a(1748613392), false, 2, (Object) null);
            String strA2 = ap.a(125492206);
            if (zStartsWith$default) {
                i = 9;
                if (str.length() < 9 || str.charAt(8) != ' ') {
                    throw new ProtocolException(strA2 + str);
                }
                int iCharAt = str.charAt(7) - '0';
                if (iCharAt == 0) {
                    protocol = Protocol.c;
                } else {
                    if (iCharAt != 1) {
                        throw new ProtocolException(strA2 + str);
                    }
                    protocol = Protocol.d;
                }
            } else if (StringsKt.startsWith$default(str, ap.a(807220505), false, 2, (Object) null)) {
                protocol = Protocol.c;
                i = 4;
            } else {
                if (!StringsKt.startsWith$default(str, ap.a(2042119661), false, 2, (Object) null)) {
                    throw new ProtocolException(strA2 + str);
                }
                protocol = Protocol.d;
                i = 12;
            }
            int i2 = i + 3;
            if (str.length() < i2) {
                throw new ProtocolException(strA2 + str);
            }
            String strSubstring = str.substring(i, i2);
            String strA3 = ap.a(835451841);
            Intrinsics.checkNotNullExpressionValue(strSubstring, strA3);
            Integer intOrNull = StringsKt.toIntOrNull(strSubstring);
            if (intOrNull == null) {
                throw new ProtocolException(strA2 + str);
            }
            int iIntValue = intOrNull.intValue();
            if (str.length() <= i2) {
                strA = ap.a(1445220159);
            } else {
                if (str.charAt(i2) != ' ') {
                    throw new ProtocolException(strA2 + str);
                }
                strA = str.substring(i + 4);
                Intrinsics.checkNotNullExpressionValue(strA, strA3);
            }
            return new StatusLine(protocol, iIntValue, strA);
        }

        private Companion() {
        }
    }

    public StatusLine(Protocol protocol, int i, String str) {
        Intrinsics.checkNotNullParameter(protocol, ap.a(627563181));
        Intrinsics.checkNotNullParameter(str, ap.a(1700149932));
        this.a = protocol;
        this.b = i;
        this.c = str;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        if (this.a == Protocol.c) {
            sb.append("HTTP/1.0");
        } else {
            sb.append("HTTP/1.1");
        }
        sb.append(' ');
        sb.append(this.b);
        sb.append(' ');
        sb.append(this.c);
        return sb.toString();
    }
}