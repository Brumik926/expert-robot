package okhttp3.internal.http;

import h.ap;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.SocketTimeoutException;
import java.security.cert.CertificateException;
import javax.net.ssl.SSLHandshakeException;
import javax.net.ssl.SSLPeerUnverifiedException;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Regex;
import okhttp3.HttpUrl;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.Route;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.connection.Exchange;
import okhttp3.internal.connection.RealCall;
import okhttp3.internal.connection.RealConnection;
import okhttp3.internal.http2.ConnectionShutdownException;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 &2\u00020\u0001:\u0001'B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J'\u0010\r\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\nH\u0002¢\u0006\u0004\b\r\u0010\u000eJ\u001f\u0010\u000f\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\nH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u001f\u0010\u0007\u001a\u00020\f2\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\fH\u0002¢\u0006\u0004\b\u0007\u0010\u0012J#\u0010\u0017\u001a\u0004\u0018\u00010\n2\u0006\u0010\u0014\u001a\u00020\u00132\b\u0010\u0016\u001a\u0004\u0018\u00010\u0015H\u0002¢\u0006\u0004\b\u0017\u0010\u0018J!\u0010\u001b\u001a\u0004\u0018\u00010\n2\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u001a\u001a\u00020\u0019H\u0002¢\u0006\u0004\b\u001b\u0010\u001cJ\u001f\u0010\u001f\u001a\u00020\u001d2\u0006\u0010\u0014\u001a\u00020\u00132\u0006\u0010\u001e\u001a\u00020\u001dH\u0002¢\u0006\u0004\b\u001f\u0010 J\u0017\u0010#\u001a\u00020\u00132\u0006\u0010\"\u001a\u00020!H\u0016¢\u0006\u0004\b#\u0010$R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b#\u0010%¨\u0006("}, d2 = {"Lokhttp3/internal/http/RetryAndFollowUpInterceptor;", "Lokhttp3/Interceptor;", "Lokhttp3/OkHttpClient;", "client", "<init>", "(Lokhttp3/OkHttpClient;)V", "Ljava/io/IOException;", "e", "Lokhttp3/internal/connection/RealCall;", "call", "Lokhttp3/Request;", "userRequest", StringUtils.EMPTY, "f", "(Ljava/io/IOException;Lokhttp3/internal/connection/RealCall;Lokhttp3/Request;)Z", "g", "(Ljava/io/IOException;Lokhttp3/Request;)Z", "requestSendStarted", "(Ljava/io/IOException;Z)Z", "Lokhttp3/Response;", "userResponse", "Lokhttp3/internal/connection/Exchange;", "exchange", "d", "(Lokhttp3/Response;Lokhttp3/internal/connection/Exchange;)Lokhttp3/Request;", StringUtils.EMPTY, "method", "c", "(Lokhttp3/Response;Ljava/lang/String;)Lokhttp3/Request;", StringUtils.EMPTY, "defaultDelay", "h", "(Lokhttp3/Response;I)I", "Lokhttp3/Interceptor$Chain;", "chain", "a", "(Lokhttp3/Interceptor$Chain;)Lokhttp3/Response;", "Lokhttp3/OkHttpClient;", "b", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class RetryAndFollowUpInterceptor implements Interceptor {
    public static final Companion b = new Companion(null);
    private final OkHttpClient a;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Lokhttp3/internal/http/RetryAndFollowUpInterceptor$Companion;", StringUtils.EMPTY, "<init>", "()V", "MAX_FOLLOW_UPS", StringUtils.EMPTY, "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    public RetryAndFollowUpInterceptor(OkHttpClient okHttpClient) {
        Intrinsics.checkNotNullParameter(okHttpClient, ap.a(2092394028));
        this.a = okHttpClient;
    }

    private final Request c(Response response, String str) {
        String strD;
        HttpUrl httpUrlR;
        if (!this.a.t() || (strD = Response.D(response, org.apache.tika.metadata.HttpHeaders.LOCATION, null, 2, null)) == null || (httpUrlR = response.b0().m().r(strD)) == null) {
            return null;
        }
        if (!Intrinsics.areEqual(httpUrlR.s(), response.b0().m().s()) && !this.a.u()) {
            return null;
        }
        Request.Builder builderJ = response.b0().j();
        if (HttpMethod.b(str)) {
            int iR = response.r();
            HttpMethod httpMethod = HttpMethod.a;
            boolean z = httpMethod.d(str) || iR == 308 || iR == 307;
            if (!httpMethod.c(str) || iR == 308 || iR == 307) {
                builderJ.p(str, z ? response.b0().a() : null);
            } else {
                builderJ.p("GET", null);
            }
            if (!z) {
                builderJ.s("Transfer-Encoding");
                builderJ.s(org.apache.tika.metadata.HttpHeaders.CONTENT_LENGTH);
                builderJ.s(org.apache.tika.metadata.HttpHeaders.CONTENT_TYPE);
            }
        }
        if (!_UtilJvmKt.f(response.b0().m(), httpUrlR)) {
            builderJ.s("Authorization");
        }
        return builderJ.x(httpUrlR).b();
    }

    private final Request d(Response response, Exchange exchange) throws ProtocolException {
        RealConnection realConnectionJ;
        Route routeW = (exchange == null || (realConnectionJ = exchange.j()) == null) ? null : realConnectionJ.w();
        int iR = response.r();
        String strI = response.b0().i();
        if (iR != 307 && iR != 308) {
            if (iR == 401) {
                return this.a.g().a(routeW, response);
            }
            if (iR == 421) {
                RequestBody requestBodyA = response.b0().a();
                if ((requestBodyA != null && requestBodyA.g()) || exchange == null || !exchange.n()) {
                    return null;
                }
                exchange.j().v();
                return response.b0();
            }
            if (iR == 503) {
                Response responseW = response.W();
                if ((responseW == null || responseW.r() != 503) && h(response, Integer.MAX_VALUE) == 0) {
                    return response.b0();
                }
                return null;
            }
            if (iR == 407) {
                Intrinsics.checkNotNull(routeW);
                if (routeW.b().type() == Proxy.Type.HTTP) {
                    return this.a.F().a(routeW, response);
                }
                throw new ProtocolException("Received HTTP_PROXY_AUTH (407) code while not using proxy");
            }
            if (iR == 408) {
                if (!this.a.I()) {
                    return null;
                }
                RequestBody requestBodyA2 = response.b0().a();
                if (requestBodyA2 != null && requestBodyA2.g()) {
                    return null;
                }
                Response responseW2 = response.W();
                if ((responseW2 == null || responseW2.r() != 408) && h(response, 0) <= 0) {
                    return response.b0();
                }
                return null;
            }
            switch (iR) {
                case 300:
                case 301:
                case 302:
                case 303:
                    break;
                default:
                    return null;
            }
        }
        return c(response, strI);
    }

    private final boolean e(IOException iOException, boolean z) {
        if (iOException instanceof ProtocolException) {
            return false;
        }
        return iOException instanceof InterruptedIOException ? (iOException instanceof SocketTimeoutException) && !z : (((iOException instanceof SSLHandshakeException) && (iOException.getCause() instanceof CertificateException)) || (iOException instanceof SSLPeerUnverifiedException)) ? false : true;
    }

    private final boolean f(IOException iOException, RealCall realCall, Request request) {
        boolean z = iOException instanceof ConnectionShutdownException;
        boolean z2 = !z;
        if (this.a.I()) {
            return (z || !g(iOException, request)) && e(iOException, z2) && realCall.x();
        }
        return false;
    }

    private final boolean g(IOException iOException, Request request) {
        RequestBody requestBodyA = request.a();
        return (requestBodyA != null && requestBodyA.g()) || (iOException instanceof FileNotFoundException);
    }

    private final int h(Response response, int i) {
        String strD = Response.D(response, "Retry-After", null, 2, null);
        if (strD == null) {
            return i;
        }
        if (!new Regex("\\d+").matches(strD)) {
            return Integer.MAX_VALUE;
        }
        Integer numValueOf = Integer.valueOf(strD);
        Intrinsics.checkNotNullExpressionValue(numValueOf, "valueOf(...)");
        return numValueOf.intValue();
    }

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0030, code lost:
    
        r6 = okhttp3.internal.UnreadableResponseBodyKt.a(r7);
     */
    /* JADX WARN: Code restructure failed: missing block: B:13:0x0039, code lost:
    
        r6 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x003a, code lost:
    
        r7 = r0.n(r6).c();
        r0 = r1.n();
        r6 = d(r7, r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x004a, code lost:
    
        if (r6 != null) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x004c, code lost:
    
        if (r0 == null) goto L20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0052, code lost:
    
        if (r0.o() == false) goto L20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x0054, code lost:
    
        r1.y();
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x0057, code lost:
    
        r1.l().o(r1, r7, null);
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x005e, code lost:
    
        r1.i(false);
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x0061, code lost:
    
        return r7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0062, code lost:
    
        r11 = th;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0065, code lost:
    
        r0 = r6.a();
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0069, code lost:
    
        if (r0 == null) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x006f, code lost:
    
        if (r0.g() == false) goto L32;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x0071, code lost:
    
        r1.l().o(r1, r7, null);
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x0078, code lost:
    
        r1.i(false);
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x007b, code lost:
    
        return r7;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x007c, code lost:
    
        okhttp3.internal._UtilCommonKt.f(r7.j());
        r8 = r8 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x0087, code lost:
    
        if (r8 > 20) goto L56;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x0089, code lost:
    
        r1.l().o(r1, r7, r6);
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0095, code lost:
    
        r1.l().o(r1, r7, null);
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x00b2, code lost:
    
        throw new java.net.ProtocolException("Too many follow-up requests: " + r8);
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x0026, code lost:
    
        r0 = r12.a(r0).Q().q(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x002e, code lost:
    
        if (r7 == null) goto L13;
     */
    @Override // okhttp3.Interceptor
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public okhttp3.Response a(okhttp3.Interceptor.Chain r12) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 222
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.http.RetryAndFollowUpInterceptor.a(okhttp3.Interceptor$Chain):okhttp3.Response");
    }
}