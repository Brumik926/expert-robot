package okhttp3.internal.http;

import java.io.IOException;
import kotlin.Metadata;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;
import okhttp3.internal.connection.RealCall;
import okio.Sink;
import okio.Source;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000J\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\bf\u0018\u00002\u00020\u0001:\u0002#$J\u001f\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H&¢\u0006\u0004\b\u0007\u0010\bJ\u0017\u0010\n\u001a\u00020\t2\u0006\u0010\u0003\u001a\u00020\u0002H&¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\f\u001a\u00020\tH&¢\u0006\u0004\b\f\u0010\rJ\u000f\u0010\u000e\u001a\u00020\tH&¢\u0006\u0004\b\u000e\u0010\rJ\u0019\u0010\u0012\u001a\u0004\u0018\u00010\u00112\u0006\u0010\u0010\u001a\u00020\u000fH&¢\u0006\u0004\b\u0012\u0010\u0013J\u0017\u0010\u0016\u001a\u00020\u00042\u0006\u0010\u0015\u001a\u00020\u0014H&¢\u0006\u0004\b\u0016\u0010\u0017J\u0017\u0010\u0019\u001a\u00020\u00182\u0006\u0010\u0015\u001a\u00020\u0014H&¢\u0006\u0004\b\u0019\u0010\u001aJ\u000f\u0010\u001b\u001a\u00020\tH&¢\u0006\u0004\b\u001b\u0010\rR\u0014\u0010\u001f\u001a\u00020\u001c8&X¦\u0004¢\u0006\u0006\u001a\u0004\b\u001d\u0010\u001eR\u0014\u0010\"\u001a\u00020\u000f8&X¦\u0004¢\u0006\u0006\u001a\u0004\b \u0010!¨\u0006%À\u0006\u0003"}, d2 = {"Lokhttp3/internal/http/ExchangeCodec;", StringUtils.EMPTY, "Lokhttp3/Request;", "request", StringUtils.EMPTY, "contentLength", "Lokio/Sink;", "b", "(Lokhttp3/Request;J)Lokio/Sink;", StringUtils.EMPTY, "f", "(Lokhttp3/Request;)V", "c", "()V", "d", StringUtils.EMPTY, "expectContinue", "Lokhttp3/Response$Builder;", "h", "(Z)Lokhttp3/Response$Builder;", "Lokhttp3/Response;", "response", "e", "(Lokhttp3/Response;)J", "Lokio/Source;", "a", "(Lokhttp3/Response;)Lokio/Source;", "cancel", "Lokhttp3/internal/http/ExchangeCodec$Carrier;", "i", "()Lokhttp3/internal/http/ExchangeCodec$Carrier;", "carrier", "g", "()Z", "isResponseComplete", "Carrier", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public interface ExchangeCodec {

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\bf\u0018\u00002\u00020\u0001J!\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004H&¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\t\u001a\u00020\u0006H&¢\u0006\u0004\b\t\u0010\nJ\u000f\u0010\u000b\u001a\u00020\u0006H&¢\u0006\u0004\b\u000b\u0010\nR\u0014\u0010\u000e\u001a\u00020\f8&X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0005\u0010\r¨\u0006\u000fÀ\u0006\u0003"}, d2 = {"Lokhttp3/internal/http/ExchangeCodec$Carrier;", StringUtils.EMPTY, "Lokhttp3/internal/connection/RealCall;", "call", "Ljava/io/IOException;", "e", StringUtils.EMPTY, "g", "(Lokhttp3/internal/connection/RealCall;Ljava/io/IOException;)V", "c", "()V", "cancel", "Lokhttp3/Route;", "()Lokhttp3/Route;", "route", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public interface Carrier {
        void c();

        void cancel();

        Route e();

        void g(RealCall realCall, IOException iOException);
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lokhttp3/internal/http/ExchangeCodec$Companion;", StringUtils.EMPTY, "<init>", "()V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        static final /* synthetic */ Companion a = new Companion();

        private Companion() {
        }
    }

    Source a(Response response);

    Sink b(Request request, long j);

    void c();

    void cancel();

    void d();

    long e(Response response);

    void f(Request request);

    boolean g();

    Response.Builder h(boolean z);

    Carrier i();
}