package okhttp3.internal.http;

import h.ap;
import java.net.Proxy;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.HttpUrl;
import okhttp3.Request;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001f\u0010\t\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\t\u0010\nJ\u001d\u0010\f\u001a\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\f\u0010\rJ\u0015\u0010\u0010\u001a\u00020\u000b2\u0006\u0010\u000f\u001a\u00020\u000e¢\u0006\u0004\b\u0010\u0010\u0011¨\u0006\u0012"}, d2 = {"Lokhttp3/internal/http/RequestLine;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/Request;", "request", "Ljava/net/Proxy$Type;", "proxyType", StringUtils.EMPTY, "b", "(Lokhttp3/Request;Ljava/net/Proxy$Type;)Z", StringUtils.EMPTY, "a", "(Lokhttp3/Request;Ljava/net/Proxy$Type;)Ljava/lang/String;", "Lokhttp3/HttpUrl;", "url", "c", "(Lokhttp3/HttpUrl;)Ljava/lang/String;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class RequestLine {
    public static final RequestLine a = new RequestLine();

    private RequestLine() {
    }

    private final boolean b(Request request, Proxy.Type type) {
        return !request.h() && type == Proxy.Type.HTTP;
    }

    public final String a(Request request, Proxy.Type type) {
        Intrinsics.checkNotNullParameter(request, ap.a(1483199085));
        Intrinsics.checkNotNullParameter(type, ap.a(1086550356));
        StringBuilder sb = new StringBuilder();
        sb.append(request.i());
        sb.append(' ');
        RequestLine requestLine = a;
        if (requestLine.b(request, type)) {
            sb.append(request.m());
        } else {
            sb.append(requestLine.c(request.m()));
        }
        sb.append(ap.a(576881661));
        return sb.toString();
    }

    public final String c(HttpUrl httpUrl) {
        Intrinsics.checkNotNullParameter(httpUrl, "url");
        String strC = httpUrl.c();
        String strE = httpUrl.e();
        if (strE == null) {
            return strC;
        }
        return strC + '?' + strE;
    }
}