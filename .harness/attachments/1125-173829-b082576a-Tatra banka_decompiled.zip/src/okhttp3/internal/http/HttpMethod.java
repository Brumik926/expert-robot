package okhttp3.internal.http;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0007\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\u0007\u0010\bJ\u0017\u0010\t\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\t\u0010\bJ\u0017\u0010\n\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\n\u0010\bJ\u0015\u0010\u000b\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u000b\u0010\bJ\u0015\u0010\f\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\f\u0010\b¨\u0006\r"}, d2 = {"Lokhttp3/internal/http/HttpMethod;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "method", StringUtils.EMPTY, "a", "(Ljava/lang/String;)Z", "e", "b", "d", "c", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class HttpMethod {
    public static final HttpMethod a = new HttpMethod();

    private HttpMethod() {
    }

    public static final boolean a(String str) {
        Intrinsics.checkNotNullParameter(str, ap.a(1988931659));
        return Intrinsics.areEqual(str, ap.a(1857363355)) || Intrinsics.areEqual(str, ap.a(1218638968)) || Intrinsics.areEqual(str, ap.a(560033382)) || Intrinsics.areEqual(str, ap.a(34823627)) || Intrinsics.areEqual(str, ap.a(608677947));
    }

    public static final boolean b(String str) {
        Intrinsics.checkNotNullParameter(str, "method");
        return (Intrinsics.areEqual(str, "GET") || Intrinsics.areEqual(str, "HEAD")) ? false : true;
    }

    public static final boolean e(String str) {
        Intrinsics.checkNotNullParameter(str, "method");
        return Intrinsics.areEqual(str, "POST") || Intrinsics.areEqual(str, "PUT") || Intrinsics.areEqual(str, "PATCH") || Intrinsics.areEqual(str, "PROPPATCH") || Intrinsics.areEqual(str, "REPORT");
    }

    public final boolean c(String str) {
        Intrinsics.checkNotNullParameter(str, "method");
        return !Intrinsics.areEqual(str, "PROPFIND");
    }

    public final boolean d(String str) {
        Intrinsics.checkNotNullParameter(str, "method");
        return Intrinsics.areEqual(str, "PROPFIND");
    }
}