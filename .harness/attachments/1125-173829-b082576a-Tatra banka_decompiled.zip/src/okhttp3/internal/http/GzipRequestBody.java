package okhttp3.internal.http;

import h.ap;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.MediaType;
import okhttp3.RequestBody;
import okio.BufferedSink;
import okio.GzipSink;
import okio.Okio;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\b\b\u0000\u0018\u00002\u00020\u0001J\u0011\u0010\u0003\u001a\u0004\u0018\u00010\u0002H\u0016¢\u0006\u0004\b\u0003\u0010\u0004J\u000f\u0010\u0006\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0006\u0010\u0007J\u0017\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\bH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\u000e\u001a\u00020\rH\u0016¢\u0006\u0004\b\u000e\u0010\u000fR\u0017\u0010\u0014\u001a\u00020\u00018\u0006¢\u0006\f\n\u0004\b\u0010\u0010\u0011\u001a\u0004\b\u0012\u0010\u0013¨\u0006\u0015"}, d2 = {"Lokhttp3/internal/http/GzipRequestBody;", "Lokhttp3/RequestBody;", "Lokhttp3/MediaType;", "b", "()Lokhttp3/MediaType;", StringUtils.EMPTY, "a", "()J", "Lokio/BufferedSink;", "sink", StringUtils.EMPTY, "h", "(Lokio/BufferedSink;)V", StringUtils.EMPTY, "g", "()Z", "c", "Lokhttp3/RequestBody;", "getDelegate", "()Lokhttp3/RequestBody;", "delegate", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nGzipRequestBody.kt\nKotlin\n*S Kotlin\n*F\n+ 1 GzipRequestBody.kt\nokhttp3/internal/http/GzipRequestBody\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,37:1\n1#2:38\n*E\n"})
public final class GzipRequestBody extends RequestBody {
    private final RequestBody c;

    @Override // okhttp3.RequestBody
    public long a() {
        return -1L;
    }

    @Override // okhttp3.RequestBody
    public MediaType b() {
        return this.c.b();
    }

    @Override // okhttp3.RequestBody
    public boolean g() {
        return this.c.g();
    }

    @Override // okhttp3.RequestBody
    public void h(BufferedSink bufferedSink) {
        Intrinsics.checkNotNullParameter(bufferedSink, ap.a(1407112392));
        BufferedSink bufferedSinkB = Okio.b(new GzipSink(bufferedSink));
        try {
            this.c.h(bufferedSinkB);
            Unit unit = Unit.INSTANCE;
            CloseableKt.closeFinally(bufferedSinkB, (Throwable) null);
        } finally {
        }
    }
}