package okhttp3.internal.http;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.MediaType;
import okhttp3.ResponseBody;
import okio.BufferedSource;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u000b\u0018\u00002\u00020\u0001B!\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\n\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\n\u0010\u000bJ\u0011\u0010\r\u001a\u0004\u0018\u00010\fH\u0016¢\u0006\u0004\b\r\u0010\u000eJ\u000f\u0010\u000f\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u000f\u0010\u0010R\u0016\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0011\u0010\u0012R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0013\u0010\u0014R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010\u0016¨\u0006\u0017"}, d2 = {"Lokhttp3/internal/http/RealResponseBody;", "Lokhttp3/ResponseBody;", StringUtils.EMPTY, "contentTypeString", StringUtils.EMPTY, "contentLength", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "<init>", "(Ljava/lang/String;JLokio/BufferedSource;)V", "r", "()J", "Lokhttp3/MediaType;", "u", "()Lokhttp3/MediaType;", "A", "()Lokio/BufferedSource;", "d", "Ljava/lang/String;", "e", "J", "f", "Lokio/BufferedSource;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class RealResponseBody extends ResponseBody {
    private final String d;
    private final long e;
    private final BufferedSource f;

    public RealResponseBody(String str, long j, BufferedSource bufferedSource) {
        Intrinsics.checkNotNullParameter(bufferedSource, ap.a(848538516));
        this.d = str;
        this.e = j;
        this.f = bufferedSource;
    }

    @Override // okhttp3.ResponseBody
    public BufferedSource A() {
        return this.f;
    }

    @Override // okhttp3.ResponseBody
    public long r() {
        return this.e;
    }

    @Override // okhttp3.ResponseBody
    public MediaType u() {
        String str = this.d;
        if (str != null) {
            return MediaType.e.b(str);
        }
        return null;
    }
}