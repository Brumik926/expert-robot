package okhttp3.internal.http;

import h.ap;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.Call;
import okhttp3.Connection;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal.connection.Exchange;
import okhttp3.internal.connection.RealCall;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0012\u0018\u00002\u00020\u0001BO\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\f\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u0004\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\b\u0010\n\u001a\u0004\u0018\u00010\t\u0012\u0006\u0010\f\u001a\u00020\u000b\u0012\u0006\u0010\r\u001a\u00020\u0007\u0012\u0006\u0010\u000e\u001a\u00020\u0007\u0012\u0006\u0010\u000f\u001a\u00020\u0007¢\u0006\u0004\b\u0010\u0010\u0011JM\u0010\u0012\u001a\u00020\u00002\b\b\u0002\u0010\b\u001a\u00020\u00072\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\t2\b\b\u0002\u0010\f\u001a\u00020\u000b2\b\b\u0002\u0010\r\u001a\u00020\u00072\b\b\u0002\u0010\u000e\u001a\u00020\u00072\b\b\u0002\u0010\u000f\u001a\u00020\u0007H\u0000¢\u0006\u0004\b\u0012\u0010\u0013J\u0011\u0010\u0015\u001a\u0004\u0018\u00010\u0014H\u0016¢\u0006\u0004\b\u0015\u0010\u0016J\u000f\u0010\u0017\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0017\u0010\u0018J\u000f\u0010\u0003\u001a\u00020\u0019H\u0016¢\u0006\u0004\b\u0003\u0010\u001aJ\u000f\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\f\u0010\u001bJ\u0017\u0010\u001d\u001a\u00020\u001c2\u0006\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u001d\u0010\u001eR\u001a\u0010\u0003\u001a\u00020\u00028\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u001d\u0010\u001f\u001a\u0004\b \u0010!R\u001a\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010\"R\u0014\u0010\b\u001a\u00020\u00078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010#R\u001c\u0010\n\u001a\u0004\u0018\u00010\t8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b$\u0010%\u001a\u0004\b&\u0010'R\u001a\u0010\f\u001a\u00020\u000b8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b \u0010(\u001a\u0004\b)\u0010\u001bR\u001a\u0010\r\u001a\u00020\u00078\u0000X\u0080\u0004¢\u0006\f\n\u0004\b*\u0010#\u001a\u0004\b*\u0010\u0018R\u001a\u0010\u000e\u001a\u00020\u00078\u0000X\u0080\u0004¢\u0006\f\n\u0004\b&\u0010#\u001a\u0004\b+\u0010\u0018R\u001a\u0010\u000f\u001a\u00020\u00078\u0000X\u0080\u0004¢\u0006\f\n\u0004\b+\u0010#\u001a\u0004\b,\u0010\u0018R\u0016\u0010-\u001a\u00020\u00078\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b)\u0010#¨\u0006."}, d2 = {"Lokhttp3/internal/http/RealInterceptorChain;", "Lokhttp3/Interceptor$Chain;", "Lokhttp3/internal/connection/RealCall;", "call", StringUtils.EMPTY, "Lokhttp3/Interceptor;", "interceptors", StringUtils.EMPTY, "index", "Lokhttp3/internal/connection/Exchange;", "exchange", "Lokhttp3/Request;", "request", "connectTimeoutMillis", "readTimeoutMillis", "writeTimeoutMillis", "<init>", "(Lokhttp3/internal/connection/RealCall;Ljava/util/List;ILokhttp3/internal/connection/Exchange;Lokhttp3/Request;III)V", "c", "(ILokhttp3/internal/connection/Exchange;Lokhttp3/Request;III)Lokhttp3/internal/http/RealInterceptorChain;", "Lokhttp3/Connection;", "b", "()Lokhttp3/Connection;", "k", "()I", "Lokhttp3/Call;", "()Lokhttp3/Call;", "()Lokhttp3/Request;", "Lokhttp3/Response;", "a", "(Lokhttp3/Request;)Lokhttp3/Response;", "Lokhttp3/internal/connection/RealCall;", "e", "()Lokhttp3/internal/connection/RealCall;", "Ljava/util/List;", "I", "d", "Lokhttp3/internal/connection/Exchange;", "g", "()Lokhttp3/internal/connection/Exchange;", "Lokhttp3/Request;", "i", "f", "h", "j", "calls", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nRealInterceptorChain.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RealInterceptorChain.kt\nokhttp3/internal/http/RealInterceptorChain\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,139:1\n1#2:140\n*E\n"})
public final class RealInterceptorChain implements Interceptor.Chain {
    private final RealCall a;
    private final List b;
    private final int c;
    private final Exchange d;
    private final Request e;
    private final int f;
    private final int g;
    private final int h;
    private int i;

    public RealInterceptorChain(RealCall realCall, List list, int i, Exchange exchange, Request request, int i2, int i3, int i4) {
        Intrinsics.checkNotNullParameter(realCall, ap.a(1042281943));
        Intrinsics.checkNotNullParameter(list, ap.a(1523449847));
        Intrinsics.checkNotNullParameter(request, ap.a(2138441260));
        this.a = realCall;
        this.b = list;
        this.c = i;
        this.d = exchange;
        this.e = request;
        this.f = i2;
        this.g = i3;
        this.h = i4;
    }

    public static /* synthetic */ RealInterceptorChain d(RealInterceptorChain realInterceptorChain, int i, Exchange exchange, Request request, int i2, int i3, int i4, int i5, Object obj) {
        if ((i5 & 1) != 0) {
            i = realInterceptorChain.c;
        }
        if ((i5 & 2) != 0) {
            exchange = realInterceptorChain.d;
        }
        if ((i5 & 4) != 0) {
            request = realInterceptorChain.e;
        }
        if ((i5 & 8) != 0) {
            i2 = realInterceptorChain.f;
        }
        if ((i5 & 16) != 0) {
            i3 = realInterceptorChain.g;
        }
        if ((i5 & 32) != 0) {
            i4 = realInterceptorChain.h;
        }
        int i6 = i3;
        int i7 = i4;
        return realInterceptorChain.c(i, exchange, request, i2, i6, i7);
    }

    @Override // okhttp3.Interceptor.Chain
    public Response a(Request request) {
        Intrinsics.checkNotNullParameter(request, "request");
        if (this.c >= this.b.size()) {
            throw new IllegalStateException("Check failed.");
        }
        this.i++;
        Exchange exchange = this.d;
        if (exchange != null) {
            if (!exchange.l().b().c(request.m())) {
                throw new IllegalStateException(("network interceptor " + this.b.get(this.c - 1) + " must retain the same host and port").toString());
            }
            if (this.i != 1) {
                throw new IllegalStateException(("network interceptor " + this.b.get(this.c - 1) + " must call proceed() exactly once").toString());
            }
        }
        RealInterceptorChain realInterceptorChainD = d(this, this.c + 1, null, request, 0, 0, 0, 58, null);
        Interceptor interceptor = (Interceptor) this.b.get(this.c);
        Response responseA = interceptor.a(realInterceptorChainD);
        if (responseA == null) {
            throw new NullPointerException("interceptor " + interceptor + " returned null");
        }
        if (this.d == null || this.c + 1 >= this.b.size() || realInterceptorChainD.i == 1) {
            return responseA;
        }
        throw new IllegalStateException(("network interceptor " + interceptor + " must call proceed() exactly once").toString());
    }

    @Override // okhttp3.Interceptor.Chain
    public Connection b() {
        Exchange exchange = this.d;
        if (exchange != null) {
            return exchange.j();
        }
        return null;
    }

    public final RealInterceptorChain c(int i, Exchange exchange, Request request, int i2, int i3, int i4) {
        Intrinsics.checkNotNullParameter(request, "request");
        return new RealInterceptorChain(this.a, this.b, i, exchange, request, i2, i3, i4);
    }

    @Override // okhttp3.Interceptor.Chain
    public Call call() {
        return this.a;
    }

    public final RealCall e() {
        return this.a;
    }

    public final int f() {
        return this.f;
    }

    public final Exchange g() {
        return this.d;
    }

    public final int h() {
        return this.g;
    }

    public final Request i() {
        return this.e;
    }

    public final int j() {
        return this.h;
    }

    public int k() {
        return this.g;
    }

    @Override // okhttp3.Interceptor.Chain
    public Request request() {
        return this.e;
    }
}