package okhttp3.internal.http;

import h.ap;
import java.io.IOException;
import java.net.ProtocolException;
import kotlin.ExceptionsKt;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.TrailersSource;
import okhttp3.internal.UnreadableResponseBodyKt;
import okhttp3.internal.connection.Exchange;
import okhttp3.internal.http2.ConnectionShutdownException;
import okio.BufferedSink;
import okio.Okio;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u001f\u0010\n\u001a\u00020\u00022\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\bH\u0002¢\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\u000f\u0010\u0010R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\u0011¨\u0006\u0012"}, d2 = {"Lokhttp3/internal/http/CallServerInterceptor;", "Lokhttp3/Interceptor;", StringUtils.EMPTY, "forWebSocket", "<init>", "(Z)V", StringUtils.EMPTY, "code", "Lokhttp3/internal/connection/Exchange;", "exchange", "c", "(ILokhttp3/internal/connection/Exchange;)Z", "Lokhttp3/Interceptor$Chain;", "chain", "Lokhttp3/Response;", "a", "(Lokhttp3/Interceptor$Chain;)Lokhttp3/Response;", "Z", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class CallServerInterceptor implements Interceptor {
    private final boolean a;

    public CallServerInterceptor(boolean z) {
        this.a = z;
    }

    private final boolean c(int i, Exchange exchange) {
        if (i == 100) {
            return true;
        }
        return 102 <= i && i < 200;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r10v0 */
    /* JADX WARN: Type inference failed for: r10v1 */
    /* JADX WARN: Type inference failed for: r10v18, types: [boolean] */
    /* JADX WARN: Type inference failed for: r10v19 */
    /* JADX WARN: Type inference failed for: r10v2 */
    /* JADX WARN: Type inference failed for: r10v20 */
    /* JADX WARN: Type inference failed for: r10v21 */
    /* JADX WARN: Type inference failed for: r10v28 */
    /* JADX WARN: Type inference failed for: r10v29 */
    /* JADX WARN: Type inference failed for: r10v3, types: [java.lang.Object, okhttp3.Response$Builder] */
    /* JADX WARN: Type inference failed for: r10v30 */
    /* JADX WARN: Type inference failed for: r10v31 */
    /* JADX WARN: Type inference failed for: r10v32 */
    /* JADX WARN: Type inference failed for: r10v33 */
    /* JADX WARN: Type inference failed for: r10v34 */
    /* JADX WARN: Type inference failed for: r10v35 */
    /* JADX WARN: Type inference failed for: r10v4, types: [okhttp3.Response$Builder] */
    @Override // okhttp3.Interceptor
    public Response a(Interceptor.Chain chain) throws IOException {
        boolean z;
        ?? r10;
        ?? T;
        Response responseC;
        Response.Builder builder;
        String strA = ap.a(1206048407);
        String strA2 = ap.a(1457784706);
        Intrinsics.checkNotNullParameter(chain, ap.a(1927063034));
        RealInterceptorChain realInterceptorChain = (RealInterceptorChain) chain;
        final Exchange exchangeG = realInterceptorChain.g();
        Intrinsics.checkNotNull(exchangeG);
        Request requestI = realInterceptorChain.i();
        RequestBody requestBodyA = requestI.a();
        long jCurrentTimeMillis = System.currentTimeMillis();
        try {
            exchangeG.y(requestI);
            ?? B = HttpMethod.b(requestI.i());
            try {
                if (B == 0 || requestBodyA == null) {
                    exchangeG.r();
                    z = true;
                    B = 0;
                } else {
                    if (StringsKt.equals(ap.a(417333343), requestI.e(ap.a(1863194840)), true)) {
                        exchangeG.h();
                        Response.Builder builderT = exchangeG.t(true);
                        try {
                            exchangeG.v();
                            z = false;
                            builder = builderT;
                        } catch (IOException e) {
                            e = e;
                            z = true;
                            r10 = builderT;
                            if (e instanceof ConnectionShutdownException) {
                                throw e;
                            }
                            T = r10;
                            if (!exchangeG.m()) {
                                throw e;
                            }
                        }
                    } else {
                        z = true;
                        builder = null;
                    }
                    if (builder != null) {
                        exchangeG.r();
                        B = builder;
                        if (!exchangeG.j().s()) {
                            exchangeG.q();
                            B = builder;
                        }
                    } else if (requestBodyA.f()) {
                        exchangeG.h();
                        requestBodyA.h(Okio.b(exchangeG.e(requestI, true)));
                        B = builder;
                    } else {
                        BufferedSink bufferedSinkB = Okio.b(exchangeG.e(requestI, false));
                        requestBodyA.h(bufferedSinkB);
                        bufferedSinkB.close();
                        B = builder;
                    }
                }
                if (requestBodyA == null || !requestBodyA.f()) {
                    exchangeG.g();
                }
                e = null;
                T = B;
            } catch (IOException e2) {
                e = e2;
                r10 = B;
            }
        } catch (IOException e3) {
            e = e3;
            z = true;
            r10 = 0;
        }
        if (T == 0) {
            try {
                T = exchangeG.t(false);
                Intrinsics.checkNotNull((Object) T);
                if (z) {
                    exchangeG.v();
                    z = false;
                }
            } catch (IOException e4) {
                if (e == null) {
                    throw e4;
                }
                ExceptionsKt.addSuppressed(e, e4);
                throw e;
            }
        }
        Response responseC2 = T.q(requestI).h(exchangeG.j().o()).r(jCurrentTimeMillis).p(System.currentTimeMillis()).c();
        int iR = responseC2.r();
        while (c(iR, exchangeG)) {
            Response.Builder builderT2 = exchangeG.t(false);
            Intrinsics.checkNotNull(builderT2);
            if (z) {
                exchangeG.v();
            }
            responseC2 = builderT2.q(requestI).h(exchangeG.j().o()).r(jCurrentTimeMillis).p(System.currentTimeMillis()).c();
            iR = responseC2.r();
        }
        exchangeG.u(responseC2);
        if (this.a && iR == 101) {
            responseC = UnreadableResponseBodyKt.a(responseC2);
        } else {
            final ResponseBody responseBodyS = exchangeG.s(responseC2);
            responseC = responseC2.Q().b(responseBodyS).s(new TrailersSource() { // from class: okhttp3.internal.http.CallServerInterceptor$intercept$1
            }).c();
        }
        if (StringsKt.equals(strA2, responseC.b0().e(strA), true) || StringsKt.equals(strA2, Response.D(responseC, strA, null, 2, null), true)) {
            exchangeG.q();
        }
        if ((iR != 204 && iR != 205) || responseC.j().r() <= 0) {
            return responseC;
        }
        throw new ProtocolException(ap.a(890631505) + iR + ap.a(499003352) + responseC.j().r());
    }
}