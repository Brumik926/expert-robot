package okhttp3.internal.http;

import h.ap;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.internal._UtilJvmKt;
import okio.GzipSource;
import okio.Okio;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u001d\u0010\n\u001a\u00020\t2\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006H\u0002¢\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\u000f\u0010\u0010R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\u0011¨\u0006\u0012"}, d2 = {"Lokhttp3/internal/http/BridgeInterceptor;", "Lokhttp3/Interceptor;", "Lokhttp3/CookieJar;", "cookieJar", "<init>", "(Lokhttp3/CookieJar;)V", StringUtils.EMPTY, "Lokhttp3/Cookie;", "cookies", StringUtils.EMPTY, "c", "(Ljava/util/List;)Ljava/lang/String;", "Lokhttp3/Interceptor$Chain;", "chain", "Lokhttp3/Response;", "a", "(Lokhttp3/Interceptor$Chain;)Lokhttp3/Response;", "Lokhttp3/CookieJar;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nBridgeInterceptor.kt\nKotlin\n*S Kotlin\n*F\n+ 1 BridgeInterceptor.kt\nokhttp3/internal/http/BridgeInterceptor\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,125:1\n1878#2,3:126\n*S KotlinDebug\n*F\n+ 1 BridgeInterceptor.kt\nokhttp3/internal/http/BridgeInterceptor\n*L\n119#1:126,3\n*E\n"})
public final class BridgeInterceptor implements Interceptor {
    private final CookieJar a;

    public BridgeInterceptor(CookieJar cookieJar) {
        Intrinsics.checkNotNullParameter(cookieJar, ap.a(547183572));
        this.a = cookieJar;
    }

    private final String c(List list) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (Object obj : list) {
            int i2 = i + 1;
            if (i < 0) {
                CollectionsKt.throwIndexOverflow();
            }
            Cookie cookie = (Cookie) obj;
            if (i > 0) {
                sb.append("; ");
            }
            sb.append(cookie.e());
            sb.append('=');
            sb.append(cookie.i());
            i = i2;
        }
        return sb.toString();
    }

    @Override // okhttp3.Interceptor
    public Response a(Interceptor.Chain chain) {
        ResponseBody responseBodyJ;
        Intrinsics.checkNotNullParameter(chain, "chain");
        Request request = chain.request();
        Request.Builder builderJ = request.j();
        RequestBody requestBodyA = request.a();
        if (requestBodyA != null) {
            MediaType mediaTypeB = requestBodyA.b();
            if (mediaTypeB != null) {
                builderJ.n(org.apache.tika.metadata.HttpHeaders.CONTENT_TYPE, mediaTypeB.toString());
            }
            long jA = requestBodyA.a();
            if (jA != -1) {
                builderJ.n(org.apache.tika.metadata.HttpHeaders.CONTENT_LENGTH, String.valueOf(jA));
                builderJ.s("Transfer-Encoding");
            } else {
                builderJ.n("Transfer-Encoding", "chunked");
                builderJ.s(org.apache.tika.metadata.HttpHeaders.CONTENT_LENGTH);
            }
        }
        boolean z = false;
        if (request.e("Host") == null) {
            builderJ.n("Host", _UtilJvmKt.w(request.m(), false, 1, null));
        }
        if (request.e("Connection") == null) {
            builderJ.n("Connection", "Keep-Alive");
        }
        if (request.e("Accept-Encoding") == null && request.e("Range") == null) {
            builderJ.n("Accept-Encoding", "gzip");
            z = true;
        }
        List listA = this.a.a(request.m());
        if (!listA.isEmpty()) {
            builderJ.n("Cookie", c(listA));
        }
        if (request.e("User-Agent") == null) {
            builderJ.n("User-Agent", "okhttp/5.1.0");
        }
        Request requestB = builderJ.b();
        Response responseA = chain.a(requestB);
        HttpHeaders.f(this.a, requestB.m(), responseA.J());
        Response.Builder builderQ = responseA.Q().q(requestB);
        if (z && StringsKt.equals("gzip", Response.D(responseA, org.apache.tika.metadata.HttpHeaders.CONTENT_ENCODING, null, 2, null), true) && HttpHeaders.b(responseA) && (responseBodyJ = responseA.j()) != null) {
            GzipSource gzipSource = new GzipSource(responseBodyJ.A());
            builderQ.j(responseA.J().f().h(org.apache.tika.metadata.HttpHeaders.CONTENT_ENCODING).h(org.apache.tika.metadata.HttpHeaders.CONTENT_LENGTH).e());
            builderQ.b(new RealResponseBody(Response.D(responseA, org.apache.tika.metadata.HttpHeaders.CONTENT_TYPE, null, 2, null), -1L, Okio.c(gzipSource)));
        }
        return builderQ.c();
    }
}