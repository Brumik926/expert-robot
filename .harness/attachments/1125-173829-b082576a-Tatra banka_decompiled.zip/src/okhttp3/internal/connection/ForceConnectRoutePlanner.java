package okhttp3.internal.connection;

import h.ap;
import kotlin.Metadata;
import kotlin.collections.ArrayDeque;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.Address;
import okhttp3.HttpUrl;
import okhttp3.internal.connection.RoutePlanner;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u0007\u0010\bJ\u0010\u0010\n\u001a\u00020\tH\u0096\u0001¢\u0006\u0004\b\n\u0010\u000bJ\u001a\u0010\u000e\u001a\u00020\t2\b\u0010\r\u001a\u0004\u0018\u00010\fH\u0096\u0001¢\u0006\u0004\b\u000e\u0010\u000fJ\u0018\u0010\u0012\u001a\u00020\t2\u0006\u0010\u0011\u001a\u00020\u0010H\u0096\u0001¢\u0006\u0004\b\u0012\u0010\u0013R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000e\u0010\u0014R\u0014\u0010\u0018\u001a\u00020\u00158\u0016X\u0096\u0005¢\u0006\u0006\u001a\u0004\b\u0016\u0010\u0017R\u001a\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u00060\u00198\u0016X\u0096\u0005¢\u0006\u0006\u001a\u0004\b\u001a\u0010\u001b¨\u0006\u001d"}, d2 = {"Lokhttp3/internal/connection/ForceConnectRoutePlanner;", "Lokhttp3/internal/connection/RoutePlanner;", "Lokhttp3/internal/connection/RealRoutePlanner;", "delegate", "<init>", "(Lokhttp3/internal/connection/RealRoutePlanner;)V", "Lokhttp3/internal/connection/RoutePlanner$Plan;", "e", "()Lokhttp3/internal/connection/RoutePlanner$Plan;", StringUtils.EMPTY, "isCanceled", "()Z", "Lokhttp3/internal/connection/RealConnection;", "failedConnection", "a", "(Lokhttp3/internal/connection/RealConnection;)Z", "Lokhttp3/HttpUrl;", "url", "c", "(Lokhttp3/HttpUrl;)Z", "Lokhttp3/internal/connection/RealRoutePlanner;", "Lokhttp3/Address;", "getAddress", "()Lokhttp3/Address;", "address", "Lkotlin/collections/ArrayDeque;", "b", "()Lkotlin/collections/ArrayDeque;", "deferredPlans", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ForceConnectRoutePlanner implements RoutePlanner {
    private final RealRoutePlanner a;

    public ForceConnectRoutePlanner(RealRoutePlanner realRoutePlanner) {
        Intrinsics.checkNotNullParameter(realRoutePlanner, ap.a(49917512));
        this.a = realRoutePlanner;
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public boolean a(RealConnection realConnection) {
        return this.a.a(realConnection);
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public ArrayDeque b() {
        return this.a.b();
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public boolean c(HttpUrl httpUrl) {
        Intrinsics.checkNotNullParameter(httpUrl, "url");
        return this.a.c(httpUrl);
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public RoutePlanner.Plan e() {
        return this.a.g();
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public Address getAddress() {
        return this.a.getAddress();
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public boolean isCanceled() {
        return this.a.isCanceled();
    }
}