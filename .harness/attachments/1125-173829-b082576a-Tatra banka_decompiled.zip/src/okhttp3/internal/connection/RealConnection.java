package okhttp3.internal.connection;

import h.ap;
import java.io.IOException;
import java.net.Proxy;
import java.net.Socket;
import java.net.SocketException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.SSLPeerUnverifiedException;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.Address;
import okhttp3.CertificatePinner;
import okhttp3.Connection;
import okhttp3.Handshake;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Route;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.concurrent.Lockable;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.http.ExchangeCodec;
import okhttp3.internal.http.RealInterceptorChain;
import okhttp3.internal.http1.Http1ExchangeCodec;
import okhttp3.internal.http2.ErrorCode;
import okhttp3.internal.http2.FlowControlListener;
import okhttp3.internal.http2.Http2Connection;
import okhttp3.internal.http2.Http2ExchangeCodec;
import okhttp3.internal.http2.Http2Stream;
import okhttp3.internal.http2.Settings;
import okhttp3.internal.tls.OkHostnameVerifier;
import okhttp3.internal.ws.RealWebSocket;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Timeout;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000Þ\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b(\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\b\u0018\u0000 ?2\u00020\u00012\u00020\u00022\u00020\u00032\u00020\u0004:\u0002\u0094\u0001Bc\b\u0000\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\f\u001a\u00020\u000b\u0012\u0006\u0010\r\u001a\u00020\u000b\u0012\b\u0010\u000f\u001a\u0004\u0018\u00010\u000e\u0012\u0006\u0010\u0011\u001a\u00020\u0010\u0012\u0006\u0010\u0013\u001a\u00020\u0012\u0012\u0006\u0010\u0015\u001a\u00020\u0014\u0012\u0006\u0010\u0017\u001a\u00020\u0016\u0012\u0006\u0010\u0019\u001a\u00020\u0018¢\u0006\u0004\b\u001a\u0010\u001bJ\u000f\u0010\u001d\u001a\u00020\u001cH\u0002¢\u0006\u0004\b\u001d\u0010\u001eJ\u001d\u0010\"\u001a\u00020!2\f\u0010 \u001a\b\u0012\u0004\u0012\u00020\t0\u001fH\u0002¢\u0006\u0004\b\"\u0010#J\u0017\u0010&\u001a\u00020!2\u0006\u0010%\u001a\u00020$H\u0002¢\u0006\u0004\b&\u0010'J\u001f\u0010(\u001a\u00020!2\u0006\u0010%\u001a\u00020$2\u0006\u0010\u000f\u001a\u00020\u000eH\u0002¢\u0006\u0004\b(\u0010)J\u000f\u0010*\u001a\u00020\u001cH\u0016¢\u0006\u0004\b*\u0010\u001eJ\u000f\u0010+\u001a\u00020\u001cH\u0000¢\u0006\u0004\b+\u0010\u001eJ\u000f\u0010,\u001a\u00020\u001cH\u0000¢\u0006\u0004\b,\u0010\u001eJ\r\u0010-\u001a\u00020\u001c¢\u0006\u0004\b-\u0010\u001eJ'\u00101\u001a\u00020!2\u0006\u0010/\u001a\u00020.2\u000e\u00100\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\u001fH\u0000¢\u0006\u0004\b1\u00102J\u001f\u00108\u001a\u0002072\u0006\u00104\u001a\u0002032\u0006\u00106\u001a\u000205H\u0000¢\u0006\u0004\b8\u00109J\u0017\u0010=\u001a\u00020<2\u0006\u0010;\u001a\u00020:H\u0000¢\u0006\u0004\b=\u0010>J\u000f\u0010?\u001a\u00020\tH\u0016¢\u0006\u0004\b?\u0010@J\u000f\u0010A\u001a\u00020\u001cH\u0016¢\u0006\u0004\bA\u0010\u001eJ\u000f\u0010B\u001a\u00020\u000bH\u0016¢\u0006\u0004\bB\u0010CJ\u0015\u0010E\u001a\u00020!2\u0006\u0010D\u001a\u00020!¢\u0006\u0004\bE\u0010FJ\u0017\u0010I\u001a\u00020\u001c2\u0006\u0010H\u001a\u00020GH\u0016¢\u0006\u0004\bI\u0010JJ\u001f\u0010O\u001a\u00020\u001c2\u0006\u0010L\u001a\u00020K2\u0006\u0010N\u001a\u00020MH\u0016¢\u0006\u0004\bO\u0010PJ\u0011\u0010Q\u001a\u0004\u0018\u00010\u000eH\u0016¢\u0006\u0004\bQ\u0010RJ'\u0010V\u001a\u00020\u001c2\u0006\u00104\u001a\u0002032\u0006\u0010S\u001a\u00020\t2\u0006\u0010U\u001a\u00020TH\u0000¢\u0006\u0004\bV\u0010WJ!\u0010[\u001a\u00020\u001c2\u0006\u0010Y\u001a\u00020X2\b\u0010Z\u001a\u0004\u0018\u00010TH\u0016¢\u0006\u0004\b[\u0010\\J\u000f\u0010]\u001a\u00020\u0010H\u0016¢\u0006\u0004\b]\u0010^J\u000f\u0010`\u001a\u00020_H\u0016¢\u0006\u0004\b`\u0010aR\u0017\u0010\u0006\u001a\u00020\u00058\u0006¢\u0006\f\n\u0004\b*\u0010b\u001a\u0004\bc\u0010dR\u0017\u0010\b\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\bI\u0010e\u001a\u0004\bf\u0010gR\u001a\u0010\n\u001a\u00020\t8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bZ\u0010h\u001a\u0004\bZ\u0010@R\u0014\u0010\f\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b(\u0010iR\u0014\u0010\r\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b[\u0010iR\u0016\u0010\u000f\u001a\u0004\u0018\u00010\u000e8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bV\u0010jR\u0014\u0010\u0011\u001a\u00020\u00108\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bk\u0010lR\u0014\u0010\u0013\u001a\u00020\u00128\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bm\u0010nR\u0014\u0010\u0015\u001a\u00020\u00148\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bo\u0010pR\u0014\u0010\u0017\u001a\u00020\u00168\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bq\u0010rR\u001a\u0010\u0019\u001a\u00020\u00188\u0000X\u0080\u0004¢\u0006\f\n\u0004\bs\u0010t\u001a\u0004\bo\u0010uR\u0018\u0010x\u001a\u0004\u0018\u00010K8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bv\u0010wR\"\u0010}\u001a\u00020!8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\bQ\u0010y\u001a\u0004\bs\u0010z\"\u0004\b{\u0010|R\u0016\u0010~\u001a\u00020!8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b,\u0010yR%\u0010\u0082\u0001\u001a\u00020\u00168\u0000@\u0000X\u0080\u000e¢\u0006\u0014\n\u0004\b1\u0010r\u001a\u0004\bv\u0010\u007f\"\u0006\b\u0080\u0001\u0010\u0081\u0001R\u0017\u0010\u0083\u0001\u001a\u00020\u00168\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bE\u0010rR\u0018\u0010\u0085\u0001\u001a\u00020\u00168\u0002@\u0002X\u0082\u000e¢\u0006\u0007\n\u0005\b\u0084\u0001\u0010rR&\u0010\u0087\u0001\u001a\u00020\u00162\u0007\u0010\u0086\u0001\u001a\u00020\u00168\u0000@BX\u0080\u000e¢\u0006\f\n\u0004\b8\u0010r\u001a\u0004\bk\u0010\u007fR(\u0010\u008c\u0001\u001a\u0010\u0012\u000b\u0012\t\u0012\u0004\u0012\u00020X0\u0089\u00010\u0088\u00018\u0006¢\u0006\u000e\n\u0005\b=\u0010\u008a\u0001\u001a\u0005\bm\u0010\u008b\u0001R(\u0010\u0092\u0001\u001a\u00030\u008d\u00018\u0006@\u0006X\u0086\u000e¢\u0006\u0016\n\u0005\b+\u0010\u008e\u0001\u001a\u0005\bq\u0010\u008f\u0001\"\u0006\b\u0090\u0001\u0010\u0091\u0001R\u0016\u0010\u0093\u0001\u001a\u00020!8@X\u0080\u0004¢\u0006\u0007\u001a\u0005\b\u0084\u0001\u0010z¨\u0006\u0095\u0001"}, d2 = {"Lokhttp3/internal/connection/RealConnection;", "Lokhttp3/internal/http2/Http2Connection$Listener;", "Lokhttp3/Connection;", "Lokhttp3/internal/http/ExchangeCodec$Carrier;", "Lokhttp3/internal/concurrent/Lockable;", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", "Lokhttp3/internal/connection/RealConnectionPool;", "connectionPool", "Lokhttp3/Route;", "route", "Ljava/net/Socket;", "rawSocket", "socket", "Lokhttp3/Handshake;", "handshake", "Lokhttp3/Protocol;", "protocol", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "Lokio/BufferedSink;", "sink", StringUtils.EMPTY, "pingIntervalMillis", "Lokhttp3/internal/connection/ConnectionListener;", "connectionListener", "<init>", "(Lokhttp3/internal/concurrent/TaskRunner;Lokhttp3/internal/connection/RealConnectionPool;Lokhttp3/Route;Ljava/net/Socket;Ljava/net/Socket;Lokhttp3/Handshake;Lokhttp3/Protocol;Lokio/BufferedSource;Lokio/BufferedSink;ILokhttp3/internal/connection/ConnectionListener;)V", StringUtils.EMPTY, "C", "()V", StringUtils.EMPTY, "candidates", StringUtils.EMPTY, "x", "(Ljava/util/List;)Z", "Lokhttp3/HttpUrl;", "url", "D", "(Lokhttp3/HttpUrl;)Z", "f", "(Lokhttp3/HttpUrl;Lokhttp3/Handshake;)Z", "c", "v", "p", "B", "Lokhttp3/Address;", "address", "routes", "q", "(Lokhttp3/Address;Ljava/util/List;)Z", "Lokhttp3/OkHttpClient;", "client", "Lokhttp3/internal/http/RealInterceptorChain;", "chain", "Lokhttp3/internal/http/ExchangeCodec;", "t", "(Lokhttp3/OkHttpClient;Lokhttp3/internal/http/RealInterceptorChain;)Lokhttp3/internal/http/ExchangeCodec;", "Lokhttp3/internal/connection/Exchange;", "exchange", "Lokhttp3/internal/ws/RealWebSocket$Streams;", "u", "(Lokhttp3/internal/connection/Exchange;)Lokhttp3/internal/ws/RealWebSocket$Streams;", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "()Lokhttp3/Route;", "cancel", "A", "()Ljava/net/Socket;", "doExtensiveChecks", "r", "(Z)Z", "Lokhttp3/internal/http2/Http2Stream;", "stream", "d", "(Lokhttp3/internal/http2/Http2Stream;)V", "Lokhttp3/internal/http2/Http2Connection;", "connection", "Lokhttp3/internal/http2/Settings;", "settings", "b", "(Lokhttp3/internal/http2/Http2Connection;Lokhttp3/internal/http2/Settings;)V", "o", "()Lokhttp3/Handshake;", "failedRoute", "Ljava/io/IOException;", "failure", "h", "(Lokhttp3/OkHttpClient;Lokhttp3/Route;Ljava/io/IOException;)V", "Lokhttp3/internal/connection/RealCall;", "call", "e", "g", "(Lokhttp3/internal/connection/RealCall;Ljava/io/IOException;)V", "a", "()Lokhttp3/Protocol;", StringUtils.EMPTY, "toString", "()Ljava/lang/String;", "Lokhttp3/internal/concurrent/TaskRunner;", "getTaskRunner", "()Lokhttp3/internal/concurrent/TaskRunner;", "Lokhttp3/internal/connection/RealConnectionPool;", "getConnectionPool", "()Lokhttp3/internal/connection/RealConnectionPool;", "Lokhttp3/Route;", "Ljava/net/Socket;", "Lokhttp3/Handshake;", "i", "Lokhttp3/Protocol;", "j", "Lokio/BufferedSource;", "k", "Lokio/BufferedSink;", "l", "I", "m", "Lokhttp3/internal/connection/ConnectionListener;", "()Lokhttp3/internal/connection/ConnectionListener;", "n", "Lokhttp3/internal/http2/Http2Connection;", "http2Connection", "Z", "()Z", "z", "(Z)V", "noNewExchanges", "noCoalescedConnections", "()I", "setRouteFailureCount$okhttp", "(I)V", "routeFailureCount", "successCount", "s", "refusedStreamCount", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "allocationLimit", StringUtils.EMPTY, "Ljava/lang/ref/Reference;", "Ljava/util/List;", "()Ljava/util/List;", "calls", StringUtils.EMPTY, "J", "()J", "y", "(J)V", "idleAtNs", "isMultiplexed", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nRealConnection.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RealConnection.kt\nokhttp3/internal/connection/RealConnection\n+ 2 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,511:1\n63#2:512\n63#2:513\n63#2:514\n55#2,4:515\n55#2,4:522\n49#2,4:526\n63#2:530\n63#2:531\n63#2:532\n1761#3,3:519\n*S KotlinDebug\n*F\n+ 1 RealConnection.kt\nokhttp3/internal/connection/RealConnection\n*L\n141#1:512\n149#1:513\n155#1:514\n193#1:515,4\n249#1:522,4\n326#1:526,4\n343#1:530\n362#1:531\n406#1:532\n242#1:519,3\n*E\n"})
public final class RealConnection extends Http2Connection.Listener implements Connection, ExchangeCodec.Carrier, Lockable {
    public static final Companion w = new Companion(null);
    private final TaskRunner c;
    private final RealConnectionPool d;
    private final Route e;
    private final Socket f;
    private final Socket g;
    private final Handshake h;
    private final Protocol i;
    private final BufferedSource j;
    private final BufferedSink k;
    private final int l;
    private final ConnectionListener m;
    private Http2Connection n;
    private boolean o;
    private boolean p;
    private int q;
    private int r;
    private int s;
    private int t;
    private final List u;
    private long v;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0014\u0010\u0005\u001a\u00020\u00048\u0006X\u0086T¢\u0006\u0006\n\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lokhttp3/internal/connection/RealConnection$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "IDLE_CONNECTION_HEALTHY_NS", "J", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    public RealConnection(TaskRunner taskRunner, RealConnectionPool realConnectionPool, Route route, Socket socket, Socket socket2, Handshake handshake, Protocol protocol, BufferedSource bufferedSource, BufferedSink bufferedSink, int i, ConnectionListener connectionListener) {
        Intrinsics.checkNotNullParameter(taskRunner, ap.a(624592063));
        Intrinsics.checkNotNullParameter(realConnectionPool, ap.a(1229198545));
        Intrinsics.checkNotNullParameter(route, ap.a(1069019872));
        Intrinsics.checkNotNullParameter(socket, ap.a(189308224));
        Intrinsics.checkNotNullParameter(socket2, ap.a(1320234882));
        Intrinsics.checkNotNullParameter(protocol, ap.a(122533731));
        Intrinsics.checkNotNullParameter(bufferedSource, ap.a(440820504));
        Intrinsics.checkNotNullParameter(bufferedSink, ap.a(1013103847));
        Intrinsics.checkNotNullParameter(connectionListener, ap.a(45120140));
        this.c = taskRunner;
        this.d = realConnectionPool;
        this.e = route;
        this.f = socket;
        this.g = socket2;
        this.h = handshake;
        this.i = protocol;
        this.j = bufferedSource;
        this.k = bufferedSink;
        this.l = i;
        this.m = connectionListener;
        this.t = 1;
        this.u = new ArrayList();
        this.v = Long.MAX_VALUE;
    }

    private final void C() throws SocketException {
        this.g.setSoTimeout(0);
        Object obj = this.m;
        FlowControlListener flowControlListener = obj instanceof FlowControlListener ? (FlowControlListener) obj : null;
        if (flowControlListener == null) {
            flowControlListener = FlowControlListener.None.a;
        }
        Http2Connection http2ConnectionA = new Http2Connection.Builder(true, this.c).s(this.g, e().a().l().g(), this.j, this.k).m(this).n(this.l).b(flowControlListener).a();
        this.n = http2ConnectionA;
        this.t = Http2Connection.D.a().d();
        Http2Connection.H1(http2ConnectionA, false, 1, null);
    }

    private final boolean D(HttpUrl httpUrl) {
        Handshake handshake;
        if (!_UtilJvmKt.b || Thread.holdsLock(this)) {
            HttpUrl httpUrlL = e().a().l();
            if (httpUrl.l() != httpUrlL.l()) {
                return false;
            }
            if (Intrinsics.areEqual(httpUrl.g(), httpUrlL.g())) {
                return true;
            }
            return (this.p || (handshake = this.h) == null || !f(httpUrl, handshake)) ? false : true;
        }
        throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
    }

    private final boolean f(HttpUrl httpUrl, Handshake handshake) {
        List listE = handshake.e();
        if (!listE.isEmpty()) {
            OkHostnameVerifier okHostnameVerifier = OkHostnameVerifier.a;
            String strG = httpUrl.g();
            Object obj = listE.get(0);
            Intrinsics.checkNotNull(obj, "null cannot be cast to non-null type java.security.cert.X509Certificate");
            if (okHostnameVerifier.e(strG, (X509Certificate) obj)) {
                return true;
            }
        }
        return false;
    }

    private final boolean x(List list) {
        List<Route> list2 = list;
        if ((list2 instanceof Collection) && list2.isEmpty()) {
            return false;
        }
        for (Route route : list2) {
            Proxy.Type type = route.b().type();
            Proxy.Type type2 = Proxy.Type.DIRECT;
            if (type == type2 && e().b().type() == type2 && Intrinsics.areEqual(e().d(), route.d())) {
                return true;
            }
        }
        return false;
    }

    public Socket A() {
        return this.g;
    }

    public final void B() throws SocketException {
        this.v = System.nanoTime();
        Protocol protocol = this.i;
        if (protocol == Protocol.f || protocol == Protocol.g) {
            C();
        }
    }

    @Override // okhttp3.Connection
    public Protocol a() {
        return this.i;
    }

    @Override // okhttp3.internal.http2.Http2Connection.Listener
    public void b(Http2Connection http2Connection, Settings settings) {
        Intrinsics.checkNotNullParameter(http2Connection, "connection");
        Intrinsics.checkNotNullParameter(settings, "settings");
        synchronized (this) {
            try {
                int i = this.t;
                int iD = settings.d();
                this.t = iD;
                if (iD < i) {
                    this.d.n(e().a());
                } else if (iD > i) {
                    this.d.m();
                }
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // okhttp3.internal.http.ExchangeCodec.Carrier
    public void c() {
        synchronized (this) {
            this.o = true;
            Unit unit = Unit.INSTANCE;
        }
        this.m.h(this);
    }

    @Override // okhttp3.internal.http.ExchangeCodec.Carrier
    public void cancel() {
        _UtilJvmKt.h(this.f);
    }

    @Override // okhttp3.internal.http2.Http2Connection.Listener
    public void d(Http2Stream http2Stream) {
        Intrinsics.checkNotNullParameter(http2Stream, "stream");
        http2Stream.e(ErrorCode.j, null);
    }

    @Override // okhttp3.internal.http.ExchangeCodec.Carrier
    public Route e() {
        return this.e;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x004c  */
    @Override // okhttp3.internal.http.ExchangeCodec.Carrier
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void g(okhttp3.internal.connection.RealCall r4, java.io.IOException r5) {
        /*
            r3 = this;
            java.lang.String r0 = "call"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r0)
            monitor-enter(r3)
            boolean r0 = r5 instanceof okhttp3.internal.http2.StreamResetException     // Catch: java.lang.Throwable -> L26
            r1 = 1
            if (r0 == 0) goto L41
            r0 = r5
            okhttp3.internal.http2.StreamResetException r0 = (okhttp3.internal.http2.StreamResetException) r0     // Catch: java.lang.Throwable -> L26
            okhttp3.internal.http2.ErrorCode r0 = r0.a     // Catch: java.lang.Throwable -> L26
            okhttp3.internal.http2.ErrorCode r2 = okhttp3.internal.http2.ErrorCode.j     // Catch: java.lang.Throwable -> L26
            if (r0 != r2) goto L28
            int r4 = r3.s     // Catch: java.lang.Throwable -> L26
            int r4 = r4 + r1
            r3.s = r4     // Catch: java.lang.Throwable -> L26
            if (r4 <= r1) goto L4c
            boolean r4 = r3.o     // Catch: java.lang.Throwable -> L26
            r4 = r4 ^ r1
            r3.o = r1     // Catch: java.lang.Throwable -> L26
            int r5 = r3.q     // Catch: java.lang.Throwable -> L26
            int r5 = r5 + r1
            r3.q = r5     // Catch: java.lang.Throwable -> L26
            goto L6a
        L26:
            r4 = move-exception
            goto L75
        L28:
            okhttp3.internal.http2.StreamResetException r5 = (okhttp3.internal.http2.StreamResetException) r5     // Catch: java.lang.Throwable -> L26
            okhttp3.internal.http2.ErrorCode r5 = r5.a     // Catch: java.lang.Throwable -> L26
            okhttp3.internal.http2.ErrorCode r0 = okhttp3.internal.http2.ErrorCode.k     // Catch: java.lang.Throwable -> L26
            if (r5 != r0) goto L36
            boolean r4 = r4.isCanceled()     // Catch: java.lang.Throwable -> L26
            if (r4 != 0) goto L4c
        L36:
            boolean r4 = r3.o     // Catch: java.lang.Throwable -> L26
            r4 = r4 ^ r1
            r3.o = r1     // Catch: java.lang.Throwable -> L26
            int r5 = r3.q     // Catch: java.lang.Throwable -> L26
            int r5 = r5 + r1
            r3.q = r5     // Catch: java.lang.Throwable -> L26
            goto L6a
        L41:
            boolean r0 = r3.s()     // Catch: java.lang.Throwable -> L26
            if (r0 == 0) goto L4e
            boolean r0 = r5 instanceof okhttp3.internal.http2.ConnectionShutdownException     // Catch: java.lang.Throwable -> L26
            if (r0 == 0) goto L4c
            goto L4e
        L4c:
            r4 = 0
            goto L6a
        L4e:
            boolean r0 = r3.o     // Catch: java.lang.Throwable -> L26
            r0 = r0 ^ r1
            r3.o = r1     // Catch: java.lang.Throwable -> L26
            int r2 = r3.r     // Catch: java.lang.Throwable -> L26
            if (r2 != 0) goto L69
            if (r5 == 0) goto L64
            okhttp3.OkHttpClient r4 = r4.j()     // Catch: java.lang.Throwable -> L26
            okhttp3.Route r2 = r3.e()     // Catch: java.lang.Throwable -> L26
            r3.h(r4, r2, r5)     // Catch: java.lang.Throwable -> L26
        L64:
            int r4 = r3.q     // Catch: java.lang.Throwable -> L26
            int r4 = r4 + r1
            r3.q = r4     // Catch: java.lang.Throwable -> L26
        L69:
            r4 = r0
        L6a:
            kotlin.Unit r5 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L26
            monitor-exit(r3)
            if (r4 == 0) goto L74
            okhttp3.internal.connection.ConnectionListener r4 = r3.m
            r4.h(r3)
        L74:
            return
        L75:
            monitor-exit(r3)
            throw r4
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.connection.RealConnection.g(okhttp3.internal.connection.RealCall, java.io.IOException):void");
    }

    public final void h(OkHttpClient okHttpClient, Route route, IOException iOException) {
        Intrinsics.checkNotNullParameter(okHttpClient, "client");
        Intrinsics.checkNotNullParameter(route, "failedRoute");
        Intrinsics.checkNotNullParameter(iOException, "failure");
        if (route.b().type() != Proxy.Type.DIRECT) {
            Address addressA = route.a();
            addressA.i().connectFailed(addressA.l().t(), route.b().address(), iOException);
        }
        okHttpClient.v().b(route);
    }

    public final int i() {
        return this.t;
    }

    public final List j() {
        return this.u;
    }

    public final ConnectionListener k() {
        return this.m;
    }

    public final long l() {
        return this.v;
    }

    public final boolean m() {
        return this.o;
    }

    public final int n() {
        return this.q;
    }

    public Handshake o() {
        return this.h;
    }

    public final void p() {
        synchronized (this) {
            this.r++;
        }
    }

    public final boolean q(Address address, List list) {
        Intrinsics.checkNotNullParameter(address, "address");
        if (_UtilJvmKt.b && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
        }
        if (this.u.size() >= this.t || this.o || !e().a().d(address)) {
            return false;
        }
        if (Intrinsics.areEqual(address.l().g(), w().a().l().g())) {
            return true;
        }
        if (this.n == null || list == null || !x(list) || address.e() != OkHostnameVerifier.a || !D(address.l())) {
            return false;
        }
        try {
            CertificatePinner certificatePinnerA = address.a();
            Intrinsics.checkNotNull(certificatePinnerA);
            String strG = address.l().g();
            Handshake handshakeO = o();
            Intrinsics.checkNotNull(handshakeO);
            certificatePinnerA.b(strG, handshakeO.e());
            return true;
        } catch (SSLPeerUnverifiedException unused) {
            return false;
        }
    }

    public final boolean r(boolean z) {
        long j;
        if (_UtilJvmKt.b && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
        }
        long jNanoTime = System.nanoTime();
        if (this.f.isClosed() || this.g.isClosed() || this.g.isInputShutdown() || this.g.isOutputShutdown()) {
            return false;
        }
        Http2Connection http2Connection = this.n;
        if (http2Connection != null) {
            return http2Connection.M0(jNanoTime);
        }
        synchronized (this) {
            j = jNanoTime - this.v;
        }
        if (j < 10000000000L || !z) {
            return true;
        }
        return _UtilJvmKt.m(this.g, this.j);
    }

    public final boolean s() {
        return this.n != null;
    }

    public final ExchangeCodec t(OkHttpClient okHttpClient, RealInterceptorChain realInterceptorChain) {
        Intrinsics.checkNotNullParameter(okHttpClient, "client");
        Intrinsics.checkNotNullParameter(realInterceptorChain, "chain");
        Socket socket = this.g;
        BufferedSource bufferedSource = this.j;
        BufferedSink bufferedSink = this.k;
        Http2Connection http2Connection = this.n;
        if (http2Connection != null) {
            return new Http2ExchangeCodec(okHttpClient, this, realInterceptorChain, http2Connection);
        }
        socket.setSoTimeout(realInterceptorChain.k());
        Timeout timeout = bufferedSource.timeout();
        long jH = realInterceptorChain.h();
        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
        timeout.h(jH, timeUnit);
        bufferedSink.timeout().h(realInterceptorChain.j(), timeUnit);
        return new Http1ExchangeCodec(okHttpClient, this, bufferedSource, bufferedSink);
    }

    public String toString() {
        Object objB;
        StringBuilder sb = new StringBuilder();
        sb.append("Connection{");
        sb.append(e().a().l().g());
        sb.append(AbstractJsonLexerKt.COLON);
        sb.append(e().a().l().l());
        sb.append(", proxy=");
        sb.append(e().b());
        sb.append(" hostAddress=");
        sb.append(e().d());
        sb.append(" cipherSuite=");
        Handshake handshake = this.h;
        if (handshake == null || (objB = handshake.b()) == null) {
            objB = "none";
        }
        sb.append(objB);
        sb.append(" protocol=");
        sb.append(this.i);
        sb.append(AbstractJsonLexerKt.END_OBJ);
        return sb.toString();
    }

    public final RealWebSocket.Streams u(final Exchange exchange) throws SocketException {
        Intrinsics.checkNotNullParameter(exchange, "exchange");
        this.g.setSoTimeout(0);
        c();
        final BufferedSource bufferedSource = this.j;
        final BufferedSink bufferedSink = this.k;
        return new RealWebSocket.Streams(bufferedSource, bufferedSink) { // from class: okhttp3.internal.connection.RealConnection$newWebSocketStreams$1
            @Override // java.io.Closeable, java.lang.AutoCloseable
            public void close() {
                exchange.b(-1L, true, true, null);
            }

            @Override // okhttp3.internal.ws.RealWebSocket.Streams
            public void j() {
                exchange.d();
            }
        };
    }

    public final void v() {
        synchronized (this) {
            this.p = true;
            Unit unit = Unit.INSTANCE;
        }
    }

    public Route w() {
        return e();
    }

    public final void y(long j) {
        this.v = j;
    }

    public final void z(boolean z) {
        this.o = z;
    }
}