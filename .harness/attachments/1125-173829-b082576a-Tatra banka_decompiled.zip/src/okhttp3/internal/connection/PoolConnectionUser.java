package okhttp3.internal.connection;

import h.ap;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.Connection;
import okhttp3.Handshake;
import okhttp3.HttpUrl;
import okhttp3.Protocol;
import okhttp3.Route;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000~\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0007\u0010\bJ\u0017\u0010\t\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\t\u0010\bJ\u0017\u0010\f\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\f\u0010\rJ\u0017\u0010\u000e\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\u000e\u0010\rJ\u000f\u0010\u000f\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u000f\u0010\u0003J\u0019\u0010\u0012\u001a\u00020\u00062\b\u0010\u0011\u001a\u0004\u0018\u00010\u0010H\u0016¢\u0006\u0004\b\u0012\u0010\u0013J!\u0010\u0016\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\n2\b\u0010\u0015\u001a\u0004\u0018\u00010\u0014H\u0016¢\u0006\u0004\b\u0016\u0010\u0017J\u001f\u0010\u001a\u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\u00182\u0006\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\u001a\u0010\u001bJ)\u0010\u001e\u001a\u00020\u00062\u0006\u0010\u000b\u001a\u00020\n2\b\u0010\u0015\u001a\u0004\u0018\u00010\u00142\u0006\u0010\u001d\u001a\u00020\u001cH\u0016¢\u0006\u0004\b\u001e\u0010\u001fJ\u0017\u0010 \u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\u0018H\u0016¢\u0006\u0004\b \u0010!J\u0017\u0010#\u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\"H\u0016¢\u0006\u0004\b#\u0010$J\u0011\u0010&\u001a\u0004\u0018\u00010%H\u0016¢\u0006\u0004\b&\u0010'J\u0017\u0010\u001d\u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\u0018H\u0016¢\u0006\u0004\b\u001d\u0010!J\u0017\u0010(\u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\"H\u0016¢\u0006\u0004\b(\u0010$J\u0017\u0010)\u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\"H\u0016¢\u0006\u0004\b)\u0010$J\u0017\u0010*\u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\"H\u0016¢\u0006\u0004\b*\u0010$J\u0017\u0010+\u001a\u00020\u00062\u0006\u0010\u0019\u001a\u00020\"H\u0016¢\u0006\u0004\b+\u0010$J\u000f\u0010-\u001a\u00020,H\u0016¢\u0006\u0004\b-\u0010.J\u000f\u0010/\u001a\u00020,H\u0016¢\u0006\u0004\b/\u0010.J\u0011\u00100\u001a\u0004\u0018\u00010\"H\u0016¢\u0006\u0004\b0\u00101J\u0017\u00104\u001a\u00020\u00062\u0006\u00103\u001a\u000202H\u0016¢\u0006\u0004\b4\u00105J%\u00109\u001a\u00020\u00062\u0006\u00103\u001a\u0002022\f\u00108\u001a\b\u0012\u0004\u0012\u00020706H\u0016¢\u0006\u0004\b9\u0010:J\u0017\u0010=\u001a\u00020\u00062\u0006\u0010<\u001a\u00020;H\u0016¢\u0006\u0004\b=\u0010>J%\u0010A\u001a\u00020\u00062\u0006\u0010<\u001a\u00020;2\f\u0010@\u001a\b\u0012\u0004\u0012\u00020?06H\u0016¢\u0006\u0004\bA\u0010B¨\u0006C"}, d2 = {"Lokhttp3/internal/connection/PoolConnectionUser;", "Lokhttp3/internal/connection/ConnectionUser;", "<init>", "()V", "Lokhttp3/internal/connection/ConnectPlan;", "connectPlan", StringUtils.EMPTY, OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "(Lokhttp3/internal/connection/ConnectPlan;)V", "r", "Lokhttp3/Route;", "route", "u", "(Lokhttp3/Route;)V", "v", "i", "Lokhttp3/Handshake;", "handshake", "q", "(Lokhttp3/Handshake;)V", "Lokhttp3/Protocol;", "protocol", "b", "(Lokhttp3/Route;Lokhttp3/Protocol;)V", "Lokhttp3/Connection;", "connection", "n", "(Lokhttp3/Connection;Lokhttp3/Route;)V", "Ljava/io/IOException;", "e", "l", "(Lokhttp3/Route;Lokhttp3/Protocol;Ljava/io/IOException;)V", "k", "(Lokhttp3/Connection;)V", "Lokhttp3/internal/connection/RealConnection;", "f", "(Lokhttp3/internal/connection/RealConnection;)V", "Ljava/net/Socket;", "s", "()Ljava/net/Socket;", "a", "g", "t", "p", StringUtils.EMPTY, "h", "()Z", "isCanceled", "j", "()Lokhttp3/internal/connection/RealConnection;", "Lokhttp3/HttpUrl;", "url", "c", "(Lokhttp3/HttpUrl;)V", StringUtils.EMPTY, "Ljava/net/Proxy;", "proxies", "d", "(Lokhttp3/HttpUrl;Ljava/util/List;)V", StringUtils.EMPTY, "socketHost", "o", "(Ljava/lang/String;)V", "Ljava/net/InetAddress;", "result", "m", "(Ljava/lang/String;Ljava/util/List;)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class PoolConnectionUser implements ConnectionUser {
    public static final PoolConnectionUser a = new PoolConnectionUser();

    private PoolConnectionUser() {
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void a(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, ap.a(229013215));
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void b(Route route, Protocol protocol) {
        Intrinsics.checkNotNullParameter(route, "route");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void c(HttpUrl httpUrl) {
        Intrinsics.checkNotNullParameter(httpUrl, "url");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void d(HttpUrl httpUrl, List list) {
        Intrinsics.checkNotNullParameter(httpUrl, "url");
        Intrinsics.checkNotNullParameter(list, "proxies");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void e(Connection connection) {
        Intrinsics.checkNotNullParameter(connection, "connection");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void f(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void g(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public boolean h() {
        return false;
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void i() {
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public boolean isCanceled() {
        return false;
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public RealConnection j() {
        return null;
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void k(Connection connection) {
        Intrinsics.checkNotNullParameter(connection, "connection");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void l(Route route, Protocol protocol, IOException iOException) {
        Intrinsics.checkNotNullParameter(route, "route");
        Intrinsics.checkNotNullParameter(iOException, "e");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void m(String str, List list) {
        Intrinsics.checkNotNullParameter(str, "socketHost");
        Intrinsics.checkNotNullParameter(list, "result");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void n(Connection connection, Route route) {
        Intrinsics.checkNotNullParameter(connection, "connection");
        Intrinsics.checkNotNullParameter(route, "route");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void o(String str) {
        Intrinsics.checkNotNullParameter(str, "socketHost");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void p(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void q(Handshake handshake) {
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void r(ConnectPlan connectPlan) {
        Intrinsics.checkNotNullParameter(connectPlan, "connectPlan");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public Socket s() {
        return null;
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void t(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void u(Route route) {
        Intrinsics.checkNotNullParameter(route, "route");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void v(Route route) {
        Intrinsics.checkNotNullParameter(route, "route");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void w(ConnectPlan connectPlan) {
        Intrinsics.checkNotNullParameter(connectPlan, "connectPlan");
    }
}