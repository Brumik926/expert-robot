package okhttp3.internal.connection;

import h.ap;
import java.io.IOException;
import java.net.ConnectException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.net.Socket;
import java.net.UnknownServiceException;
import java.security.cert.Certificate;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLPeerUnverifiedException;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import okhttp3.Address;
import okhttp3.CertificatePinner;
import okhttp3.ConnectionSpec;
import okhttp3.Handshake;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.connection.RoutePlanner;
import okhttp3.internal.http.ExchangeCodec;
import okhttp3.internal.http1.Http1ExchangeCodec;
import okhttp3.internal.platform.Platform;
import okhttp3.internal.tls.CertificateChainCleaner;
import okhttp3.internal.tls.OkHostnameVerifier;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Okio;
import okio.Timeout;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000¤\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u001e\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\n\u0018\u0000 r2\u00020\u00012\u00020\u0002:\u0001sB\u0091\u0001\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0007\u0012\u0006\u0010\n\u001a\u00020\u0007\u0012\u0006\u0010\u000b\u001a\u00020\u0007\u0012\u0006\u0010\f\u001a\u00020\u0007\u0012\u0006\u0010\u000e\u001a\u00020\r\u0012\u0006\u0010\u0010\u001a\u00020\u000f\u0012\u0006\u0010\u0012\u001a\u00020\u0011\u0012\u0006\u0010\u0014\u001a\u00020\u0013\u0012\u000e\u0010\u0016\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u0015\u0012\u0006\u0010\u0017\u001a\u00020\u0007\u0012\b\u0010\u0019\u001a\u0004\u0018\u00010\u0018\u0012\u0006\u0010\u001a\u001a\u00020\u0007\u0012\u0006\u0010\u001b\u001a\u00020\r¢\u0006\u0004\b\u001c\u0010\u001dJ9\u0010\u001e\u001a\u00020\u00002\b\b\u0002\u0010\u0017\u001a\u00020\u00072\n\b\u0002\u0010\u0019\u001a\u0004\u0018\u00010\u00182\b\b\u0002\u0010\u001a\u001a\u00020\u00072\b\b\u0002\u0010\u001b\u001a\u00020\rH\u0002¢\u0006\u0004\b\u001e\u0010\u001fJ\u000f\u0010!\u001a\u00020 H\u0002¢\u0006\u0004\b!\u0010\"J\u001f\u0010'\u001a\u00020 2\u0006\u0010$\u001a\u00020#2\u0006\u0010&\u001a\u00020%H\u0002¢\u0006\u0004\b'\u0010(J\u0011\u0010)\u001a\u0004\u0018\u00010\u0018H\u0002¢\u0006\u0004\b)\u0010*J\u000f\u0010,\u001a\u00020+H\u0016¢\u0006\u0004\b,\u0010-J\u000f\u0010.\u001a\u00020+H\u0016¢\u0006\u0004\b.\u0010-J\u000f\u0010/\u001a\u00020+H\u0000¢\u0006\u0004\b/\u0010-J%\u00101\u001a\u00020\u00002\f\u00100\u001a\b\u0012\u0004\u0012\u00020%0\u00152\u0006\u0010$\u001a\u00020#H\u0000¢\u0006\u0004\b1\u00102J'\u00103\u001a\u0004\u0018\u00010\u00002\f\u00100\u001a\b\u0012\u0004\u0012\u00020%0\u00152\u0006\u0010$\u001a\u00020#H\u0000¢\u0006\u0004\b3\u00102J\u000f\u00105\u001a\u000204H\u0016¢\u0006\u0004\b5\u00106J!\u0010;\u001a\u00020 2\u0006\u00108\u001a\u0002072\b\u0010:\u001a\u0004\u0018\u000109H\u0016¢\u0006\u0004\b;\u0010<J\u000f\u0010=\u001a\u00020 H\u0016¢\u0006\u0004\b=\u0010\"J\u000f\u0010>\u001a\u00020 H\u0016¢\u0006\u0004\b>\u0010\"J\u000f\u0010?\u001a\u00020\u0001H\u0016¢\u0006\u0004\b?\u0010@J\r\u0010A\u001a\u00020 ¢\u0006\u0004\bA\u0010\"R\u0014\u0010\u0004\u001a\u00020\u00038\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b?\u0010BR\u0014\u0010\u0006\u001a\u00020\u00058\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b5\u0010CR\u0014\u0010\b\u001a\u00020\u00078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b=\u0010DR\u0014\u0010\t\u001a\u00020\u00078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b.\u0010DR\u0014\u0010\n\u001a\u00020\u00078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b:\u0010DR\u0014\u0010\u000b\u001a\u00020\u00078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b,\u0010DR\u0014\u0010\f\u001a\u00020\u00078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b;\u0010DR\u0014\u0010\u000e\u001a\u00020\r8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bE\u0010FR\u0014\u0010\u0010\u001a\u00020\u000f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bG\u0010HR\u0014\u0010\u0012\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bA\u0010IR\u001a\u0010\u0014\u001a\u00020\u00138\u0016X\u0096\u0004¢\u0006\f\n\u0004\b!\u0010J\u001a\u0004\b:\u0010KR\"\u0010\u0016\u001a\n\u0012\u0004\u0012\u00020\u0013\u0018\u00010\u00158\u0000X\u0080\u0004¢\u0006\f\n\u0004\b'\u0010L\u001a\u0004\bM\u0010NR\u0014\u0010\u0017\u001a\u00020\u00078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bO\u0010DR\u0016\u0010\u0019\u001a\u0004\u0018\u00010\u00188\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bP\u0010QR\u001a\u0010\u001a\u001a\u00020\u00078\u0000X\u0080\u0004¢\u0006\f\n\u0004\b/\u0010D\u001a\u0004\bR\u0010SR\u001a\u0010\u001b\u001a\u00020\r8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u001e\u0010F\u001a\u0004\bT\u0010UR\u0016\u0010W\u001a\u00020\r8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bV\u0010FR\u0018\u0010Z\u001a\u0004\u0018\u00010X8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b)\u0010YR$\u0010_\u001a\u0004\u0018\u00010X8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bM\u0010Y\u001a\u0004\b[\u0010\\\"\u0004\b]\u0010^R\u0018\u0010b\u001a\u0004\u0018\u00010`8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b3\u0010aR\u0018\u0010e\u001a\u0004\u0018\u00010c8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b1\u0010dR\u0016\u0010i\u001a\u00020f8\u0002@\u0002X\u0082.¢\u0006\u0006\n\u0004\bg\u0010hR\u0016\u0010m\u001a\u00020j8\u0002@\u0002X\u0082.¢\u0006\u0006\n\u0004\bk\u0010lR\u0018\u0010p\u001a\u0004\u0018\u0001048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bn\u0010oR\u0014\u0010q\u001a\u00020\r8VX\u0096\u0004¢\u0006\u0006\u001a\u0004\bq\u0010U¨\u0006t"}, d2 = {"Lokhttp3/internal/connection/ConnectPlan;", "Lokhttp3/internal/connection/RoutePlanner$Plan;", "Lokhttp3/internal/http/ExchangeCodec$Carrier;", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", "Lokhttp3/internal/connection/RealConnectionPool;", "connectionPool", StringUtils.EMPTY, "readTimeoutMillis", "writeTimeoutMillis", "socketConnectTimeoutMillis", "socketReadTimeoutMillis", "pingIntervalMillis", StringUtils.EMPTY, "retryOnConnectionFailure", "Lokhttp3/internal/connection/ConnectionUser;", "user", "Lokhttp3/internal/connection/RealRoutePlanner;", "routePlanner", "Lokhttp3/Route;", "route", StringUtils.EMPTY, "routes", "attempt", "Lokhttp3/Request;", "tunnelRequest", "connectionSpecIndex", "isTlsFallback", "<init>", "(Lokhttp3/internal/concurrent/TaskRunner;Lokhttp3/internal/connection/RealConnectionPool;IIIIIZLokhttp3/internal/connection/ConnectionUser;Lokhttp3/internal/connection/RealRoutePlanner;Lokhttp3/Route;Ljava/util/List;ILokhttp3/Request;IZ)V", "p", "(ILokhttp3/Request;IZ)Lokhttp3/internal/connection/ConnectPlan;", StringUtils.EMPTY, "k", "()V", "Ljavax/net/ssl/SSLSocket;", "sslSocket", "Lokhttp3/ConnectionSpec;", "connectionSpec", "l", "(Ljavax/net/ssl/SSLSocket;Lokhttp3/ConnectionSpec;)V", "r", "()Lokhttp3/Request;", "Lokhttp3/internal/connection/RoutePlanner$ConnectResult;", "f", "()Lokhttp3/internal/connection/RoutePlanner$ConnectResult;", "d", "o", "connectionSpecs", "u", "(Ljava/util/List;Ljavax/net/ssl/SSLSocket;)Lokhttp3/internal/connection/ConnectPlan;", "t", "Lokhttp3/internal/connection/RealConnection;", "b", "()Lokhttp3/internal/connection/RealConnection;", "Lokhttp3/internal/connection/RealCall;", "call", "Ljava/io/IOException;", "e", "g", "(Lokhttp3/internal/connection/RealCall;Ljava/io/IOException;)V", "c", "cancel", "a", "()Lokhttp3/internal/connection/RoutePlanner$Plan;", "j", "Lokhttp3/internal/concurrent/TaskRunner;", "Lokhttp3/internal/connection/RealConnectionPool;", "I", "h", "Z", "i", "Lokhttp3/internal/connection/ConnectionUser;", "Lokhttp3/internal/connection/RealRoutePlanner;", "Lokhttp3/Route;", "()Lokhttp3/Route;", "Ljava/util/List;", "s", "()Ljava/util/List;", "m", "n", "Lokhttp3/Request;", "getConnectionSpecIndex$okhttp", "()I", "isTlsFallback$okhttp", "()Z", "q", "canceled", "Ljava/net/Socket;", "Ljava/net/Socket;", "rawSocket", "getSocket$okhttp", "()Ljava/net/Socket;", "setSocket$okhttp", "(Ljava/net/Socket;)V", "socket", "Lokhttp3/Handshake;", "Lokhttp3/Handshake;", "handshake", "Lokhttp3/Protocol;", "Lokhttp3/Protocol;", "protocol", "Lokio/BufferedSource;", "v", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "Lokio/BufferedSink;", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "Lokio/BufferedSink;", "sink", "x", "Lokhttp3/internal/connection/RealConnection;", "connection", "isReady", "y", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nConnectPlan.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ConnectPlan.kt\nokhttp3/internal/connection/ConnectPlan\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,570:1\n1#2:571\n63#3:572\n1563#4:573\n1634#4,3:574\n*S KotlinDebug\n*F\n+ 1 ConnectPlan.kt\nokhttp3/internal/connection/ConnectPlan\n*L\n514#1:572\n397#1:573\n397#1:574,3\n*E\n"})
public final class ConnectPlan implements RoutePlanner.Plan, ExchangeCodec.Carrier {
    public static final Companion y = new Companion(null);
    private final TaskRunner a;
    private final RealConnectionPool b;
    private final int c;
    private final int d;
    private final int e;
    private final int f;
    private final int g;
    private final boolean h;
    private final ConnectionUser i;
    private final RealRoutePlanner j;
    private final Route k;
    private final List l;
    private final int m;
    private final Request n;
    private final int o;
    private final boolean p;
    private volatile boolean q;
    private Socket r;
    private Socket s;
    private Handshake t;
    private Protocol u;
    private BufferedSource v;
    private BufferedSink w;
    private RealConnection x;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000¨\u0006\b"}, d2 = {"Lokhttp3/internal/connection/ConnectPlan$Companion;", StringUtils.EMPTY, "<init>", "()V", "NPE_THROW_WITH_NULL", StringUtils.EMPTY, "MAX_TUNNEL_ATTEMPTS", StringUtils.EMPTY, "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(k = 3, mv = {2, 2, 0}, xi = 48)
    public static final /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[Proxy.Type.values().length];
            try {
                iArr[Proxy.Type.DIRECT.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[Proxy.Type.HTTP.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            a = iArr;
        }
    }

    public ConnectPlan(TaskRunner taskRunner, RealConnectionPool realConnectionPool, int i, int i2, int i3, int i4, int i5, boolean z, ConnectionUser connectionUser, RealRoutePlanner realRoutePlanner, Route route, List list, int i6, Request request, int i7, boolean z2) {
        Intrinsics.checkNotNullParameter(taskRunner, ap.a(1565119760));
        Intrinsics.checkNotNullParameter(realConnectionPool, ap.a(735368954));
        Intrinsics.checkNotNullParameter(connectionUser, ap.a(292957087));
        Intrinsics.checkNotNullParameter(realRoutePlanner, ap.a(1514691399));
        Intrinsics.checkNotNullParameter(route, ap.a(1393351896));
        this.a = taskRunner;
        this.b = realConnectionPool;
        this.c = i;
        this.d = i2;
        this.e = i3;
        this.f = i4;
        this.g = i5;
        this.h = z;
        this.i = connectionUser;
        this.j = realRoutePlanner;
        this.k = route;
        this.l = list;
        this.m = i6;
        this.n = request;
        this.o = i7;
        this.p = z2;
    }

    private final void k() throws IOException {
        Socket socketCreateSocket;
        Proxy.Type type = e().b().type();
        int i = type == null ? -1 : WhenMappings.a[type.ordinal()];
        if (i == 1 || i == 2) {
            socketCreateSocket = e().a().j().createSocket();
            Intrinsics.checkNotNull(socketCreateSocket);
        } else {
            socketCreateSocket = new Socket(e().b());
        }
        this.r = socketCreateSocket;
        if (this.q) {
            throw new IOException("canceled");
        }
        socketCreateSocket.setSoTimeout(this.f);
        try {
            Platform.a.e().h(socketCreateSocket, e().d(), this.e);
            try {
                this.v = Okio.c(Okio.j(socketCreateSocket));
                this.w = Okio.b(Okio.f(socketCreateSocket));
            } catch (NullPointerException e) {
                if (Intrinsics.areEqual(e.getMessage(), "throw with null exception")) {
                    throw new IOException(e);
                }
            }
        } catch (ConnectException e2) {
            ConnectException connectException = new ConnectException("Failed to connect to " + e().d());
            connectException.initCause(e2);
            throw connectException;
        }
    }

    private final void l(SSLSocket sSLSocket, ConnectionSpec connectionSpec) {
        final Address addressA = e().a();
        try {
            if (connectionSpec.h()) {
                Platform.a.e().g(sSLSocket, addressA.l().g(), addressA.f());
            }
            sSLSocket.startHandshake();
            SSLSession session = sSLSocket.getSession();
            Handshake.Companion companion = Handshake.e;
            Intrinsics.checkNotNull(session);
            final Handshake handshakeC = companion.c(session);
            HostnameVerifier hostnameVerifierE = addressA.e();
            Intrinsics.checkNotNull(hostnameVerifierE);
            if (hostnameVerifierE.verify(addressA.l().g(), session)) {
                final CertificatePinner certificatePinnerA = addressA.a();
                Intrinsics.checkNotNull(certificatePinnerA);
                final Handshake handshake = new Handshake(handshakeC.g(), handshakeC.b(), handshakeC.d(), new Function0() { // from class: okhttp3.internal.connection.a
                    public final Object invoke() {
                        return ConnectPlan.m(certificatePinnerA, handshakeC, addressA);
                    }
                });
                this.t = handshake;
                certificatePinnerA.d(addressA.l().g(), new Function0() { // from class: okhttp3.internal.connection.b
                    public final Object invoke() {
                        return ConnectPlan.n(handshake);
                    }
                });
                String strK = connectionSpec.h() ? Platform.a.e().k(sSLSocket) : null;
                this.s = sSLSocket;
                this.v = Okio.c(Okio.j(sSLSocket));
                this.w = Okio.b(Okio.f(sSLSocket));
                this.u = strK != null ? Protocol.b.a(strK) : Protocol.d;
                Platform.a.e().d(sSLSocket);
                return;
            }
            List listE = handshakeC.e();
            if (listE.isEmpty()) {
                throw new SSLPeerUnverifiedException("Hostname " + addressA.l().g() + " not verified (no certificates)");
            }
            Object obj = listE.get(0);
            Intrinsics.checkNotNull(obj, "null cannot be cast to non-null type java.security.cert.X509Certificate");
            X509Certificate x509Certificate = (X509Certificate) obj;
            throw new SSLPeerUnverifiedException(StringsKt.trimMargin$default("\n            |Hostname " + addressA.l().g() + " not verified:\n            |    certificate: " + CertificatePinner.c.a(x509Certificate) + "\n            |    DN: " + x509Certificate.getSubjectDN().getName() + "\n            |    subjectAltNames: " + OkHostnameVerifier.a.a(x509Certificate) + "\n            ", null, 1, null));
        } catch (Throwable th) {
            Platform.a.e().d(sSLSocket);
            _UtilJvmKt.h(sSLSocket);
            throw th;
        }
    }

    private static final List m(CertificatePinner certificatePinner, Handshake handshake, Address address) {
        CertificateChainCleaner certificateChainCleanerF = certificatePinner.f();
        Intrinsics.checkNotNull(certificateChainCleanerF);
        return certificateChainCleanerF.a(handshake.e(), address.l().g());
    }

    private static final List n(Handshake handshake) {
        List<Certificate> listE = handshake.e();
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(listE, 10));
        for (Certificate certificate : listE) {
            Intrinsics.checkNotNull(certificate, "null cannot be cast to non-null type java.security.cert.X509Certificate");
            arrayList.add((X509Certificate) certificate);
        }
        return arrayList;
    }

    private final ConnectPlan p(int i, Request request, int i2, boolean z) {
        return new ConnectPlan(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, e(), this.l, i, request, i2, z);
    }

    static /* synthetic */ ConnectPlan q(ConnectPlan connectPlan, int i, Request request, int i2, boolean z, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i = connectPlan.m;
        }
        if ((i3 & 2) != 0) {
            request = connectPlan.n;
        }
        if ((i3 & 4) != 0) {
            i2 = connectPlan.o;
        }
        if ((i3 & 8) != 0) {
            z = connectPlan.p;
        }
        return connectPlan.p(i, request, i2, z);
    }

    private final Request r() throws IOException {
        Request request = this.n;
        Intrinsics.checkNotNull(request);
        String str = "CONNECT " + _UtilJvmKt.v(e().a().l(), true) + " HTTP/1.1";
        while (true) {
            BufferedSource bufferedSource = this.v;
            if (bufferedSource == null) {
                Intrinsics.throwUninitializedPropertyAccessException(ClimateForcast.SOURCE);
                bufferedSource = null;
            }
            BufferedSink bufferedSink = this.w;
            if (bufferedSink == null) {
                Intrinsics.throwUninitializedPropertyAccessException("sink");
                bufferedSink = null;
            }
            Http1ExchangeCodec http1ExchangeCodec = new Http1ExchangeCodec(null, this, bufferedSource, bufferedSink);
            BufferedSource bufferedSource2 = this.v;
            if (bufferedSource2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException(ClimateForcast.SOURCE);
                bufferedSource2 = null;
            }
            Timeout timeout = bufferedSource2.timeout();
            long j = this.c;
            TimeUnit timeUnit = TimeUnit.MILLISECONDS;
            timeout.h(j, timeUnit);
            BufferedSink bufferedSink2 = this.w;
            if (bufferedSink2 == null) {
                Intrinsics.throwUninitializedPropertyAccessException("sink");
                bufferedSink2 = null;
            }
            bufferedSink2.timeout().h(this.d, timeUnit);
            http1ExchangeCodec.B(request.g(), str);
            http1ExchangeCodec.d();
            Response.Builder builderH = http1ExchangeCodec.h(false);
            Intrinsics.checkNotNull(builderH);
            Response responseC = builderH.q(request).c();
            http1ExchangeCodec.A(responseC);
            int iR = responseC.r();
            if (iR == 200) {
                return null;
            }
            if (iR != 407) {
                throw new IOException("Unexpected response code for CONNECT: " + responseC.r());
            }
            Request requestA = e().a().h().a(e(), responseC);
            if (requestA == null) {
                throw new IOException("Failed to authenticate with proxy");
            }
            if (StringsKt.equals("close", Response.D(responseC, "Connection", null, 2, null), true)) {
                return requestA;
            }
            request = requestA;
        }
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public RoutePlanner.Plan a() {
        return new ConnectPlan(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.i, this.j, e(), this.l, this.m, this.n, this.o, this.p);
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public RealConnection b() {
        this.i.u(e());
        RealConnection realConnection = this.x;
        Intrinsics.checkNotNull(realConnection);
        this.i.n(realConnection, e());
        ReusePlan reusePlanK = this.j.k(this, this.l);
        if (reusePlanK != null) {
            return reusePlanK.h();
        }
        synchronized (realConnection) {
            this.b.l(realConnection);
            this.i.f(realConnection);
            Unit unit = Unit.INSTANCE;
        }
        this.i.k(realConnection);
        this.i.a(realConnection);
        return realConnection;
    }

    @Override // okhttp3.internal.http.ExchangeCodec.Carrier
    public void c() {
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan, okhttp3.internal.http.ExchangeCodec.Carrier
    public void cancel() {
        this.q = true;
        Socket socket = this.r;
        if (socket != null) {
            _UtilJvmKt.h(socket);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:75:0x0192  */
    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public okhttp3.internal.connection.RoutePlanner.ConnectResult d() throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 447
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.connection.ConnectPlan.d():okhttp3.internal.connection.RoutePlanner$ConnectResult");
    }

    @Override // okhttp3.internal.http.ExchangeCodec.Carrier
    public Route e() {
        return this.k;
    }

    /* JADX WARN: Removed duplicated region for block: B:36:0x00aa  */
    /* JADX WARN: Removed duplicated region for block: B:48:? A[ADDED_TO_REGION, REMOVE, SYNTHETIC] */
    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public okhttp3.internal.connection.RoutePlanner.ConnectResult f() throws java.lang.Throwable {
        /*
            r14 = this;
            java.net.Socket r0 = r14.r
            if (r0 != 0) goto Lb2
            okhttp3.internal.connection.ConnectionUser r0 = r14.i
            r0.w(r14)
            r1 = 0
            okhttp3.internal.connection.ConnectionUser r0 = r14.i     // Catch: java.lang.Throwable -> L2f java.io.IOException -> L32
            okhttp3.Route r2 = r14.e()     // Catch: java.lang.Throwable -> L2f java.io.IOException -> L32
            r0.v(r2)     // Catch: java.lang.Throwable -> L2f java.io.IOException -> L32
            r14.k()     // Catch: java.lang.Throwable -> L2f java.io.IOException -> L32
            r1 = 1
            okhttp3.internal.connection.RoutePlanner$ConnectResult r2 = new okhttp3.internal.connection.RoutePlanner$ConnectResult     // Catch: java.lang.Throwable -> L2f java.io.IOException -> L32
            r6 = 6
            r7 = 0
            r4 = 0
            r5 = 0
            r3 = r14
            r2.<init>(r3, r4, r5, r6, r7)     // Catch: java.lang.Throwable -> L27 java.io.IOException -> L2b
            okhttp3.internal.connection.ConnectionUser r14 = r3.i
            r14.r(r3)
            return r2
        L27:
            r0 = move-exception
        L28:
            r14 = r0
            goto La3
        L2b:
            r0 = move-exception
        L2c:
            r14 = r0
            r11 = r14
            goto L35
        L2f:
            r0 = move-exception
            r3 = r14
            goto L28
        L32:
            r0 = move-exception
            r3 = r14
            goto L2c
        L35:
            okhttp3.Route r14 = r3.e()     // Catch: java.lang.Throwable -> L27
            okhttp3.Address r14 = r14.a()     // Catch: java.lang.Throwable -> L27
            java.net.Proxy r14 = r14.g()     // Catch: java.lang.Throwable -> L27
            if (r14 != 0) goto L7e
            okhttp3.Route r14 = r3.e()     // Catch: java.lang.Throwable -> L27
            java.net.Proxy r14 = r14.b()     // Catch: java.lang.Throwable -> L27
            java.net.Proxy$Type r14 = r14.type()     // Catch: java.lang.Throwable -> L27
            java.net.Proxy$Type r0 = java.net.Proxy.Type.DIRECT     // Catch: java.lang.Throwable -> L27
            if (r14 == r0) goto L7e
            okhttp3.Route r14 = r3.e()     // Catch: java.lang.Throwable -> L27
            okhttp3.Address r14 = r14.a()     // Catch: java.lang.Throwable -> L27
            java.net.ProxySelector r14 = r14.i()     // Catch: java.lang.Throwable -> L27
            okhttp3.Route r0 = r3.e()     // Catch: java.lang.Throwable -> L27
            okhttp3.Address r0 = r0.a()     // Catch: java.lang.Throwable -> L27
            okhttp3.HttpUrl r0 = r0.l()     // Catch: java.lang.Throwable -> L27
            java.net.URI r0 = r0.t()     // Catch: java.lang.Throwable -> L27
            okhttp3.Route r2 = r3.e()     // Catch: java.lang.Throwable -> L27
            java.net.Proxy r2 = r2.b()     // Catch: java.lang.Throwable -> L27
            java.net.SocketAddress r2 = r2.address()     // Catch: java.lang.Throwable -> L27
            r14.connectFailed(r0, r2, r11)     // Catch: java.lang.Throwable -> L27
        L7e:
            okhttp3.internal.connection.ConnectionUser r14 = r3.i     // Catch: java.lang.Throwable -> L27
            okhttp3.Route r0 = r3.e()     // Catch: java.lang.Throwable -> L27
            r2 = 0
            r14.l(r0, r2, r11)     // Catch: java.lang.Throwable -> L27
            okhttp3.internal.connection.RoutePlanner$ConnectResult r8 = new okhttp3.internal.connection.RoutePlanner$ConnectResult     // Catch: java.lang.Throwable -> L27
            r12 = 2
            r13 = 0
            r10 = 0
            r9 = r3
            r8.<init>(r9, r10, r11, r12, r13)     // Catch: java.lang.Throwable -> La0
            okhttp3.internal.connection.ConnectionUser r14 = r3.i
            r14.r(r3)
            if (r1 != 0) goto L9f
            java.net.Socket r14 = r3.r
            if (r14 == 0) goto L9f
            okhttp3.internal._UtilJvmKt.h(r14)
        L9f:
            return r8
        La0:
            r0 = move-exception
            r3 = r9
            goto L28
        La3:
            okhttp3.internal.connection.ConnectionUser r0 = r3.i
            r0.r(r3)
            if (r1 != 0) goto Lb1
            java.net.Socket r0 = r3.r
            if (r0 == 0) goto Lb1
            okhttp3.internal._UtilJvmKt.h(r0)
        Lb1:
            throw r14
        Lb2:
            java.lang.IllegalStateException r14 = new java.lang.IllegalStateException
            java.lang.String r0 = "TCP already connected"
            r14.<init>(r0)
            throw r14
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.connection.ConnectPlan.f():okhttp3.internal.connection.RoutePlanner$ConnectResult");
    }

    @Override // okhttp3.internal.http.ExchangeCodec.Carrier
    public void g(RealCall realCall, IOException iOException) {
        Intrinsics.checkNotNullParameter(realCall, "call");
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public boolean isReady() {
        return this.u != null;
    }

    public final void j() {
        Socket socket = this.s;
        if (socket != null) {
            _UtilJvmKt.h(socket);
        }
    }

    public final RoutePlanner.ConnectResult o() throws IOException {
        Request requestR = r();
        if (requestR == null) {
            return new RoutePlanner.ConnectResult(this, null, null, 6, null);
        }
        Socket socket = this.r;
        if (socket != null) {
            _UtilJvmKt.h(socket);
        }
        int i = this.m + 1;
        if (i < 21) {
            this.i.b(e(), null);
            return new RoutePlanner.ConnectResult(this, q(this, i, requestR, 0, false, 12, null), null, 4, null);
        }
        ProtocolException protocolException = new ProtocolException("Too many tunnel connections attempted: 21");
        this.i.l(e(), null, protocolException);
        return new RoutePlanner.ConnectResult(this, null, protocolException, 2, null);
    }

    public final List s() {
        return this.l;
    }

    public final ConnectPlan t(List list, SSLSocket sSLSocket) {
        Intrinsics.checkNotNullParameter(list, "connectionSpecs");
        Intrinsics.checkNotNullParameter(sSLSocket, "sslSocket");
        int i = this.o + 1;
        int size = list.size();
        for (int i2 = i; i2 < size; i2++) {
            if (((ConnectionSpec) list.get(i2)).e(sSLSocket)) {
                return q(this, 0, null, i2, this.o != -1, 3, null);
            }
        }
        return null;
    }

    public final ConnectPlan u(List list, SSLSocket sSLSocket) throws UnknownServiceException {
        Intrinsics.checkNotNullParameter(list, "connectionSpecs");
        Intrinsics.checkNotNullParameter(sSLSocket, "sslSocket");
        if (this.o != -1) {
            return this;
        }
        ConnectPlan connectPlanT = t(list, sSLSocket);
        if (connectPlanT != null) {
            return connectPlanT;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Unable to find acceptable protocols. isFallback=");
        sb.append(this.p);
        sb.append(", modes=");
        sb.append(list);
        sb.append(", supported protocols=");
        String[] enabledProtocols = sSLSocket.getEnabledProtocols();
        Intrinsics.checkNotNull(enabledProtocols);
        String string = Arrays.toString(enabledProtocols);
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        sb.append(string);
        throw new UnknownServiceException(sb.toString());
    }
}