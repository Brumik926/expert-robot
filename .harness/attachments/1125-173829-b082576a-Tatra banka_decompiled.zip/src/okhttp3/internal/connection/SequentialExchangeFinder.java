package okhttp3.internal.connection;

import h.ap;
import java.io.IOException;
import kotlin.ExceptionsKt;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal.connection.RoutePlanner;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u0007\u0010\bR\u001a\u0010\u0003\u001a\u00020\u00028\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u0007\u0010\t\u001a\u0004\b\n\u0010\u000b¨\u0006\f"}, d2 = {"Lokhttp3/internal/connection/SequentialExchangeFinder;", "Lokhttp3/internal/connection/ExchangeFinder;", "Lokhttp3/internal/connection/RoutePlanner;", "routePlanner", "<init>", "(Lokhttp3/internal/connection/RoutePlanner;)V", "Lokhttp3/internal/connection/RealConnection;", "a", "()Lokhttp3/internal/connection/RealConnection;", "Lokhttp3/internal/connection/RoutePlanner;", "b", "()Lokhttp3/internal/connection/RoutePlanner;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class SequentialExchangeFinder implements ExchangeFinder {
    private final RoutePlanner a;

    public SequentialExchangeFinder(RoutePlanner routePlanner) {
        Intrinsics.checkNotNullParameter(routePlanner, ap.a(1333813208));
        this.a = routePlanner;
    }

    @Override // okhttp3.internal.connection.ExchangeFinder
    public RealConnection a() throws Throwable {
        RoutePlanner.Plan planE;
        IOException iOException = null;
        while (!b().isCanceled()) {
            try {
                planE = b().e();
            } catch (IOException e) {
                if (iOException == null) {
                    iOException = e;
                } else {
                    ExceptionsKt.addSuppressed(iOException, e);
                }
                if (!RoutePlanner.d(b(), null, 1, null)) {
                    throw iOException;
                }
            }
            if (!planE.isReady()) {
                RoutePlanner.ConnectResult connectResultF = planE.f();
                if (connectResultF.f()) {
                    connectResultF = planE.d();
                }
                RoutePlanner.Plan planA = connectResultF.a();
                Throwable thB = connectResultF.b();
                if (thB != null) {
                    throw thB;
                }
                if (planA != null) {
                    b().b().addFirst(planA);
                }
            }
            return planE.b();
        }
        throw new IOException("Canceled");
    }

    @Override // okhttp3.internal.connection.ExchangeFinder
    public RoutePlanner b() {
        return this.a;
    }
}