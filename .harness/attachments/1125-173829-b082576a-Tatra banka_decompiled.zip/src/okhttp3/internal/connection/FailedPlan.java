package okhttp3.internal.connection;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal.connection.RoutePlanner;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0001\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0005\b\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\t\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\t\u0010\bJ\u000f\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\r\u001a\u00020\nH\u0016¢\u0006\u0004\b\r\u0010\fJ\u000f\u0010\u000e\u001a\u00020\nH\u0016¢\u0006\u0004\b\u000e\u0010\fR\u0017\u0010\u0011\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\b\u000f\u0010\u0010\u001a\u0004\b\u0003\u0010\bR\u001a\u0010\u0015\u001a\u00020\u00128\u0016X\u0096D¢\u0006\f\n\u0004\b\u0013\u0010\u0014\u001a\u0004\b\u0015\u0010\u0016¨\u0006\u0017"}, d2 = {"Lokhttp3/internal/connection/FailedPlan;", "Lokhttp3/internal/connection/RoutePlanner$Plan;", StringUtils.EMPTY, "e", "<init>", "(Ljava/lang/Throwable;)V", "Lokhttp3/internal/connection/RoutePlanner$ConnectResult;", "f", "()Lokhttp3/internal/connection/RoutePlanner$ConnectResult;", "d", StringUtils.EMPTY, "g", "()Ljava/lang/Void;", "c", "h", "a", "Lokhttp3/internal/connection/RoutePlanner$ConnectResult;", "result", StringUtils.EMPTY, "b", "Z", "isReady", "()Z", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class FailedPlan implements RoutePlanner.Plan {
    private final RoutePlanner.ConnectResult a;
    private final boolean b;

    public FailedPlan(Throwable th) {
        Intrinsics.checkNotNullParameter(th, ap.a(315885964));
        this.a = new RoutePlanner.ConnectResult(this, null, th, 2, null);
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public /* bridge */ /* synthetic */ RoutePlanner.Plan a() {
        return (RoutePlanner.Plan) h();
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public /* bridge */ /* synthetic */ RealConnection b() {
        return (RealConnection) g();
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan, okhttp3.internal.http.ExchangeCodec.Carrier
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public Void cancel() {
        throw new IllegalStateException("unexpected cancel");
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public RoutePlanner.ConnectResult d() {
        return this.a;
    }

    public final RoutePlanner.ConnectResult e() {
        return this.a;
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public RoutePlanner.ConnectResult f() {
        return this.a;
    }

    public Void g() {
        throw new IllegalStateException("unexpected call");
    }

    public Void h() {
        throw new IllegalStateException("unexpected retry");
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public boolean isReady() {
        return this.b;
    }
}