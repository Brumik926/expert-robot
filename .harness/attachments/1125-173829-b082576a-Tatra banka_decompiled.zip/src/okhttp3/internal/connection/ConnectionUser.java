package okhttp3.internal.connection;

import java.io.IOException;
import java.net.Socket;
import java.util.List;
import kotlin.Metadata;
import okhttp3.Connection;
import okhttp3.Handshake;
import okhttp3.HttpUrl;
import okhttp3.Protocol;
import okhttp3.Route;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000z\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H&¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H&¢\u0006\u0004\b\u0007\u0010\u0006J\u0017\u0010\n\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\bH&¢\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\f\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\bH&¢\u0006\u0004\b\f\u0010\u000bJ\u000f\u0010\r\u001a\u00020\u0004H&¢\u0006\u0004\b\r\u0010\u000eJ\u0019\u0010\u0011\u001a\u00020\u00042\b\u0010\u0010\u001a\u0004\u0018\u00010\u000fH&¢\u0006\u0004\b\u0011\u0010\u0012J!\u0010\u0015\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\b2\b\u0010\u0014\u001a\u0004\u0018\u00010\u0013H&¢\u0006\u0004\b\u0015\u0010\u0016J\u001f\u0010\u0019\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u00172\u0006\u0010\t\u001a\u00020\bH&¢\u0006\u0004\b\u0019\u0010\u001aJ)\u0010\u001d\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\b2\b\u0010\u0014\u001a\u0004\u0018\u00010\u00132\u0006\u0010\u001c\u001a\u00020\u001bH&¢\u0006\u0004\b\u001d\u0010\u001eJ\u0017\u0010\u001f\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0017H&¢\u0006\u0004\b\u001f\u0010 J\u0017\u0010\"\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020!H&¢\u0006\u0004\b\"\u0010#J\u0011\u0010%\u001a\u0004\u0018\u00010$H&¢\u0006\u0004\b%\u0010&J\u0017\u0010\u001c\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020\u0017H&¢\u0006\u0004\b\u001c\u0010 J\u0017\u0010'\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020!H&¢\u0006\u0004\b'\u0010#J\u0017\u0010(\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020!H&¢\u0006\u0004\b(\u0010#J\u0017\u0010)\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020!H&¢\u0006\u0004\b)\u0010#J\u0017\u0010*\u001a\u00020\u00042\u0006\u0010\u0018\u001a\u00020!H&¢\u0006\u0004\b*\u0010#J\u000f\u0010,\u001a\u00020+H&¢\u0006\u0004\b,\u0010-J\u000f\u0010.\u001a\u00020+H&¢\u0006\u0004\b.\u0010-J\u0011\u0010/\u001a\u0004\u0018\u00010!H&¢\u0006\u0004\b/\u00100J\u0017\u00103\u001a\u00020\u00042\u0006\u00102\u001a\u000201H&¢\u0006\u0004\b3\u00104J%\u00108\u001a\u00020\u00042\u0006\u00102\u001a\u0002012\f\u00107\u001a\b\u0012\u0004\u0012\u00020605H&¢\u0006\u0004\b8\u00109J\u0017\u0010<\u001a\u00020\u00042\u0006\u0010;\u001a\u00020:H&¢\u0006\u0004\b<\u0010=J%\u0010@\u001a\u00020\u00042\u0006\u0010;\u001a\u00020:2\f\u0010?\u001a\b\u0012\u0004\u0012\u00020>05H&¢\u0006\u0004\b@\u0010A¨\u0006BÀ\u0006\u0003"}, d2 = {"Lokhttp3/internal/connection/ConnectionUser;", StringUtils.EMPTY, "Lokhttp3/internal/connection/ConnectPlan;", "connectPlan", StringUtils.EMPTY, OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "(Lokhttp3/internal/connection/ConnectPlan;)V", "r", "Lokhttp3/Route;", "route", "u", "(Lokhttp3/Route;)V", "v", "i", "()V", "Lokhttp3/Handshake;", "handshake", "q", "(Lokhttp3/Handshake;)V", "Lokhttp3/Protocol;", "protocol", "b", "(Lokhttp3/Route;Lokhttp3/Protocol;)V", "Lokhttp3/Connection;", "connection", "n", "(Lokhttp3/Connection;Lokhttp3/Route;)V", "Ljava/io/IOException;", "e", "l", "(Lokhttp3/Route;Lokhttp3/Protocol;Ljava/io/IOException;)V", "k", "(Lokhttp3/Connection;)V", "Lokhttp3/internal/connection/RealConnection;", "f", "(Lokhttp3/internal/connection/RealConnection;)V", "Ljava/net/Socket;", "s", "()Ljava/net/Socket;", "a", "g", "t", "p", StringUtils.EMPTY, "h", "()Z", "isCanceled", "j", "()Lokhttp3/internal/connection/RealConnection;", "Lokhttp3/HttpUrl;", "url", "c", "(Lokhttp3/HttpUrl;)V", StringUtils.EMPTY, "Ljava/net/Proxy;", "proxies", "d", "(Lokhttp3/HttpUrl;Ljava/util/List;)V", StringUtils.EMPTY, "socketHost", "o", "(Ljava/lang/String;)V", "Ljava/net/InetAddress;", "result", "m", "(Ljava/lang/String;Ljava/util/List;)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public interface ConnectionUser {
    void a(RealConnection realConnection);

    void b(Route route, Protocol protocol);

    void c(HttpUrl httpUrl);

    void d(HttpUrl httpUrl, List list);

    void e(Connection connection);

    void f(RealConnection realConnection);

    void g(RealConnection realConnection);

    boolean h();

    void i();

    boolean isCanceled();

    RealConnection j();

    void k(Connection connection);

    void l(Route route, Protocol protocol, IOException iOException);

    void m(String str, List list);

    void n(Connection connection, Route route);

    void o(String str);

    void p(RealConnection realConnection);

    void q(Handshake handshake);

    void r(ConnectPlan connectPlan);

    Socket s();

    void t(RealConnection realConnection);

    void u(Route route);

    void v(Route route);

    void w(ConnectPlan connectPlan);
}