package okhttp3.internal.connection;

import h.ap;
import java.util.LinkedHashSet;
import java.util.Set;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.Route;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010#\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0015\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0007\u0010\bJ\u0015\u0010\n\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u0004¢\u0006\u0004\b\n\u0010\bJ\u0015\u0010\f\u001a\u00020\u000b2\u0006\u0010\t\u001a\u00020\u0004¢\u0006\u0004\b\f\u0010\rR\u001a\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00040\u000e8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\n\u0010\u000f¨\u0006\u0011"}, d2 = {"Lokhttp3/internal/connection/RouteDatabase;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/Route;", "failedRoute", StringUtils.EMPTY, "b", "(Lokhttp3/Route;)V", "route", "a", StringUtils.EMPTY, "c", "(Lokhttp3/Route;)Z", StringUtils.EMPTY, "Ljava/util/Set;", "_failedRoutes", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class RouteDatabase {
    private final Set a = new LinkedHashSet();

    public final synchronized void a(Route route) {
        Intrinsics.checkNotNullParameter(route, ap.a(1682309789));
        this.a.remove(route);
    }

    public final synchronized void b(Route route) {
        Intrinsics.checkNotNullParameter(route, "failedRoute");
        this.a.add(route);
    }

    public final synchronized boolean c(Route route) {
        Intrinsics.checkNotNullParameter(route, "route");
        return this.a.contains(route);
    }
}