package okhttp3.internal.connection;

import h.ap;
import java.io.IOException;
import java.net.ProtocolException;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.EventListener;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;
import okhttp3.internal.http.ExchangeCodec;
import okhttp3.internal.http.RealResponseBody;
import okhttp3.internal.ws.RealWebSocket;
import okio.Buffer;
import okio.ForwardingSink;
import okio.ForwardingSource;
import okio.Okio;
import okio.Sink;
import okio.Source;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000v\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0010\t\n\u0002\b\u0019\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u00002\u00020\u0001:\u0002PQB'\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b¢\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\r\u001a\u00020\fH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u0015\u0010\u0013\u001a\u00020\u000e2\u0006\u0010\u0012\u001a\u00020\u0011¢\u0006\u0004\b\u0013\u0010\u0014J\u001d\u0010\r\u001a\u00020\u00172\u0006\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0016\u001a\u00020\u0015¢\u0006\u0004\b\r\u0010\u0018J\r\u0010\u0019\u001a\u00020\u000e¢\u0006\u0004\b\u0019\u0010\u001aJ\r\u0010\u001b\u001a\u00020\u000e¢\u0006\u0004\b\u001b\u0010\u001aJ\r\u0010\u001c\u001a\u00020\u000e¢\u0006\u0004\b\u001c\u0010\u001aJ\u0017\u0010\u001f\u001a\u0004\u0018\u00010\u001e2\u0006\u0010\u001d\u001a\u00020\u0015¢\u0006\u0004\b\u001f\u0010 J\u0015\u0010#\u001a\u00020\u000e2\u0006\u0010\"\u001a\u00020!¢\u0006\u0004\b#\u0010$J\u0015\u0010&\u001a\u00020%2\u0006\u0010\"\u001a\u00020!¢\u0006\u0004\b&\u0010'J\r\u0010)\u001a\u00020(¢\u0006\u0004\b)\u0010*J\r\u0010+\u001a\u00020\u000e¢\u0006\u0004\b+\u0010\u001aJ\r\u0010,\u001a\u00020\u000e¢\u0006\u0004\b,\u0010\u001aJ\r\u0010-\u001a\u00020\u000e¢\u0006\u0004\b-\u0010\u001aJ\r\u0010.\u001a\u00020\u000e¢\u0006\u0004\b.\u0010\u001aJ?\u00104\u001a\u00028\u0000\"\n\b\u0000\u0010/*\u0004\u0018\u00010\f2\b\b\u0002\u00101\u001a\u0002002\b\b\u0002\u00102\u001a\u00020\u00152\b\b\u0002\u00103\u001a\u00020\u00152\u0006\u0010\r\u001a\u00028\u0000¢\u0006\u0004\b4\u00105J\r\u00106\u001a\u00020\u000e¢\u0006\u0004\b6\u0010\u001aR\u001a\u0010\u0003\u001a\u00020\u00028\u0000X\u0080\u0004¢\u0006\f\n\u0004\b7\u00108\u001a\u0004\b9\u0010:R\u001a\u0010\u0005\u001a\u00020\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b4\u0010;\u001a\u0004\b<\u0010=R\u001a\u0010\u0007\u001a\u00020\u00068\u0000X\u0080\u0004¢\u0006\f\n\u0004\b>\u0010?\u001a\u0004\b@\u0010AR\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b-\u0010BR$\u0010G\u001a\u00020\u00152\u0006\u0010C\u001a\u00020\u00158\u0000@BX\u0080\u000e¢\u0006\f\n\u0004\b\r\u0010D\u001a\u0004\bE\u0010FR$\u0010I\u001a\u00020\u00152\u0006\u0010C\u001a\u00020\u00158\u0000@BX\u0080\u000e¢\u0006\f\n\u0004\b.\u0010D\u001a\u0004\bH\u0010FR\u0014\u0010M\u001a\u00020J8@X\u0080\u0004¢\u0006\u0006\u001a\u0004\bK\u0010LR\u0014\u0010O\u001a\u00020\u00158@X\u0080\u0004¢\u0006\u0006\u001a\u0004\bN\u0010F¨\u0006R"}, d2 = {"Lokhttp3/internal/connection/Exchange;", StringUtils.EMPTY, "Lokhttp3/internal/connection/RealCall;", "call", "Lokhttp3/EventListener;", "eventListener", "Lokhttp3/internal/connection/ExchangeFinder;", "finder", "Lokhttp3/internal/http/ExchangeCodec;", "codec", "<init>", "(Lokhttp3/internal/connection/RealCall;Lokhttp3/EventListener;Lokhttp3/internal/connection/ExchangeFinder;Lokhttp3/internal/http/ExchangeCodec;)V", "Ljava/io/IOException;", "e", StringUtils.EMPTY, OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "(Ljava/io/IOException;)V", "Lokhttp3/Request;", "request", "y", "(Lokhttp3/Request;)V", StringUtils.EMPTY, "duplex", "Lokio/Sink;", "(Lokhttp3/Request;Z)Lokio/Sink;", "h", "()V", "g", "v", "expectContinue", "Lokhttp3/Response$Builder;", "t", "(Z)Lokhttp3/Response$Builder;", "Lokhttp3/Response;", "response", "u", "(Lokhttp3/Response;)V", "Lokhttp3/ResponseBody;", "s", "(Lokhttp3/Response;)Lokhttp3/ResponseBody;", "Lokhttp3/internal/ws/RealWebSocket$Streams;", "p", "()Lokhttp3/internal/ws/RealWebSocket$Streams;", "x", "q", "d", "f", "E", StringUtils.EMPTY, "bytesRead", "responseDone", "requestDone", "b", "(JZZLjava/io/IOException;)Ljava/io/IOException;", "r", "a", "Lokhttp3/internal/connection/RealCall;", "i", "()Lokhttp3/internal/connection/RealCall;", "Lokhttp3/EventListener;", "k", "()Lokhttp3/EventListener;", "c", "Lokhttp3/internal/connection/ExchangeFinder;", "l", "()Lokhttp3/internal/connection/ExchangeFinder;", "Lokhttp3/internal/http/ExchangeCodec;", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "Z", "o", "()Z", "isDuplex", "m", "hasFailure", "Lokhttp3/internal/connection/RealConnection;", "j", "()Lokhttp3/internal/connection/RealConnection;", "connection", "n", "isCoalescedConnection", "RequestBodySink", "ResponseBodySource", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Exchange {
    private final RealCall a;
    private final EventListener b;
    private final ExchangeFinder c;
    private final ExchangeCodec d;
    private boolean e;
    private boolean f;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0007\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J#\u0010\u000b\u001a\u00028\u0000\"\n\b\u0000\u0010\t*\u0004\u0018\u00010\b2\u0006\u0010\n\u001a\u00028\u0000H\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u001f\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0013\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010\u0015\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0015\u0010\u0014R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0016\u0010\u0017R\u0016\u0010\u001b\u001a\u00020\u00188\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0019\u0010\u001aR\u0016\u0010\u001d\u001a\u00020\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001c\u0010\u0017R\u0016\u0010\u001e\u001a\u00020\u00188\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\n\u0010\u001a¨\u0006\u001f"}, d2 = {"Lokhttp3/internal/connection/Exchange$RequestBodySink;", "Lokio/ForwardingSink;", "Lokio/Sink;", "delegate", StringUtils.EMPTY, "contentLength", "<init>", "(Lokhttp3/internal/connection/Exchange;Lokio/Sink;J)V", "Ljava/io/IOException;", "E", "e", "a", "(Ljava/io/IOException;)Ljava/io/IOException;", "Lokio/Buffer;", ClimateForcast.SOURCE, "byteCount", StringUtils.EMPTY, "a2", "(Lokio/Buffer;J)V", "flush", "()V", "close", "b", "J", StringUtils.EMPTY, "c", "Z", "completed", "d", "bytesReceived", "closed", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nExchange.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Exchange.kt\nokhttp3/internal/connection/Exchange$RequestBodySink\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,369:1\n1#2:370\n*E\n"})
    private final class RequestBodySink extends ForwardingSink {
        private final long b;
        private boolean c;
        private long d;
        private boolean e;
        final /* synthetic */ Exchange f;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public RequestBodySink(Exchange exchange, Sink sink, long j) {
            super(sink);
            Intrinsics.checkNotNullParameter(sink, ap.a(527538394));
            this.f = exchange;
            this.b = j;
        }

        private final IOException a(IOException iOException) {
            if (this.c) {
                return iOException;
            }
            this.c = true;
            return Exchange.c(this.f, this.d, false, true, iOException, 2, null);
        }

        @Override // okio.ForwardingSink, okio.Sink
        public void a2(Buffer buffer, long j) throws IOException {
            Intrinsics.checkNotNullParameter(buffer, ClimateForcast.SOURCE);
            if (this.e) {
                throw new IllegalStateException("closed");
            }
            long j2 = this.b;
            if (j2 == -1 || this.d + j <= j2) {
                try {
                    super.a2(buffer, j);
                    this.d += j;
                    return;
                } catch (IOException e) {
                    throw a(e);
                }
            }
            throw new ProtocolException("expected " + this.b + " bytes but received " + (this.d + j));
        }

        @Override // okio.ForwardingSink, okio.Sink, java.io.Closeable, java.lang.AutoCloseable
        public void close() throws IOException {
            if (this.e) {
                return;
            }
            this.e = true;
            long j = this.b;
            if (j != -1 && this.d != j) {
                throw new ProtocolException("unexpected end of stream");
            }
            try {
                super.close();
            } catch (IOException e) {
                throw a(e);
            }
        }

        @Override // okio.ForwardingSink, okio.Sink, java.io.Flushable
        public void flush() throws IOException {
            try {
                super.flush();
            } catch (IOException e) {
                throw a(e);
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\u0007\b\u0080\u0004\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u001f\u0010\u000b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\n\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\u000e\u001a\u00020\rH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ!\u0010\u0013\u001a\u00028\u0000\"\n\b\u0000\u0010\u0011*\u0004\u0018\u00010\u00102\u0006\u0010\u0012\u001a\u00028\u0000¢\u0006\u0004\b\u0013\u0010\u0014R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010\u0016R\u0016\u0010\u0018\u001a\u00020\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0017\u0010\u0016R\u0016\u0010\u001c\u001a\u00020\u00198\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001a\u0010\u001bR\u0016\u0010\u001d\u001a\u00020\u00198\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0012\u0010\u001bR\u0016\u0010\u001f\u001a\u00020\u00198\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001e\u0010\u001b¨\u0006 "}, d2 = {"Lokhttp3/internal/connection/Exchange$ResponseBodySource;", "Lokio/ForwardingSource;", "Lokio/Source;", "delegate", StringUtils.EMPTY, "contentLength", "<init>", "(Lokhttp3/internal/connection/Exchange;Lokio/Source;J)V", "Lokio/Buffer;", "sink", "byteCount", "k3", "(Lokio/Buffer;J)J", StringUtils.EMPTY, "close", "()V", "Ljava/io/IOException;", "E", "e", "k", "(Ljava/io/IOException;)Ljava/io/IOException;", "b", "J", "c", "bytesReceived", StringUtils.EMPTY, "d", "Z", "invokeStartEvent", "completed", "f", "closed", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nExchange.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Exchange.kt\nokhttp3/internal/connection/Exchange$ResponseBodySource\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,369:1\n1#2:370\n*E\n"})
    public final class ResponseBodySource extends ForwardingSource {
        private final long b;
        private long c;
        private boolean d;
        private boolean e;
        private boolean f;
        final /* synthetic */ Exchange g;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ResponseBodySource(Exchange exchange, Source source, long j) {
            super(source);
            Intrinsics.checkNotNullParameter(source, ap.a(2082592509));
            this.g = exchange;
            this.b = j;
            this.d = true;
            if (j == 0) {
                k(null);
            }
        }

        @Override // okio.ForwardingSource, okio.Source, java.io.Closeable, java.lang.AutoCloseable
        public void close() throws IOException {
            if (this.f) {
                return;
            }
            this.f = true;
            try {
                super.close();
            } catch (IOException e) {
                throw k(e);
            }
        }

        public final IOException k(IOException iOException) {
            if (this.e) {
                return iOException;
            }
            this.e = true;
            if (iOException == null && this.d) {
                this.d = false;
                this.g.k().x(this.g.i());
            }
            return Exchange.c(this.g, this.c, true, false, iOException, 4, null);
        }

        @Override // okio.ForwardingSource, okio.Source
        public long k3(Buffer buffer, long j) throws IOException {
            Intrinsics.checkNotNullParameter(buffer, "sink");
            if (this.f) {
                throw new IllegalStateException("closed");
            }
            try {
                long jK3 = j().k3(buffer, j);
                if (this.d) {
                    this.d = false;
                    this.g.k().x(this.g.i());
                }
                if (jK3 == -1) {
                    k(null);
                    return -1L;
                }
                long j2 = this.c + jK3;
                long j3 = this.b;
                if (j3 != -1 && j2 > j3) {
                    throw new ProtocolException("expected " + this.b + " bytes but received " + j2);
                }
                this.c = j2;
                if (this.g.d.g()) {
                    k(null);
                }
                return jK3;
            } catch (IOException e) {
                throw k(e);
            }
        }
    }

    public Exchange(RealCall realCall, EventListener eventListener, ExchangeFinder exchangeFinder, ExchangeCodec exchangeCodec) {
        Intrinsics.checkNotNullParameter(realCall, ap.a(1520479220));
        Intrinsics.checkNotNullParameter(eventListener, ap.a(806513205));
        Intrinsics.checkNotNullParameter(exchangeFinder, ap.a(1280047905));
        Intrinsics.checkNotNullParameter(exchangeCodec, ap.a(949271488));
        this.a = realCall;
        this.b = eventListener;
        this.c = exchangeFinder;
        this.d = exchangeCodec;
    }

    public static /* synthetic */ IOException c(Exchange exchange, long j, boolean z, boolean z2, IOException iOException, int i, Object obj) {
        if ((i & 1) != 0) {
            j = -1;
        }
        return exchange.b(j, (i & 2) != 0 ? false : z, (i & 4) != 0 ? false : z2, iOException);
    }

    private final void w(IOException iOException) {
        this.f = true;
        this.d.i().g(this.a, iOException);
    }

    public final IOException b(long j, boolean z, boolean z2, IOException iOException) {
        if (iOException != null) {
            w(iOException);
        }
        if (z2) {
            if (iOException != null) {
                this.b.t(this.a, iOException);
            } else {
                this.b.r(this.a, j);
            }
        }
        if (z) {
            if (iOException != null) {
                this.b.y(this.a, iOException);
            } else {
                this.b.w(this.a, j);
            }
        }
        return this.a.s(this, z2, z, iOException);
    }

    public final void d() {
        this.d.cancel();
    }

    public final Sink e(Request request, boolean z) {
        Intrinsics.checkNotNullParameter(request, "request");
        this.e = z;
        RequestBody requestBodyA = request.a();
        Intrinsics.checkNotNull(requestBodyA);
        long jA = requestBodyA.a();
        this.b.s(this.a);
        return new RequestBodySink(this, this.d.b(request, jA), jA);
    }

    public final void f() {
        this.d.cancel();
        this.a.s(this, true, true, null);
    }

    public final void g() throws IOException {
        try {
            this.d.d();
        } catch (IOException e) {
            this.b.t(this.a, e);
            w(e);
            throw e;
        }
    }

    public final void h() throws IOException {
        try {
            this.d.c();
        } catch (IOException e) {
            this.b.t(this.a, e);
            w(e);
            throw e;
        }
    }

    public final RealCall i() {
        return this.a;
    }

    public final RealConnection j() {
        ExchangeCodec.Carrier carrierI = this.d.i();
        RealConnection realConnection = carrierI instanceof RealConnection ? (RealConnection) carrierI : null;
        if (realConnection != null) {
            return realConnection;
        }
        throw new IllegalStateException("no connection for CONNECT tunnels");
    }

    public final EventListener k() {
        return this.b;
    }

    public final ExchangeFinder l() {
        return this.c;
    }

    public final boolean m() {
        return this.f;
    }

    public final boolean n() {
        return !Intrinsics.areEqual(this.c.b().getAddress().l().g(), this.d.i().e().a().l().g());
    }

    public final boolean o() {
        return this.e;
    }

    public final RealWebSocket.Streams p() {
        this.a.y();
        ExchangeCodec.Carrier carrierI = this.d.i();
        Intrinsics.checkNotNull(carrierI, "null cannot be cast to non-null type okhttp3.internal.connection.RealConnection");
        return ((RealConnection) carrierI).u(this);
    }

    public final void q() {
        this.d.i().c();
    }

    public final void r() {
        RealCall.t(this.a, this, true, false, null, 4, null);
    }

    public final ResponseBody s(Response response) throws IOException {
        Intrinsics.checkNotNullParameter(response, "response");
        try {
            String strD = Response.D(response, HttpHeaders.CONTENT_TYPE, null, 2, null);
            long jE = this.d.e(response);
            return new RealResponseBody(strD, jE, Okio.c(new ResponseBodySource(this, this.d.a(response), jE)));
        } catch (IOException e) {
            this.b.y(this.a, e);
            w(e);
            throw e;
        }
    }

    public final Response.Builder t(boolean z) throws IOException {
        try {
            Response.Builder builderH = this.d.h(z);
            if (builderH == null) {
                return builderH;
            }
            builderH.k(this);
            return builderH;
        } catch (IOException e) {
            this.b.y(this.a, e);
            w(e);
            throw e;
        }
    }

    public final void u(Response response) {
        Intrinsics.checkNotNullParameter(response, "response");
        this.b.z(this.a, response);
    }

    public final void v() {
        this.b.A(this.a);
    }

    public final void x() {
        c(this, 0L, true, true, null, 1, null);
    }

    public final void y(Request request) throws IOException {
        Intrinsics.checkNotNullParameter(request, "request");
        try {
            this.b.v(this.a);
            this.d.f(request);
            this.b.u(this.a, request);
        } catch (IOException e) {
            this.b.t(this.a, e);
            w(e);
            throw e;
        }
    }
}