package okhttp3.internal.connection;

import h.ap;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.URI;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.Address;
import okhttp3.HttpUrl;
import okhttp3.Route;
import okhttp3.internal._HostnamesCommonKt;
import okhttp3.internal._UtilJvmKt;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u0000 .2\u00020\u0001:\u0002/0B'\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b¢\u0006\u0004\b\n\u0010\u000bJ!\u0010\u0011\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\f2\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0002¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0013\u001a\u00020\bH\u0002¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010\u0015\u001a\u00020\u000eH\u0002¢\u0006\u0004\b\u0015\u0010\u0016J\u0017\u0010\u0017\u001a\u00020\u00102\u0006\u0010\u000f\u001a\u00020\u000eH\u0002¢\u0006\u0004\b\u0017\u0010\u0018J\u0010\u0010\u0019\u001a\u00020\bH\u0086\u0002¢\u0006\u0004\b\u0019\u0010\u0014J\u0010\u0010\u001b\u001a\u00020\u001aH\u0086\u0002¢\u0006\u0004\b\u001b\u0010\u001cR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0019\u0010\u001dR\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0013\u0010\u001eR\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001b\u0010\u001fR\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010 R\u001c\u0010#\u001a\b\u0012\u0004\u0012\u00020\u000e0!8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0017\u0010\"R\u0016\u0010&\u001a\u00020$8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0011\u0010%R\u001c\u0010)\u001a\b\u0012\u0004\u0012\u00020'0!8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b(\u0010\"R\u001a\u0010-\u001a\b\u0012\u0004\u0012\u00020+0*8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b,\u0010\"¨\u00061"}, d2 = {"Lokhttp3/internal/connection/RouteSelector;", StringUtils.EMPTY, "Lokhttp3/Address;", "address", "Lokhttp3/internal/connection/RouteDatabase;", "routeDatabase", "Lokhttp3/internal/connection/ConnectionUser;", "connectionUser", StringUtils.EMPTY, "fastFallback", "<init>", "(Lokhttp3/Address;Lokhttp3/internal/connection/RouteDatabase;Lokhttp3/internal/connection/ConnectionUser;Z)V", "Lokhttp3/HttpUrl;", "url", "Ljava/net/Proxy;", "proxy", StringUtils.EMPTY, "f", "(Lokhttp3/HttpUrl;Ljava/net/Proxy;)V", "b", "()Z", "d", "()Ljava/net/Proxy;", "e", "(Ljava/net/Proxy;)V", "a", "Lokhttp3/internal/connection/RouteSelector$Selection;", "c", "()Lokhttp3/internal/connection/RouteSelector$Selection;", "Lokhttp3/Address;", "Lokhttp3/internal/connection/RouteDatabase;", "Lokhttp3/internal/connection/ConnectionUser;", "Z", StringUtils.EMPTY, "Ljava/util/List;", "proxies", StringUtils.EMPTY, "I", "nextProxyIndex", "Ljava/net/InetSocketAddress;", "g", "inetSocketAddresses", StringUtils.EMPTY, "Lokhttp3/Route;", "h", "postponedRoutes", "i", "Selection", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class RouteSelector {
    public static final Companion i = new Companion(null);
    private final Address a;
    private final RouteDatabase b;
    private final ConnectionUser c;
    private final boolean d;
    private List e;
    private int f;
    private List g;
    private final List h;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0015\u0010\b\u001a\u00020\u0005*\u00020\u00048F¢\u0006\u0006\u001a\u0004\b\u0006\u0010\u0007¨\u0006\t"}, d2 = {"Lokhttp3/internal/connection/RouteSelector$Companion;", StringUtils.EMPTY, "<init>", "()V", "Ljava/net/InetSocketAddress;", StringUtils.EMPTY, "a", "(Ljava/net/InetSocketAddress;)Ljava/lang/String;", "socketHost", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final String a(InetSocketAddress inetSocketAddress) {
            Intrinsics.checkNotNullParameter(inetSocketAddress, ap.a(1511455057));
            InetAddress address = inetSocketAddress.getAddress();
            if (address == null) {
                String hostName = inetSocketAddress.getHostName();
                Intrinsics.checkNotNullExpressionValue(hostName, ap.a(122105636));
                return hostName;
            }
            String hostAddress = address.getHostAddress();
            Intrinsics.checkNotNullExpressionValue(hostAddress, ap.a(90192320));
            return hostAddress;
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0010\b\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u0015\u0012\f\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u0002¢\u0006\u0004\b\u0005\u0010\u0006J\u0010\u0010\b\u001a\u00020\u0007H\u0086\u0002¢\u0006\u0004\b\b\u0010\tJ\u0010\u0010\n\u001a\u00020\u0003H\u0086\u0002¢\u0006\u0004\b\n\u0010\u000bR\u001d\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00030\u00028\u0006¢\u0006\f\n\u0004\b\f\u0010\r\u001a\u0004\b\f\u0010\u000eR\u0016\u0010\u0011\u001a\u00020\u000f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\b\u0010\u0010¨\u0006\u0012"}, d2 = {"Lokhttp3/internal/connection/RouteSelector$Selection;", StringUtils.EMPTY, StringUtils.EMPTY, "Lokhttp3/Route;", "routes", "<init>", "(Ljava/util/List;)V", StringUtils.EMPTY, "b", "()Z", "c", "()Lokhttp3/Route;", "a", "Ljava/util/List;", "()Ljava/util/List;", StringUtils.EMPTY, "I", "nextRouteIndex", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Selection {
        private final List a;
        private int b;

        public Selection(List list) {
            Intrinsics.checkNotNullParameter(list, ap.a(198899834));
            this.a = list;
        }

        public final List a() {
            return this.a;
        }

        public final boolean b() {
            return this.b < this.a.size();
        }

        public final Route c() {
            if (!b()) {
                throw new NoSuchElementException();
            }
            List list = this.a;
            int i = this.b;
            this.b = i + 1;
            return (Route) list.get(i);
        }
    }

    public RouteSelector(Address address, RouteDatabase routeDatabase, ConnectionUser connectionUser, boolean z) {
        Intrinsics.checkNotNullParameter(address, ap.a(1472637164));
        Intrinsics.checkNotNullParameter(routeDatabase, ap.a(525246247));
        Intrinsics.checkNotNullParameter(connectionUser, ap.a(668431284));
        this.a = address;
        this.b = routeDatabase;
        this.c = connectionUser;
        this.d = z;
        this.e = CollectionsKt.emptyList();
        this.g = CollectionsKt.emptyList();
        this.h = new ArrayList();
        f(address.l(), address.g());
    }

    private final boolean b() {
        return this.f < this.e.size();
    }

    private final Proxy d() throws SocketException, UnknownHostException {
        if (b()) {
            List list = this.e;
            int i2 = this.f;
            this.f = i2 + 1;
            Proxy proxy = (Proxy) list.get(i2);
            e(proxy);
            return proxy;
        }
        throw new SocketException("No route to " + this.a.l().g() + "; exhausted proxy configurations: " + this.e);
    }

    private final void e(Proxy proxy) throws SocketException, UnknownHostException {
        String strG;
        int iL;
        List listA;
        ArrayList arrayList = new ArrayList();
        this.g = arrayList;
        if (proxy.type() == Proxy.Type.DIRECT || proxy.type() == Proxy.Type.SOCKS) {
            strG = this.a.l().g();
            iL = this.a.l().l();
        } else {
            SocketAddress socketAddressAddress = proxy.address();
            if (!(socketAddressAddress instanceof InetSocketAddress)) {
                throw new IllegalArgumentException(("Proxy.address() is not an InetSocketAddress: " + socketAddressAddress.getClass()).toString());
            }
            InetSocketAddress inetSocketAddress = (InetSocketAddress) socketAddressAddress;
            strG = i.a(inetSocketAddress);
            iL = inetSocketAddress.getPort();
        }
        if (1 > iL || iL >= 65536) {
            throw new SocketException("No route to " + strG + AbstractJsonLexerKt.COLON + iL + "; port is out of range");
        }
        if (proxy.type() == Proxy.Type.SOCKS) {
            arrayList.add(InetSocketAddress.createUnresolved(strG, iL));
            return;
        }
        if (_HostnamesCommonKt.a(strG)) {
            listA = CollectionsKt.listOf(InetAddress.getByName(strG));
        } else {
            this.c.o(strG);
            listA = this.a.c().a(strG);
            if (listA.isEmpty()) {
                throw new UnknownHostException(this.a.c() + " returned no addresses for " + strG);
            }
            this.c.m(strG, listA);
        }
        if (this.d) {
            listA = InetAddressOrderKt.a(listA);
        }
        Iterator it = listA.iterator();
        while (it.hasNext()) {
            arrayList.add(new InetSocketAddress((InetAddress) it.next(), iL));
        }
    }

    private final void f(HttpUrl httpUrl, Proxy proxy) {
        this.c.c(httpUrl);
        List listG = g(proxy, httpUrl, this);
        this.e = listG;
        this.f = 0;
        this.c.d(httpUrl, listG);
    }

    private static final List g(Proxy proxy, HttpUrl httpUrl, RouteSelector routeSelector) {
        if (proxy != null) {
            return CollectionsKt.listOf(proxy);
        }
        URI uriT = httpUrl.t();
        if (uriT.getHost() == null) {
            return _UtilJvmKt.l(Proxy.NO_PROXY);
        }
        List<Proxy> listSelect = routeSelector.a.i().select(uriT);
        List<Proxy> list = listSelect;
        return (list == null || list.isEmpty()) ? _UtilJvmKt.l(Proxy.NO_PROXY) : _UtilJvmKt.x(listSelect);
    }

    public final boolean a() {
        return b() || !this.h.isEmpty();
    }

    public final Selection c() {
        if (!a()) {
            throw new NoSuchElementException();
        }
        ArrayList arrayList = new ArrayList();
        while (b()) {
            Proxy proxyD = d();
            Iterator it = this.g.iterator();
            while (it.hasNext()) {
                Route route = new Route(this.a, proxyD, (InetSocketAddress) it.next());
                if (this.b.c(route)) {
                    this.h.add(route);
                } else {
                    arrayList.add(route);
                }
            }
            if (!arrayList.isEmpty()) {
                break;
            }
        }
        if (arrayList.isEmpty()) {
            CollectionsKt.addAll(arrayList, this.h);
            this.h.clear();
        }
        return new Selection(arrayList);
    }
}