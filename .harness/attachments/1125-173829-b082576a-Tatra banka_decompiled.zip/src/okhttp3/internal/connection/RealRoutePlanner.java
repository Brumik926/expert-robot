package okhttp3.internal.connection;

import h.ap;
import java.io.IOException;
import java.net.Socket;
import java.net.UnknownServiceException;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.ArrayDeque;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.Address;
import okhttp3.ConnectionSpec;
import okhttp3.HttpUrl;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.Route;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.connection.RoutePlanner;
import okhttp3.internal.connection.RouteSelector;
import okhttp3.internal.platform.Platform;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u008e\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001Bg\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\b\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\u0006\u0012\u0006\u0010\n\u001a\u00020\u0006\u0012\u0006\u0010\u000b\u001a\u00020\u0006\u0012\u0006\u0010\r\u001a\u00020\f\u0012\u0006\u0010\u000e\u001a\u00020\f\u0012\u0006\u0010\u0010\u001a\u00020\u000f\u0012\u0006\u0010\u0012\u001a\u00020\u0011\u0012\u0006\u0010\u0014\u001a\u00020\u0013¢\u0006\u0004\b\u0015\u0010\u0016J\u0011\u0010\u0018\u001a\u0004\u0018\u00010\u0017H\u0002¢\u0006\u0004\b\u0018\u0010\u0019J\u0017\u0010\u001d\u001a\u00020\u001c2\u0006\u0010\u001b\u001a\u00020\u001aH\u0002¢\u0006\u0004\b\u001d\u0010\u001eJ\u0019\u0010!\u001a\u0004\u0018\u00010\u001a2\u0006\u0010 \u001a\u00020\u001fH\u0002¢\u0006\u0004\b!\u0010\"J\u000f\u0010#\u001a\u00020\fH\u0016¢\u0006\u0004\b#\u0010$J\u000f\u0010&\u001a\u00020%H\u0016¢\u0006\u0004\b&\u0010'J\u000f\u0010)\u001a\u00020(H\u0000¢\u0006\u0004\b)\u0010*J/\u0010.\u001a\u0004\u0018\u00010\u00172\n\b\u0002\u0010+\u001a\u0004\u0018\u00010(2\u0010\b\u0002\u0010-\u001a\n\u0012\u0004\u0012\u00020\u001a\u0018\u00010,H\u0000¢\u0006\u0004\b.\u0010/J)\u00100\u001a\u00020(2\u0006\u0010\u001b\u001a\u00020\u001a2\u0010\b\u0002\u0010-\u001a\n\u0012\u0004\u0012\u00020\u001a\u0018\u00010,H\u0000¢\u0006\u0004\b0\u00101J\u0019\u00103\u001a\u00020\f2\b\u00102\u001a\u0004\u0018\u00010\u001fH\u0016¢\u0006\u0004\b3\u00104J\u0017\u00107\u001a\u00020\f2\u0006\u00106\u001a\u000205H\u0016¢\u0006\u0004\b7\u00108R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b3\u00109R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b:\u0010;R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b7\u0010<R\u0014\u0010\b\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b=\u0010<R\u0014\u0010\t\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b&\u0010<R\u0014\u0010\n\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010<R\u0014\u0010\u000b\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b)\u0010<R\u0014\u0010\r\u001a\u00020\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b0\u0010>R\u0014\u0010\u000e\u001a\u00020\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b?\u0010>R\u001a\u0010\u0010\u001a\u00020\u000f8\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u0018\u0010@\u001a\u0004\bA\u0010BR\u0014\u0010\u0012\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b.\u0010CR\u0014\u0010\u0014\u001a\u00020\u00138\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bD\u0010ER\u0018\u0010H\u001a\u0004\u0018\u00010F8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b!\u0010GR\u0018\u0010L\u001a\u0004\u0018\u00010I8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bJ\u0010KR\u0018\u0010O\u001a\u0004\u0018\u00010\u001a8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bM\u0010NR \u0010T\u001a\b\u0012\u0004\u0012\u00020%0P8\u0016X\u0096\u0004¢\u0006\f\n\u0004\bQ\u0010R\u001a\u0004\b:\u0010S¨\u0006U"}, d2 = {"Lokhttp3/internal/connection/RealRoutePlanner;", "Lokhttp3/internal/connection/RoutePlanner;", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", "Lokhttp3/internal/connection/RealConnectionPool;", "connectionPool", StringUtils.EMPTY, "readTimeoutMillis", "writeTimeoutMillis", "socketConnectTimeoutMillis", "socketReadTimeoutMillis", "pingIntervalMillis", StringUtils.EMPTY, "retryOnConnectionFailure", "fastFallback", "Lokhttp3/Address;", "address", "Lokhttp3/internal/connection/RouteDatabase;", "routeDatabase", "Lokhttp3/internal/connection/ConnectionUser;", "connectionUser", "<init>", "(Lokhttp3/internal/concurrent/TaskRunner;Lokhttp3/internal/connection/RealConnectionPool;IIIIIZZLokhttp3/Address;Lokhttp3/internal/connection/RouteDatabase;Lokhttp3/internal/connection/ConnectionUser;)V", "Lokhttp3/internal/connection/ReusePlan;", "j", "()Lokhttp3/internal/connection/ReusePlan;", "Lokhttp3/Route;", "route", "Lokhttp3/Request;", "f", "(Lokhttp3/Route;)Lokhttp3/Request;", "Lokhttp3/internal/connection/RealConnection;", "connection", "m", "(Lokhttp3/internal/connection/RealConnection;)Lokhttp3/Route;", "isCanceled", "()Z", "Lokhttp3/internal/connection/RoutePlanner$Plan;", "e", "()Lokhttp3/internal/connection/RoutePlanner$Plan;", "Lokhttp3/internal/connection/ConnectPlan;", "g", "()Lokhttp3/internal/connection/ConnectPlan;", "planToReplace", StringUtils.EMPTY, "routes", "k", "(Lokhttp3/internal/connection/ConnectPlan;Ljava/util/List;)Lokhttp3/internal/connection/ReusePlan;", "h", "(Lokhttp3/Route;Ljava/util/List;)Lokhttp3/internal/connection/ConnectPlan;", "failedConnection", "a", "(Lokhttp3/internal/connection/RealConnection;)Z", "Lokhttp3/HttpUrl;", "url", "c", "(Lokhttp3/HttpUrl;)Z", "Lokhttp3/internal/concurrent/TaskRunner;", "b", "Lokhttp3/internal/connection/RealConnectionPool;", "I", "d", "Z", "i", "Lokhttp3/Address;", "getAddress", "()Lokhttp3/Address;", "Lokhttp3/internal/connection/RouteDatabase;", "l", "Lokhttp3/internal/connection/ConnectionUser;", "Lokhttp3/internal/connection/RouteSelector$Selection;", "Lokhttp3/internal/connection/RouteSelector$Selection;", "routeSelection", "Lokhttp3/internal/connection/RouteSelector;", "n", "Lokhttp3/internal/connection/RouteSelector;", "routeSelector", "o", "Lokhttp3/Route;", "nextRouteToTry", "Lkotlin/collections/ArrayDeque;", "p", "Lkotlin/collections/ArrayDeque;", "()Lkotlin/collections/ArrayDeque;", "deferredPlans", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nRealRoutePlanner.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RealRoutePlanner.kt\nokhttp3/internal/connection/RealRoutePlanner\n+ 2 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n*L\n1#1,346:1\n63#2:347\n63#2:348\n*S KotlinDebug\n*F\n+ 1 RealRoutePlanner.kt\nokhttp3/internal/connection/RealRoutePlanner\n*L\n98#1:347\n325#1:348\n*E\n"})
public final class RealRoutePlanner implements RoutePlanner {
    private final TaskRunner a;
    private final RealConnectionPool b;
    private final int c;
    private final int d;
    private final int e;
    private final int f;
    private final int g;
    private final boolean h;
    private final boolean i;
    private final Address j;
    private final RouteDatabase k;
    private final ConnectionUser l;
    private RouteSelector.Selection m;
    private RouteSelector n;
    private Route o;
    private final ArrayDeque p;

    public RealRoutePlanner(TaskRunner taskRunner, RealConnectionPool realConnectionPool, int i, int i2, int i3, int i4, int i5, boolean z, boolean z2, Address address, RouteDatabase routeDatabase, ConnectionUser connectionUser) {
        Intrinsics.checkNotNullParameter(taskRunner, ap.a(13955752));
        Intrinsics.checkNotNullParameter(realConnectionPool, ap.a(1834382093));
        Intrinsics.checkNotNullParameter(address, ap.a(334236558));
        Intrinsics.checkNotNullParameter(routeDatabase, ap.a(1384790833));
        Intrinsics.checkNotNullParameter(connectionUser, ap.a(926729427));
        this.a = taskRunner;
        this.b = realConnectionPool;
        this.c = i;
        this.d = i2;
        this.e = i3;
        this.f = i4;
        this.g = i5;
        this.h = z;
        this.i = z2;
        this.j = address;
        this.k = routeDatabase;
        this.l = connectionUser;
        this.p = new ArrayDeque();
    }

    private final Request f(Route route) {
        Request requestB = new Request.Builder().x(route.a().l()).p("CONNECT", null).n("Host", _UtilJvmKt.v(route.a().l(), true)).n("Proxy-Connection", "Keep-Alive").n("User-Agent", "okhttp/5.1.0").b();
        Request requestA = route.a().h().a(route, new Response.Builder().q(requestB).o(Protocol.d).f(407).l("Preemptive Authenticate").r(-1L).p(-1L).i("Proxy-Authenticate", "OkHttp-Preemptive").c());
        return requestA == null ? requestB : requestA;
    }

    public static /* synthetic */ ConnectPlan i(RealRoutePlanner realRoutePlanner, Route route, List list, int i, Object obj) {
        if ((i & 2) != 0) {
            list = null;
        }
        return realRoutePlanner.h(route, list);
    }

    private final ReusePlan j() {
        Socket socketS;
        boolean z;
        RealConnection realConnectionJ = this.l.j();
        if (realConnectionJ == null) {
            return null;
        }
        boolean zR = realConnectionJ.r(this.l.h());
        synchronized (realConnectionJ) {
            try {
                if (!zR) {
                    z = !realConnectionJ.m();
                    realConnectionJ.z(true);
                    socketS = this.l.s();
                } else if (realConnectionJ.m() || !c(realConnectionJ.w().a().l())) {
                    socketS = this.l.s();
                    z = false;
                } else {
                    z = false;
                    socketS = null;
                }
            } finally {
            }
        }
        if (this.l.j() != null) {
            if (socketS == null) {
                return new ReusePlan(realConnectionJ);
            }
            throw new IllegalStateException("Check failed.");
        }
        if (socketS != null) {
            _UtilJvmKt.h(socketS);
        }
        this.l.e(realConnectionJ);
        this.l.g(realConnectionJ);
        if (socketS != null) {
            this.l.t(realConnectionJ);
        } else if (z) {
            this.l.p(realConnectionJ);
        }
        return null;
    }

    public static /* synthetic */ ReusePlan l(RealRoutePlanner realRoutePlanner, ConnectPlan connectPlan, List list, int i, Object obj) {
        if ((i & 1) != 0) {
            connectPlan = null;
        }
        if ((i & 2) != 0) {
            list = null;
        }
        return realRoutePlanner.k(connectPlan, list);
    }

    private final Route m(RealConnection realConnection) {
        Route routeW;
        synchronized (realConnection) {
            routeW = null;
            if (realConnection.n() == 0 && realConnection.m() && _UtilJvmKt.f(realConnection.w().a().l(), getAddress().l())) {
                routeW = realConnection.w();
            }
        }
        return routeW;
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public boolean a(RealConnection realConnection) {
        RouteSelector routeSelector;
        Route routeM;
        if (!b().isEmpty() || this.o != null) {
            return true;
        }
        if (realConnection != null && (routeM = m(realConnection)) != null) {
            this.o = routeM;
            return true;
        }
        RouteSelector.Selection selection = this.m;
        if ((selection == null || !selection.b()) && (routeSelector = this.n) != null) {
            return routeSelector.a();
        }
        return true;
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public ArrayDeque b() {
        return this.p;
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public boolean c(HttpUrl httpUrl) {
        Intrinsics.checkNotNullParameter(httpUrl, "url");
        HttpUrl httpUrlL = getAddress().l();
        return httpUrl.l() == httpUrlL.l() && Intrinsics.areEqual(httpUrl.g(), httpUrlL.g());
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public RoutePlanner.Plan e() throws IOException {
        ReusePlan reusePlanJ = j();
        if (reusePlanJ != null) {
            return reusePlanJ;
        }
        ReusePlan reusePlanL = l(this, null, null, 3, null);
        if (reusePlanL != null) {
            return reusePlanL;
        }
        if (!b().isEmpty()) {
            return (RoutePlanner.Plan) b().removeFirst();
        }
        ConnectPlan connectPlanG = g();
        ReusePlan reusePlanK = k(connectPlanG, connectPlanG.s());
        return reusePlanK != null ? reusePlanK : connectPlanG;
    }

    public final ConnectPlan g() throws IOException {
        Route route = this.o;
        if (route != null) {
            this.o = null;
            return i(this, route, null, 2, null);
        }
        RouteSelector.Selection selection = this.m;
        if (selection != null && selection.b()) {
            return i(this, selection.c(), null, 2, null);
        }
        RouteSelector routeSelector = this.n;
        if (routeSelector == null) {
            routeSelector = new RouteSelector(getAddress(), this.k, this.l, this.i);
            this.n = routeSelector;
        }
        if (!routeSelector.a()) {
            throw new IOException("exhausted all routes");
        }
        RouteSelector.Selection selectionC = routeSelector.c();
        this.m = selectionC;
        if (isCanceled()) {
            throw new IOException("Canceled");
        }
        return h(selectionC.c(), selectionC.a());
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public Address getAddress() {
        return this.j;
    }

    public final ConnectPlan h(Route route, List list) throws UnknownServiceException {
        Intrinsics.checkNotNullParameter(route, "route");
        if (route.a().k() == null) {
            if (!route.a().b().contains(ConnectionSpec.k)) {
                throw new UnknownServiceException("CLEARTEXT communication not enabled for client");
            }
            String strG = route.a().l().g();
            if (!Platform.a.e().m(strG)) {
                throw new UnknownServiceException("CLEARTEXT communication to " + strG + " not permitted by network security policy");
            }
        } else if (route.a().f().contains(Protocol.g)) {
            throw new UnknownServiceException("H2_PRIOR_KNOWLEDGE cannot be used with HTTPS");
        }
        return new ConnectPlan(this.a, this.b, this.c, this.d, this.e, this.f, this.g, this.h, this.l, this, route, list, 0, route.c() ? f(route) : null, -1, false);
    }

    @Override // okhttp3.internal.connection.RoutePlanner
    public boolean isCanceled() {
        return this.l.isCanceled();
    }

    public final ReusePlan k(ConnectPlan connectPlan, List list) {
        RealConnection realConnectionB = this.b.b(this.l.h(), getAddress(), this.l, list, connectPlan != null && connectPlan.isReady());
        if (realConnectionB == null) {
            return null;
        }
        if (connectPlan != null) {
            this.o = connectPlan.e();
            connectPlan.j();
        }
        this.l.k(realConnectionB);
        this.l.a(realConnectionB);
        return new ReusePlan(realConnectionB);
    }
}