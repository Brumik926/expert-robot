package okhttp3.internal.connection;

import h.ap;
import java.io.IOException;
import java.lang.ref.Reference;
import java.net.Socket;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.time.DurationKt;
import okhttp3.Address;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.concurrent.Task;
import okhttp3.internal.concurrent.TaskQueue;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.connection.RealCall;
import okhttp3.internal.platform.Platform;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000}\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010$\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0010\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u001b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005*\u0001L\u0018\u0000 \"2\u00020\u0001:\u0002RSBQ\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\u001e\u0010\u0010\u001a\u001a\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000f0\f¢\u0006\u0004\b\u0011\u0010\u0012J\u0013\u0010\u0015\u001a\u00020\u0014*\u00020\u0013H\u0002¢\u0006\u0004\b\u0015\u0010\u0016J+\u0010\u001c\u001a\u00020\u001b2\u0012\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00130\u00172\u0006\u0010\u001a\u001a\u00020\u0019H\u0002¢\u0006\u0004\b\u001c\u0010\u001dJ\u001f\u0010\u001f\u001a\u00020\u00042\u0006\u0010\u001a\u001a\u00020\u00192\u0006\u0010\u001e\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\u001f\u0010 J\u0017\u0010\"\u001a\u00020\u00062\u0006\u0010!\u001a\u00020\u0013H\u0002¢\u0006\u0004\b\"\u0010#J\u001b\u0010%\u001a\u00020\u0006*\u00020\u00062\u0006\u0010$\u001a\u00020\u0004H\u0002¢\u0006\u0004\b%\u0010&J\r\u0010'\u001a\u00020\u0004¢\u0006\u0004\b'\u0010(J?\u00100\u001a\u0004\u0018\u00010\u00192\u0006\u0010)\u001a\u00020\u001b2\u0006\u0010*\u001a\u00020\r2\u0006\u0010+\u001a\u00020\u000e2\u000e\u0010.\u001a\n\u0012\u0004\u0012\u00020-\u0018\u00010,2\u0006\u0010/\u001a\u00020\u001b¢\u0006\u0004\b0\u00101J\u0015\u00102\u001a\u00020\u00142\u0006\u0010\u001a\u001a\u00020\u0019¢\u0006\u0004\b2\u00103J\u0015\u00104\u001a\u00020\u001b2\u0006\u0010\u001a\u001a\u00020\u0019¢\u0006\u0004\b4\u00105J\r\u00106\u001a\u00020\u0014¢\u0006\u0004\b6\u00107J\u0015\u00108\u001a\u00020\u00062\u0006\u0010\u001e\u001a\u00020\u0006¢\u0006\u0004\b8\u00109J\u0015\u0010:\u001a\u00020\u00142\u0006\u0010*\u001a\u00020\r¢\u0006\u0004\b:\u0010;J\r\u0010<\u001a\u00020\u0014¢\u0006\u0004\b<\u00107R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b=\u0010>R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b0\u0010?R\u001a\u0010\u000b\u001a\u00020\n8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b8\u0010@\u001a\u0004\bA\u0010BR,\u0010\u0010\u001a\u001a\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u000e\u0012\u0004\u0012\u00020\u000f0\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b4\u0010CR\u001a\u0010G\u001a\u00020\u00068\u0000X\u0080\u0004¢\u0006\f\n\u0004\b'\u0010D\u001a\u0004\bE\u0010FR\"\u0010\u0018\u001a\u000e\u0012\u0004\u0012\u00020\r\u0012\u0004\u0012\u00020\u00130\u00178\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b6\u0010HR\u0014\u0010K\u001a\u00020I8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bA\u0010JR\u0014\u0010N\u001a\u00020L8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001c\u0010MR\u001a\u0010Q\u001a\b\u0012\u0004\u0012\u00020\u00190O8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b%\u0010P¨\u0006T"}, d2 = {"Lokhttp3/internal/connection/RealConnectionPool;", StringUtils.EMPTY, "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", StringUtils.EMPTY, "maxIdleConnections", StringUtils.EMPTY, "keepAliveDuration", "Ljava/util/concurrent/TimeUnit;", "timeUnit", "Lokhttp3/internal/connection/ConnectionListener;", "connectionListener", "Lkotlin/Function3;", "Lokhttp3/Address;", "Lokhttp3/internal/connection/ConnectionUser;", "Lokhttp3/internal/connection/ExchangeFinder;", "exchangeFinderFactory", "<init>", "(Lokhttp3/internal/concurrent/TaskRunner;IJLjava/util/concurrent/TimeUnit;Lokhttp3/internal/connection/ConnectionListener;Lkotlin/jvm/functions/Function3;)V", "Lokhttp3/internal/connection/RealConnectionPool$AddressState;", StringUtils.EMPTY, "o", "(Lokhttp3/internal/connection/RealConnectionPool$AddressState;)V", StringUtils.EMPTY, "addressStates", "Lokhttp3/internal/connection/RealConnection;", "connection", StringUtils.EMPTY, "h", "(Ljava/util/Map;Lokhttp3/internal/connection/RealConnection;)Z", "now", "k", "(Lokhttp3/internal/connection/RealConnection;J)I", "state", "j", "(Lokhttp3/internal/connection/RealConnectionPool$AddressState;)J", "amount", "i", "(JI)J", "e", "()I", "doExtensiveHealthChecks", "address", "connectionUser", StringUtils.EMPTY, "Lokhttp3/Route;", "routes", "requireMultiplexed", "b", "(ZLokhttp3/Address;Lokhttp3/internal/connection/ConnectionUser;Ljava/util/List;Z)Lokhttp3/internal/connection/RealConnection;", "l", "(Lokhttp3/internal/connection/RealConnection;)V", "d", "(Lokhttp3/internal/connection/RealConnection;)Z", "f", "()V", "c", "(J)J", "n", "(Lokhttp3/Address;)V", "m", "a", "Lokhttp3/internal/concurrent/TaskRunner;", "I", "Lokhttp3/internal/connection/ConnectionListener;", "g", "()Lokhttp3/internal/connection/ConnectionListener;", "Lkotlin/jvm/functions/Function3;", "J", "getKeepAliveDurationNs$okhttp", "()J", "keepAliveDurationNs", "Ljava/util/Map;", "Lokhttp3/internal/concurrent/TaskQueue;", "Lokhttp3/internal/concurrent/TaskQueue;", "cleanupQueue", "okhttp3/internal/connection/RealConnectionPool$cleanupTask$1", "Lokhttp3/internal/connection/RealConnectionPool$cleanupTask$1;", "cleanupTask", "Ljava/util/concurrent/ConcurrentLinkedQueue;", "Ljava/util/concurrent/ConcurrentLinkedQueue;", "connections", "AddressState", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nRealConnectionPool.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RealConnectionPool.kt\nokhttp3/internal/connection/RealConnectionPool\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n*L\n1#1,465:1\n1#2:466\n1788#3,3:467\n1791#3:471\n63#4:470\n63#4:472\n63#4:473\n55#4,4:474\n55#4,4:478\n63#4:482\n63#4:483\n63#4:484\n63#4:485\n55#4,4:486\n63#4:490\n63#4:491\n*S KotlinDebug\n*F\n+ 1 RealConnectionPool.kt\nokhttp3/internal/connection/RealConnectionPool\n*L\n82#1:467,3\n82#1:471\n83#1:470\n110#1:472\n129#1:473\n145#1:474,4\n157#1:478,4\n176#1:482\n214#1:483\n237#1:484\n285#1:485\n336#1:486,4\n415#1:490\n430#1:491\n*E\n"})
public final class RealConnectionPool {
    public static final Companion j = new Companion(null);
    private static AtomicReferenceFieldUpdater k = AtomicReferenceFieldUpdater.newUpdater(RealConnectionPool.class, Map.class, ap.a(1411932263));
    private final TaskRunner a;
    private final int b;
    private final ConnectionListener c;
    private final Function3 d;
    private final long e;
    private volatile Map f;
    private final TaskQueue g;
    private final RealConnectionPool$cleanupTask$1 h;
    private final ConcurrentLinkedQueue i;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\u0006\u0018\u00002\u00020\u0001R\u0017\u0010\u0006\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0003\u0010\u0004\u001a\u0004\b\u0003\u0010\u0005R\u0017\u0010\f\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\n\u0010\u000bR\"\u0010\u0013\u001a\u00020\r8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\u000e\u0010\u0010\"\u0004\b\u0011\u0010\u0012R\"\u0010\u0019\u001a\u00020\u00148\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\n\u0010\u0015\u001a\u0004\b\b\u0010\u0016\"\u0004\b\u0017\u0010\u0018¨\u0006\u001a"}, d2 = {"Lokhttp3/internal/connection/RealConnectionPool$AddressState;", StringUtils.EMPTY, "Lokhttp3/Address;", "a", "Lokhttp3/Address;", "()Lokhttp3/Address;", "address", "Lokhttp3/internal/concurrent/TaskQueue;", "b", "Lokhttp3/internal/concurrent/TaskQueue;", "d", "()Lokhttp3/internal/concurrent/TaskQueue;", "queue", "Lokhttp3/internal/connection/AddressPolicy;", "c", "Lokhttp3/internal/connection/AddressPolicy;", "()Lokhttp3/internal/connection/AddressPolicy;", "setPolicy", "(Lokhttp3/internal/connection/AddressPolicy;)V", "policy", StringUtils.EMPTY, "I", "()I", "e", "(I)V", "concurrentCallCapacity", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class AddressState {
        private final Address a;
        private final TaskQueue b;
        private AddressPolicy c;
        private int d;

        public final Address a() {
            return this.a;
        }

        public final int b() {
            return this.d;
        }

        public final AddressPolicy c() {
            return this.c;
        }

        public final TaskQueue d() {
            return this.b;
        }

        public final void e(int i) {
            this.d = i;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003Rv\u0010\b\u001ab\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005\u0012\u001c\u0012\u001a\u0012\u0002\b\u0003\u0012\u0002\b\u0003 \u0006*\f\u0012\u0002\b\u0003\u0012\u0002\b\u0003\u0018\u00010\u00070\u0007 \u0006*0\u0012\f\u0012\n \u0006*\u0004\u0018\u00010\u00050\u0005\u0012\u001c\u0012\u001a\u0012\u0002\b\u0003\u0012\u0002\b\u0003 \u0006*\f\u0012\u0002\b\u0003\u0012\u0002\b\u0003\u0018\u00010\u00070\u0007\u0018\u00010\u00040\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Lokhttp3/internal/connection/RealConnectionPool$Companion;", StringUtils.EMPTY, "<init>", "()V", "Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;", "Lokhttp3/internal/connection/RealConnectionPool;", "kotlin.jvm.PlatformType", StringUtils.EMPTY, "addressStatesUpdater", "Ljava/util/concurrent/atomic/AtomicReferenceFieldUpdater;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX WARN: Type inference failed for: r3v4, types: [okhttp3.internal.connection.RealConnectionPool$cleanupTask$1] */
    public RealConnectionPool(TaskRunner taskRunner, int i, long j2, TimeUnit timeUnit, ConnectionListener connectionListener, Function3 function3) {
        Intrinsics.checkNotNullParameter(taskRunner, "taskRunner");
        Intrinsics.checkNotNullParameter(timeUnit, "timeUnit");
        Intrinsics.checkNotNullParameter(connectionListener, "connectionListener");
        Intrinsics.checkNotNullParameter(function3, "exchangeFinderFactory");
        this.a = taskRunner;
        this.b = i;
        this.c = connectionListener;
        this.d = function3;
        this.e = timeUnit.toNanos(j2);
        this.f = MapsKt.emptyMap();
        this.g = taskRunner.k();
        final String str = _UtilJvmKt.c + " ConnectionPool connection closer";
        this.h = new Task(str) { // from class: okhttp3.internal.connection.RealConnectionPool$cleanupTask$1
            @Override // okhttp3.internal.concurrent.Task
            public long f() {
                return this.e.c(System.nanoTime());
            }
        };
        this.i = new ConcurrentLinkedQueue();
        if (j2 > 0) {
            return;
        }
        throw new IllegalArgumentException(("keepAliveDuration <= 0: " + j2).toString());
    }

    private final boolean h(Map map, RealConnection realConnection) {
        AddressState addressState = (AddressState) map.get(realConnection.e().a());
        return addressState == null || addressState.b() - realConnection.i() >= addressState.c().a;
    }

    private final long i(long j2, int i) {
        return j2 + ((long) ThreadLocalRandom.current().nextInt(i * (-1), i));
    }

    private final long j(AddressState addressState) {
        if (addressState.c().a == 0) {
            return -1L;
        }
        Iterator it = this.i.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        int i = 0;
        while (it.hasNext()) {
            RealConnection realConnection = (RealConnection) it.next();
            if (Intrinsics.areEqual(addressState.a(), realConnection.e().a())) {
                Intrinsics.checkNotNull(realConnection);
                synchronized (realConnection) {
                    i += realConnection.i();
                    Unit unit = Unit.INSTANCE;
                }
                if (i >= addressState.c().a) {
                    return -1L;
                }
            }
        }
        try {
            RealConnection realConnectionA = ((ExchangeFinder) this.d.invoke(this, addressState.a(), PoolConnectionUser.a)).a();
            if (this.i.contains(realConnectionA)) {
                return 0L;
            }
            synchronized (realConnectionA) {
                l(realConnectionA);
                Unit unit2 = Unit.INSTANCE;
            }
            return 0L;
        } catch (IOException unused) {
            return i(addressState.c().b, addressState.c().c) * ((long) DurationKt.NANOS_IN_MILLIS);
        }
    }

    private final int k(RealConnection realConnection, long j2) {
        if (_UtilJvmKt.b && !Thread.holdsLock(realConnection)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + realConnection);
        }
        List listJ = realConnection.j();
        int i = 0;
        while (i < listJ.size()) {
            Reference reference = (Reference) listJ.get(i);
            if (reference.get() != null) {
                i++;
            } else {
                Intrinsics.checkNotNull(reference, "null cannot be cast to non-null type okhttp3.internal.connection.RealCall.CallReference");
                Platform.a.e().p("A connection to " + realConnection.w().a().l() + " was leaked. Did you forget to close a response body?", ((RealCall.CallReference) reference).a());
                listJ.remove(i);
                if (listJ.isEmpty()) {
                    realConnection.y(j2 - this.e);
                    return 0;
                }
            }
        }
        return listJ.size();
    }

    private final void o(final AddressState addressState) {
        TaskQueue taskQueueD = addressState.d();
        final String str = _UtilJvmKt.c + " ConnectionPool connection opener";
        TaskQueue.m(taskQueueD, new Task(str) { // from class: okhttp3.internal.connection.RealConnectionPool$scheduleOpener$1
            @Override // okhttp3.internal.concurrent.Task
            public long f() {
                return this.e.j(addressState);
            }
        }, 0L, 2, null);
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x0032 A[Catch: all -> 0x0030, TryCatch #0 {all -> 0x0030, blocks: (B:9:0x0029, B:14:0x0032, B:17:0x0039), top: B:38:0x0029 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final okhttp3.internal.connection.RealConnection b(boolean r6, okhttp3.Address r7, okhttp3.internal.connection.ConnectionUser r8, java.util.List r9, boolean r10) {
        /*
            r5 = this;
            java.lang.String r0 = "address"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r7, r0)
            java.lang.String r0 = "connectionUser"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r8, r0)
            java.util.concurrent.ConcurrentLinkedQueue r0 = r5.i
            java.util.Iterator r0 = r0.iterator()
            java.lang.String r1 = "iterator(...)"
            kotlin.jvm.internal.Intrinsics.checkNotNullExpressionValue(r0, r1)
        L15:
            boolean r1 = r0.hasNext()
            if (r1 == 0) goto L6c
            java.lang.Object r1 = r0.next()
            okhttp3.internal.connection.RealConnection r1 = (okhttp3.internal.connection.RealConnection) r1
            kotlin.jvm.internal.Intrinsics.checkNotNull(r1)
            monitor-enter(r1)
            r2 = 1
            r3 = 0
            if (r10 == 0) goto L32
            boolean r4 = r1.s()     // Catch: java.lang.Throwable -> L30
            if (r4 != 0) goto L32
            goto L3d
        L30:
            r5 = move-exception
            goto L6a
        L32:
            boolean r4 = r1.q(r7, r9)     // Catch: java.lang.Throwable -> L30
            if (r4 != 0) goto L39
            goto L3d
        L39:
            r8.f(r1)     // Catch: java.lang.Throwable -> L30
            r3 = r2
        L3d:
            monitor-exit(r1)
            if (r3 == 0) goto L15
            boolean r3 = r1.r(r6)
            if (r3 == 0) goto L47
            return r1
        L47:
            monitor-enter(r1)
            boolean r3 = r1.m()     // Catch: java.lang.Throwable -> L67
            r1.z(r2)     // Catch: java.lang.Throwable -> L67
            java.net.Socket r2 = r8.s()     // Catch: java.lang.Throwable -> L67
            monitor-exit(r1)
            if (r2 == 0) goto L5f
            okhttp3.internal._UtilJvmKt.h(r2)
            okhttp3.internal.connection.ConnectionListener r2 = r5.c
            r2.f(r1)
            goto L15
        L5f:
            if (r3 != 0) goto L15
            okhttp3.internal.connection.ConnectionListener r2 = r5.c
            r2.h(r1)
            goto L15
        L67:
            r5 = move-exception
            monitor-exit(r1)
            throw r5
        L6a:
            monitor-exit(r1)
            throw r5
        L6c:
            r5 = 0
            return r5
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.connection.RealConnectionPool.b(boolean, okhttp3.Address, okhttp3.internal.connection.ConnectionUser, java.util.List, boolean):okhttp3.internal.connection.RealConnection");
    }

    public final long c(long j2) {
        int i;
        Map map = this.f;
        Iterator it = map.values().iterator();
        while (true) {
            i = 0;
            if (!it.hasNext()) {
                break;
            }
            ((AddressState) it.next()).e(0);
        }
        Iterator it2 = this.i.iterator();
        Intrinsics.checkNotNullExpressionValue(it2, "iterator(...)");
        while (it2.hasNext()) {
            RealConnection realConnection = (RealConnection) it2.next();
            AddressState addressState = (AddressState) map.get(realConnection.e().a());
            if (addressState != null) {
                Intrinsics.checkNotNull(realConnection);
                synchronized (realConnection) {
                    addressState.e(addressState.b() + realConnection.i());
                    Unit unit = Unit.INSTANCE;
                }
            }
        }
        long j3 = (j2 - this.e) + 1;
        Iterator it3 = this.i.iterator();
        Intrinsics.checkNotNullExpressionValue(it3, "iterator(...)");
        RealConnection realConnection2 = null;
        RealConnection realConnection3 = null;
        RealConnection realConnection4 = null;
        long j4 = Long.MAX_VALUE;
        int i2 = 0;
        while (it3.hasNext()) {
            RealConnection realConnection5 = (RealConnection) it3.next();
            Intrinsics.checkNotNull(realConnection5);
            synchronized (realConnection5) {
                if (k(realConnection5, j2) > 0) {
                    i2++;
                } else {
                    long jL = realConnection5.l();
                    if (jL < j3) {
                        realConnection3 = realConnection5;
                        j3 = jL;
                    }
                    if (h(map, realConnection5)) {
                        i++;
                        if (jL < j4) {
                            realConnection4 = realConnection5;
                            j4 = jL;
                        }
                    }
                }
                Unit unit2 = Unit.INSTANCE;
            }
        }
        if (realConnection3 != null) {
            realConnection2 = realConnection3;
        } else if (i > this.b) {
            j3 = j4;
            realConnection2 = realConnection4;
        } else {
            j3 = -1;
        }
        if (realConnection2 == null) {
            if (realConnection4 != null) {
                return (j4 + this.e) - j2;
            }
            if (i2 > 0) {
                return this.e;
            }
            return -1L;
        }
        synchronized (realConnection2) {
            if (!realConnection2.j().isEmpty()) {
                return 0L;
            }
            if (realConnection2.l() != j3) {
                return 0L;
            }
            realConnection2.z(true);
            this.i.remove(realConnection2);
            AddressState addressState2 = (AddressState) map.get(realConnection2.e().a());
            if (addressState2 != null) {
                o(addressState2);
            }
            _UtilJvmKt.h(realConnection2.A());
            this.c.f(realConnection2);
            if (this.i.isEmpty()) {
                this.g.a();
            }
            return 0L;
        }
    }

    public final boolean d(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
        if (_UtilJvmKt.b && !Thread.holdsLock(realConnection)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + realConnection);
        }
        if (!realConnection.m() && this.b != 0) {
            m();
            return false;
        }
        realConnection.z(true);
        this.i.remove(realConnection);
        if (this.i.isEmpty()) {
            this.g.a();
        }
        n(realConnection.e().a());
        return true;
    }

    public final int e() {
        return this.i.size();
    }

    public final void f() {
        Socket socketA;
        Iterator it = this.i.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        while (it.hasNext()) {
            RealConnection realConnection = (RealConnection) it.next();
            Intrinsics.checkNotNull(realConnection);
            synchronized (realConnection) {
                if (realConnection.j().isEmpty()) {
                    it.remove();
                    realConnection.z(true);
                    socketA = realConnection.A();
                } else {
                    socketA = null;
                }
            }
            if (socketA != null) {
                _UtilJvmKt.h(socketA);
                this.c.f(realConnection);
            }
        }
        if (this.i.isEmpty()) {
            this.g.a();
        }
        Iterator it2 = this.f.values().iterator();
        while (it2.hasNext()) {
            o((AddressState) it2.next());
        }
    }

    public final ConnectionListener g() {
        return this.c;
    }

    public final void l(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
        if (!_UtilJvmKt.b || Thread.holdsLock(realConnection)) {
            this.i.add(realConnection);
            m();
            return;
        }
        throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + realConnection);
    }

    public final void m() {
        TaskQueue.m(this.g, this.h, 0L, 2, null);
    }

    public final void n(Address address) {
        Intrinsics.checkNotNullParameter(address, "address");
        AddressState addressState = (AddressState) this.f.get(address);
        if (addressState != null) {
            o(addressState);
        }
    }
}