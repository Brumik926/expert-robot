package okhttp3.internal.connection;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal.connection.RoutePlanner;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0001\n\u0002\b\n\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\t\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\t\u0010\bJ\u000f\u0010\n\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\f\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\f\u0010\bJ\u000f\u0010\r\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\r\u0010\bR\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\u0010\u0010\u000bR\u001a\u0010\u0013\u001a\u00020\u00118\u0016X\u0096D¢\u0006\f\n\u0004\b\n\u0010\u0012\u001a\u0004\b\u0013\u0010\u0014¨\u0006\u0015"}, d2 = {"Lokhttp3/internal/connection/ReusePlan;", "Lokhttp3/internal/connection/RoutePlanner$Plan;", "Lokhttp3/internal/connection/RealConnection;", "connection", "<init>", "(Lokhttp3/internal/connection/RealConnection;)V", StringUtils.EMPTY, "e", "()Ljava/lang/Void;", "g", "b", "()Lokhttp3/internal/connection/RealConnection;", "c", "i", "a", "Lokhttp3/internal/connection/RealConnection;", "h", StringUtils.EMPTY, "Z", "isReady", "()Z", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ReusePlan implements RoutePlanner.Plan {
    private final RealConnection a;
    private final boolean b;

    public ReusePlan(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, ap.a(733764485));
        this.a = realConnection;
        this.b = true;
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public /* bridge */ /* synthetic */ RoutePlanner.Plan a() {
        return (RoutePlanner.Plan) i();
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public RealConnection b() {
        return this.a;
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan, okhttp3.internal.http.ExchangeCodec.Carrier
    /* JADX INFO: renamed from: c, reason: merged with bridge method [inline-methods] */
    public Void cancel() {
        throw new IllegalStateException("unexpected cancel");
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public /* bridge */ /* synthetic */ RoutePlanner.ConnectResult d() {
        return (RoutePlanner.ConnectResult) g();
    }

    public Void e() {
        throw new IllegalStateException("already connected");
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public /* bridge */ /* synthetic */ RoutePlanner.ConnectResult f() {
        return (RoutePlanner.ConnectResult) e();
    }

    public Void g() {
        throw new IllegalStateException("already connected");
    }

    public final RealConnection h() {
        return this.a;
    }

    public Void i() {
        throw new IllegalStateException("unexpected retry");
    }

    @Override // okhttp3.internal.connection.RoutePlanner.Plan
    public boolean isReady() {
        return this.b;
    }
}