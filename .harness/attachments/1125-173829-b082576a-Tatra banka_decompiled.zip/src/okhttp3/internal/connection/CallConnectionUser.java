package okhttp3.internal.connection;

import h.ap;
import java.io.IOException;
import java.net.Socket;
import java.util.List;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.Connection;
import okhttp3.EventListener;
import okhttp3.Handshake;
import okhttp3.HttpUrl;
import okhttp3.Protocol;
import okhttp3.Route;
import okhttp3.internal.http.RealInterceptorChain;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0094\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u0017\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\r\u0010\u000eJ\u0017\u0010\u000f\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\nH\u0016¢\u0006\u0004\b\u000f\u0010\u000eJ\u0017\u0010\u0012\u001a\u00020\f2\u0006\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0012\u0010\u0013J\u0017\u0010\u0014\u001a\u00020\f2\u0006\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0014\u0010\u0013J)\u0010\u0019\u001a\u00020\f2\u0006\u0010\u0011\u001a\u00020\u00102\b\u0010\u0016\u001a\u0004\u0018\u00010\u00152\u0006\u0010\u0018\u001a\u00020\u0017H\u0016¢\u0006\u0004\b\u0019\u0010\u001aJ\u000f\u0010\u001b\u001a\u00020\fH\u0016¢\u0006\u0004\b\u001b\u0010\u001cJ\u0019\u0010\u001f\u001a\u00020\f2\b\u0010\u001e\u001a\u0004\u0018\u00010\u001dH\u0016¢\u0006\u0004\b\u001f\u0010 J!\u0010!\u001a\u00020\f2\u0006\u0010\u0011\u001a\u00020\u00102\b\u0010\u0016\u001a\u0004\u0018\u00010\u0015H\u0016¢\u0006\u0004\b!\u0010\"J\u001f\u0010%\u001a\u00020\f2\u0006\u0010$\u001a\u00020#2\u0006\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b%\u0010&J\u0017\u0010'\u001a\u00020\f2\u0006\u0010$\u001a\u00020#H\u0016¢\u0006\u0004\b'\u0010(J\u0017\u0010*\u001a\u00020\f2\u0006\u0010$\u001a\u00020)H\u0016¢\u0006\u0004\b*\u0010+J\u0011\u0010-\u001a\u0004\u0018\u00010,H\u0016¢\u0006\u0004\b-\u0010.J\u0017\u0010\u0018\u001a\u00020\f2\u0006\u0010$\u001a\u00020#H\u0016¢\u0006\u0004\b\u0018\u0010(J\u0017\u0010/\u001a\u00020\f2\u0006\u0010$\u001a\u00020)H\u0016¢\u0006\u0004\b/\u0010+J\u0017\u00100\u001a\u00020\f2\u0006\u0010$\u001a\u00020)H\u0016¢\u0006\u0004\b0\u0010+J\u0017\u00101\u001a\u00020\f2\u0006\u0010$\u001a\u00020)H\u0016¢\u0006\u0004\b1\u0010+J\u0017\u00102\u001a\u00020\f2\u0006\u0010$\u001a\u00020)H\u0016¢\u0006\u0004\b2\u0010+J\u000f\u00104\u001a\u000203H\u0016¢\u0006\u0004\b4\u00105J\u000f\u00106\u001a\u000203H\u0016¢\u0006\u0004\b6\u00105J\u0011\u00107\u001a\u0004\u0018\u00010)H\u0016¢\u0006\u0004\b7\u00108J\u0017\u0010;\u001a\u00020\f2\u0006\u0010:\u001a\u000209H\u0016¢\u0006\u0004\b;\u0010<J%\u0010@\u001a\u00020\f2\u0006\u0010:\u001a\u0002092\f\u0010?\u001a\b\u0012\u0004\u0012\u00020>0=H\u0016¢\u0006\u0004\b@\u0010AJ\u0017\u0010D\u001a\u00020\f2\u0006\u0010C\u001a\u00020BH\u0016¢\u0006\u0004\bD\u0010EJ%\u0010H\u001a\u00020\f2\u0006\u0010C\u001a\u00020B2\f\u0010G\u001a\b\u0012\u0004\u0012\u00020F0=H\u0016¢\u0006\u0004\bH\u0010IR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b/\u0010JR\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b!\u0010KR\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b;\u0010LR\u0014\u0010P\u001a\u00020M8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\bN\u0010O¨\u0006Q"}, d2 = {"Lokhttp3/internal/connection/CallConnectionUser;", "Lokhttp3/internal/connection/ConnectionUser;", "Lokhttp3/internal/connection/RealCall;", "call", "Lokhttp3/internal/connection/ConnectionListener;", "poolConnectionListener", "Lokhttp3/internal/http/RealInterceptorChain;", "chain", "<init>", "(Lokhttp3/internal/connection/RealCall;Lokhttp3/internal/connection/ConnectionListener;Lokhttp3/internal/http/RealInterceptorChain;)V", "Lokhttp3/internal/connection/ConnectPlan;", "connectPlan", StringUtils.EMPTY, OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "(Lokhttp3/internal/connection/ConnectPlan;)V", "r", "Lokhttp3/Route;", "route", "u", "(Lokhttp3/Route;)V", "v", "Lokhttp3/Protocol;", "protocol", "Ljava/io/IOException;", "e", "l", "(Lokhttp3/Route;Lokhttp3/Protocol;Ljava/io/IOException;)V", "i", "()V", "Lokhttp3/Handshake;", "handshake", "q", "(Lokhttp3/Handshake;)V", "b", "(Lokhttp3/Route;Lokhttp3/Protocol;)V", "Lokhttp3/Connection;", "connection", "n", "(Lokhttp3/Connection;Lokhttp3/Route;)V", "k", "(Lokhttp3/Connection;)V", "Lokhttp3/internal/connection/RealConnection;", "f", "(Lokhttp3/internal/connection/RealConnection;)V", "Ljava/net/Socket;", "s", "()Ljava/net/Socket;", "a", "g", "t", "p", StringUtils.EMPTY, "h", "()Z", "isCanceled", "j", "()Lokhttp3/internal/connection/RealConnection;", "Lokhttp3/HttpUrl;", "url", "c", "(Lokhttp3/HttpUrl;)V", StringUtils.EMPTY, "Ljava/net/Proxy;", "proxies", "d", "(Lokhttp3/HttpUrl;Ljava/util/List;)V", StringUtils.EMPTY, "socketHost", "o", "(Ljava/lang/String;)V", "Ljava/net/InetAddress;", "result", "m", "(Ljava/lang/String;Ljava/util/List;)V", "Lokhttp3/internal/connection/RealCall;", "Lokhttp3/internal/connection/ConnectionListener;", "Lokhttp3/internal/http/RealInterceptorChain;", "Lokhttp3/EventListener;", "x", "()Lokhttp3/EventListener;", "eventListener", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class CallConnectionUser implements ConnectionUser {
    private final RealCall a;
    private final ConnectionListener b;
    private final RealInterceptorChain c;

    public CallConnectionUser(RealCall realCall, ConnectionListener connectionListener, RealInterceptorChain realInterceptorChain) {
        Intrinsics.checkNotNullParameter(realCall, ap.a(1350718049));
        Intrinsics.checkNotNullParameter(connectionListener, ap.a(1461022090));
        Intrinsics.checkNotNullParameter(realInterceptorChain, ap.a(23518960));
        this.a = realCall;
        this.b = connectionListener;
        this.c = realInterceptorChain;
    }

    private final EventListener x() {
        return this.a.l();
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void a(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
        realConnection.k().e(realConnection, this.a);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void b(Route route, Protocol protocol) {
        Intrinsics.checkNotNullParameter(route, "route");
        x().h(this.a, route.d(), route.b(), protocol);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void c(HttpUrl httpUrl) {
        Intrinsics.checkNotNullParameter(httpUrl, "url");
        x().q(this.a, httpUrl);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void d(HttpUrl httpUrl, List list) {
        Intrinsics.checkNotNullParameter(httpUrl, "url");
        Intrinsics.checkNotNullParameter(list, "proxies");
        x().p(this.a, httpUrl, list);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void e(Connection connection) {
        Intrinsics.checkNotNullParameter(connection, "connection");
        x().l(this.a, connection);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void f(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
        this.a.c(realConnection);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void g(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
        realConnection.k().g(realConnection, this.a);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public boolean h() {
        return !Intrinsics.areEqual(this.c.i().i(), "GET");
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void i() {
        x().E(this.a);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public boolean isCanceled() {
        return this.a.isCanceled();
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public RealConnection j() {
        return this.a.k();
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void k(Connection connection) {
        Intrinsics.checkNotNullParameter(connection, "connection");
        x().k(this.a, connection);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void l(Route route, Protocol protocol, IOException iOException) {
        Intrinsics.checkNotNullParameter(route, "route");
        Intrinsics.checkNotNullParameter(iOException, "e");
        x().i(this.a, route.d(), route.b(), null, iOException);
        this.b.c(route, this.a, iOException);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void m(String str, List list) {
        Intrinsics.checkNotNullParameter(str, "socketHost");
        Intrinsics.checkNotNullParameter(list, "result");
        x().m(this.a, str, list);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void n(Connection connection, Route route) {
        Intrinsics.checkNotNullParameter(connection, "connection");
        Intrinsics.checkNotNullParameter(route, "route");
        this.b.b(connection, route, this.a);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void o(String str) {
        Intrinsics.checkNotNullParameter(str, "socketHost");
        x().n(this.a, str);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void p(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
        realConnection.k().h(realConnection);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void q(Handshake handshake) {
        x().D(this.a, handshake);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void r(ConnectPlan connectPlan) {
        Intrinsics.checkNotNullParameter(connectPlan, "connectPlan");
        this.a.p().remove(connectPlan);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public Socket s() {
        return this.a.w();
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void t(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
        realConnection.k().f(realConnection);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void u(Route route) {
        Intrinsics.checkNotNullParameter(route, "route");
        this.a.j().v().a(route);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void v(Route route) {
        Intrinsics.checkNotNullParameter(route, "route");
        x().j(this.a, route.d(), route.b());
        this.b.d(route, this.a);
    }

    @Override // okhttp3.internal.connection.ConnectionUser
    public void w(ConnectPlan connectPlan) {
        Intrinsics.checkNotNullParameter(connectPlan, "connectPlan");
        this.a.p().add(connectPlan);
    }
}