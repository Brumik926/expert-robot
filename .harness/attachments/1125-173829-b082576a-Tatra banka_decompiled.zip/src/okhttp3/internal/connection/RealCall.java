package okhttp3.internal.connection;

import h.ap;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.lang.ref.Reference;
import java.lang.ref.WeakReference;
import java.net.Socket;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.ExceptionsKt;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.EventListener;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.concurrent.Lockable;
import okhttp3.internal.connection.RoutePlanner;
import okhttp3.internal.http.RealInterceptorChain;
import okhttp3.internal.platform.Platform;
import okio.AsyncTimeout;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000§\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006*\u0001T\u0018\u00002\u00020\u00012\u00020\u00022\u00020\u0003:\u0002stB\u001f\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\r\u001a\u00020\fH\u0002¢\u0006\u0004\b\r\u0010\u000eJ#\u0010\u0012\u001a\u00028\u0000\"\n\b\u0000\u0010\u0010*\u0004\u0018\u00010\u000f2\u0006\u0010\u0011\u001a\u00028\u0000H\u0002¢\u0006\u0004\b\u0012\u0010\u0013J#\u0010\u0015\u001a\u00028\u0000\"\n\b\u0000\u0010\u0010*\u0004\u0018\u00010\u000f2\u0006\u0010\u0014\u001a\u00028\u0000H\u0002¢\u0006\u0004\b\u0015\u0010\u0013J\u000f\u0010\u0017\u001a\u00020\u0016H\u0002¢\u0006\u0004\b\u0017\u0010\u0018J\u000f\u0010\u0019\u001a\u00020\u0001H\u0016¢\u0006\u0004\b\u0019\u0010\u001aJ\u000f\u0010\u001b\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u001b\u0010\u001cJ\u000f\u0010\u001d\u001a\u00020\fH\u0016¢\u0006\u0004\b\u001d\u0010\u000eJ\u000f\u0010\u001e\u001a\u00020\bH\u0016¢\u0006\u0004\b\u001e\u0010\u001fJ\u000f\u0010!\u001a\u00020 H\u0016¢\u0006\u0004\b!\u0010\"J\u0017\u0010%\u001a\u00020\f2\u0006\u0010$\u001a\u00020#H\u0016¢\u0006\u0004\b%\u0010&J\u000f\u0010'\u001a\u00020 H\u0000¢\u0006\u0004\b'\u0010\"J%\u0010+\u001a\u00020\f2\u0006\u0010\u001b\u001a\u00020\u00062\u0006\u0010(\u001a\u00020\b2\u0006\u0010*\u001a\u00020)¢\u0006\u0004\b+\u0010,J\u0017\u0010.\u001a\u00020-2\u0006\u0010*\u001a\u00020)H\u0000¢\u0006\u0004\b.\u0010/J\u0015\u00102\u001a\u00020\f2\u0006\u00101\u001a\u000200¢\u0006\u0004\b2\u00103J?\u00107\u001a\u00028\u0000\"\n\b\u0000\u0010\u0010*\u0004\u0018\u00010\u000f2\u0006\u00104\u001a\u00020-2\b\b\u0002\u00105\u001a\u00020\b2\b\b\u0002\u00106\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00028\u0000H\u0000¢\u0006\u0004\b7\u00108J\u001b\u00109\u001a\u0004\u0018\u00010\u000f2\b\u0010\u0011\u001a\u0004\u0018\u00010\u000fH\u0000¢\u0006\u0004\b9\u0010\u0013J\u0011\u0010;\u001a\u0004\u0018\u00010:H\u0000¢\u0006\u0004\b;\u0010<J\r\u0010=\u001a\u00020\f¢\u0006\u0004\b=\u0010\u000eJ\u0017\u0010?\u001a\u00020\f2\u0006\u0010>\u001a\u00020\bH\u0000¢\u0006\u0004\b?\u0010@J\r\u0010A\u001a\u00020\b¢\u0006\u0004\bA\u0010\u001fJ\u000f\u0010B\u001a\u00020\u0016H\u0000¢\u0006\u0004\bB\u0010\u0018R\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\bC\u0010D\u001a\u0004\bE\u0010FR\u0017\u0010\u0007\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\bG\u0010H\u001a\u0004\bI\u0010\u001cR\u0017\u0010\t\u001a\u00020\b8\u0006¢\u0006\f\n\u0004\b2\u0010J\u001a\u0004\bK\u0010\u001fR\u0014\u0010N\u001a\u00020L8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010MR\u001a\u0010S\u001a\u00020O8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u0011\u0010P\u001a\u0004\bQ\u0010RR\u0014\u0010V\u001a\u00020T8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\r\u0010UR\u0014\u0010Y\u001a\u00020W8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0019\u0010XR\u0018\u0010\\\u001a\u0004\u0018\u00010Z8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b+\u0010[R\u0018\u0010_\u001a\u0004\u0018\u00010]8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b?\u0010^R(\u00101\u001a\u0004\u0018\u0001002\b\u0010`\u001a\u0004\u0018\u0001008\u0006@BX\u0086\u000e¢\u0006\f\n\u0004\bE\u0010a\u001a\u0004\bb\u0010cR\u0016\u0010d\u001a\u00020\b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bb\u0010JR(\u0010h\u001a\u0004\u0018\u00010-2\b\u0010`\u001a\u0004\u0018\u00010-8\u0000@BX\u0080\u000e¢\u0006\f\n\u0004\bQ\u0010e\u001a\u0004\bf\u0010gR\u0016\u0010i\u001a\u00020\b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bK\u0010JR\u0016\u0010j\u001a\u00020\b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bf\u0010JR\u0016\u0010k\u001a\u00020\b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bI\u0010JR\u0016\u0010m\u001a\u00020\b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bl\u0010JR\u0018\u00104\u001a\u0004\u0018\u00010-8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b'\u0010eR \u0010r\u001a\b\u0012\u0004\u0012\u00020o0n8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b.\u0010p\u001a\u0004\bl\u0010q¨\u0006u"}, d2 = {"Lokhttp3/internal/connection/RealCall;", "Lokhttp3/Call;", StringUtils.EMPTY, "Lokhttp3/internal/concurrent/Lockable;", "Lokhttp3/OkHttpClient;", "client", "Lokhttp3/Request;", "originalRequest", StringUtils.EMPTY, "forWebSocket", "<init>", "(Lokhttp3/OkHttpClient;Lokhttp3/Request;Z)V", StringUtils.EMPTY, "f", "()V", "Ljava/io/IOException;", "E", "e", "d", "(Ljava/io/IOException;)Ljava/io/IOException;", "cause", "z", StringUtils.EMPTY, "A", "()Ljava/lang/String;", "g", "()Lokhttp3/Call;", "request", "()Lokhttp3/Request;", "cancel", "isCanceled", "()Z", "Lokhttp3/Response;", "execute", "()Lokhttp3/Response;", "Lokhttp3/Callback;", "responseCallback", "G2", "(Lokhttp3/Callback;)V", "q", "newRoutePlanner", "Lokhttp3/internal/http/RealInterceptorChain;", "chain", "h", "(Lokhttp3/Request;ZLokhttp3/internal/http/RealInterceptorChain;)V", "Lokhttp3/internal/connection/Exchange;", "r", "(Lokhttp3/internal/http/RealInterceptorChain;)Lokhttp3/internal/connection/Exchange;", "Lokhttp3/internal/connection/RealConnection;", "connection", "c", "(Lokhttp3/internal/connection/RealConnection;)V", "exchange", "requestDone", "responseDone", "s", "(Lokhttp3/internal/connection/Exchange;ZZLjava/io/IOException;)Ljava/io/IOException;", "u", "Ljava/net/Socket;", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "()Ljava/net/Socket;", "y", "closeExchange", "i", "(Z)V", "x", "v", "a", "Lokhttp3/OkHttpClient;", "j", "()Lokhttp3/OkHttpClient;", "b", "Lokhttp3/Request;", "o", "Z", "m", "Lokhttp3/internal/connection/RealConnectionPool;", "Lokhttp3/internal/connection/RealConnectionPool;", "connectionPool", "Lokhttp3/EventListener;", "Lokhttp3/EventListener;", "l", "()Lokhttp3/EventListener;", "eventListener", "okhttp3/internal/connection/RealCall$timeout$1", "Lokhttp3/internal/connection/RealCall$timeout$1;", "timeout", "Ljava/util/concurrent/atomic/AtomicBoolean;", "Ljava/util/concurrent/atomic/AtomicBoolean;", "executed", StringUtils.EMPTY, "Ljava/lang/Object;", "callStackTrace", "Lokhttp3/internal/connection/ExchangeFinder;", "Lokhttp3/internal/connection/ExchangeFinder;", "exchangeFinder", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "Lokhttp3/internal/connection/RealConnection;", "k", "()Lokhttp3/internal/connection/RealConnection;", "timeoutEarlyExit", "Lokhttp3/internal/connection/Exchange;", "n", "()Lokhttp3/internal/connection/Exchange;", "interceptorScopedExchange", "requestBodyOpen", "responseBodyOpen", "expectMoreExchanges", "p", "canceled", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lokhttp3/internal/connection/RoutePlanner$Plan;", "Ljava/util/concurrent/CopyOnWriteArrayList;", "()Ljava/util/concurrent/CopyOnWriteArrayList;", "plansToCancel", "AsyncCall", "CallReference", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nRealCall.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RealCall.kt\nokhttp3/internal/connection/RealCall\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,564:1\n1#2:565\n63#3:566\n63#3:567\n63#3:568\n55#3,4:569\n63#3:573\n63#3:574\n49#3,4:575\n49#3,4:579\n63#3:583\n55#3,4:584\n63#3:595\n360#4,7:588\n*S KotlinDebug\n*F\n+ 1 RealCall.kt\nokhttp3/internal/connection/RealCall\n*L\n239#1:566\n273#1:567\n285#1:568\n295#1:569,4\n320#1:573\n343#1:574\n370#1:575,4\n374#1:579,4\n376#1:583\n407#1:584,4\n451#1:595\n410#1:588,7\n*E\n"})
public final class RealCall implements Call, Cloneable, Lockable {
    private final OkHttpClient a;
    private final Request b;
    private final boolean c;
    private final RealConnectionPool d;
    private final EventListener e;
    private final RealCall$timeout$1 f;
    private final AtomicBoolean g;
    private Object h;
    private ExchangeFinder i;
    private RealConnection j;
    private boolean k;
    private Exchange l;
    private boolean m;
    private boolean n;
    private boolean o;
    private volatile boolean p;
    private volatile Exchange q;
    private final CopyOnWriteArrayList r;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0007\b\u0086\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u0019\u0010\t\u001a\u00020\b2\n\u0010\u0007\u001a\u00060\u0000R\u00020\u0006¢\u0006\u0004\b\t\u0010\nJ\u0015\u0010\r\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\u000b¢\u0006\u0004\b\r\u0010\u000eJ\u001b\u0010\u0011\u001a\u00020\b2\n\b\u0002\u0010\u0010\u001a\u0004\u0018\u00010\u000fH\u0000¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0013\u001a\u00020\bH\u0016¢\u0006\u0004\b\u0013\u0010\u0014R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\r\u0010\u0015R$\u0010\u001a\u001a\u00020\u00162\u0006\u0010\u0017\u001a\u00020\u00168\u0006@BX\u0086\u000e¢\u0006\f\n\u0004\b\u0011\u0010\u0018\u001a\u0004\b\u0010\u0010\u0019R\u0011\u0010\u001e\u001a\u00020\u001b8F¢\u0006\u0006\u001a\u0004\b\u001c\u0010\u001dR\u0011\u0010!\u001a\u00020\u00068F¢\u0006\u0006\u001a\u0004\b\u001f\u0010 ¨\u0006\""}, d2 = {"Lokhttp3/internal/connection/RealCall$AsyncCall;", "Ljava/lang/Runnable;", "Lokhttp3/Callback;", "responseCallback", "<init>", "(Lokhttp3/internal/connection/RealCall;Lokhttp3/Callback;)V", "Lokhttp3/internal/connection/RealCall;", "other", StringUtils.EMPTY, "g", "(Lokhttp3/internal/connection/RealCall$AsyncCall;)V", "Ljava/util/concurrent/ExecutorService;", "executorService", "a", "(Ljava/util/concurrent/ExecutorService;)V", "Ljava/util/concurrent/RejectedExecutionException;", "e", "b", "(Ljava/util/concurrent/RejectedExecutionException;)V", "run", "()V", "Lokhttp3/Callback;", "Ljava/util/concurrent/atomic/AtomicInteger;", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "Ljava/util/concurrent/atomic/AtomicInteger;", "()Ljava/util/concurrent/atomic/AtomicInteger;", "callsPerHost", StringUtils.EMPTY, "f", "()Ljava/lang/String;", "host", "d", "()Lokhttp3/internal/connection/RealCall;", "call", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nRealCall.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RealCall.kt\nokhttp3/internal/connection/RealCall$AsyncCall\n+ 2 -UtilJvm.kt\nokhttp3/internal/_UtilJvmKt\n*L\n1#1,564:1\n233#2,9:565\n*S KotlinDebug\n*F\n+ 1 RealCall.kt\nokhttp3/internal/connection/RealCall$AsyncCall\n*L\n526#1:565,9\n*E\n"})
    public final class AsyncCall implements Runnable {
        private final Callback a;
        private volatile AtomicInteger b;
        final /* synthetic */ RealCall c;

        public AsyncCall(RealCall realCall, Callback callback) {
            Intrinsics.checkNotNullParameter(callback, ap.a(335651849));
            this.c = realCall;
            this.a = callback;
            this.b = new AtomicInteger(0);
        }

        public static /* synthetic */ void c(AsyncCall asyncCall, RejectedExecutionException rejectedExecutionException, int i, Object obj) {
            if ((i & 1) != 0) {
                rejectedExecutionException = null;
            }
            asyncCall.b(rejectedExecutionException);
        }

        public final void a(ExecutorService executorService) {
            Intrinsics.checkNotNullParameter(executorService, "executorService");
            _UtilJvmKt.e(this.c.j().p());
            try {
                try {
                    executorService.execute(this);
                } catch (RejectedExecutionException e) {
                    b(e);
                    this.c.j().p().g(this);
                }
            } catch (Throwable th) {
                this.c.j().p().g(this);
                throw th;
            }
        }

        public final void b(RejectedExecutionException rejectedExecutionException) {
            InterruptedIOException interruptedIOException = new InterruptedIOException("executor rejected");
            interruptedIOException.initCause(rejectedExecutionException);
            this.c.u(interruptedIOException);
            this.a.onFailure(this.c, interruptedIOException);
        }

        public final RealCall d() {
            return this.c;
        }

        public final AtomicInteger e() {
            return this.b;
        }

        public final String f() {
            return this.c.o().m().g();
        }

        public final void g(AsyncCall asyncCall) {
            Intrinsics.checkNotNullParameter(asyncCall, "other");
            this.b = asyncCall.b;
        }

        @Override // java.lang.Runnable
        public void run() {
            boolean z;
            Throwable th;
            IOException e;
            OkHttpClient okHttpClientJ;
            String str = "OkHttp " + this.c.v();
            RealCall realCall = this.c;
            Thread threadCurrentThread = Thread.currentThread();
            String name = threadCurrentThread.getName();
            threadCurrentThread.setName(str);
            try {
                realCall.f.u();
                try {
                    try {
                        z = true;
                        try {
                            this.a.onResponse(realCall, realCall.q());
                            okHttpClientJ = realCall.j();
                        } catch (IOException e2) {
                            e = e2;
                            if (z) {
                                Platform.a.e().n("Callback failure for " + realCall.A(), 4, e);
                            } else {
                                this.a.onFailure(realCall, e);
                            }
                            okHttpClientJ = realCall.j();
                        } catch (Throwable th2) {
                            th = th2;
                            realCall.cancel();
                            if (!z) {
                                IOException iOException = new IOException("canceled due to " + th);
                                ExceptionsKt.addSuppressed(iOException, th);
                                this.a.onFailure(realCall, iOException);
                            }
                            throw th;
                        }
                    } catch (Throwable th3) {
                        realCall.j().p().g(this);
                        throw th3;
                    }
                } catch (IOException e3) {
                    z = false;
                    e = e3;
                } catch (Throwable th4) {
                    z = false;
                    th = th4;
                }
                okHttpClientJ.p().g(this);
            } finally {
                threadCurrentThread.setName(name);
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\b\u0007\b\u0000\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001B\u0019\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\u0006\u0010\u0007R\u0019\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\b\u0010\n¨\u0006\u000b"}, d2 = {"Lokhttp3/internal/connection/RealCall$CallReference;", "Ljava/lang/ref/WeakReference;", "Lokhttp3/internal/connection/RealCall;", "referent", StringUtils.EMPTY, "callStackTrace", "<init>", "(Lokhttp3/internal/connection/RealCall;Ljava/lang/Object;)V", "a", "Ljava/lang/Object;", "()Ljava/lang/Object;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class CallReference extends WeakReference<RealCall> {
        private final Object a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public CallReference(RealCall realCall, Object obj) {
            super(realCall);
            Intrinsics.checkNotNullParameter(realCall, ap.a(998301438));
            this.a = obj;
        }

        public final Object a() {
            return this.a;
        }
    }

    /* JADX WARN: Type inference failed for: r4v5, types: [okhttp3.internal.connection.RealCall$timeout$1, okio.Timeout] */
    public RealCall(OkHttpClient okHttpClient, Request request, boolean z) {
        Intrinsics.checkNotNullParameter(okHttpClient, ap.a(1678098154));
        Intrinsics.checkNotNullParameter(request, ap.a(1159198924));
        this.a = okHttpClient;
        this.b = request;
        this.c = z;
        this.d = okHttpClient.m().e();
        this.e = okHttpClient.r().a(this);
        ?? r4 = new AsyncTimeout() { // from class: okhttp3.internal.connection.RealCall$timeout$1
            @Override // okio.AsyncTimeout
            protected void D() {
                this.q.cancel();
            }
        };
        r4.h(okHttpClient.i(), TimeUnit.MILLISECONDS);
        this.f = r4;
        this.g = new AtomicBoolean();
        this.o = true;
        this.r = new CopyOnWriteArrayList();
    }

    private final String A() {
        StringBuilder sb = new StringBuilder();
        sb.append(isCanceled() ? "canceled " : StringUtils.EMPTY);
        sb.append(this.c ? "web socket" : "call");
        sb.append(" to ");
        sb.append(v());
        return sb.toString();
    }

    private final IOException d(IOException iOException) {
        Socket socketW;
        boolean z = _UtilJvmKt.b;
        if (z && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
        }
        RealConnection realConnection = this.j;
        if (realConnection != null) {
            if (z && Thread.holdsLock(realConnection)) {
                throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + realConnection);
            }
            synchronized (realConnection) {
                socketW = w();
            }
            if (this.j == null) {
                if (socketW != null) {
                    _UtilJvmKt.h(socketW);
                }
                this.e.l(this, realConnection);
                realConnection.k().g(realConnection, this);
                if (socketW != null) {
                    realConnection.k().f(realConnection);
                }
            } else if (socketW != null) {
                throw new IllegalStateException("Check failed.");
            }
        }
        IOException iOExceptionZ = z(iOException);
        if (iOException == null) {
            this.e.d(this);
            return iOExceptionZ;
        }
        EventListener eventListener = this.e;
        Intrinsics.checkNotNull(iOExceptionZ);
        eventListener.e(this, iOExceptionZ);
        return iOExceptionZ;
    }

    private final void f() {
        this.h = Platform.a.e().l("response.body().close()");
        this.e.f(this);
    }

    public static /* synthetic */ IOException t(RealCall realCall, Exchange exchange, boolean z, boolean z2, IOException iOException, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        if ((i & 4) != 0) {
            z2 = false;
        }
        return realCall.s(exchange, z, z2, iOException);
    }

    private final IOException z(IOException iOException) {
        if (this.k || !v()) {
            return iOException;
        }
        InterruptedIOException interruptedIOException = new InterruptedIOException("timeout");
        if (iOException != null) {
            interruptedIOException.initCause(iOException);
        }
        return interruptedIOException;
    }

    @Override // okhttp3.Call
    public void G2(Callback callback) {
        Intrinsics.checkNotNullParameter(callback, "responseCallback");
        if (!this.g.compareAndSet(false, true)) {
            throw new IllegalStateException("Already Executed");
        }
        f();
        this.a.p().b(new AsyncCall(this, callback));
    }

    public final void c(RealConnection realConnection) {
        Intrinsics.checkNotNullParameter(realConnection, "connection");
        if (!_UtilJvmKt.b || Thread.holdsLock(realConnection)) {
            if (this.j != null) {
                throw new IllegalStateException("Check failed.");
            }
            this.j = realConnection;
            realConnection.j().add(new CallReference(this, this.h));
            return;
        }
        throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + realConnection);
    }

    @Override // okhttp3.Call
    public void cancel() {
        if (this.p) {
            return;
        }
        this.p = true;
        Exchange exchange = this.q;
        if (exchange != null) {
            exchange.d();
        }
        Iterator it = this.r.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        while (it.hasNext()) {
            ((RoutePlanner.Plan) it.next()).cancel();
        }
        this.e.g(this);
    }

    @Override // okhttp3.Call
    public Response execute() {
        if (!this.g.compareAndSet(false, true)) {
            throw new IllegalStateException("Already Executed");
        }
        u();
        f();
        try {
            this.a.p().c(this);
            return q();
        } finally {
            this.a.p().h(this);
        }
    }

    /* JADX INFO: renamed from: g, reason: merged with bridge method [inline-methods] */
    public Call clone() {
        return new RealCall(this.a, this.b, this.c);
    }

    public final void h(Request request, boolean z, RealInterceptorChain realInterceptorChain) {
        Intrinsics.checkNotNullParameter(request, "request");
        Intrinsics.checkNotNullParameter(realInterceptorChain, "chain");
        if (this.l != null) {
            throw new IllegalStateException("Check failed.");
        }
        synchronized (this) {
            if (this.n) {
                throw new IllegalStateException("cannot make a new request because the previous response is still open: please call response.close()");
            }
            if (this.m) {
                throw new IllegalStateException("Check failed.");
            }
            Unit unit = Unit.INSTANCE;
        }
        if (z) {
            RealRoutePlanner realRoutePlanner = new RealRoutePlanner(this.a.w(), this.d, this.a.H(), this.a.N(), realInterceptorChain.f(), realInterceptorChain.h(), this.a.C(), this.a.I(), this.a.s(), this.a.f(request.m()), this.a.v(), new CallConnectionUser(this, this.d.g(), realInterceptorChain));
            this.i = this.a.s() ? new FastFallbackExchangeFinder(realRoutePlanner, this.a.w()) : new SequentialExchangeFinder(realRoutePlanner);
        }
    }

    public final void i(boolean z) {
        Exchange exchange;
        synchronized (this) {
            if (!this.o) {
                throw new IllegalStateException("released");
            }
            Unit unit = Unit.INSTANCE;
        }
        if (z && (exchange = this.q) != null) {
            exchange.f();
        }
        this.l = null;
    }

    @Override // okhttp3.Call
    public boolean isCanceled() {
        return this.p;
    }

    public final OkHttpClient j() {
        return this.a;
    }

    public final RealConnection k() {
        return this.j;
    }

    public final EventListener l() {
        return this.e;
    }

    public final boolean m() {
        return this.c;
    }

    public final Exchange n() {
        return this.l;
    }

    public final Request o() {
        return this.b;
    }

    public final CopyOnWriteArrayList p() {
        return this.r;
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x009d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final okhttp3.Response q() {
        /*
            r9 = this;
            java.util.ArrayList r2 = new java.util.ArrayList
            r2.<init>()
            okhttp3.OkHttpClient r0 = r9.a
            java.util.List r0 = r0.y()
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            kotlin.collections.CollectionsKt.addAll(r2, r0)
            okhttp3.internal.http.RetryAndFollowUpInterceptor r0 = new okhttp3.internal.http.RetryAndFollowUpInterceptor
            okhttp3.OkHttpClient r1 = r9.a
            r0.<init>(r1)
            r2.add(r0)
            okhttp3.internal.http.BridgeInterceptor r0 = new okhttp3.internal.http.BridgeInterceptor
            okhttp3.OkHttpClient r1 = r9.a
            okhttp3.CookieJar r1 = r1.o()
            r0.<init>(r1)
            r2.add(r0)
            okhttp3.internal.cache.CacheInterceptor r0 = new okhttp3.internal.cache.CacheInterceptor
            okhttp3.OkHttpClient r1 = r9.a
            okhttp3.Cache r1 = r1.h()
            r0.<init>(r1)
            r2.add(r0)
            okhttp3.internal.connection.ConnectInterceptor r0 = okhttp3.internal.connection.ConnectInterceptor.a
            r2.add(r0)
            boolean r0 = r9.c
            if (r0 != 0) goto L4a
            okhttp3.OkHttpClient r0 = r9.a
            java.util.List r0 = r0.A()
            java.lang.Iterable r0 = (java.lang.Iterable) r0
            kotlin.collections.CollectionsKt.addAll(r2, r0)
        L4a:
            okhttp3.internal.http.CallServerInterceptor r0 = new okhttp3.internal.http.CallServerInterceptor
            boolean r1 = r9.c
            r0.<init>(r1)
            r2.add(r0)
            okhttp3.internal.http.RealInterceptorChain r0 = new okhttp3.internal.http.RealInterceptorChain
            okhttp3.Request r5 = r9.b
            okhttp3.OkHttpClient r1 = r9.a
            int r6 = r1.l()
            okhttp3.OkHttpClient r1 = r9.a
            int r7 = r1.H()
            okhttp3.OkHttpClient r1 = r9.a
            int r8 = r1.N()
            r3 = 0
            r4 = 0
            r1 = r9
            r0.<init>(r1, r2, r3, r4, r5, r6, r7, r8)
            r9 = 0
            r2 = 0
            okhttp3.Request r3 = r1.b     // Catch: java.lang.Throwable -> L8d java.io.IOException -> L8f
            okhttp3.Response r0 = r0.a(r3)     // Catch: java.lang.Throwable -> L8d java.io.IOException -> L8f
            boolean r3 = r1.isCanceled()     // Catch: java.lang.Throwable -> L8d java.io.IOException -> L8f
            if (r3 != 0) goto L82
            r1.u(r9)
            return r0
        L82:
            okhttp3.internal._UtilCommonKt.f(r0)     // Catch: java.lang.Throwable -> L8d java.io.IOException -> L8f
            java.io.IOException r0 = new java.io.IOException     // Catch: java.lang.Throwable -> L8d java.io.IOException -> L8f
            java.lang.String r3 = "Canceled"
            r0.<init>(r3)     // Catch: java.lang.Throwable -> L8d java.io.IOException -> L8f
            throw r0     // Catch: java.lang.Throwable -> L8d java.io.IOException -> L8f
        L8d:
            r0 = move-exception
            goto L9b
        L8f:
            r0 = move-exception
            r2 = 1
            java.io.IOException r0 = r1.u(r0)     // Catch: java.lang.Throwable -> L8d
            java.lang.String r3 = "null cannot be cast to non-null type kotlin.Throwable"
            kotlin.jvm.internal.Intrinsics.checkNotNull(r0, r3)     // Catch: java.lang.Throwable -> L8d
            throw r0     // Catch: java.lang.Throwable -> L8d
        L9b:
            if (r2 != 0) goto La0
            r1.u(r9)
        La0:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.connection.RealCall.q():okhttp3.Response");
    }

    public final Exchange r(RealInterceptorChain realInterceptorChain) throws IOException {
        Intrinsics.checkNotNullParameter(realInterceptorChain, "chain");
        synchronized (this) {
            if (!this.o) {
                throw new IllegalStateException("released");
            }
            if (this.n) {
                throw new IllegalStateException("Check failed.");
            }
            if (this.m) {
                throw new IllegalStateException("Check failed.");
            }
            Unit unit = Unit.INSTANCE;
        }
        ExchangeFinder exchangeFinder = this.i;
        Intrinsics.checkNotNull(exchangeFinder);
        Exchange exchange = new Exchange(this, this.e, exchangeFinder, exchangeFinder.a().t(this.a, realInterceptorChain));
        this.l = exchange;
        this.q = exchange;
        synchronized (this) {
            this.m = true;
            this.n = true;
        }
        if (this.p) {
            throw new IOException("Canceled");
        }
        return exchange;
    }

    @Override // okhttp3.Call
    public Request request() {
        return this.b;
    }

    public final IOException s(Exchange exchange, boolean z, boolean z2, IOException iOException) {
        boolean z3;
        boolean z4;
        Intrinsics.checkNotNullParameter(exchange, "exchange");
        if (Intrinsics.areEqual(exchange, this.q)) {
            synchronized (this) {
                z3 = false;
                if (z) {
                    try {
                        if (!this.m) {
                            if (z2 || !this.n) {
                                z4 = false;
                            }
                            Unit unit = Unit.INSTANCE;
                        }
                        if (z) {
                            this.m = false;
                        }
                        if (z2) {
                            this.n = false;
                        }
                        boolean z5 = this.m;
                        boolean z6 = (z5 || this.n) ? false : true;
                        if (!z5 && !this.n && !this.o) {
                            z3 = true;
                        }
                        z4 = z3;
                        z3 = z6;
                        Unit unit2 = Unit.INSTANCE;
                    } catch (Throwable th) {
                        throw th;
                    }
                } else {
                    if (z2) {
                    }
                    z4 = false;
                    Unit unit22 = Unit.INSTANCE;
                }
            }
            if (z3) {
                this.q = null;
                RealConnection realConnection = this.j;
                if (realConnection != null) {
                    realConnection.p();
                }
            }
            if (z4) {
                return d(iOException);
            }
        }
        return iOException;
    }

    public final IOException u(IOException iOException) {
        boolean z;
        synchronized (this) {
            try {
                z = false;
                if (this.o) {
                    this.o = false;
                    if (!this.m && !this.n) {
                        z = true;
                    }
                }
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
        return z ? d(iOException) : iOException;
    }

    public final String v() {
        return this.b.m().q();
    }

    public final Socket w() {
        RealConnection realConnection = this.j;
        Intrinsics.checkNotNull(realConnection);
        if (_UtilJvmKt.b && !Thread.holdsLock(realConnection)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + realConnection);
        }
        List listJ = realConnection.j();
        Iterator it = listJ.iterator();
        int i = 0;
        while (true) {
            if (!it.hasNext()) {
                i = -1;
                break;
            }
            if (Intrinsics.areEqual(((Reference) it.next()).get(), this)) {
                break;
            }
            i++;
        }
        if (i == -1) {
            throw new IllegalStateException("Check failed.");
        }
        listJ.remove(i);
        this.j = null;
        if (listJ.isEmpty()) {
            realConnection.y(System.nanoTime());
            if (this.d.d(realConnection)) {
                return realConnection.A();
            }
        }
        return null;
    }

    public final boolean x() {
        Exchange exchange = this.q;
        if (exchange == null || !exchange.m()) {
            return false;
        }
        ExchangeFinder exchangeFinder = this.i;
        Intrinsics.checkNotNull(exchangeFinder);
        RoutePlanner routePlannerB = exchangeFinder.b();
        Exchange exchange2 = this.q;
        return routePlannerB.a(exchange2 != null ? exchange2.j() : null);
    }

    public final void y() {
        if (this.k) {
            throw new IllegalStateException("Check failed.");
        }
        this.k = true;
        v();
    }
}