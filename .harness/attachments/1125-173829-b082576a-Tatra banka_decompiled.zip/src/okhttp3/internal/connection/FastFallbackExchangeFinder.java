package okhttp3.internal.connection;

import h.ap;
import java.io.IOException;
import java.util.Iterator;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import kotlin.ExceptionsKt;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.concurrent.Task;
import okhttp3.internal.concurrent.TaskQueue;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.connection.RoutePlanner;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0011\u0010\t\u001a\u0004\u0018\u00010\bH\u0002¢\u0006\u0004\b\t\u0010\nJ!\u0010\u000f\u001a\u0004\u0018\u00010\b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\rH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u000f\u0010\u0012\u001a\u00020\u0011H\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0015\u001a\u00020\u0014H\u0016¢\u0006\u0004\b\u0015\u0010\u0016R\u001a\u0010\u0003\u001a\u00020\u00028\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u0015\u0010\u0017\u001a\u0004\b\u0018\u0010\u0019R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0018\u0010\u001aR\u0014\u0010\u001d\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001b\u0010\u001cR\u0016\u0010\u001f\u001a\u00020\u000b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001e\u0010\u001cR\u001a\u0010#\u001a\b\u0012\u0004\u0012\u00020!0 8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\"R\"\u0010'\u001a\u0010\u0012\f\u0012\n %*\u0004\u0018\u00010\b0\b0$8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010&¨\u0006("}, d2 = {"Lokhttp3/internal/connection/FastFallbackExchangeFinder;", "Lokhttp3/internal/connection/ExchangeFinder;", "Lokhttp3/internal/connection/RoutePlanner;", "routePlanner", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", "<init>", "(Lokhttp3/internal/connection/RoutePlanner;Lokhttp3/internal/concurrent/TaskRunner;)V", "Lokhttp3/internal/connection/RoutePlanner$ConnectResult;", "g", "()Lokhttp3/internal/connection/RoutePlanner$ConnectResult;", StringUtils.EMPTY, "timeout", "Ljava/util/concurrent/TimeUnit;", "unit", "e", "(JLjava/util/concurrent/TimeUnit;)Lokhttp3/internal/connection/RoutePlanner$ConnectResult;", StringUtils.EMPTY, "f", "()V", "Lokhttp3/internal/connection/RealConnection;", "a", "()Lokhttp3/internal/connection/RealConnection;", "Lokhttp3/internal/connection/RoutePlanner;", "b", "()Lokhttp3/internal/connection/RoutePlanner;", "Lokhttp3/internal/concurrent/TaskRunner;", "c", "J", "connectDelayNanos", "d", "nextTcpConnectAtNanos", "Ljava/util/concurrent/CopyOnWriteArrayList;", "Lokhttp3/internal/connection/RoutePlanner$Plan;", "Ljava/util/concurrent/CopyOnWriteArrayList;", "tcpConnectsInFlight", "Ljava/util/concurrent/BlockingQueue;", "kotlin.jvm.PlatformType", "Ljava/util/concurrent/BlockingQueue;", "connectResults", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class FastFallbackExchangeFinder implements ExchangeFinder {
    private final RoutePlanner a;
    private final TaskRunner b;
    private final long c;
    private long d;
    private final CopyOnWriteArrayList e;
    private final BlockingQueue f;

    public FastFallbackExchangeFinder(RoutePlanner routePlanner, TaskRunner taskRunner) {
        Intrinsics.checkNotNullParameter(routePlanner, ap.a(387176637));
        Intrinsics.checkNotNullParameter(taskRunner, ap.a(171817790));
        this.a = routePlanner;
        this.b = taskRunner;
        this.c = TimeUnit.MILLISECONDS.toNanos(250L);
        this.d = Long.MIN_VALUE;
        this.e = new CopyOnWriteArrayList();
        this.f = taskRunner.h().e(new LinkedBlockingDeque());
    }

    private final RoutePlanner.ConnectResult e(long j, TimeUnit timeUnit) {
        RoutePlanner.ConnectResult connectResult;
        if (this.e.isEmpty() || (connectResult = (RoutePlanner.ConnectResult) this.f.poll(j, timeUnit)) == null) {
            return null;
        }
        this.e.remove(connectResult.d());
        return connectResult;
    }

    private final void f() {
        Iterator it = this.e.iterator();
        Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
        while (it.hasNext()) {
            RoutePlanner.Plan plan = (RoutePlanner.Plan) it.next();
            plan.cancel();
            RoutePlanner.Plan planA = plan.a();
            if (planA != null) {
                b().b().addLast(planA);
            }
        }
        this.e.clear();
    }

    private final RoutePlanner.ConnectResult g() {
        final RoutePlanner.Plan failedPlan;
        if (RoutePlanner.d(b(), null, 1, null)) {
            try {
                failedPlan = b().e();
            } catch (Throwable th) {
                failedPlan = new FailedPlan(th);
            }
            if (failedPlan.isReady()) {
                return new RoutePlanner.ConnectResult(failedPlan, null, null, 6, null);
            }
            if (failedPlan instanceof FailedPlan) {
                return ((FailedPlan) failedPlan).e();
            }
            this.e.add(failedPlan);
            final String str = _UtilJvmKt.c + " connect " + b().getAddress().l().q();
            TaskQueue.m(this.b.k(), new Task(str) { // from class: okhttp3.internal.connection.FastFallbackExchangeFinder$launchTcpConnect$1
                @Override // okhttp3.internal.concurrent.Task
                public long f() throws InterruptedException {
                    RoutePlanner.ConnectResult connectResult;
                    try {
                        connectResult = failedPlan.f();
                    } catch (Throwable th2) {
                        connectResult = new RoutePlanner.ConnectResult(failedPlan, null, th2, 2, null);
                    }
                    if (!this.e.contains(failedPlan)) {
                        return -1L;
                    }
                    this.f.put(connectResult);
                    return -1L;
                }
            }, 0L, 2, null);
        }
        return null;
    }

    @Override // okhttp3.internal.connection.ExchangeFinder
    public RealConnection a() throws IOException {
        RoutePlanner.ConnectResult connectResultG;
        long j;
        IOException iOException = null;
        while (true) {
            try {
                if (this.e.isEmpty() && !RoutePlanner.d(b(), null, 1, null)) {
                    f();
                    Intrinsics.checkNotNull(iOException);
                    throw iOException;
                }
                if (b().isCanceled()) {
                    throw new IOException("Canceled");
                }
                long jB = this.b.h().b();
                long j2 = this.d - jB;
                if (this.e.isEmpty() || j2 <= 0) {
                    connectResultG = g();
                    j = this.c;
                    this.d = jB + j;
                } else {
                    j = j2;
                    connectResultG = null;
                }
                if (connectResultG != null || (connectResultG = e(j, TimeUnit.NANOSECONDS)) != null) {
                    if (connectResultG.f()) {
                        f();
                        if (!connectResultG.d().isReady()) {
                            connectResultG = connectResultG.d().d();
                        }
                        if (connectResultG.f()) {
                            return connectResultG.d().b();
                        }
                    }
                    Throwable thE = connectResultG.e();
                    if (thE != null) {
                        if (!(thE instanceof IOException)) {
                            throw thE;
                        }
                        if (iOException == null) {
                            iOException = (IOException) thE;
                        } else {
                            ExceptionsKt.addSuppressed(iOException, thE);
                        }
                    }
                    RoutePlanner.Plan planC = connectResultG.c();
                    if (planC != null) {
                        b().b().addFirst(planC);
                    }
                }
            } finally {
                f();
            }
        }
    }

    @Override // okhttp3.internal.connection.ExchangeFinder
    public RoutePlanner b() {
        return this.a;
    }
}