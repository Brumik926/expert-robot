package okhttp3.internal;

import h.ap;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.collections.IntIterator;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.ranges.IntRange;
import kotlin.ranges.RangesKt;
import kotlin.text.Charsets;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.Call;
import okhttp3.Dispatcher;
import okhttp3.EventListener;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Response;
import okhttp3.internal.http2.Header;
import okio.Buffer;
import okio.BufferedSource;
import okio.Source;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.metadata.TikaCoreProperties;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0094\u0001\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0011\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\u001a\u001f\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0001\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u0002H\u0000¢\u0006\u0004\b\u0005\u0010\u0006\u001a\u001d\u0010\t\u001a\u00020\u0000*\u00020\u00072\b\b\u0002\u0010\b\u001a\u00020\u0002H\u0000¢\u0006\u0004\b\t\u0010\n\u001a+\u0010\u000f\u001a\u00020\u00002\u0006\u0010\u000b\u001a\u00020\u00002\u0012\u0010\u000e\u001a\n\u0012\u0006\b\u0001\u0012\u00020\r0\f\"\u00020\rH\u0000¢\u0006\u0004\b\u000f\u0010\u0010\u001a\u001b\u0010\u0014\u001a\u00020\u0012*\u00020\u00112\u0006\u0010\u0013\u001a\u00020\u0012H\u0000¢\u0006\u0004\b\u0014\u0010\u0015\u001a'\u0010\u001b\u001a\u00020\u001a2\u0006\u0010\u0001\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0019\u001a\u00020\u0018H\u0000¢\u0006\u0004\b\u001b\u0010\u001c\u001a\u0019\u0010 \u001a\u00020\u001f*\b\u0012\u0004\u0012\u00020\u001e0\u001dH\u0000¢\u0006\u0004\b \u0010!\u001a\u0019\u0010\"\u001a\b\u0012\u0004\u0012\u00020\u001e0\u001d*\u00020\u001fH\u0000¢\u0006\u0004\b\"\u0010#\u001a\u001b\u0010%\u001a\u00020\u0002*\u00020\u00072\u0006\u0010$\u001a\u00020\u0007H\u0000¢\u0006\u0004\b%\u0010&\u001a\u0013\u0010)\u001a\u00020(*\u00020'H\u0000¢\u0006\u0004\b)\u0010*\u001a#\u0010-\u001a\u00020\u0002*\u00020+2\u0006\u0010\u0017\u001a\u00020\u001a2\u0006\u0010,\u001a\u00020\u0018H\u0000¢\u0006\u0004\b-\u0010.\u001a#\u00100\u001a\u00020\u0002*\u00020+2\u0006\u0010/\u001a\u00020\u001a2\u0006\u0010,\u001a\u00020\u0018H\u0000¢\u0006\u0004\b0\u0010.\u001a\u001b\u00103\u001a\u00020\u0002*\u0002012\u0006\u00102\u001a\u00020\u0011H\u0000¢\u0006\u0004\b3\u00104\u001a\u0013\u00106\u001a\u00020\u0016*\u000205H\u0000¢\u0006\u0004\b6\u00107\u001a%\u00109\u001a\b\u0012\u0004\u0012\u00028\u00000\u001d\"\u0004\b\u0000\u00108*\b\u0012\u0004\u0012\u00028\u00000\u001dH\u0000¢\u0006\u0004\b9\u0010:\u001a/\u0010<\u001a\b\u0012\u0004\u0012\u00028\u00000\u001d\"\u0004\b\u0000\u001082\u0012\u0010;\u001a\n\u0012\u0006\b\u0001\u0012\u00028\u00000\f\"\u00028\u0000H\u0001¢\u0006\u0004\b<\u0010=\u001a)\u0010>\u001a\b\u0012\u0004\u0012\u00028\u00000\u001d\"\u0004\b\u0000\u00108*\f\u0012\u0006\b\u0001\u0012\u00028\u0000\u0018\u00010\fH\u0000¢\u0006\u0004\b>\u0010=\u001a\u0013\u0010@\u001a\u00020?*\u000201H\u0000¢\u0006\u0004\b@\u0010A\u001a\u0013\u0010B\u001a\u00020\u0000*\u00020\u0016H\u0000¢\u0006\u0004\bB\u0010C\u001a\u0013\u0010D\u001a\u00020\u0000*\u00020\u001aH\u0000¢\u0006\u0004\bD\u0010E\u001a\u0013\u0010G\u001a\u00020?*\u00020FH\u0000¢\u0006\u0004\bG\u0010H\"\u0014\u0010L\u001a\u00020I8\u0000X\u0081\u0004¢\u0006\u0006\n\u0004\bJ\u0010K\"\u0014\u0010O\u001a\u00020\u00028\u0000X\u0081\u0004¢\u0006\u0006\n\u0004\bM\u0010N\"\u0014\u0010Q\u001a\u00020\u00008\u0000X\u0081\u0004¢\u0006\u0006\n\u0004\b)\u0010P¨\u0006R"}, d2 = {StringUtils.EMPTY, "name", StringUtils.EMPTY, "daemon", "Ljava/util/concurrent/ThreadFactory;", "p", "(Ljava/lang/String;Z)Ljava/util/concurrent/ThreadFactory;", "Lokhttp3/HttpUrl;", "includeDefaultPort", "v", "(Lokhttp3/HttpUrl;Z)Ljava/lang/String;", "format", StringUtils.EMPTY, StringUtils.EMPTY, "args", "j", "(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;", "Lokio/BufferedSource;", "Ljava/nio/charset/Charset;", "default", "n", "(Lokio/BufferedSource;Ljava/nio/charset/Charset;)Ljava/nio/charset/Charset;", StringUtils.EMPTY, "duration", "Ljava/util/concurrent/TimeUnit;", "unit", StringUtils.EMPTY, "g", "(Ljava/lang/String;JLjava/util/concurrent/TimeUnit;)I", StringUtils.EMPTY, "Lokhttp3/internal/http2/Header;", "Lokhttp3/Headers;", "s", "(Ljava/util/List;)Lokhttp3/Headers;", "r", "(Lokhttp3/Headers;)Ljava/util/List;", "other", "f", "(Lokhttp3/HttpUrl;Lokhttp3/HttpUrl;)Z", "Lokhttp3/EventListener;", "Lokhttp3/EventListener$Factory;", "c", "(Lokhttp3/EventListener;)Lokhttp3/EventListener$Factory;", "Lokio/Source;", "timeUnit", "o", "(Lokio/Source;ILjava/util/concurrent/TimeUnit;)Z", "timeout", "i", "Ljava/net/Socket;", ClimateForcast.SOURCE, "m", "(Ljava/net/Socket;Lokio/BufferedSource;)Z", "Lokhttp3/Response;", "k", "(Lokhttp3/Response;)J", "T", "x", "(Ljava/util/List;)Ljava/util/List;", "elements", "l", "([Ljava/lang/Object;)Ljava/util/List;", "y", StringUtils.EMPTY, "h", "(Ljava/net/Socket;)V", "u", "(J)Ljava/lang/String;", "t", "(I)Ljava/lang/String;", "Lokhttp3/Dispatcher;", "e", "(Lokhttp3/Dispatcher;)V", "Ljava/util/TimeZone;", "a", "Ljava/util/TimeZone;", "UTC", "b", "Z", "assertionsEnabled", "Ljava/lang/String;", "okHttpName", "okhttp"}, k = 2, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\n-UtilJvm.kt\nKotlin\n*S Kotlin\n*F\n+ 1 -UtilJvm.kt\nokhttp3/internal/_UtilJvmKt\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,361:1\n248#1:367\n248#1:368\n1#2:362\n1563#3:363\n1634#3,3:364\n*S KotlinDebug\n*F\n+ 1 -UtilJvm.kt\nokhttp3/internal/_UtilJvmKt\n*L\n266#1:367\n278#1:368\n132#1:363\n132#1:364,3\n*E\n"})
public final class _UtilJvmKt {
    public static final TimeZone a;
    public static final boolean b;
    public static final String c;

    static {
        TimeZone timeZone = TimeZone.getTimeZone(ap.a(1282692483));
        Intrinsics.checkNotNull(timeZone);
        a = timeZone;
        b = false;
        String name = OkHttpClient.class.getName();
        Intrinsics.checkNotNullExpressionValue(name, ap.a(907642941));
        c = StringsKt.removeSuffix(StringsKt.removePrefix(name, (CharSequence) ap.a(2022232279)), (CharSequence) ap.a(1060119869));
    }

    public static final EventListener.Factory c(final EventListener eventListener) {
        Intrinsics.checkNotNullParameter(eventListener, "<this>");
        return new EventListener.Factory() { // from class: okhttp3.internal.a
            @Override // okhttp3.EventListener.Factory
            public final EventListener a(Call call) {
                return _UtilJvmKt.d(eventListener, call);
            }
        };
    }

    private static final EventListener d(EventListener eventListener, Call call) {
        Intrinsics.checkNotNullParameter(call, "it");
        return eventListener;
    }

    public static final void e(Dispatcher dispatcher) {
        Intrinsics.checkNotNullParameter(dispatcher, "<this>");
        if (b && Thread.holdsLock(dispatcher)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + dispatcher);
        }
    }

    public static final boolean f(HttpUrl httpUrl, HttpUrl httpUrl2) {
        Intrinsics.checkNotNullParameter(httpUrl, "<this>");
        Intrinsics.checkNotNullParameter(httpUrl2, "other");
        return Intrinsics.areEqual(httpUrl.g(), httpUrl2.g()) && httpUrl.l() == httpUrl2.l() && Intrinsics.areEqual(httpUrl.s(), httpUrl2.s());
    }

    public static final int g(String str, long j, TimeUnit timeUnit) {
        Intrinsics.checkNotNullParameter(str, "name");
        Intrinsics.checkNotNullParameter(timeUnit, "unit");
        if (j < 0) {
            throw new IllegalStateException((str + " < 0").toString());
        }
        long millis = timeUnit.toMillis(j);
        if (millis > 2147483647L) {
            throw new IllegalArgumentException((str + " too large").toString());
        }
        if (millis != 0 || j <= 0) {
            return (int) millis;
        }
        throw new IllegalArgumentException((str + " too small").toString());
    }

    public static final void h(Socket socket) {
        Intrinsics.checkNotNullParameter(socket, "<this>");
        try {
            socket.close();
        } catch (AssertionError e) {
            throw e;
        } catch (RuntimeException e2) {
            if (!Intrinsics.areEqual(e2.getMessage(), "bio == null")) {
                throw e2;
            }
        } catch (Exception unused) {
        }
    }

    public static final boolean i(Source source, int i, TimeUnit timeUnit) {
        Intrinsics.checkNotNullParameter(source, "<this>");
        Intrinsics.checkNotNullParameter(timeUnit, "timeUnit");
        try {
            return o(source, i, timeUnit);
        } catch (IOException unused) {
            return false;
        }
    }

    public static final String j(String str, Object... objArr) {
        Intrinsics.checkNotNullParameter(str, "format");
        Intrinsics.checkNotNullParameter(objArr, "args");
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        Locale locale = Locale.US;
        Object[] objArrCopyOf = Arrays.copyOf(objArr, objArr.length);
        String str2 = String.format(locale, str, Arrays.copyOf(objArrCopyOf, objArrCopyOf.length));
        Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
        return str2;
    }

    public static final long k(Response response) {
        Intrinsics.checkNotNullParameter(response, "<this>");
        String strA = response.J().a(HttpHeaders.CONTENT_LENGTH);
        if (strA != null) {
            return _UtilCommonKt.C(strA, -1L);
        }
        return -1L;
    }

    public static final List l(Object... objArr) {
        Intrinsics.checkNotNullParameter(objArr, "elements");
        return y(objArr);
    }

    public static final boolean m(Socket socket, BufferedSource bufferedSource) {
        Intrinsics.checkNotNullParameter(socket, "<this>");
        Intrinsics.checkNotNullParameter(bufferedSource, ClimateForcast.SOURCE);
        try {
            int soTimeout = socket.getSoTimeout();
            try {
                socket.setSoTimeout(1);
                return !bufferedSource.H2();
            } finally {
                socket.setSoTimeout(soTimeout);
            }
        } catch (SocketTimeoutException unused) {
            return true;
        } catch (IOException unused2) {
            return false;
        }
    }

    public static final Charset n(BufferedSource bufferedSource, Charset charset) {
        Intrinsics.checkNotNullParameter(bufferedSource, "<this>");
        Intrinsics.checkNotNullParameter(charset, "default");
        int iU3 = bufferedSource.u3(_UtilCommonKt.m());
        if (iU3 == -1) {
            return charset;
        }
        if (iU3 == 0) {
            return Charsets.UTF_8;
        }
        if (iU3 == 1) {
            return Charsets.UTF_16BE;
        }
        if (iU3 == 2) {
            return Charsets.INSTANCE.UTF32_LE();
        }
        if (iU3 == 3) {
            return Charsets.UTF_16LE;
        }
        if (iU3 == 4) {
            return Charsets.INSTANCE.UTF32_BE();
        }
        throw new AssertionError();
    }

    public static final boolean o(Source source, int i, TimeUnit timeUnit) {
        Intrinsics.checkNotNullParameter(source, "<this>");
        Intrinsics.checkNotNullParameter(timeUnit, "timeUnit");
        long jNanoTime = System.nanoTime();
        long jD = source.timeout().f() ? source.timeout().d() - jNanoTime : Long.MAX_VALUE;
        source.timeout().e(Math.min(jD, timeUnit.toNanos(i)) + jNanoTime);
        try {
            Buffer buffer = new Buffer();
            while (source.k3(buffer, 8192L) != -1) {
                buffer.j();
            }
            if (jD == Long.MAX_VALUE) {
                source.timeout().b();
                return true;
            }
            source.timeout().e(jNanoTime + jD);
            return true;
        } catch (InterruptedIOException unused) {
            if (jD == Long.MAX_VALUE) {
                source.timeout().b();
                return false;
            }
            source.timeout().e(jNanoTime + jD);
            return false;
        } catch (Throwable th) {
            if (jD == Long.MAX_VALUE) {
                source.timeout().b();
            } else {
                source.timeout().e(jNanoTime + jD);
            }
            throw th;
        }
    }

    public static final ThreadFactory p(final String str, final boolean z) {
        Intrinsics.checkNotNullParameter(str, "name");
        return new ThreadFactory() { // from class: okhttp3.internal.b
            @Override // java.util.concurrent.ThreadFactory
            public final Thread newThread(Runnable runnable) {
                return _UtilJvmKt.q(str, z, runnable);
            }
        };
    }

    private static final Thread q(String str, boolean z, Runnable runnable) {
        Thread thread = new Thread(runnable, str);
        thread.setDaemon(z);
        return thread;
    }

    public static final List r(Headers headers) {
        Intrinsics.checkNotNullParameter(headers, "<this>");
        IntRange intRangeUntil = RangesKt.until(0, headers.size());
        ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(intRangeUntil, 10));
        IntIterator it = intRangeUntil.iterator();
        while (it.hasNext()) {
            int iNextInt = it.nextInt();
            arrayList.add(new Header(headers.e(iNextInt), headers.k(iNextInt)));
        }
        return arrayList;
    }

    public static final Headers s(List list) {
        Intrinsics.checkNotNullParameter(list, "<this>");
        Headers.Builder builder = new Headers.Builder();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            Header header = (Header) it.next();
            builder.c(header.a().M(), header.b().M());
        }
        return builder.e();
    }

    public static final String t(int i) {
        String hexString = Integer.toHexString(i);
        Intrinsics.checkNotNullExpressionValue(hexString, "toHexString(...)");
        return hexString;
    }

    public static final String u(long j) {
        String hexString = Long.toHexString(j);
        Intrinsics.checkNotNullExpressionValue(hexString, "toHexString(...)");
        return hexString;
    }

    public static final String v(HttpUrl httpUrl, boolean z) {
        String strG;
        Intrinsics.checkNotNullParameter(httpUrl, "<this>");
        if (StringsKt.contains$default((CharSequence) httpUrl.g(), (CharSequence) TikaCoreProperties.NAMESPACE_PREFIX_DELIMITER, false, 2, (Object) null)) {
            strG = AbstractJsonLexerKt.BEGIN_LIST + httpUrl.g() + AbstractJsonLexerKt.END_LIST;
        } else {
            strG = httpUrl.g();
        }
        if (!z && httpUrl.l() == HttpUrl.j.b(httpUrl.s())) {
            return strG;
        }
        return strG + AbstractJsonLexerKt.COLON + httpUrl.l();
    }

    public static /* synthetic */ String w(HttpUrl httpUrl, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = false;
        }
        return v(httpUrl, z);
    }

    public static final List x(List list) {
        Intrinsics.checkNotNullParameter(list, "<this>");
        if (list.isEmpty()) {
            return CollectionsKt.emptyList();
        }
        if (list.size() == 1) {
            List listSingletonList = Collections.singletonList(list.get(0));
            Intrinsics.checkNotNullExpressionValue(listSingletonList, "singletonList(...)");
            return listSingletonList;
        }
        Object[] array = list.toArray();
        Intrinsics.checkNotNullExpressionValue(array, "toArray(...)");
        List listUnmodifiableList = Collections.unmodifiableList(ArraysKt.asList(array));
        Intrinsics.checkNotNullExpressionValue(listUnmodifiableList, "unmodifiableList(...)");
        Intrinsics.checkNotNull(listUnmodifiableList, "null cannot be cast to non-null type kotlin.collections.List<T of okhttp3.internal._UtilJvmKt.toImmutableList>");
        return listUnmodifiableList;
    }

    public static final List y(Object[] objArr) {
        if (objArr == null || objArr.length == 0) {
            return CollectionsKt.emptyList();
        }
        if (objArr.length == 1) {
            List listSingletonList = Collections.singletonList(objArr[0]);
            Intrinsics.checkNotNullExpressionValue(listSingletonList, "singletonList(...)");
            return listSingletonList;
        }
        List listUnmodifiableList = Collections.unmodifiableList(ArraysKt.asList((Object[]) objArr.clone()));
        Intrinsics.checkNotNullExpressionValue(listUnmodifiableList, "unmodifiableList(...)");
        return listUnmodifiableList;
    }
}