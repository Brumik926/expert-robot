package okhttp3.internal;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import kotlin.time.Duration;
import kotlin.time.DurationKt;
import kotlin.time.DurationUnit;
import okhttp3.CacheControl;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\b\u001a\u0013\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u0000¢\u0006\u0004\b\u0002\u0010\u0003\u001a\u0013\u0010\u0006\u001a\u00020\u0005*\u00020\u0004H\u0000¢\u0006\u0004\b\u0006\u0010\u0007\u001a\u0013\u0010\t\u001a\u00020\u0000*\u00020\bH\u0000¢\u0006\u0004\b\t\u0010\n\u001a\u0013\u0010\u000b\u001a\u00020\u0000*\u00020\bH\u0000¢\u0006\u0004\b\u000b\u0010\n\u001a\u0013\u0010\r\u001a\u00020\u0000*\u00020\fH\u0000¢\u0006\u0004\b\r\u0010\u000e\u001a\u0013\u0010\u000f\u001a\u00020\f*\u00020\fH\u0000¢\u0006\u0004\b\u000f\u0010\u0010\u001a\u0013\u0010\u0011\u001a\u00020\f*\u00020\fH\u0000¢\u0006\u0004\b\u0011\u0010\u0010\u001a\u0013\u0010\u0012\u001a\u00020\f*\u00020\fH\u0000¢\u0006\u0004\b\u0012\u0010\u0010\u001a\u001b\u0010\u0015\u001a\u00020\u0000*\u00020\b2\u0006\u0010\u0014\u001a\u00020\u0013H\u0000¢\u0006\u0004\b\u0015\u0010\u0016\u001a%\u0010\u0019\u001a\u00020\u0005*\u00020\u00012\u0006\u0010\u0017\u001a\u00020\u00012\b\b\u0002\u0010\u0018\u001a\u00020\u0005H\u0002¢\u0006\u0004\b\u0019\u0010\u001a¨\u0006\u001b"}, d2 = {"Lokhttp3/CacheControl;", StringUtils.EMPTY, "i", "(Lokhttp3/CacheControl;)Ljava/lang/String;", StringUtils.EMPTY, StringUtils.EMPTY, "b", "(J)I", "Lokhttp3/CacheControl$Companion;", "d", "(Lokhttp3/CacheControl$Companion;)Lokhttp3/CacheControl;", "c", "Lokhttp3/CacheControl$Builder;", "a", "(Lokhttp3/CacheControl$Builder;)Lokhttp3/CacheControl;", "e", "(Lokhttp3/CacheControl$Builder;)Lokhttp3/CacheControl$Builder;", "f", "g", "Lokhttp3/Headers;", "headers", "h", "(Lokhttp3/CacheControl$Companion;Lokhttp3/Headers;)Lokhttp3/CacheControl;", "characters", "startIndex", "j", "(Ljava/lang/String;Ljava/lang/String;I)I", "okhttp"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class _CacheControlCommonKt {
    public static final CacheControl a(CacheControl.Builder builder) {
        Intrinsics.checkNotNullParameter(builder, ap.a(1908143271));
        return new CacheControl(builder.f(), builder.g(), builder.c(), -1, false, false, false, builder.d(), builder.e(), builder.i(), builder.h(), builder.b(), null);
    }

    public static final int b(long j) {
        if (j > 2147483647L) {
            return Integer.MAX_VALUE;
        }
        return (int) j;
    }

    public static final CacheControl c(CacheControl.Companion companion) {
        Intrinsics.checkNotNullParameter(companion, "<this>");
        CacheControl.Builder builderM = new CacheControl.Builder().m();
        Duration.Companion companion2 = Duration.Companion;
        return builderM.j(DurationKt.toDuration(Integer.MAX_VALUE, DurationUnit.SECONDS)).a();
    }

    public static final CacheControl d(CacheControl.Companion companion) {
        Intrinsics.checkNotNullParameter(companion, "<this>");
        return new CacheControl.Builder().k().a();
    }

    public static final CacheControl.Builder e(CacheControl.Builder builder) {
        Intrinsics.checkNotNullParameter(builder, "<this>");
        builder.n(true);
        return builder;
    }

    public static final CacheControl.Builder f(CacheControl.Builder builder) {
        Intrinsics.checkNotNullParameter(builder, "<this>");
        builder.o(true);
        return builder;
    }

    public static final CacheControl.Builder g(CacheControl.Builder builder) {
        Intrinsics.checkNotNullParameter(builder, "<this>");
        builder.p(true);
        return builder;
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x004f  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00e0  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00ea  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final okhttp3.CacheControl h(okhttp3.CacheControl.Companion r30, okhttp3.Headers r31) {
        /*
            Method dump skipped, instruction units count: 427
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal._CacheControlCommonKt.h(okhttp3.CacheControl$Companion, okhttp3.Headers):okhttp3.CacheControl");
    }

    public static final String i(CacheControl cacheControl) {
        Intrinsics.checkNotNullParameter(cacheControl, "<this>");
        String strA = cacheControl.a();
        if (strA != null) {
            return strA;
        }
        StringBuilder sb = new StringBuilder();
        if (cacheControl.i()) {
            sb.append("no-cache, ");
        }
        if (cacheControl.j()) {
            sb.append("no-store, ");
        }
        if (cacheControl.e() != -1) {
            sb.append("max-age=");
            sb.append(cacheControl.e());
            sb.append(", ");
        }
        if (cacheControl.m() != -1) {
            sb.append("s-maxage=");
            sb.append(cacheControl.m());
            sb.append(", ");
        }
        if (cacheControl.c()) {
            sb.append("private, ");
        }
        if (cacheControl.d()) {
            sb.append("public, ");
        }
        if (cacheControl.h()) {
            sb.append("must-revalidate, ");
        }
        if (cacheControl.f() != -1) {
            sb.append("max-stale=");
            sb.append(cacheControl.f());
            sb.append(", ");
        }
        if (cacheControl.g() != -1) {
            sb.append("min-fresh=");
            sb.append(cacheControl.g());
            sb.append(", ");
        }
        if (cacheControl.l()) {
            sb.append("only-if-cached, ");
        }
        if (cacheControl.k()) {
            sb.append("no-transform, ");
        }
        if (cacheControl.b()) {
            sb.append("immutable, ");
        }
        if (sb.length() == 0) {
            return StringUtils.EMPTY;
        }
        Intrinsics.checkNotNullExpressionValue(sb.delete(sb.length() - 2, sb.length()), "delete(...)");
        String string = sb.toString();
        cacheControl.n(string);
        return string;
    }

    private static final int j(String str, String str2, int i) {
        int length = str.length();
        while (i < length) {
            if (StringsKt.contains$default((CharSequence) str2, str.charAt(i), false, 2, (Object) null)) {
                return i;
            }
            i++;
        }
        return str.length();
    }
}