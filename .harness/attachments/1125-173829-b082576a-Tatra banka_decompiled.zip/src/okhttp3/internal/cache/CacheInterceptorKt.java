package okhttp3.internal.cache;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.HttpUrl;
import okhttp3.Request;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\b\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\u0013\u0010\u0001\u001a\u00020\u0000*\u00020\u0000H\u0002¢\u0006\u0004\b\u0001\u0010\u0002¨\u0006\u0003"}, d2 = {"Lokhttp3/Request;", "b", "(Lokhttp3/Request;)Lokhttp3/Request;", "okhttp"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class CacheInterceptorKt {
    private static final Request b(Request request) {
        HttpUrl httpUrlC = request.c();
        return httpUrlC != null ? (Intrinsics.areEqual(request.i(), ap.a(631806101)) || Intrinsics.areEqual(request.i(), ap.a(137896825))) ? request.j().g().x(httpUrlC).d(null).b() : request : request;
    }
}