package okhttp3.internal.cache;

import h.ap;
import java.io.IOException;
import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.markers.KMutableIterator;
import okhttp3.internal.cache.DiskLruCache;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000*\n\u0000\n\u0002\u0010)\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\t\b\n\u0018\u00002\f\u0012\b\u0012\u00060\u0002R\u00020\u00030\u0001J\u0010\u0010\u0005\u001a\u00020\u0004H\u0096\u0002¢\u0006\u0004\b\u0005\u0010\u0006J\u0014\u0010\u0007\u001a\u00060\u0002R\u00020\u0003H\u0096\u0002¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b\n\u0010\u000bR4\u0010\u0010\u001a\"\u0012\u001e\u0012\u001c \u000e*\r\u0018\u00010\fR\u00020\u0003¢\u0006\u0002\b\r0\fR\u00020\u0003¢\u0006\u0002\b\r0\u00018\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0007\u0010\u000fR\u001c\u0010\u0013\u001a\b\u0018\u00010\u0002R\u00020\u00038\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0011\u0010\u0012R\u001c\u0010\u0015\u001a\b\u0018\u00010\u0002R\u00020\u00038\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0014\u0010\u0012¨\u0006\u0016"}, d2 = {"okhttp3/internal/cache/DiskLruCache$snapshots$1", StringUtils.EMPTY, "Lokhttp3/internal/cache/DiskLruCache$Snapshot;", "Lokhttp3/internal/cache/DiskLruCache;", StringUtils.EMPTY, "hasNext", "()Z", "a", "()Lokhttp3/internal/cache/DiskLruCache$Snapshot;", StringUtils.EMPTY, "remove", "()V", "Lokhttp3/internal/cache/DiskLruCache$Entry;", "Lkotlin/jvm/internal/EnhancedNullability;", "kotlin.jvm.PlatformType", "Ljava/util/Iterator;", "delegate", "b", "Lokhttp3/internal/cache/DiskLruCache$Snapshot;", "nextSnapshot", "c", "removeSnapshot", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nDiskLruCache.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DiskLruCache.kt\nokhttp3/internal/cache/DiskLruCache$snapshots$1\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1120:1\n1#2:1121\n*E\n"})
public final class DiskLruCache$snapshots$1 implements Iterator<DiskLruCache.Snapshot>, KMutableIterator {
    private final Iterator a;
    private DiskLruCache.Snapshot b;
    private DiskLruCache.Snapshot c;
    final /* synthetic */ DiskLruCache d;

    @Override // java.util.Iterator
    /* JADX INFO: renamed from: a, reason: merged with bridge method [inline-methods] */
    public DiskLruCache.Snapshot next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        DiskLruCache.Snapshot snapshot = this.b;
        this.c = snapshot;
        this.b = null;
        Intrinsics.checkNotNull(snapshot);
        return snapshot;
    }

    @Override // java.util.Iterator
    public boolean hasNext() {
        DiskLruCache.Snapshot snapshotR;
        if (this.b != null) {
            return true;
        }
        DiskLruCache diskLruCache = this.d;
        synchronized (diskLruCache) {
            if (diskLruCache.O()) {
                return false;
            }
            while (this.a.hasNext()) {
                DiskLruCache.Entry entry = (DiskLruCache.Entry) this.a.next();
                if (entry != null && (snapshotR = entry.r()) != null) {
                    this.b = snapshotR;
                    return true;
                }
            }
            Unit unit = Unit.INSTANCE;
            return false;
        }
    }

    @Override // java.util.Iterator
    public void remove() {
        DiskLruCache.Snapshot snapshot = this.c;
        if (snapshot == null) {
            throw new IllegalStateException(ap.a(1708744183));
        }
        try {
            this.d.m0(snapshot.o());
        } catch (IOException unused) {
        } finally {
            this.c = null;
        }
    }
}