package okhttp3.internal.cache;

import h.ap;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.Cache;
import okhttp3.Call;
import okhttp3.EventListener;
import okhttp3.Headers;
import okhttp3.Interceptor;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal.UnreadableResponseBodyKt;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.cache.CacheStrategy;
import okhttp3.internal.connection.RealCall;
import okhttp3.internal.http.HttpMethod;
import okhttp3.internal.http.RealResponseBody;
import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.Okio;
import okio.Sink;
import okio.Source;
import okio.Timeout;
import org.apache.tika.metadata.HttpHeaders;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\u0018\u0000 \u00132\u00020\u0001:\u0001\u0014B\u0011\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u0004\u0010\u0005J!\u0010\n\u001a\u00020\b2\b\u0010\u0007\u001a\u0004\u0018\u00010\u00062\u0006\u0010\t\u001a\u00020\bH\u0002¢\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\u000e\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\u000e\u0010\u000fR\u001c\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u000e\u0010\u0010\u001a\u0004\b\u0011\u0010\u0012¨\u0006\u0015"}, d2 = {"Lokhttp3/internal/cache/CacheInterceptor;", "Lokhttp3/Interceptor;", "Lokhttp3/Cache;", "cache", "<init>", "(Lokhttp3/Cache;)V", "Lokhttp3/internal/cache/CacheRequest;", "cacheRequest", "Lokhttp3/Response;", "response", "c", "(Lokhttp3/internal/cache/CacheRequest;Lokhttp3/Response;)Lokhttp3/Response;", "Lokhttp3/Interceptor$Chain;", "chain", "a", "(Lokhttp3/Interceptor$Chain;)Lokhttp3/Response;", "Lokhttp3/Cache;", "getCache$okhttp", "()Lokhttp3/Cache;", "b", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class CacheInterceptor implements Interceptor {
    public static final Companion b = new Companion(null);
    private final Cache a;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001f\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0007\u0010\bJ\u0017\u0010\f\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\tH\u0002¢\u0006\u0004\b\f\u0010\rJ\u0017\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\tH\u0002¢\u0006\u0004\b\u000e\u0010\r¨\u0006\u000f"}, d2 = {"Lokhttp3/internal/cache/CacheInterceptor$Companion;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/Headers;", "cachedHeaders", "networkHeaders", "b", "(Lokhttp3/Headers;Lokhttp3/Headers;)Lokhttp3/Headers;", StringUtils.EMPTY, "fieldName", StringUtils.EMPTY, "d", "(Ljava/lang/String;)Z", "c", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private final Headers b(Headers headers, Headers headers2) {
            Headers.Builder builder = new Headers.Builder();
            int size = headers.size();
            for (int i = 0; i < size; i++) {
                String strE = headers.e(i);
                String strK = headers.k(i);
                if ((!StringsKt.equals(ap.a(1466548620), strE, true) || !StringsKt.startsWith$default(strK, ap.a(366759897), false, 2, (Object) null)) && (c(strE) || !d(strE) || headers2.a(strE) == null)) {
                    builder.c(strE, strK);
                }
            }
            int size2 = headers2.size();
            for (int i2 = 0; i2 < size2; i2++) {
                String strE2 = headers2.e(i2);
                if (!c(strE2) && d(strE2)) {
                    builder.c(strE2, headers2.k(i2));
                }
            }
            return builder.e();
        }

        private final boolean c(String str) {
            return StringsKt.equals(HttpHeaders.CONTENT_LENGTH, str, true) || StringsKt.equals(HttpHeaders.CONTENT_ENCODING, str, true) || StringsKt.equals(HttpHeaders.CONTENT_TYPE, str, true);
        }

        private final boolean d(String str) {
            return (StringsKt.equals("Connection", str, true) || StringsKt.equals("Keep-Alive", str, true) || StringsKt.equals("Proxy-Authenticate", str, true) || StringsKt.equals("Proxy-Authorization", str, true) || StringsKt.equals("TE", str, true) || StringsKt.equals("Trailers", str, true) || StringsKt.equals("Transfer-Encoding", str, true) || StringsKt.equals("Upgrade", str, true)) ? false : true;
        }

        private Companion() {
        }
    }

    public CacheInterceptor(Cache cache) {
        this.a = cache;
    }

    private final Response c(final CacheRequest cacheRequest, Response response) {
        if (cacheRequest == null) {
            return response;
        }
        Sink sinkBody = cacheRequest.body();
        final BufferedSource bufferedSourceA = response.j().A();
        final BufferedSink bufferedSinkB = Okio.b(sinkBody);
        Source source = new Source() { // from class: okhttp3.internal.cache.CacheInterceptor$cacheWritingResponse$cacheWritingSource$1
            private boolean a;

            @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
            public void close() {
                if (!this.a && !_UtilJvmKt.i(this, 100, TimeUnit.MILLISECONDS)) {
                    this.a = true;
                    cacheRequest.abort();
                }
                bufferedSourceA.close();
            }

            @Override // okio.Source
            public long k3(Buffer buffer, long j) throws IOException {
                Intrinsics.checkNotNullParameter(buffer, ap.a(1891010869));
                try {
                    long jK3 = bufferedSourceA.k3(buffer, j);
                    if (jK3 != -1) {
                        buffer.r(bufferedSinkB.getBuffer(), buffer.size() - jK3, jK3);
                        bufferedSinkB.P1();
                        return jK3;
                    }
                    if (!this.a) {
                        this.a = true;
                        bufferedSinkB.close();
                    }
                    return -1L;
                } catch (IOException e) {
                    if (this.a) {
                        throw e;
                    }
                    this.a = true;
                    cacheRequest.abort();
                    throw e;
                }
            }

            @Override // okio.Source
            public Timeout timeout() {
                return bufferedSourceA.timeout();
            }
        };
        return response.Q().b(new RealResponseBody(Response.D(response, ap.a(1489335893), null, 2, null), response.j().r(), Okio.c(source))).c();
    }

    @Override // okhttp3.Interceptor
    public Response a(Interceptor.Chain chain) {
        EventListener eventListenerL;
        Intrinsics.checkNotNullParameter(chain, "chain");
        Call call = chain.call();
        Cache cache = this.a;
        Response responseD = cache != null ? cache.d(CacheInterceptorKt.b(chain.request())) : null;
        CacheStrategy cacheStrategyB = new CacheStrategy.Factory(System.currentTimeMillis(), chain.request(), responseD).b();
        Request requestB = cacheStrategyB.b();
        Response responseA = cacheStrategyB.a();
        Cache cache2 = this.a;
        if (cache2 != null) {
            cache2.B(cacheStrategyB);
        }
        RealCall realCall = call instanceof RealCall ? (RealCall) call : null;
        if (realCall == null || (eventListenerL = realCall.l()) == null) {
            eventListenerL = EventListener.b;
        }
        if (responseD != null && responseA == null) {
            _UtilCommonKt.f(responseD.j());
        }
        if (requestB == null && responseA == null) {
            Response responseC = new Response.Builder().q(chain.request()).o(Protocol.d).f(504).l("Unsatisfiable Request (only-if-cached)").r(-1L).p(System.currentTimeMillis()).c();
            eventListenerL.C(call, responseC);
            return responseC;
        }
        if (requestB == null) {
            Intrinsics.checkNotNull(responseA);
            Response responseC2 = responseA.Q().d(UnreadableResponseBodyKt.a(responseA)).c();
            eventListenerL.b(call, responseC2);
            return responseC2;
        }
        if (responseA != null) {
            eventListenerL.a(call, responseA);
        } else if (this.a != null) {
            eventListenerL.c(call);
        }
        try {
            Response responseA2 = chain.a(requestB);
            if (responseA2 == null && responseD != null) {
            }
            if (responseA != null) {
                if (responseA2 != null && responseA2.r() == 304) {
                    Response responseC3 = responseA.Q().j(b.b(responseA.J(), responseA2.J())).r(responseA2.d0()).p(responseA2.a0()).d(UnreadableResponseBodyKt.a(responseA)).m(UnreadableResponseBodyKt.a(responseA2)).c();
                    responseA2.j().close();
                    Cache cache3 = this.a;
                    Intrinsics.checkNotNull(cache3);
                    cache3.A();
                    this.a.D(responseA, responseC3);
                    eventListenerL.b(call, responseC3);
                    return responseC3;
                }
                _UtilCommonKt.f(responseA.j());
            }
            Intrinsics.checkNotNull(responseA2);
            Response responseC4 = responseA2.Q().d(responseA != null ? UnreadableResponseBodyKt.a(responseA) : null).m(UnreadableResponseBodyKt.a(responseA2)).c();
            if (this.a != null) {
                Request requestB2 = CacheInterceptorKt.b(requestB);
                if (okhttp3.internal.http.HttpHeaders.b(responseC4) && CacheStrategy.c.a(responseC4, requestB2)) {
                    Response responseC5 = c(this.a.o(responseC4.Q().q(requestB2).c()), responseC4);
                    if (responseA != null) {
                        eventListenerL.c(call);
                    }
                    return responseC5;
                }
                if (HttpMethod.a(requestB.i())) {
                    try {
                        this.a.q(requestB);
                    } catch (IOException unused) {
                    }
                }
            }
            return responseC4;
        } finally {
            if (responseD != null) {
                _UtilCommonKt.f(responseD.j());
            }
        }
    }
}