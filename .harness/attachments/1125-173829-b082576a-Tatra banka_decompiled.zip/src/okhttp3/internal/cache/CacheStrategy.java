package okhttp3.internal.cache;

import h.ap;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.CacheControl;
import okhttp3.Headers;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal.http.DateFormattingKt;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\r\u0018\u0000 \u000e2\u00020\u0001:\u0002\u000f\u0010B\u001d\b\u0000\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004¢\u0006\u0004\b\u0006\u0010\u0007R\u0019\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0006¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\n\u0010\u000bR\u0019\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006¢\u0006\f\n\u0004\b\n\u0010\f\u001a\u0004\b\b\u0010\r¨\u0006\u0011"}, d2 = {"Lokhttp3/internal/cache/CacheStrategy;", StringUtils.EMPTY, "Lokhttp3/Request;", "networkRequest", "Lokhttp3/Response;", "cacheResponse", "<init>", "(Lokhttp3/Request;Lokhttp3/Response;)V", "a", "Lokhttp3/Request;", "b", "()Lokhttp3/Request;", "Lokhttp3/Response;", "()Lokhttp3/Response;", "c", "Factory", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class CacheStrategy {
    public static final Companion c = new Companion(null);
    private final Request a;
    private final Response b;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001d\u0010\t\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\t\u0010\n¨\u0006\u000b"}, d2 = {"Lokhttp3/internal/cache/CacheStrategy$Companion;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/Response;", "response", "Lokhttp3/Request;", "request", StringUtils.EMPTY, "a", "(Lokhttp3/Response;Lokhttp3/Request;)Z", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        /* JADX WARN: Removed duplicated region for block: B:24:0x0045  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final boolean a(okhttp3.Response r4, okhttp3.Request r5) {
            /*
                r3 = this;
                r3 = 270620916(0x102158f4, float:3.1820178E-29)
                java.lang.String r3 = h.ap.a(r3)
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r4, r3)
                r3 = 455711503(0x1b299b0f, float:1.4029454E-22)
                java.lang.String r3 = h.ap.a(r3)
                kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r5, r3)
                int r3 = r4.r()
                r0 = 200(0xc8, float:2.8E-43)
                r1 = 0
                if (r3 == r0) goto L74
                r0 = 410(0x19a, float:5.75E-43)
                if (r3 == r0) goto L74
                r0 = 414(0x19e, float:5.8E-43)
                if (r3 == r0) goto L74
                r0 = 501(0x1f5, float:7.02E-43)
                if (r3 == r0) goto L74
                r0 = 203(0xcb, float:2.84E-43)
                if (r3 == r0) goto L74
                r0 = 204(0xcc, float:2.86E-43)
                if (r3 == r0) goto L74
                r0 = 307(0x133, float:4.3E-43)
                if (r3 == r0) goto L45
                r0 = 308(0x134, float:4.32E-43)
                if (r3 == r0) goto L74
                r0 = 404(0x194, float:5.66E-43)
                if (r3 == r0) goto L74
                r0 = 405(0x195, float:5.68E-43)
                if (r3 == r0) goto L74
                switch(r3) {
                    case 300: goto L74;
                    case 301: goto L74;
                    case 302: goto L45;
                    default: goto L44;
                }
            L44:
                return r1
            L45:
                r3 = 656769185(0x272580a1, float:2.296808E-15)
                java.lang.String r3 = h.ap.a(r3)
                r0 = 2
                r2 = 0
                java.lang.String r3 = okhttp3.Response.D(r4, r3, r2, r0, r2)
                if (r3 != 0) goto L74
                okhttp3.CacheControl r3 = r4.k()
                int r3 = r3.e()
                r0 = -1
                if (r3 != r0) goto L74
                okhttp3.CacheControl r3 = r4.k()
                boolean r3 = r3.d()
                if (r3 != 0) goto L74
                okhttp3.CacheControl r3 = r4.k()
                boolean r3 = r3.c()
                if (r3 != 0) goto L74
                return r1
            L74:
                okhttp3.CacheControl r3 = r4.k()
                boolean r3 = r3.j()
                if (r3 != 0) goto L8a
                okhttp3.CacheControl r3 = r5.b()
                boolean r3 = r3.j()
                if (r3 != 0) goto L8a
                r3 = 1
                return r3
            L8a:
                return r1
            */
            throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.cache.CacheStrategy.Companion.a(okhttp3.Response, okhttp3.Request):boolean");
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0010\b\n\u0002\b\u0004\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\b\u0010\u0007\u001a\u0004\u0018\u00010\u0006¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\u000b\u001a\u00020\nH\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\u000e\u001a\u00020\rH\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0010\u001a\u00020\u0002H\u0002¢\u0006\u0004\b\u0010\u0010\u0011J\u000f\u0010\u0012\u001a\u00020\u0002H\u0002¢\u0006\u0004\b\u0012\u0010\u0011J\u0017\u0010\u0013\u001a\u00020\n2\u0006\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0013\u0010\u0014J\r\u0010\u0015\u001a\u00020\r¢\u0006\u0004\b\u0015\u0010\u000fR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010\u0016R\u001a\u0010\u0005\u001a\u00020\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u0015\u0010\u0017\u001a\u0004\b\u0018\u0010\u0019R\u0016\u0010\u0007\u001a\u0004\u0018\u00010\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000e\u0010\u001aR\u0018\u0010\u001d\u001a\u0004\u0018\u00010\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0010\u0010\u001cR\u0018\u0010 \u001a\u0004\u0018\u00010\u001e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0013\u0010\u001fR\u0018\u0010!\u001a\u0004\u0018\u00010\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u000b\u0010\u001cR\u0018\u0010#\u001a\u0004\u0018\u00010\u001e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\"\u0010\u001fR\u0018\u0010%\u001a\u0004\u0018\u00010\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b$\u0010\u001cR\u0016\u0010'\u001a\u00020\u00028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b&\u0010\u0016R\u0016\u0010)\u001a\u00020\u00028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b(\u0010\u0016R\u0018\u0010+\u001a\u0004\u0018\u00010\u001e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b*\u0010\u001fR\u0016\u0010/\u001a\u00020,8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b-\u0010.¨\u00060"}, d2 = {"Lokhttp3/internal/cache/CacheStrategy$Factory;", StringUtils.EMPTY, StringUtils.EMPTY, "nowMillis", "Lokhttp3/Request;", "request", "Lokhttp3/Response;", "cacheResponse", "<init>", "(JLokhttp3/Request;Lokhttp3/Response;)V", StringUtils.EMPTY, "f", "()Z", "Lokhttp3/internal/cache/CacheStrategy;", "c", "()Lokhttp3/internal/cache/CacheStrategy;", "d", "()J", "a", "e", "(Lokhttp3/Request;)Z", "b", "J", "Lokhttp3/Request;", "getRequest$okhttp", "()Lokhttp3/Request;", "Lokhttp3/Response;", "Ljava/util/Date;", "Ljava/util/Date;", "servedDate", StringUtils.EMPTY, "Ljava/lang/String;", "servedDateString", "lastModified", "g", "lastModifiedString", "h", "expires", "i", "sentRequestMillis", "j", "receivedResponseMillis", "k", "etag", StringUtils.EMPTY, "l", "I", "ageSeconds", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Factory {
        private final long a;
        private final Request b;
        private final Response c;
        private Date d;
        private String e;
        private Date f;
        private String g;
        private Date h;
        private long i;
        private long j;
        private String k;
        private int l;

        public Factory(long j, Request request, Response response) {
            Intrinsics.checkNotNullParameter(request, ap.a(1435641963));
            this.a = j;
            this.b = request;
            this.c = response;
            this.l = -1;
            if (response != null) {
                this.i = response.d0();
                this.j = response.a0();
                Headers headersJ = response.J();
                int size = headersJ.size();
                for (int i = 0; i < size; i++) {
                    String strE = headersJ.e(i);
                    String strK = headersJ.k(i);
                    if (StringsKt.equals(strE, ap.a(547381164), true)) {
                        this.d = DateFormattingKt.a(strK);
                        this.e = strK;
                    } else if (StringsKt.equals(strE, ap.a(961510142), true)) {
                        this.h = DateFormattingKt.a(strK);
                    } else if (StringsKt.equals(strE, ap.a(631218639), true)) {
                        this.f = DateFormattingKt.a(strK);
                        this.g = strK;
                    } else if (StringsKt.equals(strE, ap.a(1391113953), true)) {
                        this.k = strK;
                    } else if (StringsKt.equals(strE, ap.a(85713286), true)) {
                        this.l = _UtilCommonKt.D(strK, -1);
                    }
                }
            }
        }

        private final long a() {
            Date date = this.d;
            long jMax = date != null ? Math.max(0L, this.j - date.getTime()) : 0L;
            int i = this.l;
            if (i != -1) {
                jMax = Math.max(jMax, TimeUnit.SECONDS.toMillis(i));
            }
            return jMax + Math.max(0L, this.j - this.i) + Math.max(0L, this.a - this.j);
        }

        private final CacheStrategy c() {
            String str;
            if (this.c == null) {
                return new CacheStrategy(this.b, null);
            }
            if (this.b.h() && this.c.A() == null) {
                return new CacheStrategy(this.b, null);
            }
            if (!CacheStrategy.c.a(this.c, this.b)) {
                return new CacheStrategy(this.b, null);
            }
            CacheControl cacheControlB = this.b.b();
            if (cacheControlB.i() || e(this.b)) {
                return new CacheStrategy(this.b, null);
            }
            CacheControl cacheControlK = this.c.k();
            long jA = a();
            long jD = d();
            if (cacheControlB.e() != -1) {
                jD = Math.min(jD, TimeUnit.SECONDS.toMillis(cacheControlB.e()));
            }
            long millis = 0;
            long millis2 = cacheControlB.g() != -1 ? TimeUnit.SECONDS.toMillis(cacheControlB.g()) : 0L;
            if (!cacheControlK.h() && cacheControlB.f() != -1) {
                millis = TimeUnit.SECONDS.toMillis(cacheControlB.f());
            }
            if (!cacheControlK.i()) {
                long j = millis2 + jA;
                if (j < millis + jD) {
                    Response.Builder builderQ = this.c.Q();
                    if (j >= jD) {
                        builderQ.a("Warning", "110 HttpURLConnection \"Response is stale\"");
                    }
                    if (jA > 86400000 && f()) {
                        builderQ.a("Warning", "113 HttpURLConnection \"Heuristic expiration\"");
                    }
                    return new CacheStrategy(null, builderQ.c());
                }
            }
            String str2 = this.k;
            if (str2 != null) {
                str = "If-None-Match";
            } else {
                if (this.f != null) {
                    str2 = this.g;
                } else {
                    if (this.d == null) {
                        return new CacheStrategy(this.b, null);
                    }
                    str2 = this.e;
                }
                str = "If-Modified-Since";
            }
            Headers.Builder builderF = this.b.g().f();
            Intrinsics.checkNotNull(str2);
            builderF.c(str, str2);
            return new CacheStrategy(this.b.j().o(builderF.e()).b(), this.c);
        }

        private final long d() {
            Response response = this.c;
            Intrinsics.checkNotNull(response);
            if (response.k().e() != -1) {
                return TimeUnit.SECONDS.toMillis(r0.e());
            }
            Date date = this.h;
            if (date != null) {
                Date date2 = this.d;
                long time = date.getTime() - (date2 != null ? date2.getTime() : this.j);
                if (time > 0) {
                    return time;
                }
                return 0L;
            }
            if (this.f != null && this.c.b0().m().m() == null) {
                Date date3 = this.d;
                long time2 = date3 != null ? date3.getTime() : this.i;
                Date date4 = this.f;
                Intrinsics.checkNotNull(date4);
                long time3 = time2 - date4.getTime();
                if (time3 > 0) {
                    return time3 / ((long) 10);
                }
            }
            return 0L;
        }

        private final boolean e(Request request) {
            return (request.e("If-Modified-Since") == null && request.e("If-None-Match") == null) ? false : true;
        }

        private final boolean f() {
            Response response = this.c;
            Intrinsics.checkNotNull(response);
            return response.k().e() == -1 && this.h == null;
        }

        public final CacheStrategy b() {
            CacheStrategy cacheStrategyC = c();
            return (cacheStrategyC.b() == null || !this.b.b().l()) ? cacheStrategyC : new CacheStrategy(null, null);
        }
    }

    public CacheStrategy(Request request, Response response) {
        this.a = request;
        this.b = response;
    }

    public final Response a() {
        return this.b;
    }

    public final Request b() {
        return this.a;
    }
}