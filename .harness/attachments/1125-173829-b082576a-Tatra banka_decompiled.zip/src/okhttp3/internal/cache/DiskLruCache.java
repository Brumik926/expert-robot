package okhttp3.internal.cache;

import h.ap;
import java.io.Closeable;
import java.io.EOFException;
import java.io.FileNotFoundException;
import java.io.Flushable;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import kotlin.ExceptionsKt;
import kotlin.KotlinNothingValueException;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.cache.DiskLruCache;
import okhttp3.internal.concurrent.Lockable;
import okhttp3.internal.concurrent.Task;
import okhttp3.internal.concurrent.TaskQueue;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.platform.Platform;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.FileSystem;
import okio.ForwardingFileSystem;
import okio.ForwardingSource;
import okio.Okio;
import okio.Path;
import okio.Sink;
import okio.Source;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.parser.external.ExternalParsersConfigReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0085\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b%\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0019\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\b\t*\u0001w\u0018\u0000 z2\u00020\u00012\u00020\u00022\u00020\u0003:\u0004{|}~B7\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\n\u001a\u00020\b\u0012\u0006\u0010\f\u001a\u00020\u000b\u0012\u0006\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u000f\u0010\u0010J\u000f\u0010\u0012\u001a\u00020\u0011H\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0015\u001a\u00020\u0014H\u0002¢\u0006\u0004\b\u0015\u0010\u0016J\u0017\u0010\u0019\u001a\u00020\u00112\u0006\u0010\u0018\u001a\u00020\u0017H\u0002¢\u0006\u0004\b\u0019\u0010\u001aJ\u000f\u0010\u001b\u001a\u00020\u0011H\u0002¢\u0006\u0004\b\u001b\u0010\u0013J\u000f\u0010\u001d\u001a\u00020\u001cH\u0002¢\u0006\u0004\b\u001d\u0010\u001eJ\u000f\u0010\u001f\u001a\u00020\u0011H\u0002¢\u0006\u0004\b\u001f\u0010\u0013J\u000f\u0010 \u001a\u00020\u001cH\u0002¢\u0006\u0004\b \u0010\u001eJ\u0017\u0010\"\u001a\u00020\u00112\u0006\u0010!\u001a\u00020\u0017H\u0002¢\u0006\u0004\b\"\u0010\u001aJ\r\u0010#\u001a\u00020\u0011¢\u0006\u0004\b#\u0010\u0013J\u000f\u0010$\u001a\u00020\u0011H\u0000¢\u0006\u0004\b$\u0010\u0013J\u001e\u0010&\u001a\b\u0018\u00010%R\u00020\u00002\u0006\u0010!\u001a\u00020\u0017H\u0086\u0002¢\u0006\u0004\b&\u0010'J'\u0010*\u001a\b\u0018\u00010)R\u00020\u00002\u0006\u0010!\u001a\u00020\u00172\b\b\u0002\u0010(\u001a\u00020\u000bH\u0007¢\u0006\u0004\b*\u0010+J#\u0010.\u001a\u00020\u00112\n\u0010,\u001a\u00060)R\u00020\u00002\u0006\u0010-\u001a\u00020\u001cH\u0000¢\u0006\u0004\b.\u0010/J\u0015\u00100\u001a\u00020\u001c2\u0006\u0010!\u001a\u00020\u0017¢\u0006\u0004\b0\u00101J\u001b\u00104\u001a\u00020\u001c2\n\u00103\u001a\u000602R\u00020\u0000H\u0000¢\u0006\u0004\b4\u00105J\u000f\u00106\u001a\u00020\u0011H\u0016¢\u0006\u0004\b6\u0010\u0013J\u000f\u00107\u001a\u00020\u0011H\u0016¢\u0006\u0004\b7\u0010\u0013J\r\u00108\u001a\u00020\u0011¢\u0006\u0004\b8\u0010\u0013J\r\u00109\u001a\u00020\u0011¢\u0006\u0004\b9\u0010\u0013R\u0017\u0010\u0007\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\b:\u0010;\u001a\u0004\b<\u0010=R\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b>\u0010?R\u001a\u0010\n\u001a\u00020\b8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b@\u0010?\u001a\u0004\bA\u0010BR\u001a\u0010\u0005\u001a\u00020\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\bC\u0010D\u001a\u0004\bE\u0010FR*\u0010\f\u001a\u00020\u000b2\u0006\u0010G\u001a\u00020\u000b8\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\bH\u0010&\u001a\u0004\bI\u0010J\"\u0004\bK\u0010LR\u0014\u0010N\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bM\u0010;R\u0014\u0010P\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bO\u0010;R\u0014\u0010R\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bQ\u0010;R\u0016\u0010T\u001a\u00020\u000b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bS\u0010&R\u0018\u0010W\u001a\u0004\u0018\u00010\u00148\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bU\u0010VR>\u0010^\u001a&\u0012\u0004\u0012\u00020\u0017\u0012\b\u0012\u000602R\u00020\u00000Xj\u0012\u0012\u0004\u0012\u00020\u0017\u0012\b\u0012\u000602R\u00020\u0000`Y8\u0000X\u0080\u0004¢\u0006\f\n\u0004\bZ\u0010[\u001a\u0004\b\\\u0010]R\u0016\u0010`\u001a\u00020\b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b_\u0010?R\u0016\u0010c\u001a\u00020\u001c8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\ba\u0010bR\u0016\u0010e\u001a\u00020\u001c8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bd\u0010bR\u0016\u0010g\u001a\u00020\u001c8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bf\u0010bR\"\u0010l\u001a\u00020\u001c8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bh\u0010b\u001a\u0004\bi\u0010\u001e\"\u0004\bj\u0010kR\u0016\u0010n\u001a\u00020\u001c8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bm\u0010bR\u0016\u0010p\u001a\u00020\u001c8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bo\u0010bR\u0016\u0010r\u001a\u00020\u000b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bq\u0010&R\u0014\u0010v\u001a\u00020s8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bt\u0010uR\u0014\u0010y\u001a\u00020w8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001f\u0010x¨\u0006\u007f"}, d2 = {"Lokhttp3/internal/cache/DiskLruCache;", "Ljava/io/Closeable;", "Ljava/io/Flushable;", "Lokhttp3/internal/concurrent/Lockable;", "Lokio/FileSystem;", "fileSystem", "Lokio/Path;", "directory", StringUtils.EMPTY, "appVersion", "valueCount", StringUtils.EMPTY, "maxSize", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", "<init>", "(Lokio/FileSystem;Lokio/Path;IIJLokhttp3/internal/concurrent/TaskRunner;)V", StringUtils.EMPTY, "e0", "()V", "Lokio/BufferedSink;", "a0", "()Lokio/BufferedSink;", StringUtils.EMPTY, "line", "i0", "(Ljava/lang/String;)V", "d0", StringUtils.EMPTY, "X", "()Z", "u", "v0", ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR, "x0", "W", "j0", "Lokhttp3/internal/cache/DiskLruCache$Snapshot;", "J", "(Ljava/lang/String;)Lokhttp3/internal/cache/DiskLruCache$Snapshot;", "expectedSequenceNumber", "Lokhttp3/internal/cache/DiskLruCache$Editor;", "D", "(Ljava/lang/String;J)Lokhttp3/internal/cache/DiskLruCache$Editor;", "editor", "success", "A", "(Lokhttp3/internal/cache/DiskLruCache$Editor;Z)V", "m0", "(Ljava/lang/String;)Z", "Lokhttp3/internal/cache/DiskLruCache$Entry;", "entry", "o0", "(Lokhttp3/internal/cache/DiskLruCache$Entry;)Z", "flush", "close", "w0", "B", "a", "Lokio/Path;", "P", "()Lokio/Path;", "b", "I", "c", "V", "()I", "d", "Lokio/FileSystem;", "Q", "()Lokio/FileSystem;", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "e", "getMaxSize", "()J", "setMaxSize", "(J)V", "f", "journalFile", "g", "journalFileTmp", "h", "journalFileBackup", "i", "size", "j", "Lokio/BufferedSink;", "journalWriter", "Ljava/util/LinkedHashMap;", "Lkotlin/collections/LinkedHashMap;", "k", "Ljava/util/LinkedHashMap;", "getLruEntries$okhttp", "()Ljava/util/LinkedHashMap;", "lruEntries", "l", "redundantOpCount", "m", "Z", "hasJournalErrors", "n", "civilizedFileSystem", "o", "initialized", "p", "O", "setClosed$okhttp", "(Z)V", "closed", "q", "mostRecentTrimFailed", "r", "mostRecentRebuildFailed", "s", "nextSequenceNumber", "Lokhttp3/internal/concurrent/TaskQueue;", "t", "Lokhttp3/internal/concurrent/TaskQueue;", "cleanupQueue", "okhttp3/internal/cache/DiskLruCache$cleanupTask$1", "Lokhttp3/internal/cache/DiskLruCache$cleanupTask$1;", "cleanupTask", "v", "Snapshot", "Editor", "Entry", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nDiskLruCache.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DiskLruCache.kt\nokhttp3/internal/cache/DiskLruCache\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n+ 4 Okio.kt\nokio/Okio__OkioKt\n+ 5 FileSystem.kt\nokio/FileSystem\n+ 6 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,1120:1\n1#2:1121\n55#3,4:1122\n55#3,4:1193\n72#4:1126\n58#4,4:1128\n66#4,10:1133\n62#4,3:1143\n77#4,3:1146\n58#4,4:1152\n66#4,10:1157\n62#4,18:1167\n73#5:1127\n74#5:1132\n84#5:1149\n191#5:1150\n95#5:1151\n96#5:1156\n37#6:1185\n36#6,3:1186\n37#6:1189\n36#6,3:1190\n*S KotlinDebug\n*F\n+ 1 DiskLruCache.kt\nokhttp3/internal/cache/DiskLruCache\n*L\n230#1:1122,4\n324#1:1193,4\n279#1:1126\n279#1:1128,4\n279#1:1133,10\n279#1:1143,3\n279#1:1146,3\n411#1:1152,4\n411#1:1157,10\n411#1:1167,18\n279#1:1127\n279#1:1132\n411#1:1149\n411#1:1150\n411#1:1151\n411#1:1156\n715#1:1185\n715#1:1186,3\n765#1:1189\n765#1:1190,3\n*E\n"})
public final class DiskLruCache implements Closeable, Flushable, Lockable {
    private final Path a;
    private final int b;
    private final int c;
    private final FileSystem d;
    private long e;
    private final Path f;
    private final Path g;
    private final Path h;
    private long i;
    private BufferedSink j;
    private final LinkedHashMap k;
    private int l;
    private boolean m;
    private boolean n;
    private boolean o;
    private boolean p;
    private boolean q;
    private boolean r;
    private long s;
    private final TaskQueue t;
    private final DiskLruCache$cleanupTask$1 u;
    public static final Companion v = new Companion(null);
    public static final String w = ap.a(493993429);
    public static final String x = ap.a(1845218386);
    public static final String y = ap.a(647853830);
    public static final String z = ap.a(983342326);
    public static final String A = ap.a(1172750881);
    public static final long B = -1;
    public static final Regex D = new Regex(ap.a(334358669));
    public static final String G = ap.a(1547327110);
    public static final String H = ap.a(1172685611);
    public static final String J = ap.a(415616029);
    public static final String N = ap.a(1774766694);

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0010\u0010\u0004\u001a\u00020\u00058\u0006X\u0087D¢\u0006\u0002\n\u0000R\u0010\u0010\u0006\u001a\u00020\u00058\u0006X\u0087D¢\u0006\u0002\n\u0000R\u0010\u0010\u0007\u001a\u00020\u00058\u0006X\u0087D¢\u0006\u0002\n\u0000R\u0010\u0010\b\u001a\u00020\u00058\u0006X\u0087D¢\u0006\u0002\n\u0000R\u0010\u0010\t\u001a\u00020\u00058\u0006X\u0087D¢\u0006\u0002\n\u0000R\u0010\u0010\n\u001a\u00020\u000b8\u0006X\u0087D¢\u0006\u0002\n\u0000R\u0010\u0010\f\u001a\u00020\r8\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u0010\u0010\u000e\u001a\u00020\u00058\u0006X\u0087D¢\u0006\u0002\n\u0000R\u0010\u0010\u000f\u001a\u00020\u00058\u0006X\u0087D¢\u0006\u0002\n\u0000R\u0010\u0010\u0010\u001a\u00020\u00058\u0006X\u0087D¢\u0006\u0002\n\u0000R\u0010\u0010\u0011\u001a\u00020\u00058\u0006X\u0087D¢\u0006\u0002\n\u0000¨\u0006\u0012"}, d2 = {"Lokhttp3/internal/cache/DiskLruCache$Companion;", StringUtils.EMPTY, "<init>", "()V", "JOURNAL_FILE", StringUtils.EMPTY, "JOURNAL_FILE_TEMP", "JOURNAL_FILE_BACKUP", "MAGIC", "VERSION_1", "ANY_SEQUENCE_NUMBER", StringUtils.EMPTY, "LEGAL_KEY_PATTERN", "Lkotlin/text/Regex;", "CLEAN", "DIRTY", "REMOVE", "READ", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0018\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0003\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0015\b\u0000\u0012\n\u0010\u0004\u001a\u00060\u0002R\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\u000f\u0010\b\u001a\u00020\u0007H\u0000¢\u0006\u0004\b\b\u0010\tJ\u0015\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\r\u0010\u000eJ\r\u0010\u000f\u001a\u00020\u0007¢\u0006\u0004\b\u000f\u0010\tJ\r\u0010\u0010\u001a\u00020\u0007¢\u0006\u0004\b\u0010\u0010\tR\u001e\u0010\u0004\u001a\u00060\u0002R\u00020\u00038\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u0011\u0010\u0012\u001a\u0004\b\u0013\u0010\u0014R\u001c\u0010\u0019\u001a\u0004\u0018\u00010\u00158\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u0010\u0010\u0016\u001a\u0004\b\u0017\u0010\u0018R\u0016\u0010\u001c\u001a\u00020\u001a8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u000f\u0010\u001b¨\u0006\u001d"}, d2 = {"Lokhttp3/internal/cache/DiskLruCache$Editor;", StringUtils.EMPTY, "Lokhttp3/internal/cache/DiskLruCache$Entry;", "Lokhttp3/internal/cache/DiskLruCache;", "entry", "<init>", "(Lokhttp3/internal/cache/DiskLruCache;Lokhttp3/internal/cache/DiskLruCache$Entry;)V", StringUtils.EMPTY, "d", "()V", StringUtils.EMPTY, "index", "Lokio/Sink;", "g", "(I)Lokio/Sink;", "c", "b", "a", "Lokhttp3/internal/cache/DiskLruCache$Entry;", "e", "()Lokhttp3/internal/cache/DiskLruCache$Entry;", StringUtils.EMPTY, "[Z", "f", "()[Z", "written", StringUtils.EMPTY, "Z", "done", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public final class Editor {
        private final Entry a;
        private final boolean[] b;
        private boolean c;
        final /* synthetic */ DiskLruCache d;

        public Editor(DiskLruCache diskLruCache, Entry entry) {
            Intrinsics.checkNotNullParameter(entry, ap.a(886374774));
            this.d = diskLruCache;
            this.a = entry;
            this.b = entry.g() ? null : new boolean[diskLruCache.V()];
        }

        private static final Unit h(DiskLruCache diskLruCache, Editor editor, IOException iOException) {
            Intrinsics.checkNotNullParameter(iOException, "it");
            synchronized (diskLruCache) {
                editor.d();
            }
            return Unit.INSTANCE;
        }

        public final void b() {
            DiskLruCache diskLruCache = this.d;
            synchronized (diskLruCache) {
                try {
                    if (this.c) {
                        throw new IllegalStateException("Check failed.");
                    }
                    if (Intrinsics.areEqual(this.a.b(), this)) {
                        diskLruCache.A(this, false);
                    }
                    this.c = true;
                    Unit unit = Unit.INSTANCE;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public final void c() {
            DiskLruCache diskLruCache = this.d;
            synchronized (diskLruCache) {
                try {
                    if (this.c) {
                        throw new IllegalStateException("Check failed.");
                    }
                    if (Intrinsics.areEqual(this.a.b(), this)) {
                        diskLruCache.A(this, true);
                    }
                    this.c = true;
                    Unit unit = Unit.INSTANCE;
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        public final void d() {
            if (Intrinsics.areEqual(this.a.b(), this)) {
                if (this.d.n) {
                    this.d.A(this, false);
                } else {
                    this.a.q(true);
                }
            }
        }

        public final Entry e() {
            return this.a;
        }

        public final boolean[] f() {
            return this.b;
        }

        public final Sink g(int i) {
            final DiskLruCache diskLruCache = this.d;
            synchronized (diskLruCache) {
                if (this.c) {
                    throw new IllegalStateException("Check failed.");
                }
                if (!Intrinsics.areEqual(this.a.b(), this)) {
                    return Okio.a();
                }
                if (!this.a.g()) {
                    boolean[] zArr = this.b;
                    Intrinsics.checkNotNull(zArr);
                    zArr[i] = true;
                }
                try {
                    return new FaultHidingSink(diskLruCache.Q().Q((Path) this.a.c().get(i)), new Function1() { // from class: okhttp3.internal.cache.b
                        public final Object invoke(Object obj) {
                            return DiskLruCache.Editor.h(diskLruCache, this, (IOException) obj);
                        }
                    });
                } catch (FileNotFoundException unused) {
                    return Okio.a();
                }
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000t\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010 \n\u0000\n\u0002\u0010\u0001\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0016\n\u0002\b\u0005\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\t\n\u0002\b\u0006\b\u0080\u0004\u0018\u00002\u00020\u0001B\u0011\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u001d\u0010\t\u001a\u00020\b2\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00020\u0006H\u0002¢\u0006\u0004\b\t\u0010\nJ\u0017\u0010\u000e\u001a\u00020\r2\u0006\u0010\f\u001a\u00020\u000bH\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\u001d\u0010\u0011\u001a\u00020\u00102\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00020\u0006H\u0000¢\u0006\u0004\b\u0011\u0010\u0012J\u0017\u0010\u0015\u001a\u00020\u00102\u0006\u0010\u0014\u001a\u00020\u0013H\u0000¢\u0006\u0004\b\u0015\u0010\u0016J\u0015\u0010\u0019\u001a\b\u0018\u00010\u0017R\u00020\u0018H\u0000¢\u0006\u0004\b\u0019\u0010\u001aR\u001a\u0010\u0003\u001a\u00020\u00028\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u001d\u0010\u001eR\u001a\u0010$\u001a\u00020\u001f8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b \u0010!\u001a\u0004\b\"\u0010#R \u0010*\u001a\b\u0012\u0004\u0012\u00020&0%8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b'\u0010(\u001a\u0004\b\u001b\u0010)R \u0010+\u001a\b\u0012\u0004\u0012\u00020&0%8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u001d\u0010(\u001a\u0004\b'\u0010)R\"\u00102\u001a\u00020,8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\"\u0010-\u001a\u0004\b.\u0010/\"\u0004\b0\u00101R\"\u00106\u001a\u00020,8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b3\u0010-\u001a\u0004\b4\u0010/\"\u0004\b5\u00101R(\u0010<\u001a\b\u0018\u000107R\u00020\u00188\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b.\u00108\u001a\u0004\b \u00109\"\u0004\b:\u0010;R\"\u0010B\u001a\u00020\u000b8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b=\u0010>\u001a\u0004\b3\u0010?\"\u0004\b@\u0010AR\"\u0010H\u001a\u00020C8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b4\u0010D\u001a\u0004\b=\u0010E\"\u0004\bF\u0010G¨\u0006I"}, d2 = {"Lokhttp3/internal/cache/DiskLruCache$Entry;", StringUtils.EMPTY, StringUtils.EMPTY, ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR, "<init>", "(Lokhttp3/internal/cache/DiskLruCache;Ljava/lang/String;)V", StringUtils.EMPTY, "strings", StringUtils.EMPTY, "j", "(Ljava/util/List;)Ljava/lang/Void;", StringUtils.EMPTY, "index", "Lokio/Source;", "k", "(I)Lokio/Source;", StringUtils.EMPTY, "m", "(Ljava/util/List;)V", "Lokio/BufferedSink;", "writer", "s", "(Lokio/BufferedSink;)V", "Lokhttp3/internal/cache/DiskLruCache$Snapshot;", "Lokhttp3/internal/cache/DiskLruCache;", "r", "()Lokhttp3/internal/cache/DiskLruCache$Snapshot;", "a", "Ljava/lang/String;", "d", "()Ljava/lang/String;", StringUtils.EMPTY, "b", "[J", "e", "()[J", "lengths", StringUtils.EMPTY, "Lokio/Path;", "c", "Ljava/util/List;", "()Ljava/util/List;", "cleanFiles", "dirtyFiles", StringUtils.EMPTY, "Z", "g", "()Z", "o", "(Z)V", "readable", "f", "i", "q", "zombie", "Lokhttp3/internal/cache/DiskLruCache$Editor;", "Lokhttp3/internal/cache/DiskLruCache$Editor;", "()Lokhttp3/internal/cache/DiskLruCache$Editor;", "l", "(Lokhttp3/internal/cache/DiskLruCache$Editor;)V", "currentEditor", "h", "I", "()I", "n", "(I)V", "lockingSourceCount", StringUtils.EMPTY, "J", "()J", "p", "(J)V", "sequenceNumber", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nDiskLruCache.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DiskLruCache.kt\nokhttp3/internal/cache/DiskLruCache$Entry\n+ 2 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n*L\n1#1,1120:1\n55#2,4:1121\n*S KotlinDebug\n*F\n+ 1 DiskLruCache.kt\nokhttp3/internal/cache/DiskLruCache$Entry\n*L\n1045#1:1121,4\n*E\n"})
    public final class Entry {
        private final String a;
        private final long[] b;
        private final List c;
        private final List d;
        private boolean e;
        private boolean f;
        private Editor g;
        private int h;
        private long i;
        final /* synthetic */ DiskLruCache j;

        public Entry(DiskLruCache diskLruCache, String str) {
            Intrinsics.checkNotNullParameter(str, ap.a(1370698730));
            this.j = diskLruCache;
            this.a = str;
            this.b = new long[diskLruCache.V()];
            this.c = new ArrayList();
            this.d = new ArrayList();
            StringBuilder sb = new StringBuilder(str);
            sb.append('.');
            int length = sb.length();
            int iV = diskLruCache.V();
            for (int i = 0; i < iV; i++) {
                sb.append(i);
                List list = this.c;
                Path pathP = this.j.P();
                String string = sb.toString();
                String strA = ap.a(1581276759);
                Intrinsics.checkNotNullExpressionValue(string, strA);
                list.add(pathP.j(string));
                sb.append(ap.a(1963720792));
                List list2 = this.d;
                Path pathP2 = this.j.P();
                String string2 = sb.toString();
                Intrinsics.checkNotNullExpressionValue(string2, strA);
                list2.add(pathP2.j(string2));
                sb.setLength(length);
            }
        }

        private final Void j(List list) throws IOException {
            throw new IOException("unexpected journal line: " + list);
        }

        private final Source k(int i) {
            final Source sourceW = this.j.Q().W((Path) this.c.get(i));
            if (this.j.n) {
                return sourceW;
            }
            this.h++;
            final DiskLruCache diskLruCache = this.j;
            return new ForwardingSource(sourceW) { // from class: okhttp3.internal.cache.DiskLruCache$Entry$newSource$1
                private boolean b;

                @Override // okio.ForwardingSource, okio.Source, java.io.Closeable, java.lang.AutoCloseable
                public void close() {
                    super.close();
                    if (this.b) {
                        return;
                    }
                    this.b = true;
                    DiskLruCache diskLruCache2 = diskLruCache;
                    DiskLruCache.Entry entry = this;
                    synchronized (diskLruCache2) {
                        try {
                            entry.n(entry.f() - 1);
                            if (entry.f() == 0 && entry.i()) {
                                diskLruCache2.o0(entry);
                            }
                            Unit unit = Unit.INSTANCE;
                        } catch (Throwable th) {
                            throw th;
                        }
                    }
                }
            };
        }

        public final List a() {
            return this.c;
        }

        public final Editor b() {
            return this.g;
        }

        public final List c() {
            return this.d;
        }

        public final String d() {
            return this.a;
        }

        public final long[] e() {
            return this.b;
        }

        public final int f() {
            return this.h;
        }

        public final boolean g() {
            return this.e;
        }

        public final long h() {
            return this.i;
        }

        public final boolean i() {
            return this.f;
        }

        public final void l(Editor editor) {
            this.g = editor;
        }

        /* JADX INFO: Thrown type has an unknown type hierarchy: kotlin.KotlinNothingValueException */
        public final void m(List list) throws IOException, KotlinNothingValueException {
            Intrinsics.checkNotNullParameter(list, "strings");
            if (list.size() != this.j.V()) {
                j(list);
                throw new KotlinNothingValueException();
            }
            try {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    this.b[i] = Long.parseLong((String) list.get(i));
                }
            } catch (NumberFormatException unused) {
                j(list);
                throw new KotlinNothingValueException();
            }
        }

        public final void n(int i) {
            this.h = i;
        }

        public final void o(boolean z) {
            this.e = z;
        }

        public final void p(long j) {
            this.i = j;
        }

        public final void q(boolean z) {
            this.f = z;
        }

        public final Snapshot r() {
            DiskLruCache diskLruCache = this.j;
            if (_UtilJvmKt.b && !Thread.holdsLock(diskLruCache)) {
                throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + diskLruCache);
            }
            if (!this.e) {
                return null;
            }
            if (!this.j.n && (this.g != null || this.f)) {
                return null;
            }
            ArrayList arrayList = new ArrayList();
            long[] jArr = (long[]) this.b.clone();
            try {
                int iV = this.j.V();
                for (int i = 0; i < iV; i++) {
                    arrayList.add(k(i));
                }
                return new Snapshot(this.j, this.a, this.i, arrayList, jArr);
            } catch (FileNotFoundException unused) {
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    _UtilCommonKt.f((Source) it.next());
                }
                try {
                    this.j.o0(this);
                } catch (IOException unused2) {
                }
                return null;
            }
        }

        public final void s(BufferedSink bufferedSink) {
            Intrinsics.checkNotNullParameter(bufferedSink, "writer");
            for (long j : this.b) {
                bufferedSink.writeByte(32).A0(j);
            }
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0016\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u000b\b\u0086\u0004\u0018\u00002\u00020\u0001B/\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\f\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\u0006\u0012\u0006\u0010\n\u001a\u00020\t¢\u0006\u0004\b\u000b\u0010\fJ\r\u0010\r\u001a\u00020\u0002¢\u0006\u0004\b\r\u0010\u000eJ\u0013\u0010\u0011\u001a\b\u0018\u00010\u000fR\u00020\u0010¢\u0006\u0004\b\u0011\u0010\u0012J\u0015\u0010\u0015\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u0013¢\u0006\u0004\b\u0015\u0010\u0016J\u000f\u0010\u0018\u001a\u00020\u0017H\u0016¢\u0006\u0004\b\u0018\u0010\u0019R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010\u001bR\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001c\u0010\u001dR\u001a\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001e\u0010\u001fR\u0014\u0010\n\u001a\u00020\t8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b \u0010!¨\u0006\""}, d2 = {"Lokhttp3/internal/cache/DiskLruCache$Snapshot;", "Ljava/io/Closeable;", StringUtils.EMPTY, ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR, StringUtils.EMPTY, "sequenceNumber", StringUtils.EMPTY, "Lokio/Source;", "sources", StringUtils.EMPTY, "lengths", "<init>", "(Lokhttp3/internal/cache/DiskLruCache;Ljava/lang/String;JLjava/util/List;[J)V", "o", "()Ljava/lang/String;", "Lokhttp3/internal/cache/DiskLruCache$Editor;", "Lokhttp3/internal/cache/DiskLruCache;", "j", "()Lokhttp3/internal/cache/DiskLruCache$Editor;", StringUtils.EMPTY, "index", "k", "(I)Lokio/Source;", StringUtils.EMPTY, "close", "()V", "a", "Ljava/lang/String;", "b", "J", "c", "Ljava/util/List;", "d", "[J", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public final class Snapshot implements Closeable {
        private final String a;
        private final long b;
        private final List c;
        private final long[] d;
        final /* synthetic */ DiskLruCache e;

        public Snapshot(DiskLruCache diskLruCache, String str, long j, List list, long[] jArr) {
            Intrinsics.checkNotNullParameter(str, ap.a(1206618023));
            Intrinsics.checkNotNullParameter(list, ap.a(835838467));
            Intrinsics.checkNotNullParameter(jArr, ap.a(1619875479));
            this.e = diskLruCache;
            this.a = str;
            this.b = j;
            this.c = list;
            this.d = jArr;
        }

        @Override // java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            Iterator it = this.c.iterator();
            while (it.hasNext()) {
                _UtilCommonKt.f((Source) it.next());
            }
        }

        public final Editor j() {
            return this.e.D(this.a, this.b);
        }

        public final Source k(int i) {
            return (Source) this.c.get(i);
        }

        public final String o() {
            return this.a;
        }
    }

    /* JADX WARN: Type inference failed for: r5v5, types: [okhttp3.internal.cache.DiskLruCache$cleanupTask$1] */
    public DiskLruCache(final FileSystem fileSystem, Path path, int i, int i2, long j, TaskRunner taskRunner) {
        Intrinsics.checkNotNullParameter(fileSystem, "fileSystem");
        Intrinsics.checkNotNullParameter(path, "directory");
        Intrinsics.checkNotNullParameter(taskRunner, "taskRunner");
        this.a = path;
        this.b = i;
        this.c = i2;
        this.d = new ForwardingFileSystem(fileSystem) { // from class: okhttp3.internal.cache.DiskLruCache$fileSystem$1
            @Override // okio.ForwardingFileSystem, okio.FileSystem
            public Sink V(Path path2, boolean z2) {
                Intrinsics.checkNotNullParameter(path2, ap.a(95906515));
                Path pathH = path2.h();
                if (pathH != null) {
                    g(pathH);
                }
                return super.V(path2, z2);
            }
        };
        this.e = j;
        this.k = new LinkedHashMap(0, 0.75f, true);
        this.t = taskRunner.k();
        final String str = _UtilJvmKt.c + " Cache";
        this.u = new Task(str) { // from class: okhttp3.internal.cache.DiskLruCache$cleanupTask$1
            {
                int i3 = 2;
                DefaultConstructorMarker defaultConstructorMarker = null;
                boolean z2 = false;
            }

            @Override // okhttp3.internal.concurrent.Task
            public long f() {
                DiskLruCache diskLruCache = this.e;
                synchronized (diskLruCache) {
                    if (!diskLruCache.o || diskLruCache.O()) {
                        return -1L;
                    }
                    try {
                        diskLruCache.w0();
                    } catch (IOException unused) {
                        diskLruCache.q = true;
                    }
                    try {
                        if (diskLruCache.X()) {
                            diskLruCache.j0();
                            diskLruCache.l = 0;
                        }
                    } catch (IOException unused2) {
                        diskLruCache.r = true;
                        BufferedSink bufferedSink = diskLruCache.j;
                        if (bufferedSink != null) {
                            _UtilCommonKt.f(bufferedSink);
                        }
                        diskLruCache.j = Okio.b(Okio.a());
                    }
                    return -1L;
                }
            }
        };
        if (j <= 0) {
            throw new IllegalArgumentException("maxSize <= 0");
        }
        if (i2 <= 0) {
            throw new IllegalArgumentException("valueCount <= 0");
        }
        this.f = path.j(w);
        this.g = path.j(x);
        this.h = path.j(y);
    }

    public static /* synthetic */ Editor I(DiskLruCache diskLruCache, String str, long j, int i, Object obj) {
        if ((i & 2) != 0) {
            j = B;
        }
        return diskLruCache.D(str, j);
    }

    private final boolean X() {
        int i = this.l;
        return i >= 2000 && i >= this.k.size();
    }

    private final BufferedSink a0() {
        return Okio.b(new FaultHidingSink(this.d.a(this.f), new Function1() { // from class: okhttp3.internal.cache.a
            public final Object invoke(Object obj) {
                return DiskLruCache.b0(this.a, (IOException) obj);
            }
        }));
    }

    private static final Unit b0(DiskLruCache diskLruCache, IOException iOException) {
        Intrinsics.checkNotNullParameter(iOException, "it");
        if (!_UtilJvmKt.b || Thread.holdsLock(diskLruCache)) {
            diskLruCache.m = true;
            return Unit.INSTANCE;
        }
        throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + diskLruCache);
    }

    private final void d0() {
        _UtilCommonKt.i(this.d, this.g);
        Iterator it = this.k.values().iterator();
        while (it.hasNext()) {
            Object next = it.next();
            Intrinsics.checkNotNullExpressionValue(next, "next(...)");
            Entry entry = (Entry) next;
            int i = 0;
            if (entry.b() == null) {
                int i2 = this.c;
                while (i < i2) {
                    this.i += entry.e()[i];
                    i++;
                }
            } else {
                entry.l(null);
                int i3 = this.c;
                while (i < i3) {
                    _UtilCommonKt.i(this.d, (Path) entry.a().get(i));
                    _UtilCommonKt.i(this.d, (Path) entry.c().get(i));
                    i++;
                }
                it.remove();
            }
        }
    }

    private final void e0() throws Throwable {
        BufferedSource bufferedSourceC = Okio.c(this.d.W(this.f));
        try {
            String strJ2 = bufferedSourceC.j2();
            String strJ22 = bufferedSourceC.j2();
            String strJ23 = bufferedSourceC.j2();
            String strJ24 = bufferedSourceC.j2();
            String strJ25 = bufferedSourceC.j2();
            if (!Intrinsics.areEqual(z, strJ2) || !Intrinsics.areEqual(A, strJ22) || !Intrinsics.areEqual(String.valueOf(this.b), strJ23) || !Intrinsics.areEqual(String.valueOf(this.c), strJ24) || strJ25.length() > 0) {
                throw new IOException("unexpected journal header: [" + strJ2 + ", " + strJ22 + ", " + strJ24 + ", " + strJ25 + AbstractJsonLexerKt.END_LIST);
            }
            int i = 0;
            while (true) {
                try {
                    i0(bufferedSourceC.j2());
                    i++;
                } catch (EOFException unused) {
                    this.l = i - this.k.size();
                    if (bufferedSourceC.H2()) {
                        BufferedSink bufferedSink = this.j;
                        if (bufferedSink != null) {
                            _UtilCommonKt.f(bufferedSink);
                        }
                        this.j = a0();
                    } else {
                        j0();
                    }
                    Unit unit = Unit.INSTANCE;
                    if (bufferedSourceC != null) {
                        try {
                            bufferedSourceC.close();
                            th = null;
                        } catch (Throwable th) {
                            th = th;
                        }
                    } else {
                        th = null;
                    }
                }
            }
        } catch (Throwable th2) {
            th = th2;
            if (bufferedSourceC != null) {
                try {
                    bufferedSourceC.close();
                } catch (Throwable th3) {
                    ExceptionsKt.addSuppressed(th, th3);
                }
            }
        }
        if (th != null) {
            throw th;
        }
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: kotlin.KotlinNothingValueException */
    private final void i0(String str) throws IOException, KotlinNothingValueException {
        String strSubstring;
        int iIndexOf$default = StringsKt.indexOf$default((CharSequence) str, ' ', 0, false, 6, (Object) null);
        if (iIndexOf$default == -1) {
            throw new IOException("unexpected journal line: " + str);
        }
        int i = iIndexOf$default + 1;
        int iIndexOf$default2 = StringsKt.indexOf$default((CharSequence) str, ' ', i, false, 4, (Object) null);
        if (iIndexOf$default2 == -1) {
            strSubstring = str.substring(i);
            Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
            String str2 = J;
            if (iIndexOf$default == str2.length() && StringsKt.startsWith$default(str, str2, false, 2, (Object) null)) {
                this.k.remove(strSubstring);
                return;
            }
        } else {
            strSubstring = str.substring(i, iIndexOf$default2);
            Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        }
        Entry entry = (Entry) this.k.get(strSubstring);
        if (entry == null) {
            entry = new Entry(this, strSubstring);
            this.k.put(strSubstring, entry);
        }
        if (iIndexOf$default2 != -1) {
            String str3 = G;
            if (iIndexOf$default == str3.length() && StringsKt.startsWith$default(str, str3, false, 2, (Object) null)) {
                String strSubstring2 = str.substring(iIndexOf$default2 + 1);
                Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
                List listSplit$default = StringsKt.split$default((CharSequence) strSubstring2, new char[]{' '}, false, 0, 6, (Object) null);
                entry.o(true);
                entry.l(null);
                entry.m(listSplit$default);
                return;
            }
        }
        if (iIndexOf$default2 == -1) {
            String str4 = H;
            if (iIndexOf$default == str4.length() && StringsKt.startsWith$default(str, str4, false, 2, (Object) null)) {
                entry.l(new Editor(this, entry));
                return;
            }
        }
        if (iIndexOf$default2 == -1) {
            String str5 = N;
            if (iIndexOf$default == str5.length() && StringsKt.startsWith$default(str, str5, false, 2, (Object) null)) {
                return;
            }
        }
        throw new IOException("unexpected journal line: " + str);
    }

    private final synchronized void u() {
        if (this.p) {
            throw new IllegalStateException("cache is closed");
        }
    }

    private final boolean v0() {
        for (Object obj : this.k.values()) {
            Intrinsics.checkNotNullExpressionValue(obj, "next(...)");
            Entry entry = (Entry) obj;
            if (!entry.i()) {
                o0(entry);
                return true;
            }
        }
        return false;
    }

    private final void x0(String str) {
        if (D.matches(str)) {
            return;
        }
        throw new IllegalArgumentException(("keys must match regex [a-z0-9_-]{1,120}: \"" + str + '\"').toString());
    }

    public final synchronized void A(Editor editor, boolean z2) {
        Intrinsics.checkNotNullParameter(editor, "editor");
        Entry entryE = editor.e();
        if (!Intrinsics.areEqual(entryE.b(), editor)) {
            throw new IllegalStateException("Check failed.");
        }
        if (z2 && !entryE.g()) {
            int i = this.c;
            for (int i2 = 0; i2 < i; i2++) {
                boolean[] zArrF = editor.f();
                Intrinsics.checkNotNull(zArrF);
                if (!zArrF[i2]) {
                    editor.b();
                    throw new IllegalStateException("Newly created entry didn't create value for index " + i2);
                }
                if (!this.d.u((Path) entryE.c().get(i2))) {
                    editor.b();
                    return;
                }
            }
        }
        int i3 = this.c;
        for (int i4 = 0; i4 < i3; i4++) {
            Path path = (Path) entryE.c().get(i4);
            if (!z2 || entryE.i()) {
                _UtilCommonKt.i(this.d, path);
            } else if (this.d.u(path)) {
                Path path2 = (Path) entryE.a().get(i4);
                this.d.e(path, path2);
                long j = entryE.e()[i4];
                Long lC = this.d.D(path2).c();
                long jLongValue = lC != null ? lC.longValue() : 0L;
                entryE.e()[i4] = jLongValue;
                this.i = (this.i - j) + jLongValue;
            }
        }
        entryE.l(null);
        if (entryE.i()) {
            o0(entryE);
            return;
        }
        this.l++;
        BufferedSink bufferedSink = this.j;
        Intrinsics.checkNotNull(bufferedSink);
        if (entryE.g() || z2) {
            entryE.o(true);
            bufferedSink.V1(G).writeByte(32);
            bufferedSink.V1(entryE.d());
            entryE.s(bufferedSink);
            bufferedSink.writeByte(10);
            if (z2) {
                long j2 = this.s;
                this.s = 1 + j2;
                entryE.p(j2);
            }
        } else {
            this.k.remove(entryE.d());
            bufferedSink.V1(J).writeByte(32);
            bufferedSink.V1(entryE.d());
            bufferedSink.writeByte(10);
        }
        bufferedSink.flush();
        if (this.i > this.e || X()) {
            TaskQueue.m(this.t, this.u, 0L, 2, null);
        }
    }

    public final void B() throws IOException {
        close();
        _UtilCommonKt.h(this.d, this.a);
    }

    public final synchronized Editor D(String str, long j) {
        Intrinsics.checkNotNullParameter(str, ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR);
        W();
        u();
        x0(str);
        Entry entry = (Entry) this.k.get(str);
        if (j != B && (entry == null || entry.h() != j)) {
            return null;
        }
        if ((entry != null ? entry.b() : null) != null) {
            return null;
        }
        if (entry != null && entry.f() != 0) {
            return null;
        }
        if (!this.q && !this.r) {
            BufferedSink bufferedSink = this.j;
            Intrinsics.checkNotNull(bufferedSink);
            bufferedSink.V1(H).writeByte(32).V1(str).writeByte(10);
            bufferedSink.flush();
            if (this.m) {
                return null;
            }
            if (entry == null) {
                entry = new Entry(this, str);
                this.k.put(str, entry);
            }
            Editor editor = new Editor(this, entry);
            entry.l(editor);
            return editor;
        }
        TaskQueue.m(this.t, this.u, 0L, 2, null);
        return null;
    }

    public final synchronized Snapshot J(String str) {
        Intrinsics.checkNotNullParameter(str, ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR);
        W();
        u();
        x0(str);
        Entry entry = (Entry) this.k.get(str);
        if (entry == null) {
            return null;
        }
        Snapshot snapshotR = entry.r();
        if (snapshotR == null) {
            return null;
        }
        this.l++;
        BufferedSink bufferedSink = this.j;
        Intrinsics.checkNotNull(bufferedSink);
        bufferedSink.V1(N).writeByte(32).V1(str).writeByte(10);
        if (X()) {
            TaskQueue.m(this.t, this.u, 0L, 2, null);
        }
        return snapshotR;
    }

    public final boolean O() {
        return this.p;
    }

    public final Path P() {
        return this.a;
    }

    public final FileSystem Q() {
        return this.d;
    }

    public final int V() {
        return this.c;
    }

    public final synchronized void W() {
        try {
            if (_UtilJvmKt.b && !Thread.holdsLock(this)) {
                throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
            }
            if (this.o) {
                return;
            }
            if (this.d.u(this.h)) {
                if (this.d.u(this.f)) {
                    this.d.q(this.h);
                } else {
                    this.d.e(this.h, this.f);
                }
            }
            this.n = _UtilCommonKt.x(this.d, this.h);
            if (this.d.u(this.f)) {
                try {
                    e0();
                    d0();
                    this.o = true;
                    return;
                } catch (IOException e) {
                    Platform.a.e().n("DiskLruCache " + this.a + " is corrupt: " + e.getMessage() + ", removing", 5, e);
                    try {
                        B();
                        this.p = false;
                        j0();
                        this.o = true;
                    } catch (Throwable th) {
                        this.p = false;
                        throw th;
                    }
                }
            }
            j0();
            this.o = true;
        } catch (Throwable th2) {
            throw th2;
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public synchronized void close() {
        Editor editorB;
        try {
            if (this.o && !this.p) {
                Collection collectionValues = this.k.values();
                Intrinsics.checkNotNullExpressionValue(collectionValues, "<get-values>(...)");
                for (Entry entry : (Entry[]) collectionValues.toArray(new Entry[0])) {
                    Intrinsics.checkNotNull(entry);
                    if (entry.b() != null && (editorB = entry.b()) != null) {
                        editorB.d();
                    }
                }
                w0();
                BufferedSink bufferedSink = this.j;
                if (bufferedSink != null) {
                    _UtilCommonKt.f(bufferedSink);
                }
                this.j = null;
                this.p = true;
                return;
            }
            this.p = true;
        } catch (Throwable th) {
            throw th;
        }
    }

    @Override // java.io.Flushable
    public synchronized void flush() {
        if (this.o) {
            u();
            w0();
            BufferedSink bufferedSink = this.j;
            Intrinsics.checkNotNull(bufferedSink);
            bufferedSink.flush();
        }
    }

    public final synchronized void j0() {
        Throwable th;
        try {
            BufferedSink bufferedSink = this.j;
            if (bufferedSink != null) {
                bufferedSink.close();
            }
            BufferedSink bufferedSinkB = Okio.b(this.d.V(this.g, false));
            try {
                bufferedSinkB.V1(z).writeByte(10);
                bufferedSinkB.V1(A).writeByte(10);
                bufferedSinkB.A0(this.b).writeByte(10);
                bufferedSinkB.A0(this.c).writeByte(10);
                bufferedSinkB.writeByte(10);
                for (Object obj : this.k.values()) {
                    Intrinsics.checkNotNullExpressionValue(obj, "next(...)");
                    Entry entry = (Entry) obj;
                    if (entry.b() != null) {
                        bufferedSinkB.V1(H).writeByte(32);
                        bufferedSinkB.V1(entry.d());
                        bufferedSinkB.writeByte(10);
                    } else {
                        bufferedSinkB.V1(G).writeByte(32);
                        bufferedSinkB.V1(entry.d());
                        entry.s(bufferedSinkB);
                        bufferedSinkB.writeByte(10);
                    }
                }
                Unit unit = Unit.INSTANCE;
                if (bufferedSinkB != null) {
                    try {
                        bufferedSinkB.close();
                        th = null;
                    } catch (Throwable th2) {
                        th = th2;
                    }
                } else {
                    th = null;
                }
            } catch (Throwable th3) {
                if (bufferedSinkB != null) {
                    try {
                        bufferedSinkB.close();
                    } catch (Throwable th4) {
                        ExceptionsKt.addSuppressed(th3, th4);
                    }
                }
                th = th3;
            }
            if (th != null) {
                throw th;
            }
            if (this.d.u(this.f)) {
                this.d.e(this.f, this.h);
                this.d.e(this.g, this.f);
                _UtilCommonKt.i(this.d, this.h);
            } else {
                this.d.e(this.g, this.f);
            }
            BufferedSink bufferedSink2 = this.j;
            if (bufferedSink2 != null) {
                _UtilCommonKt.f(bufferedSink2);
            }
            this.j = a0();
            this.m = false;
            this.r = false;
        } catch (Throwable th5) {
            throw th5;
        }
    }

    public final synchronized boolean m0(String str) {
        Intrinsics.checkNotNullParameter(str, ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR);
        W();
        u();
        x0(str);
        Entry entry = (Entry) this.k.get(str);
        if (entry == null) {
            return false;
        }
        boolean zO0 = o0(entry);
        if (zO0 && this.i <= this.e) {
            this.q = false;
        }
        return zO0;
    }

    public final boolean o0(Entry entry) {
        BufferedSink bufferedSink;
        Intrinsics.checkNotNullParameter(entry, "entry");
        if (!this.n) {
            if (entry.f() > 0 && (bufferedSink = this.j) != null) {
                bufferedSink.V1(H);
                bufferedSink.writeByte(32);
                bufferedSink.V1(entry.d());
                bufferedSink.writeByte(10);
                bufferedSink.flush();
            }
            if (entry.f() > 0 || entry.b() != null) {
                entry.q(true);
                return true;
            }
        }
        Editor editorB = entry.b();
        if (editorB != null) {
            editorB.d();
        }
        int i = this.c;
        for (int i2 = 0; i2 < i; i2++) {
            _UtilCommonKt.i(this.d, (Path) entry.a().get(i2));
            this.i -= entry.e()[i2];
            entry.e()[i2] = 0;
        }
        this.l++;
        BufferedSink bufferedSink2 = this.j;
        if (bufferedSink2 != null) {
            bufferedSink2.V1(J);
            bufferedSink2.writeByte(32);
            bufferedSink2.V1(entry.d());
            bufferedSink2.writeByte(10);
        }
        this.k.remove(entry.d());
        if (X()) {
            TaskQueue.m(this.t, this.u, 0L, 2, null);
        }
        return true;
    }

    public final void w0() {
        while (this.i > this.e) {
            if (!v0()) {
                return;
            }
        }
        this.q = false;
    }
}