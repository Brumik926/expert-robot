package okhttp3.internal.publicsuffix;

import android.content.Context;
import android.content.res.AssetManager;
import h.ap;
import java.io.IOException;
import java.io.InputStream;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal.platform.PlatformRegistry;
import okio.Okio;
import okio.Source;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\b\u0000\u0018\u0000 \r2\u00020\u0001:\u0001\u000eB\u0011\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u0007\u0010\bR\u001a\u0010\u0003\u001a\u00020\u00028\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\u000b\u0010\f¨\u0006\u000f"}, d2 = {"Lokhttp3/internal/publicsuffix/AssetPublicSuffixList;", "Lokhttp3/internal/publicsuffix/BasePublicSuffixList;", StringUtils.EMPTY, "path", "<init>", "(Ljava/lang/String;)V", "Lokio/Source;", "e", "()Lokio/Source;", "f", "Ljava/lang/String;", "j", "()Ljava/lang/String;", "g", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class AssetPublicSuffixList extends BasePublicSuffixList {
    public static final Companion g = new Companion(null);
    private static final String h = ap.a(268833581);
    private final String f;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lokhttp3/internal/publicsuffix/AssetPublicSuffixList$Companion;", StringUtils.EMPTY, "<init>", "()V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public AssetPublicSuffixList() {
        String str = null;
        this(str, 1, str);
    }

    @Override // okhttp3.internal.publicsuffix.BasePublicSuffixList
    public Source e() throws IOException {
        AssetManager assets;
        Context contextB = PlatformRegistry.a.b();
        if (contextB == null || (assets = contextB.getAssets()) == null) {
            throw new IOException("Platform applicationContext not initialized");
        }
        InputStream inputStreamOpen = assets.open(d());
        Intrinsics.checkNotNullExpressionValue(inputStreamOpen, "open(...)");
        return Okio.i(inputStreamOpen);
    }

    @Override // okhttp3.internal.publicsuffix.BasePublicSuffixList
    /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
    public String d() {
        return this.f;
    }

    public /* synthetic */ AssetPublicSuffixList(String str, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? h : str);
    }

    public AssetPublicSuffixList(String str) {
        Intrinsics.checkNotNullParameter(str, "path");
        this.f = str;
    }
}