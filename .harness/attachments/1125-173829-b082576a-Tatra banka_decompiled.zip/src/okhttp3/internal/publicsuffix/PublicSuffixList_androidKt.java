package okhttp3.internal.publicsuffix;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal.publicsuffix.PublicSuffixList;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\"\u0018\u0010\u0004\u001a\u00020\u0001*\u00020\u00008@X\u0080\u0004¢\u0006\u0006\u001a\u0004\b\u0002\u0010\u0003¨\u0006\u0005"}, d2 = {"Lokhttp3/internal/publicsuffix/PublicSuffixList$Companion;", "Lokhttp3/internal/publicsuffix/PublicSuffixList;", "a", "(Lokhttp3/internal/publicsuffix/PublicSuffixList$Companion;)Lokhttp3/internal/publicsuffix/PublicSuffixList;", "Default", "okhttp"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class PublicSuffixList_androidKt {
    public static final PublicSuffixList a(PublicSuffixList.Companion companion) {
        Intrinsics.checkNotNullParameter(companion, ap.a(584063116));
        return new AssetPublicSuffixList(null, 1, null);
    }
}