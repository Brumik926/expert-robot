package okhttp3.internal.publicsuffix;

import h.ap;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicBoolean;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal.platform.Platform;
import okio.BufferedSource;
import okio.ByteString;
import okio.Okio;
import okio.Source;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u0000\n\u0002\b\u0003\b \u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0005\u0010\u0003J\u000f\u0010\u0006\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0006\u0010\u0003J\u000f\u0010\b\u001a\u00020\u0007H&¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\n\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\n\u0010\u0003R\u0014\u0010\r\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\n\u0010\fR\u0014\u0010\u0011\u001a\u00020\u000e8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\u0010R\"\u0010\u0019\u001a\u00020\u00128\u0016@\u0016X\u0096.¢\u0006\u0012\n\u0004\b\u0013\u0010\u0014\u001a\u0004\b\u0015\u0010\u0016\"\u0004\b\u0017\u0010\u0018R\"\u0010\u001b\u001a\u00020\u00128\u0016@\u0016X\u0096.¢\u0006\u0012\n\u0004\b\b\u0010\u0014\u001a\u0004\b\u000f\u0010\u0016\"\u0004\b\u001a\u0010\u0018R\u0014\u0010\u001e\u001a\u00020\u001c8&X¦\u0004¢\u0006\u0006\u001a\u0004\b\u0013\u0010\u001d¨\u0006\u001f"}, d2 = {"Lokhttp3/internal/publicsuffix/BasePublicSuffixList;", "Lokhttp3/internal/publicsuffix/PublicSuffixList;", "<init>", "()V", StringUtils.EMPTY, "f", "g", "Lokio/Source;", "e", "()Lokio/Source;", "b", "Ljava/util/concurrent/atomic/AtomicBoolean;", "Ljava/util/concurrent/atomic/AtomicBoolean;", "listRead", "Ljava/util/concurrent/CountDownLatch;", "c", "Ljava/util/concurrent/CountDownLatch;", "readCompleteLatch", "Lokio/ByteString;", "d", "Lokio/ByteString;", "a", "()Lokio/ByteString;", "h", "(Lokio/ByteString;)V", "bytes", "i", "exceptionBytes", StringUtils.EMPTY, "()Ljava/lang/Object;", "path", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public abstract class BasePublicSuffixList implements PublicSuffixList {
    private final AtomicBoolean b = new AtomicBoolean(false);
    private final CountDownLatch c = new CountDownLatch(1);
    public ByteString d;
    public ByteString e;

    private final void f() {
        try {
            BufferedSource bufferedSourceC = Okio.c(e());
            try {
                ByteString byteStringF0 = bufferedSourceC.F0(bufferedSourceC.readInt());
                ByteString byteStringF02 = bufferedSourceC.F0(bufferedSourceC.readInt());
                Unit unit = Unit.INSTANCE;
                CloseableKt.closeFinally(bufferedSourceC, (Throwable) null);
                synchronized (this) {
                    Intrinsics.checkNotNull(byteStringF0);
                    h(byteStringF0);
                    Intrinsics.checkNotNull(byteStringF02);
                    i(byteStringF02);
                }
            } finally {
            }
        } finally {
            this.c.countDown();
        }
    }

    private final void g() {
        boolean z = false;
        while (true) {
            try {
                try {
                    f();
                    break;
                } catch (InterruptedIOException unused) {
                    Thread.interrupted();
                    z = true;
                } catch (IOException e) {
                    Platform.a.e().n(ap.a(2126083043), 5, e);
                    if (!z) {
                        return;
                    }
                }
            } finally {
                if (z) {
                    Thread.currentThread().interrupt();
                }
            }
        }
    }

    @Override // okhttp3.internal.publicsuffix.PublicSuffixList
    public ByteString a() {
        ByteString byteString = this.d;
        if (byteString != null) {
            return byteString;
        }
        Intrinsics.throwUninitializedPropertyAccessException("bytes");
        return null;
    }

    @Override // okhttp3.internal.publicsuffix.PublicSuffixList
    public void b() {
        if (this.b.get() || !this.b.compareAndSet(false, true)) {
            try {
                this.c.await();
            } catch (InterruptedException unused) {
                Thread.currentThread().interrupt();
            }
        } else {
            g();
        }
        if (this.d != null) {
            return;
        }
        throw new IllegalStateException(("Unable to load " + d() + " resource.").toString());
    }

    @Override // okhttp3.internal.publicsuffix.PublicSuffixList
    public ByteString c() {
        ByteString byteString = this.e;
        if (byteString != null) {
            return byteString;
        }
        Intrinsics.throwUninitializedPropertyAccessException("exceptionBytes");
        return null;
    }

    public abstract Object d();

    public abstract Source e();

    public void h(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "<set-?>");
        this.d = byteString;
    }

    public void i(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "<set-?>");
        this.e = byteString;
    }
}