package okhttp3.internal.ws;

import h.ap;
import java.io.Closeable;
import java.io.IOException;
import java.util.Random;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.coroutines.scheduling.WorkQueueKt;
import okio.Buffer;
import okio.BufferedSink;
import okio.ByteString;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0018\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B7\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\b\u001a\u00020\u0002\u0012\u0006\u0010\t\u001a\u00020\u0002\u0012\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\f\u0010\rJ\u001f\u0010\u0013\u001a\u00020\u00122\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0011\u001a\u00020\u0010H\u0002¢\u0006\u0004\b\u0013\u0010\u0014J\u0015\u0010\u0015\u001a\u00020\u00122\u0006\u0010\u0011\u001a\u00020\u0010¢\u0006\u0004\b\u0015\u0010\u0016J\u0015\u0010\u0017\u001a\u00020\u00122\u0006\u0010\u0011\u001a\u00020\u0010¢\u0006\u0004\b\u0017\u0010\u0016J\u001f\u0010\u001a\u001a\u00020\u00122\u0006\u0010\u0018\u001a\u00020\u000e2\b\u0010\u0019\u001a\u0004\u0018\u00010\u0010¢\u0006\u0004\b\u001a\u0010\u0014J\u001d\u0010\u001d\u001a\u00020\u00122\u0006\u0010\u001b\u001a\u00020\u000e2\u0006\u0010\u001c\u001a\u00020\u0010¢\u0006\u0004\b\u001d\u0010\u0014J\u000f\u0010\u001e\u001a\u00020\u0012H\u0016¢\u0006\u0004\b\u001e\u0010\u001fR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010 R\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b!\u0010\"\u001a\u0004\b#\u0010$R\u0017\u0010\u0007\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\b%\u0010&\u001a\u0004\b'\u0010(R\u0014\u0010\b\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0013\u0010 R\u0014\u0010\t\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010 R\u0014\u0010\u000b\u001a\u00020\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b)\u0010*R\u0014\u0010-\u001a\u00020+8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010,R\u0014\u0010/\u001a\u00020+8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b.\u0010,R\u0016\u00101\u001a\u00020\u00028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b0\u0010 R\u0018\u00104\u001a\u0004\u0018\u0001028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0017\u00103R\u0016\u00108\u001a\u0004\u0018\u0001058\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b6\u00107R\u0016\u0010<\u001a\u0004\u0018\u0001098\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b:\u0010;¨\u0006="}, d2 = {"Lokhttp3/internal/ws/WebSocketWriter;", "Ljava/io/Closeable;", StringUtils.EMPTY, "isClient", "Lokio/BufferedSink;", "sink", "Ljava/util/Random;", "random", "perMessageDeflate", "noContextTakeover", StringUtils.EMPTY, "minimumDeflateSize", "<init>", "(ZLokio/BufferedSink;Ljava/util/Random;ZZJ)V", StringUtils.EMPTY, "opcode", "Lokio/ByteString;", "payload", StringUtils.EMPTY, "d", "(ILokio/ByteString;)V", "g", "(Lokio/ByteString;)V", "j", "code", "reason", "a", "formatOpcode", "data", "e", "close", "()V", "Z", "b", "Lokio/BufferedSink;", "getSink", "()Lokio/BufferedSink;", "c", "Ljava/util/Random;", "getRandom", "()Ljava/util/Random;", "f", "J", "Lokio/Buffer;", "Lokio/Buffer;", "messageBuffer", "h", "sinkBuffer", "i", "writerClosed", "Lokhttp3/internal/ws/MessageDeflater;", "Lokhttp3/internal/ws/MessageDeflater;", "messageDeflater", StringUtils.EMPTY, "k", "[B", "maskKey", "Lokio/Buffer$UnsafeCursor;", "l", "Lokio/Buffer$UnsafeCursor;", "maskCursor", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nWebSocketWriter.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WebSocketWriter.kt\nokhttp3/internal/ws/WebSocketWriter\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,213:1\n1#2:214\n*E\n"})
public final class WebSocketWriter implements Closeable {
    private final boolean a;
    private final BufferedSink b;
    private final Random c;
    private final boolean d;
    private final boolean e;
    private final long f;
    private final Buffer g;
    private final Buffer h;
    private boolean i;
    private MessageDeflater j;
    private final byte[] k;
    private final Buffer.UnsafeCursor l;

    public WebSocketWriter(boolean z, BufferedSink bufferedSink, Random random, boolean z2, boolean z3, long j) {
        Intrinsics.checkNotNullParameter(bufferedSink, ap.a(401191485));
        Intrinsics.checkNotNullParameter(random, ap.a(42617077));
        this.a = z;
        this.b = bufferedSink;
        this.c = random;
        this.d = z2;
        this.e = z3;
        this.f = j;
        this.g = new Buffer();
        this.h = bufferedSink.getBuffer();
        this.k = z ? new byte[4] : null;
        this.l = z ? new Buffer.UnsafeCursor() : null;
    }

    private final void d(int i, ByteString byteString) throws IOException {
        if (this.i) {
            throw new IOException("closed");
        }
        int size = byteString.size();
        if (size > 125) {
            throw new IllegalArgumentException("Payload size must be less than or equal to 125");
        }
        this.h.writeByte(i | 128);
        if (this.a) {
            this.h.writeByte(size | 128);
            Random random = this.c;
            byte[] bArr = this.k;
            Intrinsics.checkNotNull(bArr);
            random.nextBytes(bArr);
            this.h.write(this.k);
            if (size > 0) {
                long size2 = this.h.size();
                this.h.l1(byteString);
                Buffer buffer = this.h;
                Buffer.UnsafeCursor unsafeCursor = this.l;
                Intrinsics.checkNotNull(unsafeCursor);
                buffer.P(unsafeCursor);
                this.l.q(size2);
                WebSocketProtocol.a.b(this.l, this.k);
                this.l.close();
            }
        } else {
            this.h.writeByte(size);
            this.h.l1(byteString);
        }
        this.b.flush();
    }

    public final void a(int i, ByteString byteString) {
        ByteString byteStringV = ByteString.e;
        if (i != 0 || byteString != null) {
            if (i != 0) {
                WebSocketProtocol.a.c(i);
            }
            Buffer buffer = new Buffer();
            buffer.writeShort(i);
            if (byteString != null) {
                buffer.l1(byteString);
            }
            byteStringV = buffer.V();
        }
        try {
            d(8, byteStringV);
        } finally {
            this.i = true;
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        MessageDeflater messageDeflater = this.j;
        if (messageDeflater != null) {
            messageDeflater.close();
        }
    }

    public final void e(int i, ByteString byteString) throws IOException {
        Intrinsics.checkNotNullParameter(byteString, "data");
        if (this.i) {
            throw new IOException("closed");
        }
        this.g.l1(byteString);
        int i2 = i | 128;
        if (this.d && byteString.size() >= this.f) {
            MessageDeflater messageDeflater = this.j;
            if (messageDeflater == null) {
                messageDeflater = new MessageDeflater(this.e);
                this.j = messageDeflater;
            }
            messageDeflater.a(this.g);
            i2 = i | 192;
        }
        long size = this.g.size();
        this.h.writeByte(i2);
        int i3 = this.a ? 128 : 0;
        if (size <= 125) {
            this.h.writeByte(i3 | ((int) size));
        } else if (size <= 65535) {
            this.h.writeByte(i3 | 126);
            this.h.writeShort((int) size);
        } else {
            this.h.writeByte(i3 | WorkQueueKt.MASK);
            this.h.J0(size);
        }
        if (this.a) {
            Random random = this.c;
            byte[] bArr = this.k;
            Intrinsics.checkNotNull(bArr);
            random.nextBytes(bArr);
            this.h.write(this.k);
            if (size > 0) {
                Buffer buffer = this.g;
                Buffer.UnsafeCursor unsafeCursor = this.l;
                Intrinsics.checkNotNull(unsafeCursor);
                buffer.P(unsafeCursor);
                this.l.q(0L);
                WebSocketProtocol.a.b(this.l, this.k);
                this.l.close();
            }
        }
        this.h.a2(this.g, size);
        this.b.A1();
    }

    public final void g(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "payload");
        d(9, byteString);
    }

    public final void j(ByteString byteString) throws IOException {
        Intrinsics.checkNotNullParameter(byteString, "payload");
        d(10, byteString);
    }
}