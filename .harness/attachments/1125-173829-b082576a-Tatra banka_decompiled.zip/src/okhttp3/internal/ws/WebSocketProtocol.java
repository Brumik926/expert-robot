package okhttp3.internal.ws;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okio.Buffer;
import org.apache.tika.parser.external.ExternalParsersConfigReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0012\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001d\u0010\t\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\t\u0010\nJ\u0017\u0010\u000e\u001a\u0004\u0018\u00010\r2\u0006\u0010\f\u001a\u00020\u000b¢\u0006\u0004\b\u000e\u0010\u000fJ\u0015\u0010\u0010\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\u000b¢\u0006\u0004\b\u0010\u0010\u0011¨\u0006\u0012"}, d2 = {"Lokhttp3/internal/ws/WebSocketProtocol;", StringUtils.EMPTY, "<init>", "()V", "Lokio/Buffer$UnsafeCursor;", "cursor", StringUtils.EMPTY, ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR, StringUtils.EMPTY, "b", "(Lokio/Buffer$UnsafeCursor;[B)V", StringUtils.EMPTY, "code", StringUtils.EMPTY, "a", "(I)Ljava/lang/String;", "c", "(I)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nWebSocketProtocol.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WebSocketProtocol.kt\nokhttp3/internal/ws/WebSocketProtocol\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,152:1\n1#2:153\n*E\n"})
public final class WebSocketProtocol {
    public static final WebSocketProtocol a = new WebSocketProtocol();

    private WebSocketProtocol() {
    }

    public final String a(int i) {
        if (i < 1000 || i >= 5000) {
            return ap.a(132774901) + i;
        }
        if ((1004 > i || i >= 1007) && (1015 > i || i >= 3000)) {
            return null;
        }
        return ap.a(9202292) + i + ap.a(80491151);
    }

    public final void b(Buffer.UnsafeCursor unsafeCursor, byte[] bArr) {
        Intrinsics.checkNotNullParameter(unsafeCursor, "cursor");
        Intrinsics.checkNotNullParameter(bArr, ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR);
        int length = bArr.length;
        int i = 0;
        do {
            byte[] bArr2 = unsafeCursor.e;
            int i2 = unsafeCursor.f;
            int i3 = unsafeCursor.g;
            if (bArr2 != null) {
                while (i2 < i3) {
                    int i4 = i % length;
                    bArr2[i2] = (byte) (bArr2[i2] ^ bArr[i4]);
                    i2++;
                    i = i4 + 1;
                }
            }
        } while (unsafeCursor.k() != -1);
    }

    public final void c(int i) {
        String strA = a(i);
        if (strA == null) {
            return;
        }
        Intrinsics.checkNotNull(strA);
        throw new IllegalArgumentException(strA.toString());
    }
}