package okhttp3.internal.ws;

import h.ap;
import java.io.Closeable;
import java.util.zip.Deflater;
import kotlin.Metadata;
import kotlin.io.CloseableKt;
import kotlin.jvm.internal.Intrinsics;
import okio.Buffer;
import okio.ByteString;
import okio.DeflaterSink;
import okio.Sink;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u001b\u0010\t\u001a\u00020\u0002*\u00020\u00062\u0006\u0010\b\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\t\u0010\nJ\u0015\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\u0006¢\u0006\u0004\b\r\u0010\u000eJ\u000f\u0010\u000f\u001a\u00020\fH\u0016¢\u0006\u0004\b\u000f\u0010\u0010R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\r\u0010\u0011R\u0014\u0010\u0014\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010\u0013R\u0014\u0010\u0018\u001a\u00020\u00158\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0016\u0010\u0017R\u0014\u0010\u001b\u001a\u00020\u00198\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\t\u0010\u001a¨\u0006\u001c"}, d2 = {"Lokhttp3/internal/ws/MessageDeflater;", "Ljava/io/Closeable;", StringUtils.EMPTY, "noContextTakeover", "<init>", "(Z)V", "Lokio/Buffer;", "Lokio/ByteString;", "suffix", "d", "(Lokio/Buffer;Lokio/ByteString;)Z", "buffer", StringUtils.EMPTY, "a", "(Lokio/Buffer;)V", "close", "()V", "Z", "b", "Lokio/Buffer;", "deflatedBytes", "Ljava/util/zip/Deflater;", "c", "Ljava/util/zip/Deflater;", "deflater", "Lokio/DeflaterSink;", "Lokio/DeflaterSink;", "deflaterSink", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class MessageDeflater implements Closeable {
    private final boolean a;
    private final Buffer b;
    private final Deflater c;
    private final DeflaterSink d;

    public MessageDeflater(boolean z) {
        this.a = z;
        Buffer buffer = new Buffer();
        this.b = buffer;
        Deflater deflater = new Deflater(-1, true);
        this.c = deflater;
        this.d = new DeflaterSink((Sink) buffer, deflater);
    }

    private final boolean d(Buffer buffer, ByteString byteString) {
        return buffer.Y(buffer.size() - ((long) byteString.size()), byteString);
    }

    public final void a(Buffer buffer) {
        Intrinsics.checkNotNullParameter(buffer, ap.a(30583475));
        if (this.b.size() != 0) {
            throw new IllegalArgumentException(ap.a(1153380873));
        }
        if (this.a) {
            this.c.reset();
        }
        this.d.a2(buffer, buffer.size());
        this.d.flush();
        if (d(this.b, MessageDeflaterKt.a)) {
            long size = this.b.size() - ((long) 4);
            Buffer.UnsafeCursor unsafeCursorQ = Buffer.Q(this.b, null, 1, null);
            try {
                unsafeCursorQ.o(size);
                CloseableKt.closeFinally(unsafeCursorQ, (Throwable) null);
            } finally {
            }
        } else {
            this.b.writeByte(0);
        }
        Buffer buffer2 = this.b;
        buffer.a2(buffer2, buffer2.size());
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() throws Throwable {
        this.d.close();
    }
}