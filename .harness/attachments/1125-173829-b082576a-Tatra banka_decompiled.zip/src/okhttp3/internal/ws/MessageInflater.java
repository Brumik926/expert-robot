package okhttp3.internal.ws;

import h.ap;
import java.io.Closeable;
import java.io.IOException;
import java.util.zip.Inflater;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okio.Buffer;
import okio.InflaterSource;
import okio.Source;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u0015\u0010\t\u001a\u00020\b2\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\t\u0010\nJ\u000f\u0010\u000b\u001a\u00020\bH\u0016¢\u0006\u0004\b\u000b\u0010\fR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\t\u0010\rR\u0014\u0010\u0010\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000e\u0010\u000fR\u0014\u0010\u0014\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010\u0013R\u0014\u0010\u0018\u001a\u00020\u00158\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0016\u0010\u0017¨\u0006\u0019"}, d2 = {"Lokhttp3/internal/ws/MessageInflater;", "Ljava/io/Closeable;", StringUtils.EMPTY, "noContextTakeover", "<init>", "(Z)V", "Lokio/Buffer;", "buffer", StringUtils.EMPTY, "a", "(Lokio/Buffer;)V", "close", "()V", "Z", "b", "Lokio/Buffer;", "deflatedBytes", "Ljava/util/zip/Inflater;", "c", "Ljava/util/zip/Inflater;", "inflater", "Lokio/InflaterSource;", "d", "Lokio/InflaterSource;", "inflaterSource", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class MessageInflater implements Closeable {
    private final boolean a;
    private final Buffer b;
    private final Inflater c;
    private final InflaterSource d;

    public MessageInflater(boolean z) {
        this.a = z;
        Buffer buffer = new Buffer();
        this.b = buffer;
        Inflater inflater = new Inflater(true);
        this.c = inflater;
        this.d = new InflaterSource((Source) buffer, inflater);
    }

    public final void a(Buffer buffer) throws IOException {
        Intrinsics.checkNotNullParameter(buffer, ap.a(70648364));
        if (this.b.size() != 0) {
            throw new IllegalArgumentException(ap.a(1544243529));
        }
        if (this.a) {
            this.c.reset();
        }
        this.b.d2(buffer);
        this.b.writeInt(65535);
        long bytesRead = this.c.getBytesRead() + this.b.size();
        do {
            this.d.a(buffer, Long.MAX_VALUE);
            if (this.c.getBytesRead() >= bytesRead) {
                return;
            }
        } while (!this.c.finished());
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.d.close();
    }
}