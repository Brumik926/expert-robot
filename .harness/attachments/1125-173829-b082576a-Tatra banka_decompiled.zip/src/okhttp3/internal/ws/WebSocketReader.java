package okhttp3.internal.ws;

import h.ap;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.net.ProtocolException;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.coroutines.scheduling.WorkQueueKt;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal._UtilJvmKt;
import okio.Buffer;
import okio.BufferedSource;
import okio.ByteString;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0014\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001:\u0001>B/\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\b\u001a\u00020\u0002\u0012\u0006\u0010\t\u001a\u00020\u0002¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\r\u001a\u00020\fH\u0002¢\u0006\u0004\b\r\u0010\u000eJ\u000f\u0010\u000f\u001a\u00020\fH\u0002¢\u0006\u0004\b\u000f\u0010\u000eJ\u000f\u0010\u0010\u001a\u00020\fH\u0002¢\u0006\u0004\b\u0010\u0010\u000eJ\u000f\u0010\u0011\u001a\u00020\fH\u0002¢\u0006\u0004\b\u0011\u0010\u000eJ\u000f\u0010\u0012\u001a\u00020\fH\u0002¢\u0006\u0004\b\u0012\u0010\u000eJ\r\u0010\u0013\u001a\u00020\f¢\u0006\u0004\b\u0013\u0010\u000eJ\u000f\u0010\u0014\u001a\u00020\fH\u0016¢\u0006\u0004\b\u0014\u0010\u000eR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010\u0016R\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\u0017\u0010\u0018\u001a\u0004\b\u0019\u0010\u001aR\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001b\u0010\u001cR\u0014\u0010\b\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010\u0016R\u0014\u0010\t\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001e\u0010\u0016R\u0016\u0010 \u001a\u00020\u00028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001f\u0010\u0016R\u0016\u0010$\u001a\u00020!8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\"\u0010#R\u0016\u0010(\u001a\u00020%8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b&\u0010'R\u0016\u0010*\u001a\u00020\u00028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b)\u0010\u0016R\u0016\u0010+\u001a\u00020\u00028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0013\u0010\u0016R\u0016\u0010,\u001a\u00020\u00028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u000f\u0010\u0016R\u0014\u00100\u001a\u00020-8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b.\u0010/R\u0014\u00102\u001a\u00020-8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b1\u0010/R\u0018\u00106\u001a\u0004\u0018\u0001038\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b4\u00105R\u0016\u00109\u001a\u0004\u0018\u0001078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\r\u00108R\u0016\u0010=\u001a\u0004\u0018\u00010:8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b;\u0010<¨\u0006?"}, d2 = {"Lokhttp3/internal/ws/WebSocketReader;", "Ljava/io/Closeable;", StringUtils.EMPTY, "isClient", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "Lokhttp3/internal/ws/WebSocketReader$FrameCallback;", "frameCallback", "perMessageDeflate", "noContextTakeover", "<init>", "(ZLokio/BufferedSource;Lokhttp3/internal/ws/WebSocketReader$FrameCallback;ZZ)V", StringUtils.EMPTY, "o", "()V", "k", "r", "u", "q", "j", "close", "a", "Z", "b", "Lokio/BufferedSource;", "getSource", "()Lokio/BufferedSource;", "c", "Lokhttp3/internal/ws/WebSocketReader$FrameCallback;", "d", "e", "f", "closed", StringUtils.EMPTY, "g", "I", "opcode", StringUtils.EMPTY, "h", "J", "frameLength", "i", "isFinalFrame", "isControlFrame", "readingCompressedMessage", "Lokio/Buffer;", "l", "Lokio/Buffer;", "controlFrameBuffer", "m", "messageFrameBuffer", "Lokhttp3/internal/ws/MessageInflater;", "n", "Lokhttp3/internal/ws/MessageInflater;", "messageInflater", StringUtils.EMPTY, "[B", "maskKey", "Lokio/Buffer$UnsafeCursor;", "p", "Lokio/Buffer$UnsafeCursor;", "maskCursor", "FrameCallback", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nWebSocketReader.kt\nKotlin\n*S Kotlin\n*F\n+ 1 WebSocketReader.kt\nokhttp3/internal/ws/WebSocketReader\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,308:1\n1#2:309\n*E\n"})
public final class WebSocketReader implements Closeable {
    private final boolean a;
    private final BufferedSource b;
    private final FrameCallback c;
    private final boolean d;
    private final boolean e;
    private boolean f;
    private int g;
    private long h;
    private boolean i;
    private boolean j;
    private boolean k;
    private final Buffer l;
    private final Buffer m;
    private MessageInflater n;
    private final byte[] o;
    private final Buffer.UnsafeCursor p;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\u0005\bf\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H&¢\u0006\u0004\b\u0005\u0010\u0006J\u0017\u0010\t\u001a\u00020\u00042\u0006\u0010\b\u001a\u00020\u0007H&¢\u0006\u0004\b\t\u0010\nJ\u0017\u0010\f\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u0007H&¢\u0006\u0004\b\f\u0010\nJ\u0017\u0010\r\u001a\u00020\u00042\u0006\u0010\u000b\u001a\u00020\u0007H&¢\u0006\u0004\b\r\u0010\nJ\u001f\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\u0002H&¢\u0006\u0004\b\u0011\u0010\u0012¨\u0006\u0013À\u0006\u0003"}, d2 = {"Lokhttp3/internal/ws/WebSocketReader$FrameCallback;", StringUtils.EMPTY, StringUtils.EMPTY, "text", StringUtils.EMPTY, "h", "(Ljava/lang/String;)V", "Lokio/ByteString;", "bytes", "g", "(Lokio/ByteString;)V", "payload", "b", "c", StringUtils.EMPTY, "code", "reason", "e", "(ILjava/lang/String;)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public interface FrameCallback {
        void b(ByteString byteString);

        void c(ByteString byteString);

        void e(int i, String str);

        void g(ByteString byteString);

        void h(String str);
    }

    public WebSocketReader(boolean z, BufferedSource bufferedSource, FrameCallback frameCallback, boolean z2, boolean z3) {
        Intrinsics.checkNotNullParameter(bufferedSource, ap.a(1689959445));
        Intrinsics.checkNotNullParameter(frameCallback, ap.a(617802618));
        this.a = z;
        this.b = bufferedSource;
        this.c = frameCallback;
        this.d = z2;
        this.e = z3;
        this.l = new Buffer();
        this.m = new Buffer();
        this.o = z ? null : new byte[4];
        this.p = z ? null : new Buffer.UnsafeCursor();
    }

    private final void k() throws ProtocolException, EOFException {
        short s;
        String strX;
        long j = this.h;
        if (j > 0) {
            this.b.N1(this.l, j);
            if (!this.a) {
                Buffer buffer = this.l;
                Buffer.UnsafeCursor unsafeCursor = this.p;
                Intrinsics.checkNotNull(unsafeCursor);
                buffer.P(unsafeCursor);
                this.p.q(0L);
                WebSocketProtocol webSocketProtocol = WebSocketProtocol.a;
                Buffer.UnsafeCursor unsafeCursor2 = this.p;
                byte[] bArr = this.o;
                Intrinsics.checkNotNull(bArr);
                webSocketProtocol.b(unsafeCursor2, bArr);
                this.p.close();
            }
        }
        switch (this.g) {
            case 8:
                long size = this.l.size();
                if (size == 1) {
                    throw new ProtocolException("Malformed close payload length of 1.");
                }
                if (size != 0) {
                    s = this.l.readShort();
                    strX = this.l.X();
                    String strA = WebSocketProtocol.a.a(s);
                    if (strA != null) {
                        throw new ProtocolException(strA);
                    }
                } else {
                    s = 1005;
                    strX = StringUtils.EMPTY;
                }
                this.c.e(s, strX);
                this.f = true;
                return;
            case 9:
                this.c.b(this.l.V());
                return;
            case 10:
                this.c.c(this.l.V());
                return;
            default:
                throw new ProtocolException("Unknown control opcode: " + _UtilJvmKt.t(this.g));
        }
    }

    private final void o() throws IOException {
        boolean z;
        if (this.f) {
            throw new IOException("closed");
        }
        long jI = this.b.timeout().i();
        this.b.timeout().c();
        try {
            int iB = _UtilCommonKt.b(this.b.readByte(), 255);
            this.b.timeout().h(jI, TimeUnit.NANOSECONDS);
            int i = iB & 15;
            this.g = i;
            boolean z2 = (iB & 128) != 0;
            this.i = z2;
            boolean z3 = (iB & 8) != 0;
            this.j = z3;
            if (z3 && !z2) {
                throw new ProtocolException("Control frames must be final.");
            }
            boolean z4 = (iB & 64) != 0;
            if (i == 1 || i == 2) {
                if (!z4) {
                    z = false;
                } else {
                    if (!this.d) {
                        throw new ProtocolException("Unexpected rsv1 flag");
                    }
                    z = true;
                }
                this.k = z;
            } else if (z4) {
                throw new ProtocolException("Unexpected rsv1 flag");
            }
            if ((iB & 32) != 0) {
                throw new ProtocolException("Unexpected rsv2 flag");
            }
            if ((iB & 16) != 0) {
                throw new ProtocolException("Unexpected rsv3 flag");
            }
            int iB2 = _UtilCommonKt.b(this.b.readByte(), 255);
            boolean z5 = (iB2 & 128) != 0;
            if (z5 == this.a) {
                throw new ProtocolException(this.a ? "Server-sent frames must not be masked." : "Client-sent frames must be masked.");
            }
            long j = iB2 & WorkQueueKt.MASK;
            this.h = j;
            if (j == 126) {
                this.h = _UtilCommonKt.c(this.b.readShort(), 65535);
            } else if (j == 127) {
                long j2 = this.b.readLong();
                this.h = j2;
                if (j2 < 0) {
                    throw new ProtocolException("Frame length 0x" + _UtilJvmKt.u(this.h) + " > 0x7FFFFFFFFFFFFFFF");
                }
            }
            if (this.j && this.h > 125) {
                throw new ProtocolException("Control frame must be less than 125B.");
            }
            if (z5) {
                BufferedSource bufferedSource = this.b;
                byte[] bArr = this.o;
                Intrinsics.checkNotNull(bArr);
                bufferedSource.readFully(bArr);
            }
        } catch (Throwable th) {
            this.b.timeout().h(jI, TimeUnit.NANOSECONDS);
            throw th;
        }
    }

    private final void q() throws IOException {
        while (!this.f) {
            long j = this.h;
            if (j > 0) {
                this.b.N1(this.m, j);
                if (!this.a) {
                    Buffer buffer = this.m;
                    Buffer.UnsafeCursor unsafeCursor = this.p;
                    Intrinsics.checkNotNull(unsafeCursor);
                    buffer.P(unsafeCursor);
                    this.p.q(this.m.size() - this.h);
                    WebSocketProtocol webSocketProtocol = WebSocketProtocol.a;
                    Buffer.UnsafeCursor unsafeCursor2 = this.p;
                    byte[] bArr = this.o;
                    Intrinsics.checkNotNull(bArr);
                    webSocketProtocol.b(unsafeCursor2, bArr);
                    this.p.close();
                }
            }
            if (this.i) {
                return;
            }
            u();
            if (this.g != 0) {
                throw new ProtocolException("Expected continuation opcode. Got: " + _UtilJvmKt.t(this.g));
            }
        }
        throw new IOException("closed");
    }

    private final void r() throws IOException {
        int i = this.g;
        if (i != 1 && i != 2) {
            throw new ProtocolException("Unknown opcode: " + _UtilJvmKt.t(i));
        }
        q();
        if (this.k) {
            MessageInflater messageInflater = this.n;
            if (messageInflater == null) {
                messageInflater = new MessageInflater(this.e);
                this.n = messageInflater;
            }
            messageInflater.a(this.m);
        }
        if (i == 1) {
            this.c.h(this.m.X());
        } else {
            this.c.g(this.m.V());
        }
    }

    private final void u() throws IOException {
        while (!this.f) {
            o();
            if (!this.j) {
                return;
            } else {
                k();
            }
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        MessageInflater messageInflater = this.n;
        if (messageInflater != null) {
            messageInflater.close();
        }
    }

    public final void j() throws IOException {
        o();
        if (this.j) {
            k();
        } else {
            r();
        }
    }
}