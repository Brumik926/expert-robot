package okhttp3.internal.ws;

import h.ap;
import kotlin.Metadata;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\b\n\u0002\u0018\u0002\n\u0002\b\u0004\"\u0014\u0010\u0003\u001a\u00020\u00008\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0001\u0010\u0002¨\u0006\u0004"}, d2 = {"Lokio/ByteString;", "a", "Lokio/ByteString;", "EMPTY_DEFLATE_BLOCK", "okhttp"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class MessageDeflaterKt {
    private static final ByteString a = ByteString.d.b(ap.a(1354106519));
}