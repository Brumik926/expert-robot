package okhttp3.internal.ws;

import h.ap;
import java.io.Closeable;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.SocketTimeoutException;
import java.util.ArrayDeque;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.IntRange;
import kotlin.text.StringsKt;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.EventListener;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.concurrent.Lockable;
import okhttp3.internal.concurrent.Task;
import okhttp3.internal.concurrent.TaskQueue;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.connection.Exchange;
import okhttp3.internal.connection.RealCall;
import okhttp3.internal.ws.RealWebSocket;
import okhttp3.internal.ws.WebSocketReader;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.ByteString;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.parser.external.ExternalParsersConfigReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000¼\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u001f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u0016\u0018\u0000 \u008c\u00012\u00020\u00012\u00020\u00022\u00020\u0003:\n\u008d\u0001\u008e\u0001\u008f\u0001\u0090\u0001\u0091\u0001BI\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\u000b\u001a\u00020\n\u0012\u0006\u0010\r\u001a\u00020\f\u0012\b\u0010\u000f\u001a\u0004\u0018\u00010\u000e\u0012\u0006\u0010\u0010\u001a\u00020\f\u0012\u0006\u0010\u0011\u001a\u00020\f¢\u0006\u0004\b\u0012\u0010\u0013J\u0013\u0010\u0015\u001a\u00020\u0014*\u00020\u000eH\u0002¢\u0006\u0004\b\u0015\u0010\u0016J\u001f\u0010\u001b\u001a\u00020\u00142\u0006\u0010\u0018\u001a\u00020\u00172\u0006\u0010\u001a\u001a\u00020\u0019H\u0002¢\u0006\u0004\b\u001b\u0010\u001cJ\u000f\u0010\u001e\u001a\u00020\u001dH\u0002¢\u0006\u0004\b\u001e\u0010\u001fJ\u000f\u0010 \u001a\u00020\u0006H\u0016¢\u0006\u0004\b \u0010!J\u000f\u0010\"\u001a\u00020\u001dH\u0016¢\u0006\u0004\b\"\u0010\u001fJ\u0015\u0010%\u001a\u00020\u001d2\u0006\u0010$\u001a\u00020#¢\u0006\u0004\b%\u0010&J!\u0010+\u001a\u00020\u001d2\u0006\u0010(\u001a\u00020'2\b\u0010*\u001a\u0004\u0018\u00010)H\u0000¢\u0006\u0004\b+\u0010,J\u001d\u00101\u001a\u00020\u001d2\u0006\u0010.\u001a\u00020-2\u0006\u00100\u001a\u00020/¢\u0006\u0004\b1\u00102J\u0015\u00103\u001a\u00020\u001d2\u0006\u0010(\u001a\u00020'¢\u0006\u0004\b3\u00104J\r\u00105\u001a\u00020\u001d¢\u0006\u0004\b5\u0010\u001fJ\u0017\u00107\u001a\u00020\u001d2\u0006\u00106\u001a\u00020-H\u0016¢\u0006\u0004\b7\u00108J\u0017\u0010:\u001a\u00020\u001d2\u0006\u00109\u001a\u00020\u0017H\u0016¢\u0006\u0004\b:\u0010;J\u0017\u0010=\u001a\u00020\u001d2\u0006\u0010<\u001a\u00020\u0017H\u0016¢\u0006\u0004\b=\u0010;J\u0017\u0010>\u001a\u00020\u001d2\u0006\u0010<\u001a\u00020\u0017H\u0016¢\u0006\u0004\b>\u0010;J\u001f\u0010A\u001a\u00020\u001d2\u0006\u0010?\u001a\u00020\u00192\u0006\u0010@\u001a\u00020-H\u0016¢\u0006\u0004\bA\u0010BJ\u0017\u0010C\u001a\u00020\u00142\u0006\u00106\u001a\u00020-H\u0016¢\u0006\u0004\bC\u0010DJ\u0017\u0010E\u001a\u00020\u00142\u0006\u00109\u001a\u00020\u0017H\u0016¢\u0006\u0004\bE\u0010FJ!\u0010G\u001a\u00020\u00142\u0006\u0010?\u001a\u00020\u00192\b\u0010@\u001a\u0004\u0018\u00010-H\u0016¢\u0006\u0004\bG\u0010HJ'\u0010J\u001a\u00020\u00142\u0006\u0010?\u001a\u00020\u00192\b\u0010@\u001a\u0004\u0018\u00010-2\u0006\u0010I\u001a\u00020\f¢\u0006\u0004\bJ\u0010KJ\u000f\u0010L\u001a\u00020\u0014H\u0000¢\u0006\u0004\bL\u0010MJ\u000f\u0010N\u001a\u00020\u001dH\u0000¢\u0006\u0004\bN\u0010\u001fJ/\u0010R\u001a\u00020\u001d2\n\u0010A\u001a\u00060Oj\u0002`P2\n\b\u0002\u0010(\u001a\u0004\u0018\u00010'2\b\b\u0002\u0010Q\u001a\u00020\u0014¢\u0006\u0004\bR\u0010SR\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bC\u0010TR\u001a\u0010\t\u001a\u00020\b8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b=\u0010U\u001a\u0004\bV\u0010WR\u0014\u0010\u000b\u001a\u00020\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b>\u0010XR\u0014\u0010\r\u001a\u00020\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bG\u0010YR\u0018\u0010\u000f\u001a\u0004\u0018\u00010\u000e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bA\u0010ZR\u0016\u0010\u0010\u001a\u00020\f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bE\u0010YR\u0014\u0010\u0011\u001a\u00020\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b:\u0010YR\u0014\u0010\\\u001a\u00020-8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b7\u0010[R$\u0010d\u001a\u0004\u0018\u00010]8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b^\u0010_\u001a\u0004\b`\u0010a\"\u0004\bb\u0010cR\u0018\u0010h\u001a\u0004\u0018\u00010e8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bf\u0010gR\u0018\u0010l\u001a\u0004\u0018\u00010i8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bj\u0010kR\u0018\u0010p\u001a\u0004\u0018\u00010m8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bn\u0010oR\u0016\u0010t\u001a\u00020q8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\br\u0010sR\u0018\u0010.\u001a\u0004\u0018\u00010-8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bu\u0010[R\u0018\u00100\u001a\u0004\u0018\u00010/8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bv\u0010wR\u001a\u0010{\u001a\b\u0012\u0004\u0012\u00020\u00170x8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\by\u0010zR\u001a\u0010}\u001a\b\u0012\u0004\u0012\u00020|0x8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\"\u0010zR\u0016\u0010~\u001a\u00020\f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b+\u0010YR\u0017\u0010\u0080\u0001\u001a\u00020\u00148\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bJ\u0010\u007fR\u0018\u0010\u0082\u0001\u001a\u00020\u00198\u0002@\u0002X\u0082\u000e¢\u0006\u0007\n\u0005\b%\u0010\u0081\u0001R\u0019\u0010\u0083\u0001\u001a\u0004\u0018\u00010-8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bR\u0010[R\u0018\u0010\u0085\u0001\u001a\u00020\u00148\u0002@\u0002X\u0082\u000e¢\u0006\u0007\n\u0005\b\u0084\u0001\u0010\u007fR\u0019\u0010\u0087\u0001\u001a\u00020\u00198\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0086\u0001\u0010\u0081\u0001R\u0018\u0010\u0088\u0001\u001a\u00020\u00198\u0002@\u0002X\u0082\u000e¢\u0006\u0007\n\u0005\b5\u0010\u0081\u0001R\u0019\u0010\u008a\u0001\u001a\u00020\u00198\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0089\u0001\u0010\u0081\u0001R\u0017\u0010\u008b\u0001\u001a\u00020\u00148\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b1\u0010\u007f¨\u0006\u0092\u0001"}, d2 = {"Lokhttp3/internal/ws/RealWebSocket;", "Lokhttp3/WebSocket;", "Lokhttp3/internal/ws/WebSocketReader$FrameCallback;", "Lokhttp3/internal/concurrent/Lockable;", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", "Lokhttp3/Request;", "originalRequest", "Lokhttp3/WebSocketListener;", "listener", "Ljava/util/Random;", "random", StringUtils.EMPTY, "pingIntervalMillis", "Lokhttp3/internal/ws/WebSocketExtensions;", "extensions", "minimumDeflateSize", "webSocketCloseTimeout", "<init>", "(Lokhttp3/internal/concurrent/TaskRunner;Lokhttp3/Request;Lokhttp3/WebSocketListener;Ljava/util/Random;JLokhttp3/internal/ws/WebSocketExtensions;JJ)V", StringUtils.EMPTY, "B", "(Lokhttp3/internal/ws/WebSocketExtensions;)Z", "Lokio/ByteString;", "data", StringUtils.EMPTY, "formatOpcode", "E", "(Lokio/ByteString;I)Z", StringUtils.EMPTY, "D", "()V", "request", "()Lokhttp3/Request;", "q", "Lokhttp3/OkHttpClient;", "client", "t", "(Lokhttp3/OkHttpClient;)V", "Lokhttp3/Response;", "response", "Lokhttp3/internal/connection/Exchange;", "exchange", "r", "(Lokhttp3/Response;Lokhttp3/internal/connection/Exchange;)V", StringUtils.EMPTY, "name", "Lokhttp3/internal/ws/RealWebSocket$Streams;", "streams", "z", "(Ljava/lang/String;Lokhttp3/internal/ws/RealWebSocket$Streams;)V", "C", "(Lokhttp3/Response;)V", "x", "text", "h", "(Ljava/lang/String;)V", "bytes", "g", "(Lokio/ByteString;)V", "payload", "b", "c", "code", "reason", "e", "(ILjava/lang/String;)V", "a", "(Ljava/lang/String;)Z", "f", "(Lokio/ByteString;)Z", "d", "(ILjava/lang/String;)Z", "cancelAfterCloseMillis", "s", "(ILjava/lang/String;J)Z", "G", "()Z", "H", "Ljava/lang/Exception;", "Lkotlin/Exception;", "isWriter", "u", "(Ljava/lang/Exception;Lokhttp3/Response;Z)V", "Lokhttp3/Request;", "Lokhttp3/WebSocketListener;", "getListener$okhttp", "()Lokhttp3/WebSocketListener;", "Ljava/util/Random;", "J", "Lokhttp3/internal/ws/WebSocketExtensions;", "Ljava/lang/String;", ExternalParsersConfigReaderMetKeys.METADATA_KEY_ATTR, "Lokhttp3/Call;", "i", "Lokhttp3/Call;", "getCall$okhttp", "()Lokhttp3/Call;", "setCall$okhttp", "(Lokhttp3/Call;)V", "call", "Lokhttp3/internal/concurrent/Task;", "j", "Lokhttp3/internal/concurrent/Task;", "writerTask", "Lokhttp3/internal/ws/WebSocketReader;", "k", "Lokhttp3/internal/ws/WebSocketReader;", "reader", "Lokhttp3/internal/ws/WebSocketWriter;", "l", "Lokhttp3/internal/ws/WebSocketWriter;", "writer", "Lokhttp3/internal/concurrent/TaskQueue;", "m", "Lokhttp3/internal/concurrent/TaskQueue;", "taskQueue", "n", "o", "Lokhttp3/internal/ws/RealWebSocket$Streams;", "Ljava/util/ArrayDeque;", "p", "Ljava/util/ArrayDeque;", "pongQueue", StringUtils.EMPTY, "messageAndCloseQueue", "queueSize", "Z", "enqueuedClose", "I", "receivedCloseCode", "receivedCloseReason", "v", "failed", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "sentPingCount", "receivedPingCount", "y", "receivedPongCount", "awaitingPong", "A", "Message", "Close", "Streams", "WriterTask", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nRealWebSocket.kt\nKotlin\n*S Kotlin\n*F\n+ 1 RealWebSocket.kt\nokhttp3/internal/ws/RealWebSocket\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n*L\n1#1,727:1\n1#2:728\n55#3,4:729\n*S KotlinDebug\n*F\n+ 1 RealWebSocket.kt\nokhttp3/internal/ws/RealWebSocket\n*L\n501#1:729,4\n*E\n"})
public final class RealWebSocket implements WebSocket, WebSocketReader.FrameCallback, Lockable {
    public static final Companion A = new Companion(null);
    private static final List B = CollectionsKt.listOf(Protocol.d);
    private final Request a;
    private final WebSocketListener b;
    private final Random c;
    private final long d;
    private WebSocketExtensions e;
    private long f;
    private final long g;
    private final String h;
    private Call i;
    private Task j;
    private WebSocketReader k;
    private WebSocketWriter l;
    private TaskQueue m;
    private String n;
    private Streams o;
    private final ArrayDeque p;
    private final ArrayDeque q;
    private long r;
    private boolean s;
    private int t;
    private String u;
    private boolean v;
    private int w;
    private int x;
    private int y;
    private boolean z;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\r\b\u0000\u0018\u00002\u00020\u0001B!\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\b\u0010\u0005\u001a\u0004\u0018\u00010\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tR\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\n\u0010\u000b\u001a\u0004\b\f\u0010\rR\u0019\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0006¢\u0006\f\n\u0004\b\f\u0010\u000e\u001a\u0004\b\u000f\u0010\u0010R\u0017\u0010\u0007\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\b\u000f\u0010\u0011\u001a\u0004\b\n\u0010\u0012¨\u0006\u0013"}, d2 = {"Lokhttp3/internal/ws/RealWebSocket$Close;", StringUtils.EMPTY, StringUtils.EMPTY, "code", "Lokio/ByteString;", "reason", StringUtils.EMPTY, "cancelAfterCloseMillis", "<init>", "(ILokio/ByteString;J)V", "a", "I", "b", "()I", "Lokio/ByteString;", "c", "()Lokio/ByteString;", "J", "()J", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Close {
        private final int a;
        private final ByteString b;
        private final long c;

        public Close(int i, ByteString byteString, long j) {
            this.a = i;
            this.b = byteString;
            this.c = j;
        }

        public final long a() {
            return this.c;
        }

        public final int b() {
            return this.a;
        }

        public final ByteString c() {
            return this.b;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0014\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005X\u0082\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\bX\u0086T¢\u0006\u0002\n\u0000¨\u0006\u000b"}, d2 = {"Lokhttp3/internal/ws/RealWebSocket$Companion;", StringUtils.EMPTY, "<init>", "()V", "ONLY_HTTP1", StringUtils.EMPTY, "Lokhttp3/Protocol;", "MAX_QUEUE_SIZE", StringUtils.EMPTY, "CANCEL_AFTER_CLOSE_MILLIS", "DEFAULT_MINIMUM_DEFLATE_SIZE", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\b\u0000\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\n\u0010\u000bR\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\n\u0010\f\u001a\u0004\b\b\u0010\r¨\u0006\u000e"}, d2 = {"Lokhttp3/internal/ws/RealWebSocket$Message;", StringUtils.EMPTY, StringUtils.EMPTY, "formatOpcode", "Lokio/ByteString;", "data", "<init>", "(ILokio/ByteString;)V", "a", "I", "b", "()I", "Lokio/ByteString;", "()Lokio/ByteString;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Message {
        private final int a;
        private final ByteString b;

        public Message(int i, ByteString byteString) {
            Intrinsics.checkNotNullParameter(byteString, ap.a(54538688));
            this.a = i;
            this.b = byteString;
        }

        public final ByteString a() {
            return this.b;
        }

        public final int b() {
            return this.a;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u000f\b&\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\u000b\u001a\u00020\nH&¢\u0006\u0004\b\u000b\u0010\fR\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\r\u0010\u000e\u001a\u0004\b\u000f\u0010\u0010R\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\u0011\u0010\u0012\u001a\u0004\b\u0013\u0010\u0014R\u0017\u0010\u0007\u001a\u00020\u00068\u0006¢\u0006\f\n\u0004\b\u0015\u0010\u0016\u001a\u0004\b\u0017\u0010\u0018¨\u0006\u0019"}, d2 = {"Lokhttp3/internal/ws/RealWebSocket$Streams;", "Ljava/io/Closeable;", StringUtils.EMPTY, "client", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "Lokio/BufferedSink;", "sink", "<init>", "(ZLokio/BufferedSource;Lokio/BufferedSink;)V", StringUtils.EMPTY, "j", "()V", "a", "Z", "k", "()Z", "b", "Lokio/BufferedSource;", "q", "()Lokio/BufferedSource;", "c", "Lokio/BufferedSink;", "o", "()Lokio/BufferedSink;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static abstract class Streams implements Closeable {
        private final boolean a;
        private final BufferedSource b;
        private final BufferedSink c;

        public Streams(boolean z, BufferedSource bufferedSource, BufferedSink bufferedSink) {
            Intrinsics.checkNotNullParameter(bufferedSource, ap.a(408163817));
            Intrinsics.checkNotNullParameter(bufferedSink, ap.a(1036033370));
            this.a = z;
            this.b = bufferedSource;
            this.c = bufferedSink;
        }

        public abstract void j();

        public final boolean k() {
            return this.a;
        }

        public final BufferedSink o() {
            return this.c;
        }

        public final BufferedSource q() {
            return this.b;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0003\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lokhttp3/internal/ws/RealWebSocket$WriterTask;", "Lokhttp3/internal/concurrent/Task;", "<init>", "(Lokhttp3/internal/ws/RealWebSocket;)V", StringUtils.EMPTY, "f", "()J", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private final class WriterTask extends Task {
        public WriterTask() {
            super(RealWebSocket.this.n + ap.a(69244557), false, 2, null);
        }

        @Override // okhttp3.internal.concurrent.Task
        public long f() {
            try {
                return RealWebSocket.this.G() ? 0L : -1L;
            } catch (IOException e) {
                RealWebSocket.v(RealWebSocket.this, e, null, true, 2, null);
                return -1L;
            }
        }
    }

    public RealWebSocket(TaskRunner taskRunner, Request request, WebSocketListener webSocketListener, Random random, long j, WebSocketExtensions webSocketExtensions, long j2, long j3) {
        Intrinsics.checkNotNullParameter(taskRunner, ap.a(73986964));
        Intrinsics.checkNotNullParameter(request, ap.a(258859289));
        Intrinsics.checkNotNullParameter(webSocketListener, ap.a(1753481876));
        Intrinsics.checkNotNullParameter(random, ap.a(1809281041));
        this.a = request;
        this.b = webSocketListener;
        this.c = random;
        this.d = j;
        this.e = webSocketExtensions;
        this.f = j2;
        this.g = j3;
        this.m = taskRunner.k();
        this.p = new ArrayDeque();
        this.q = new ArrayDeque();
        this.t = -1;
        if (!Intrinsics.areEqual(ap.a(1835349899), request.i())) {
            throw new IllegalArgumentException((ap.a(1900519908) + request.i()).toString());
        }
        ByteString.Companion companion = ByteString.d;
        byte[] bArr = new byte[16];
        random.nextBytes(bArr);
        Unit unit = Unit.INSTANCE;
        this.h = ByteString.Companion.g(companion, bArr, 0, 0, 3, null).a();
    }

    private static final long A(RealWebSocket realWebSocket, long j) {
        realWebSocket.H();
        return j;
    }

    private final boolean B(WebSocketExtensions webSocketExtensions) {
        if (!webSocketExtensions.f && webSocketExtensions.b == null) {
            return webSocketExtensions.d == null || new IntRange(8, 15).contains(webSocketExtensions.d.intValue());
        }
        return false;
    }

    private final void D() {
        if (!_UtilJvmKt.b || Thread.holdsLock(this)) {
            Task task = this.j;
            if (task != null) {
                TaskQueue.m(this.m, task, 0L, 2, null);
                return;
            }
            return;
        }
        throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
    }

    private final synchronized boolean E(ByteString byteString, int i) {
        if (!this.v && !this.s) {
            if (this.r + ((long) byteString.size()) > 16777216) {
                d(1001, null);
                return false;
            }
            this.r += (long) byteString.size();
            this.q.add(new Message(i, byteString));
            D();
            return true;
        }
        return false;
    }

    private static final Unit F(RealWebSocket realWebSocket) {
        realWebSocket.q();
        return Unit.INSTANCE;
    }

    public static /* synthetic */ void v(RealWebSocket realWebSocket, Exception exc, Response response, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            response = null;
        }
        if ((i & 4) != 0) {
            z = false;
        }
        realWebSocket.u(exc, response, z);
    }

    private static final Unit w(Ref.ObjectRef objectRef, Ref.ObjectRef objectRef2) {
        _UtilCommonKt.f((Closeable) objectRef.element);
        Streams streams = (Streams) objectRef2.element;
        if (streams != null) {
            _UtilCommonKt.f(streams);
        }
        return Unit.INSTANCE;
    }

    private static final Unit y(WebSocketWriter webSocketWriter) {
        _UtilCommonKt.f(webSocketWriter);
        return Unit.INSTANCE;
    }

    public final void C(Response response) throws Throwable {
        Throwable th;
        RealWebSocket realWebSocket;
        Intrinsics.checkNotNullParameter(response, "response");
        try {
            this.b.onOpen(this, response);
            while (this.t == -1) {
                WebSocketReader webSocketReader = this.k;
                Intrinsics.checkNotNull(webSocketReader);
                webSocketReader.j();
            }
            x();
        } catch (Exception e) {
            realWebSocket = this;
            try {
                v(realWebSocket, e, null, false, 6, null);
                realWebSocket.x();
            } catch (Throwable th2) {
                th = th2;
                realWebSocket.x();
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            realWebSocket = this;
            realWebSocket.x();
            throw th;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0088 A[Catch: all -> 0x0091, TRY_ENTER, TryCatch #0 {all -> 0x0091, blocks: (B:34:0x0088, B:37:0x0093, B:39:0x0097, B:40:0x00a7, B:42:0x00b6, B:45:0x00b9, B:46:0x00ba, B:47:0x00bb, B:49:0x00bf, B:51:0x00d1, B:58:0x00e5, B:59:0x00ea, B:41:0x00a8), top: B:67:0x0086, inners: #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0093 A[Catch: all -> 0x0091, TryCatch #0 {all -> 0x0091, blocks: (B:34:0x0088, B:37:0x0093, B:39:0x0097, B:40:0x00a7, B:42:0x00b6, B:45:0x00b9, B:46:0x00ba, B:47:0x00bb, B:49:0x00bf, B:51:0x00d1, B:58:0x00e5, B:59:0x00ea, B:41:0x00a8), top: B:67:0x0086, inners: #2 }] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00db  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x00e1  */
    /* JADX WARN: Type inference failed for: r2v3, types: [java.io.Closeable] */
    /* JADX WARN: Type inference failed for: r2v6 */
    /* JADX WARN: Type inference failed for: r2v7 */
    /* JADX WARN: Type inference failed for: r2v8 */
    /* JADX WARN: Type inference failed for: r5v1 */
    /* JADX WARN: Type inference failed for: r5v2, types: [java.io.Closeable] */
    /* JADX WARN: Type inference failed for: r5v7 */
    /* JADX WARN: Type inference failed for: r5v9 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean G() {
        /*
            Method dump skipped, instruction units count: 248
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.ws.RealWebSocket.G():boolean");
    }

    public final void H() {
        synchronized (this) {
            try {
                if (this.v) {
                    return;
                }
                WebSocketWriter webSocketWriter = this.l;
                if (webSocketWriter == null) {
                    return;
                }
                int i = this.z ? this.w : -1;
                this.w++;
                this.z = true;
                Unit unit = Unit.INSTANCE;
                if (i == -1) {
                    try {
                        webSocketWriter.g(ByteString.e);
                        return;
                    } catch (IOException e) {
                        v(this, e, null, true, 2, null);
                        return;
                    }
                }
                v(this, new SocketTimeoutException("sent ping but didn't receive pong within " + this.d + "ms (after " + (i - 1) + " successful ping/pongs)"), null, true, 2, null);
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // okhttp3.WebSocket
    public boolean a(String str) {
        Intrinsics.checkNotNullParameter(str, "text");
        return E(ByteString.d.d(str), 1);
    }

    @Override // okhttp3.internal.ws.WebSocketReader.FrameCallback
    public synchronized void b(ByteString byteString) {
        try {
            Intrinsics.checkNotNullParameter(byteString, "payload");
            if (!this.v && (!this.s || !this.q.isEmpty())) {
                this.p.add(byteString);
                D();
                this.x++;
            }
        } finally {
        }
    }

    @Override // okhttp3.internal.ws.WebSocketReader.FrameCallback
    public synchronized void c(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "payload");
        this.y++;
        this.z = false;
    }

    @Override // okhttp3.WebSocket
    public boolean d(int i, String str) {
        return s(i, str, this.g);
    }

    @Override // okhttp3.internal.ws.WebSocketReader.FrameCallback
    public void e(int i, String str) {
        Intrinsics.checkNotNullParameter(str, "reason");
        if (i == -1) {
            throw new IllegalArgumentException("Failed requirement.");
        }
        synchronized (this) {
            if (this.t != -1) {
                throw new IllegalStateException("already closed");
            }
            this.t = i;
            this.u = str;
            Unit unit = Unit.INSTANCE;
        }
        this.b.onClosing(this, i, str);
    }

    @Override // okhttp3.WebSocket
    public boolean f(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "bytes");
        return E(byteString, 2);
    }

    @Override // okhttp3.internal.ws.WebSocketReader.FrameCallback
    public void g(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "bytes");
        this.b.onMessage(this, byteString);
    }

    @Override // okhttp3.internal.ws.WebSocketReader.FrameCallback
    public void h(String str) {
        Intrinsics.checkNotNullParameter(str, "text");
        this.b.onMessage(this, str);
    }

    public void q() {
        Call call = this.i;
        Intrinsics.checkNotNull(call);
        call.cancel();
    }

    public final void r(Response response, Exchange exchange) throws ProtocolException {
        Intrinsics.checkNotNullParameter(response, "response");
        if (response.r() != 101) {
            throw new ProtocolException("Expected HTTP 101 response but was '" + response.r() + ' ' + response.O() + '\'');
        }
        String strD = Response.D(response, "Connection", null, 2, null);
        if (!StringsKt.equals("Upgrade", strD, true)) {
            throw new ProtocolException("Expected 'Connection' header value 'Upgrade' but was '" + strD + '\'');
        }
        String strD2 = Response.D(response, "Upgrade", null, 2, null);
        if (!StringsKt.equals("websocket", strD2, true)) {
            throw new ProtocolException("Expected 'Upgrade' header value 'websocket' but was '" + strD2 + '\'');
        }
        String strD3 = Response.D(response, "Sec-WebSocket-Accept", null, 2, null);
        String strA = ByteString.d.d(this.h + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").C().a();
        if (Intrinsics.areEqual(strA, strD3)) {
            if (exchange == null) {
                throw new ProtocolException("Web Socket exchange missing: bad interceptor?");
            }
            return;
        }
        throw new ProtocolException("Expected 'Sec-WebSocket-Accept' header value '" + strA + "' but was '" + strD3 + '\'');
    }

    @Override // okhttp3.WebSocket
    public Request request() {
        return this.a;
    }

    public final synchronized boolean s(int i, String str, long j) {
        ByteString byteStringD;
        try {
            WebSocketProtocol.a.c(i);
            if (str != null) {
                byteStringD = ByteString.d.d(str);
                if (byteStringD.size() > 123) {
                    throw new IllegalArgumentException(("reason.size() > 123: " + str).toString());
                }
            } else {
                byteStringD = null;
            }
            if (!this.v && !this.s) {
                this.s = true;
                this.q.add(new Close(i, byteStringD, j));
                D();
                return true;
            }
            return false;
        } finally {
        }
    }

    public final void t(OkHttpClient okHttpClient) {
        Intrinsics.checkNotNullParameter(okHttpClient, "client");
        if (this.a.e("Sec-WebSocket-Extensions") != null) {
            v(this, new ProtocolException("Request header not permitted: 'Sec-WebSocket-Extensions'"), null, false, 6, null);
            return;
        }
        OkHttpClient okHttpClientB = okHttpClient.B().h(EventListener.b).U(B).b();
        final Request requestB = this.a.j().n("Upgrade", "websocket").n("Connection", "Upgrade").n("Sec-WebSocket-Key", this.h).n("Sec-WebSocket-Version", "13").n("Sec-WebSocket-Extensions", "permessage-deflate").b();
        RealCall realCall = new RealCall(okHttpClientB, requestB, true);
        this.i = realCall;
        Intrinsics.checkNotNull(realCall);
        realCall.G2(new Callback() { // from class: okhttp3.internal.ws.RealWebSocket$connect$1
            @Override // okhttp3.Callback
            public void onFailure(Call call, IOException iOException) {
                Intrinsics.checkNotNullParameter(call, ap.a(733732164));
                Intrinsics.checkNotNullParameter(iOException, ap.a(189054056));
                RealWebSocket.v(this.a, iOException, null, false, 6, null);
            }

            @Override // okhttp3.Callback
            public void onResponse(Call call, Response response) throws Throwable {
                Intrinsics.checkNotNullParameter(call, "call");
                Intrinsics.checkNotNullParameter(response, "response");
                Exchange exchangeU = response.u();
                try {
                    this.a.r(response, exchangeU);
                    Intrinsics.checkNotNull(exchangeU);
                    RealWebSocket.Streams streamsP = exchangeU.p();
                    WebSocketExtensions webSocketExtensionsA = WebSocketExtensions.g.a(response.J());
                    this.a.e = webSocketExtensionsA;
                    if (!this.a.B(webSocketExtensionsA)) {
                        RealWebSocket realWebSocket = this.a;
                        synchronized (realWebSocket) {
                            realWebSocket.q.clear();
                            realWebSocket.d(1010, "unexpected Sec-WebSocket-Extensions in response header");
                        }
                    }
                    this.a.z(_UtilJvmKt.c + " WebSocket " + requestB.m().q(), streamsP);
                    this.a.C(response);
                } catch (IOException e) {
                    RealWebSocket.v(this.a, e, response, false, 4, null);
                    _UtilCommonKt.f(response);
                    if (exchangeU != null) {
                        exchangeU.x();
                    }
                }
            }
        });
    }

    public final void u(Exception exc, Response response, boolean z) {
        Intrinsics.checkNotNullParameter(exc, "e");
        final Ref.ObjectRef objectRef = new Ref.ObjectRef();
        final Ref.ObjectRef objectRef2 = new Ref.ObjectRef();
        synchronized (this) {
            try {
                if (this.v) {
                    return;
                }
                this.v = true;
                Streams streams = this.o;
                WebSocketWriter webSocketWriter = this.l;
                objectRef2.element = webSocketWriter;
                Streams streams2 = null;
                this.l = null;
                if (webSocketWriter != null && this.k == null) {
                    streams2 = streams;
                }
                objectRef.element = streams2;
                if (!z && objectRef2.element != null) {
                    TaskQueue.d(this.m, this.n + " writer close", 0L, false, new Function0() { // from class: okhttp3.internal.ws.c
                        public final Object invoke() {
                            return RealWebSocket.w(objectRef2, objectRef);
                        }
                    }, 2, null);
                }
                this.m.q();
                Unit unit = Unit.INSTANCE;
                try {
                    this.b.onFailure(this, exc, response);
                    if (streams != null) {
                        streams.j();
                    }
                    if (z) {
                        WebSocketWriter webSocketWriter2 = (WebSocketWriter) objectRef2.element;
                        if (webSocketWriter2 != null) {
                            _UtilCommonKt.f(webSocketWriter2);
                        }
                        Streams streams3 = (Streams) objectRef.element;
                        if (streams3 != null) {
                            _UtilCommonKt.f(streams3);
                        }
                    }
                } finally {
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void x() {
        boolean z;
        int i;
        String str;
        WebSocketReader webSocketReader;
        Streams streams;
        synchronized (this) {
            try {
                z = this.v;
                i = this.t;
                str = this.u;
                webSocketReader = this.k;
                this.k = null;
                if (this.s && this.q.isEmpty()) {
                    final WebSocketWriter webSocketWriter = this.l;
                    if (webSocketWriter != null) {
                        this.l = null;
                        TaskQueue.d(this.m, this.n + " writer close", 0L, false, new Function0() { // from class: okhttp3.internal.ws.b
                            public final Object invoke() {
                                return RealWebSocket.y(webSocketWriter);
                            }
                        }, 2, null);
                    }
                    this.m.q();
                }
                streams = this.l == null ? this.o : null;
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
        if (!z && streams != null && this.t != -1) {
            WebSocketListener webSocketListener = this.b;
            Intrinsics.checkNotNull(str);
            webSocketListener.onClosed(this, i, str);
        }
        if (webSocketReader != null) {
            _UtilCommonKt.f(webSocketReader);
        }
        if (streams != null) {
            _UtilCommonKt.f(streams);
        }
    }

    public final void z(String str, Streams streams) throws Throwable {
        RealWebSocket realWebSocket;
        Throwable th;
        Intrinsics.checkNotNullParameter(str, "name");
        Intrinsics.checkNotNullParameter(streams, "streams");
        WebSocketExtensions webSocketExtensions = this.e;
        Intrinsics.checkNotNull(webSocketExtensions);
        synchronized (this) {
            try {
                this.n = str;
                this.o = streams;
                this.l = new WebSocketWriter(streams.k(), streams.o(), this.c, webSocketExtensions.a, webSocketExtensions.a(streams.k()), this.f);
                this.j = new WriterTask();
                long j = this.d;
                if (j != 0) {
                    try {
                        final long nanos = TimeUnit.MILLISECONDS.toNanos(j);
                        this.m.k(str + " ping", nanos, new Function0() { // from class: okhttp3.internal.ws.d
                            public final Object invoke() {
                                return Long.valueOf(RealWebSocket.A(this.a, nanos));
                            }
                        });
                    } catch (Throwable th2) {
                        th = th2;
                        realWebSocket = this;
                        throw th;
                    }
                }
                if (!this.q.isEmpty()) {
                    D();
                }
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th3) {
                realWebSocket = this;
                th = th3;
            }
        }
        this.k = new WebSocketReader(streams.k(), streams.q(), this, webSocketExtensions.a, webSocketExtensions.a(!streams.k()));
    }
}