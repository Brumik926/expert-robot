package okhttp3.internal;

import h.ap;
import java.nio.charset.Charset;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.jvm.JvmName;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.Charsets;
import okhttp3.CipherSuite;
import okhttp3.ConnectionSpec;
import okhttp3.MediaType;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u001a'\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001*\u00020\u00002\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00020\u00020\u0001H\u0000¢\u0006\u0004\b\u0004\u0010\u0005\u001a#\u0010\t\u001a\u0010\u0012\u0004\u0012\u00020\b\u0012\u0006\u0012\u0004\u0018\u00010\u00060\u0007*\u0004\u0018\u00010\u0006H\u0000¢\u0006\u0004\b\t\u0010\n\u001a\u0015\u0010\u000b\u001a\u00020\b*\u0004\u0018\u00010\u0006H\u0000¢\u0006\u0004\b\u000b\u0010\f¨\u0006\r"}, d2 = {"Lokhttp3/ConnectionSpec;", StringUtils.EMPTY, StringUtils.EMPTY, "socketEnabledCipherSuites", "c", "(Lokhttp3/ConnectionSpec;[Ljava/lang/String;)[Ljava/lang/String;", "Lokhttp3/MediaType;", "Lkotlin/Pair;", "Ljava/nio/charset/Charset;", "b", "(Lokhttp3/MediaType;)Lkotlin/Pair;", "a", "(Lokhttp3/MediaType;)Ljava/nio/charset/Charset;", "okhttp"}, k = 2, mv = {2, 2, 0}, xi = 48)
@JvmName(name = "Internal")
public final class Internal {
    public static final Charset a(MediaType mediaType) {
        Charset charsetD;
        return (mediaType == null || (charsetD = MediaType.d(mediaType, null, 1, null)) == null) ? Charsets.UTF_8 : charsetD;
    }

    public static final Pair b(MediaType mediaType) {
        Charset charset = Charsets.UTF_8;
        if (mediaType != null) {
            Charset charsetD = MediaType.d(mediaType, null, 1, null);
            if (charsetD == null) {
                mediaType = MediaType.e.b(mediaType + ap.a(1707352249));
            } else {
                charset = charsetD;
            }
        }
        return TuplesKt.to(charset, mediaType);
    }

    public static final String[] c(ConnectionSpec connectionSpec, String[] strArr) {
        Intrinsics.checkNotNullParameter(connectionSpec, "<this>");
        Intrinsics.checkNotNullParameter(strArr, "socketEnabledCipherSuites");
        return connectionSpec.d() != null ? _UtilCommonKt.w(connectionSpec.d(), strArr, CipherSuite.b.c()) : strArr;
    }
}