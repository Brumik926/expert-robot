package okhttp3.internal.platform.android;

import android.util.Log;
import h.ap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.logging.Level;
import java.util.logging.Logger;
import kotlin.Metadata;
import kotlin.collections.MapsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.OkHttpClient;
import okhttp3.internal.SuppressSignatureCheck;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.http2.Http2;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@SuppressSignatureCheck
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\b\u0003\bÇ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0006\u0010\u0007J\u001f\u0010\u000b\u001a\u00020\n2\u0006\u0010\b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u000b\u0010\fJ3\u0010\u0012\u001a\u00020\n2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u000f\u001a\u00020\u00042\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u0010H\u0000¢\u0006\u0004\b\u0012\u0010\u0013J\r\u0010\u0014\u001a\u00020\n¢\u0006\u0004\b\u0014\u0010\u0003R\u001a\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00160\u00158\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0014\u0010\u0017R \u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\u0004\u0012\u0004\u0012\u00020\u00040\u00198\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000b\u0010\u001a¨\u0006\u001c"}, d2 = {"Lokhttp3/internal/platform/android/AndroidLog;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "loggerName", "d", "(Ljava/lang/String;)Ljava/lang/String;", "logger", "tag", StringUtils.EMPTY, "c", "(Ljava/lang/String;Ljava/lang/String;)V", StringUtils.EMPTY, "logLevel", "message", StringUtils.EMPTY, "t", "a", "(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Throwable;)V", "b", "Ljava/util/concurrent/CopyOnWriteArraySet;", "Ljava/util/logging/Logger;", "Ljava/util/concurrent/CopyOnWriteArraySet;", "configuredLoggers", StringUtils.EMPTY, "Ljava/util/Map;", "knownLoggers", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class AndroidLog {
    public static final AndroidLog a = new AndroidLog();
    private static final CopyOnWriteArraySet b = new CopyOnWriteArraySet();
    private static final Map c;

    static {
        LinkedHashMap linkedHashMap = new LinkedHashMap();
        Package r2 = OkHttpClient.class.getPackage();
        String name = r2 != null ? r2.getName() : null;
        if (name != null) {
            linkedHashMap.put(name, ap.a(676959622));
        }
        linkedHashMap.put(OkHttpClient.class.getName(), ap.a(4253645));
        linkedHashMap.put(Http2.class.getName(), ap.a(216529502));
        linkedHashMap.put(TaskRunner.class.getName(), ap.a(1273522277));
        linkedHashMap.put(ap.a(207362928), ap.a(994118777));
        c = MapsKt.toMap(linkedHashMap);
    }

    private AndroidLog() {
    }

    private final void c(String str, String str2) {
        Logger logger = Logger.getLogger(str);
        if (b.add(logger)) {
            logger.setUseParentHandlers(false);
            logger.setLevel(Log.isLoggable(str2, 3) ? Level.FINE : Log.isLoggable(str2, 4) ? Level.INFO : Level.WARNING);
            logger.addHandler(AndroidLogHandler.a);
        }
    }

    private final String d(String str) {
        String str2 = (String) c.get(str);
        return str2 == null ? StringsKt.take(str, 23) : str2;
    }

    public final void a(String str, int i, String str2, Throwable th) {
        int iMin;
        Intrinsics.checkNotNullParameter(str, "loggerName");
        Intrinsics.checkNotNullParameter(str2, "message");
        String strD = d(str);
        if (Log.isLoggable(strD, i)) {
            if (th != null) {
                str2 = str2 + '\n' + Log.getStackTraceString(th);
            }
            String str3 = str2;
            int length = str3.length();
            int i2 = 0;
            while (i2 < length) {
                int iIndexOf$default = StringsKt.indexOf$default((CharSequence) str3, '\n', i2, false, 4, (Object) null);
                if (iIndexOf$default == -1) {
                    iIndexOf$default = length;
                }
                while (true) {
                    iMin = Math.min(iIndexOf$default, i2 + 4000);
                    String strSubstring = str3.substring(i2, iMin);
                    Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                    Log.println(i, strD, strSubstring);
                    if (iMin >= iIndexOf$default) {
                        break;
                    } else {
                        i2 = iMin;
                    }
                }
                i2 = iMin + 1;
            }
        }
    }

    public final void b() {
        try {
            for (Map.Entry entry : c.entrySet()) {
                c((String) entry.getKey(), (String) entry.getValue());
            }
        } catch (RuntimeException e) {
            e.printStackTrace();
        }
    }
}