package okhttp3.internal.platform;

import android.content.Context;
import kotlin.Metadata;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\bf\u0018\u00002\u00020\u0001R\u001e\u0010\u0007\u001a\u0004\u0018\u00010\u00028&@&X¦\u000e¢\u0006\f\u001a\u0004\b\u0003\u0010\u0004\"\u0004\b\u0005\u0010\u0006¨\u0006\bÀ\u0006\u0003"}, d2 = {"Lokhttp3/internal/platform/ContextAwarePlatform;", StringUtils.EMPTY, "Landroid/content/Context;", "b", "()Landroid/content/Context;", "a", "(Landroid/content/Context;)V", "applicationContext", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public interface ContextAwarePlatform {
    void a(Context context);

    Context b();
}