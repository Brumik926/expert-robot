package okhttp3.internal.platform;

import android.content.Context;
import android.os.Build;
import h.ap;
import kotlin.Metadata;
import okhttp3.internal.platform.android.AndroidLog;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\r\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0005\u0010\u0006R\u0011\u0010\n\u001a\u00020\u00078F¢\u0006\u0006\u001a\u0004\b\b\u0010\tR(\u0010\u0011\u001a\u0004\u0018\u00010\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\u000b8F@FX\u0086\u000e¢\u0006\f\u001a\u0004\b\r\u0010\u000e\"\u0004\b\u000f\u0010\u0010¨\u0006\u0012"}, d2 = {"Lokhttp3/internal/platform/PlatformRegistry;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/internal/platform/Platform;", "a", "()Lokhttp3/internal/platform/Platform;", StringUtils.EMPTY, "c", "()Z", "isAndroid", "Landroid/content/Context;", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "b", "()Landroid/content/Context;", "d", "(Landroid/content/Context;)V", "applicationContext", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class PlatformRegistry {
    public static final PlatformRegistry a = new PlatformRegistry();

    private PlatformRegistry() {
    }

    public final Platform a() {
        AndroidLog.a.b();
        Platform platformA = Android10Platform.f.a();
        if (platformA == null) {
            platformA = AndroidPlatform.f.a();
        }
        if (platformA != null) {
            return platformA;
        }
        throw new IllegalStateException(ap.a(763699063) + Build.VERSION.SDK_INT);
    }

    public final Context b() {
        Object objE = Platform.a.e();
        ContextAwarePlatform contextAwarePlatform = objE instanceof ContextAwarePlatform ? (ContextAwarePlatform) objE : null;
        if (contextAwarePlatform != null) {
            return contextAwarePlatform.b();
        }
        return null;
    }

    public final boolean c() {
        return true;
    }

    public final void d(Context context) {
        Object objE = Platform.a.e();
        ContextAwarePlatform contextAwarePlatform = objE instanceof ContextAwarePlatform ? (ContextAwarePlatform) objE : null;
        if (contextAwarePlatform != null) {
            contextAwarePlatform.a(context);
        }
    }
}