package okhttp3.internal.concurrent;

import h.ap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal._UtilJvmKt;
import org.apache.tika.pipes.PipesConfigBase;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0010\b\n\u0002\b\t\n\u0002\u0010!\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u0000 \u001b2\u00020\u0001:\u0003789B\u0019\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0017\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\bH\u0002¢\u0006\u0004\b\u000b\u0010\fJ'\u0010\u0011\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000e\u001a\u00020\r2\u0006\u0010\u0010\u001a\u00020\u000fH\u0002¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0013\u001a\u00020\nH\u0002¢\u0006\u0004\b\u0013\u0010\u0014J\u0017\u0010\u0017\u001a\u00020\n2\u0006\u0010\u0016\u001a\u00020\u0015H\u0000¢\u0006\u0004\b\u0017\u0010\u0018J\u000f\u0010\u0019\u001a\u0004\u0018\u00010\b¢\u0006\u0004\b\u0019\u0010\u001aJ\r\u0010\u001b\u001a\u00020\u0015¢\u0006\u0004\b\u001b\u0010\u001cJ\r\u0010\u001d\u001a\u00020\n¢\u0006\u0004\b\u001d\u0010\u0014R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u001e\u0010\u001f\u001a\u0004\b \u0010!R\u001a\u0010\u0005\u001a\u00020\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\"\u0010#\u001a\u0004\b$\u0010%R\u0016\u0010)\u001a\u00020&8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b'\u0010(R\u0016\u0010+\u001a\u00020\u000f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0011\u0010*R\u0016\u0010-\u001a\u00020\r8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0019\u0010,R\u0016\u0010.\u001a\u00020&8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u000b\u0010(R\u0016\u0010/\u001a\u00020&8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001d\u0010(R\u001a\u00102\u001a\b\u0012\u0004\u0012\u00020\u0015008\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b \u00101R\u001a\u00103\u001a\b\u0012\u0004\u0012\u00020\u0015008\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b$\u00101R\u0014\u00106\u001a\u0002048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0017\u00105¨\u0006:"}, d2 = {"Lokhttp3/internal/concurrent/TaskRunner;", "Lokhttp3/internal/concurrent/Lockable;", "Lokhttp3/internal/concurrent/TaskRunner$Backend;", "backend", "Ljava/util/logging/Logger;", "logger", "<init>", "(Lokhttp3/internal/concurrent/TaskRunner$Backend;Ljava/util/logging/Logger;)V", "Lokhttp3/internal/concurrent/Task;", "task", StringUtils.EMPTY, "f", "(Lokhttp3/internal/concurrent/Task;)V", StringUtils.EMPTY, "delayNanos", StringUtils.EMPTY, "completedNormally", "d", "(Lokhttp3/internal/concurrent/Task;JZ)V", "l", "()V", "Lokhttp3/internal/concurrent/TaskQueue;", "taskQueue", "j", "(Lokhttp3/internal/concurrent/TaskQueue;)V", "e", "()Lokhttp3/internal/concurrent/Task;", "k", "()Lokhttp3/internal/concurrent/TaskQueue;", "g", "a", "Lokhttp3/internal/concurrent/TaskRunner$Backend;", "h", "()Lokhttp3/internal/concurrent/TaskRunner$Backend;", "b", "Ljava/util/logging/Logger;", "i", "()Ljava/util/logging/Logger;", StringUtils.EMPTY, "c", "I", "nextQueueName", "Z", "coordinatorWaiting", "J", "coordinatorWakeUpAt", "executeCallCount", "runCallCount", StringUtils.EMPTY, "Ljava/util/List;", "busyQueues", "readyQueues", "Ljava/lang/Runnable;", "Ljava/lang/Runnable;", "runnable", "Backend", "RealBackend", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nTaskRunner.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TaskRunner.kt\nokhttp3/internal/concurrent/TaskRunner\n+ 2 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n*L\n1#1,360:1\n55#2,4:361\n55#2,4:365\n55#2,4:369\n55#2,4:373\n55#2,4:377\n63#2:381\n63#2:382\n55#2,4:383\n*S KotlinDebug\n*F\n+ 1 TaskRunner.kt\nokhttp3/internal/concurrent/TaskRunner\n*L\n103#1:361,4\n121#1:365,4\n136#1:369,4\n167#1:373,4\n247#1:377,4\n255#1:381\n264#1:382\n270#1:383,4\n*E\n"})
public final class TaskRunner implements Lockable {
    public static final Companion k;
    private static final Logger l;
    public static final TaskRunner m;
    private final Backend a;
    private final Logger b;
    private int c;
    private boolean d;
    private long e;
    private int f;
    private int g;
    private final List h;
    private final List i;
    private final Runnable j;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\bf\u0018\u00002\u00020\u0001J\u000f\u0010\u0003\u001a\u00020\u0002H&¢\u0006\u0004\b\u0003\u0010\u0004J\u0017\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0005H&¢\u0006\u0004\b\b\u0010\tJ\u001f\u0010\u000b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\u0002H&¢\u0006\u0004\b\u000b\u0010\fJ)\u0010\u0010\u001a\b\u0012\u0004\u0012\u00028\u00000\u000e\"\u0004\b\u0000\u0010\r2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00028\u00000\u000eH&¢\u0006\u0004\b\u0010\u0010\u0011J\u001f\u0010\u0014\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0013\u001a\u00020\u0012H&¢\u0006\u0004\b\u0014\u0010\u0015¨\u0006\u0016À\u0006\u0003"}, d2 = {"Lokhttp3/internal/concurrent/TaskRunner$Backend;", StringUtils.EMPTY, StringUtils.EMPTY, "b", "()J", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", StringUtils.EMPTY, "c", "(Lokhttp3/internal/concurrent/TaskRunner;)V", "nanos", "d", "(Lokhttp3/internal/concurrent/TaskRunner;J)V", "T", "Ljava/util/concurrent/BlockingQueue;", "queue", "e", "(Ljava/util/concurrent/BlockingQueue;)Ljava/util/concurrent/BlockingQueue;", "Ljava/lang/Runnable;", "runnable", "a", "(Lokhttp3/internal/concurrent/TaskRunner;Ljava/lang/Runnable;)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public interface Backend {
        void a(TaskRunner taskRunner, Runnable runnable);

        long b();

        void c(TaskRunner taskRunner);

        void d(TaskRunner taskRunner, long j);

        BlockingQueue e(BlockingQueue blockingQueue);
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0014\u0010\u0005\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0005\u0010\u0006¨\u0006\u0007"}, d2 = {"Lokhttp3/internal/concurrent/TaskRunner$Companion;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/internal/concurrent/TaskRunner;", "INSTANCE", "Lokhttp3/internal/concurrent/TaskRunner;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u0007\u0010\bJ\u0017\u0010\f\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b\f\u0010\rJ\u001f\u0010\u000f\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000e\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u000f\u0010\u0010J)\u0010\u0014\u001a\b\u0012\u0004\u0012\u00028\u00000\u0012\"\u0004\b\u0000\u0010\u00112\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00028\u00000\u0012H\u0016¢\u0006\u0004\b\u0014\u0010\u0015J\u001f\u0010\u0018\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u0017\u001a\u00020\u0016H\u0016¢\u0006\u0004\b\u0018\u0010\u0019R\u0017\u0010\u001e\u001a\u00020\u001a8\u0006¢\u0006\f\n\u0004\b\u0018\u0010\u001b\u001a\u0004\b\u001c\u0010\u001d¨\u0006\u001f"}, d2 = {"Lokhttp3/internal/concurrent/TaskRunner$RealBackend;", "Lokhttp3/internal/concurrent/TaskRunner$Backend;", "Ljava/util/concurrent/ThreadFactory;", "threadFactory", "<init>", "(Ljava/util/concurrent/ThreadFactory;)V", StringUtils.EMPTY, "b", "()J", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", StringUtils.EMPTY, "c", "(Lokhttp3/internal/concurrent/TaskRunner;)V", "nanos", "d", "(Lokhttp3/internal/concurrent/TaskRunner;J)V", "T", "Ljava/util/concurrent/BlockingQueue;", "queue", "e", "(Ljava/util/concurrent/BlockingQueue;)Ljava/util/concurrent/BlockingQueue;", "Ljava/lang/Runnable;", "runnable", "a", "(Lokhttp3/internal/concurrent/TaskRunner;Ljava/lang/Runnable;)V", "Ljava/util/concurrent/ThreadPoolExecutor;", "Ljava/util/concurrent/ThreadPoolExecutor;", "getExecutor", "()Ljava/util/concurrent/ThreadPoolExecutor;", "executor", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nTaskRunner.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TaskRunner.kt\nokhttp3/internal/concurrent/TaskRunner$RealBackend\n+ 2 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n*L\n1#1,360:1\n36#2:361\n55#2,4:362\n41#2,6:366\n*S KotlinDebug\n*F\n+ 1 TaskRunner.kt\nokhttp3/internal/concurrent/TaskRunner$RealBackend\n*L\n320#1:361\n333#1:362,4\n335#1:366,6\n*E\n"})
    public static final class RealBackend implements Backend {
        private final ThreadPoolExecutor a;

        public RealBackend(ThreadFactory threadFactory) {
            Intrinsics.checkNotNullParameter(threadFactory, ap.a(1791844947));
            this.a = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS, new SynchronousQueue(), threadFactory);
        }

        @Override // okhttp3.internal.concurrent.TaskRunner.Backend
        public void a(TaskRunner taskRunner, Runnable runnable) {
            Intrinsics.checkNotNullParameter(taskRunner, "taskRunner");
            Intrinsics.checkNotNullParameter(runnable, "runnable");
            this.a.execute(runnable);
        }

        @Override // okhttp3.internal.concurrent.TaskRunner.Backend
        public long b() {
            return System.nanoTime();
        }

        @Override // okhttp3.internal.concurrent.TaskRunner.Backend
        public void c(TaskRunner taskRunner) {
            Intrinsics.checkNotNullParameter(taskRunner, "taskRunner");
            taskRunner.notify();
        }

        @Override // okhttp3.internal.concurrent.TaskRunner.Backend
        public void d(TaskRunner taskRunner, long j) throws InterruptedException {
            Intrinsics.checkNotNullParameter(taskRunner, "taskRunner");
            if (_UtilJvmKt.b && !Thread.holdsLock(taskRunner)) {
                throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + taskRunner);
            }
            if (j > 0) {
                long j2 = j / 1000000;
                long j3 = j - (1000000 * j2);
                if (j2 > 0 || j > 0) {
                    taskRunner.wait(j2, (int) j3);
                }
            }
        }

        @Override // okhttp3.internal.concurrent.TaskRunner.Backend
        public BlockingQueue e(BlockingQueue blockingQueue) {
            Intrinsics.checkNotNullParameter(blockingQueue, "queue");
            return blockingQueue;
        }
    }

    static {
        DefaultConstructorMarker defaultConstructorMarker = null;
        k = new Companion(defaultConstructorMarker);
        Logger logger = Logger.getLogger(TaskRunner.class.getName());
        Intrinsics.checkNotNullExpressionValue(logger, ap.a(429175723));
        l = logger;
        m = new TaskRunner(new RealBackend(_UtilJvmKt.p(_UtilJvmKt.c + ap.a(1601653317), true)), defaultConstructorMarker, 2, defaultConstructorMarker);
    }

    public TaskRunner(Backend backend, Logger logger) {
        Intrinsics.checkNotNullParameter(backend, "backend");
        Intrinsics.checkNotNullParameter(logger, "logger");
        this.a = backend;
        this.b = logger;
        this.c = PipesConfigBase.DEFAULT_MAX_FILES_PROCESSED_PER_PROCESS;
        this.h = new ArrayList();
        this.i = new ArrayList();
        this.j = new Runnable() { // from class: okhttp3.internal.concurrent.TaskRunner$runnable$1
            @Override // java.lang.Runnable
            public void run() {
                Task taskE;
                long jB;
                Task taskE2;
                TaskRunner taskRunner = this.a;
                synchronized (taskRunner) {
                    taskRunner.g++;
                    taskE = taskRunner.e();
                }
                if (taskE == null) {
                    return;
                }
                Thread threadCurrentThread = Thread.currentThread();
                String name = threadCurrentThread.getName();
                while (true) {
                    try {
                        threadCurrentThread.setName(taskE.b());
                        Logger loggerI = this.a.i();
                        TaskQueue taskQueueD = taskE.d();
                        Intrinsics.checkNotNull(taskQueueD);
                        boolean zIsLoggable = loggerI.isLoggable(Level.FINE);
                        if (zIsLoggable) {
                            jB = taskQueueD.j().h().b();
                            TaskLoggerKt.a(loggerI, taskE, taskQueueD, ap.a(1379195472));
                        } else {
                            jB = -1;
                        }
                        try {
                            long jF = taskE.f();
                            if (zIsLoggable) {
                                TaskLoggerKt.a(loggerI, taskE, taskQueueD, ap.a(707907038) + TaskLoggerKt.b(taskQueueD.j().h().b() - jB));
                            }
                            TaskRunner taskRunner2 = this.a;
                            synchronized (taskRunner2) {
                                taskRunner2.d(taskE, jF, true);
                                taskE2 = taskRunner2.e();
                            }
                            if (taskE2 == null) {
                                threadCurrentThread.setName(name);
                                return;
                            }
                            taskE = taskE2;
                        } catch (Throwable th) {
                            if (zIsLoggable) {
                                TaskLoggerKt.a(loggerI, taskE, taskQueueD, ap.a(1630019550) + TaskLoggerKt.b(taskQueueD.j().h().b() - jB));
                            }
                            throw th;
                        }
                    } catch (Throwable th2) {
                        try {
                            TaskRunner taskRunner3 = this.a;
                            synchronized (taskRunner3) {
                                taskRunner3.d(taskE, -1L, false);
                                Unit unit = Unit.INSTANCE;
                                throw th2;
                            }
                        } catch (Throwable th3) {
                            threadCurrentThread.setName(name);
                            throw th3;
                        }
                    }
                }
            }
        };
    }

    private final void d(Task task, long j, boolean z) {
        if (_UtilJvmKt.b && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
        }
        TaskQueue taskQueueD = task.d();
        Intrinsics.checkNotNull(taskQueueD);
        if (taskQueueD.e() != task) {
            throw new IllegalStateException("Check failed.");
        }
        boolean zF = taskQueueD.f();
        taskQueueD.p(false);
        taskQueueD.o(null);
        this.h.remove(taskQueueD);
        if (j != -1 && !zF && !taskQueueD.i()) {
            taskQueueD.n(task, j, true);
        }
        if (taskQueueD.g().isEmpty()) {
            return;
        }
        this.i.add(taskQueueD);
        if (z) {
            return;
        }
        l();
    }

    private final void f(Task task) {
        if (_UtilJvmKt.b && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
        }
        task.g(-1L);
        TaskQueue taskQueueD = task.d();
        Intrinsics.checkNotNull(taskQueueD);
        taskQueueD.g().remove(task);
        this.i.remove(taskQueueD);
        taskQueueD.o(task);
        this.h.add(taskQueueD);
    }

    private final void l() {
        if (!_UtilJvmKt.b || Thread.holdsLock(this)) {
            int i = this.f;
            if (i > this.g) {
                return;
            }
            this.f = i + 1;
            this.a.a(this, this.j);
            return;
        }
        throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
    }

    public final Task e() {
        boolean z;
        if (_UtilJvmKt.b && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
        }
        while (!this.i.isEmpty()) {
            long jB = this.a.b();
            Iterator it = this.i.iterator();
            long jMin = Long.MAX_VALUE;
            Task task = null;
            while (true) {
                if (!it.hasNext()) {
                    z = false;
                    break;
                }
                Task task2 = (Task) ((TaskQueue) it.next()).g().get(0);
                long jMax = Math.max(0L, task2.c() - jB);
                if (jMax > 0) {
                    jMin = Math.min(jMax, jMin);
                } else {
                    if (task != null) {
                        z = true;
                        break;
                    }
                    task = task2;
                }
            }
            if (task != null) {
                f(task);
                if (z || (!this.d && !this.i.isEmpty())) {
                    l();
                }
                return task;
            }
            if (this.d) {
                if (jMin < this.e - jB) {
                    this.a.c(this);
                }
                return null;
            }
            this.d = true;
            this.e = jB + jMin;
            try {
                try {
                    this.a.d(this, jMin);
                } catch (InterruptedException unused) {
                    g();
                }
            } finally {
                this.d = false;
            }
        }
        return null;
    }

    public final void g() {
        if (_UtilJvmKt.b && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
        }
        int size = this.h.size();
        while (true) {
            size--;
            if (-1 >= size) {
                break;
            } else {
                ((TaskQueue) this.h.get(size)).b();
            }
        }
        for (int size2 = this.i.size() - 1; -1 < size2; size2--) {
            TaskQueue taskQueue = (TaskQueue) this.i.get(size2);
            taskQueue.b();
            if (taskQueue.g().isEmpty()) {
                this.i.remove(size2);
            }
        }
    }

    public final Backend h() {
        return this.a;
    }

    public final Logger i() {
        return this.b;
    }

    public final void j(TaskQueue taskQueue) {
        Intrinsics.checkNotNullParameter(taskQueue, "taskQueue");
        if (_UtilJvmKt.b && !Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST hold lock on " + this);
        }
        if (taskQueue.e() == null) {
            if (taskQueue.g().isEmpty()) {
                this.i.remove(taskQueue);
            } else {
                _UtilCommonKt.a(this.i, taskQueue);
            }
        }
        if (this.d) {
            this.a.c(this);
        } else {
            l();
        }
    }

    public final TaskQueue k() {
        int i;
        synchronized (this) {
            i = this.c;
            this.c = i + 1;
        }
        StringBuilder sb = new StringBuilder();
        sb.append('Q');
        sb.append(i);
        return new TaskQueue(this, sb.toString());
    }

    public /* synthetic */ TaskRunner(Backend backend, Logger logger, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(backend, (i & 2) != 0 ? l : logger);
    }
}