package okhttp3.internal.concurrent;

import h.ap;
import java.util.Arrays;
import java.util.logging.Logger;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.time.DurationKt;
import kotlin.time.InstantKt;
import org.apache.tika.pipes.pipesiterator.PipesIterator;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0004\u001a+\u0010\b\u001a\u00020\u0007*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u0005H\u0002¢\u0006\u0004\b\b\u0010\t\u001a\u0015\u0010\f\u001a\u00020\u00052\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\f\u0010\r¨\u0006\u000e"}, d2 = {"Ljava/util/logging/Logger;", "Lokhttp3/internal/concurrent/Task;", "task", "Lokhttp3/internal/concurrent/TaskQueue;", "queue", StringUtils.EMPTY, "message", StringUtils.EMPTY, "c", "(Ljava/util/logging/Logger;Lokhttp3/internal/concurrent/Task;Lokhttp3/internal/concurrent/TaskQueue;Ljava/lang/String;)V", StringUtils.EMPTY, "ns", "b", "(J)Ljava/lang/String;", "okhttp"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class TaskLoggerKt {
    public static final String b(long j) {
        String str;
        String strA = ap.a(1457639865);
        if (j <= -999500000) {
            str = ((j - ((long) 500000000)) / ((long) InstantKt.NANOS_PER_SECOND)) + strA;
        } else {
            String strA2 = ap.a(1279660290);
            if (j <= -999500) {
                str = ((j - ((long) 500000)) / ((long) DurationKt.NANOS_IN_MILLIS)) + strA2;
            } else {
                String strA3 = ap.a(1063010818);
                if (j <= 0) {
                    str = ((j - ((long) 500)) / ((long) PipesIterator.DEFAULT_QUEUE_SIZE)) + strA3;
                } else if (j < 999500) {
                    str = ((j + ((long) 500)) / ((long) PipesIterator.DEFAULT_QUEUE_SIZE)) + strA3;
                } else if (j < 999500000) {
                    str = ((j + ((long) 500000)) / ((long) DurationKt.NANOS_IN_MILLIS)) + strA2;
                } else {
                    str = ((j + ((long) 500000000)) / ((long) InstantKt.NANOS_PER_SECOND)) + strA;
                }
            }
        }
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        String str2 = String.format(ap.a(1626615638), Arrays.copyOf(new Object[]{str}, 1));
        Intrinsics.checkNotNullExpressionValue(str2, ap.a(243250753));
        return str2;
    }

    private static final void c(Logger logger, Task task, TaskQueue taskQueue, String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(taskQueue.h());
        sb.append(' ');
        StringCompanionObject stringCompanionObject = StringCompanionObject.INSTANCE;
        String str2 = String.format("%-22s", Arrays.copyOf(new Object[]{str}, 1));
        Intrinsics.checkNotNullExpressionValue(str2, "format(...)");
        sb.append(str2);
        sb.append(": ");
        sb.append(task.b());
        logger.fine(sb.toString());
    }
}