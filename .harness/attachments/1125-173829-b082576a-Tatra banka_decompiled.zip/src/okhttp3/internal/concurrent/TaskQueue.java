package okhttp3.internal.concurrent;

import h.ap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.RejectedExecutionException;
import java.util.logging.Level;
import java.util.logging.Logger;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.internal._UtilJvmKt;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u001e\n\u0002\u0010!\n\u0002\b\t\u0018\u00002\u00020\u0001:\u0001:B\u0019\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u001f\u0010\r\u001a\u00020\f2\u0006\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\r\u0010\u000eJ-\u0010\u0011\u001a\u00020\f2\u0006\u0010\u0005\u001a\u00020\u00042\b\b\u0002\u0010\u000b\u001a\u00020\n2\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\n0\u000f¢\u0006\u0004\b\u0011\u0010\u0012J7\u0010\u0015\u001a\u00020\f2\u0006\u0010\u0005\u001a\u00020\u00042\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\u0014\u001a\u00020\u00132\f\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\f0\u000f¢\u0006\u0004\b\u0015\u0010\u0016J'\u0010\u0018\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0017\u001a\u00020\u0013H\u0000¢\u0006\u0004\b\u0018\u0010\u0019J\r\u0010\u001a\u001a\u00020\f¢\u0006\u0004\b\u001a\u0010\u001bJ\r\u0010\u001c\u001a\u00020\f¢\u0006\u0004\b\u001c\u0010\u001bJ\u000f\u0010\u001d\u001a\u00020\u0013H\u0000¢\u0006\u0004\b\u001d\u0010\u001eJ\u000f\u0010\u001f\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u001f\u0010 R\u001a\u0010\u0003\u001a\u00020\u00028\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u001a\u0010!\u001a\u0004\b\"\u0010#R\u001a\u0010\u0005\u001a\u00020\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u001d\u0010$\u001a\u0004\b%\u0010 R\"\u0010*\u001a\u00020\u00138\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0015\u0010&\u001a\u0004\b'\u0010\u001e\"\u0004\b(\u0010)R$\u00101\u001a\u0004\u0018\u00010\b8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b+\u0010,\u001a\u0004\b-\u0010.\"\u0004\b/\u00100R \u00106\u001a\b\u0012\u0004\u0012\u00020\b028\u0000X\u0080\u0004¢\u0006\f\n\u0004\b-\u00103\u001a\u0004\b4\u00105R\"\u00109\u001a\u00020\u00138\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b7\u0010&\u001a\u0004\b7\u0010\u001e\"\u0004\b8\u0010)¨\u0006;"}, d2 = {"Lokhttp3/internal/concurrent/TaskQueue;", StringUtils.EMPTY, "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", StringUtils.EMPTY, "name", "<init>", "(Lokhttp3/internal/concurrent/TaskRunner;Ljava/lang/String;)V", "Lokhttp3/internal/concurrent/Task;", "task", StringUtils.EMPTY, "delayNanos", StringUtils.EMPTY, "l", "(Lokhttp3/internal/concurrent/Task;J)V", "Lkotlin/Function0;", "block", "k", "(Ljava/lang/String;JLkotlin/jvm/functions/Function0;)V", StringUtils.EMPTY, "cancelable", "c", "(Ljava/lang/String;JZLkotlin/jvm/functions/Function0;)V", "recurrence", "n", "(Lokhttp3/internal/concurrent/Task;JZ)Z", "a", "()V", "q", "b", "()Z", "toString", "()Ljava/lang/String;", "Lokhttp3/internal/concurrent/TaskRunner;", "j", "()Lokhttp3/internal/concurrent/TaskRunner;", "Ljava/lang/String;", "h", "Z", "i", "setShutdown$okhttp", "(Z)V", "shutdown", "d", "Lokhttp3/internal/concurrent/Task;", "e", "()Lokhttp3/internal/concurrent/Task;", "o", "(Lokhttp3/internal/concurrent/Task;)V", "activeTask", StringUtils.EMPTY, "Ljava/util/List;", "g", "()Ljava/util/List;", "futureTasks", "f", "p", "cancelActiveTask", "AwaitIdleTask", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nTaskQueue.kt\nKotlin\n*S Kotlin\n*F\n+ 1 TaskQueue.kt\nokhttp3/internal/concurrent/TaskQueue\n+ 2 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n+ 3 TaskLogger.kt\nokhttp3/internal/concurrent/TaskLoggerKt\n+ 4 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,241:1\n63#2:242\n63#2:243\n63#2:252\n49#2,4:268\n63#2:272\n49#2,4:273\n63#2:277\n26#3,4:244\n26#3,4:248\n26#3,4:253\n26#3,4:257\n26#3,4:278\n360#4,7:261\n*S KotlinDebug\n*F\n+ 1 TaskQueue.kt\nokhttp3/internal/concurrent/TaskQueue\n*L\n48#1:242\n64#1:243\n122#1:252\n202#1:268,4\n204#1:272\n212#1:273,4\n214#1:277\n67#1:244,4\n70#1:248,4\n173#1:253,4\n179#1:257,4\n231#1:278,4\n188#1:261,7\n*E\n"})
public final class TaskQueue {
    private final TaskRunner a;
    private final String b;
    private boolean c;
    private Task d;
    private final List e;
    private boolean f;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0002\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0006R\u0017\u0010\f\u001a\u00020\u00078\u0006¢\u0006\f\n\u0004\b\b\u0010\t\u001a\u0004\b\n\u0010\u000b¨\u0006\r"}, d2 = {"Lokhttp3/internal/concurrent/TaskQueue$AwaitIdleTask;", "Lokhttp3/internal/concurrent/Task;", "<init>", "()V", StringUtils.EMPTY, "f", "()J", "Ljava/util/concurrent/CountDownLatch;", "e", "Ljava/util/concurrent/CountDownLatch;", "getLatch", "()Ljava/util/concurrent/CountDownLatch;", "latch", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private static final class AwaitIdleTask extends Task {
        private final CountDownLatch e;

        public AwaitIdleTask() {
            super(_UtilJvmKt.c + ap.a(1850911365), false);
            this.e = new CountDownLatch(1);
        }

        @Override // okhttp3.internal.concurrent.Task
        public long f() {
            this.e.countDown();
            return -1L;
        }
    }

    public TaskQueue(TaskRunner taskRunner, String str) {
        Intrinsics.checkNotNullParameter(taskRunner, ap.a(1868506066));
        Intrinsics.checkNotNullParameter(str, ap.a(1238780684));
        this.a = taskRunner;
        this.b = str;
        this.e = new ArrayList();
    }

    public static /* synthetic */ void d(TaskQueue taskQueue, String str, long j, boolean z, Function0 function0, int i, Object obj) {
        if ((i & 2) != 0) {
            j = 0;
        }
        long j2 = j;
        if ((i & 4) != 0) {
            z = true;
        }
        taskQueue.c(str, j2, z, function0);
    }

    public static /* synthetic */ void m(TaskQueue taskQueue, Task task, long j, int i, Object obj) {
        if ((i & 2) != 0) {
            j = 0;
        }
        taskQueue.l(task, j);
    }

    public final void a() {
        TaskRunner taskRunner = this.a;
        if (_UtilJvmKt.b && Thread.holdsLock(taskRunner)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + taskRunner);
        }
        synchronized (this.a) {
            try {
                if (b()) {
                    this.a.j(this);
                }
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final boolean b() {
        Task task = this.d;
        if (task != null) {
            Intrinsics.checkNotNull(task);
            if (task.a()) {
                this.f = true;
            }
        }
        boolean z = false;
        for (int size = this.e.size() - 1; -1 < size; size--) {
            if (((Task) this.e.get(size)).a()) {
                Logger loggerI = this.a.i();
                Task task2 = (Task) this.e.get(size);
                if (loggerI.isLoggable(Level.FINE)) {
                    TaskLoggerKt.c(loggerI, task2, this, "canceled");
                }
                this.e.remove(size);
                z = true;
            }
        }
        return z;
    }

    public final void c(final String str, long j, final boolean z, final Function0 function0) {
        Intrinsics.checkNotNullParameter(str, "name");
        Intrinsics.checkNotNullParameter(function0, "block");
        l(new Task(str, z) { // from class: okhttp3.internal.concurrent.TaskQueue$execute$1
            @Override // okhttp3.internal.concurrent.Task
            public long f() {
                function0.invoke();
                return -1L;
            }
        }, j);
    }

    public final Task e() {
        return this.d;
    }

    public final boolean f() {
        return this.f;
    }

    public final List g() {
        return this.e;
    }

    public final String h() {
        return this.b;
    }

    public final boolean i() {
        return this.c;
    }

    public final TaskRunner j() {
        return this.a;
    }

    public final void k(final String str, long j, final Function0 function0) {
        Intrinsics.checkNotNullParameter(str, "name");
        Intrinsics.checkNotNullParameter(function0, "block");
        l(new Task(str) { // from class: okhttp3.internal.concurrent.TaskQueue$schedule$2
            @Override // okhttp3.internal.concurrent.Task
            public long f() {
                return ((Number) function0.invoke()).longValue();
            }
        }, j);
    }

    public final void l(Task task, long j) {
        Intrinsics.checkNotNullParameter(task, "task");
        synchronized (this.a) {
            if (!this.c) {
                if (n(task, j, false)) {
                    this.a.j(this);
                }
                Unit unit = Unit.INSTANCE;
            } else if (task.a()) {
                Logger loggerI = this.a.i();
                if (loggerI.isLoggable(Level.FINE)) {
                    TaskLoggerKt.c(loggerI, task, this, "schedule canceled (queue is shutdown)");
                }
            } else {
                Logger loggerI2 = this.a.i();
                if (loggerI2.isLoggable(Level.FINE)) {
                    TaskLoggerKt.c(loggerI2, task, this, "schedule failed (queue is shutdown)");
                }
                throw new RejectedExecutionException();
            }
        }
    }

    public final boolean n(Task task, long j, boolean z) {
        String str;
        Intrinsics.checkNotNullParameter(task, "task");
        task.e(this);
        long jB = this.a.h().b();
        long j2 = jB + j;
        int iIndexOf = this.e.indexOf(task);
        if (iIndexOf != -1) {
            if (task.c() <= j2) {
                Logger loggerI = this.a.i();
                if (loggerI.isLoggable(Level.FINE)) {
                    TaskLoggerKt.c(loggerI, task, this, "already scheduled");
                }
                return false;
            }
            this.e.remove(iIndexOf);
        }
        task.g(j2);
        Logger loggerI2 = this.a.i();
        if (loggerI2.isLoggable(Level.FINE)) {
            if (z) {
                str = "run again after " + TaskLoggerKt.b(j2 - jB);
            } else {
                str = "scheduled after " + TaskLoggerKt.b(j2 - jB);
            }
            TaskLoggerKt.c(loggerI2, task, this, str);
        }
        Iterator it = this.e.iterator();
        int size = 0;
        while (true) {
            if (!it.hasNext()) {
                size = -1;
                break;
            }
            if (((Task) it.next()).c() - jB > j) {
                break;
            }
            size++;
        }
        if (size == -1) {
            size = this.e.size();
        }
        this.e.add(size, task);
        return size == 0;
    }

    public final void o(Task task) {
        this.d = task;
    }

    public final void p(boolean z) {
        this.f = z;
    }

    public final void q() {
        TaskRunner taskRunner = this.a;
        if (_UtilJvmKt.b && Thread.holdsLock(taskRunner)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + taskRunner);
        }
        synchronized (this.a) {
            try {
                this.c = true;
                if (b()) {
                    this.a.j(this);
                }
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public String toString() {
        return this.b;
    }
}