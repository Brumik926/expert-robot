package okhttp3.internal.idn;

import h.ap;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.coroutines.scheduling.WorkQueueKt;
import okio.BufferedSink;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\b\b\u0000\u0018\u00002\u00020\u0001B!\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0002¢\u0006\u0004\b\u0006\u0010\u0007J\u0017\u0010\n\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\bH\u0002¢\u0006\u0004\b\n\u0010\u000bJ'\u0010\u000e\u001a\u00020\b2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\bH\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\u001d\u0010\u0013\u001a\u00020\u00122\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u0011\u001a\u00020\u0010¢\u0006\u0004\b\u0013\u0010\u0014R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u000e\u0010\u0015\u001a\u0004\b\u0016\u0010\u0017R\u0017\u0010\u0004\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\n\u0010\u0015\u001a\u0004\b\u0018\u0010\u0017R\u0017\u0010\u0005\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0013\u0010\u0015\u001a\u0004\b\u0019\u0010\u0017¨\u0006\u001a"}, d2 = {"Lokhttp3/internal/idn/IdnaMappingTable;", StringUtils.EMPTY, StringUtils.EMPTY, "sections", "ranges", "mappings", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", StringUtils.EMPTY, "codePoint", "b", "(I)I", "position", "limit", "a", "(III)I", "Lokio/BufferedSink;", "sink", StringUtils.EMPTY, "c", "(ILokio/BufferedSink;)Z", "Ljava/lang/String;", "getSections", "()Ljava/lang/String;", "getRanges", "getMappings", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nIdnaMappingTable.kt\nKotlin\n*S Kotlin\n*F\n+ 1 IdnaMappingTable.kt\nokhttp3/internal/idn/IdnaMappingTable\n+ 2 IdnaMappingTable.kt\nokhttp3/internal/idn/IdnaMappingTableKt\n*L\n1#1,286:1\n272#2,13:287\n272#2,13:300\n*S KotlinDebug\n*F\n+ 1 IdnaMappingTable.kt\nokhttp3/internal/idn/IdnaMappingTable\n*L\n209#1:287,13\n237#1:300,13\n*E\n"})
public final class IdnaMappingTable {
    private final String a;
    private final String b;
    private final String c;

    public IdnaMappingTable(String str, String str2, String str3) {
        Intrinsics.checkNotNullParameter(str, ap.a(849176261));
        Intrinsics.checkNotNullParameter(str2, ap.a(828449819));
        Intrinsics.checkNotNullParameter(str3, ap.a(264624615));
        this.a = str;
        this.b = str2;
        this.c = str3;
    }

    private final int a(int i, int i2, int i3) {
        int i4;
        int i5 = i & WorkQueueKt.MASK;
        int i6 = i3 - 1;
        while (true) {
            if (i2 > i6) {
                i4 = (-i2) - 1;
                break;
            }
            i4 = (i2 + i6) / 2;
            int iCompare = Intrinsics.compare(i5, this.b.charAt(i4 * 4));
            if (iCompare >= 0) {
                if (iCompare <= 0) {
                    break;
                }
                i2 = i4 + 1;
            } else {
                i6 = i4 - 1;
            }
        }
        return i4 >= 0 ? i4 * 4 : ((-i4) - 2) * 4;
    }

    private final int b(int i) {
        int i2;
        int i3 = (i & 2097024) >> 7;
        int length = (this.a.length() / 4) - 1;
        int i4 = 0;
        while (true) {
            if (i4 > length) {
                i2 = (-i4) - 1;
                break;
            }
            i2 = (i4 + length) / 2;
            int iCompare = Intrinsics.compare(i3, IdnaMappingTableKt.a(this.a, i2 * 4));
            if (iCompare >= 0) {
                if (iCompare <= 0) {
                    break;
                }
                i4 = i2 + 1;
            } else {
                length = i2 - 1;
            }
        }
        return i2 >= 0 ? i2 * 4 : ((-i2) - 2) * 4;
    }

    public final boolean c(int i, BufferedSink bufferedSink) {
        Intrinsics.checkNotNullParameter(bufferedSink, "sink");
        int iB = b(i);
        int iA = a(i, IdnaMappingTableKt.a(this.a, iB + 2), iB + 4 < this.a.length() ? IdnaMappingTableKt.a(this.a, iB + 6) : this.b.length() / 4);
        char cCharAt = this.b.charAt(iA + 1);
        if (cCharAt >= 0 && cCharAt < '@') {
            int iA2 = IdnaMappingTableKt.a(this.b, iA + 2);
            bufferedSink.f0(this.c, iA2, cCharAt + iA2);
            return true;
        }
        if ('@' <= cCharAt && cCharAt < 'P') {
            bufferedSink.C1(i - (this.b.charAt(iA + 3) | (((cCharAt & 15) << 14) | (this.b.charAt(iA + 2) << 7))));
            return true;
        }
        if ('P' <= cCharAt && cCharAt < '`') {
            bufferedSink.C1(i + (this.b.charAt(iA + 3) | ((cCharAt & 15) << 14) | (this.b.charAt(iA + 2) << 7)));
            return true;
        }
        if (cCharAt == 'w') {
            Unit unit = Unit.INSTANCE;
            return true;
        }
        if (cCharAt == 'x') {
            bufferedSink.C1(i);
            return true;
        }
        if (cCharAt == 'y') {
            bufferedSink.C1(i);
            return false;
        }
        if (cCharAt == 'z') {
            bufferedSink.writeByte(this.b.charAt(iA + 2));
            return true;
        }
        if (cCharAt == '{') {
            bufferedSink.writeByte(this.b.charAt(iA + 2) | 128);
            return true;
        }
        if (cCharAt == '|') {
            bufferedSink.writeByte(this.b.charAt(iA + 2));
            bufferedSink.writeByte(this.b.charAt(iA + 3));
            return true;
        }
        if (cCharAt == '}') {
            bufferedSink.writeByte(this.b.charAt(iA + 2) | 128);
            bufferedSink.writeByte(this.b.charAt(iA + 3));
            return true;
        }
        if (cCharAt == '~') {
            bufferedSink.writeByte(this.b.charAt(iA + 2));
            bufferedSink.writeByte(this.b.charAt(iA + 3) | 128);
            return true;
        }
        if (cCharAt == 127) {
            bufferedSink.writeByte(this.b.charAt(iA + 2) | 128);
            bufferedSink.writeByte(this.b.charAt(iA + 3) | 128);
            return true;
        }
        throw new IllegalStateException(("unexpected rangesIndex for " + i).toString());
    }
}