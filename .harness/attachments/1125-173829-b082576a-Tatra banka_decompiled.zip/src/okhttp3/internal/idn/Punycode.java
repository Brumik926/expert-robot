package okhttp3.internal.idn;

import h.ap;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.IntProgression;
import kotlin.ranges.RangesKt;
import kotlin.text.CharsKt;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okio.Buffer;
import okio.ByteString;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0010 \n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\b\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J/\u0010\f\u001a\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\tH\u0002¢\u0006\u0004\b\f\u0010\rJ/\u0010\u000e\u001a\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\tH\u0002¢\u0006\u0004\b\u000e\u0010\rJ'\u0010\u0012\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u00062\u0006\u0010\u0010\u001a\u00020\u00062\u0006\u0010\u0011\u001a\u00020\u000bH\u0002¢\u0006\u0004\b\u0012\u0010\u0013J#\u0010\u0014\u001a\u00020\u000b*\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\u0014\u0010\u0015J)\u0010\u0017\u001a\b\u0012\u0004\u0012\u00020\u00060\u0016*\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\u0017\u0010\u0018J\u0017\u0010\u0019\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0019\u0010\u001aJ\u0017\u0010\u001b\u001a\u0004\u0018\u00010\u00042\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u001b\u0010\u001aR\u001a\u0010\u001f\u001a\u00020\u00048\u0006X\u0086D¢\u0006\f\n\u0004\b\u0017\u0010\u001c\u001a\u0004\b\u001d\u0010\u001eR\u0017\u0010$\u001a\u00020 8\u0006¢\u0006\f\n\u0004\b\u001b\u0010!\u001a\u0004\b\"\u0010#R\u0018\u0010'\u001a\u00020\u0006*\u00020\u00068BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b%\u0010&¨\u0006("}, d2 = {"Lokhttp3/internal/idn/Punycode;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "string", StringUtils.EMPTY, "pos", "limit", "Lokio/Buffer;", "result", StringUtils.EMPTY, "f", "(Ljava/lang/String;IILokio/Buffer;)Z", "d", "delta", "numpoints", "first", "a", "(IIZ)I", "h", "(Ljava/lang/String;II)Z", StringUtils.EMPTY, "b", "(Ljava/lang/String;II)Ljava/util/List;", "e", "(Ljava/lang/String;)Ljava/lang/String;", "c", "Ljava/lang/String;", "getPREFIX_STRING", "()Ljava/lang/String;", "PREFIX_STRING", "Lokio/ByteString;", "Lokio/ByteString;", "getPREFIX", "()Lokio/ByteString;", "PREFIX", "g", "(I)I", "punycodeDigit", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nPunycode.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Punycode.kt\nokhttp3/internal/idn/Punycode\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,329:1\n2393#2,14:330\n*S KotlinDebug\n*F\n+ 1 Punycode.kt\nokhttp3/internal/idn/Punycode\n*L\n108#1:330,14\n*E\n"})
public final class Punycode {
    public static final Punycode a = new Punycode();
    private static final String b;
    private static final ByteString c;

    static {
        String strA = ap.a(137145234);
        b = strA;
        c = ByteString.d.d(strA);
    }

    private Punycode() {
    }

    private final int a(int i, int i2, boolean z) {
        int i3 = z ? i / 700 : i / 2;
        int i4 = i3 + (i3 / i2);
        int i5 = 0;
        while (i4 > 455) {
            i4 /= 35;
            i5 += 36;
        }
        return i5 + ((i4 * 36) / (i4 + 38));
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [char] */
    /* JADX WARN: Type inference failed for: r0v3 */
    /* JADX WARN: Type inference failed for: r0v6, types: [int] */
    private final List b(String str, int i, int i2) {
        ArrayList arrayList = new ArrayList();
        while (i < i2) {
            int iCharAt = str.charAt(i);
            if (CharsKt.isSurrogate(iCharAt)) {
                int i3 = i + 1;
                char cCharAt = i3 < i2 ? str.charAt(i3) : (char) 0;
                if (Character.isLowSurrogate(iCharAt) || !Character.isLowSurrogate(cCharAt)) {
                    iCharAt = 63;
                } else {
                    iCharAt = 65536 + (((iCharAt & 1023) << 10) | (cCharAt & 1023));
                    i = i3;
                }
            }
            arrayList.add(Integer.valueOf(iCharAt));
            i++;
        }
        return arrayList;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final boolean d(String str, int i, int i2, Buffer buffer) {
        int i3;
        int i4;
        int i5 = 1;
        if (!StringsKt.regionMatches(str, i, b, 0, 4, true)) {
            buffer.f0(str, i, i2);
            return true;
        }
        int i6 = i + 4;
        ArrayList arrayList = new ArrayList();
        int iLastIndexOf$default = StringsKt.lastIndexOf$default((CharSequence) str, '-', i2, false, 4, (Object) null);
        char c2 = '0';
        char c3 = AbstractJsonLexerKt.BEGIN_LIST;
        char c4 = AbstractJsonLexerKt.BEGIN_OBJ;
        boolean z = false;
        if (iLastIndexOf$default >= i6) {
            while (i6 < iLastIndexOf$default) {
                int i7 = i6 + 1;
                char cCharAt = str.charAt(i6);
                if (('a' > cCharAt || cCharAt >= '{') && (('A' > cCharAt || cCharAt >= '[') && (('0' > cCharAt || cCharAt >= ':') && cCharAt != '-'))) {
                    return false;
                }
                arrayList.add(Integer.valueOf(cCharAt));
                i6 = i7;
            }
            i6++;
        }
        int i8 = 128;
        int iA = 72;
        int i9 = 0;
        while (i6 < i2) {
            int i10 = i5;
            boolean z2 = z;
            IntProgression intProgressionStep = RangesKt.step(RangesKt.until(36, Integer.MAX_VALUE), 36);
            int first = intProgressionStep.getFirst();
            int last = intProgressionStep.getLast();
            int step = intProgressionStep.getStep();
            if ((step > 0 && first <= last) || (step < 0 && last <= first)) {
                i3 = i9;
                int i11 = i10;
                while (i6 != i2) {
                    int i12 = i6 + 1;
                    char cCharAt2 = str.charAt(i6);
                    if ('a' <= cCharAt2 && cCharAt2 < c4) {
                        i4 = cCharAt2 - 'a';
                    } else if ('A' <= cCharAt2 && cCharAt2 < c3) {
                        i4 = cCharAt2 - 'A';
                    } else {
                        if (c2 > cCharAt2 || cCharAt2 >= ':') {
                            return z2;
                        }
                        i4 = cCharAt2 - 22;
                    }
                    int i13 = i11;
                    int i14 = i4 * i13;
                    int i15 = i3;
                    if (i15 > Integer.MAX_VALUE - i14) {
                        return z2;
                    }
                    i3 = i15 + i14;
                    int i16 = first <= iA ? i10 : first >= iA + 26 ? 26 : first - iA;
                    if (i4 >= i16) {
                        int i17 = 36 - i16;
                        if (i13 > Integer.MAX_VALUE / i17) {
                            return z2;
                        }
                        i11 = i13 * i17;
                        if (first != last) {
                            first += step;
                            i6 = i12;
                            c2 = '0';
                            c3 = AbstractJsonLexerKt.BEGIN_LIST;
                            c4 = AbstractJsonLexerKt.BEGIN_OBJ;
                        }
                    }
                    i6 = i12;
                }
                return z2;
            }
            i3 = i9;
            iA = a(i3 - i9, arrayList.size() + 1, i9 == 0 ? i10 : z2);
            int size = i3 / (arrayList.size() + 1);
            if (i8 > Integer.MAX_VALUE - size) {
                return z2;
            }
            i8 += size;
            int size2 = i3 % (arrayList.size() + 1);
            if (i8 > 1114111) {
                return z2;
            }
            arrayList.add(size2, Integer.valueOf(i8));
            i9 = size2 + 1;
            z = z2;
            i5 = i10;
            c2 = '0';
            c3 = AbstractJsonLexerKt.BEGIN_LIST;
            c4 = AbstractJsonLexerKt.BEGIN_OBJ;
        }
        boolean z3 = i5;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            buffer.C1(((Number) it.next()).intValue());
        }
        return z3;
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final boolean f(String str, int i, int i2, Buffer buffer) {
        int i3;
        int i4;
        int i5;
        int i6 = 1;
        if (!h(str, i, i2)) {
            buffer.f0(str, i, i2);
            return true;
        }
        buffer.l1(c);
        List listB = b(str, i, i2);
        Iterator it = listB.iterator();
        int i7 = 0;
        while (true) {
            i3 = 128;
            if (!it.hasNext()) {
                break;
            }
            int iIntValue = ((Number) it.next()).intValue();
            if (iIntValue < 128) {
                buffer.writeByte(iIntValue);
                i7++;
            }
        }
        if (i7 > 0) {
            buffer.writeByte(45);
        }
        int iA = 72;
        int i8 = 0;
        int i9 = i7;
        while (i9 < listB.size()) {
            Iterator it2 = listB.iterator();
            if (!it2.hasNext()) {
                throw new NoSuchElementException();
            }
            Object next = it2.next();
            if (it2.hasNext()) {
                int iIntValue2 = ((Number) next).intValue();
                if (iIntValue2 < i3) {
                    iIntValue2 = Integer.MAX_VALUE;
                }
                do {
                    Object next2 = it2.next();
                    int iIntValue3 = ((Number) next2).intValue();
                    if (iIntValue3 < i3) {
                        iIntValue3 = Integer.MAX_VALUE;
                    }
                    if (iIntValue2 > iIntValue3) {
                        next = next2;
                        iIntValue2 = iIntValue3;
                    }
                } while (it2.hasNext());
            }
            int iIntValue4 = ((Number) next).intValue();
            int i10 = (iIntValue4 - i3) * (i9 + 1);
            if (i8 > Integer.MAX_VALUE - i10) {
                return false;
            }
            int i11 = i8 + i10;
            Iterator it3 = listB.iterator();
            while (it3.hasNext()) {
                int iIntValue5 = ((Number) it3.next()).intValue();
                if (iIntValue5 < iIntValue4) {
                    if (i11 == Integer.MAX_VALUE) {
                        return false;
                    }
                    i11++;
                } else if (iIntValue5 == iIntValue4) {
                    IntProgression intProgressionStep = RangesKt.step(RangesKt.until(36, Integer.MAX_VALUE), 36);
                    int first = intProgressionStep.getFirst();
                    int last = intProgressionStep.getLast();
                    int step = intProgressionStep.getStep();
                    if ((step > 0 && first <= last) || (step < 0 && last <= first)) {
                        i5 = i11;
                        while (true) {
                            if (first <= iA) {
                                i4 = i6;
                            } else {
                                i4 = i6;
                                i6 = first >= iA + 26 ? 26 : first - iA;
                            }
                            if (i5 < i6) {
                                break;
                            }
                            int i12 = i5 - i6;
                            int i13 = 36 - i6;
                            buffer.writeByte(g(i6 + (i12 % i13)));
                            i5 = i12 / i13;
                            if (first == last) {
                                break;
                            }
                            first += step;
                            i6 = i4;
                        }
                    } else {
                        i4 = i6;
                        i5 = i11;
                    }
                    buffer.writeByte(g(i5));
                    int i14 = i9 + 1;
                    iA = a(i11, i14, i9 == i7 ? i4 : false);
                    i9 = i14;
                    i11 = 0;
                    i6 = i4;
                }
            }
            i8 = i11 + 1;
            i3 = iIntValue4 + 1;
        }
        return i6;
    }

    private final int g(int i) {
        if (i < 26) {
            return i + 97;
        }
        if (i < 36) {
            return i + 22;
        }
        throw new IllegalStateException(("unexpected digit: " + i).toString());
    }

    private final boolean h(String str, int i, int i2) {
        while (i < i2) {
            if (str.charAt(i) >= 128) {
                return true;
            }
            i++;
        }
        return false;
    }

    public final String c(String str) {
        Intrinsics.checkNotNullParameter(str, "string");
        int length = str.length();
        Buffer buffer = new Buffer();
        int i = 0;
        while (i < length) {
            String str2 = str;
            int iIndexOf$default = StringsKt.indexOf$default((CharSequence) str2, '.', i, false, 4, (Object) null);
            if (iIndexOf$default == -1) {
                iIndexOf$default = length;
            }
            if (!d(str2, i, iIndexOf$default, buffer)) {
                return null;
            }
            if (iIndexOf$default >= length) {
                break;
            }
            buffer.writeByte(46);
            i = iIndexOf$default + 1;
            str = str2;
        }
        return buffer.X();
    }

    public final String e(String str) {
        Intrinsics.checkNotNullParameter(str, "string");
        int length = str.length();
        Buffer buffer = new Buffer();
        int i = 0;
        while (i < length) {
            String str2 = str;
            int iIndexOf$default = StringsKt.indexOf$default((CharSequence) str2, '.', i, false, 4, (Object) null);
            if (iIndexOf$default == -1) {
                iIndexOf$default = length;
            }
            if (!f(str2, i, iIndexOf$default, buffer)) {
                return null;
            }
            if (iIndexOf$default >= length) {
                break;
            }
            buffer.writeByte(46);
            i = iIndexOf$default + 1;
            str = str2;
        }
        return buffer.X();
    }
}