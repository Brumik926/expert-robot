package okhttp3.internal.http1;

import h.ap;
import java.io.EOFException;
import java.io.IOException;
import java.net.ProtocolException;
import java.net.Proxy;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import okhttp3.CookieJar;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.http.ExchangeCodec;
import okhttp3.internal.http.HttpHeaders;
import okhttp3.internal.http.RequestLine;
import okhttp3.internal.http.StatusLine;
import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.ForwardingTimeout;
import okio.Sink;
import okio.Source;
import okio.Timeout;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0088\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0014\u0018\u0000 92\u00020\u0001:\u0007STUVWXYB)\u0012\b\u0010\u0003\u001a\u0004\u0018\u00010\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\r\u001a\u00020\fH\u0002¢\u0006\u0004\b\r\u0010\u000eJ\u000f\u0010\u000f\u001a\u00020\fH\u0002¢\u0006\u0004\b\u000f\u0010\u000eJ\u001f\u0010\u0015\u001a\u00020\u00142\u0006\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0013\u001a\u00020\u0012H\u0002¢\u0006\u0004\b\u0015\u0010\u0016J\u0017\u0010\u0017\u001a\u00020\u00142\u0006\u0010\u0011\u001a\u00020\u0010H\u0002¢\u0006\u0004\b\u0017\u0010\u0018J\u0017\u0010\u0019\u001a\u00020\u00142\u0006\u0010\u0011\u001a\u00020\u0010H\u0002¢\u0006\u0004\b\u0019\u0010\u0018J\u0017\u0010\u001d\u001a\u00020\u001c2\u0006\u0010\u001b\u001a\u00020\u001aH\u0002¢\u0006\u0004\b\u001d\u0010\u001eJ\u001f\u0010\"\u001a\u00020\f2\u0006\u0010 \u001a\u00020\u001f2\u0006\u0010!\u001a\u00020\u0012H\u0016¢\u0006\u0004\b\"\u0010#J\u000f\u0010$\u001a\u00020\u001cH\u0016¢\u0006\u0004\b$\u0010%J\u0017\u0010&\u001a\u00020\u001c2\u0006\u0010 \u001a\u00020\u001fH\u0016¢\u0006\u0004\b&\u0010'J\u0017\u0010*\u001a\u00020\u00122\u0006\u0010)\u001a\u00020(H\u0016¢\u0006\u0004\b*\u0010+J\u0017\u0010,\u001a\u00020\u00142\u0006\u0010)\u001a\u00020(H\u0016¢\u0006\u0004\b,\u0010-J\u000f\u0010.\u001a\u00020\u001cH\u0016¢\u0006\u0004\b.\u0010%J\u000f\u0010/\u001a\u00020\u001cH\u0016¢\u0006\u0004\b/\u0010%J\u001d\u00104\u001a\u00020\u001c2\u0006\u00101\u001a\u0002002\u0006\u00103\u001a\u000202¢\u0006\u0004\b4\u00105J\u0019\u00109\u001a\u0004\u0018\u0001082\u0006\u00107\u001a\u000206H\u0016¢\u0006\u0004\b9\u0010:J\u0015\u0010;\u001a\u00020\u001c2\u0006\u0010)\u001a\u00020(¢\u0006\u0004\b;\u0010<R\u0016\u0010\u0003\u001a\u0004\u0018\u00010\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b,\u0010=R\u001a\u0010\u0005\u001a\u00020\u00048\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\"\u0010>\u001a\u0004\b?\u0010@R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b.\u0010AR\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b/\u0010BR\u0016\u0010E\u001a\u00020C8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b*\u0010DR\u0014\u0010H\u001a\u00020F8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b&\u0010GR\u0018\u0010K\u001a\u0004\u0018\u0001008\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bI\u0010JR\u0018\u0010N\u001a\u000206*\u00020(8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\bL\u0010MR\u0018\u0010N\u001a\u000206*\u00020\u001f8BX\u0082\u0004¢\u0006\u0006\u001a\u0004\bO\u0010PR\u0014\u0010R\u001a\u0002068VX\u0096\u0004¢\u0006\u0006\u001a\u0004\bI\u0010Q¨\u0006Z"}, d2 = {"Lokhttp3/internal/http1/Http1ExchangeCodec;", "Lokhttp3/internal/http/ExchangeCodec;", "Lokhttp3/OkHttpClient;", "client", "Lokhttp3/internal/http/ExchangeCodec$Carrier;", "carrier", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "Lokio/BufferedSink;", "sink", "<init>", "(Lokhttp3/OkHttpClient;Lokhttp3/internal/http/ExchangeCodec$Carrier;Lokio/BufferedSource;Lokio/BufferedSink;)V", "Lokio/Sink;", "v", "()Lokio/Sink;", "y", "Lokhttp3/HttpUrl;", "url", StringUtils.EMPTY, "length", "Lokio/Source;", "x", "(Lokhttp3/HttpUrl;J)Lokio/Source;", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "(Lokhttp3/HttpUrl;)Lokio/Source;", "z", "Lokio/ForwardingTimeout;", "timeout", StringUtils.EMPTY, "s", "(Lokio/ForwardingTimeout;)V", "Lokhttp3/Request;", "request", "contentLength", "b", "(Lokhttp3/Request;J)Lokio/Sink;", "cancel", "()V", "f", "(Lokhttp3/Request;)V", "Lokhttp3/Response;", "response", "e", "(Lokhttp3/Response;)J", "a", "(Lokhttp3/Response;)Lokio/Source;", "c", "d", "Lokhttp3/Headers;", "headers", StringUtils.EMPTY, "requestLine", "B", "(Lokhttp3/Headers;Ljava/lang/String;)V", StringUtils.EMPTY, "expectContinue", "Lokhttp3/Response$Builder;", "h", "(Z)Lokhttp3/Response$Builder;", "A", "(Lokhttp3/Response;)V", "Lokhttp3/OkHttpClient;", "Lokhttp3/internal/http/ExchangeCodec$Carrier;", "i", "()Lokhttp3/internal/http/ExchangeCodec$Carrier;", "Lokio/BufferedSource;", "Lokio/BufferedSink;", StringUtils.EMPTY, "I", "state", "Lokhttp3/internal/http1/HeadersReader;", "Lokhttp3/internal/http1/HeadersReader;", "headersReader", "g", "Lokhttp3/Headers;", "trailers", "u", "(Lokhttp3/Response;)Z", "isChunked", "t", "(Lokhttp3/Request;)Z", "()Z", "isResponseComplete", "KnownLengthSink", "ChunkedSink", "AbstractSource", "FixedLengthSource", "ChunkedSource", "UnknownLengthSource", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nHttp1ExchangeCodec.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http1ExchangeCodec.kt\nokhttp3/internal/http1/Http1ExchangeCodec\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,561:1\n1#2:562\n*E\n"})
public final class Http1ExchangeCodec implements ExchangeCodec {
    public static final Companion h = new Companion(null);
    private static final Headers i = Headers.b.b(ap.a(745063805), ap.a(1653956908));
    private final OkHttpClient a;
    private final ExchangeCodec.Carrier b;
    private final BufferedSource c;
    private final BufferedSink d;
    private int e;
    private final HeadersReader f;
    private Headers g;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\b\b¢\u0004\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u0007\u0010\bJ\u001f\u0010\r\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\r\u0010\u000eJ\u0015\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0010\u001a\u00020\u000f¢\u0006\u0004\b\u0012\u0010\u0013R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0014\u0010\u0015\u001a\u0004\b\u0016\u0010\u0017R\u001a\u0010\u0007\u001a\u00020\u00188\u0004X\u0084\u0004¢\u0006\f\n\u0004\b\u0019\u0010\u001a\u001a\u0004\b\u001b\u0010\u001cR\"\u0010$\u001a\u00020\u001d8\u0004@\u0004X\u0084\u000e¢\u0006\u0012\n\u0004\b\u001e\u0010\u001f\u001a\u0004\b \u0010!\"\u0004\b\"\u0010#¨\u0006%"}, d2 = {"Lokhttp3/internal/http1/Http1ExchangeCodec$AbstractSource;", "Lokio/Source;", "Lokhttp3/HttpUrl;", "url", "<init>", "(Lokhttp3/internal/http1/Http1ExchangeCodec;Lokhttp3/HttpUrl;)V", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", "Lokio/Buffer;", "sink", StringUtils.EMPTY, "byteCount", "k3", "(Lokio/Buffer;J)J", "Lokhttp3/Headers;", "trailers", StringUtils.EMPTY, "k", "(Lokhttp3/Headers;)V", "a", "Lokhttp3/HttpUrl;", "getUrl", "()Lokhttp3/HttpUrl;", "Lokio/ForwardingTimeout;", "b", "Lokio/ForwardingTimeout;", "getTimeout", "()Lokio/ForwardingTimeout;", StringUtils.EMPTY, "c", "Z", "j", "()Z", "o", "(Z)V", "closed", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private abstract class AbstractSource implements Source {
        private final HttpUrl a;
        private final ForwardingTimeout b;
        private boolean c;
        final /* synthetic */ Http1ExchangeCodec d;

        public AbstractSource(Http1ExchangeCodec http1ExchangeCodec, HttpUrl httpUrl) {
            Intrinsics.checkNotNullParameter(httpUrl, ap.a(2081450090));
            this.d = http1ExchangeCodec;
            this.a = httpUrl;
            this.b = new ForwardingTimeout(http1ExchangeCodec.c.timeout());
        }

        protected final boolean j() {
            return this.c;
        }

        public final void k(Headers headers) {
            OkHttpClient okHttpClient;
            CookieJar cookieJarO;
            Intrinsics.checkNotNullParameter(headers, "trailers");
            if (this.d.e == 6) {
                return;
            }
            if (this.d.e != 5) {
                throw new IllegalStateException("state: " + this.d.e);
            }
            this.d.s(this.b);
            this.d.g = headers;
            this.d.e = 6;
            if (headers.size() <= 0 || (okHttpClient = this.d.a) == null || (cookieJarO = okHttpClient.o()) == null) {
                return;
            }
            HttpHeaders.f(cookieJarO, this.a, headers);
        }

        @Override // okio.Source
        public long k3(Buffer buffer, long j) throws IOException {
            Intrinsics.checkNotNullParameter(buffer, "sink");
            try {
                return this.d.c.k3(buffer, j);
            } catch (IOException e) {
                this.d.i().c();
                this.k(Http1ExchangeCodec.i);
                throw e;
            }
        }

        protected final void o(boolean z) {
            this.c = z;
        }

        @Override // okio.Source
        public Timeout timeout() {
            return this.b;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0006J\u001f\u0010\f\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b\f\u0010\rJ\u000f\u0010\u000e\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0010\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u0010\u0010\u000fR\u0014\u0010\u0005\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010\u0013R\u0016\u0010\u0017\u001a\u00020\u00148\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0015\u0010\u0016¨\u0006\u0018"}, d2 = {"Lokhttp3/internal/http1/Http1ExchangeCodec$ChunkedSink;", "Lokio/Sink;", "<init>", "(Lokhttp3/internal/http1/Http1ExchangeCodec;)V", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", "Lokio/Buffer;", ClimateForcast.SOURCE, StringUtils.EMPTY, "byteCount", StringUtils.EMPTY, "a2", "(Lokio/Buffer;J)V", "flush", "()V", "close", "Lokio/ForwardingTimeout;", "a", "Lokio/ForwardingTimeout;", StringUtils.EMPTY, "b", "Z", "closed", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nHttp1ExchangeCodec.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http1ExchangeCodec.kt\nokhttp3/internal/http1/Http1ExchangeCodec$ChunkedSink\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,561:1\n1#2:562\n*E\n"})
    private final class ChunkedSink implements Sink {
        private final ForwardingTimeout a;
        private boolean b;

        public ChunkedSink() {
            this.a = new ForwardingTimeout(Http1ExchangeCodec.this.d.timeout());
        }

        @Override // okio.Sink
        public void a2(Buffer buffer, long j) {
            Intrinsics.checkNotNullParameter(buffer, ap.a(155102380));
            if (this.b) {
                throw new IllegalStateException(ap.a(1083367382));
            }
            if (j == 0) {
                return;
            }
            Http1ExchangeCodec.this.d.b1(j);
            BufferedSink bufferedSink = Http1ExchangeCodec.this.d;
            String strA = ap.a(610510419);
            bufferedSink.V1(strA);
            Http1ExchangeCodec.this.d.a2(buffer, j);
            Http1ExchangeCodec.this.d.V1(strA);
        }

        @Override // okio.Sink, java.io.Closeable, java.lang.AutoCloseable
        public synchronized void close() {
            if (this.b) {
                return;
            }
            this.b = true;
            Http1ExchangeCodec.this.d.V1("0\r\n\r\n");
            Http1ExchangeCodec.this.s(this.a);
            Http1ExchangeCodec.this.e = 3;
        }

        @Override // okio.Sink, java.io.Flushable
        public synchronized void flush() {
            if (this.b) {
                return;
            }
            Http1ExchangeCodec.this.d.flush();
        }

        @Override // okio.Sink
        public Timeout timeout() {
            return this.a;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u00060\u0001R\u00020\u0002B\u000f\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\u000f\u0010\b\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\b\u0010\tJ\u001f\u0010\u000e\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0010\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0010\u0010\tR\u0016\u0010\u0013\u001a\u00020\f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0011\u0010\u0012R\u0016\u0010\u0017\u001a\u00020\u00148\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0015\u0010\u0016¨\u0006\u0018"}, d2 = {"Lokhttp3/internal/http1/Http1ExchangeCodec$ChunkedSource;", "Lokhttp3/internal/http1/Http1ExchangeCodec$AbstractSource;", "Lokhttp3/internal/http1/Http1ExchangeCodec;", "Lokhttp3/HttpUrl;", "url", "<init>", "(Lokhttp3/internal/http1/Http1ExchangeCodec;Lokhttp3/HttpUrl;)V", StringUtils.EMPTY, "q", "()V", "Lokio/Buffer;", "sink", StringUtils.EMPTY, "byteCount", "k3", "(Lokio/Buffer;J)J", "close", "e", "J", "bytesRemainingInChunk", StringUtils.EMPTY, "f", "Z", "hasMoreChunks", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nHttp1ExchangeCodec.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http1ExchangeCodec.kt\nokhttp3/internal/http1/Http1ExchangeCodec$ChunkedSource\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,561:1\n1#2:562\n*E\n"})
    private final class ChunkedSource extends AbstractSource {
        private long e;
        private boolean f;
        final /* synthetic */ Http1ExchangeCodec g;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public ChunkedSource(Http1ExchangeCodec http1ExchangeCodec, HttpUrl httpUrl) {
            super(http1ExchangeCodec, httpUrl);
            Intrinsics.checkNotNullParameter(httpUrl, ap.a(2025295176));
            this.g = http1ExchangeCodec;
            this.e = -1L;
            this.f = true;
        }

        private final void q() throws ProtocolException {
            if (this.e != -1) {
                this.g.c.j2();
            }
            try {
                this.e = this.g.c.s1();
                String string = StringsKt.trim((CharSequence) this.g.c.j2()).toString();
                if (this.e >= 0 && (string.length() <= 0 || StringsKt.startsWith$default(string, ";", false, 2, (Object) null))) {
                    if (this.e == 0) {
                        this.f = false;
                        k(this.g.f.a());
                        return;
                    }
                    return;
                }
                throw new ProtocolException("expected chunk size and optional extensions but was \"" + this.e + string + '\"');
            } catch (NumberFormatException e) {
                throw new ProtocolException(e.getMessage());
            }
        }

        @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (j()) {
                return;
            }
            if (this.f && !_UtilJvmKt.i(this, 100, TimeUnit.MILLISECONDS)) {
                this.g.i().c();
                k(Http1ExchangeCodec.i);
            }
            o(true);
        }

        @Override // okhttp3.internal.http1.Http1ExchangeCodec.AbstractSource, okio.Source
        public long k3(Buffer buffer, long j) throws IOException {
            Intrinsics.checkNotNullParameter(buffer, "sink");
            if (j < 0) {
                throw new IllegalArgumentException(("byteCount < 0: " + j).toString());
            }
            if (j()) {
                throw new IllegalStateException("closed");
            }
            if (!this.f) {
                return -1L;
            }
            long j2 = this.e;
            if (j2 == 0 || j2 == -1) {
                q();
                if (!this.f) {
                    return -1L;
                }
            }
            long jK3 = super.k3(buffer, Math.min(j, this.e));
            if (jK3 != -1) {
                this.e -= jK3;
                return jK3;
            }
            this.g.i().c();
            ProtocolException protocolException = new ProtocolException("unexpected end of stream");
            k(Http1ExchangeCodec.i);
            throw protocolException;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0010\b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u0006\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\b\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\n\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u000b\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\f\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\r\u001a\u00020\u0007X\u0082T¢\u0006\u0002\n\u0000R\u000e\u0010\u000e\u001a\u00020\u000fX\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0010"}, d2 = {"Lokhttp3/internal/http1/Http1ExchangeCodec$Companion;", StringUtils.EMPTY, "<init>", "()V", "NO_CHUNK_YET", StringUtils.EMPTY, "STATE_IDLE", StringUtils.EMPTY, "STATE_OPEN_REQUEST_BODY", "STATE_WRITING_REQUEST_BODY", "STATE_READ_RESPONSE_HEADERS", "STATE_OPEN_RESPONSE_BODY", "STATE_READING_RESPONSE_BODY", "STATE_CLOSED", "TRAILERS_RESPONSE_BODY_TRUNCATED", "Lokhttp3/Headers;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0005\b\u0082\u0004\u0018\u00002\u00060\u0001R\u00020\u0002B\u0017\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u001f\u0010\f\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\f\u0010\rJ\u000f\u0010\u000f\u001a\u00020\u000eH\u0016¢\u0006\u0004\b\u000f\u0010\u0010R\u0016\u0010\u0006\u001a\u00020\u00058\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0011\u0010\u0012¨\u0006\u0013"}, d2 = {"Lokhttp3/internal/http1/Http1ExchangeCodec$FixedLengthSource;", "Lokhttp3/internal/http1/Http1ExchangeCodec$AbstractSource;", "Lokhttp3/internal/http1/Http1ExchangeCodec;", "Lokhttp3/HttpUrl;", "url", StringUtils.EMPTY, "bytesRemaining", "<init>", "(Lokhttp3/internal/http1/Http1ExchangeCodec;Lokhttp3/HttpUrl;J)V", "Lokio/Buffer;", "sink", "byteCount", "k3", "(Lokio/Buffer;J)J", StringUtils.EMPTY, "close", "()V", "e", "J", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nHttp1ExchangeCodec.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http1ExchangeCodec.kt\nokhttp3/internal/http1/Http1ExchangeCodec$FixedLengthSource\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,561:1\n1#2:562\n*E\n"})
    private final class FixedLengthSource extends AbstractSource {
        private long e;
        final /* synthetic */ Http1ExchangeCodec f;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public FixedLengthSource(Http1ExchangeCodec http1ExchangeCodec, HttpUrl httpUrl, long j) {
            super(http1ExchangeCodec, httpUrl);
            Intrinsics.checkNotNullParameter(httpUrl, ap.a(1754918617));
            this.f = http1ExchangeCodec;
            this.e = j;
            if (j == 0) {
                k(Headers.c);
            }
        }

        @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (j()) {
                return;
            }
            if (this.e != 0 && !_UtilJvmKt.i(this, 100, TimeUnit.MILLISECONDS)) {
                this.f.i().c();
                k(Http1ExchangeCodec.i);
            }
            o(true);
        }

        @Override // okhttp3.internal.http1.Http1ExchangeCodec.AbstractSource, okio.Source
        public long k3(Buffer buffer, long j) throws IOException {
            Intrinsics.checkNotNullParameter(buffer, "sink");
            if (j < 0) {
                throw new IllegalArgumentException(("byteCount < 0: " + j).toString());
            }
            if (j()) {
                throw new IllegalStateException("closed");
            }
            long j2 = this.e;
            if (j2 == 0) {
                return -1L;
            }
            long jK3 = super.k3(buffer, Math.min(j2, j));
            if (jK3 == -1) {
                this.f.i().c();
                ProtocolException protocolException = new ProtocolException("unexpected end of stream");
                k(Http1ExchangeCodec.i);
                throw protocolException;
            }
            long j3 = this.e - jK3;
            this.e = j3;
            if (j3 == 0) {
                k(Headers.c);
            }
            return jK3;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0005\u0010\u0006J\u001f\u0010\f\u001a\u00020\u000b2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b\f\u0010\rJ\u000f\u0010\u000e\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0010\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u0010\u0010\u000fR\u0014\u0010\u0005\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010\u0013R\u0016\u0010\u0017\u001a\u00020\u00148\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0015\u0010\u0016¨\u0006\u0018"}, d2 = {"Lokhttp3/internal/http1/Http1ExchangeCodec$KnownLengthSink;", "Lokio/Sink;", "<init>", "(Lokhttp3/internal/http1/Http1ExchangeCodec;)V", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", "Lokio/Buffer;", ClimateForcast.SOURCE, StringUtils.EMPTY, "byteCount", StringUtils.EMPTY, "a2", "(Lokio/Buffer;J)V", "flush", "()V", "close", "Lokio/ForwardingTimeout;", "a", "Lokio/ForwardingTimeout;", StringUtils.EMPTY, "b", "Z", "closed", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nHttp1ExchangeCodec.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http1ExchangeCodec.kt\nokhttp3/internal/http1/Http1ExchangeCodec$KnownLengthSink\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,561:1\n1#2:562\n*E\n"})
    private final class KnownLengthSink implements Sink {
        private final ForwardingTimeout a;
        private boolean b;

        public KnownLengthSink() {
            this.a = new ForwardingTimeout(Http1ExchangeCodec.this.d.timeout());
        }

        @Override // okio.Sink
        public void a2(Buffer buffer, long j) {
            Intrinsics.checkNotNullParameter(buffer, ap.a(1206329036));
            if (this.b) {
                throw new IllegalStateException(ap.a(53179460));
            }
            _UtilCommonKt.e(buffer.size(), 0L, j);
            Http1ExchangeCodec.this.d.a2(buffer, j);
        }

        @Override // okio.Sink, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (this.b) {
                return;
            }
            this.b = true;
            Http1ExchangeCodec.this.s(this.a);
            Http1ExchangeCodec.this.e = 3;
        }

        @Override // okio.Sink, java.io.Flushable
        public void flush() {
            if (this.b) {
                return;
            }
            Http1ExchangeCodec.this.d.flush();
        }

        @Override // okio.Sink
        public Timeout timeout() {
            return this.a;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\b\u0082\u0004\u0018\u00002\u00060\u0001R\u00020\u0002B\u000f\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J\u001f\u0010\u000b\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\u000e\u001a\u00020\rH\u0016¢\u0006\u0004\b\u000e\u0010\u000fR\u0016\u0010\u0013\u001a\u00020\u00108\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0011\u0010\u0012¨\u0006\u0014"}, d2 = {"Lokhttp3/internal/http1/Http1ExchangeCodec$UnknownLengthSource;", "Lokhttp3/internal/http1/Http1ExchangeCodec$AbstractSource;", "Lokhttp3/internal/http1/Http1ExchangeCodec;", "Lokhttp3/HttpUrl;", "url", "<init>", "(Lokhttp3/internal/http1/Http1ExchangeCodec;Lokhttp3/HttpUrl;)V", "Lokio/Buffer;", "sink", StringUtils.EMPTY, "byteCount", "k3", "(Lokio/Buffer;J)J", StringUtils.EMPTY, "close", "()V", StringUtils.EMPTY, "e", "Z", "inputExhausted", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nHttp1ExchangeCodec.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http1ExchangeCodec.kt\nokhttp3/internal/http1/Http1ExchangeCodec$UnknownLengthSource\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,561:1\n1#2:562\n*E\n"})
    private final class UnknownLengthSource extends AbstractSource {
        private boolean e;
        final /* synthetic */ Http1ExchangeCodec f;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public UnknownLengthSource(Http1ExchangeCodec http1ExchangeCodec, HttpUrl httpUrl) {
            super(http1ExchangeCodec, httpUrl);
            Intrinsics.checkNotNullParameter(httpUrl, ap.a(1251624060));
            this.f = http1ExchangeCodec;
        }

        @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (j()) {
                return;
            }
            if (!this.e) {
                k(Http1ExchangeCodec.i);
            }
            o(true);
        }

        @Override // okhttp3.internal.http1.Http1ExchangeCodec.AbstractSource, okio.Source
        public long k3(Buffer buffer, long j) throws IOException {
            Intrinsics.checkNotNullParameter(buffer, "sink");
            if (j < 0) {
                throw new IllegalArgumentException(("byteCount < 0: " + j).toString());
            }
            if (j()) {
                throw new IllegalStateException("closed");
            }
            if (this.e) {
                return -1L;
            }
            long jK3 = super.k3(buffer, j);
            if (jK3 != -1) {
                return jK3;
            }
            this.e = true;
            k(Headers.c);
            return -1L;
        }
    }

    public Http1ExchangeCodec(OkHttpClient okHttpClient, ExchangeCodec.Carrier carrier, BufferedSource bufferedSource, BufferedSink bufferedSink) {
        Intrinsics.checkNotNullParameter(carrier, "carrier");
        Intrinsics.checkNotNullParameter(bufferedSource, ClimateForcast.SOURCE);
        Intrinsics.checkNotNullParameter(bufferedSink, "sink");
        this.a = okHttpClient;
        this.b = carrier;
        this.c = bufferedSource;
        this.d = bufferedSink;
        this.f = new HeadersReader(bufferedSource);
    }

    private final void s(ForwardingTimeout forwardingTimeout) {
        Timeout timeoutK = forwardingTimeout.k();
        forwardingTimeout.l(Timeout.f);
        timeoutK.b();
        timeoutK.c();
    }

    private final boolean t(Request request) {
        return StringsKt.equals("chunked", request.e("Transfer-Encoding"), true);
    }

    private final boolean u(Response response) {
        return StringsKt.equals("chunked", Response.D(response, "Transfer-Encoding", null, 2, null), true);
    }

    private final Sink v() {
        if (this.e == 1) {
            this.e = 2;
            return new ChunkedSink();
        }
        throw new IllegalStateException(("state: " + this.e).toString());
    }

    private final Source w(HttpUrl httpUrl) {
        if (this.e == 4) {
            this.e = 5;
            return new ChunkedSource(this, httpUrl);
        }
        throw new IllegalStateException(("state: " + this.e).toString());
    }

    private final Source x(HttpUrl httpUrl, long j) {
        if (this.e == 4) {
            this.e = 5;
            return new FixedLengthSource(this, httpUrl, j);
        }
        throw new IllegalStateException(("state: " + this.e).toString());
    }

    private final Sink y() {
        if (this.e == 1) {
            this.e = 2;
            return new KnownLengthSink();
        }
        throw new IllegalStateException(("state: " + this.e).toString());
    }

    private final Source z(HttpUrl httpUrl) {
        if (this.e == 4) {
            this.e = 5;
            i().c();
            return new UnknownLengthSource(this, httpUrl);
        }
        throw new IllegalStateException(("state: " + this.e).toString());
    }

    public final void A(Response response) {
        Intrinsics.checkNotNullParameter(response, "response");
        long jK = _UtilJvmKt.k(response);
        if (jK == -1) {
            return;
        }
        Source sourceX = x(response.b0().m(), jK);
        _UtilJvmKt.o(sourceX, Integer.MAX_VALUE, TimeUnit.MILLISECONDS);
        sourceX.close();
    }

    public final void B(Headers headers, String str) {
        Intrinsics.checkNotNullParameter(headers, "headers");
        Intrinsics.checkNotNullParameter(str, "requestLine");
        if (this.e != 0) {
            throw new IllegalStateException(("state: " + this.e).toString());
        }
        this.d.V1(str).V1("\r\n");
        int size = headers.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.d.V1(headers.e(i2)).V1(": ").V1(headers.k(i2)).V1("\r\n");
        }
        this.d.V1("\r\n");
        this.e = 1;
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public Source a(Response response) {
        Intrinsics.checkNotNullParameter(response, "response");
        if (!HttpHeaders.b(response)) {
            return x(response.b0().m(), 0L);
        }
        if (u(response)) {
            return w(response.b0().m());
        }
        long jK = _UtilJvmKt.k(response);
        return jK != -1 ? x(response.b0().m(), jK) : z(response.b0().m());
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public Sink b(Request request, long j) throws ProtocolException {
        Intrinsics.checkNotNullParameter(request, "request");
        RequestBody requestBodyA = request.a();
        if (requestBodyA != null && requestBodyA.f()) {
            throw new ProtocolException("Duplex connections are not supported for HTTP/1");
        }
        if (t(request)) {
            return v();
        }
        if (j != -1) {
            return y();
        }
        throw new IllegalStateException("Cannot stream a request body without chunked encoding or a known content length!");
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public void c() {
        this.d.flush();
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public void cancel() {
        i().cancel();
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public void d() {
        this.d.flush();
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public long e(Response response) {
        Intrinsics.checkNotNullParameter(response, "response");
        if (!HttpHeaders.b(response)) {
            return 0L;
        }
        if (u(response)) {
            return -1L;
        }
        return _UtilJvmKt.k(response);
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public void f(Request request) {
        Intrinsics.checkNotNullParameter(request, "request");
        RequestLine requestLine = RequestLine.a;
        Proxy.Type type = i().e().b().type();
        Intrinsics.checkNotNullExpressionValue(type, "type(...)");
        B(request.g(), requestLine.a(request, type));
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public boolean g() {
        return this.e == 6;
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public Response.Builder h(boolean z) {
        int i2 = this.e;
        if (i2 != 0 && i2 != 1 && i2 != 2 && i2 != 3) {
            throw new IllegalStateException(("state: " + this.e).toString());
        }
        try {
            StatusLine statusLineA = StatusLine.d.a(this.f.b());
            Response.Builder builderJ = new Response.Builder().o(statusLineA.a).f(statusLineA.b).l(statusLineA.c).j(this.f.a());
            if (z && statusLineA.b == 100) {
                return null;
            }
            int i3 = statusLineA.b;
            if (i3 == 100) {
                this.e = 3;
                return builderJ;
            }
            if (102 > i3 || i3 >= 200) {
                this.e = 4;
                return builderJ;
            }
            this.e = 3;
            return builderJ;
        } catch (EOFException e) {
            throw new IOException("unexpected end of stream on " + i().e().a().l().q(), e);
        }
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public ExchangeCodec.Carrier i() {
        return this.b;
    }
}