package okhttp3.internal;

import h.ap;
import java.text.Normalizer;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\b\n\u0002\u0010\u000e\n\u0002\b\u0004\u001a\u0017\u0010\u0002\u001a\u00020\u00002\u0006\u0010\u0001\u001a\u00020\u0000H\u0000¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {StringUtils.EMPTY, "string", "a", "(Ljava/lang/String;)Ljava/lang/String;", "okhttp"}, k = 2, mv = {2, 2, 0}, xi = 48)
public final class _NormalizeJvmKt {
    public static final String a(String str) {
        Intrinsics.checkNotNullParameter(str, ap.a(1920628121));
        String strNormalize = Normalizer.normalize(str, Normalizer.Form.NFC);
        Intrinsics.checkNotNullExpressionValue(strNormalize, ap.a(1026512985));
        return strNormalize;
    }
}