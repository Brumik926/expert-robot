package okhttp3.internal;

import h.ap;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import kotlin.ExceptionsKt;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.ArrayIteratorKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import kotlinx.coroutines.scheduling.WorkQueueKt;
import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.ByteString;
import okio.FileSystem;
import okio.Options;
import okio.Path;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000²\u0001\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u000e\n\u0002\u0010\f\n\u0002\b\n\n\u0002\u0010\u0005\n\u0002\b\u0003\n\u0002\u0010\n\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010!\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010 \n\u0000\n\u0002\u0010\u0003\n\u0002\b\b\n\u0002\u0010\u001c\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u001aI\u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00010\u0000*\b\u0012\u0004\u0012\u00020\u00010\u00002\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00020\u00010\u00002\u001a\u0010\u0005\u001a\u0016\u0012\u0006\b\u0000\u0012\u00020\u00010\u0003j\n\u0012\u0006\b\u0000\u0012\u00020\u0001`\u0004H\u0000¢\u0006\u0004\b\u0006\u0010\u0007\u001aE\u0010\t\u001a\u00020\b*\b\u0012\u0004\u0012\u00020\u00010\u00002\u000e\u0010\u0002\u001a\n\u0012\u0004\u0012\u00020\u0001\u0018\u00010\u00002\u001a\u0010\u0005\u001a\u0016\u0012\u0006\b\u0000\u0012\u00020\u00010\u0003j\n\u0012\u0006\b\u0000\u0012\u00020\u0001`\u0004H\u0000¢\u0006\u0004\b\t\u0010\n\u001a9\u0010\r\u001a\u00020\f*\b\u0012\u0004\u0012\u00020\u00010\u00002\u0006\u0010\u000b\u001a\u00020\u00012\u0016\u0010\u0005\u001a\u0012\u0012\u0004\u0012\u00020\u00010\u0003j\b\u0012\u0004\u0012\u00020\u0001`\u0004H\u0000¢\u0006\u0004\b\r\u0010\u000e\u001a'\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u00010\u0000*\b\u0012\u0004\u0012\u00020\u00010\u00002\u0006\u0010\u000b\u001a\u00020\u0001H\u0000¢\u0006\u0004\b\u000f\u0010\u0010\u001a'\u0010\u0013\u001a\u00020\f*\u00020\u00012\b\b\u0002\u0010\u0011\u001a\u00020\f2\b\b\u0002\u0010\u0012\u001a\u00020\fH\u0000¢\u0006\u0004\b\u0013\u0010\u0014\u001a'\u0010\u0015\u001a\u00020\f*\u00020\u00012\b\b\u0002\u0010\u0011\u001a\u00020\f2\b\b\u0002\u0010\u0012\u001a\u00020\fH\u0000¢\u0006\u0004\b\u0015\u0010\u0014\u001a%\u0010\u0016\u001a\u00020\u0001*\u00020\u00012\b\b\u0002\u0010\u0011\u001a\u00020\f2\b\b\u0002\u0010\u0012\u001a\u00020\f¢\u0006\u0004\b\u0016\u0010\u0017\u001a-\u0010\u0019\u001a\u00020\f*\u00020\u00012\u0006\u0010\u0018\u001a\u00020\u00012\b\b\u0002\u0010\u0011\u001a\u00020\f2\b\b\u0002\u0010\u0012\u001a\u00020\f¢\u0006\u0004\b\u0019\u0010\u001a\u001a-\u0010\u001d\u001a\u00020\f*\u00020\u00012\u0006\u0010\u001c\u001a\u00020\u001b2\b\b\u0002\u0010\u0011\u001a\u00020\f2\b\b\u0002\u0010\u0012\u001a\u00020\f¢\u0006\u0004\b\u001d\u0010\u001e\u001a\u0013\u0010\u001f\u001a\u00020\f*\u00020\u0001H\u0000¢\u0006\u0004\b\u001f\u0010 \u001a\u0017\u0010\"\u001a\u00020\b2\u0006\u0010!\u001a\u00020\u0001H\u0000¢\u0006\u0004\b\"\u0010#\u001a\u0013\u0010$\u001a\u00020\f*\u00020\u001bH\u0000¢\u0006\u0004\b$\u0010%\u001a\u001c\u0010(\u001a\u00020\f*\u00020&2\u0006\u0010'\u001a\u00020\fH\u0080\u0004¢\u0006\u0004\b(\u0010)\u001a\u001c\u0010+\u001a\u00020\f*\u00020*2\u0006\u0010'\u001a\u00020\fH\u0080\u0004¢\u0006\u0004\b+\u0010,\u001a\u001c\u0010.\u001a\u00020-*\u00020\f2\u0006\u0010'\u001a\u00020-H\u0080\u0004¢\u0006\u0004\b.\u0010/\u001a\u001b\u00103\u001a\u000202*\u0002002\u0006\u00101\u001a\u00020\fH\u0000¢\u0006\u0004\b3\u00104\u001a\u0013\u00106\u001a\u00020\f*\u000205H\u0000¢\u0006\u0004\b6\u00107\u001a\u001b\u00109\u001a\u00020\f*\u0002082\u0006\u0010(\u001a\u00020&H\u0000¢\u0006\u0004\b9\u0010:\u001a\u001d\u0010;\u001a\u00020\f*\u00020\u00012\b\b\u0002\u0010\u0011\u001a\u00020\fH\u0000¢\u0006\u0004\b;\u0010<\u001a\u0019\u0010>\u001a\u00020-*\u00020\u00012\u0006\u0010=\u001a\u00020-¢\u0006\u0004\b>\u0010?\u001a\u001d\u0010@\u001a\u00020\f*\u0004\u0018\u00010\u00012\u0006\u0010=\u001a\u00020\fH\u0000¢\u0006\u0004\b@\u0010<\u001a\u0015\u0010C\u001a\u000202*\u00060Aj\u0002`B¢\u0006\u0004\bC\u0010D\u001a\u001b\u0010H\u001a\u00020\b*\u00020E2\u0006\u0010G\u001a\u00020FH\u0000¢\u0006\u0004\bH\u0010I\u001a\u001b\u0010K\u001a\u000202*\u00020E2\u0006\u0010J\u001a\u00020FH\u0000¢\u0006\u0004\bK\u0010L\u001a\u001b\u0010N\u001a\u000202*\u00020E2\u0006\u0010M\u001a\u00020FH\u0000¢\u0006\u0004\bN\u0010L\u001a'\u0010Q\u001a\u000202\"\u0004\b\u0000\u0010\u0016*\b\u0012\u0004\u0012\u00028\u00000O2\u0006\u0010P\u001a\u00028\u0000H\u0000¢\u0006\u0004\bQ\u0010R\u001a)\u0010X\u001a\u00020W*\u00060Sj\u0002`T2\u0010\u0010V\u001a\f\u0012\b\u0012\u00060Sj\u0002`T0UH\u0000¢\u0006\u0004\bX\u0010Y\u001a'\u0010]\u001a\u0002022\u0006\u0010Z\u001a\u00020-2\u0006\u0010[\u001a\u00020-2\u0006\u0010\\\u001a\u00020-H\u0000¢\u0006\u0004\b]\u0010^\u001a7\u0010a\u001a\b\u0012\u0004\u0012\u00028\u00000U\"\u0004\b\u0000\u0010_2\f\u0010Q\u001a\b\u0012\u0004\u0012\u00028\u00000`2\f\u0010(\u001a\b\u0012\u0004\u0012\u00028\u00000`H\u0000¢\u0006\u0004\ba\u0010b\"\u0014\u0010e\u001a\u00020c8\u0000X\u0081\u0004¢\u0006\u0006\n\u0004\bQ\u0010d\"\u001a\u0010j\u001a\u00020f8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b(\u0010g\u001a\u0004\bh\u0010i¨\u0006k"}, d2 = {StringUtils.EMPTY, StringUtils.EMPTY, "other", "Ljava/util/Comparator;", "Lkotlin/Comparator;", "comparator", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "([Ljava/lang/String;[Ljava/lang/String;Ljava/util/Comparator;)[Ljava/lang/String;", StringUtils.EMPTY, "n", "([Ljava/lang/String;[Ljava/lang/String;Ljava/util/Comparator;)Z", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, StringUtils.EMPTY, "o", "([Ljava/lang/String;Ljava/lang/String;Ljava/util/Comparator;)I", "g", "([Ljava/lang/String;Ljava/lang/String;)[Ljava/lang/String;", "startIndex", "endIndex", "q", "(Ljava/lang/String;II)I", "s", "E", "(Ljava/lang/String;II)Ljava/lang/String;", "delimiters", "k", "(Ljava/lang/String;Ljava/lang/String;II)I", StringUtils.EMPTY, "delimiter", "j", "(Ljava/lang/String;CII)I", "p", "(Ljava/lang/String;)I", "name", "y", "(Ljava/lang/String;)Z", "z", "(C)I", StringUtils.EMPTY, MimeTypesReaderMetKeys.MATCH_MASK_ATTR, "b", "(BI)I", StringUtils.EMPTY, "c", "(SI)I", StringUtils.EMPTY, "d", "(IJ)J", "Lokio/BufferedSink;", "medium", StringUtils.EMPTY, "H", "(Lokio/BufferedSink;I)V", "Lokio/BufferedSource;", "A", "(Lokio/BufferedSource;)I", "Lokio/Buffer;", "B", "(Lokio/Buffer;B)I", "u", "(Ljava/lang/String;I)I", "defaultValue", "C", "(Ljava/lang/String;J)J", "D", "Ljava/io/Closeable;", "Lokio/Closeable;", "f", "(Ljava/io/Closeable;)V", "Lokio/FileSystem;", "Lokio/Path;", "file", "x", "(Lokio/FileSystem;Lokio/Path;)Z", "path", "i", "(Lokio/FileSystem;Lokio/Path;)V", "directory", "h", StringUtils.EMPTY, "element", "a", "(Ljava/util/List;Ljava/lang/Object;)V", "Ljava/lang/Exception;", "Lkotlin/Exception;", StringUtils.EMPTY, "suppressed", StringUtils.EMPTY, "G", "(Ljava/lang/Exception;Ljava/util/List;)Ljava/lang/Throwable;", "arrayLength", MimeTypesReaderMetKeys.MATCH_OFFSET_ATTR, "count", "e", "(JJJ)V", "T", StringUtils.EMPTY, "v", "(Ljava/lang/Iterable;Ljava/lang/Iterable;)Ljava/util/List;", StringUtils.EMPTY, "[B", "EMPTY_BYTE_ARRAY", "Lokio/Options;", "Lokio/Options;", "m", "()Lokio/Options;", "UNICODE_BOMS", "okhttp"}, k = 2, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\n-UtilCommon.kt\nKotlin\n*S Kotlin\n*F\n+ 1 -UtilCommon.kt\nokhttp3/internal/_UtilCommonKt\n+ 2 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 3 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n+ 4 Okio.kt\nokio/Okio__OkioKt\n*L\n1#1,400:1\n37#2:401\n36#2,3:402\n1682#3,6:405\n72#4:411\n58#4,22:412\n*S KotlinDebug\n*F\n+ 1 -UtilCommon.kt\nokhttp3/internal/_UtilCommonKt\n*L\n68#1:401\n68#1:402,3\n97#1:405,6\n303#1:411\n303#1:412,22\n*E\n"})
public final class _UtilCommonKt {
    public static final byte[] a = new byte[0];
    private static final Options b;

    static {
        Options.Companion companion = Options.c;
        ByteString.Companion companion2 = ByteString.d;
        b = companion.d(companion2.b(ap.a(737762235)), companion2.b(ap.a(1262580621)), companion2.b(ap.a(1945089836)), companion2.b(ap.a(1942627701)), companion2.b(ap.a(450158023)));
    }

    public static final int A(BufferedSource bufferedSource) {
        Intrinsics.checkNotNullParameter(bufferedSource, "<this>");
        return b(bufferedSource.readByte(), 255) | (b(bufferedSource.readByte(), 255) << 16) | (b(bufferedSource.readByte(), 255) << 8);
    }

    public static final int B(Buffer buffer, byte b2) {
        Intrinsics.checkNotNullParameter(buffer, "<this>");
        int i = 0;
        while (!buffer.H2() && buffer.B(0L) == b2) {
            i++;
            buffer.readByte();
        }
        return i;
    }

    public static final long C(String str, long j) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        try {
            return Long.parseLong(str);
        } catch (NumberFormatException unused) {
            return j;
        }
    }

    public static final int D(String str, int i) {
        if (str != null) {
            try {
                long j = Long.parseLong(str);
                if (j > 2147483647L) {
                    return Integer.MAX_VALUE;
                }
                if (j < 0) {
                    return 0;
                }
                return (int) j;
            } catch (NumberFormatException unused) {
            }
        }
        return i;
    }

    public static final String E(String str, int i, int i2) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        int iQ = q(str, i, i2);
        String strSubstring = str.substring(iQ, s(str, iQ, i2));
        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        return strSubstring;
    }

    public static /* synthetic */ String F(String str, int i, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i = 0;
        }
        if ((i3 & 2) != 0) {
            i2 = str.length();
        }
        return E(str, i, i2);
    }

    public static final Throwable G(Exception exc, List list) {
        Intrinsics.checkNotNullParameter(exc, "<this>");
        Intrinsics.checkNotNullParameter(list, "suppressed");
        Iterator it = list.iterator();
        while (it.hasNext()) {
            ExceptionsKt.addSuppressed(exc, (Exception) it.next());
        }
        return exc;
    }

    public static final void H(BufferedSink bufferedSink, int i) {
        Intrinsics.checkNotNullParameter(bufferedSink, "<this>");
        bufferedSink.writeByte((i >>> 16) & 255);
        bufferedSink.writeByte((i >>> 8) & 255);
        bufferedSink.writeByte(i & 255);
    }

    public static final void a(List list, Object obj) {
        Intrinsics.checkNotNullParameter(list, "<this>");
        if (list.contains(obj)) {
            return;
        }
        list.add(obj);
    }

    public static final int b(byte b2, int i) {
        return b2 & i;
    }

    public static final int c(short s, int i) {
        return s & i;
    }

    public static final long d(int i, long j) {
        return ((long) i) & j;
    }

    public static final void e(long j, long j2, long j3) {
        if ((j2 | j3) < 0 || j2 > j || j - j2 < j3) {
            throw new ArrayIndexOutOfBoundsException("length=" + j + ", offset=" + j2 + ", count=" + j2);
        }
    }

    public static final void f(Closeable closeable) {
        Intrinsics.checkNotNullParameter(closeable, "<this>");
        try {
            closeable.close();
        } catch (RuntimeException e) {
            throw e;
        } catch (Exception unused) {
        }
    }

    public static final String[] g(String[] strArr, String str) {
        Intrinsics.checkNotNullParameter(strArr, "<this>");
        Intrinsics.checkNotNullParameter(str, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
        Object[] objArrCopyOf = Arrays.copyOf(strArr, strArr.length + 1);
        Intrinsics.checkNotNullExpressionValue(objArrCopyOf, "copyOf(...)");
        String[] strArr2 = (String[]) objArrCopyOf;
        strArr2[ArraysKt.getLastIndex(strArr2)] = str;
        return strArr2;
    }

    public static final void h(FileSystem fileSystem, Path path) throws IOException {
        Intrinsics.checkNotNullParameter(fileSystem, "<this>");
        Intrinsics.checkNotNullParameter(path, "directory");
        try {
            IOException iOException = null;
            for (Path path2 : fileSystem.A(path)) {
                try {
                    if (fileSystem.D(path2).e()) {
                        h(fileSystem, path2);
                    }
                    fileSystem.q(path2);
                } catch (IOException e) {
                    if (iOException == null) {
                        iOException = e;
                    }
                }
            }
            if (iOException != null) {
                throw iOException;
            }
        } catch (FileNotFoundException unused) {
        }
    }

    public static final void i(FileSystem fileSystem, Path path) {
        Intrinsics.checkNotNullParameter(fileSystem, "<this>");
        Intrinsics.checkNotNullParameter(path, "path");
        try {
            fileSystem.q(path);
        } catch (FileNotFoundException unused) {
        }
    }

    public static final int j(String str, char c, int i, int i2) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        while (i < i2) {
            if (str.charAt(i) == c) {
                return i;
            }
            i++;
        }
        return i2;
    }

    public static final int k(String str, String str2, int i, int i2) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        Intrinsics.checkNotNullParameter(str2, "delimiters");
        while (i < i2) {
            if (StringsKt.contains$default((CharSequence) str2, str.charAt(i), false, 2, (Object) null)) {
                return i;
            }
            i++;
        }
        return i2;
    }

    public static /* synthetic */ int l(String str, char c, int i, int i2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i = 0;
        }
        if ((i3 & 4) != 0) {
            i2 = str.length();
        }
        return j(str, c, i, i2);
    }

    public static final Options m() {
        return b;
    }

    public static final boolean n(String[] strArr, String[] strArr2, Comparator comparator) {
        Intrinsics.checkNotNullParameter(strArr, "<this>");
        Intrinsics.checkNotNullParameter(comparator, "comparator");
        if (strArr.length != 0 && strArr2 != null && strArr2.length != 0) {
            for (String str : strArr) {
                Iterator it = ArrayIteratorKt.iterator(strArr2);
                while (it.hasNext()) {
                    if (comparator.compare(str, (String) it.next()) == 0) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public static final int o(String[] strArr, String str, Comparator comparator) {
        Intrinsics.checkNotNullParameter(strArr, "<this>");
        Intrinsics.checkNotNullParameter(str, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
        Intrinsics.checkNotNullParameter(comparator, "comparator");
        int length = strArr.length;
        for (int i = 0; i < length; i++) {
            if (comparator.compare(strArr[i], str) == 0) {
                return i;
            }
        }
        return -1;
    }

    public static final int p(String str) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char cCharAt = str.charAt(i);
            if (Intrinsics.compare(cCharAt, 31) <= 0 || Intrinsics.compare(cCharAt, WorkQueueKt.MASK) >= 0) {
                return i;
            }
        }
        return -1;
    }

    public static final int q(String str, int i, int i2) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        while (i < i2) {
            char cCharAt = str.charAt(i);
            if (cCharAt != '\t' && cCharAt != '\n' && cCharAt != '\f' && cCharAt != '\r' && cCharAt != ' ') {
                return i;
            }
            i++;
        }
        return i2;
    }

    public static /* synthetic */ int r(String str, int i, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i = 0;
        }
        if ((i3 & 2) != 0) {
            i2 = str.length();
        }
        return q(str, i, i2);
    }

    public static final int s(String str, int i, int i2) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        int i3 = i2 - 1;
        if (i <= i3) {
            while (true) {
                char cCharAt = str.charAt(i3);
                if (cCharAt != '\t' && cCharAt != '\n' && cCharAt != '\f' && cCharAt != '\r' && cCharAt != ' ') {
                    return i3 + 1;
                }
                if (i3 == i) {
                    break;
                }
                i3--;
            }
        }
        return i;
    }

    public static /* synthetic */ int t(String str, int i, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i = 0;
        }
        if ((i3 & 2) != 0) {
            i2 = str.length();
        }
        return s(str, i, i2);
    }

    public static final int u(String str, int i) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        int length = str.length();
        while (i < length) {
            char cCharAt = str.charAt(i);
            if (cCharAt != ' ' && cCharAt != '\t') {
                return i;
            }
            i++;
        }
        return str.length();
    }

    public static final List v(Iterable iterable, Iterable iterable2) {
        Intrinsics.checkNotNullParameter(iterable, "a");
        Intrinsics.checkNotNullParameter(iterable2, "b");
        Iterator it = iterable.iterator();
        Iterator it2 = iterable2.iterator();
        List listCreateListBuilder = CollectionsKt.createListBuilder();
        while (true) {
            if (!it.hasNext() && !it2.hasNext()) {
                return CollectionsKt.build(listCreateListBuilder);
            }
            if (it.hasNext()) {
                listCreateListBuilder.add(it.next());
            }
            if (it2.hasNext()) {
                listCreateListBuilder.add(it2.next());
            }
        }
    }

    public static final String[] w(String[] strArr, String[] strArr2, Comparator comparator) {
        Intrinsics.checkNotNullParameter(strArr, "<this>");
        Intrinsics.checkNotNullParameter(strArr2, "other");
        Intrinsics.checkNotNullParameter(comparator, "comparator");
        ArrayList arrayList = new ArrayList();
        for (String str : strArr) {
            int length = strArr2.length;
            int i = 0;
            while (true) {
                if (i >= length) {
                    break;
                }
                if (comparator.compare(str, strArr2[i]) == 0) {
                    arrayList.add(str);
                    break;
                }
                i++;
            }
        }
        return (String[]) arrayList.toArray(new String[0]);
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x0033  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0038  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final boolean x(okio.FileSystem r2, okio.Path r3) throws java.lang.Throwable {
        /*
            java.lang.String r0 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r0)
            java.lang.String r0 = "file"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r3, r0)
            okio.Sink r0 = r2.Q(r3)
            r2.q(r3)     // Catch: java.lang.Throwable -> L18 java.io.IOException -> L1a
            r2 = 1
            if (r0 == 0) goto L17
            r0.close()     // Catch: java.lang.Throwable -> L17
        L17:
            return r2
        L18:
            r1 = move-exception
            goto L26
        L1a:
            kotlin.Unit r1 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L18
            if (r0 == 0) goto L24
            r0.close()     // Catch: java.lang.Throwable -> L22
            goto L24
        L22:
            r0 = move-exception
            goto L31
        L24:
            r0 = 0
            goto L31
        L26:
            if (r0 == 0) goto L30
            r0.close()     // Catch: java.lang.Throwable -> L2c
            goto L30
        L2c:
            r0 = move-exception
            kotlin.ExceptionsKt.addSuppressed(r1, r0)
        L30:
            r0 = r1
        L31:
            if (r0 != 0) goto L38
            r2.q(r3)
            r2 = 0
            return r2
        L38:
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal._UtilCommonKt.x(okio.FileSystem, okio.Path):boolean");
    }

    public static final boolean y(String str) {
        Intrinsics.checkNotNullParameter(str, "name");
        return StringsKt.equals(str, "Authorization", true) || StringsKt.equals(str, "Cookie", true) || StringsKt.equals(str, "Proxy-Authorization", true) || StringsKt.equals(str, "Set-Cookie", true);
    }

    public static final int z(char c) {
        if ('0' <= c && c < ':') {
            return c - '0';
        }
        if ('a' <= c && c < 'g') {
            return c - 'W';
        }
        if ('A' > c || c >= 'G') {
            return -1;
        }
        return c - '7';
    }
}