package okhttp3.internal.http2;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal.http2.flowcontrol.WindowCounter;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\bf\u0018\u00002\u00020\u0001:\u0001\rJ'\u0010\t\u001a\u00020\b2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006H&¢\u0006\u0004\b\t\u0010\nJ\u0017\u0010\u000b\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u0004H&¢\u0006\u0004\b\u000b\u0010\f¨\u0006\u000eÀ\u0006\u0003"}, d2 = {"Lokhttp3/internal/http2/FlowControlListener;", StringUtils.EMPTY, StringUtils.EMPTY, "streamId", "Lokhttp3/internal/http2/flowcontrol/WindowCounter;", "windowCounter", StringUtils.EMPTY, "bufferSize", StringUtils.EMPTY, "a", "(ILokhttp3/internal/http2/flowcontrol/WindowCounter;J)V", "b", "(Lokhttp3/internal/http2/flowcontrol/WindowCounter;)V", OfficeOpenXMLExtended.SECURITY_NONE, "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public interface FlowControlListener {

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J'\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\bH\u0016¢\u0006\u0004\b\u000b\u0010\fJ\u0017\u0010\r\u001a\u00020\n2\u0006\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\r\u0010\u000e¨\u0006\u000f"}, d2 = {"Lokhttp3/internal/http2/FlowControlListener$None;", "Lokhttp3/internal/http2/FlowControlListener;", "<init>", "()V", StringUtils.EMPTY, "streamId", "Lokhttp3/internal/http2/flowcontrol/WindowCounter;", "windowCounter", StringUtils.EMPTY, "bufferSize", StringUtils.EMPTY, "a", "(ILokhttp3/internal/http2/flowcontrol/WindowCounter;J)V", "b", "(Lokhttp3/internal/http2/flowcontrol/WindowCounter;)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class None implements FlowControlListener {
        public static final None a = new None();

        private None() {
        }

        @Override // okhttp3.internal.http2.FlowControlListener
        public void a(int i, WindowCounter windowCounter, long j) {
            Intrinsics.checkNotNullParameter(windowCounter, ap.a(1374048666));
        }

        @Override // okhttp3.internal.http2.FlowControlListener
        public void b(WindowCounter windowCounter) {
            Intrinsics.checkNotNullParameter(windowCounter, "windowCounter");
        }
    }

    void a(int i, WindowCounter windowCounter, long j);

    void b(WindowCounter windowCounter);
}