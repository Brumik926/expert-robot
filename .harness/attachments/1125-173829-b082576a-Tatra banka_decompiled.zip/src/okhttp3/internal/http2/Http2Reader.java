package okhttp3.internal.http2;

import h.ap;
import java.io.Closeable;
import java.io.EOFException;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.http2.Hpack;
import okio.Buffer;
import okio.BufferedSource;
import okio.ByteString;
import okio.Source;
import okio.Timeout;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0017\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u0000 32\u00020\u0001:\u0003456B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J/\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J5\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00130\u00122\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0004\b\u0014\u0010\u0015J/\u0010\u0016\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0004\b\u0016\u0010\u0010J/\u0010\u0017\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0004\b\u0017\u0010\u0010J\u001f\u0010\u0018\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0004\b\u0018\u0010\u0019J/\u0010\u001a\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0004\b\u001a\u0010\u0010J/\u0010\u001b\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0004\b\u001b\u0010\u0010J/\u0010\u001c\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0004\b\u001c\u0010\u0010J/\u0010\u001d\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0004\b\u001d\u0010\u0010J/\u0010\u001e\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0004\b\u001e\u0010\u0010J/\u0010\u001f\u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\b2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\f\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\nH\u0002¢\u0006\u0004\b\u001f\u0010\u0010J\u0015\u0010 \u001a\u00020\u000e2\u0006\u0010\t\u001a\u00020\b¢\u0006\u0004\b \u0010!J\u001d\u0010#\u001a\u00020\u00042\u0006\u0010\"\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\b¢\u0006\u0004\b#\u0010$J\u000f\u0010%\u001a\u00020\u000eH\u0016¢\u0006\u0004\b%\u0010&R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b'\u0010(R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b)\u0010*R\u0014\u0010.\u001a\u00020+8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b,\u0010-R\u0014\u00102\u001a\u00020/8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b0\u00101¨\u00067"}, d2 = {"Lokhttp3/internal/http2/Http2Reader;", "Ljava/io/Closeable;", "Lokio/BufferedSource;", ClimateForcast.SOURCE, StringUtils.EMPTY, "client", "<init>", "(Lokio/BufferedSource;Z)V", "Lokhttp3/internal/http2/Http2Reader$Handler;", "handler", StringUtils.EMPTY, "length", "flags", "streamId", StringUtils.EMPTY, "A", "(Lokhttp3/internal/http2/Http2Reader$Handler;III)V", "padding", StringUtils.EMPTY, "Lokhttp3/internal/http2/Header;", "u", "(IIII)Ljava/util/List;", "q", "I", "D", "(Lokhttp3/internal/http2/Http2Reader$Handler;I)V", "O", "P", "J", "B", "r", "Q", "o", "(Lokhttp3/internal/http2/Http2Reader$Handler;)V", "requireSettings", "k", "(ZLokhttp3/internal/http2/Http2Reader$Handler;)Z", "close", "()V", "a", "Lokio/BufferedSource;", "b", "Z", "Lokhttp3/internal/http2/Http2Reader$ContinuationSource;", "c", "Lokhttp3/internal/http2/Http2Reader$ContinuationSource;", "continuation", "Lokhttp3/internal/http2/Hpack$Reader;", "d", "Lokhttp3/internal/http2/Hpack$Reader;", "hpackReader", "e", "ContinuationSource", "Handler", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Http2Reader implements Closeable {
    public static final Companion e = new Companion(null);
    private static final Logger f;
    private final BufferedSource a;
    private final boolean b;
    private final ContinuationSource c;
    private final Hpack.Reader d;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J%\u0010\b\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0004¢\u0006\u0004\b\b\u0010\tR\u0017\u0010\u000b\u001a\u00020\n8\u0006¢\u0006\f\n\u0004\b\u000b\u0010\f\u001a\u0004\b\r\u0010\u000e¨\u0006\u000f"}, d2 = {"Lokhttp3/internal/http2/Http2Reader$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "length", "flags", "padding", "b", "(III)I", "Ljava/util/logging/Logger;", "logger", "Ljava/util/logging/Logger;", "a", "()Ljava/util/logging/Logger;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final Logger a() {
            return Http2Reader.f;
        }

        public final int b(int i, int i2, int i3) throws IOException {
            if ((i2 & 8) != 0) {
                i--;
            }
            if (i3 <= i) {
                return i - i3;
            }
            throw new IOException(ap.a(1856663727) + i3 + ap.a(126914659) + i);
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0018\b\u0000\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0007\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\u0007\u0010\bJ\u001f\u0010\r\u001a\u00020\u000b2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\r\u0010\u000eJ\u000f\u0010\u0010\u001a\u00020\u000fH\u0016¢\u0006\u0004\b\u0010\u0010\u0011J\u000f\u0010\u0012\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u0012\u0010\bR\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0013\u0010\u0014R\"\u0010\u001c\u001a\u00020\u00158\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0016\u0010\u0017\u001a\u0004\b\u0018\u0010\u0019\"\u0004\b\u001a\u0010\u001bR\"\u0010 \u001a\u00020\u00158\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u001d\u0010\u0017\u001a\u0004\b\u001e\u0010\u0019\"\u0004\b\u001f\u0010\u001bR\"\u0010$\u001a\u00020\u00158\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b!\u0010\u0017\u001a\u0004\b\"\u0010\u0019\"\u0004\b#\u0010\u001bR\"\u0010(\u001a\u00020\u00158\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b%\u0010\u0017\u001a\u0004\b&\u0010\u0019\"\u0004\b'\u0010\u001bR\"\u0010,\u001a\u00020\u00158\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b)\u0010\u0017\u001a\u0004\b*\u0010\u0019\"\u0004\b+\u0010\u001b¨\u0006-"}, d2 = {"Lokhttp3/internal/http2/Http2Reader$ContinuationSource;", "Lokio/Source;", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "<init>", "(Lokio/BufferedSource;)V", StringUtils.EMPTY, "k", "()V", "Lokio/Buffer;", "sink", StringUtils.EMPTY, "byteCount", "k3", "(Lokio/Buffer;J)J", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", "close", "a", "Lokio/BufferedSource;", StringUtils.EMPTY, "b", "I", "getLength", "()I", "r", "(I)V", "length", "c", "getFlags", "o", "flags", "d", "getStreamId", "A", "streamId", "e", "j", "q", "left", "f", "getPadding", "u", "padding", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class ContinuationSource implements Source {
        private final BufferedSource a;
        private int b;
        private int c;
        private int d;
        private int e;
        private int f;

        public ContinuationSource(BufferedSource bufferedSource) {
            Intrinsics.checkNotNullParameter(bufferedSource, ap.a(1558172820));
            this.a = bufferedSource;
        }

        private final void k() throws IOException {
            int i = this.d;
            int iA = _UtilCommonKt.A(this.a);
            this.e = iA;
            this.b = iA;
            int iB = _UtilCommonKt.b(this.a.readByte(), 255);
            this.c = _UtilCommonKt.b(this.a.readByte(), 255);
            Companion companion = Http2Reader.e;
            if (companion.a().isLoggable(Level.FINE)) {
                companion.a().fine(Http2.a.c(true, this.d, this.b, iB, this.c));
            }
            int i2 = this.a.readInt() & Integer.MAX_VALUE;
            this.d = i2;
            if (iB == 9) {
                if (i2 != i) {
                    throw new IOException("TYPE_CONTINUATION streamId changed");
                }
            } else {
                throw new IOException(iB + " != TYPE_CONTINUATION");
            }
        }

        public final void A(int i) {
            this.d = i;
        }

        @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
        }

        public final int j() {
            return this.e;
        }

        @Override // okio.Source
        public long k3(Buffer buffer, long j) throws IOException {
            Intrinsics.checkNotNullParameter(buffer, "sink");
            while (true) {
                int i = this.e;
                if (i != 0) {
                    long jK3 = this.a.k3(buffer, Math.min(j, i));
                    if (jK3 == -1) {
                        return -1L;
                    }
                    this.e -= (int) jK3;
                    return jK3;
                }
                this.a.skip(this.f);
                this.f = 0;
                if ((this.c & 4) != 0) {
                    return -1L;
                }
                k();
            }
        }

        public final void o(int i) {
            this.c = i;
        }

        public final void q(int i) {
            this.e = i;
        }

        public final void r(int i) {
            this.b = i;
        }

        @Override // okio.Source
        public Timeout timeout() {
            return this.a.timeout();
        }

        public final void u(int i) {
            this.f = i;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000P\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\r\bf\u0018\u00002\u00020\u0001J/\u0010\n\u001a\u00020\t2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u0004H&¢\u0006\u0004\b\n\u0010\u000bJ5\u0010\u0010\u001a\u00020\t2\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\u00042\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u000e0\rH&¢\u0006\u0004\b\u0010\u0010\u0011J\u001f\u0010\u0014\u001a\u00020\t2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u0012H&¢\u0006\u0004\b\u0014\u0010\u0015J\u001f\u0010\u0019\u001a\u00020\t2\u0006\u0010\u0016\u001a\u00020\u00022\u0006\u0010\u0018\u001a\u00020\u0017H&¢\u0006\u0004\b\u0019\u0010\u001aJ\u000f\u0010\u001b\u001a\u00020\tH&¢\u0006\u0004\b\u001b\u0010\u001cJ'\u0010 \u001a\u00020\t2\u0006\u0010\u001d\u001a\u00020\u00022\u0006\u0010\u001e\u001a\u00020\u00042\u0006\u0010\u001f\u001a\u00020\u0004H&¢\u0006\u0004\b \u0010!J'\u0010%\u001a\u00020\t2\u0006\u0010\"\u001a\u00020\u00042\u0006\u0010\u0013\u001a\u00020\u00122\u0006\u0010$\u001a\u00020#H&¢\u0006\u0004\b%\u0010&J\u001f\u0010)\u001a\u00020\t2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010(\u001a\u00020'H&¢\u0006\u0004\b)\u0010*J/\u0010.\u001a\u00020\t2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010+\u001a\u00020\u00042\u0006\u0010,\u001a\u00020\u00042\u0006\u0010-\u001a\u00020\u0002H&¢\u0006\u0004\b.\u0010/J-\u00102\u001a\u00020\t2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u00100\u001a\u00020\u00042\f\u00101\u001a\b\u0012\u0004\u0012\u00020\u000e0\rH&¢\u0006\u0004\b2\u00103¨\u00064À\u0006\u0003"}, d2 = {"Lokhttp3/internal/http2/Http2Reader$Handler;", StringUtils.EMPTY, StringUtils.EMPTY, "inFinished", StringUtils.EMPTY, "streamId", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "length", StringUtils.EMPTY, "j", "(ZILokio/BufferedSource;I)V", "associatedStreamId", StringUtils.EMPTY, "Lokhttp3/internal/http2/Header;", "headerBlock", "i", "(ZIILjava/util/List;)V", "Lokhttp3/internal/http2/ErrorCode;", "errorCode", "a", "(ILokhttp3/internal/http2/ErrorCode;)V", "clearPrevious", "Lokhttp3/internal/http2/Settings;", "settings", "h", "(ZLokhttp3/internal/http2/Settings;)V", "e", "()V", "ack", "payload1", "payload2", "b", "(ZII)V", "lastGoodStreamId", "Lokio/ByteString;", "debugData", "g", "(ILokhttp3/internal/http2/ErrorCode;Lokio/ByteString;)V", StringUtils.EMPTY, "windowSizeIncrement", "c", "(IJ)V", "streamDependency", "weight", "exclusive", "f", "(IIIZ)V", "promisedStreamId", "requestHeaders", "d", "(IILjava/util/List;)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public interface Handler {
        void a(int i, ErrorCode errorCode);

        void b(boolean z, int i, int i2);

        void c(int i, long j);

        void d(int i, int i2, List list);

        void e();

        void f(int i, int i2, int i3, boolean z);

        void g(int i, ErrorCode errorCode, ByteString byteString);

        void h(boolean z, Settings settings);

        void i(boolean z, int i, int i2, List list);

        void j(boolean z, int i, BufferedSource bufferedSource, int i2);
    }

    static {
        Logger logger = Logger.getLogger(Http2.class.getName());
        Intrinsics.checkNotNullExpressionValue(logger, ap.a(1945479703));
        f = logger;
    }

    public Http2Reader(BufferedSource bufferedSource, boolean z) {
        Intrinsics.checkNotNullParameter(bufferedSource, ClimateForcast.SOURCE);
        this.a = bufferedSource;
        this.b = z;
        ContinuationSource continuationSource = new ContinuationSource(bufferedSource);
        this.c = continuationSource;
        this.d = new Hpack.Reader(continuationSource, 4096, 0, 4, null);
    }

    private final void A(Handler handler, int i, int i2, int i3) throws IOException {
        if (i3 == 0) {
            throw new IOException("PROTOCOL_ERROR: TYPE_HEADERS streamId == 0");
        }
        boolean z = (i2 & 1) != 0;
        int iB = (i2 & 8) != 0 ? _UtilCommonKt.b(this.a.readByte(), 255) : 0;
        if ((i2 & 32) != 0) {
            D(handler, i3);
            i -= 5;
        }
        handler.i(z, i3, -1, u(e.b(i, i2, iB), iB, i2, i3));
    }

    private final void B(Handler handler, int i, int i2, int i3) throws IOException {
        if (i != 8) {
            throw new IOException("TYPE_PING length != 8: " + i);
        }
        if (i3 != 0) {
            throw new IOException("TYPE_PING streamId != 0");
        }
        handler.b((i2 & 1) != 0, this.a.readInt(), this.a.readInt());
    }

    private final void D(Handler handler, int i) {
        int i2 = this.a.readInt();
        handler.f(i, i2 & Integer.MAX_VALUE, _UtilCommonKt.b(this.a.readByte(), 255) + 1, (Integer.MIN_VALUE & i2) != 0);
    }

    private final void I(Handler handler, int i, int i2, int i3) throws IOException {
        if (i == 5) {
            if (i3 == 0) {
                throw new IOException("TYPE_PRIORITY streamId == 0");
            }
            D(handler, i3);
        } else {
            throw new IOException("TYPE_PRIORITY length: " + i + " != 5");
        }
    }

    private final void J(Handler handler, int i, int i2, int i3) throws IOException {
        if (i3 == 0) {
            throw new IOException("PROTOCOL_ERROR: TYPE_PUSH_PROMISE streamId == 0");
        }
        int iB = (i2 & 8) != 0 ? _UtilCommonKt.b(this.a.readByte(), 255) : 0;
        handler.d(i3, this.a.readInt() & Integer.MAX_VALUE, u(e.b(i - 4, i2, iB), iB, i2, i3));
    }

    private final void O(Handler handler, int i, int i2, int i3) throws IOException {
        if (i != 4) {
            throw new IOException("TYPE_RST_STREAM length: " + i + " != 4");
        }
        if (i3 == 0) {
            throw new IOException("TYPE_RST_STREAM streamId == 0");
        }
        int i4 = this.a.readInt();
        ErrorCode errorCodeA = ErrorCode.b.a(i4);
        if (errorCodeA != null) {
            handler.a(i3, errorCodeA);
            return;
        }
        throw new IOException("TYPE_RST_STREAM unexpected error code: " + i4);
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x0078, code lost:
    
        throw new java.io.IOException("PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: " + r4);
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void P(okhttp3.internal.http2.Http2Reader.Handler r7, int r8, int r9, int r10) throws java.io.IOException {
        /*
            r6 = this;
            if (r10 != 0) goto Lb3
            r10 = 1
            r9 = r9 & r10
            if (r9 == 0) goto L14
            if (r8 != 0) goto Lc
            r7.e()
            return
        Lc:
            java.io.IOException r6 = new java.io.IOException
            java.lang.String r7 = "FRAME_SIZE_ERROR ack frame should be empty!"
            r6.<init>(r7)
            throw r6
        L14:
            int r9 = r8 % 6
            if (r9 != 0) goto L9c
            okhttp3.internal.http2.Settings r9 = new okhttp3.internal.http2.Settings
            r9.<init>()
            r0 = 0
            kotlin.ranges.IntRange r8 = kotlin.ranges.RangesKt.until(r0, r8)
            r1 = 6
            kotlin.ranges.IntProgression r8 = kotlin.ranges.RangesKt.step(r8, r1)
            int r1 = r8.getFirst()
            int r2 = r8.getLast()
            int r8 = r8.getStep()
            if (r8 <= 0) goto L37
            if (r1 <= r2) goto L3b
        L37:
            if (r8 >= 0) goto L98
            if (r2 > r1) goto L98
        L3b:
            okio.BufferedSource r3 = r6.a
            short r3 = r3.readShort()
            r4 = 65535(0xffff, float:9.1834E-41)
            int r3 = okhttp3.internal._UtilCommonKt.c(r3, r4)
            okio.BufferedSource r4 = r6.a
            int r4 = r4.readInt()
            r5 = 2
            if (r3 == r5) goto L84
            r5 = 4
            if (r3 == r5) goto L79
            r5 = 5
            if (r3 == r5) goto L58
            goto L91
        L58:
            r5 = 16384(0x4000, float:2.2959E-41)
            if (r4 < r5) goto L62
            r5 = 16777215(0xffffff, float:2.3509886E-38)
            if (r4 > r5) goto L62
            goto L91
        L62:
            java.io.IOException r6 = new java.io.IOException
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r8 = "PROTOCOL_ERROR SETTINGS_MAX_FRAME_SIZE: "
            r7.append(r8)
            r7.append(r4)
            java.lang.String r7 = r7.toString()
            r6.<init>(r7)
            throw r6
        L79:
            if (r4 < 0) goto L7c
            goto L91
        L7c:
            java.io.IOException r6 = new java.io.IOException
            java.lang.String r7 = "PROTOCOL_ERROR SETTINGS_INITIAL_WINDOW_SIZE > 2^31 - 1"
            r6.<init>(r7)
            throw r6
        L84:
            if (r4 == 0) goto L91
            if (r4 != r10) goto L89
            goto L91
        L89:
            java.io.IOException r6 = new java.io.IOException
            java.lang.String r7 = "PROTOCOL_ERROR SETTINGS_ENABLE_PUSH != 0 or 1"
            r6.<init>(r7)
            throw r6
        L91:
            r9.h(r3, r4)
            if (r1 == r2) goto L98
            int r1 = r1 + r8
            goto L3b
        L98:
            r7.h(r0, r9)
            return
        L9c:
            java.io.IOException r6 = new java.io.IOException
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r9 = "TYPE_SETTINGS length % 6 != 0: "
            r7.append(r9)
            r7.append(r8)
            java.lang.String r7 = r7.toString()
            r6.<init>(r7)
            throw r6
        Lb3:
            java.io.IOException r6 = new java.io.IOException
            java.lang.String r7 = "TYPE_SETTINGS streamId != 0"
            r6.<init>(r7)
            throw r6
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.http2.Http2Reader.P(okhttp3.internal.http2.Http2Reader$Handler, int, int, int):void");
    }

    private final void Q(Handler handler, int i, int i2, int i3) throws Exception {
        int i4;
        try {
            if (i != 4) {
                throw new IOException("TYPE_WINDOW_UPDATE length !=4: " + i);
            }
            try {
                long jD = _UtilCommonKt.d(this.a.readInt(), 2147483647L);
                if (jD == 0) {
                    throw new IOException("windowSizeIncrement was 0");
                }
                Logger logger = f;
                if (logger.isLoggable(Level.FINE)) {
                    i4 = i3;
                    logger.fine(Http2.a.d(true, i3, i, jD));
                } else {
                    i4 = i3;
                }
                handler.c(i4, jD);
            } catch (Exception e2) {
                e = e2;
                Exception exc = e;
                f.fine(Http2.a.c(true, i3, i, 8, i2));
                throw exc;
            }
        } catch (Exception e3) {
            e = e3;
        }
    }

    private final void q(Handler handler, int i, int i2, int i3) throws IOException {
        if (i3 == 0) {
            throw new IOException("PROTOCOL_ERROR: TYPE_DATA streamId == 0");
        }
        boolean z = (i2 & 1) != 0;
        if ((i2 & 32) != 0) {
            throw new IOException("PROTOCOL_ERROR: FLAG_COMPRESSED without SETTINGS_COMPRESS_DATA");
        }
        int iB = (i2 & 8) != 0 ? _UtilCommonKt.b(this.a.readByte(), 255) : 0;
        handler.j(z, i3, this.a, e.b(i, i2, iB));
        this.a.skip(iB);
    }

    private final void r(Handler handler, int i, int i2, int i3) throws IOException {
        if (i < 8) {
            throw new IOException("TYPE_GOAWAY length < 8: " + i);
        }
        if (i3 != 0) {
            throw new IOException("TYPE_GOAWAY streamId != 0");
        }
        int i4 = this.a.readInt();
        int i5 = this.a.readInt();
        int i6 = i - 8;
        ErrorCode errorCodeA = ErrorCode.b.a(i5);
        if (errorCodeA == null) {
            throw new IOException("TYPE_GOAWAY unexpected error code: " + i5);
        }
        ByteString byteStringF0 = ByteString.e;
        if (i6 > 0) {
            byteStringF0 = this.a.F0(i6);
        }
        handler.g(i4, errorCodeA, byteStringF0);
    }

    private final List u(int i, int i2, int i3, int i4) {
        this.c.q(i);
        ContinuationSource continuationSource = this.c;
        continuationSource.r(continuationSource.j());
        this.c.u(i2);
        this.c.o(i3);
        this.c.A(i4);
        this.d.k();
        return this.d.e();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        this.a.close();
    }

    public final boolean k(boolean z, Handler handler) throws Exception {
        Intrinsics.checkNotNullParameter(handler, "handler");
        try {
            this.a.s2(9L);
            int iA = _UtilCommonKt.A(this.a);
            if (iA > 16384) {
                throw new IOException("FRAME_SIZE_ERROR: " + iA);
            }
            int iB = _UtilCommonKt.b(this.a.readByte(), 255);
            int iB2 = _UtilCommonKt.b(this.a.readByte(), 255);
            int i = this.a.readInt() & Integer.MAX_VALUE;
            if (iB != 8) {
                Logger logger = f;
                if (logger.isLoggable(Level.FINE)) {
                    logger.fine(Http2.a.c(true, i, iA, iB, iB2));
                }
            }
            if (z && iB != 4) {
                throw new IOException("Expected a SETTINGS frame but was " + Http2.a.b(iB));
            }
            switch (iB) {
                case 0:
                    q(handler, iA, iB2, i);
                    return true;
                case 1:
                    A(handler, iA, iB2, i);
                    return true;
                case 2:
                    I(handler, iA, iB2, i);
                    return true;
                case 3:
                    O(handler, iA, iB2, i);
                    return true;
                case 4:
                    P(handler, iA, iB2, i);
                    return true;
                case 5:
                    J(handler, iA, iB2, i);
                    return true;
                case 6:
                    B(handler, iA, iB2, i);
                    return true;
                case 7:
                    r(handler, iA, iB2, i);
                    return true;
                case 8:
                    Q(handler, iA, iB2, i);
                    return true;
                default:
                    this.a.skip(iA);
                    return true;
            }
        } catch (EOFException unused) {
            return false;
        }
    }

    public final void o(Handler handler) throws IOException {
        Intrinsics.checkNotNullParameter(handler, "handler");
        if (this.b) {
            if (!k(true, handler)) {
                throw new IOException("Required SETTINGS preface not received");
            }
            return;
        }
        BufferedSource bufferedSource = this.a;
        ByteString byteString = Http2.b;
        ByteString byteStringF0 = bufferedSource.F0(byteString.size());
        Logger logger = f;
        if (logger.isLoggable(Level.FINE)) {
            logger.fine(_UtilJvmKt.j("<< CONNECTION " + byteStringF0.l(), new Object[0]));
        }
        if (Intrinsics.areEqual(byteString, byteStringF0)) {
            return;
        }
        throw new IOException("Expected a connection header but was " + byteStringF0.M());
    }
}