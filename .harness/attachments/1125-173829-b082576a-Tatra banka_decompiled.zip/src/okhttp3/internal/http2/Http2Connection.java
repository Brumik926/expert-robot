package okhttp3.internal.http2;

import h.ap;
import java.io.Closeable;
import java.io.IOException;
import java.net.Socket;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.time.InstantKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import kotlinx.serialization.json.internal.ReaderJsonLexerKt;
import okhttp3.Headers;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.concurrent.Lockable;
import okhttp3.internal.concurrent.TaskQueue;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.http2.FlowControlListener;
import okhttp3.internal.http2.Http2Connection;
import okhttp3.internal.http2.Http2Reader;
import okhttp3.internal.http2.flowcontrol.WindowCounter;
import okhttp3.internal.platform.Platform;
import okio.Buffer;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.ByteString;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000È\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0007\n\u0002\u0010\t\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b%\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010%\n\u0002\b\u0005\n\u0002\u0010\u000e\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010#\n\u0002\b\t\u0018\u0000 Ê\u00012\u00020\u00012\u00020\u0002:\bË\u0001Ì\u0001Í\u0001Î\u0001B\u0011\b\u0000\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006J-\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\b\u001a\u00020\u00072\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010\r\u001a\u00020\fH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u0019\u0010\u0014\u001a\u00020\u00132\b\u0010\u0012\u001a\u0004\u0018\u00010\u0011H\u0002¢\u0006\u0004\b\u0014\u0010\u0015J\u0017\u0010\u0017\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0016\u001a\u00020\u0007¢\u0006\u0004\b\u0017\u0010\u0018J\u0019\u0010\u001a\u001a\u0004\u0018\u00010\u000e2\u0006\u0010\u0019\u001a\u00020\u0007H\u0000¢\u0006\u0004\b\u001a\u0010\u0018J\u0017\u0010\u001d\u001a\u00020\u00132\u0006\u0010\u001c\u001a\u00020\u001bH\u0000¢\u0006\u0004\b\u001d\u0010\u001eJ#\u0010\u001f\u001a\u00020\u000e2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010\r\u001a\u00020\f¢\u0006\u0004\b\u001f\u0010 J-\u0010#\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010!\u001a\u00020\f2\f\u0010\"\u001a\b\u0012\u0004\u0012\u00020\n0\tH\u0000¢\u0006\u0004\b#\u0010$J/\u0010(\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010!\u001a\u00020\f2\b\u0010&\u001a\u0004\u0018\u00010%2\u0006\u0010'\u001a\u00020\u001b¢\u0006\u0004\b(\u0010)J\u001f\u0010,\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010+\u001a\u00020*H\u0000¢\u0006\u0004\b,\u0010-J\u001f\u0010/\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010.\u001a\u00020*H\u0000¢\u0006\u0004\b/\u0010-J\u001f\u00101\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u00100\u001a\u00020\u001bH\u0000¢\u0006\u0004\b1\u00102J%\u00106\u001a\u00020\u00132\u0006\u00103\u001a\u00020\f2\u0006\u00104\u001a\u00020\u00072\u0006\u00105\u001a\u00020\u0007¢\u0006\u0004\b6\u00107J\r\u00108\u001a\u00020\u0013¢\u0006\u0004\b8\u00109J\u0015\u0010:\u001a\u00020\u00132\u0006\u0010.\u001a\u00020*¢\u0006\u0004\b:\u0010;J\u000f\u0010<\u001a\u00020\u0013H\u0016¢\u0006\u0004\b<\u00109J)\u0010@\u001a\u00020\u00132\u0006\u0010=\u001a\u00020*2\u0006\u0010>\u001a\u00020*2\b\u0010?\u001a\u0004\u0018\u00010\u0011H\u0000¢\u0006\u0004\b@\u0010AJ\u0019\u0010C\u001a\u00020\u00132\b\b\u0002\u0010B\u001a\u00020\fH\u0007¢\u0006\u0004\bC\u0010DJ\u0015\u0010F\u001a\u00020\f2\u0006\u0010E\u001a\u00020\u001b¢\u0006\u0004\bF\u0010GJ\u000f\u0010H\u001a\u00020\u0013H\u0000¢\u0006\u0004\bH\u00109J\u0017\u0010I\u001a\u00020\f2\u0006\u0010\u0019\u001a\u00020\u0007H\u0000¢\u0006\u0004\bI\u0010JJ%\u0010K\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\tH\u0000¢\u0006\u0004\bK\u0010LJ-\u0010N\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\t2\u0006\u0010M\u001a\u00020\fH\u0000¢\u0006\u0004\bN\u0010OJ/\u0010R\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010Q\u001a\u00020P2\u0006\u0010'\u001a\u00020\u00072\u0006\u0010M\u001a\u00020\fH\u0000¢\u0006\u0004\bR\u0010SJ\u001f\u0010T\u001a\u00020\u00132\u0006\u0010\u0019\u001a\u00020\u00072\u0006\u0010+\u001a\u00020*H\u0000¢\u0006\u0004\bT\u0010-R\u001a\u0010Y\u001a\u00020\f8\u0000X\u0080\u0004¢\u0006\f\n\u0004\bU\u0010V\u001a\u0004\bW\u0010XR\u001a\u0010_\u001a\u00020Z8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b[\u0010\\\u001a\u0004\b]\u0010^R&\u0010e\u001a\u000e\u0012\u0004\u0012\u00020\u0007\u0012\u0004\u0012\u00020\u000e0`8\u0000X\u0080\u0004¢\u0006\f\n\u0004\ba\u0010b\u001a\u0004\bc\u0010dR\u001a\u0010k\u001a\u00020f8\u0000X\u0080\u0004¢\u0006\f\n\u0004\bg\u0010h\u001a\u0004\bi\u0010jR\"\u0010q\u001a\u00020\u00078\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0012\u0010l\u001a\u0004\bm\u0010n\"\u0004\bo\u0010pR\"\u0010u\u001a\u00020\u00078\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\br\u0010l\u001a\u0004\bs\u0010n\"\u0004\bt\u0010pR\u0016\u0010w\u001a\u00020\f8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\bv\u0010VR\u0014\u0010{\u001a\u00020x8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\by\u0010zR\u0014\u0010\u007f\u001a\u00020|8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b}\u0010~R\u0016\u0010\u0081\u0001\u001a\u00020|8\u0002X\u0082\u0004¢\u0006\u0007\n\u0005\b\u0080\u0001\u0010~R\u0016\u0010\u0083\u0001\u001a\u00020|8\u0002X\u0082\u0004¢\u0006\u0007\n\u0005\b\u0082\u0001\u0010~R\u0018\u0010\u0087\u0001\u001a\u00030\u0084\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\b\u0085\u0001\u0010\u0086\u0001R\u0019\u0010\u008a\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0088\u0001\u0010\u0089\u0001R\u0019\u0010\u008c\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u008b\u0001\u0010\u0089\u0001R\u0019\u0010\u008e\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u008d\u0001\u0010\u0089\u0001R\u0019\u0010\u0090\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u008f\u0001\u0010\u0089\u0001R\u0019\u0010\u0092\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0091\u0001\u0010\u0089\u0001R\u0019\u0010\u0094\u0001\u001a\u00020\u001b8\u0002@\u0002X\u0082\u000e¢\u0006\b\n\u0006\b\u0093\u0001\u0010\u0089\u0001R \u0010\u009a\u0001\u001a\u00030\u0095\u00018\u0000X\u0080\u0004¢\u0006\u0010\n\u0006\b\u0096\u0001\u0010\u0097\u0001\u001a\u0006\b\u0098\u0001\u0010\u0099\u0001R\u001d\u0010 \u0001\u001a\u00030\u009b\u00018\u0006¢\u0006\u0010\n\u0006\b\u009c\u0001\u0010\u009d\u0001\u001a\u0006\b\u009e\u0001\u0010\u009f\u0001R*\u0010¥\u0001\u001a\u00030\u009b\u00018\u0006@\u0006X\u0086\u000e¢\u0006\u0018\n\u0006\b¡\u0001\u0010\u009d\u0001\u001a\u0006\b¢\u0001\u0010\u009f\u0001\"\u0006\b£\u0001\u0010¤\u0001R\u001d\u0010«\u0001\u001a\u00030¦\u00018\u0006¢\u0006\u0010\n\u0006\b§\u0001\u0010¨\u0001\u001a\u0006\b©\u0001\u0010ª\u0001R*\u0010°\u0001\u001a\u00020\u001b2\u0007\u0010¬\u0001\u001a\u00020\u001b8\u0006@BX\u0086\u000e¢\u0006\u0010\n\u0006\b\u00ad\u0001\u0010\u0089\u0001\u001a\u0006\b®\u0001\u0010¯\u0001R*\u0010³\u0001\u001a\u00020\u001b2\u0007\u0010¬\u0001\u001a\u00020\u001b8\u0006@BX\u0086\u000e¢\u0006\u0010\n\u0006\b±\u0001\u0010\u0089\u0001\u001a\u0006\b²\u0001\u0010¯\u0001R \u0010¹\u0001\u001a\u00030´\u00018\u0000X\u0080\u0004¢\u0006\u0010\n\u0006\bµ\u0001\u0010¶\u0001\u001a\u0006\b·\u0001\u0010¸\u0001R\u001d\u0010¿\u0001\u001a\u00030º\u00018\u0006¢\u0006\u0010\n\u0006\b»\u0001\u0010¼\u0001\u001a\u0006\b½\u0001\u0010¾\u0001R!\u0010Å\u0001\u001a\u00070À\u0001R\u00020\u00008\u0006¢\u0006\u0010\n\u0006\bÁ\u0001\u0010Â\u0001\u001a\u0006\bÃ\u0001\u0010Ä\u0001R\u001e\u0010É\u0001\u001a\t\u0012\u0004\u0012\u00020\u00070Æ\u00018\u0002X\u0082\u0004¢\u0006\b\n\u0006\bÇ\u0001\u0010È\u0001¨\u0006Ï\u0001"}, d2 = {"Lokhttp3/internal/http2/Http2Connection;", "Ljava/io/Closeable;", "Lokhttp3/internal/concurrent/Lockable;", "Lokhttp3/internal/http2/Http2Connection$Builder;", "builder", "<init>", "(Lokhttp3/internal/http2/Http2Connection$Builder;)V", StringUtils.EMPTY, "associatedStreamId", StringUtils.EMPTY, "Lokhttp3/internal/http2/Header;", "requestHeaders", StringUtils.EMPTY, "out", "Lokhttp3/internal/http2/Http2Stream;", "N0", "(ILjava/util/List;Z)Lokhttp3/internal/http2/Http2Stream;", "Ljava/io/IOException;", "e", StringUtils.EMPTY, "e0", "(Ljava/io/IOException;)V", "id", "C0", "(I)Lokhttp3/internal/http2/Http2Stream;", "streamId", "j1", StringUtils.EMPTY, "read", "I1", "(J)V", "O0", "(Ljava/util/List;Z)Lokhttp3/internal/http2/Http2Stream;", "outFinished", "alternating", "Q1", "(IZLjava/util/List;)V", "Lokio/Buffer;", "buffer", "byteCount", "J1", "(IZLokio/Buffer;J)V", "Lokhttp3/internal/http2/ErrorCode;", "errorCode", "f2", "(ILokhttp3/internal/http2/ErrorCode;)V", "statusCode", "c2", "unacknowledgedBytesRead", "h2", "(IJ)V", "reply", "payload1", "payload2", "Z1", "(ZII)V", "flush", "()V", "w1", "(Lokhttp3/internal/http2/ErrorCode;)V", "close", "connectionCode", "streamCode", "cause", "d0", "(Lokhttp3/internal/http2/ErrorCode;Lokhttp3/internal/http2/ErrorCode;Ljava/io/IOException;)V", "sendConnectionPreface", "F1", "(Z)V", "nowNs", "M0", "(J)Z", "o1", "i1", "(I)Z", "f1", "(ILjava/util/List;)V", "inFinished", "W0", "(ILjava/util/List;Z)V", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "U0", "(ILokio/BufferedSource;IZ)V", "h1", "a", "Z", "i0", "()Z", "client", "Lokhttp3/internal/http2/Http2Connection$Listener;", "b", "Lokhttp3/internal/http2/Http2Connection$Listener;", "v0", "()Lokhttp3/internal/http2/Http2Connection$Listener;", "listener", StringUtils.EMPTY, "c", "Ljava/util/Map;", "E0", "()Ljava/util/Map;", "streams", StringUtils.EMPTY, "d", "Ljava/lang/String;", "j0", "()Ljava/lang/String;", "connectionName", "I", "o0", "()I", "q1", "(I)V", "lastGoodStreamId", "f", "w0", "setNextStreamId$okhttp", "nextStreamId", "g", "isShutdown", "Lokhttp3/internal/concurrent/TaskRunner;", "h", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", "Lokhttp3/internal/concurrent/TaskQueue;", "i", "Lokhttp3/internal/concurrent/TaskQueue;", "writerQueue", "j", "pushQueue", "k", "settingsListenerQueue", "Lokhttp3/internal/http2/PushObserver;", "l", "Lokhttp3/internal/http2/PushObserver;", "pushObserver", "m", "J", "intervalPingsSent", "n", "intervalPongsReceived", "o", "degradedPingsSent", "p", "degradedPongsReceived", "q", "awaitPongsReceived", "r", "degradedPongDeadlineNs", "Lokhttp3/internal/http2/FlowControlListener;", "s", "Lokhttp3/internal/http2/FlowControlListener;", "m0", "()Lokhttp3/internal/http2/FlowControlListener;", "flowControlListener", "Lokhttp3/internal/http2/Settings;", "t", "Lokhttp3/internal/http2/Settings;", "x0", "()Lokhttp3/internal/http2/Settings;", "okHttpSettings", "u", "z0", "r1", "(Lokhttp3/internal/http2/Settings;)V", "peerSettings", "Lokhttp3/internal/http2/flowcontrol/WindowCounter;", "v", "Lokhttp3/internal/http2/flowcontrol/WindowCounter;", "getReadBytes", "()Lokhttp3/internal/http2/flowcontrol/WindowCounter;", "readBytes", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "getWriteBytesTotal", "()J", "writeBytesTotal", "x", "H0", "writeBytesMaximum", "Ljava/net/Socket;", "y", "Ljava/net/Socket;", "getSocket$okhttp", "()Ljava/net/Socket;", "socket", "Lokhttp3/internal/http2/Http2Writer;", "z", "Lokhttp3/internal/http2/Http2Writer;", "J0", "()Lokhttp3/internal/http2/Http2Writer;", "writer", "Lokhttp3/internal/http2/Http2Connection$ReaderRunnable;", "A", "Lokhttp3/internal/http2/Http2Connection$ReaderRunnable;", "getReaderRunnable", "()Lokhttp3/internal/http2/Http2Connection$ReaderRunnable;", "readerRunnable", StringUtils.EMPTY, "B", "Ljava/util/Set;", "currentPushRequests", "D", "Builder", "ReaderRunnable", "Listener", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nHttp2Connection.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http2Connection.kt\nokhttp3/internal/http2/Http2Connection\n+ 2 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 -UtilCommon.kt\nokhttp3/internal/_UtilCommonKt\n+ 5 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 6 _Arrays.kt\nkotlin/collections/ArraysKt___ArraysKt\n*L\n1#1,1054:1\n63#2:1055\n63#2:1056\n63#2:1057\n38#2:1058\n63#2:1059\n63#2:1061\n63#2:1062\n63#2:1063\n34#2:1064\n63#2:1065\n63#2:1066\n34#2:1067\n63#2:1068\n63#2:1069\n49#2,4:1070\n63#2:1079\n63#2:1101\n63#2:1102\n63#2:1103\n63#2:1104\n63#2:1105\n63#2:1106\n63#2:1109\n63#2:1115\n63#2:1121\n63#2:1125\n1#3:1060\n228#4,5:1074\n228#4,5:1085\n228#4,5:1091\n228#4,5:1096\n228#4,2:1107\n230#4,3:1110\n228#4,2:1113\n230#4,3:1116\n228#4,2:1119\n230#4,3:1122\n37#5:1080\n36#5,3:1081\n13472#6:1084\n13473#6:1090\n*S KotlinDebug\n*F\n+ 1 Http2Connection.kt\nokhttp3/internal/http2/Http2Connection\n*L\n179#1:1055\n181#1:1056\n184#1:1057\n188#1:1058\n195#1:1059\n247#1:1061\n248#1:1062\n318#1:1063\n326#1:1064\n399#1:1065\n410#1:1066\n412#1:1067\n429#1:1068\n431#1:1069\n457#1:1070,4\n464#1:1079\n524#1:1101\n525#1:1102\n536#1:1103\n562#1:1104\n926#1:1105\n157#1:1106\n938#1:1109\n956#1:1115\n983#1:1121\n997#1:1125\n459#1:1074,5\n472#1:1085,5\n478#1:1091,5\n483#1:1096,5\n935#1:1107,2\n935#1:1110,3\n953#1:1113,2\n953#1:1116,3\n979#1:1119,2\n979#1:1122,3\n466#1:1080\n466#1:1081,3\n471#1:1084\n471#1:1090\n*E\n"})
public final class Http2Connection implements Closeable, Lockable {
    public static final Companion D = new Companion(null);
    private static final Settings G;
    private final ReaderRunnable A;
    private final Set B;
    private final boolean a;
    private final Listener b;
    private final Map c;
    private final String d;
    private int e;
    private int f;
    private boolean g;
    private final TaskRunner h;
    private final TaskQueue i;
    private final TaskQueue j;
    private final TaskQueue k;
    private final PushObserver l;
    private long m;
    private long n;
    private long o;
    private long p;
    private long q;
    private long r;
    private final FlowControlListener s;
    private final Settings t;
    private Settings u;
    private final WindowCounter v;
    private long w;
    private long x;
    private final Socket y;
    private final Http2Writer z;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b&\n\u0002\u0018\u0002\n\u0002\b\u000f\u0018\u00002\u00020\u0001B\u0017\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J5\u0010\u0010\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\b2\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\r\u001a\u00020\f2\b\b\u0002\u0010\u000f\u001a\u00020\u000eH\u0007¢\u0006\u0004\b\u0010\u0010\u0011J\u0015\u0010\u0014\u001a\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u0012¢\u0006\u0004\b\u0014\u0010\u0015J\u0015\u0010\u0018\u001a\u00020\u00002\u0006\u0010\u0017\u001a\u00020\u0016¢\u0006\u0004\b\u0018\u0010\u0019J\u0015\u0010\u001c\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\u001a¢\u0006\u0004\b\u001c\u0010\u001dJ\r\u0010\u001f\u001a\u00020\u001e¢\u0006\u0004\b\u001f\u0010 R\"\u0010\u0003\u001a\u00020\u00028\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u001f\u0010!\u001a\u0004\b\"\u0010#\"\u0004\b$\u0010%R\u001a\u0010\u0005\u001a\u00020\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u001c\u0010&\u001a\u0004\b'\u0010(R\"\u0010\t\u001a\u00020\b8\u0000@\u0000X\u0080.¢\u0006\u0012\n\u0004\b\"\u0010)\u001a\u0004\b*\u0010+\"\u0004\b,\u0010-R\"\u00103\u001a\u00020\n8\u0000@\u0000X\u0080.¢\u0006\u0012\n\u0004\b.\u0010/\u001a\u0004\b.\u00100\"\u0004\b1\u00102R\"\u0010\r\u001a\u00020\f8\u0000@\u0000X\u0080.¢\u0006\u0012\n\u0004\b4\u00105\u001a\u0004\b6\u00107\"\u0004\b8\u00109R\"\u0010\u000f\u001a\u00020\u000e8\u0000@\u0000X\u0080.¢\u0006\u0012\n\u0004\b:\u0010;\u001a\u0004\b<\u0010=\"\u0004\b>\u0010?R\"\u0010\u0013\u001a\u00020\u00128\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b@\u0010A\u001a\u0004\b:\u0010B\"\u0004\bC\u0010DR\"\u0010K\u001a\u00020E8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bF\u0010G\u001a\u0004\bF\u0010H\"\u0004\bI\u0010JR\"\u0010\u0017\u001a\u00020\u00168\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b<\u0010L\u001a\u0004\b@\u0010M\"\u0004\bN\u0010OR\"\u0010\u001b\u001a\u00020\u001a8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b*\u0010P\u001a\u0004\b4\u0010Q\"\u0004\bR\u0010S¨\u0006T"}, d2 = {"Lokhttp3/internal/http2/Http2Connection$Builder;", StringUtils.EMPTY, StringUtils.EMPTY, "client", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", "<init>", "(ZLokhttp3/internal/concurrent/TaskRunner;)V", "Ljava/net/Socket;", "socket", StringUtils.EMPTY, "peerName", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "Lokio/BufferedSink;", "sink", "s", "(Ljava/net/Socket;Ljava/lang/String;Lokio/BufferedSource;Lokio/BufferedSink;)Lokhttp3/internal/http2/Http2Connection$Builder;", "Lokhttp3/internal/http2/Http2Connection$Listener;", "listener", "m", "(Lokhttp3/internal/http2/Http2Connection$Listener;)Lokhttp3/internal/http2/Http2Connection$Builder;", StringUtils.EMPTY, "pingIntervalMillis", "n", "(I)Lokhttp3/internal/http2/Http2Connection$Builder;", "Lokhttp3/internal/http2/FlowControlListener;", "flowControlListener", "b", "(Lokhttp3/internal/http2/FlowControlListener;)Lokhttp3/internal/http2/Http2Connection$Builder;", "Lokhttp3/internal/http2/Http2Connection;", "a", "()Lokhttp3/internal/http2/Http2Connection;", "Z", "c", "()Z", "setClient$okhttp", "(Z)V", "Lokhttp3/internal/concurrent/TaskRunner;", "l", "()Lokhttp3/internal/concurrent/TaskRunner;", "Ljava/net/Socket;", "j", "()Ljava/net/Socket;", "q", "(Ljava/net/Socket;)V", "d", "Ljava/lang/String;", "()Ljava/lang/String;", "o", "(Ljava/lang/String;)V", "connectionName", "e", "Lokio/BufferedSource;", "k", "()Lokio/BufferedSource;", "r", "(Lokio/BufferedSource;)V", "f", "Lokio/BufferedSink;", "i", "()Lokio/BufferedSink;", "p", "(Lokio/BufferedSink;)V", "g", "Lokhttp3/internal/http2/Http2Connection$Listener;", "()Lokhttp3/internal/http2/Http2Connection$Listener;", "setListener$okhttp", "(Lokhttp3/internal/http2/Http2Connection$Listener;)V", "Lokhttp3/internal/http2/PushObserver;", "h", "Lokhttp3/internal/http2/PushObserver;", "()Lokhttp3/internal/http2/PushObserver;", "setPushObserver$okhttp", "(Lokhttp3/internal/http2/PushObserver;)V", "pushObserver", "I", "()I", "setPingIntervalMillis$okhttp", "(I)V", "Lokhttp3/internal/http2/FlowControlListener;", "()Lokhttp3/internal/http2/FlowControlListener;", "setFlowControlListener$okhttp", "(Lokhttp3/internal/http2/FlowControlListener;)V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Builder {
        private boolean a;
        private final TaskRunner b;
        public Socket c;
        public String d;
        public BufferedSource e;
        public BufferedSink f;
        private Listener g;
        private PushObserver h;
        private int i;
        private FlowControlListener j;

        public Builder(boolean z, TaskRunner taskRunner) {
            Intrinsics.checkNotNullParameter(taskRunner, ap.a(1311118014));
            this.a = z;
            this.b = taskRunner;
            this.g = Listener.b;
            this.h = PushObserver.b;
            this.j = FlowControlListener.None.a;
        }

        public final Http2Connection a() {
            return new Http2Connection(this);
        }

        public final Builder b(FlowControlListener flowControlListener) {
            Intrinsics.checkNotNullParameter(flowControlListener, "flowControlListener");
            this.j = flowControlListener;
            return this;
        }

        public final boolean c() {
            return this.a;
        }

        public final String d() {
            String str = this.d;
            if (str != null) {
                return str;
            }
            Intrinsics.throwUninitializedPropertyAccessException("connectionName");
            return null;
        }

        public final FlowControlListener e() {
            return this.j;
        }

        public final Listener f() {
            return this.g;
        }

        public final int g() {
            return this.i;
        }

        public final PushObserver h() {
            return this.h;
        }

        public final BufferedSink i() {
            BufferedSink bufferedSink = this.f;
            if (bufferedSink != null) {
                return bufferedSink;
            }
            Intrinsics.throwUninitializedPropertyAccessException("sink");
            return null;
        }

        public final Socket j() {
            Socket socket = this.c;
            if (socket != null) {
                return socket;
            }
            Intrinsics.throwUninitializedPropertyAccessException("socket");
            return null;
        }

        public final BufferedSource k() {
            BufferedSource bufferedSource = this.e;
            if (bufferedSource != null) {
                return bufferedSource;
            }
            Intrinsics.throwUninitializedPropertyAccessException(ClimateForcast.SOURCE);
            return null;
        }

        public final TaskRunner l() {
            return this.b;
        }

        public final Builder m(Listener listener) {
            Intrinsics.checkNotNullParameter(listener, "listener");
            this.g = listener;
            return this;
        }

        public final Builder n(int i) {
            this.i = i;
            return this;
        }

        public final void o(String str) {
            Intrinsics.checkNotNullParameter(str, "<set-?>");
            this.d = str;
        }

        public final void p(BufferedSink bufferedSink) {
            Intrinsics.checkNotNullParameter(bufferedSink, "<set-?>");
            this.f = bufferedSink;
        }

        public final void q(Socket socket) {
            Intrinsics.checkNotNullParameter(socket, "<set-?>");
            this.c = socket;
        }

        public final void r(BufferedSource bufferedSource) {
            Intrinsics.checkNotNullParameter(bufferedSource, "<set-?>");
            this.e = bufferedSource;
        }

        public final Builder s(Socket socket, String str, BufferedSource bufferedSource, BufferedSink bufferedSink) {
            String str2;
            Intrinsics.checkNotNullParameter(socket, "socket");
            Intrinsics.checkNotNullParameter(str, "peerName");
            Intrinsics.checkNotNullParameter(bufferedSource, ClimateForcast.SOURCE);
            Intrinsics.checkNotNullParameter(bufferedSink, "sink");
            q(socket);
            if (this.a) {
                str2 = _UtilJvmKt.c + ' ' + str;
            } else {
                str2 = "MockWebServer " + str;
            }
            o(str2);
            r(bufferedSource);
            p(bufferedSink);
            return this;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\u0007\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\u0005\u0010\u0006\u001a\u0004\b\u0007\u0010\bR\u0014\u0010\n\u001a\u00020\t8\u0006X\u0086T¢\u0006\u0006\n\u0004\b\n\u0010\u000bR\u0014\u0010\f\u001a\u00020\t8\u0006X\u0086T¢\u0006\u0006\n\u0004\b\f\u0010\u000bR\u0014\u0010\r\u001a\u00020\t8\u0006X\u0086T¢\u0006\u0006\n\u0004\b\r\u0010\u000bR\u0014\u0010\u000e\u001a\u00020\t8\u0006X\u0086T¢\u0006\u0006\n\u0004\b\u000e\u0010\u000bR\u0014\u0010\u000f\u001a\u00020\t8\u0006X\u0086T¢\u0006\u0006\n\u0004\b\u000f\u0010\u000b¨\u0006\u0010"}, d2 = {"Lokhttp3/internal/http2/Http2Connection$Companion;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/internal/http2/Settings;", "DEFAULT_SETTINGS", "Lokhttp3/internal/http2/Settings;", "a", "()Lokhttp3/internal/http2/Settings;", StringUtils.EMPTY, "OKHTTP_CLIENT_WINDOW_SIZE", "I", "INTERVAL_PING", "DEGRADED_PING", "AWAIT_PING", "DEGRADED_PONG_TIMEOUT_NS", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final Settings a() {
            return Http2Connection.G;
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\b&\u0018\u0000 \u000f2\u00020\u0001:\u0001\u0010B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H&¢\u0006\u0004\b\u0007\u0010\bJ\u001f\u0010\r\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\r\u0010\u000e¨\u0006\u0011"}, d2 = {"Lokhttp3/internal/http2/Http2Connection$Listener;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/internal/http2/Http2Stream;", "stream", StringUtils.EMPTY, "d", "(Lokhttp3/internal/http2/Http2Stream;)V", "Lokhttp3/internal/http2/Http2Connection;", "connection", "Lokhttp3/internal/http2/Settings;", "settings", "b", "(Lokhttp3/internal/http2/Http2Connection;Lokhttp3/internal/http2/Settings;)V", "a", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static abstract class Listener {
        public static final Companion a = new Companion(null);
        public static final Listener b = new Listener() { // from class: okhttp3.internal.http2.Http2Connection$Listener$Companion$REFUSE_INCOMING_STREAMS$1
            @Override // okhttp3.internal.http2.Http2Connection.Listener
            public void d(Http2Stream http2Stream) {
                Intrinsics.checkNotNullParameter(http2Stream, ap.a(1777169277));
                http2Stream.e(ErrorCode.j, null);
            }
        };

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0010\u0010\u0004\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Lokhttp3/internal/http2/Http2Connection$Listener$Companion;", StringUtils.EMPTY, "<init>", "()V", "REFUSE_INCOMING_STREAMS", "Lokhttp3/internal/http2/Http2Connection$Listener;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
        public static final class Companion {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            private Companion() {
            }
        }

        public void b(Http2Connection http2Connection, Settings settings) {
            Intrinsics.checkNotNullParameter(http2Connection, ap.a(890128742));
            Intrinsics.checkNotNullParameter(settings, ap.a(1752078158));
        }

        public abstract void d(Http2Stream http2Stream);
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000X\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0010\b\u0086\u0004\u0018\u00002\u00020\u00012\b\u0012\u0004\u0012\u00020\u00030\u0002B\u0011\b\u0000\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\b\u001a\u00020\u0003H\u0096\u0002¢\u0006\u0004\b\b\u0010\tJ/\u0010\u0011\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u0010\u001a\u00020\fH\u0016¢\u0006\u0004\b\u0011\u0010\u0012J5\u0010\u0017\u001a\u00020\u00032\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\u0013\u001a\u00020\f2\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014H\u0016¢\u0006\u0004\b\u0017\u0010\u0018J\u001f\u0010\u001b\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\u001a\u001a\u00020\u0019H\u0016¢\u0006\u0004\b\u001b\u0010\u001cJ\u001f\u0010 \u001a\u00020\u00032\u0006\u0010\u001d\u001a\u00020\n2\u0006\u0010\u001f\u001a\u00020\u001eH\u0016¢\u0006\u0004\b \u0010!J\u001d\u0010\"\u001a\u00020\u00032\u0006\u0010\u001d\u001a\u00020\n2\u0006\u0010\u001f\u001a\u00020\u001e¢\u0006\u0004\b\"\u0010!J\u000f\u0010#\u001a\u00020\u0003H\u0016¢\u0006\u0004\b#\u0010\tJ'\u0010'\u001a\u00020\u00032\u0006\u0010$\u001a\u00020\n2\u0006\u0010%\u001a\u00020\f2\u0006\u0010&\u001a\u00020\fH\u0016¢\u0006\u0004\b'\u0010(J'\u0010,\u001a\u00020\u00032\u0006\u0010)\u001a\u00020\f2\u0006\u0010\u001a\u001a\u00020\u00192\u0006\u0010+\u001a\u00020*H\u0016¢\u0006\u0004\b,\u0010-J\u001f\u00100\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\f2\u0006\u0010/\u001a\u00020.H\u0016¢\u0006\u0004\b0\u00101J/\u00105\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\f2\u0006\u00102\u001a\u00020\f2\u0006\u00103\u001a\u00020\f2\u0006\u00104\u001a\u00020\nH\u0016¢\u0006\u0004\b5\u00106J-\u00109\u001a\u00020\u00032\u0006\u0010\r\u001a\u00020\f2\u0006\u00107\u001a\u00020\f2\f\u00108\u001a\b\u0012\u0004\u0012\u00020\u00150\u0014H\u0016¢\u0006\u0004\b9\u0010:R\u001a\u0010\u0005\u001a\u00020\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u001b\u0010;\u001a\u0004\b<\u0010=¨\u0006>"}, d2 = {"Lokhttp3/internal/http2/Http2Connection$ReaderRunnable;", "Lokhttp3/internal/http2/Http2Reader$Handler;", "Lkotlin/Function0;", StringUtils.EMPTY, "Lokhttp3/internal/http2/Http2Reader;", "reader", "<init>", "(Lokhttp3/internal/http2/Http2Connection;Lokhttp3/internal/http2/Http2Reader;)V", "r", "()V", StringUtils.EMPTY, "inFinished", StringUtils.EMPTY, "streamId", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "length", "j", "(ZILokio/BufferedSource;I)V", "associatedStreamId", StringUtils.EMPTY, "Lokhttp3/internal/http2/Header;", "headerBlock", "i", "(ZIILjava/util/List;)V", "Lokhttp3/internal/http2/ErrorCode;", "errorCode", "a", "(ILokhttp3/internal/http2/ErrorCode;)V", "clearPrevious", "Lokhttp3/internal/http2/Settings;", "settings", "h", "(ZLokhttp3/internal/http2/Settings;)V", "o", "e", "ack", "payload1", "payload2", "b", "(ZII)V", "lastGoodStreamId", "Lokio/ByteString;", "debugData", "g", "(ILokhttp3/internal/http2/ErrorCode;Lokio/ByteString;)V", StringUtils.EMPTY, "windowSizeIncrement", "c", "(IJ)V", "streamDependency", "weight", "exclusive", "f", "(IIIZ)V", "promisedStreamId", "requestHeaders", "d", "(IILjava/util/List;)V", "Lokhttp3/internal/http2/Http2Reader;", "getReader$okhttp", "()Lokhttp3/internal/http2/Http2Reader;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nHttp2Connection.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http2Connection.kt\nokhttp3/internal/http2/Http2Connection$ReaderRunnable\n+ 2 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 4 -UtilCommon.kt\nokhttp3/internal/_UtilCommonKt\n*L\n1#1,1054:1\n63#2:1055\n63#2:1056\n63#2:1057\n63#2:1062\n63#2:1063\n38#2:1064\n63#2:1065\n63#2:1070\n38#2:1071\n63#2:1072\n37#3:1058\n36#3,3:1059\n37#3:1066\n36#3,3:1067\n228#4,5:1073\n*S KotlinDebug\n*F\n+ 1 Http2Connection.kt\nokhttp3/internal/http2/Http2Connection$ReaderRunnable\n*L\n690#1:1055\n769#1:1056\n770#1:1057\n804#1:1062\n821#1:1063\n831#1:1064\n857#1:1065\n876#1:1070\n878#1:1071\n883#1:1072\n787#1:1058\n787#1:1059,3\n858#1:1066\n858#1:1067,3\n715#1:1073,5\n*E\n"})
    public final class ReaderRunnable implements Http2Reader.Handler, Function0<Unit> {
        private final Http2Reader a;
        final /* synthetic */ Http2Connection b;

        public ReaderRunnable(Http2Connection http2Connection, Http2Reader http2Reader) {
            Intrinsics.checkNotNullParameter(http2Reader, ap.a(1694194362));
            this.b = http2Connection;
            this.a = http2Reader;
        }

        private static final Unit p(Http2Connection http2Connection, Ref.ObjectRef objectRef) {
            http2Connection.v0().b(http2Connection, (Settings) objectRef.element);
            return Unit.INSTANCE;
        }

        private static final Unit q(Http2Connection http2Connection, Http2Stream http2Stream) {
            try {
                http2Connection.v0().d(http2Stream);
            } catch (IOException e) {
                Platform.a.e().n("Http2Connection.Listener failure for " + http2Connection.j0(), 4, e);
                try {
                    http2Stream.e(ErrorCode.d, e);
                } catch (IOException unused) {
                }
            }
            return Unit.INSTANCE;
        }

        private static final Unit s(Http2Connection http2Connection, int i, int i2) {
            http2Connection.Z1(true, i, i2);
            return Unit.INSTANCE;
        }

        private static final Unit t(ReaderRunnable readerRunnable, boolean z, Settings settings) {
            readerRunnable.o(z, settings);
            return Unit.INSTANCE;
        }

        @Override // okhttp3.internal.http2.Http2Reader.Handler
        public void a(int i, ErrorCode errorCode) {
            Intrinsics.checkNotNullParameter(errorCode, "errorCode");
            if (this.b.i1(i)) {
                this.b.h1(i, errorCode);
                return;
            }
            Http2Stream http2StreamJ1 = this.b.j1(i);
            if (http2StreamJ1 != null) {
                http2StreamJ1.z(errorCode);
            }
        }

        @Override // okhttp3.internal.http2.Http2Reader.Handler
        public void b(boolean z, final int i, final int i2) {
            if (!z) {
                TaskQueue taskQueue = this.b.i;
                String str = this.b.j0() + " ping";
                final Http2Connection http2Connection = this.b;
                TaskQueue.d(taskQueue, str, 0L, false, new Function0() { // from class: okhttp3.internal.http2.i
                    public final Object invoke() {
                        return Http2Connection.ReaderRunnable.s(http2Connection, i, i2);
                    }
                }, 6, null);
                return;
            }
            Http2Connection http2Connection2 = this.b;
            synchronized (http2Connection2) {
                try {
                    if (i == 1) {
                        http2Connection2.n++;
                    } else if (i != 2) {
                        if (i == 3) {
                            http2Connection2.q++;
                            Intrinsics.checkNotNull(http2Connection2, "null cannot be cast to non-null type java.lang.Object");
                            http2Connection2.notifyAll();
                        }
                        Unit unit = Unit.INSTANCE;
                    } else {
                        http2Connection2.p++;
                    }
                } catch (Throwable th) {
                    throw th;
                }
            }
        }

        @Override // okhttp3.internal.http2.Http2Reader.Handler
        public void c(int i, long j) {
            if (i == 0) {
                Http2Connection http2Connection = this.b;
                synchronized (http2Connection) {
                    http2Connection.x = http2Connection.H0() + j;
                    Intrinsics.checkNotNull(http2Connection, "null cannot be cast to non-null type java.lang.Object");
                    http2Connection.notifyAll();
                    Unit unit = Unit.INSTANCE;
                }
                return;
            }
            Http2Stream http2StreamC0 = this.b.C0(i);
            if (http2StreamC0 != null) {
                synchronized (http2StreamC0) {
                    http2StreamC0.b(j);
                    Unit unit2 = Unit.INSTANCE;
                }
            }
        }

        @Override // okhttp3.internal.http2.Http2Reader.Handler
        public void d(int i, int i2, List list) {
            Intrinsics.checkNotNullParameter(list, "requestHeaders");
            this.b.f1(i2, list);
        }

        @Override // okhttp3.internal.http2.Http2Reader.Handler
        public void e() {
        }

        @Override // okhttp3.internal.http2.Http2Reader.Handler
        public void f(int i, int i2, int i3, boolean z) {
        }

        @Override // okhttp3.internal.http2.Http2Reader.Handler
        public void g(int i, ErrorCode errorCode, ByteString byteString) {
            int i2;
            Object[] array;
            Intrinsics.checkNotNullParameter(errorCode, "errorCode");
            Intrinsics.checkNotNullParameter(byteString, "debugData");
            byteString.size();
            Http2Connection http2Connection = this.b;
            synchronized (http2Connection) {
                array = http2Connection.E0().values().toArray(new Http2Stream[0]);
                http2Connection.g = true;
                Unit unit = Unit.INSTANCE;
            }
            for (Http2Stream http2Stream : (Http2Stream[]) array) {
                if (http2Stream.l() > i && http2Stream.t()) {
                    http2Stream.z(ErrorCode.j);
                    this.b.j1(http2Stream.l());
                }
            }
        }

        @Override // okhttp3.internal.http2.Http2Reader.Handler
        public void h(final boolean z, final Settings settings) {
            Intrinsics.checkNotNullParameter(settings, "settings");
            TaskQueue.d(this.b.i, this.b.j0() + " applyAndAckSettings", 0L, false, new Function0() { // from class: okhttp3.internal.http2.k
                public final Object invoke() {
                    return Http2Connection.ReaderRunnable.t(this.a, z, settings);
                }
            }, 6, null);
        }

        @Override // okhttp3.internal.http2.Http2Reader.Handler
        public void i(boolean z, int i, int i2, List list) {
            Intrinsics.checkNotNullParameter(list, "headerBlock");
            if (this.b.i1(i)) {
                this.b.W0(i, list, z);
                return;
            }
            final Http2Connection http2Connection = this.b;
            synchronized (http2Connection) {
                Http2Stream http2StreamC0 = http2Connection.C0(i);
                if (http2StreamC0 != null) {
                    Unit unit = Unit.INSTANCE;
                    http2StreamC0.y(_UtilJvmKt.s(list), z);
                    return;
                }
                if (http2Connection.g) {
                    return;
                }
                if (i <= http2Connection.o0()) {
                    return;
                }
                if (i % 2 == http2Connection.w0() % 2) {
                    return;
                }
                final Http2Stream http2Stream = new Http2Stream(i, http2Connection, false, z, _UtilJvmKt.s(list));
                http2Connection.q1(i);
                http2Connection.E0().put(Integer.valueOf(i), http2Stream);
                TaskQueue.d(http2Connection.h.k(), http2Connection.j0() + AbstractJsonLexerKt.BEGIN_LIST + i + "] onStream", 0L, false, new Function0() { // from class: okhttp3.internal.http2.j
                    public final Object invoke() {
                        return Http2Connection.ReaderRunnable.q(http2Connection, http2Stream);
                    }
                }, 6, null);
            }
        }

        public /* bridge */ /* synthetic */ Object invoke() throws Throwable {
            r();
            return Unit.INSTANCE;
        }

        @Override // okhttp3.internal.http2.Http2Reader.Handler
        public void j(boolean z, int i, BufferedSource bufferedSource, int i2) {
            Intrinsics.checkNotNullParameter(bufferedSource, ClimateForcast.SOURCE);
            if (this.b.i1(i)) {
                this.b.U0(i, bufferedSource, i2, z);
                return;
            }
            Http2Stream http2StreamC0 = this.b.C0(i);
            if (http2StreamC0 == null) {
                this.b.f2(i, ErrorCode.d);
                long j = i2;
                this.b.I1(j);
                bufferedSource.skip(j);
                return;
            }
            http2StreamC0.x(bufferedSource, i2);
            if (z) {
                http2StreamC0.y(Headers.c, true);
            }
        }

        public final void o(boolean z, Settings settings) {
            long jC;
            int i;
            Http2Stream[] http2StreamArr;
            Intrinsics.checkNotNullParameter(settings, "settings");
            final Ref.ObjectRef objectRef = new Ref.ObjectRef();
            Http2Writer http2WriterJ0 = this.b.J0();
            final Http2Connection http2Connection = this.b;
            synchronized (http2WriterJ0) {
                synchronized (http2Connection) {
                    try {
                        Settings settingsZ0 = http2Connection.z0();
                        if (!z) {
                            Settings settings2 = new Settings();
                            settings2.g(settingsZ0);
                            settings2.g(settings);
                            settings = settings2;
                        }
                        objectRef.element = settings;
                        jC = ((long) settings.c()) - ((long) settingsZ0.c());
                        http2StreamArr = (jC == 0 || http2Connection.E0().isEmpty()) ? null : (Http2Stream[]) http2Connection.E0().values().toArray(new Http2Stream[0]);
                        http2Connection.r1((Settings) objectRef.element);
                        TaskQueue.d(http2Connection.k, http2Connection.j0() + " onSettings", 0L, false, new Function0() { // from class: okhttp3.internal.http2.l
                            public final Object invoke() {
                                return Http2Connection.ReaderRunnable.p(http2Connection, objectRef);
                            }
                        }, 6, null);
                        Unit unit = Unit.INSTANCE;
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                try {
                    http2Connection.J0().a((Settings) objectRef.element);
                } catch (IOException e) {
                    http2Connection.e0(e);
                }
                Unit unit2 = Unit.INSTANCE;
            }
            if (http2StreamArr != null) {
                for (Http2Stream http2Stream : http2StreamArr) {
                    synchronized (http2Stream) {
                        http2Stream.b(jC);
                        Unit unit3 = Unit.INSTANCE;
                    }
                }
            }
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r5v3 */
        /* JADX WARN: Type inference failed for: r5v4, types: [java.io.Closeable, okhttp3.internal.http2.Http2Reader] */
        /* JADX WARN: Type inference fix 'apply assigned field type' failed
        java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
        	at jadx.core.dex.instructions.args.ArgType.getObject(SourceFile:16)
        	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(SourceFile:2)
        	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(SourceFile:13)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(SourceFile:100)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(SourceFile:73)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(SourceFile:20)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.a(SourceFile:0)
        	at jadx.core.dex.visitors.typeinference.a.apply(SourceFile:87)
        	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(SourceFile:31)
         */
        public void r() throws Throwable {
            ErrorCode errorCode;
            ErrorCode errorCode2 = ErrorCode.e;
            IOException e = null;
            try {
                try {
                    this.a.o(this);
                    while (this.a.k(false, this)) {
                    }
                    ErrorCode errorCode3 = ErrorCode.c;
                    try {
                        errorCode2 = ErrorCode.k;
                        this.b.d0(errorCode3, errorCode2, null);
                        errorCode = errorCode3;
                    } catch (IOException e2) {
                        e = e2;
                        errorCode2 = ErrorCode.d;
                        Http2Connection http2Connection = this.b;
                        http2Connection.d0(errorCode2, errorCode2, e);
                        errorCode = http2Connection;
                    }
                } catch (Throwable th) {
                    th = th;
                    this.b.d0(errorCode, errorCode2, e);
                    _UtilCommonKt.f(this.a);
                    throw th;
                }
            } catch (IOException e3) {
                e = e3;
            } catch (Throwable th2) {
                th = th2;
                errorCode = errorCode2;
                this.b.d0(errorCode, errorCode2, e);
                _UtilCommonKt.f(this.a);
                throw th;
            }
            this = this.a;
            _UtilCommonKt.f(this);
        }
    }

    static {
        Settings settings = new Settings();
        settings.h(4, 65535);
        settings.h(5, ReaderJsonLexerKt.BATCH_SIZE);
        G = settings;
    }

    public Http2Connection(Builder builder) {
        Intrinsics.checkNotNullParameter(builder, ap.a(1446629411));
        boolean zC = builder.c();
        this.a = zC;
        this.b = builder.f();
        this.c = new LinkedHashMap();
        String strD = builder.d();
        this.d = strD;
        this.f = builder.c() ? 3 : 2;
        TaskRunner taskRunnerL = builder.l();
        this.h = taskRunnerL;
        TaskQueue taskQueueK = taskRunnerL.k();
        this.i = taskQueueK;
        this.j = taskRunnerL.k();
        this.k = taskRunnerL.k();
        this.l = builder.h();
        this.s = builder.e();
        Settings settings = new Settings();
        if (builder.c()) {
            settings.h(4, 16777216);
        }
        this.t = settings;
        this.u = G;
        this.v = new WindowCounter(0);
        this.x = this.u.c();
        this.y = builder.j();
        this.z = new Http2Writer(builder.i(), zC);
        this.A = new ReaderRunnable(this, new Http2Reader(builder.k(), zC));
        this.B = new LinkedHashSet();
        if (builder.g() != 0) {
            final long nanos = TimeUnit.MILLISECONDS.toNanos(builder.g());
            taskQueueK.k(strD + ap.a(993020542), nanos, new Function0() { // from class: okhttp3.internal.http2.b
                public final Object invoke() {
                    return Long.valueOf(Http2Connection.r(this.a, nanos));
                }
            });
        }
    }

    public static /* synthetic */ void H1(Http2Connection http2Connection, boolean z, int i, Object obj) {
        if ((i & 1) != 0) {
            z = true;
        }
        http2Connection.F1(z);
    }

    private final Http2Stream N0(int i, List list, boolean z) {
        Http2Connection http2Connection;
        Throwable th;
        int i2;
        Http2Stream http2Stream;
        boolean z2;
        boolean z3 = !z;
        synchronized (this.z) {
            try {
                synchronized (this) {
                    try {
                        if (this.f > 1073741823) {
                            try {
                                w1(ErrorCode.j);
                            } catch (Throwable th2) {
                                th = th2;
                                http2Connection = this;
                            }
                        }
                        try {
                            if (this.g) {
                                throw new ConnectionShutdownException();
                            }
                            i2 = this.f;
                            this.f = i2 + 2;
                            http2Stream = new Http2Stream(i2, this, z3, false, null);
                            z2 = !z || this.w >= this.x || http2Stream.r() >= http2Stream.q();
                            if (http2Stream.u()) {
                                this.c.put(Integer.valueOf(i2), http2Stream);
                            }
                            Unit unit = Unit.INSTANCE;
                        } catch (Throwable th3) {
                            th = th3;
                        }
                    } catch (Throwable th4) {
                        th = th4;
                        http2Connection = this;
                    }
                    th = th;
                    throw th;
                }
                if (i == 0) {
                    this.z.j(z3, i2, list);
                } else {
                    if (this.a) {
                        throw new IllegalArgumentException("client streams shouldn't have associated stream IDs");
                    }
                    this.z.k(i, i2, list);
                }
            } catch (Throwable th5) {
                throw th5;
            }
        }
        if (z2) {
            this.z.flush();
        }
        return http2Stream;
    }

    private static final Unit S0(Http2Connection http2Connection, int i, Buffer buffer, int i2, boolean z) {
        try {
            boolean zC = http2Connection.l.c(i, buffer, i2, z);
            if (zC) {
                http2Connection.z.o(i, ErrorCode.k);
            }
            if (zC || z) {
                synchronized (http2Connection) {
                    http2Connection.B.remove(Integer.valueOf(i));
                    Unit unit = Unit.INSTANCE;
                }
            }
        } catch (IOException unused) {
        }
        return Unit.INSTANCE;
    }

    private static final Unit V0(Http2Connection http2Connection, int i, List list, boolean z) {
        boolean zB = http2Connection.l.b(i, list, z);
        if (zB) {
            try {
                http2Connection.z.o(i, ErrorCode.k);
            } catch (IOException unused) {
            }
        }
        if (zB || z) {
            synchronized (http2Connection) {
                http2Connection.B.remove(Integer.valueOf(i));
                Unit unit = Unit.INSTANCE;
            }
        }
        return Unit.INSTANCE;
    }

    private static final Unit d1(Http2Connection http2Connection, int i, List list) {
        if (http2Connection.l.a(i, list)) {
            try {
                http2Connection.z.o(i, ErrorCode.k);
                synchronized (http2Connection) {
                    http2Connection.B.remove(Integer.valueOf(i));
                    Unit unit = Unit.INSTANCE;
                }
            } catch (IOException unused) {
            }
        }
        return Unit.INSTANCE;
    }

    private final void e0(IOException iOException) {
        ErrorCode errorCode = ErrorCode.d;
        d0(errorCode, errorCode, iOException);
    }

    private static final Unit e2(Http2Connection http2Connection, int i, ErrorCode errorCode) {
        try {
            http2Connection.c2(i, errorCode);
        } catch (IOException e) {
            http2Connection.e0(e);
        }
        return Unit.INSTANCE;
    }

    private static final Unit g1(Http2Connection http2Connection, int i, ErrorCode errorCode) {
        http2Connection.l.d(i, errorCode);
        synchronized (http2Connection) {
            http2Connection.B.remove(Integer.valueOf(i));
        }
        return Unit.INSTANCE;
    }

    private static final Unit g2(Http2Connection http2Connection, int i, long j) {
        try {
            http2Connection.z.c(i, j);
        } catch (IOException e) {
            http2Connection.e0(e);
        }
        return Unit.INSTANCE;
    }

    private static final Unit m1(Http2Connection http2Connection) {
        http2Connection.Z1(false, 2, 0);
        return Unit.INSTANCE;
    }

    private static final long r(Http2Connection http2Connection, long j) {
        boolean z;
        synchronized (http2Connection) {
            long j2 = http2Connection.n;
            long j3 = http2Connection.m;
            if (j2 < j3) {
                z = true;
            } else {
                http2Connection.m = j3 + 1;
                z = false;
            }
        }
        if (z) {
            http2Connection.e0(null);
            return -1L;
        }
        http2Connection.Z1(false, 1, 0);
        return j;
    }

    public final Http2Stream C0(int i) {
        Http2Stream http2Stream;
        synchronized (this) {
            http2Stream = (Http2Stream) this.c.get(Integer.valueOf(i));
        }
        return http2Stream;
    }

    public final Map E0() {
        return this.c;
    }

    public final void F1(boolean z) {
        if (z) {
            this.z.M();
            this.z.q(this.t);
            if (this.t.c() != 65535) {
                this.z.c(0, r9 - 65535);
            }
        }
        TaskQueue.d(this.h.k(), this.d, 0L, false, this.A, 6, null);
    }

    public final long H0() {
        return this.x;
    }

    public final void I1(long j) {
        synchronized (this) {
            try {
                WindowCounter.c(this.v, j, 0L, 2, null);
                long jA = this.v.a();
                if (jA >= this.t.c() / 2) {
                    h2(0, jA);
                    WindowCounter.c(this.v, 0L, jA, 1, null);
                }
                this.s.b(this.v);
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final Http2Writer J0() {
        return this.z;
    }

    /* JADX WARN: Code restructure failed: missing block: B:19:0x003a, code lost:
    
        r2 = java.lang.Math.min((int) java.lang.Math.min(r12, r6 - r4), r8.z.r2());
        r6 = r2;
        r8.w += r6;
        r4 = kotlin.Unit.INSTANCE;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void J1(int r9, boolean r10, okio.Buffer r11, long r12) {
        /*
            r8 = this;
            r0 = 0
            int r2 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            r3 = 0
            if (r2 != 0) goto Ld
            okhttp3.internal.http2.Http2Writer r8 = r8.z
            r8.L1(r10, r9, r11, r3)
            return
        Ld:
            int r2 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            if (r2 <= 0) goto L71
            monitor-enter(r8)
        L12:
            long r4 = r8.w     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            long r6 = r8.x     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            int r2 = (r4 > r6 ? 1 : (r4 == r6 ? 0 : -1))
            if (r2 < 0) goto L39
            java.util.Map r2 = r8.c     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            java.lang.Integer r4 = java.lang.Integer.valueOf(r9)     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            boolean r2 = r2.containsKey(r4)     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            if (r2 == 0) goto L31
            java.lang.String r2 = "null cannot be cast to non-null type java.lang.Object"
            kotlin.jvm.internal.Intrinsics.checkNotNull(r8, r2)     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            r8.wait()     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            goto L12
        L2f:
            r9 = move-exception
            goto L6f
        L31:
            java.io.IOException r9 = new java.io.IOException     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            java.lang.String r10 = "stream closed"
            r9.<init>(r10)     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
            throw r9     // Catch: java.lang.Throwable -> L2f java.lang.InterruptedException -> L62
        L39:
            long r6 = r6 - r4
            long r4 = java.lang.Math.min(r12, r6)     // Catch: java.lang.Throwable -> L2f
            int r2 = (int) r4     // Catch: java.lang.Throwable -> L2f
            okhttp3.internal.http2.Http2Writer r4 = r8.z     // Catch: java.lang.Throwable -> L2f
            int r4 = r4.r2()     // Catch: java.lang.Throwable -> L2f
            int r2 = java.lang.Math.min(r2, r4)     // Catch: java.lang.Throwable -> L2f
            long r4 = r8.w     // Catch: java.lang.Throwable -> L2f
            long r6 = (long) r2     // Catch: java.lang.Throwable -> L2f
            long r4 = r4 + r6
            r8.w = r4     // Catch: java.lang.Throwable -> L2f
            kotlin.Unit r4 = kotlin.Unit.INSTANCE     // Catch: java.lang.Throwable -> L2f
            monitor-exit(r8)
            long r12 = r12 - r6
            okhttp3.internal.http2.Http2Writer r4 = r8.z
            if (r10 == 0) goto L5d
            int r5 = (r12 > r0 ? 1 : (r12 == r0 ? 0 : -1))
            if (r5 != 0) goto L5d
            r5 = 1
            goto L5e
        L5d:
            r5 = r3
        L5e:
            r4.L1(r5, r9, r11, r2)
            goto Ld
        L62:
            java.lang.Thread r9 = java.lang.Thread.currentThread()     // Catch: java.lang.Throwable -> L2f
            r9.interrupt()     // Catch: java.lang.Throwable -> L2f
            java.io.InterruptedIOException r9 = new java.io.InterruptedIOException     // Catch: java.lang.Throwable -> L2f
            r9.<init>()     // Catch: java.lang.Throwable -> L2f
            throw r9     // Catch: java.lang.Throwable -> L2f
        L6f:
            monitor-exit(r8)
            throw r9
        L71:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.http2.Http2Connection.J1(int, boolean, okio.Buffer, long):void");
    }

    public final boolean M0(long j) {
        synchronized (this) {
            if (this.g) {
                return false;
            }
            if (this.p < this.o) {
                if (j >= this.r) {
                    return false;
                }
            }
            return true;
        }
    }

    public final Http2Stream O0(List list, boolean z) {
        Intrinsics.checkNotNullParameter(list, "requestHeaders");
        return N0(0, list, z);
    }

    public final void Q1(int i, boolean z, List list) {
        Intrinsics.checkNotNullParameter(list, "alternating");
        this.z.j(z, i, list);
    }

    public final void U0(final int i, BufferedSource bufferedSource, final int i2, final boolean z) {
        Intrinsics.checkNotNullParameter(bufferedSource, ClimateForcast.SOURCE);
        final Buffer buffer = new Buffer();
        long j = i2;
        bufferedSource.s2(j);
        bufferedSource.k3(buffer, j);
        TaskQueue.d(this.j, this.d + AbstractJsonLexerKt.BEGIN_LIST + i + "] onData", 0L, false, new Function0() { // from class: okhttp3.internal.http2.a
            public final Object invoke() {
                return Http2Connection.S0(this.a, i, buffer, i2, z);
            }
        }, 6, null);
    }

    public final void W0(final int i, final List list, final boolean z) {
        Intrinsics.checkNotNullParameter(list, "requestHeaders");
        TaskQueue.d(this.j, this.d + AbstractJsonLexerKt.BEGIN_LIST + i + "] onHeaders", 0L, false, new Function0() { // from class: okhttp3.internal.http2.h
            public final Object invoke() {
                return Http2Connection.V0(this.a, i, list, z);
            }
        }, 6, null);
    }

    public final void Z1(boolean z, int i, int i2) {
        try {
            this.z.b(z, i, i2);
        } catch (IOException e) {
            e0(e);
        }
    }

    public final void c2(int i, ErrorCode errorCode) {
        Intrinsics.checkNotNullParameter(errorCode, "statusCode");
        this.z.o(i, errorCode);
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        d0(ErrorCode.c, ErrorCode.k, null);
    }

    public final void d0(ErrorCode errorCode, ErrorCode errorCode2, IOException iOException) {
        int i;
        Object[] array;
        Intrinsics.checkNotNullParameter(errorCode, "connectionCode");
        Intrinsics.checkNotNullParameter(errorCode2, "streamCode");
        if (_UtilJvmKt.b && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
        }
        try {
            w1(errorCode);
        } catch (IOException unused) {
        }
        synchronized (this) {
            try {
                if (this.c.isEmpty()) {
                    array = null;
                } else {
                    array = this.c.values().toArray(new Http2Stream[0]);
                    this.c.clear();
                }
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
        Http2Stream[] http2StreamArr = (Http2Stream[]) array;
        if (http2StreamArr != null) {
            for (Http2Stream http2Stream : http2StreamArr) {
                try {
                    http2Stream.e(errorCode2, iOException);
                } catch (IOException unused2) {
                }
            }
        }
        try {
            this.z.close();
        } catch (IOException unused3) {
        }
        try {
            this.y.close();
        } catch (IOException unused4) {
        }
        this.i.q();
        this.j.q();
        this.k.q();
    }

    public final void f1(final int i, final List list) {
        Intrinsics.checkNotNullParameter(list, "requestHeaders");
        synchronized (this) {
            if (this.B.contains(Integer.valueOf(i))) {
                f2(i, ErrorCode.d);
                return;
            }
            this.B.add(Integer.valueOf(i));
            TaskQueue.d(this.j, this.d + AbstractJsonLexerKt.BEGIN_LIST + i + "] onRequest", 0L, false, new Function0() { // from class: okhttp3.internal.http2.f
                public final Object invoke() {
                    return Http2Connection.d1(this.a, i, list);
                }
            }, 6, null);
        }
    }

    public final void f2(final int i, final ErrorCode errorCode) {
        Intrinsics.checkNotNullParameter(errorCode, "errorCode");
        TaskQueue.d(this.i, this.d + AbstractJsonLexerKt.BEGIN_LIST + i + "] writeSynReset", 0L, false, new Function0() { // from class: okhttp3.internal.http2.e
            public final Object invoke() {
                return Http2Connection.e2(this.a, i, errorCode);
            }
        }, 6, null);
    }

    public final void flush() {
        this.z.flush();
    }

    public final void h1(final int i, final ErrorCode errorCode) {
        Intrinsics.checkNotNullParameter(errorCode, "errorCode");
        TaskQueue.d(this.j, this.d + AbstractJsonLexerKt.BEGIN_LIST + i + "] onReset", 0L, false, new Function0() { // from class: okhttp3.internal.http2.g
            public final Object invoke() {
                return Http2Connection.g1(this.a, i, errorCode);
            }
        }, 6, null);
    }

    public final void h2(final int i, final long j) {
        TaskQueue.d(this.i, this.d + AbstractJsonLexerKt.BEGIN_LIST + i + "] windowUpdate", 0L, false, new Function0() { // from class: okhttp3.internal.http2.c
            public final Object invoke() {
                return Http2Connection.g2(this.a, i, j);
            }
        }, 6, null);
    }

    public final boolean i0() {
        return this.a;
    }

    public final boolean i1(int i) {
        return i != 0 && (i & 1) == 0;
    }

    public final String j0() {
        return this.d;
    }

    public final Http2Stream j1(int i) {
        Http2Stream http2Stream;
        synchronized (this) {
            http2Stream = (Http2Stream) this.c.remove(Integer.valueOf(i));
            Intrinsics.checkNotNull(this, "null cannot be cast to non-null type java.lang.Object");
            notifyAll();
        }
        return http2Stream;
    }

    public final FlowControlListener m0() {
        return this.s;
    }

    public final int o0() {
        return this.e;
    }

    public final void o1() {
        synchronized (this) {
            long j = this.p;
            long j2 = this.o;
            if (j < j2) {
                return;
            }
            this.o = j2 + 1;
            this.r = System.nanoTime() + ((long) InstantKt.NANOS_PER_SECOND);
            Unit unit = Unit.INSTANCE;
            TaskQueue.d(this.i, this.d + " ping", 0L, false, new Function0() { // from class: okhttp3.internal.http2.d
                public final Object invoke() {
                    return Http2Connection.m1(this.a);
                }
            }, 6, null);
        }
    }

    public final void q1(int i) {
        this.e = i;
    }

    public final void r1(Settings settings) {
        Intrinsics.checkNotNullParameter(settings, "<set-?>");
        this.u = settings;
    }

    public final Listener v0() {
        return this.b;
    }

    public final int w0() {
        return this.f;
    }

    public final void w1(ErrorCode errorCode) {
        Intrinsics.checkNotNullParameter(errorCode, "statusCode");
        synchronized (this.z) {
            Ref.IntRef intRef = new Ref.IntRef();
            synchronized (this) {
                if (this.g) {
                    return;
                }
                this.g = true;
                int i = this.e;
                intRef.element = i;
                Unit unit = Unit.INSTANCE;
                this.z.g(i, errorCode, _UtilCommonKt.a);
            }
        }
    }

    public final Settings x0() {
        return this.t;
    }

    public final Settings z0() {
        return this.u;
    }
}