package okhttp3.internal.http2;

import h.ap;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.SourceDebugExtension;
import org.apache.tika.utils.StringUtils;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\b\n\u0002\b\u0017\b\u0086\u0081\u0002\u0018\u0000 \b2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\nB\u0011\b\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\b\u0010\tj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012j\u0002\b\u0013j\u0002\b\u0014j\u0002\b\u0015j\u0002\b\u0016j\u0002\b\u0017j\u0002\b\u0018¨\u0006\u0019"}, d2 = {"Lokhttp3/internal/http2/ErrorCode;", StringUtils.EMPTY, StringUtils.EMPTY, "httpCode", "<init>", "(Ljava/lang/String;II)V", "a", "I", "b", "()I", "Companion", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ErrorCode {
    public static final Companion b;
    public static final ErrorCode c = new ErrorCode(ap.a(1112376551), 0, 0);
    public static final ErrorCode d = new ErrorCode(ap.a(1423614477), 1, 1);
    public static final ErrorCode e = new ErrorCode(ap.a(722408622), 2, 2);
    public static final ErrorCode f = new ErrorCode(ap.a(7158856), 3, 3);
    public static final ErrorCode g = new ErrorCode(ap.a(1457594365), 4, 4);
    public static final ErrorCode h = new ErrorCode(ap.a(1911713929), 5, 5);
    public static final ErrorCode i = new ErrorCode(ap.a(1746960379), 6, 6);
    public static final ErrorCode j = new ErrorCode(ap.a(563464104), 7, 7);
    public static final ErrorCode k = new ErrorCode(ap.a(1098835374), 8, 8);
    public static final ErrorCode l = new ErrorCode(ap.a(401504543), 9, 9);
    public static final ErrorCode m = new ErrorCode(ap.a(788452574), 10, 10);
    public static final ErrorCode n = new ErrorCode(ap.a(477675975), 11, 11);
    public static final ErrorCode o = new ErrorCode(ap.a(509936190), 12, 12);
    public static final ErrorCode p = new ErrorCode(ap.a(840291363), 13, 13);
    private static final /* synthetic */ ErrorCode[] q;
    private static final /* synthetic */ EnumEntries r;
    private final int a;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lokhttp3/internal/http2/ErrorCode$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "code", "Lokhttp3/internal/http2/ErrorCode;", "a", "(I)Lokhttp3/internal/http2/ErrorCode;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nErrorCode.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ErrorCode.kt\nokhttp3/internal/http2/ErrorCode$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,56:1\n1#2:57\n*E\n"})
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final ErrorCode a(int i) {
            for (ErrorCode errorCode : ErrorCode.values()) {
                if (errorCode.b() == i) {
                    return errorCode;
                }
            }
            return null;
        }

        private Companion() {
        }
    }

    static {
        ErrorCode[] errorCodeArrA = a();
        q = errorCodeArrA;
        r = EnumEntriesKt.enumEntries(errorCodeArrA);
        b = new Companion(null);
    }

    private ErrorCode(String str, int i2, int i3) {
        this.a = i3;
    }

    private static final /* synthetic */ ErrorCode[] a() {
        return new ErrorCode[]{c, d, e, f, g, h, i, j, k, l, m, n, o, p};
    }

    public static ErrorCode valueOf(String str) {
        return (ErrorCode) Enum.valueOf(ErrorCode.class, str);
    }

    public static ErrorCode[] values() {
        return (ErrorCode[]) q.clone();
    }

    public final int b() {
        return this.a;
    }
}