package okhttp3.internal.http2.flowcontrol;

import h.ap;
import kotlin.Metadata;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u000e\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J!\u0010\n\u001a\u00020\t2\b\b\u0002\u0010\u0007\u001a\u00020\u00062\b\b\u0002\u0010\b\u001a\u00020\u0006¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\r\u0010\u000eR\u0017\u0010\u0003\u001a\u00020\u00028\u0006¢\u0006\f\n\u0004\b\u000f\u0010\u0010\u001a\u0004\b\u0011\u0010\u0012R$\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00068\u0006@BX\u0086\u000e¢\u0006\f\n\u0004\b\n\u0010\u0014\u001a\u0004\b\u0015\u0010\u0016R$\u0010\b\u001a\u00020\u00062\u0006\u0010\u0013\u001a\u00020\u00068\u0006@BX\u0086\u000e¢\u0006\f\n\u0004\b\u0017\u0010\u0014\u001a\u0004\b\u0018\u0010\u0016R\u0011\u0010\u0019\u001a\u00020\u00068F¢\u0006\u0006\u001a\u0004\b\u000f\u0010\u0016¨\u0006\u001a"}, d2 = {"Lokhttp3/internal/http2/flowcontrol/WindowCounter;", StringUtils.EMPTY, StringUtils.EMPTY, "streamId", "<init>", "(I)V", StringUtils.EMPTY, "total", "acknowledged", StringUtils.EMPTY, "b", "(JJ)V", StringUtils.EMPTY, "toString", "()Ljava/lang/String;", "a", "I", "getStreamId", "()I", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "J", "getTotal", "()J", "c", "getAcknowledged", "unacknowledged", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class WindowCounter {
    private final int a;
    private long b;
    private long c;

    public WindowCounter(int i) {
        this.a = i;
    }

    public static /* synthetic */ void c(WindowCounter windowCounter, long j, long j2, int i, Object obj) {
        if ((i & 1) != 0) {
            j = 0;
        }
        if ((i & 2) != 0) {
            j2 = 0;
        }
        windowCounter.b(j, j2);
    }

    public final synchronized long a() {
        return this.b - this.c;
    }

    public final synchronized void b(long j, long j2) {
        try {
            if (j < 0) {
                throw new IllegalStateException(ap.a(1134862650));
            }
            if (j2 < 0) {
                throw new IllegalStateException(ap.a(1382668086));
            }
            long j3 = this.b + j;
            this.b = j3;
            long j4 = this.c + j2;
            this.c = j4;
            if (j4 > j3) {
                throw new IllegalStateException(ap.a(2034925369));
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public String toString() {
        return "WindowCounter(streamId=" + this.a + ", total=" + this.b + ", acknowledged=" + this.c + ", unacknowledged=" + a() + ')';
    }
}