package okhttp3.internal.http2;

import h.ap;
import java.io.Closeable;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.serialization.json.internal.ReaderJsonLexerKt;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.concurrent.Lockable;
import okhttp3.internal.http2.Hpack;
import okio.Buffer;
import okio.BufferedSink;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u000f\n\u0002\u0010\u0012\n\u0002\b\u0014\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u0000 62\u00020\u00012\u00020\u0002:\u0001OB\u0017\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0005¢\u0006\u0004\b\u0007\u0010\bJ\u001f\u0010\u000e\u001a\u00020\r2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\f\u001a\u00020\u000bH\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\r\u0010\u0010\u001a\u00020\r¢\u0006\u0004\b\u0010\u0010\u0011J\u0015\u0010\u0014\u001a\u00020\r2\u0006\u0010\u0013\u001a\u00020\u0012¢\u0006\u0004\b\u0014\u0010\u0015J+\u0010\u001a\u001a\u00020\r2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u0016\u001a\u00020\t2\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u00180\u0017¢\u0006\u0004\b\u001a\u0010\u001bJ\r\u0010\u001c\u001a\u00020\r¢\u0006\u0004\b\u001c\u0010\u0011J\u001d\u0010\u001f\u001a\u00020\r2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u001e\u001a\u00020\u001d¢\u0006\u0004\b\u001f\u0010 J\r\u0010!\u001a\u00020\t¢\u0006\u0004\b!\u0010\"J/\u0010&\u001a\u00020\r2\u0006\u0010#\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\t2\b\u0010%\u001a\u0004\u0018\u00010$2\u0006\u0010\f\u001a\u00020\t¢\u0006\u0004\b&\u0010'J/\u0010*\u001a\u00020\r2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010(\u001a\u00020\t2\b\u0010)\u001a\u0004\u0018\u00010$2\u0006\u0010\f\u001a\u00020\t¢\u0006\u0004\b*\u0010+J\u0015\u0010-\u001a\u00020\r2\u0006\u0010,\u001a\u00020\u0012¢\u0006\u0004\b-\u0010\u0015J%\u00101\u001a\u00020\r2\u0006\u0010.\u001a\u00020\u00052\u0006\u0010/\u001a\u00020\t2\u0006\u00100\u001a\u00020\t¢\u0006\u0004\b1\u00102J%\u00106\u001a\u00020\r2\u0006\u00103\u001a\u00020\t2\u0006\u0010\u001e\u001a\u00020\u001d2\u0006\u00105\u001a\u000204¢\u0006\u0004\b6\u00107J\u001d\u00109\u001a\u00020\r2\u0006\u0010\n\u001a\u00020\t2\u0006\u00108\u001a\u00020\u000b¢\u0006\u0004\b9\u0010\u000fJ-\u0010<\u001a\u00020\r2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010:\u001a\u00020\t2\u0006\u0010;\u001a\u00020\t2\u0006\u0010(\u001a\u00020\t¢\u0006\u0004\b<\u0010=J\u000f\u0010>\u001a\u00020\rH\u0016¢\u0006\u0004\b>\u0010\u0011J+\u0010@\u001a\u00020\r2\u0006\u0010#\u001a\u00020\u00052\u0006\u0010\n\u001a\u00020\t2\f\u0010?\u001a\b\u0012\u0004\u0012\u00020\u00180\u0017¢\u0006\u0004\b@\u0010AR\u0014\u0010\u0004\u001a\u00020\u00038\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0014\u0010BR\u0014\u0010\u0006\u001a\u00020\u00058\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b1\u0010CR\u0014\u0010E\u001a\u00020$8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b9\u0010DR\u0016\u0010G\u001a\u00020\t8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b*\u0010FR\u0016\u0010H\u001a\u00020\u00058\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b<\u0010CR\u0017\u0010N\u001a\u00020I8\u0006¢\u0006\f\n\u0004\bJ\u0010K\u001a\u0004\bL\u0010M¨\u0006P"}, d2 = {"Lokhttp3/internal/http2/Http2Writer;", "Ljava/io/Closeable;", "Lokhttp3/internal/concurrent/Lockable;", "Lokio/BufferedSink;", "sink", StringUtils.EMPTY, "client", "<init>", "(Lokio/BufferedSink;Z)V", StringUtils.EMPTY, "streamId", StringUtils.EMPTY, "byteCount", StringUtils.EMPTY, "r", "(IJ)V", "M", "()V", "Lokhttp3/internal/http2/Settings;", "peerSettings", "a", "(Lokhttp3/internal/http2/Settings;)V", "promisedStreamId", StringUtils.EMPTY, "Lokhttp3/internal/http2/Header;", "requestHeaders", "k", "(IILjava/util/List;)V", "flush", "Lokhttp3/internal/http2/ErrorCode;", "errorCode", "o", "(ILokhttp3/internal/http2/ErrorCode;)V", "r2", "()I", "outFinished", "Lokio/Buffer;", ClimateForcast.SOURCE, "L1", "(ZILokio/Buffer;I)V", "flags", "buffer", "d", "(IILokio/Buffer;I)V", "settings", "q", "ack", "payload1", "payload2", "b", "(ZII)V", "lastGoodStreamId", StringUtils.EMPTY, "debugData", "g", "(ILokhttp3/internal/http2/ErrorCode;[B)V", "windowSizeIncrement", "c", "length", "type", "e", "(IIII)V", "close", "headerBlock", "j", "(ZILjava/util/List;)V", "Lokio/BufferedSink;", "Z", "Lokio/Buffer;", "hpackBuffer", "I", "maxFrameSize", "closed", "Lokhttp3/internal/http2/Hpack$Writer;", "f", "Lokhttp3/internal/http2/Hpack$Writer;", "getHpackWriter", "()Lokhttp3/internal/http2/Hpack$Writer;", "hpackWriter", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nHttp2Writer.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http2Writer.kt\nokhttp3/internal/http2/Http2Writer\n+ 2 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,384:1\n63#2:385\n63#2:386\n63#2:387\n63#2:388\n63#2:389\n63#2:390\n63#2:391\n63#2:392\n63#2:393\n63#2:395\n63#2:396\n63#2:397\n1#3:394\n*S KotlinDebug\n*F\n+ 1 Http2Writer.kt\nokhttp3/internal/http2/Http2Writer\n*L\n60#1:385\n74#1:386\n108#1:387\n129#1:388\n140#1:389\n172#1:390\n201#1:391\n228#1:392\n256#1:393\n283#1:395\n329#1:396\n360#1:397\n*E\n"})
public final class Http2Writer implements Closeable, Lockable {
    public static final Companion g = new Companion(null);
    private static final Logger h = Logger.getLogger(Http2.class.getName());
    private final BufferedSink a;
    private final boolean b;
    private final Buffer c;
    private int d;
    private boolean e;
    private final Hpack.Writer f;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\n \u0006*\u0004\u0018\u00010\u00050\u0005X\u0082\u0004¢\u0006\u0002\n\u0000¨\u0006\u0007"}, d2 = {"Lokhttp3/internal/http2/Http2Writer$Companion;", StringUtils.EMPTY, "<init>", "()V", "logger", "Ljava/util/logging/Logger;", "kotlin.jvm.PlatformType", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    public Http2Writer(BufferedSink bufferedSink, boolean z) {
        Intrinsics.checkNotNullParameter(bufferedSink, ap.a(1565121020));
        this.a = bufferedSink;
        this.b = z;
        Buffer buffer = new Buffer();
        this.c = buffer;
        this.d = ReaderJsonLexerKt.BATCH_SIZE;
        this.f = new Hpack.Writer(0, false, buffer, 3, null);
    }

    private final void r(int i, long j) {
        while (j > 0) {
            long jMin = Math.min(this.d, j);
            j -= jMin;
            e(i, (int) jMin, 9, j == 0 ? 4 : 0);
            this.a.a2(this.c, jMin);
        }
    }

    public final void L1(boolean z, int i, Buffer buffer, int i2) {
        synchronized (this) {
            if (this.e) {
                throw new IOException("closed");
            }
            d(i, z ? 1 : 0, buffer, i2);
            Unit unit = Unit.INSTANCE;
        }
    }

    public final void M() {
        synchronized (this) {
            try {
                if (this.e) {
                    throw new IOException("closed");
                }
                if (this.b) {
                    Logger logger = h;
                    if (logger.isLoggable(Level.FINE)) {
                        logger.fine(_UtilJvmKt.j(">> CONNECTION " + Http2.b.l(), new Object[0]));
                    }
                    this.a.l1(Http2.b);
                    this.a.flush();
                    Unit unit = Unit.INSTANCE;
                }
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void a(Settings settings) {
        Intrinsics.checkNotNullParameter(settings, "peerSettings");
        synchronized (this) {
            try {
                if (this.e) {
                    throw new IOException("closed");
                }
                this.d = settings.e(this.d);
                if (settings.b() != -1) {
                    this.f.e(settings.b());
                }
                e(0, 0, 4, 1);
                this.a.flush();
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void b(boolean z, int i, int i2) {
        synchronized (this) {
            if (this.e) {
                throw new IOException("closed");
            }
            e(0, 8, 6, z ? 1 : 0);
            this.a.writeInt(i);
            this.a.writeInt(i2);
            this.a.flush();
            Unit unit = Unit.INSTANCE;
        }
    }

    public final void c(int i, long j) {
        int i2;
        long j2;
        synchronized (this) {
            try {
                if (this.e) {
                    throw new IOException("closed");
                }
                if (j == 0 || j > 2147483647L) {
                    throw new IllegalArgumentException(("windowSizeIncrement == 0 || windowSizeIncrement > 0x7fffffffL: " + j).toString());
                }
                Logger logger = h;
                if (logger.isLoggable(Level.FINE)) {
                    i2 = i;
                    j2 = j;
                    logger.fine(Http2.a.d(false, i2, 4, j2));
                } else {
                    i2 = i;
                    j2 = j;
                }
                e(i2, 4, 8, 0);
                this.a.writeInt((int) j2);
                this.a.flush();
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        synchronized (this) {
            this.e = true;
            this.a.close();
            Unit unit = Unit.INSTANCE;
        }
    }

    public final void d(int i, int i2, Buffer buffer, int i3) {
        e(i, i3, 0, i2);
        if (i3 > 0) {
            BufferedSink bufferedSink = this.a;
            Intrinsics.checkNotNull(buffer);
            bufferedSink.a2(buffer, i3);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:7:0x001d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void e(int r9, int r10, int r11, int r12) {
        /*
            r8 = this;
            r0 = 8
            if (r11 == r0) goto L1d
            java.util.logging.Logger r0 = okhttp3.internal.http2.Http2Writer.h
            java.util.logging.Level r1 = java.util.logging.Level.FINE
            boolean r1 = r0.isLoggable(r1)
            if (r1 == 0) goto L1d
            okhttp3.internal.http2.Http2 r2 = okhttp3.internal.http2.Http2.a
            r3 = 0
            r4 = r9
            r5 = r10
            r6 = r11
            r7 = r12
            java.lang.String r9 = r2.c(r3, r4, r5, r6, r7)
            r0.fine(r9)
            goto L21
        L1d:
            r4 = r9
            r5 = r10
            r6 = r11
            r7 = r12
        L21:
            int r9 = r8.d
            if (r5 > r9) goto L62
            r9 = -2147483648(0xffffffff80000000, float:-0.0)
            r9 = r9 & r4
            if (r9 != 0) goto L47
            okio.BufferedSink r9 = r8.a
            okhttp3.internal._UtilCommonKt.H(r9, r5)
            okio.BufferedSink r9 = r8.a
            r10 = r6 & 255(0xff, float:3.57E-43)
            r9.writeByte(r10)
            okio.BufferedSink r9 = r8.a
            r10 = r7 & 255(0xff, float:3.57E-43)
            r9.writeByte(r10)
            okio.BufferedSink r8 = r8.a
            r9 = 2147483647(0x7fffffff, float:NaN)
            r9 = r9 & r4
            r8.writeInt(r9)
            return
        L47:
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>()
            java.lang.String r9 = "reserved bit set: "
            r8.append(r9)
            r8.append(r4)
            java.lang.String r8 = r8.toString()
            java.lang.IllegalArgumentException r9 = new java.lang.IllegalArgumentException
            java.lang.String r8 = r8.toString()
            r9.<init>(r8)
            throw r9
        L62:
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            java.lang.String r10 = "FRAME_SIZE_ERROR length > "
            r9.append(r10)
            int r8 = r8.d
            r9.append(r8)
            java.lang.String r8 = ": "
            r9.append(r8)
            r9.append(r5)
            java.lang.String r8 = r9.toString()
            java.lang.IllegalArgumentException r9 = new java.lang.IllegalArgumentException
            java.lang.String r8 = r8.toString()
            r9.<init>(r8)
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.http2.Http2Writer.e(int, int, int, int):void");
    }

    public final void flush() {
        synchronized (this) {
            if (this.e) {
                throw new IOException("closed");
            }
            this.a.flush();
            Unit unit = Unit.INSTANCE;
        }
    }

    public final void g(int i, ErrorCode errorCode, byte[] bArr) {
        Intrinsics.checkNotNullParameter(errorCode, "errorCode");
        Intrinsics.checkNotNullParameter(bArr, "debugData");
        synchronized (this) {
            try {
                if (this.e) {
                    throw new IOException("closed");
                }
                if (errorCode.b() == -1) {
                    throw new IllegalArgumentException("errorCode.httpCode == -1");
                }
                e(0, bArr.length + 8, 7, 0);
                this.a.writeInt(i);
                this.a.writeInt(errorCode.b());
                if (!(bArr.length == 0)) {
                    this.a.write(bArr);
                }
                this.a.flush();
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void j(boolean z, int i, List list) {
        Intrinsics.checkNotNullParameter(list, "headerBlock");
        synchronized (this) {
            try {
                if (this.e) {
                    throw new IOException("closed");
                }
                this.f.g(list);
                long size = this.c.size();
                long jMin = Math.min(this.d, size);
                int i2 = size == jMin ? 4 : 0;
                if (z) {
                    i2 |= 1;
                }
                e(i, (int) jMin, 1, i2);
                this.a.a2(this.c, jMin);
                if (size > jMin) {
                    r(i, size - jMin);
                }
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void k(int i, int i2, List list) {
        Intrinsics.checkNotNullParameter(list, "requestHeaders");
        synchronized (this) {
            try {
                if (this.e) {
                    throw new IOException("closed");
                }
                this.f.g(list);
                long size = this.c.size();
                int iMin = (int) Math.min(((long) this.d) - 4, size);
                long j = iMin;
                e(i, iMin + 4, 5, size == j ? 4 : 0);
                this.a.writeInt(i2 & Integer.MAX_VALUE);
                this.a.a2(this.c, j);
                if (size > j) {
                    r(i, size - j);
                }
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final void o(int i, ErrorCode errorCode) {
        Intrinsics.checkNotNullParameter(errorCode, "errorCode");
        synchronized (this) {
            if (this.e) {
                throw new IOException("closed");
            }
            if (errorCode.b() == -1) {
                throw new IllegalArgumentException("Failed requirement.");
            }
            e(i, 4, 3, 0);
            this.a.writeInt(errorCode.b());
            this.a.flush();
            Unit unit = Unit.INSTANCE;
        }
    }

    public final void q(Settings settings) {
        Intrinsics.checkNotNullParameter(settings, "settings");
        synchronized (this) {
            try {
                if (this.e) {
                    throw new IOException("closed");
                }
                e(0, settings.i() * 6, 4, 0);
                for (int i = 0; i < 10; i++) {
                    if (settings.f(i)) {
                        this.a.writeShort(i);
                        this.a.writeInt(settings.a(i));
                    }
                }
                this.a.flush();
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    public final int r2() {
        return this.d;
    }
}