package okhttp3.internal.http2;

import h.ap;
import java.io.EOFException;
import java.io.IOException;
import java.io.InterruptedIOException;
import java.net.SocketTimeoutException;
import java.util.ArrayDeque;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.Headers;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.concurrent.Lockable;
import okhttp3.internal.http2.flowcontrol.WindowCounter;
import okio.AsyncTimeout;
import okio.Buffer;
import okio.BufferedSource;
import okio.Sink;
import okio.Socket;
import okio.Source;
import okio.Timeout;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000~\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\t\n\u0002\b\f\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u001a\u0018\u0000 Y2\u00020\u00012\u00020\u0002:\u0004lmnoB3\b\u0000\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\t\u001a\u00020\u0007\u0012\b\u0010\u000b\u001a\u0004\u0018\u00010\n¢\u0006\u0004\b\f\u0010\rJ!\u0010\u0012\u001a\u00020\u00072\u0006\u0010\u000f\u001a\u00020\u000e2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0010H\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0014\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\u0014\u0010\u0015J\u0017\u0010\u0017\u001a\u00020\n2\b\b\u0002\u0010\u0016\u001a\u00020\u0007¢\u0006\u0004\b\u0017\u0010\u0018J\r\u0010\u001a\u001a\u00020\u0019¢\u0006\u0004\b\u001a\u0010\u001bJ\r\u0010\u001c\u001a\u00020\u0019¢\u0006\u0004\b\u001c\u0010\u001bJ\u001f\u0010\u001f\u001a\u00020\u001e2\u0006\u0010\u001d\u001a\u00020\u000e2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0010¢\u0006\u0004\b\u001f\u0010 J\u0015\u0010!\u001a\u00020\u001e2\u0006\u0010\u000f\u001a\u00020\u000e¢\u0006\u0004\b!\u0010\"J\u001d\u0010&\u001a\u00020\u001e2\u0006\u0010$\u001a\u00020#2\u0006\u0010%\u001a\u00020\u0003¢\u0006\u0004\b&\u0010'J\u001d\u0010(\u001a\u00020\u001e2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\t\u001a\u00020\u0007¢\u0006\u0004\b(\u0010)J\u0015\u0010*\u001a\u00020\u001e2\u0006\u0010\u000f\u001a\u00020\u000e¢\u0006\u0004\b*\u0010\"J\u000f\u0010+\u001a\u00020\u001eH\u0000¢\u0006\u0004\b+\u0010,J\u0015\u0010/\u001a\u00020\u001e2\u0006\u0010.\u001a\u00020-¢\u0006\u0004\b/\u00100J\u000f\u00101\u001a\u00020\u001eH\u0000¢\u0006\u0004\b1\u0010,J\u000f\u00102\u001a\u00020\u001eH\u0000¢\u0006\u0004\b2\u0010,R\u0017\u0010\u0004\u001a\u00020\u00038\u0006¢\u0006\f\n\u0004\b3\u00104\u001a\u0004\b5\u00106R\u0017\u0010\u0006\u001a\u00020\u00058\u0006¢\u0006\f\n\u0004\b/\u00107\u001a\u0004\b8\u00109R\u0017\u0010>\u001a\u00020:8\u0006¢\u0006\f\n\u0004\b+\u0010;\u001a\u0004\b<\u0010=R*\u0010D\u001a\u00020-2\u0006\u0010?\u001a\u00020-8\u0006@@X\u0086\u000e¢\u0006\u0012\n\u0004\b1\u0010@\u001a\u0004\bA\u0010B\"\u0004\bC\u00100R*\u0010G\u001a\u00020-2\u0006\u0010?\u001a\u00020-8\u0006@@X\u0086\u000e¢\u0006\u0012\n\u0004\b\u001f\u0010@\u001a\u0004\bE\u0010B\"\u0004\bF\u00100R\u001a\u0010J\u001a\b\u0012\u0004\u0012\u00020\n0H8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010IR\u0016\u0010L\u001a\u00020\u00078\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b!\u0010KR\u001e\u0010$\u001a\u00060MR\u00020\u00008\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u0014\u0010N\u001a\u0004\bO\u0010PR\u001e\u0010U\u001a\u00060QR\u00020\u00008\u0016X\u0096\u0004¢\u0006\f\n\u0004\b8\u0010R\u001a\u0004\bS\u0010TR\u001e\u0010[\u001a\u00060VR\u00020\u00008\u0000X\u0080\u0004¢\u0006\f\n\u0004\bW\u0010X\u001a\u0004\bY\u0010ZR\u001e\u0010^\u001a\u00060VR\u00020\u00008\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\\\u0010X\u001a\u0004\b]\u0010ZR$\u0010\u000f\u001a\u0004\u0018\u00010\u000e8@@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b5\u0010_\u001a\u0004\bW\u0010`\"\u0004\ba\u0010\"R$\u0010\u0011\u001a\u0004\u0018\u00010\u00108\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b<\u0010b\u001a\u0004\b\\\u0010c\"\u0004\bd\u0010eR\u0011\u0010g\u001a\u00020\u00078F¢\u0006\u0006\u001a\u0004\bf\u0010\u0015R\u0011\u0010i\u001a\u00020\u00078F¢\u0006\u0006\u001a\u0004\bh\u0010\u0015R\u0011\u0010k\u001a\u00020\u00078F¢\u0006\u0006\u001a\u0004\bj\u0010\u0015¨\u0006p"}, d2 = {"Lokhttp3/internal/http2/Http2Stream;", "Lokhttp3/internal/concurrent/Lockable;", "Lokio/Socket;", StringUtils.EMPTY, "id", "Lokhttp3/internal/http2/Http2Connection;", "connection", StringUtils.EMPTY, "outFinished", "inFinished", "Lokhttp3/Headers;", "headers", "<init>", "(ILokhttp3/internal/http2/Http2Connection;ZZLokhttp3/Headers;)V", "Lokhttp3/internal/http2/ErrorCode;", "errorCode", "Ljava/io/IOException;", "errorException", "f", "(Lokhttp3/internal/http2/ErrorCode;Ljava/io/IOException;)Z", "h", "()Z", "callerIsIdle", "B", "(Z)Lokhttp3/Headers;", "Lokio/Timeout;", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "()Lokio/Timeout;", "D", "rstStatusCode", StringUtils.EMPTY, "e", "(Lokhttp3/internal/http2/ErrorCode;Ljava/io/IOException;)V", "g", "(Lokhttp3/internal/http2/ErrorCode;)V", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "length", "x", "(Lokio/BufferedSource;I)V", "y", "(Lokhttp3/Headers;Z)V", "z", "c", "()V", StringUtils.EMPTY, "delta", "b", "(J)V", "d", "C", "a", "I", "l", "()I", "Lokhttp3/internal/http2/Http2Connection;", "i", "()Lokhttp3/internal/http2/Http2Connection;", "Lokhttp3/internal/http2/flowcontrol/WindowCounter;", "Lokhttp3/internal/http2/flowcontrol/WindowCounter;", "m", "()Lokhttp3/internal/http2/flowcontrol/WindowCounter;", "readBytes", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "J", "r", "()J", "A", "writeBytesTotal", "q", "setWriteBytesMaximum$okhttp", "writeBytesMaximum", "Ljava/util/ArrayDeque;", "Ljava/util/ArrayDeque;", "headersQueue", "Z", "hasResponseHeaders", "Lokhttp3/internal/http2/Http2Stream$FramingSource;", "Lokhttp3/internal/http2/Http2Stream$FramingSource;", "p", "()Lokhttp3/internal/http2/Http2Stream$FramingSource;", "Lokhttp3/internal/http2/Http2Stream$FramingSink;", "Lokhttp3/internal/http2/Http2Stream$FramingSink;", "o", "()Lokhttp3/internal/http2/Http2Stream$FramingSink;", "sink", "Lokhttp3/internal/http2/Http2Stream$StreamTimeout;", "j", "Lokhttp3/internal/http2/Http2Stream$StreamTimeout;", "n", "()Lokhttp3/internal/http2/Http2Stream$StreamTimeout;", "readTimeout", "k", "s", "writeTimeout", "Lokhttp3/internal/http2/ErrorCode;", "()Lokhttp3/internal/http2/ErrorCode;", "setErrorCode$okhttp", "Ljava/io/IOException;", "()Ljava/io/IOException;", "setErrorException$okhttp", "(Ljava/io/IOException;)V", "u", "isOpen", "t", "isLocallyInitiated", "v", "isSourceComplete", "FramingSource", "FramingSink", "Companion", "StreamTimeout", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nHttp2Stream.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http2Stream.kt\nokhttp3/internal/http2/Http2Stream\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n*L\n1#1,743:1\n1#2:744\n63#3:745\n63#3:746\n63#3:747\n63#3:748\n63#3:749\n49#3,4:750\n63#3:754\n38#3:755\n63#3:756\n63#3:757\n49#3,4:758\n63#3:762\n38#3:763\n49#3,4:764\n49#3,4:768\n63#3:772\n38#3:773\n63#3:774\n38#3:775\n49#3,4:776\n63#3:780\n38#3:781\n34#3:782\n*S KotlinDebug\n*F\n+ 1 Http2Stream.kt\nokhttp3/internal/http2/Http2Stream\n*L\n89#1:745\n114#1:746\n136#1:747\n149#1:748\n175#1:749\n200#1:750,4\n203#1:754\n207#1:755\n214#1:756\n227#1:757\n272#1:758,4\n274#1:762\n280#1:763\n294#1:764,4\n304#1:768,4\n307#1:772\n321#1:773\n329#1:774\n332#1:775\n543#1:776,4\n547#1:780\n693#1:781\n713#1:782\n*E\n"})
public final class Http2Stream implements Lockable, Socket {
    public static final Companion n = new Companion(null);
    private final int a;
    private final Http2Connection b;
    private final WindowCounter c;
    private long d;
    private long e;
    private final ArrayDeque f;
    private boolean g;
    private final FramingSource h;
    private final FramingSink i;
    private final StreamTimeout j;
    private final StreamTimeout k;
    private ErrorCode l;
    private IOException m;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0012\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u000e\u0010\u0004\u001a\u00020\u0005X\u0080T¢\u0006\u0002\n\u0000¨\u0006\u0006"}, d2 = {"Lokhttp3/internal/http2/Http2Stream$Companion;", StringUtils.EMPTY, "<init>", "()V", "EMIT_BUFFER_SIZE", StringUtils.EMPTY, "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\f\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0011\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u0017\u0010\b\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u0002H\u0002¢\u0006\u0004\b\b\u0010\tJ\u001f\u0010\u000e\u001a\u00020\u00072\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0010\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0010\u0010\u0011J\u000f\u0010\u0013\u001a\u00020\u0012H\u0016¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010\u0015\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0015\u0010\u0011R\"\u0010\u0003\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\b\u0010\u0016\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\tR\u0014\u0010\u001c\u001a\u00020\n8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010\u001bR$\u0010$\u001a\u0004\u0018\u00010\u001d8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u001e\u0010\u001f\u001a\u0004\b \u0010!\"\u0004\b\"\u0010#R\"\u0010(\u001a\u00020\u00028\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b%\u0010\u0016\u001a\u0004\b&\u0010\u0018\"\u0004\b'\u0010\t¨\u0006)"}, d2 = {"Lokhttp3/internal/http2/Http2Stream$FramingSink;", "Lokio/Sink;", StringUtils.EMPTY, "finished", "<init>", "(Lokhttp3/internal/http2/Http2Stream;Z)V", "outFinishedOnLastFrame", StringUtils.EMPTY, "a", "(Z)V", "Lokio/Buffer;", ClimateForcast.SOURCE, StringUtils.EMPTY, "byteCount", "a2", "(Lokio/Buffer;J)V", "flush", "()V", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", "close", "Z", "k", "()Z", "setFinished", "b", "Lokio/Buffer;", "sendBuffer", "Lokhttp3/Headers;", "c", "Lokhttp3/Headers;", "getTrailers", "()Lokhttp3/Headers;", "setTrailers", "(Lokhttp3/Headers;)V", "trailers", "d", "j", "setClosed", "closed", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nHttp2Stream.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http2Stream.kt\nokhttp3/internal/http2/Http2Stream$FramingSink\n+ 2 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n*L\n1#1,743:1\n49#2,4:744\n63#2:748\n49#2,4:749\n63#2:753\n49#2,4:754\n63#2:758\n63#2:759\n38#2:760\n*S KotlinDebug\n*F\n+ 1 Http2Stream.kt\nokhttp3/internal/http2/Http2Stream$FramingSink\n*L\n582#1:744,4\n598#1:748\n628#1:749,4\n630#1:753\n644#1:754,4\n647#1:758\n676#1:759\n678#1:760\n*E\n"})
    public final class FramingSink implements Sink {
        private boolean a;
        private final Buffer b = new Buffer();
        private Headers c;
        private boolean d;

        public FramingSink(boolean z) {
            this.a = z;
        }

        /* JADX WARN: Finally extract failed */
        private final void a(boolean z) throws IOException {
            long jMin;
            boolean z2;
            Http2Stream http2Stream = Http2Stream.this;
            synchronized (http2Stream) {
                try {
                    http2Stream.s().u();
                    while (http2Stream.r() >= http2Stream.q() && !this.a && !this.d && http2Stream.j() == null) {
                        try {
                            http2Stream.C();
                        } catch (Throwable th) {
                            http2Stream.s().E();
                            throw th;
                        }
                    }
                    http2Stream.s().E();
                    http2Stream.d();
                    jMin = Math.min(http2Stream.q() - http2Stream.r(), this.b.size());
                    http2Stream.A(http2Stream.r() + jMin);
                    z2 = z && jMin == this.b.size();
                    Unit unit = Unit.INSTANCE;
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            Http2Stream.this.s().u();
            try {
                Http2Stream.this.i().J1(Http2Stream.this.l(), z2, this.b, jMin);
            } finally {
                Http2Stream.this.s().E();
            }
        }

        @Override // okio.Sink
        public void a2(Buffer buffer, long j) throws IOException {
            Intrinsics.checkNotNullParameter(buffer, ap.a(583579163));
            Http2Stream http2Stream = Http2Stream.this;
            if (!_UtilJvmKt.b || !Thread.holdsLock(http2Stream)) {
                this.b.a2(buffer, j);
                while (this.b.size() >= 16384) {
                    a(false);
                }
            } else {
                throw new AssertionError(ap.a(159625637) + Thread.currentThread().getName() + ap.a(473059406) + http2Stream);
            }
        }

        @Override // okio.Sink, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            Http2Stream http2Stream = Http2Stream.this;
            if (_UtilJvmKt.b && Thread.holdsLock(http2Stream)) {
                throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + http2Stream);
            }
            Http2Stream http2Stream2 = Http2Stream.this;
            synchronized (http2Stream2) {
                if (this.d) {
                    return;
                }
                boolean z = http2Stream2.j() == null;
                Unit unit = Unit.INSTANCE;
                if (!Http2Stream.this.o().a) {
                    boolean z2 = this.b.size() > 0;
                    if (this.c != null) {
                        while (this.b.size() > 0) {
                            a(false);
                        }
                        Http2Connection http2ConnectionI = Http2Stream.this.i();
                        int iL = Http2Stream.this.l();
                        Headers headers = this.c;
                        Intrinsics.checkNotNull(headers);
                        http2ConnectionI.Q1(iL, z, _UtilJvmKt.r(headers));
                    } else if (z2) {
                        while (this.b.size() > 0) {
                            a(true);
                        }
                    } else if (z) {
                        Http2Stream.this.i().J1(Http2Stream.this.l(), true, null, 0L);
                    }
                }
                Http2Stream http2Stream3 = Http2Stream.this;
                synchronized (http2Stream3) {
                    this.d = true;
                    Intrinsics.checkNotNull(http2Stream3, "null cannot be cast to non-null type java.lang.Object");
                    http2Stream3.notifyAll();
                    Unit unit2 = Unit.INSTANCE;
                }
                Http2Stream.this.i().flush();
                Http2Stream.this.c();
            }
        }

        @Override // okio.Sink, java.io.Flushable
        public void flush() throws IOException {
            Http2Stream http2Stream = Http2Stream.this;
            if (_UtilJvmKt.b && Thread.holdsLock(http2Stream)) {
                throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + http2Stream);
            }
            Http2Stream http2Stream2 = Http2Stream.this;
            synchronized (http2Stream2) {
                http2Stream2.d();
                Unit unit = Unit.INSTANCE;
            }
            while (this.b.size() > 0) {
                a(false);
                Http2Stream.this.i().flush();
            }
        }

        public final boolean j() {
            return this.d;
        }

        public final boolean k() {
            return this.a;
        }

        @Override // okio.Sink
        public Timeout timeout() {
            return Http2Stream.this.s();
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0014\n\u0002\u0018\u0002\n\u0002\b\f\b\u0086\u0004\u0018\u00002\u00020\u0001B\u0019\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u0017\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u0002H\u0002¢\u0006\u0004\b\n\u0010\u000bJ\u001f\u0010\u000f\u001a\u00020\u00022\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u000f\u0010\u0010J\u001f\u0010\u0013\u001a\u00020\t2\u0006\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u000e\u001a\u00020\u0002H\u0000¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010\u0016\u001a\u00020\u0015H\u0016¢\u0006\u0004\b\u0016\u0010\u0017J\u000f\u0010\u0018\u001a\u00020\tH\u0016¢\u0006\u0004\b\u0018\u0010\u0019R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010\u001bR\"\u0010\u0005\u001a\u00020\u00048\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010!R\u0017\u0010&\u001a\u00020\f8\u0006¢\u0006\f\n\u0004\b\"\u0010#\u001a\u0004\b$\u0010%R\u0017\u0010)\u001a\u00020\f8\u0006¢\u0006\f\n\u0004\b'\u0010#\u001a\u0004\b(\u0010%R$\u00101\u001a\u0004\u0018\u00010*8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b+\u0010,\u001a\u0004\b-\u0010.\"\u0004\b/\u00100R\"\u00105\u001a\u00020\u00048\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b2\u0010\u001d\u001a\u0004\b3\u0010\u001f\"\u0004\b4\u0010!¨\u00066"}, d2 = {"Lokhttp3/internal/http2/Http2Stream$FramingSource;", "Lokio/Source;", StringUtils.EMPTY, "maxByteCount", StringUtils.EMPTY, "finished", "<init>", "(Lokhttp3/internal/http2/Http2Stream;JZ)V", "read", StringUtils.EMPTY, "A", "(J)V", "Lokio/Buffer;", "sink", "byteCount", "k3", "(Lokio/Buffer;J)J", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "q", "(Lokio/BufferedSource;J)V", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", "close", "()V", "a", "J", "b", "Z", "k", "()Z", "r", "(Z)V", "c", "Lokio/Buffer;", "getReceiveBuffer", "()Lokio/Buffer;", "receiveBuffer", "d", "o", "readBuffer", "Lokhttp3/Headers;", "e", "Lokhttp3/Headers;", "getTrailers", "()Lokhttp3/Headers;", "u", "(Lokhttp3/Headers;)V", "trailers", "f", "j", "setClosed$okhttp", "closed", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nHttp2Stream.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Http2Stream.kt\nokhttp3/internal/http2/Http2Stream$FramingSource\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n*L\n1#1,743:1\n1#2:744\n63#3:745\n49#3,4:746\n49#3,4:750\n63#3:754\n63#3:755\n38#3:756\n63#3:757\n38#3:758\n*S KotlinDebug\n*F\n+ 1 Http2Stream.kt\nokhttp3/internal/http2/Http2Stream$FramingSource\n*L\n390#1:745\n453#1:746,4\n467#1:750,4\n474#1:754\n500#1:755\n507#1:756\n528#1:757\n532#1:758\n*E\n"})
    public final class FramingSource implements Source {
        private final long a;
        private boolean b;
        private final Buffer c = new Buffer();
        private final Buffer d = new Buffer();
        private Headers e;
        private boolean f;

        public FramingSource(long j, boolean z) {
            this.a = j;
            this.b = z;
        }

        private final void A(long j) {
            Http2Stream http2Stream = Http2Stream.this;
            if (!_UtilJvmKt.b || !Thread.holdsLock(http2Stream)) {
                Http2Stream.this.i().I1(j);
                return;
            }
            throw new AssertionError(ap.a(1545165116) + Thread.currentThread().getName() + ap.a(311059787) + http2Stream);
        }

        @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            long size;
            Http2Stream http2Stream = Http2Stream.this;
            synchronized (http2Stream) {
                this.f = true;
                size = this.d.size();
                this.d.j();
                Intrinsics.checkNotNull(http2Stream, "null cannot be cast to non-null type java.lang.Object");
                http2Stream.notifyAll();
                Unit unit = Unit.INSTANCE;
            }
            if (size > 0) {
                A(size);
            }
            Http2Stream.this.c();
        }

        public final boolean j() {
            return this.f;
        }

        public final boolean k() {
            return this.b;
        }

        @Override // okio.Source
        public long k3(Buffer buffer, long j) throws IOException {
            IOException iOExceptionK;
            boolean z;
            long jK3;
            Intrinsics.checkNotNullParameter(buffer, "sink");
            long j2 = 0;
            if (j < 0) {
                throw new IllegalArgumentException(("byteCount < 0: " + j).toString());
            }
            while (true) {
                Http2Stream http2Stream = Http2Stream.this;
                synchronized (http2Stream) {
                    boolean zH = http2Stream.h();
                    if (zH) {
                        http2Stream.n().u();
                    }
                    try {
                        if (http2Stream.j() == null || this.b) {
                            iOExceptionK = null;
                        } else {
                            iOExceptionK = http2Stream.k();
                            if (iOExceptionK == null) {
                                ErrorCode errorCodeJ = http2Stream.j();
                                Intrinsics.checkNotNull(errorCodeJ);
                                iOExceptionK = new StreamResetException(errorCodeJ);
                            }
                        }
                        if (this.f) {
                            throw new IOException("stream closed");
                        }
                        z = false;
                        if (this.d.size() > j2) {
                            Buffer buffer2 = this.d;
                            jK3 = buffer2.k3(buffer, Math.min(j, buffer2.size()));
                            WindowCounter.c(http2Stream.m(), jK3, 0L, 2, null);
                            long jA = http2Stream.m().a();
                            if (iOExceptionK == null && jA >= http2Stream.i().x0().c() / 2) {
                                http2Stream.i().h2(http2Stream.l(), jA);
                                WindowCounter.c(http2Stream.m(), 0L, jA, 1, null);
                            }
                        } else {
                            if (!this.b && iOExceptionK == null) {
                                http2Stream.C();
                                z = true;
                            }
                            jK3 = -1;
                        }
                        if (zH) {
                            http2Stream.n().E();
                        }
                        Unit unit = Unit.INSTANCE;
                    } finally {
                    }
                }
                Http2Stream.this.i().m0().a(Http2Stream.this.l(), Http2Stream.this.m(), this.d.size());
                if (!z) {
                    if (jK3 != -1) {
                        return jK3;
                    }
                    if (iOExceptionK == null) {
                        return -1L;
                    }
                    throw iOExceptionK;
                }
                j2 = 0;
            }
        }

        public final Buffer o() {
            return this.d;
        }

        public final void q(BufferedSource bufferedSource, long j) throws EOFException {
            boolean z;
            boolean z2;
            Intrinsics.checkNotNullParameter(bufferedSource, ClimateForcast.SOURCE);
            Http2Stream http2Stream = Http2Stream.this;
            if (_UtilJvmKt.b && Thread.holdsLock(http2Stream)) {
                throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + http2Stream);
            }
            long j2 = j;
            while (j2 > 0) {
                synchronized (Http2Stream.this) {
                    z = this.b;
                    z2 = this.d.size() + j2 > this.a;
                    Unit unit = Unit.INSTANCE;
                }
                if (z2) {
                    bufferedSource.skip(j2);
                    Http2Stream.this.g(ErrorCode.f);
                    return;
                }
                if (z) {
                    bufferedSource.skip(j2);
                    return;
                }
                long jK3 = bufferedSource.k3(this.c, j2);
                if (jK3 == -1) {
                    throw new EOFException();
                }
                j2 -= jK3;
                Http2Stream http2Stream2 = Http2Stream.this;
                synchronized (http2Stream2) {
                    try {
                        if (this.f) {
                            this.c.j();
                        } else {
                            boolean z3 = this.d.size() == 0;
                            this.d.d2(this.c);
                            if (z3) {
                                Intrinsics.checkNotNull(http2Stream2, "null cannot be cast to non-null type java.lang.Object");
                                http2Stream2.notifyAll();
                            }
                        }
                    } finally {
                    }
                }
            }
            A(j);
            Http2Stream.this.i().m0().a(Http2Stream.this.l(), Http2Stream.this.m(), this.d.size());
        }

        public final void r(boolean z) {
            this.b = z;
        }

        @Override // okio.Source
        public Timeout timeout() {
            return Http2Stream.this.n();
        }

        public final void u(Headers headers) {
            this.e = headers;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0080\u0004\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0014¢\u0006\u0004\b\u0005\u0010\u0006J\u0019\u0010\t\u001a\u00020\u00072\b\u0010\b\u001a\u0004\u0018\u00010\u0007H\u0014¢\u0006\u0004\b\t\u0010\nJ\r\u0010\u000b\u001a\u00020\u0004¢\u0006\u0004\b\u000b\u0010\u0006¨\u0006\f"}, d2 = {"Lokhttp3/internal/http2/Http2Stream$StreamTimeout;", "Lokio/AsyncTimeout;", "<init>", "(Lokhttp3/internal/http2/Http2Stream;)V", StringUtils.EMPTY, "D", "()V", "Ljava/io/IOException;", "cause", "x", "(Ljava/io/IOException;)Ljava/io/IOException;", "E", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public final class StreamTimeout extends AsyncTimeout {
        public StreamTimeout() {
        }

        @Override // okio.AsyncTimeout
        protected void D() {
            Http2Stream.this.g(ErrorCode.k);
            Http2Stream.this.i().o1();
        }

        public final void E() throws IOException {
            if (v()) {
                throw x(null);
            }
        }

        @Override // okio.AsyncTimeout
        protected IOException x(IOException iOException) {
            SocketTimeoutException socketTimeoutException = new SocketTimeoutException(ap.a(1858897120));
            if (iOException != null) {
                socketTimeoutException.initCause(iOException);
            }
            return socketTimeoutException;
        }
    }

    public Http2Stream(int i, Http2Connection http2Connection, boolean z, boolean z2, Headers headers) {
        Intrinsics.checkNotNullParameter(http2Connection, ap.a(1331533799));
        this.a = i;
        this.b = http2Connection;
        this.c = new WindowCounter(i);
        this.e = http2Connection.z0().c();
        ArrayDeque arrayDeque = new ArrayDeque();
        this.f = arrayDeque;
        this.h = new FramingSource(http2Connection.x0().c(), z2);
        this.i = new FramingSink(z);
        this.j = new StreamTimeout();
        this.k = new StreamTimeout();
        if (headers == null) {
            if (!t()) {
                throw new IllegalStateException(ap.a(1544829567));
            }
        } else {
            if (t()) {
                throw new IllegalStateException(ap.a(574249748));
            }
            arrayDeque.add(headers);
        }
    }

    private final boolean f(ErrorCode errorCode, IOException iOException) {
        if (_UtilJvmKt.b && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
        }
        synchronized (this) {
            if (j() != null) {
                return false;
            }
            this.l = errorCode;
            this.m = iOException;
            Intrinsics.checkNotNull(this, "null cannot be cast to non-null type java.lang.Object");
            notifyAll();
            if (p().k() && o().k()) {
                return false;
            }
            Unit unit = Unit.INSTANCE;
            this.b.j1(this.a);
            return true;
        }
    }

    private final boolean h() {
        return !this.b.i0() || o().j() || o().k();
    }

    public final void A(long j) {
        this.d = j;
    }

    public final Headers B(boolean z) {
        Headers headers;
        synchronized (this) {
            while (this.f.isEmpty() && j() == null) {
                try {
                    boolean z2 = z || h();
                    if (z2) {
                        this.j.u();
                    }
                    try {
                        C();
                        if (z2) {
                            this.j.E();
                        }
                    } catch (Throwable th) {
                        if (z2) {
                            this.j.E();
                        }
                        throw th;
                    }
                } catch (Throwable th2) {
                    throw th2;
                }
            }
            if (this.f.isEmpty()) {
                IOException iOException = this.m;
                if (iOException != null) {
                    throw iOException;
                }
                ErrorCode errorCodeJ = j();
                Intrinsics.checkNotNull(errorCodeJ);
                throw new StreamResetException(errorCodeJ);
            }
            Object objRemoveFirst = this.f.removeFirst();
            Intrinsics.checkNotNullExpressionValue(objRemoveFirst, "removeFirst(...)");
            headers = (Headers) objRemoveFirst;
        }
        return headers;
    }

    public final void C() throws InterruptedIOException {
        try {
            Intrinsics.checkNotNull(this, "null cannot be cast to non-null type java.lang.Object");
            wait();
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
            throw new InterruptedIOException();
        }
    }

    public final Timeout D() {
        return this.k;
    }

    public final void b(long j) {
        this.e += j;
        if (j > 0) {
            Intrinsics.checkNotNull(this, "null cannot be cast to non-null type java.lang.Object");
            notifyAll();
        }
    }

    public final void c() {
        boolean z;
        boolean zU;
        if (_UtilJvmKt.b && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
        }
        synchronized (this) {
            try {
                z = !p().k() && p().j() && (o().k() || o().j());
                zU = u();
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
        if (z) {
            e(ErrorCode.k, null);
        } else {
            if (zU) {
                return;
            }
            this.b.j1(this.a);
        }
    }

    public final void d() throws IOException {
        if (o().j()) {
            throw new IOException("stream closed");
        }
        if (o().k()) {
            throw new IOException("stream finished");
        }
        if (j() != null) {
            IOException iOException = this.m;
            if (iOException != null) {
                throw iOException;
            }
            ErrorCode errorCodeJ = j();
            Intrinsics.checkNotNull(errorCodeJ);
            throw new StreamResetException(errorCodeJ);
        }
    }

    public final void e(ErrorCode errorCode, IOException iOException) {
        Intrinsics.checkNotNullParameter(errorCode, "rstStatusCode");
        if (f(errorCode, iOException)) {
            this.b.c2(this.a, errorCode);
        }
    }

    public final void g(ErrorCode errorCode) {
        Intrinsics.checkNotNullParameter(errorCode, "errorCode");
        if (f(errorCode, null)) {
            this.b.f2(this.a, errorCode);
        }
    }

    public final Http2Connection i() {
        return this.b;
    }

    public final ErrorCode j() {
        ErrorCode errorCode;
        synchronized (this) {
            errorCode = this.l;
        }
        return errorCode;
    }

    public final IOException k() {
        return this.m;
    }

    public final int l() {
        return this.a;
    }

    public final WindowCounter m() {
        return this.c;
    }

    public final StreamTimeout n() {
        return this.j;
    }

    public FramingSink o() {
        return this.i;
    }

    public FramingSource p() {
        return this.h;
    }

    public final long q() {
        return this.e;
    }

    public final long r() {
        return this.d;
    }

    public final StreamTimeout s() {
        return this.k;
    }

    public final boolean t() {
        return this.b.i0() == ((this.a & 1) == 1);
    }

    public final boolean u() {
        synchronized (this) {
            try {
                if (j() != null) {
                    return false;
                }
                if (p().k() || p().j()) {
                    if (o().k() || o().j()) {
                        if (this.g) {
                            return false;
                        }
                    }
                }
                return true;
            } catch (Throwable th) {
                throw th;
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x001d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean v() {
        /*
            r1 = this;
            monitor-enter(r1)
            okhttp3.internal.http2.Http2Stream$FramingSource r0 = r1.p()     // Catch: java.lang.Throwable -> L1b
            boolean r0 = r0.k()     // Catch: java.lang.Throwable -> L1b
            if (r0 == 0) goto L1d
            okhttp3.internal.http2.Http2Stream$FramingSource r0 = r1.p()     // Catch: java.lang.Throwable -> L1b
            okio.Buffer r0 = r0.o()     // Catch: java.lang.Throwable -> L1b
            boolean r0 = r0.H2()     // Catch: java.lang.Throwable -> L1b
            if (r0 == 0) goto L1d
            r0 = 1
            goto L1e
        L1b:
            r0 = move-exception
            goto L20
        L1d:
            r0 = 0
        L1e:
            monitor-exit(r1)
            return r0
        L20:
            monitor-exit(r1)
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.http2.Http2Stream.v():boolean");
    }

    public final Timeout w() {
        return this.j;
    }

    public final void x(BufferedSource bufferedSource, int i) {
        Intrinsics.checkNotNullParameter(bufferedSource, ClimateForcast.SOURCE);
        if (!_UtilJvmKt.b || !Thread.holdsLock(this)) {
            p().q(bufferedSource, i);
            return;
        }
        throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
    }

    public final void y(Headers headers, boolean z) {
        boolean zU;
        Intrinsics.checkNotNullParameter(headers, "headers");
        if (_UtilJvmKt.b && Thread.holdsLock(this)) {
            throw new AssertionError("Thread " + Thread.currentThread().getName() + " MUST NOT hold lock on " + this);
        }
        synchronized (this) {
            try {
                if (this.g && headers.a(":status") == null && headers.a(":method") == null) {
                    p().u(headers);
                } else {
                    this.g = true;
                    this.f.add(headers);
                }
                if (z) {
                    p().r(true);
                }
                zU = u();
                Intrinsics.checkNotNull(this, "null cannot be cast to non-null type java.lang.Object");
                notifyAll();
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
        if (zU) {
            return;
        }
        this.b.j1(this.a);
    }

    public final void z(ErrorCode errorCode) {
        Intrinsics.checkNotNullParameter(errorCode, "errorCode");
        synchronized (this) {
            try {
                if (j() == null) {
                    this.l = errorCode;
                    Intrinsics.checkNotNull(this, "null cannot be cast to non-null type java.lang.Object");
                    notifyAll();
                }
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
    }
}