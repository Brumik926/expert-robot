package okhttp3.internal.http2;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import okhttp3.internal._UtilJvmKt;
import okio.ByteString;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\b\u0006\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J5\u0010\f\u001a\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u0006¢\u0006\u0004\b\f\u0010\rJ-\u0010\u0010\u001a\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\b\u001a\u00020\u00062\u0006\u0010\u000f\u001a\u00020\u000e¢\u0006\u0004\b\u0010\u0010\u0011J\u0017\u0010\u0012\u001a\u00020\u000b2\u0006\u0010\t\u001a\u00020\u0006H\u0000¢\u0006\u0004\b\u0012\u0010\u0013J\u001d\u0010\u0014\u001a\u00020\u000b2\u0006\u0010\t\u001a\u00020\u00062\u0006\u0010\n\u001a\u00020\u0006¢\u0006\u0004\b\u0014\u0010\u0015R\u0014\u0010\u0018\u001a\u00020\u00168\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010\u0017R\u001a\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u000b0\u00198\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\f\u0010\u001aR\u001c\u0010\u001c\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u00198\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0010\u0010\u001aR\u001a\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u000b0\u00198\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010\u001a¨\u0006\u001f"}, d2 = {"Lokhttp3/internal/http2/Http2;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "inbound", StringUtils.EMPTY, "streamId", "length", "type", "flags", StringUtils.EMPTY, "c", "(ZIIII)Ljava/lang/String;", StringUtils.EMPTY, "windowSizeIncrement", "d", "(ZIIJ)Ljava/lang/String;", "b", "(I)Ljava/lang/String;", "a", "(II)Ljava/lang/String;", "Lokio/ByteString;", "Lokio/ByteString;", "CONNECTION_PREFACE", StringUtils.EMPTY, "[Ljava/lang/String;", "FRAME_NAMES", "FLAGS", "e", "BINARY", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Http2 {
    public static final Http2 a = new Http2();
    public static final ByteString b = ByteString.d.d(ap.a(682145402));
    private static final String[] c = {ap.a(916137690), ap.a(915900725), ap.a(617878474), ap.a(2120329861), ap.a(464245324), ap.a(651977596), ap.a(1044887250), ap.a(1209281008), ap.a(23434221), ap.a(218141056)};
    private static final String[] d = new String[64];
    private static final String[] e;

    static {
        String[] strArr = new String[256];
        for (int i = 0; i < 256; i++) {
            String binaryString = Integer.toBinaryString(i);
            Intrinsics.checkNotNullExpressionValue(binaryString, ap.a(1528555625));
            strArr[i] = StringsKt.replace$default(_UtilJvmKt.j(ap.a(1968831023), binaryString), ' ', '0', false, 4, (Object) null);
        }
        e = strArr;
        String[] strArr2 = d;
        strArr2[0] = ap.a(1479817044);
        strArr2[1] = ap.a(2104197127);
        int[] iArr = {1};
        strArr2[8] = ap.a(1747709863);
        int i2 = iArr[0];
        int i3 = i2 | 8;
        StringBuilder sb = new StringBuilder();
        sb.append(strArr2[i2]);
        String strA = ap.a(572906147);
        sb.append(strA);
        strArr2[i3] = sb.toString();
        strArr2[4] = ap.a(404881851);
        strArr2[32] = ap.a(1521941348);
        strArr2[36] = ap.a(1103589835);
        int[] iArr2 = {4, 32, 36};
        for (int i4 = 0; i4 < 3; i4++) {
            int i5 = iArr2[i4];
            int i6 = iArr[0];
            String[] strArr3 = d;
            int i7 = i6 | i5;
            strArr3[i7] = strArr3[i6] + '|' + strArr3[i5];
            strArr3[i7 | 8] = strArr3[i6] + '|' + strArr3[i5] + strA;
        }
        int length = d.length;
        for (int i8 = 0; i8 < length; i8++) {
            String[] strArr4 = d;
            if (strArr4[i8] == null) {
                strArr4[i8] = e[i8];
            }
        }
    }

    private Http2() {
    }

    public final String a(int i, int i2) {
        String str;
        if (i2 == 0) {
            return StringUtils.EMPTY;
        }
        if (i != 2 && i != 3) {
            if (i == 4 || i == 6) {
                return i2 == 1 ? "ACK" : e[i2];
            }
            if (i != 7 && i != 8) {
                String[] strArr = d;
                if (i2 < strArr.length) {
                    str = strArr[i2];
                    Intrinsics.checkNotNull(str);
                } else {
                    str = e[i2];
                }
                String str2 = str;
                return (i != 5 || (i2 & 4) == 0) ? (i != 0 || (i2 & 32) == 0) ? str2 : StringsKt.replace$default(str2, "PRIORITY", "COMPRESSED", false, 4, (Object) null) : StringsKt.replace$default(str2, "HEADERS", "PUSH_PROMISE", false, 4, (Object) null);
            }
        }
        return e[i2];
    }

    public final String b(int i) {
        String[] strArr = c;
        return i < strArr.length ? strArr[i] : _UtilJvmKt.j("0x%02x", Integer.valueOf(i));
    }

    public final String c(boolean z, int i, int i2, int i3, int i4) {
        return _UtilJvmKt.j("%s 0x%08x %5d %-13s %s", z ? "<<" : ">>", Integer.valueOf(i), Integer.valueOf(i2), b(i3), a(i3, i4));
    }

    public final String d(boolean z, int i, int i2, long j) {
        return _UtilJvmKt.j("%s 0x%08x %5d %-13s %d", z ? "<<" : ">>", Integer.valueOf(i), Integer.valueOf(i2), b(8), Long.valueOf(j));
    }
}