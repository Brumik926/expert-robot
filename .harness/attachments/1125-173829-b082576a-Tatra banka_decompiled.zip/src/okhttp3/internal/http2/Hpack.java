package okhttp3.internal.http2;

import h.ap;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlinx.coroutines.scheduling.WorkQueueKt;
import kotlinx.serialization.json.internal.ReaderJsonLexerKt;
import okhttp3.internal._UtilCommonKt;
import okio.Buffer;
import okio.BufferedSource;
import okio.ByteString;
import okio.Okio;
import okio.Source;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\b\n\bÆ\u0002\u0018\u00002\u00020\u0001:\u0002\u0015\u0016B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001b\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0004H\u0002¢\u0006\u0004\b\u0007\u0010\bJ\u0015\u0010\n\u001a\u00020\u00052\u0006\u0010\t\u001a\u00020\u0005¢\u0006\u0004\b\n\u0010\u000bR\u001d\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\r0\f8\u0006¢\u0006\f\n\u0004\b\u000e\u0010\u000f\u001a\u0004\b\u0010\u0010\u0011R#\u0010\u0014\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u00048\u0006¢\u0006\f\n\u0004\b\u0010\u0010\u0013\u001a\u0004\b\u000e\u0010\b¨\u0006\u0017"}, d2 = {"Lokhttp3/internal/http2/Hpack;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "Lokio/ByteString;", StringUtils.EMPTY, "d", "()Ljava/util/Map;", "name", "a", "(Lokio/ByteString;)Lokio/ByteString;", StringUtils.EMPTY, "Lokhttp3/internal/http2/Header;", "b", "[Lokhttp3/internal/http2/Header;", "c", "()[Lokhttp3/internal/http2/Header;", "STATIC_HEADER_TABLE", "Ljava/util/Map;", "NAME_TO_FIRST_INDEX", "Reader", "Writer", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nHpack.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Hpack.kt\nokhttp3/internal/http2/Hpack\n+ 2 -UtilJvm.kt\nokhttp3/internal/_UtilJvmKt\n*L\n1#1,647:1\n256#2:648\n*S KotlinDebug\n*F\n+ 1 Hpack.kt\nokhttp3/internal/http2/Hpack\n*L\n398#1:648\n*E\n"})
public final class Hpack {
    public static final Hpack a;
    private static final Header[] b;
    private static final Map c;

    static {
        Hpack hpack = new Hpack();
        a = hpack;
        ByteString byteString = Header.j;
        String strA = ap.a(780536407);
        Header header = new Header(byteString, strA);
        ByteString byteString2 = Header.g;
        Header header2 = new Header(byteString2, ap.a(1752832584));
        Header header3 = new Header(byteString2, ap.a(2042686015));
        ByteString byteString3 = Header.h;
        Header header4 = new Header(byteString3, ap.a(310073506));
        Header header5 = new Header(byteString3, ap.a(1251481725));
        ByteString byteString4 = Header.i;
        Header header6 = new Header(byteString4, ap.a(41079793));
        Header header7 = new Header(byteString4, ap.a(332971093));
        ByteString byteString5 = Header.f;
        b = new Header[]{header, header2, header3, header4, header5, header6, header7, new Header(byteString5, ap.a(999279269)), new Header(byteString5, ap.a(2075433508)), new Header(byteString5, ap.a(411442876)), new Header(byteString5, ap.a(737186480)), new Header(byteString5, ap.a(1793756861)), new Header(byteString5, ap.a(243752564)), new Header(byteString5, ap.a(1383057080)), new Header(ap.a(2018946455), strA), new Header(ap.a(360245808), ap.a(1302832884)), new Header(ap.a(956592286), strA), new Header(ap.a(1374924568), strA), new Header(ap.a(1723973715), strA), new Header(ap.a(33875108), strA), new Header(ap.a(1291207548), strA), new Header(ap.a(1755493992), strA), new Header(ap.a(150460072), strA), new Header(ap.a(808451235), strA), new Header(ap.a(2123145980), strA), new Header(ap.a(168409148), strA), new Header(ap.a(176238032), strA), new Header(ap.a(437086303), strA), new Header(ap.a(1259616051), strA), new Header(ap.a(996219862), strA), new Header(ap.a(584081846), strA), new Header(ap.a(816768628), strA), new Header(ap.a(907484780), strA), new Header(ap.a(13570101), strA), new Header(ap.a(1316949926), strA), new Header(ap.a(1562309635), strA), new Header(ap.a(1042446824), strA), new Header(ap.a(1093698359), strA), new Header(ap.a(1569955782), strA), new Header(ap.a(1996358354), strA), new Header(ap.a(889334716), strA), new Header(ap.a(593180774), strA), new Header(ap.a(1391603378), strA), new Header(ap.a(1534851945), strA), new Header(ap.a(2068235424), strA), new Header(ap.a(662920476), strA), new Header(ap.a(297190637), strA), new Header(ap.a(1055835266), strA), new Header(ap.a(1492539195), strA), new Header(ap.a(1459787174), strA), new Header(ap.a(2049524423), strA), new Header(ap.a(1324877444), strA), new Header(ap.a(1578379775), strA), new Header(ap.a(1733785456), strA), new Header(ap.a(1921856074), strA), new Header(ap.a(1185988387), strA), new Header(ap.a(1057228566), strA), new Header(ap.a(89071742), strA), new Header(ap.a(1807099759), strA), new Header(ap.a(957737093), strA), new Header(ap.a(1829757744), strA)};
        c = hpack.d();
    }

    private Hpack() {
    }

    private final Map d() {
        Header[] headerArr = b;
        LinkedHashMap linkedHashMap = new LinkedHashMap(headerArr.length, 1.0f);
        int length = headerArr.length;
        for (int i = 0; i < length; i++) {
            Header[] headerArr2 = b;
            if (!linkedHashMap.containsKey(headerArr2[i].a)) {
                linkedHashMap.put(headerArr2[i].a, Integer.valueOf(i));
            }
        }
        Map mapUnmodifiableMap = Collections.unmodifiableMap(linkedHashMap);
        Intrinsics.checkNotNullExpressionValue(mapUnmodifiableMap, "unmodifiableMap(...)");
        return mapUnmodifiableMap;
    }

    public final ByteString a(ByteString byteString) throws IOException {
        Intrinsics.checkNotNullParameter(byteString, "name");
        int size = byteString.size();
        for (int i = 0; i < size; i++) {
            byte bG = byteString.g(i);
            if (65 <= bG && bG < 91) {
                throw new IOException("PROTOCOL_ERROR response malformed: mixed case name: " + byteString.M());
            }
        }
        return byteString;
    }

    public final Map b() {
        return c;
    }

    public final Header[] c() {
        return b;
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000T\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u000f\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\b\n\n\u0002\u0010!\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0006\u0018\u00002\u00020\u0001B#\b\u0007\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0004¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\n\u001a\u00020\tH\u0002¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\f\u001a\u00020\tH\u0002¢\u0006\u0004\b\f\u0010\u000bJ\u0017\u0010\u000e\u001a\u00020\u00042\u0006\u0010\r\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\u0017\u0010\u0011\u001a\u00020\t2\u0006\u0010\u0010\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0011\u0010\u0012J\u0017\u0010\u0013\u001a\u00020\u00042\u0006\u0010\u0010\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0013\u0010\u000fJ\u0017\u0010\u0014\u001a\u00020\t2\u0006\u0010\u0010\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0014\u0010\u0012J\u000f\u0010\u0015\u001a\u00020\tH\u0002¢\u0006\u0004\b\u0015\u0010\u000bJ\u0017\u0010\u0017\u001a\u00020\t2\u0006\u0010\u0016\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0017\u0010\u0012J\u000f\u0010\u0018\u001a\u00020\tH\u0002¢\u0006\u0004\b\u0018\u0010\u000bJ\u0017\u0010\u001a\u001a\u00020\u00192\u0006\u0010\u0010\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u001a\u0010\u001bJ\u0017\u0010\u001d\u001a\u00020\u001c2\u0006\u0010\u0010\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u001d\u0010\u001eJ\u001f\u0010!\u001a\u00020\t2\u0006\u0010\u0010\u001a\u00020\u00042\u0006\u0010 \u001a\u00020\u001fH\u0002¢\u0006\u0004\b!\u0010\"J\u000f\u0010#\u001a\u00020\u0004H\u0002¢\u0006\u0004\b#\u0010$J\u0013\u0010&\u001a\b\u0012\u0004\u0012\u00020\u001f0%¢\u0006\u0004\b&\u0010'J\r\u0010(\u001a\u00020\t¢\u0006\u0004\b(\u0010\u000bJ\u001d\u0010+\u001a\u00020\u00042\u0006\u0010)\u001a\u00020\u00042\u0006\u0010*\u001a\u00020\u0004¢\u0006\u0004\b+\u0010,J\r\u0010-\u001a\u00020\u0019¢\u0006\u0004\b-\u0010.R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\n\u0010/R\u0016\u0010\u0006\u001a\u00020\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\f\u0010/R\u001a\u00102\u001a\b\u0012\u0004\u0012\u00020\u001f008\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0013\u00101R\u0014\u0010\u0003\u001a\u0002038\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000e\u00104R\u001e\u00107\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u001f058\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b&\u00106R\u0016\u00108\u001a\u00020\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001a\u0010/R\u0016\u00109\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b!\u0010/R\u0016\u0010:\u001a\u00020\u00048\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b\u001d\u0010/¨\u0006;"}, d2 = {"Lokhttp3/internal/http2/Hpack$Reader;", StringUtils.EMPTY, "Lokio/Source;", ClimateForcast.SOURCE, StringUtils.EMPTY, "headerTableSizeSetting", "maxDynamicTableByteCount", "<init>", "(Lokio/Source;II)V", StringUtils.EMPTY, "a", "()V", "b", "bytesToRecover", "d", "(I)I", "index", "l", "(I)V", "c", "p", "q", "nameIndex", "n", "o", "Lokio/ByteString;", "f", "(I)Lokio/ByteString;", StringUtils.EMPTY, "h", "(I)Z", "Lokhttp3/internal/http2/Header;", "entry", "g", "(ILokhttp3/internal/http2/Header;)V", "i", "()I", StringUtils.EMPTY, "e", "()Ljava/util/List;", "k", "firstByte", "prefixMask", "m", "(II)I", "j", "()Lokio/ByteString;", "I", StringUtils.EMPTY, "Ljava/util/List;", "headerList", "Lokio/BufferedSource;", "Lokio/BufferedSource;", StringUtils.EMPTY, "[Lokhttp3/internal/http2/Header;", "dynamicTable", "nextHeaderIndex", "headerCount", "dynamicTableByteCount", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Reader {
        private final int a;
        private int b;
        private final List c;
        private final BufferedSource d;
        public Header[] e;
        private int f;
        public int g;
        public int h;

        public Reader(Source source, int i, int i2) {
            Intrinsics.checkNotNullParameter(source, ap.a(1861980903));
            this.a = i;
            this.b = i2;
            this.c = new ArrayList();
            this.d = Okio.c(source);
            this.e = new Header[8];
            this.f = r2.length - 1;
        }

        private final void a() {
            int i = this.b;
            int i2 = this.h;
            if (i < i2) {
                if (i == 0) {
                    b();
                } else {
                    d(i2 - i);
                }
            }
        }

        private final void b() {
            ArraysKt.fill$default(this.e, (Object) null, 0, 0, 6, (Object) null);
            this.f = this.e.length - 1;
            this.g = 0;
            this.h = 0;
        }

        private final int c(int i) {
            return this.f + 1 + i;
        }

        private final int d(int i) {
            int i2;
            int i3 = 0;
            if (i > 0) {
                int length = this.e.length;
                while (true) {
                    length--;
                    i2 = this.f;
                    if (length < i2 || i <= 0) {
                        break;
                    }
                    Header header = this.e[length];
                    Intrinsics.checkNotNull(header);
                    int i4 = header.c;
                    i -= i4;
                    this.h -= i4;
                    this.g--;
                    i3++;
                }
                Header[] headerArr = this.e;
                System.arraycopy(headerArr, i2 + 1, headerArr, i2 + 1 + i3, this.g);
                this.f += i3;
            }
            return i3;
        }

        private final ByteString f(int i) throws IOException {
            if (h(i)) {
                return Hpack.a.c()[i].a;
            }
            int iC = c(i - Hpack.a.c().length);
            if (iC >= 0) {
                Header[] headerArr = this.e;
                if (iC < headerArr.length) {
                    Header header = headerArr[iC];
                    Intrinsics.checkNotNull(header);
                    return header.a;
                }
            }
            throw new IOException("Header index too large " + (i + 1));
        }

        private final void g(int i, Header header) {
            this.c.add(header);
            int i2 = header.c;
            if (i != -1) {
                Header header2 = this.e[c(i)];
                Intrinsics.checkNotNull(header2);
                i2 -= header2.c;
            }
            int i3 = this.b;
            if (i2 > i3) {
                b();
                return;
            }
            int iD = d((this.h + i2) - i3);
            if (i == -1) {
                int i4 = this.g + 1;
                Header[] headerArr = this.e;
                if (i4 > headerArr.length) {
                    Header[] headerArr2 = new Header[headerArr.length * 2];
                    System.arraycopy(headerArr, 0, headerArr2, headerArr.length, headerArr.length);
                    this.f = this.e.length - 1;
                    this.e = headerArr2;
                }
                int i5 = this.f;
                this.f = i5 - 1;
                this.e[i5] = header;
                this.g++;
            } else {
                this.e[i + c(i) + iD] = header;
            }
            this.h += i2;
        }

        private final boolean h(int i) {
            return i >= 0 && i <= Hpack.a.c().length - 1;
        }

        private final int i() {
            return _UtilCommonKt.b(this.d.readByte(), 255);
        }

        private final void l(int i) throws IOException {
            if (h(i)) {
                this.c.add(Hpack.a.c()[i]);
                return;
            }
            int iC = c(i - Hpack.a.c().length);
            if (iC >= 0) {
                Header[] headerArr = this.e;
                if (iC < headerArr.length) {
                    List list = this.c;
                    Header header = headerArr[iC];
                    Intrinsics.checkNotNull(header);
                    list.add(header);
                    return;
                }
            }
            throw new IOException("Header index too large " + (i + 1));
        }

        private final void n(int i) {
            g(-1, new Header(f(i), j()));
        }

        private final void o() {
            g(-1, new Header(Hpack.a.a(j()), j()));
        }

        private final void p(int i) throws IOException {
            this.c.add(new Header(f(i), j()));
        }

        private final void q() throws IOException {
            this.c.add(new Header(Hpack.a.a(j()), j()));
        }

        public final List e() {
            List list = CollectionsKt.toList(this.c);
            this.c.clear();
            return list;
        }

        public final ByteString j() {
            int i = i();
            boolean z = (i & 128) == 128;
            long jM = m(i, WorkQueueKt.MASK);
            if (!z) {
                return this.d.F0(jM);
            }
            Buffer buffer = new Buffer();
            Huffman.a.b(this.d, jM, buffer);
            return buffer.V();
        }

        public final void k() throws IOException {
            while (!this.d.H2()) {
                int iB = _UtilCommonKt.b(this.d.readByte(), 255);
                if (iB == 128) {
                    throw new IOException("index == 0");
                }
                if ((iB & 128) == 128) {
                    l(m(iB, WorkQueueKt.MASK) - 1);
                } else if (iB == 64) {
                    o();
                } else if ((iB & 64) == 64) {
                    n(m(iB, 63) - 1);
                } else if ((iB & 32) == 32) {
                    int iM = m(iB, 31);
                    this.b = iM;
                    if (iM < 0 || iM > this.a) {
                        throw new IOException("Invalid dynamic table size update " + this.b);
                    }
                    a();
                } else if (iB == 16 || iB == 0) {
                    q();
                } else {
                    p(m(iB, 15) - 1);
                }
            }
        }

        public final int m(int i, int i2) {
            int i3 = i & i2;
            if (i3 < i2) {
                return i3;
            }
            int i4 = 0;
            while (true) {
                int i5 = i();
                if ((i5 & 128) == 0) {
                    return i2 + (i5 << i4);
                }
                i2 += (i5 & WorkQueueKt.MASK) << i4;
                i4 += 7;
            }
        }

        public /* synthetic */ Reader(Source source, int i, int i2, int i3, DefaultConstructorMarker defaultConstructorMarker) {
            this(source, i, (i3 & 4) != 0 ? i : i2);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0010\u0011\n\u0002\b\b\u0018\u00002\u00020\u0001B%\b\u0007\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0002\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\u000b\u001a\u00020\nH\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u0017\u0010\u000e\u001a\u00020\u00022\u0006\u0010\r\u001a\u00020\u0002H\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\u0017\u0010\u0012\u001a\u00020\n2\u0006\u0010\u0011\u001a\u00020\u0010H\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0014\u001a\u00020\nH\u0002¢\u0006\u0004\b\u0014\u0010\fJ\u001b\u0010\u0017\u001a\u00020\n2\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00100\u0015¢\u0006\u0004\b\u0017\u0010\u0018J%\u0010\u001c\u001a\u00020\n2\u0006\u0010\u0019\u001a\u00020\u00022\u0006\u0010\u001a\u001a\u00020\u00022\u0006\u0010\u001b\u001a\u00020\u0002¢\u0006\u0004\b\u001c\u0010\u001dJ\u0015\u0010 \u001a\u00020\n2\u0006\u0010\u001f\u001a\u00020\u001e¢\u0006\u0004\b \u0010!J\u0015\u0010\"\u001a\u00020\n2\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\"\u0010#R\u0016\u0010\u0003\u001a\u00020\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b\u0014\u0010$R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000b\u0010%R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000e\u0010&R\u0016\u0010'\u001a\u00020\u00028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0012\u0010$R\u0016\u0010(\u001a\u00020\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\"\u0010%R\u0016\u0010)\u001a\u00020\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b \u0010$R\u001e\u0010,\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\u00100*8\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b\u0017\u0010+R\u0016\u0010-\u001a\u00020\u00028\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001c\u0010$R\u0016\u0010/\u001a\u00020\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b.\u0010$R\u0016\u00101\u001a\u00020\u00028\u0006@\u0006X\u0087\u000e¢\u0006\u0006\n\u0004\b0\u0010$¨\u00062"}, d2 = {"Lokhttp3/internal/http2/Hpack$Writer;", StringUtils.EMPTY, StringUtils.EMPTY, "headerTableSizeSetting", StringUtils.EMPTY, "useCompression", "Lokio/Buffer;", "out", "<init>", "(IZLokio/Buffer;)V", StringUtils.EMPTY, "b", "()V", "bytesToRecover", "c", "(I)I", "Lokhttp3/internal/http2/Header;", "entry", "d", "(Lokhttp3/internal/http2/Header;)V", "a", StringUtils.EMPTY, "headerBlock", "g", "(Ljava/util/List;)V", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "prefixMask", "bits", "h", "(III)V", "Lokio/ByteString;", "data", "f", "(Lokio/ByteString;)V", "e", "(I)V", "I", "Z", "Lokio/Buffer;", "smallestHeaderTableSizeSetting", "emitDynamicTableSizeUpdate", "maxDynamicTableByteCount", StringUtils.EMPTY, "[Lokhttp3/internal/http2/Header;", "dynamicTable", "nextHeaderIndex", "i", "headerCount", "j", "dynamicTableByteCount", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Writer {
        public int a;
        private final boolean b;
        private final Buffer c;
        private int d;
        private boolean e;
        public int f;
        public Header[] g;
        private int h;
        public int i;
        public int j;

        public Writer(int i, boolean z, Buffer buffer) {
            Intrinsics.checkNotNullParameter(buffer, ap.a(371518391));
            this.a = i;
            this.b = z;
            this.c = buffer;
            this.d = Integer.MAX_VALUE;
            this.f = i;
            this.g = new Header[8];
            this.h = r2.length - 1;
        }

        private final void a() {
            int i = this.f;
            int i2 = this.j;
            if (i < i2) {
                if (i == 0) {
                    b();
                } else {
                    c(i2 - i);
                }
            }
        }

        private final void b() {
            ArraysKt.fill$default(this.g, (Object) null, 0, 0, 6, (Object) null);
            this.h = this.g.length - 1;
            this.i = 0;
            this.j = 0;
        }

        private final int c(int i) {
            int i2;
            int i3 = 0;
            if (i > 0) {
                int length = this.g.length;
                while (true) {
                    length--;
                    i2 = this.h;
                    if (length < i2 || i <= 0) {
                        break;
                    }
                    Header header = this.g[length];
                    Intrinsics.checkNotNull(header);
                    i -= header.c;
                    int i4 = this.j;
                    Header header2 = this.g[length];
                    Intrinsics.checkNotNull(header2);
                    this.j = i4 - header2.c;
                    this.i--;
                    i3++;
                }
                Header[] headerArr = this.g;
                System.arraycopy(headerArr, i2 + 1, headerArr, i2 + 1 + i3, this.i);
                Header[] headerArr2 = this.g;
                int i5 = this.h;
                Arrays.fill(headerArr2, i5 + 1, i5 + 1 + i3, (Object) null);
                this.h += i3;
            }
            return i3;
        }

        private final void d(Header header) {
            int i = header.c;
            int i2 = this.f;
            if (i > i2) {
                b();
                return;
            }
            c((this.j + i) - i2);
            int i3 = this.i + 1;
            Header[] headerArr = this.g;
            if (i3 > headerArr.length) {
                Header[] headerArr2 = new Header[headerArr.length * 2];
                System.arraycopy(headerArr, 0, headerArr2, headerArr.length, headerArr.length);
                this.h = this.g.length - 1;
                this.g = headerArr2;
            }
            int i4 = this.h;
            this.h = i4 - 1;
            this.g[i4] = header;
            this.i++;
            this.j += i;
        }

        public final void e(int i) {
            this.a = i;
            int iMin = Math.min(i, ReaderJsonLexerKt.BATCH_SIZE);
            int i2 = this.f;
            if (i2 == iMin) {
                return;
            }
            if (iMin < i2) {
                this.d = Math.min(this.d, iMin);
            }
            this.e = true;
            this.f = iMin;
            a();
        }

        public final void f(ByteString byteString) {
            Intrinsics.checkNotNullParameter(byteString, "data");
            if (this.b) {
                Huffman huffman = Huffman.a;
                if (huffman.d(byteString) < byteString.size()) {
                    Buffer buffer = new Buffer();
                    huffman.c(byteString, buffer);
                    ByteString byteStringV = buffer.V();
                    h(byteStringV.size(), WorkQueueKt.MASK, 128);
                    this.c.l1(byteStringV);
                    return;
                }
            }
            h(byteString.size(), WorkQueueKt.MASK, 0);
            this.c.l1(byteString);
        }

        /* JADX WARN: Removed duplicated region for block: B:22:0x0077  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final void g(java.util.List r13) {
            /*
                Method dump skipped, instruction units count: 264
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: okhttp3.internal.http2.Hpack.Writer.g(java.util.List):void");
        }

        public final void h(int i, int i2, int i3) {
            if (i < i2) {
                this.c.writeByte(i | i3);
                return;
            }
            this.c.writeByte(i3 | i2);
            int i4 = i - i2;
            while (i4 >= 128) {
                this.c.writeByte(128 | (i4 & WorkQueueKt.MASK));
                i4 >>>= 7;
            }
            this.c.writeByte(i4);
        }

        public /* synthetic */ Writer(int i, boolean z, Buffer buffer, int i2, DefaultConstructorMarker defaultConstructorMarker) {
            this((i2 & 1) != 0 ? 4096 : i, (i2 & 2) != 0 ? true : z, buffer);
        }
    }
}