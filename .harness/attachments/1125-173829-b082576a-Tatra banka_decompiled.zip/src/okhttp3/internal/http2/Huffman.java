package okhttp3.internal.http2;

import h.ap;
import kotlin.Metadata;
import kotlin.collections.ArraysKt;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.internal._UtilCommonKt;
import okio.BufferedSink;
import okio.BufferedSource;
import okio.ByteString;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0015\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001:\u0001\"B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J'\u0010\t\u001a\u00020\b2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\t\u0010\nJ\u001d\u0010\u000f\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u000f\u0010\u0010J\u0015\u0010\u0012\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u000b¢\u0006\u0004\b\u0012\u0010\u0013J%\u0010\u0017\u001a\u00020\b2\u0006\u0010\f\u001a\u00020\u00142\u0006\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u0017\u0010\u0018R\u0014\u0010\u001b\u001a\u00020\u00198\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0017\u0010\u001aR\u0014\u0010\u001e\u001a\u00020\u001c8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\u001dR\u0014\u0010!\u001a\u00020\u001f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u0010 ¨\u0006#"}, d2 = {"Lokhttp3/internal/http2/Huffman;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "symbol", "code", "codeBitCount", StringUtils.EMPTY, "a", "(III)V", "Lokio/ByteString;", ClimateForcast.SOURCE, "Lokio/BufferedSink;", "sink", "c", "(Lokio/ByteString;Lokio/BufferedSink;)V", "bytes", "d", "(Lokio/ByteString;)I", "Lokio/BufferedSource;", StringUtils.EMPTY, "byteCount", "b", "(Lokio/BufferedSource;JLokio/BufferedSink;)V", StringUtils.EMPTY, "[I", "CODES", StringUtils.EMPTY, "[B", "CODE_BIT_COUNTS", "Lokhttp3/internal/http2/Huffman$Node;", "Lokhttp3/internal/http2/Huffman$Node;", "root", "Node", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Huffman {
    private static final byte[] c;
    public static final Huffman a = new Huffman();
    private static final int[] b = {8184, 8388568, 268435426, 268435427, 268435428, 268435429, 268435430, 268435431, 268435432, 16777194, 1073741820, 268435433, 268435434, 1073741821, 268435435, 268435436, 268435437, 268435438, 268435439, 268435440, 268435441, 268435442, 1073741822, 268435443, 268435444, 268435445, 268435446, 268435447, 268435448, 268435449, 268435450, 268435451, 20, 1016, 1017, 4090, 8185, 21, 248, 2042, 1018, 1019, 249, 2043, 250, 22, 23, 24, 0, 1, 2, 25, 26, 27, 28, 29, 30, 31, 92, 251, 32764, 32, 4091, 1020, 8186, 33, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 252, 115, 253, 8187, 524272, 8188, 16380, 34, 32765, 3, 35, 4, 36, 5, 37, 38, 39, 6, 116, 117, 40, 41, 42, 7, 43, 118, 44, 8, 9, 45, 119, 120, 121, 122, 123, 32766, 2044, 16381, 8189, 268435452, 1048550, 4194258, 1048551, 1048552, 4194259, 4194260, 4194261, 8388569, 4194262, 8388570, 8388571, 8388572, 8388573, 8388574, 16777195, 8388575, 16777196, 16777197, 4194263, 8388576, 16777198, 8388577, 8388578, 8388579, 8388580, 2097116, 4194264, 8388581, 4194265, 8388582, 8388583, 16777199, 4194266, 2097117, 1048553, 4194267, 4194268, 8388584, 8388585, 2097118, 8388586, 4194269, 4194270, 16777200, 2097119, 4194271, 8388587, 8388588, 2097120, 2097121, 4194272, 2097122, 8388589, 4194273, 8388590, 8388591, 1048554, 4194274, 4194275, 4194276, 8388592, 4194277, 4194278, 8388593, 67108832, 67108833, 1048555, 524273, 4194279, 8388594, 4194280, 33554412, 67108834, 67108835, 67108836, 134217694, 134217695, 67108837, 16777201, 33554413, 524274, 2097123, 67108838, 134217696, 134217697, 67108839, 134217698, 16777202, 2097124, 2097125, 67108840, 67108841, 268435453, 134217699, 134217700, 134217701, 1048556, 16777203, 1048557, 2097126, 4194281, 2097127, 2097128, 8388595, 4194282, 4194283, 33554414, 33554415, 16777204, 16777205, 67108842, 8388596, 67108843, 134217702, 67108844, 67108845, 134217703, 134217704, 134217705, 134217706, 134217707, 268435454, 134217708, 134217709, 134217710, 134217711, 134217712, 67108846};
    private static final Node d = new Node();

    static {
        byte[] bArr = {13, 23, 28, 28, 28, 28, 28, 28, 28, 24, 30, 28, 28, 30, 28, 28, 28, 28, 28, 28, 28, 28, 30, 28, 28, 28, 28, 28, 28, 28, 28, 28, 6, 10, 10, 12, 13, 6, 8, 11, 10, 10, 8, 11, 8, 6, 6, 6, 5, 5, 5, 6, 6, 6, 6, 6, 6, 6, 7, 8, 15, 6, 12, 10, 13, 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8, 7, 8, 13, 19, 13, 14, 6, 15, 5, 6, 5, 6, 5, 6, 6, 6, 5, 7, 7, 6, 6, 6, 5, 6, 7, 6, 5, 5, 6, 7, 7, 7, 7, 7, 15, 11, 14, 13, 28, 20, 22, 20, 20, 22, 22, 22, 23, 22, 23, 23, 23, 23, 23, 24, 23, 24, 24, 22, 23, 24, 23, 23, 23, 23, 21, 22, 23, 22, 23, 23, 24, 22, 21, 20, 22, 22, 23, 23, 21, 23, 22, 22, 24, 21, 22, 23, 23, 21, 21, 22, 21, 23, 22, 23, 23, 20, 22, 22, 22, 23, 22, 22, 23, 26, 26, 20, 19, 22, 23, 22, 25, 26, 26, 26, 27, 27, 26, 24, 25, 19, 21, 26, 27, 27, 26, 27, 24, 21, 21, 26, 26, 28, 27, 27, 27, 20, 24, 20, 21, 22, 21, 21, 23, 22, 22, 25, 25, 24, 24, 26, 23, 26, 27, 26, 26, 27, 27, 27, 27, 27, 28, 27, 27, 27, 27, 27, 26};
        c = bArr;
        int length = bArr.length;
        for (int i = 0; i < length; i++) {
            a.a(i, b[i], c[i]);
        }
    }

    private Huffman() {
    }

    private final void a(int i, int i2, int i3) {
        Node node = new Node(i, i3);
        Node node2 = d;
        while (i3 > 8) {
            i3 -= 8;
            int i4 = (i2 >>> i3) & 255;
            Node[] nodeArrA = node2.a();
            Intrinsics.checkNotNull(nodeArrA);
            Node node3 = nodeArrA[i4];
            if (node3 == null) {
                node3 = new Node();
                nodeArrA[i4] = node3;
            }
            node2 = node3;
        }
        int i5 = 8 - i3;
        int i6 = (i2 << i5) & 255;
        Node[] nodeArrA2 = node2.a();
        Intrinsics.checkNotNull(nodeArrA2);
        ArraysKt.fill(nodeArrA2, node, i6, (1 << i5) + i6);
    }

    public final void b(BufferedSource bufferedSource, long j, BufferedSink bufferedSink) {
        Intrinsics.checkNotNullParameter(bufferedSource, ap.a(1240351215));
        Intrinsics.checkNotNullParameter(bufferedSink, ap.a(1951257753));
        Node node = d;
        int iB = 0;
        int iC = 0;
        for (long j2 = 0; j2 < j; j2++) {
            iB = (iB << 8) | _UtilCommonKt.b(bufferedSource.readByte(), 255);
            iC += 8;
            while (iC >= 8) {
                Node[] nodeArrA = node.a();
                Intrinsics.checkNotNull(nodeArrA);
                node = nodeArrA[(iB >>> (iC - 8)) & 255];
                Intrinsics.checkNotNull(node);
                if (node.a() == null) {
                    bufferedSink.writeByte(node.b());
                    iC -= node.c();
                    node = d;
                } else {
                    iC -= 8;
                }
            }
        }
        while (iC > 0) {
            Node[] nodeArrA2 = node.a();
            Intrinsics.checkNotNull(nodeArrA2);
            Node node2 = nodeArrA2[(iB << (8 - iC)) & 255];
            Intrinsics.checkNotNull(node2);
            if (node2.a() != null || node2.c() > iC) {
                return;
            }
            bufferedSink.writeByte(node2.b());
            iC -= node2.c();
            node = d;
        }
    }

    public final void c(ByteString byteString, BufferedSink bufferedSink) {
        Intrinsics.checkNotNullParameter(byteString, ClimateForcast.SOURCE);
        Intrinsics.checkNotNullParameter(bufferedSink, "sink");
        int size = byteString.size();
        long j = 0;
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            int iB = _UtilCommonKt.b(byteString.g(i2), 255);
            int i3 = b[iB];
            byte b2 = c[iB];
            j = (j << b2) | ((long) i3);
            i += b2;
            while (i >= 8) {
                i -= 8;
                bufferedSink.writeByte((int) (j >> i));
            }
        }
        if (i > 0) {
            bufferedSink.writeByte((int) ((j << (8 - i)) | (255 >>> i)));
        }
    }

    public final int d(ByteString byteString) {
        Intrinsics.checkNotNullParameter(byteString, "bytes");
        int size = byteString.size();
        long j = 0;
        for (int i = 0; i < size; i++) {
            j += (long) c[_UtilCommonKt.b(byteString.g(i), 255)];
        }
        return (int) ((j + ((long) 7)) >> 3);
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\b\n\b\u0002\u0018\u00002\u00020\u0001B\t\b\u0016¢\u0006\u0004\b\u0002\u0010\u0003B\u0019\b\u0016\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0006\u001a\u00020\u0004¢\u0006\u0004\b\u0002\u0010\u0007R!\u0010\f\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0000\u0018\u00010\b8\u0006¢\u0006\f\n\u0004\b\t\u0010\n\u001a\u0004\b\t\u0010\u000bR\u0017\u0010\u0005\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\r\u0010\u000e\u001a\u0004\b\r\u0010\u000fR\u0017\u0010\u0011\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\u0010\u0010\u000e\u001a\u0004\b\u0010\u0010\u000f¨\u0006\u0012"}, d2 = {"Lokhttp3/internal/http2/Huffman$Node;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "symbol", "bits", "(II)V", StringUtils.EMPTY, "a", "[Lokhttp3/internal/http2/Huffman$Node;", "()[Lokhttp3/internal/http2/Huffman$Node;", "children", "b", "I", "()I", "c", "terminalBitCount", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    private static final class Node {
        private final Node[] a;
        private final int b;
        private final int c;

        public Node() {
            this.a = new Node[256];
            this.b = 0;
            this.c = 0;
        }

        public final Node[] a() {
            return this.a;
        }

        public final int b() {
            return this.b;
        }

        public final int c() {
            return this.c;
        }

        public Node(int i, int i2) {
            this.a = null;
            this.b = i;
            int i3 = i2 & 7;
            this.c = i3 == 0 ? 8 : i3;
        }
    }
}