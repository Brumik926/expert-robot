package okhttp3.internal.http2;

import h.ap;
import java.io.IOException;
import java.net.ProtocolException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.Headers;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.http.ExchangeCodec;
import okhttp3.internal.http.HttpHeaders;
import okhttp3.internal.http.RealInterceptorChain;
import okhttp3.internal.http.RequestLine;
import okhttp3.internal.http.StatusLine;
import okio.Sink;
import okio.Source;
import okio.Timeout;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000l\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\u0018\u0000 32\u00020\u0001:\u00016B'\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b¢\u0006\u0004\b\n\u0010\u000bJ\u001f\u0010\u0011\u001a\u00020\u00102\u0006\u0010\r\u001a\u00020\f2\u0006\u0010\u000f\u001a\u00020\u000eH\u0016¢\u0006\u0004\b\u0011\u0010\u0012J\u0017\u0010\u0014\u001a\u00020\u00132\u0006\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\u0014\u0010\u0015J\u000f\u0010\u0016\u001a\u00020\u0013H\u0016¢\u0006\u0004\b\u0016\u0010\u0017J\u000f\u0010\u0018\u001a\u00020\u0013H\u0016¢\u0006\u0004\b\u0018\u0010\u0017J\u0019\u0010\u001c\u001a\u0004\u0018\u00010\u001b2\u0006\u0010\u001a\u001a\u00020\u0019H\u0016¢\u0006\u0004\b\u001c\u0010\u001dJ\u0017\u0010 \u001a\u00020\u000e2\u0006\u0010\u001f\u001a\u00020\u001eH\u0016¢\u0006\u0004\b \u0010!J\u0017\u0010#\u001a\u00020\"2\u0006\u0010\u001f\u001a\u00020\u001eH\u0016¢\u0006\u0004\b#\u0010$J\u000f\u0010%\u001a\u00020\u0013H\u0016¢\u0006\u0004\b%\u0010\u0017R\u001a\u0010\u0005\u001a\u00020\u00048\u0016X\u0096\u0004¢\u0006\f\n\u0004\b#\u0010&\u001a\u0004\b'\u0010(R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0011\u0010)R\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0016\u0010*R\u0018\u0010-\u001a\u0004\u0018\u00010+8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0018\u0010,R\u0014\u00100\u001a\u00020.8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b \u0010/R\u0016\u00102\u001a\u00020\u00198\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0014\u00101R\u0014\u00105\u001a\u00020\u00198VX\u0096\u0004¢\u0006\u0006\u001a\u0004\b3\u00104¨\u00067"}, d2 = {"Lokhttp3/internal/http2/Http2ExchangeCodec;", "Lokhttp3/internal/http/ExchangeCodec;", "Lokhttp3/OkHttpClient;", "client", "Lokhttp3/internal/http/ExchangeCodec$Carrier;", "carrier", "Lokhttp3/internal/http/RealInterceptorChain;", "chain", "Lokhttp3/internal/http2/Http2Connection;", "http2Connection", "<init>", "(Lokhttp3/OkHttpClient;Lokhttp3/internal/http/ExchangeCodec$Carrier;Lokhttp3/internal/http/RealInterceptorChain;Lokhttp3/internal/http2/Http2Connection;)V", "Lokhttp3/Request;", "request", StringUtils.EMPTY, "contentLength", "Lokio/Sink;", "b", "(Lokhttp3/Request;J)Lokio/Sink;", StringUtils.EMPTY, "f", "(Lokhttp3/Request;)V", "c", "()V", "d", StringUtils.EMPTY, "expectContinue", "Lokhttp3/Response$Builder;", "h", "(Z)Lokhttp3/Response$Builder;", "Lokhttp3/Response;", "response", "e", "(Lokhttp3/Response;)J", "Lokio/Source;", "a", "(Lokhttp3/Response;)Lokio/Source;", "cancel", "Lokhttp3/internal/http/ExchangeCodec$Carrier;", "i", "()Lokhttp3/internal/http/ExchangeCodec$Carrier;", "Lokhttp3/internal/http/RealInterceptorChain;", "Lokhttp3/internal/http2/Http2Connection;", "Lokhttp3/internal/http2/Http2Stream;", "Lokhttp3/internal/http2/Http2Stream;", "stream", "Lokhttp3/Protocol;", "Lokhttp3/Protocol;", "protocol", "Z", "canceled", "g", "()Z", "isResponseComplete", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Http2ExchangeCodec implements ExchangeCodec {
    public static final Companion g = new Companion(null);
    private static final List h = _UtilJvmKt.l(ap.a(1375530435), ap.a(1695353385), ap.a(1879904316), ap.a(1509557756), ap.a(32470403), ap.a(1309813129), ap.a(823093444), ap.a(1066517776), ap.a(608386359), ap.a(1350431928), ap.a(1579490068), ap.a(360176876));
    private static final List i = _UtilJvmKt.l(ap.a(71045918), ap.a(1961028271), ap.a(1054598789), ap.a(1724157175), ap.a(934588223), ap.a(142149972), ap.a(736121512), ap.a(462292623));
    private final ExchangeCodec.Carrier a;
    private final RealInterceptorChain b;
    private final Http2Connection c;
    private volatile Http2Stream d;
    private final Protocol e;
    private volatile boolean f;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\r\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001b\u0010\b\u001a\b\u0012\u0004\u0012\u00020\u00070\u00062\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\b\u0010\tJ\u001d\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\u000b\u001a\u00020\n2\u0006\u0010\r\u001a\u00020\f¢\u0006\u0004\b\u000f\u0010\u0010R\u0014\u0010\u0012\u001a\u00020\u00118\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0012\u0010\u0013R\u0014\u0010\u0014\u001a\u00020\u00118\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0014\u0010\u0013R\u0014\u0010\u0015\u001a\u00020\u00118\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0015\u0010\u0013R\u0014\u0010\u0016\u001a\u00020\u00118\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0016\u0010\u0013R\u0014\u0010\u0017\u001a\u00020\u00118\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0017\u0010\u0013R\u0014\u0010\u0018\u001a\u00020\u00118\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0018\u0010\u0013R\u0014\u0010\u0019\u001a\u00020\u00118\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0019\u0010\u0013R\u0014\u0010\u001a\u001a\u00020\u00118\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u001a\u0010\u0013R\u001a\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u00110\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001b\u0010\u001cR\u001a\u0010\u001d\u001a\b\u0012\u0004\u0012\u00020\u00110\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010\u001c¨\u0006\u001e"}, d2 = {"Lokhttp3/internal/http2/Http2ExchangeCodec$Companion;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/Request;", "request", StringUtils.EMPTY, "Lokhttp3/internal/http2/Header;", "a", "(Lokhttp3/Request;)Ljava/util/List;", "Lokhttp3/Headers;", "headerBlock", "Lokhttp3/Protocol;", "protocol", "Lokhttp3/Response$Builder;", "b", "(Lokhttp3/Headers;Lokhttp3/Protocol;)Lokhttp3/Response$Builder;", StringUtils.EMPTY, "CONNECTION", "Ljava/lang/String;", "HOST", "KEEP_ALIVE", "PROXY_CONNECTION", "TRANSFER_ENCODING", "TE", "ENCODING", "UPGRADE", "HTTP_2_SKIPPED_REQUEST_HEADERS", "Ljava/util/List;", "HTTP_2_SKIPPED_RESPONSE_HEADERS", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final List a(Request request) {
            Intrinsics.checkNotNullParameter(request, ap.a(2057249520));
            Headers headersG = request.g();
            ArrayList arrayList = new ArrayList(headersG.size() + 4);
            arrayList.add(new Header(Header.g, request.i()));
            arrayList.add(new Header(Header.h, RequestLine.a.c(request.m())));
            String strE = request.e(ap.a(2020438967));
            if (strE != null) {
                arrayList.add(new Header(Header.j, strE));
            }
            arrayList.add(new Header(Header.i, request.m().s()));
            int size = headersG.size();
            for (int i = 0; i < size; i++) {
                String strE2 = headersG.e(i);
                Locale locale = Locale.US;
                Intrinsics.checkNotNullExpressionValue(locale, ap.a(1320500133));
                String lowerCase = strE2.toLowerCase(locale);
                Intrinsics.checkNotNullExpressionValue(lowerCase, ap.a(1213373148));
                if (!Http2ExchangeCodec.h.contains(lowerCase) || (Intrinsics.areEqual(lowerCase, ap.a(403959678)) && Intrinsics.areEqual(headersG.k(i), ap.a(774483379)))) {
                    arrayList.add(new Header(lowerCase, headersG.k(i)));
                }
            }
            return arrayList;
        }

        public final Response.Builder b(Headers headers, Protocol protocol) throws ProtocolException {
            Intrinsics.checkNotNullParameter(headers, "headerBlock");
            Intrinsics.checkNotNullParameter(protocol, "protocol");
            Headers.Builder builder = new Headers.Builder();
            int size = headers.size();
            StatusLine statusLineA = null;
            for (int i = 0; i < size; i++) {
                String strE = headers.e(i);
                String strK = headers.k(i);
                if (Intrinsics.areEqual(strE, ":status")) {
                    statusLineA = StatusLine.d.a("HTTP/1.1 " + strK);
                } else if (!Http2ExchangeCodec.i.contains(strE)) {
                    builder.c(strE, strK);
                }
            }
            if (statusLineA != null) {
                return new Response.Builder().o(protocol).f(statusLineA.b).l(statusLineA.c).j(builder.e());
            }
            throw new ProtocolException("Expected ':status' header not present");
        }

        private Companion() {
        }
    }

    public Http2ExchangeCodec(OkHttpClient okHttpClient, ExchangeCodec.Carrier carrier, RealInterceptorChain realInterceptorChain, Http2Connection http2Connection) {
        Intrinsics.checkNotNullParameter(okHttpClient, "client");
        Intrinsics.checkNotNullParameter(carrier, "carrier");
        Intrinsics.checkNotNullParameter(realInterceptorChain, "chain");
        Intrinsics.checkNotNullParameter(http2Connection, "http2Connection");
        this.a = carrier;
        this.b = realInterceptorChain;
        this.c = http2Connection;
        List listD = okHttpClient.D();
        Protocol protocol = Protocol.g;
        this.e = listD.contains(protocol) ? protocol : Protocol.f;
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public Source a(Response response) {
        Intrinsics.checkNotNullParameter(response, "response");
        Http2Stream http2Stream = this.d;
        Intrinsics.checkNotNull(http2Stream);
        return http2Stream.p();
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public Sink b(Request request, long j) {
        Intrinsics.checkNotNullParameter(request, "request");
        Http2Stream http2Stream = this.d;
        Intrinsics.checkNotNull(http2Stream);
        return http2Stream.o();
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public void c() {
        this.c.flush();
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public void cancel() {
        this.f = true;
        Http2Stream http2Stream = this.d;
        if (http2Stream != null) {
            http2Stream.g(ErrorCode.k);
        }
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public void d() {
        Http2Stream http2Stream = this.d;
        Intrinsics.checkNotNull(http2Stream);
        http2Stream.o().close();
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public long e(Response response) {
        Intrinsics.checkNotNullParameter(response, "response");
        if (HttpHeaders.b(response)) {
            return _UtilJvmKt.k(response);
        }
        return 0L;
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public void f(Request request) throws IOException {
        Intrinsics.checkNotNullParameter(request, "request");
        if (this.d != null) {
            return;
        }
        this.d = this.c.O0(g.a(request), request.a() != null);
        if (this.f) {
            Http2Stream http2Stream = this.d;
            Intrinsics.checkNotNull(http2Stream);
            http2Stream.g(ErrorCode.k);
            throw new IOException("Canceled");
        }
        Http2Stream http2Stream2 = this.d;
        Intrinsics.checkNotNull(http2Stream2);
        Timeout timeoutW = http2Stream2.w();
        long jH = this.b.h();
        TimeUnit timeUnit = TimeUnit.MILLISECONDS;
        timeoutW.h(jH, timeUnit);
        Http2Stream http2Stream3 = this.d;
        Intrinsics.checkNotNull(http2Stream3);
        http2Stream3.D().h(this.b.j(), timeUnit);
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public boolean g() {
        Http2Stream http2Stream = this.d;
        return http2Stream != null && http2Stream.v();
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public Response.Builder h(boolean z) throws IOException {
        Http2Stream http2Stream = this.d;
        if (http2Stream == null) {
            throw new IOException("stream wasn't created");
        }
        Response.Builder builderB = g.b(http2Stream.B(z), this.e);
        if (z && builderB.g() == 100) {
            return null;
        }
        return builderB;
    }

    @Override // okhttp3.internal.http.ExchangeCodec
    public ExchangeCodec.Carrier i() {
        return this.a;
    }
}