package okhttp3.internal.cache2;

import h.ap;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal.concurrent.Lockable;
import okio.Buffer;
import okio.ByteString;
import okio.Source;
import okio.Timeout;
import org.apache.tika.parser.external.ExternalParsersConfigReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0011\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\b\u0018\u0000 \u00112\u00020\u0001:\u0002@AJ'\u0010\b\u001a\u00020\u00072\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\b\u0010\tJ\u0017\u0010\n\u001a\u00020\u00072\u0006\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\n\u0010\u000bJ\u0015\u0010\f\u001a\u00020\u00072\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\f\u0010\u000bR$\u0010\u0013\u001a\u0004\u0018\u00010\r8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\f\u0010\u000e\u001a\u0004\b\u000f\u0010\u0010\"\u0004\b\u0011\u0010\u0012R$\u0010\u001b\u001a\u0004\u0018\u00010\u00148\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0015\u0010\u0016\u001a\u0004\b\u0017\u0010\u0018\"\u0004\b\u0019\u0010\u001aR\"\u0010!\u001a\u00020\u00048\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001e\u0010\u001f\"\u0004\b \u0010\u000bR\u0014\u0010$\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\"\u0010#R\u0017\u0010%\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\u000f\u0010\u001d\u001a\u0004\b\u001c\u0010\u001fR$\u0010-\u001a\u0004\u0018\u00010&8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b'\u0010(\u001a\u0004\b)\u0010*\"\u0004\b+\u0010,R\u0017\u00102\u001a\u00020.8\u0006¢\u0006\f\n\u0004\b\u0017\u0010/\u001a\u0004\b0\u00101R\"\u00108\u001a\u0002038\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b0\u00104\u001a\u0004\b\"\u00105\"\u0004\b6\u00107R\u0017\u00109\u001a\u00020.8\u0006¢\u0006\f\n\u0004\b\u001e\u0010/\u001a\u0004\b\u0015\u00101R\"\u0010?\u001a\u00020:8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b)\u0010;\u001a\u0004\b'\u0010<\"\u0004\b=\u0010>¨\u0006B"}, d2 = {"Lokhttp3/internal/cache2/Relay;", "Lokhttp3/internal/concurrent/Lockable;", "Lokio/ByteString;", "prefix", StringUtils.EMPTY, "upstreamSize", "metadataSize", StringUtils.EMPTY, "o", "(Lokio/ByteString;JJ)V", "p", "(J)V", "a", "Ljava/io/RandomAccessFile;", "Ljava/io/RandomAccessFile;", "e", "()Ljava/io/RandomAccessFile;", "k", "(Ljava/io/RandomAccessFile;)V", "file", "Lokio/Source;", "b", "Lokio/Source;", "g", "()Lokio/Source;", "setUpstream", "(Lokio/Source;)V", "upstream", "c", "J", "i", "()J", "m", "upstreamPos", "d", "Lokio/ByteString;", ExternalParsersConfigReaderMetKeys.METADATA_TAG, "bufferMaxSize", "Ljava/lang/Thread;", "f", "Ljava/lang/Thread;", "j", "()Ljava/lang/Thread;", "n", "(Ljava/lang/Thread;)V", "upstreamReader", "Lokio/Buffer;", "Lokio/Buffer;", "h", "()Lokio/Buffer;", "upstreamBuffer", StringUtils.EMPTY, "Z", "()Z", "setComplete", "(Z)V", "complete", "buffer", StringUtils.EMPTY, "I", "()I", "l", "(I)V", "sourceCount", "RelaySource", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Relay implements Lockable {
    public static final Companion k = new Companion(null);
    public static final ByteString l;
    public static final ByteString m;
    private RandomAccessFile a;
    private Source b;
    private long c;
    private final ByteString d;
    private final long e;
    private Thread f;
    private final Buffer g;
    private boolean h;
    private final Buffer i;
    private int j;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0005\u0010\u0006R\u0014\u0010\u0007\u001a\u00020\u00048\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u0007\u0010\u0006R\u0014\u0010\t\u001a\u00020\b8\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\t\u0010\nR\u0014\u0010\u000b\u001a\u00020\b8\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u000b\u0010\nR\u0014\u0010\r\u001a\u00020\f8\u0002X\u0082T¢\u0006\u0006\n\u0004\b\r\u0010\u000e¨\u0006\u000f"}, d2 = {"Lokhttp3/internal/cache2/Relay$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "SOURCE_UPSTREAM", "I", "SOURCE_FILE", "Lokio/ByteString;", "PREFIX_CLEAN", "Lokio/ByteString;", "PREFIX_DIRTY", StringUtils.EMPTY, "FILE_HEADER_SIZE", "J", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000.\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0080\u0004\u0018\u00002\u00020\u0001J\u001f\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0006\u0010\u0007J\u000f\u0010\t\u001a\u00020\bH\u0016¢\u0006\u0004\b\t\u0010\nJ\u000f\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\f\u0010\rR\u0014\u0010\t\u001a\u00020\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000e\u0010\u000fR\u0018\u0010\u0013\u001a\u0004\u0018\u00010\u00108\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0011\u0010\u0012R\u0016\u0010\u0016\u001a\u00020\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0014\u0010\u0015¨\u0006\u0017"}, d2 = {"Lokhttp3/internal/cache2/Relay$RelaySource;", "Lokio/Source;", "Lokio/Buffer;", "sink", StringUtils.EMPTY, "byteCount", "k3", "(Lokio/Buffer;J)J", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", StringUtils.EMPTY, "close", "()V", "a", "Lokio/Timeout;", "Lokhttp3/internal/cache2/FileOperator;", "b", "Lokhttp3/internal/cache2/FileOperator;", "fileOperator", "c", "J", "sourcePos", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nRelay.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Relay.kt\nokhttp3/internal/cache2/Relay$RelaySource\n+ 2 Lockable.kt\nokhttp3/internal/concurrent/LockableKt\n*L\n1#1,362:1\n38#2:363\n*S KotlinDebug\n*F\n+ 1 Relay.kt\nokhttp3/internal/cache2/Relay$RelaySource\n*L\n272#1:363\n*E\n"})
    public final class RelaySource implements Source {
        private final Timeout a;
        private FileOperator b;
        private long c;
        final /* synthetic */ Relay d;

        @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (this.b == null) {
                return;
            }
            RandomAccessFile randomAccessFile = null;
            this.b = null;
            Relay relay = this.d;
            synchronized (relay) {
                try {
                    relay.l(relay.f() - 1);
                    if (relay.f() == 0) {
                        RandomAccessFile randomAccessFileE = relay.e();
                        relay.k(null);
                        randomAccessFile = randomAccessFileE;
                    }
                    Unit unit = Unit.INSTANCE;
                } catch (Throwable th) {
                    throw th;
                }
            }
            if (randomAccessFile != null) {
                _UtilCommonKt.f(randomAccessFile);
            }
        }

        @Override // okio.Source
        public long k3(Buffer buffer, long j) throws IOException {
            char c;
            Intrinsics.checkNotNullParameter(buffer, ap.a(640281227));
            if (this.b == null) {
                throw new IllegalStateException(ap.a(875402611));
            }
            Relay relay = this.d;
            synchronized (relay) {
                while (true) {
                    try {
                        if (this.c != relay.i()) {
                            long jI = relay.i() - relay.b().size();
                            if (this.c >= jI) {
                                long jMin = Math.min(j, relay.i() - this.c);
                                relay.b().r(buffer, this.c - jI, jMin);
                                this.c += jMin;
                                return jMin;
                            }
                            c = 2;
                        } else if (!relay.d()) {
                            if (relay.j() == null) {
                                relay.n(Thread.currentThread());
                                c = 1;
                                break;
                            }
                            this.a.j(relay);
                        } else {
                            return -1L;
                        }
                    } catch (Throwable th) {
                        throw th;
                    }
                }
                if (c == 2) {
                    long jMin2 = Math.min(j, this.d.i() - this.c);
                    FileOperator fileOperator = this.b;
                    Intrinsics.checkNotNull(fileOperator);
                    fileOperator.a(this.c + 32, buffer, jMin2);
                    this.c += jMin2;
                    return jMin2;
                }
                try {
                    Source sourceG = this.d.g();
                    Intrinsics.checkNotNull(sourceG);
                    long jK3 = sourceG.k3(this.d.h(), this.d.c());
                    if (jK3 == -1) {
                        Relay relay2 = this.d;
                        relay2.a(relay2.i());
                        Relay relay3 = this.d;
                        synchronized (relay3) {
                            relay3.n(null);
                            Intrinsics.checkNotNull(relay3, ap.a(886808228));
                            relay3.notifyAll();
                            Unit unit = Unit.INSTANCE;
                        }
                        return -1L;
                    }
                    long jMin3 = Math.min(jK3, j);
                    this.d.h().r(buffer, 0L, jMin3);
                    this.c += jMin3;
                    FileOperator fileOperator2 = this.b;
                    Intrinsics.checkNotNull(fileOperator2);
                    fileOperator2.b(this.d.i() + 32, this.d.h().clone(), jK3);
                    Relay relay4 = this.d;
                    synchronized (relay4) {
                        try {
                            relay4.b().a2(relay4.h(), jK3);
                            if (relay4.b().size() > relay4.c()) {
                                relay4.b().skip(relay4.b().size() - relay4.c());
                            }
                            relay4.m(relay4.i() + jK3);
                            Unit unit2 = Unit.INSTANCE;
                        } finally {
                        }
                    }
                    Relay relay5 = this.d;
                    synchronized (relay5) {
                        relay5.n(null);
                        Intrinsics.checkNotNull(relay5, ap.a(1206734877));
                        relay5.notifyAll();
                    }
                    return jMin3;
                } catch (Throwable th2) {
                    Relay relay6 = this.d;
                    synchronized (relay6) {
                        relay6.n(null);
                        Intrinsics.checkNotNull(relay6, ap.a(417527842));
                        relay6.notifyAll();
                        Unit unit3 = Unit.INSTANCE;
                        throw th2;
                    }
                }
            }
        }

        @Override // okio.Source
        public Timeout timeout() {
            return this.a;
        }
    }

    static {
        ByteString.Companion companion = ByteString.d;
        l = companion.d(ap.a(217761613));
        m = companion.d(ap.a(1055430150));
    }

    private final void o(ByteString byteString, long j, long j2) throws IOException {
        Buffer buffer = new Buffer();
        buffer.l1(byteString);
        buffer.J0(j);
        buffer.J0(j2);
        if (buffer.size() != 32) {
            throw new IllegalArgumentException("Failed requirement.");
        }
        RandomAccessFile randomAccessFile = this.a;
        Intrinsics.checkNotNull(randomAccessFile);
        FileChannel channel = randomAccessFile.getChannel();
        Intrinsics.checkNotNullExpressionValue(channel, "getChannel(...)");
        new FileOperator(channel).b(0L, buffer, 32L);
    }

    private final void p(long j) throws IOException {
        Buffer buffer = new Buffer();
        buffer.l1(this.d);
        RandomAccessFile randomAccessFile = this.a;
        Intrinsics.checkNotNull(randomAccessFile);
        FileChannel channel = randomAccessFile.getChannel();
        Intrinsics.checkNotNullExpressionValue(channel, "getChannel(...)");
        new FileOperator(channel).b(32 + j, buffer, this.d.size());
    }

    public final void a(long j) throws IOException {
        p(j);
        RandomAccessFile randomAccessFile = this.a;
        Intrinsics.checkNotNull(randomAccessFile);
        randomAccessFile.getChannel().force(false);
        o(l, j, this.d.size());
        RandomAccessFile randomAccessFile2 = this.a;
        Intrinsics.checkNotNull(randomAccessFile2);
        randomAccessFile2.getChannel().force(false);
        synchronized (this) {
            this.h = true;
            Unit unit = Unit.INSTANCE;
        }
        Source source = this.b;
        if (source != null) {
            _UtilCommonKt.f(source);
        }
        this.b = null;
    }

    public final Buffer b() {
        return this.i;
    }

    public final long c() {
        return this.e;
    }

    public final boolean d() {
        return this.h;
    }

    public final RandomAccessFile e() {
        return this.a;
    }

    public final int f() {
        return this.j;
    }

    public final Source g() {
        return this.b;
    }

    public final Buffer h() {
        return this.g;
    }

    public final long i() {
        return this.c;
    }

    public final Thread j() {
        return this.f;
    }

    public final void k(RandomAccessFile randomAccessFile) {
        this.a = randomAccessFile;
    }

    public final void l(int i) {
        this.j = i;
    }

    public final void m(long j) {
        this.c = j;
    }

    public final void n(Thread thread) {
        this.f = thread;
    }
}