package okhttp3.internal;

import h.ap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.ArraysKt;
import kotlin.collections.CollectionsKt;
import kotlin.internal.ProgressionUtilKt;
import kotlin.jvm.internal.ArrayIteratorKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.CharsKt;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.Headers;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010(\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u0011\n\u0002\b\u000e\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\f\n\u0002\b\u0005\n\u0002\u0010$\n\u0002\b\u0003\u001a\u001b\u0010\u0004\u001a\u00020\u0003*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\u0000¢\u0006\u0004\b\u0004\u0010\u0005\u001a\u001b\u0010\u0006\u001a\u00020\u0003*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\u0000¢\u0006\u0004\b\u0006\u0010\u0005\u001a!\u0010\t\u001a\b\u0012\u0004\u0012\u00020\u00030\b*\u00020\u00002\u0006\u0010\u0007\u001a\u00020\u0003H\u0000¢\u0006\u0004\b\t\u0010\n\u001a%\u0010\r\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\f0\u000b*\u00020\u0000H\u0000¢\u0006\u0004\b\r\u0010\u000e\u001a\u0013\u0010\u0010\u001a\u00020\u000f*\u00020\u0000H\u0000¢\u0006\u0004\b\u0010\u0010\u0011\u001a\u001d\u0010\u0015\u001a\u00020\u0014*\u00020\u00002\b\u0010\u0013\u001a\u0004\u0018\u00010\u0012H\u0000¢\u0006\u0004\b\u0015\u0010\u0016\u001a\u0013\u0010\u0017\u001a\u00020\u0001*\u00020\u0000H\u0000¢\u0006\u0004\b\u0017\u0010\u0018\u001a\u0013\u0010\u0019\u001a\u00020\u0003*\u00020\u0000H\u0000¢\u0006\u0004\b\u0019\u0010\u001a\u001a'\u0010\u001d\u001a\u0004\u0018\u00010\u00032\f\u0010\u001c\u001a\b\u0012\u0004\u0012\u00020\u00030\u001b2\u0006\u0010\u0007\u001a\u00020\u0003H\u0000¢\u0006\u0004\b\u001d\u0010\u001e\u001a#\u0010 \u001a\u00020\u000f*\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\u00032\u0006\u0010\u001f\u001a\u00020\u0003H\u0000¢\u0006\u0004\b \u0010!\u001a#\u0010\"\u001a\u00020\u000f*\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\u00032\u0006\u0010\u001f\u001a\u00020\u0003H\u0000¢\u0006\u0004\b\"\u0010!\u001a\u001b\u0010#\u001a\u00020\u000f*\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\u0003H\u0000¢\u0006\u0004\b#\u0010$\u001a#\u0010%\u001a\u00020\u000f*\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\u00032\u0006\u0010\u001f\u001a\u00020\u0003H\u0000¢\u0006\u0004\b%\u0010!\u001a\u001d\u0010&\u001a\u0004\u0018\u00010\u0003*\u00020\u000f2\u0006\u0010\u0007\u001a\u00020\u0003H\u0000¢\u0006\u0004\b&\u0010'\u001a\u0013\u0010(\u001a\u00020\u0000*\u00020\u000fH\u0000¢\u0006\u0004\b(\u0010)\u001a\u0017\u0010+\u001a\u00020*2\u0006\u0010\u0007\u001a\u00020\u0003H\u0000¢\u0006\u0004\b+\u0010,\u001a\u001f\u0010-\u001a\u00020*2\u0006\u0010\u001f\u001a\u00020\u00032\u0006\u0010\u0007\u001a\u00020\u0003H\u0000¢\u0006\u0004\b-\u0010.\u001a\u0013\u00100\u001a\u00020\u0003*\u00020/H\u0002¢\u0006\u0004\b0\u00101\u001a#\u00103\u001a\u00020\u00002\u0012\u00102\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00030\u001b\"\u00020\u0003H\u0000¢\u0006\u0004\b3\u00104\u001a\u001f\u00106\u001a\u00020\u0000*\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u000305H\u0000¢\u0006\u0004\b6\u00107¨\u00068"}, d2 = {"Lokhttp3/Headers;", StringUtils.EMPTY, "index", StringUtils.EMPTY, "k", "(Lokhttp3/Headers;I)Ljava/lang/String;", "q", "name", StringUtils.EMPTY, "r", "(Lokhttp3/Headers;Ljava/lang/String;)Ljava/util/List;", StringUtils.EMPTY, "Lkotlin/Pair;", "j", "(Lokhttp3/Headers;)Ljava/util/Iterator;", "Lokhttp3/Headers$Builder;", "l", "(Lokhttp3/Headers;)Lokhttp3/Headers$Builder;", StringUtils.EMPTY, "other", StringUtils.EMPTY, "e", "(Lokhttp3/Headers;Ljava/lang/Object;)Z", "g", "(Lokhttp3/Headers;)I", "p", "(Lokhttp3/Headers;)Ljava/lang/String;", StringUtils.EMPTY, "namesAndValues", "h", "([Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "b", "(Lokhttp3/Headers$Builder;Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Headers$Builder;", "c", "m", "(Lokhttp3/Headers$Builder;Ljava/lang/String;)Lokhttp3/Headers$Builder;", "n", "f", "(Lokhttp3/Headers$Builder;Ljava/lang/String;)Ljava/lang/String;", "d", "(Lokhttp3/Headers$Builder;)Lokhttp3/Headers;", StringUtils.EMPTY, "s", "(Ljava/lang/String;)V", "t", "(Ljava/lang/String;Ljava/lang/String;)V", StringUtils.EMPTY, "a", "(C)Ljava/lang/String;", "inputNamesAndValues", "i", "([Ljava/lang/String;)Lokhttp3/Headers;", StringUtils.EMPTY, "o", "(Ljava/util/Map;)Lokhttp3/Headers;", "okhttp"}, k = 2, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\n-HeadersCommon.kt\nKotlin\n*S Kotlin\n*F\n+ 1 -HeadersCommon.kt\nokhttp3/internal/_HeadersCommonKt\n+ 2 -UtilJvm.kt\nokhttp3/internal/_UtilJvmKt\n+ 3 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n+ 4 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,207:1\n248#2:208\n37#3:209\n36#3,3:210\n1#4:213\n*S KotlinDebug\n*F\n+ 1 -HeadersCommon.kt\nokhttp3/internal/_HeadersCommonKt\n*L\n36#1:208\n136#1:209\n136#1:210,3\n*E\n"})
public final class _HeadersCommonKt {
    private static final String a(char c) {
        String string = Integer.toString(c, CharsKt.checkRadix(16));
        Intrinsics.checkNotNullExpressionValue(string, ap.a(742395872));
        if (string.length() >= 2) {
            return string;
        }
        return '0' + string;
    }

    public static final Headers.Builder b(Headers.Builder builder, String str, String str2) {
        Intrinsics.checkNotNullParameter(builder, "<this>");
        Intrinsics.checkNotNullParameter(str, "name");
        Intrinsics.checkNotNullParameter(str2, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
        s(str);
        t(str2, str);
        c(builder, str, str2);
        return builder;
    }

    public static final Headers.Builder c(Headers.Builder builder, String str, String str2) {
        Intrinsics.checkNotNullParameter(builder, "<this>");
        Intrinsics.checkNotNullParameter(str, "name");
        Intrinsics.checkNotNullParameter(str2, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
        builder.g().add(str);
        builder.g().add(StringsKt.trim((CharSequence) str2).toString());
        return builder;
    }

    public static final Headers d(Headers.Builder builder) {
        Intrinsics.checkNotNullParameter(builder, "<this>");
        return new Headers((String[]) builder.g().toArray(new String[0]));
    }

    public static final boolean e(Headers headers, Object obj) {
        Intrinsics.checkNotNullParameter(headers, "<this>");
        return (obj instanceof Headers) && Arrays.equals(headers.c(), ((Headers) obj).c());
    }

    public static final String f(Headers.Builder builder, String str) {
        Intrinsics.checkNotNullParameter(builder, "<this>");
        Intrinsics.checkNotNullParameter(str, "name");
        int size = builder.g().size() - 2;
        int progressionLastElement = ProgressionUtilKt.getProgressionLastElement(size, 0, -2);
        if (progressionLastElement > size) {
            return null;
        }
        while (!StringsKt.equals(str, (String) builder.g().get(size), true)) {
            if (size == progressionLastElement) {
                return null;
            }
            size -= 2;
        }
        return (String) builder.g().get(size + 1);
    }

    public static final int g(Headers headers) {
        Intrinsics.checkNotNullParameter(headers, "<this>");
        return Arrays.hashCode(headers.c());
    }

    public static final String h(String[] strArr, String str) {
        Intrinsics.checkNotNullParameter(strArr, "namesAndValues");
        Intrinsics.checkNotNullParameter(str, "name");
        int length = strArr.length - 2;
        int progressionLastElement = ProgressionUtilKt.getProgressionLastElement(length, 0, -2);
        if (progressionLastElement > length) {
            return null;
        }
        while (!StringsKt.equals(str, strArr[length], true)) {
            if (length == progressionLastElement) {
                return null;
            }
            length -= 2;
        }
        return strArr[length + 1];
    }

    public static final Headers i(String... strArr) {
        Intrinsics.checkNotNullParameter(strArr, "inputNamesAndValues");
        if (strArr.length % 2 != 0) {
            throw new IllegalArgumentException("Expected alternating header names and values");
        }
        String[] strArr2 = (String[]) Arrays.copyOf(strArr, strArr.length);
        int length = strArr2.length;
        int i = 0;
        for (int i2 = 0; i2 < length; i2++) {
            if (strArr2[i2] == null) {
                throw new IllegalArgumentException("Headers cannot be null");
            }
            strArr2[i2] = StringsKt.trim((CharSequence) strArr[i2]).toString();
        }
        int progressionLastElement = ProgressionUtilKt.getProgressionLastElement(0, strArr2.length - 1, 2);
        if (progressionLastElement >= 0) {
            while (true) {
                String str = strArr2[i];
                String str2 = strArr2[i + 1];
                s(str);
                t(str2, str);
                if (i == progressionLastElement) {
                    break;
                }
                i += 2;
            }
        }
        return new Headers(strArr2);
    }

    public static final Iterator j(Headers headers) {
        Intrinsics.checkNotNullParameter(headers, "<this>");
        int size = headers.size();
        Pair[] pairArr = new Pair[size];
        for (int i = 0; i < size; i++) {
            pairArr[i] = TuplesKt.to(headers.e(i), headers.k(i));
        }
        return ArrayIteratorKt.iterator(pairArr);
    }

    public static final String k(Headers headers, int i) {
        Intrinsics.checkNotNullParameter(headers, "<this>");
        String str = (String) ArraysKt.getOrNull(headers.c(), i * 2);
        if (str != null) {
            return str;
        }
        throw new IndexOutOfBoundsException("name[" + i + AbstractJsonLexerKt.END_LIST);
    }

    public static final Headers.Builder l(Headers headers) {
        Intrinsics.checkNotNullParameter(headers, "<this>");
        Headers.Builder builder = new Headers.Builder();
        CollectionsKt.addAll(builder.g(), headers.c());
        return builder;
    }

    public static final Headers.Builder m(Headers.Builder builder, String str) {
        Intrinsics.checkNotNullParameter(builder, "<this>");
        Intrinsics.checkNotNullParameter(str, "name");
        int i = 0;
        while (i < builder.g().size()) {
            if (StringsKt.equals(str, (String) builder.g().get(i), true)) {
                builder.g().remove(i);
                builder.g().remove(i);
                i -= 2;
            }
            i += 2;
        }
        return builder;
    }

    public static final Headers.Builder n(Headers.Builder builder, String str, String str2) {
        Intrinsics.checkNotNullParameter(builder, "<this>");
        Intrinsics.checkNotNullParameter(str, "name");
        Intrinsics.checkNotNullParameter(str2, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
        s(str);
        t(str2, str);
        builder.h(str);
        c(builder, str, str2);
        return builder;
    }

    public static final Headers o(Map map) {
        Intrinsics.checkNotNullParameter(map, "<this>");
        String[] strArr = new String[map.size() * 2];
        int i = 0;
        for (Map.Entry entry : map.entrySet()) {
            String str = (String) entry.getKey();
            String str2 = (String) entry.getValue();
            String string = StringsKt.trim((CharSequence) str).toString();
            String string2 = StringsKt.trim((CharSequence) str2).toString();
            s(string);
            t(string2, string);
            strArr[i] = string;
            strArr[i + 1] = string2;
            i += 2;
        }
        return new Headers(strArr);
    }

    public static final String p(Headers headers) {
        Intrinsics.checkNotNullParameter(headers, "<this>");
        StringBuilder sb = new StringBuilder();
        int size = headers.size();
        for (int i = 0; i < size; i++) {
            String strE = headers.e(i);
            String strK = headers.k(i);
            sb.append(strE);
            sb.append(": ");
            if (_UtilCommonKt.y(strE)) {
                strK = "██";
            }
            sb.append(strK);
            sb.append("\n");
        }
        return sb.toString();
    }

    public static final String q(Headers headers, int i) {
        Intrinsics.checkNotNullParameter(headers, "<this>");
        String str = (String) ArraysKt.getOrNull(headers.c(), (i * 2) + 1);
        if (str != null) {
            return str;
        }
        throw new IndexOutOfBoundsException("value[" + i + AbstractJsonLexerKt.END_LIST);
    }

    public static final List r(Headers headers, String str) {
        Intrinsics.checkNotNullParameter(headers, "<this>");
        Intrinsics.checkNotNullParameter(str, "name");
        int size = headers.size();
        List listUnmodifiableList = null;
        ArrayList arrayList = null;
        for (int i = 0; i < size; i++) {
            if (StringsKt.equals(str, headers.e(i), true)) {
                if (arrayList == null) {
                    arrayList = new ArrayList(2);
                }
                arrayList.add(headers.k(i));
            }
        }
        if (arrayList != null) {
            listUnmodifiableList = Collections.unmodifiableList(arrayList);
            Intrinsics.checkNotNullExpressionValue(listUnmodifiableList, "unmodifiableList(...)");
        }
        return listUnmodifiableList == null ? CollectionsKt.emptyList() : listUnmodifiableList;
    }

    public static final void s(String str) {
        Intrinsics.checkNotNullParameter(str, "name");
        if (str.length() <= 0) {
            throw new IllegalArgumentException("name is empty");
        }
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char cCharAt = str.charAt(i);
            if ('!' > cCharAt || cCharAt >= 127) {
                throw new IllegalArgumentException(("Unexpected char 0x" + a(cCharAt) + " at " + i + " in header name: " + str).toString());
            }
        }
    }

    public static final void t(String str, String str2) {
        Intrinsics.checkNotNullParameter(str, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
        Intrinsics.checkNotNullParameter(str2, "name");
        int length = str.length();
        for (int i = 0; i < length; i++) {
            char cCharAt = str.charAt(i);
            if (cCharAt != '\t' && (' ' > cCharAt || cCharAt >= 127)) {
                StringBuilder sb = new StringBuilder();
                sb.append("Unexpected char 0x");
                sb.append(a(cCharAt));
                sb.append(" at ");
                sb.append(i);
                sb.append(" in ");
                sb.append(str2);
                sb.append(" value");
                sb.append(_UtilCommonKt.y(str2) ? StringUtils.EMPTY : ": " + str);
                throw new IllegalArgumentException(sb.toString().toString());
            }
        }
    }
}