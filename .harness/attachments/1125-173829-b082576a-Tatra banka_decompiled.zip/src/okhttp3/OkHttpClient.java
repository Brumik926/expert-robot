package okhttp3;

import com.dynatrace.android.callback.OkCallback;
import h.ap;
import java.net.Proxy;
import java.net.ProxySelector;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import javax.net.SocketFactory;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.X509TrustManager;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.Call;
import okhttp3.EventListener;
import okhttp3.WebSocket;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.connection.RealCall;
import okhttp3.internal.connection.RouteDatabase;
import okhttp3.internal.platform.Platform;
import okhttp3.internal.proxy.NullProxySelector;
import okhttp3.internal.tls.CertificateChainCleaner;
import okhttp3.internal.tls.OkHostnameVerifier;
import okhttp3.internal.ws.RealWebSocket;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.pipes.PipesConfigBase;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000þ\u0001\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0002\b\f\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\b\u0016\u0018\u0000 \u0087\u00012\u00020\u00012\u00020\u0002:\u0004¡\u0001¢\u0001B\u0011\b\u0000\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006B\t\b\u0016¢\u0006\u0004\b\u0005\u0010\u0007J\u000f\u0010\t\u001a\u00020\bH\u0002¢\u0006\u0004\b\t\u0010\u0007J\u0015\u0010\r\u001a\u00020\f2\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\r\u0010\u000eJ\u0017\u0010\u0012\u001a\u00020\u00112\u0006\u0010\u0010\u001a\u00020\u000fH\u0016¢\u0006\u0004\b\u0012\u0010\u0013J\u001f\u0010\u0017\u001a\u00020\u00162\u0006\u0010\u0010\u001a\u00020\u000f2\u0006\u0010\u0015\u001a\u00020\u0014H\u0016¢\u0006\u0004\b\u0017\u0010\u0018J\u000f\u0010\u0019\u001a\u00020\u0003H\u0016¢\u0006\u0004\b\u0019\u0010\u001aR\u0017\u0010\u001f\u001a\u00020\u001b8G¢\u0006\f\n\u0004\b\u0012\u0010\u001c\u001a\u0004\b\u001d\u0010\u001eR\u001d\u0010%\u001a\b\u0012\u0004\u0012\u00020!0 8G¢\u0006\f\n\u0004\b\u0017\u0010\"\u001a\u0004\b#\u0010$R\u001d\u0010(\u001a\b\u0012\u0004\u0012\u00020!0 8G¢\u0006\f\n\u0004\b&\u0010\"\u001a\u0004\b'\u0010$R\u0017\u0010.\u001a\u00020)8G¢\u0006\f\n\u0004\b*\u0010+\u001a\u0004\b,\u0010-R\u0017\u00104\u001a\u00020/8G¢\u0006\f\n\u0004\b0\u00101\u001a\u0004\b2\u00103R\u0017\u00106\u001a\u00020/8G¢\u0006\f\n\u0004\b\r\u00101\u001a\u0004\b5\u00103R\u0017\u0010;\u001a\u0002078G¢\u0006\f\n\u0004\b8\u00109\u001a\u0004\b8\u0010:R\u0017\u0010>\u001a\u00020/8G¢\u0006\f\n\u0004\b<\u00101\u001a\u0004\b=\u00103R\u0017\u0010A\u001a\u00020/8G¢\u0006\f\n\u0004\b?\u00101\u001a\u0004\b@\u00103R\u0017\u0010G\u001a\u00020B8G¢\u0006\f\n\u0004\bC\u0010D\u001a\u0004\bE\u0010FR\u0019\u0010L\u001a\u0004\u0018\u00010H8G¢\u0006\f\n\u0004\bI\u0010J\u001a\u0004\b<\u0010KR\u0017\u0010R\u001a\u00020M8G¢\u0006\f\n\u0004\bN\u0010O\u001a\u0004\bP\u0010QR\u0019\u0010X\u001a\u0004\u0018\u00010S8G¢\u0006\f\n\u0004\bT\u0010U\u001a\u0004\bV\u0010WR\u0017\u0010^\u001a\u00020Y8G¢\u0006\f\n\u0004\bZ\u0010[\u001a\u0004\b\\\u0010]R\u0017\u0010`\u001a\u0002078G¢\u0006\f\n\u0004\bE\u00109\u001a\u0004\b_\u0010:R\u0017\u0010e\u001a\u00020a8G¢\u0006\f\n\u0004\b\u001d\u0010b\u001a\u0004\bc\u0010dR\u0016\u0010h\u001a\u0004\u0018\u00010f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\bP\u0010gR\u0019\u0010m\u001a\u0004\u0018\u00010i8G¢\u0006\f\n\u0004\b,\u0010j\u001a\u0004\bk\u0010lR\u001d\u0010o\u001a\b\u0012\u0004\u0012\u00020n0 8G¢\u0006\f\n\u0004\b5\u0010\"\u001a\u0004\bZ\u0010$R\u001d\u0010r\u001a\b\u0012\u0004\u0012\u00020p0 8G¢\u0006\f\n\u0004\b=\u0010\"\u001a\u0004\bq\u0010$R\u0017\u0010w\u001a\u00020s8G¢\u0006\f\n\u0004\b@\u0010t\u001a\u0004\bu\u0010vR\u0017\u0010|\u001a\u00020x8G¢\u0006\f\n\u0004\by\u0010z\u001a\u0004\bI\u0010{R\u001b\u0010\u0081\u0001\u001a\u0004\u0018\u00010}8G¢\u0006\r\n\u0004\b~\u0010\u007f\u001a\u0005\bC\u0010\u0080\u0001R\u001a\u0010\u0084\u0001\u001a\u00030\u0082\u00018G¢\u0006\r\n\u0004\bu\u00102\u001a\u0005\b?\u0010\u0083\u0001R\u001a\u0010\u0085\u0001\u001a\u00030\u0082\u00018G¢\u0006\r\n\u0004\b#\u00102\u001a\u0005\bN\u0010\u0083\u0001R\u001c\u0010\u0088\u0001\u001a\u00030\u0082\u00018G¢\u0006\u000f\n\u0005\b\u0086\u0001\u00102\u001a\u0006\b\u0087\u0001\u0010\u0083\u0001R\u001b\u0010\u008a\u0001\u001a\u00030\u0082\u00018G¢\u0006\u000e\n\u0004\b'\u00102\u001a\u0006\b\u0089\u0001\u0010\u0083\u0001R\u001b\u0010\u008c\u0001\u001a\u00030\u0082\u00018G¢\u0006\u000e\n\u0004\b\u0019\u00102\u001a\u0006\b\u008b\u0001\u0010\u0083\u0001R\u001c\u0010\u008e\u0001\u001a\u00030\u0082\u00018G¢\u0006\u000f\n\u0005\b\u008b\u0001\u00102\u001a\u0006\b\u008d\u0001\u0010\u0083\u0001R\u001b\u0010\u0091\u0001\u001a\u00030\u008f\u00018G¢\u0006\u000e\n\u0004\bq\u0010c\u001a\u0006\b\u0086\u0001\u0010\u0090\u0001R\u001e\u0010\u0095\u0001\u001a\u00030\u0092\u00018\u0000X\u0080\u0004¢\u0006\u000e\n\u0005\bV\u0010\u0093\u0001\u001a\u0005\by\u0010\u0094\u0001R\u001e\u0010\u0099\u0001\u001a\u00030\u0096\u00018\u0000X\u0080\u0004¢\u0006\u000e\n\u0005\b_\u0010\u0097\u0001\u001a\u0005\b~\u0010\u0098\u0001R\u001b\u0010\u009d\u0001\u001a\u00030\u009a\u00018G¢\u0006\u000e\n\u0005\b\\\u0010\u009b\u0001\u001a\u0005\bT\u0010\u009c\u0001R\u0014\u0010 \u0001\u001a\u00020f8G¢\u0006\b\u001a\u0006\b\u009e\u0001\u0010\u009f\u0001¨\u0006£\u0001"}, d2 = {"Lokhttp3/OkHttpClient;", "Lokhttp3/Call$Factory;", "Lokhttp3/WebSocket$Factory;", "Lokhttp3/OkHttpClient$Builder;", "builder", "<init>", "(Lokhttp3/OkHttpClient$Builder;)V", "()V", StringUtils.EMPTY, "L", "Lokhttp3/HttpUrl;", "url", "Lokhttp3/Address;", "f", "(Lokhttp3/HttpUrl;)Lokhttp3/Address;", "Lokhttp3/Request;", "request", "Lokhttp3/Call;", "a", "(Lokhttp3/Request;)Lokhttp3/Call;", "Lokhttp3/WebSocketListener;", "listener", "Lokhttp3/WebSocket;", "b", "(Lokhttp3/Request;Lokhttp3/WebSocketListener;)Lokhttp3/WebSocket;", "B", "()Lokhttp3/OkHttpClient$Builder;", "Lokhttp3/Dispatcher;", "Lokhttp3/Dispatcher;", "p", "()Lokhttp3/Dispatcher;", "dispatcher", StringUtils.EMPTY, "Lokhttp3/Interceptor;", "Ljava/util/List;", "y", "()Ljava/util/List;", "interceptors", "c", "A", "networkInterceptors", "Lokhttp3/EventListener$Factory;", "d", "Lokhttp3/EventListener$Factory;", "r", "()Lokhttp3/EventListener$Factory;", "eventListenerFactory", StringUtils.EMPTY, "e", "Z", "I", "()Z", "retryOnConnectionFailure", "s", "fastFallback", "Lokhttp3/Authenticator;", "g", "Lokhttp3/Authenticator;", "()Lokhttp3/Authenticator;", "authenticator", "h", "t", "followRedirects", "i", "u", "followSslRedirects", "Lokhttp3/CookieJar;", "j", "Lokhttp3/CookieJar;", "o", "()Lokhttp3/CookieJar;", "cookieJar", "Lokhttp3/Cache;", "k", "Lokhttp3/Cache;", "()Lokhttp3/Cache;", "cache", "Lokhttp3/Dns;", "l", "Lokhttp3/Dns;", "q", "()Lokhttp3/Dns;", "dns", "Ljava/net/Proxy;", "m", "Ljava/net/Proxy;", "E", "()Ljava/net/Proxy;", "proxy", "Ljava/net/ProxySelector;", "n", "Ljava/net/ProxySelector;", "G", "()Ljava/net/ProxySelector;", "proxySelector", "F", "proxyAuthenticator", "Ljavax/net/SocketFactory;", "Ljavax/net/SocketFactory;", "J", "()Ljavax/net/SocketFactory;", "socketFactory", "Ljavax/net/ssl/SSLSocketFactory;", "Ljavax/net/ssl/SSLSocketFactory;", "sslSocketFactoryOrNull", "Ljavax/net/ssl/X509TrustManager;", "Ljavax/net/ssl/X509TrustManager;", "O", "()Ljavax/net/ssl/X509TrustManager;", "x509TrustManager", "Lokhttp3/ConnectionSpec;", "connectionSpecs", "Lokhttp3/Protocol;", "D", "protocols", "Ljavax/net/ssl/HostnameVerifier;", "Ljavax/net/ssl/HostnameVerifier;", "x", "()Ljavax/net/ssl/HostnameVerifier;", "hostnameVerifier", "Lokhttp3/CertificatePinner;", "v", "Lokhttp3/CertificatePinner;", "()Lokhttp3/CertificatePinner;", "certificatePinner", "Lokhttp3/internal/tls/CertificateChainCleaner;", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "Lokhttp3/internal/tls/CertificateChainCleaner;", "()Lokhttp3/internal/tls/CertificateChainCleaner;", "certificateChainCleaner", StringUtils.EMPTY, "()I", "callTimeoutMillis", "connectTimeoutMillis", "z", "H", "readTimeoutMillis", "N", "writeTimeoutMillis", "C", "pingIntervalMillis", "M", "webSocketCloseTimeout", StringUtils.EMPTY, "()J", "minWebSocketMessageToCompress", "Lokhttp3/internal/connection/RouteDatabase;", "Lokhttp3/internal/connection/RouteDatabase;", "()Lokhttp3/internal/connection/RouteDatabase;", "routeDatabase", "Lokhttp3/internal/concurrent/TaskRunner;", "Lokhttp3/internal/concurrent/TaskRunner;", "()Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", "Lokhttp3/ConnectionPool;", "Lokhttp3/ConnectionPool;", "()Lokhttp3/ConnectionPool;", "connectionPool", "K", "()Ljavax/net/ssl/SSLSocketFactory;", "sslSocketFactory", "Builder", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nOkHttpClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OkHttpClient.kt\nokhttp3/OkHttpClient\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1397:1\n2746#2,3:1398\n2746#2,3:1401\n1#3:1404\n*S KotlinDebug\n*F\n+ 1 OkHttpClient.kt\nokhttp3/OkHttpClient\n*L\n287#1:1398,3\n349#1:1401,3\n*E\n"})
public class OkHttpClient implements Call.Factory, WebSocket.Factory {
    public static final Companion H = new Companion(null);
    private static final List I = _UtilJvmKt.l(Protocol.f, Protocol.d);
    private static final List J = _UtilJvmKt.l(ConnectionSpec.i, ConnectionSpec.k);
    private final int A;
    private final int B;
    private final int C;
    private final long D;
    private final RouteDatabase E;
    private final TaskRunner F;
    private final ConnectionPool G;
    private final Dispatcher a;
    private final List b;
    private final List c;
    private final EventListener.Factory d;
    private final boolean e;
    private final boolean f;
    private final Authenticator g;
    private final boolean h;
    private final boolean i;
    private final CookieJar j;
    private final Cache k;
    private final Dns l;
    private final Proxy m;
    private final ProxySelector n;
    private final Authenticator o;
    private final SocketFactory p;
    private final SSLSocketFactory q;
    private final X509TrustManager r;
    private final List s;
    private final List t;
    private final HostnameVerifier u;
    private final CertificatePinner v;
    private final CertificateChainCleaner w;
    private final int x;
    private final int y;
    private final int z;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R \u0010\u0006\u001a\b\u0012\u0004\u0012\u00020\u00050\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\b\u0010\tR \u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\n0\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u000b\u0010\u0007\u001a\u0004\b\f\u0010\t¨\u0006\r"}, d2 = {"Lokhttp3/OkHttpClient$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "Lokhttp3/Protocol;", "DEFAULT_PROTOCOLS", "Ljava/util/List;", "b", "()Ljava/util/List;", "Lokhttp3/ConnectionSpec;", "DEFAULT_CONNECTION_SPECS", "a", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final List a() {
            return OkHttpClient.J;
        }

        public final List b() {
            return OkHttpClient.I;
        }

        private Companion() {
        }
    }

    public OkHttpClient(Builder builder) throws NoSuchAlgorithmException, KeyStoreException {
        ProxySelector proxySelectorG;
        List list;
        OkCallback.c(builder);
        Intrinsics.checkNotNullParameter(builder, ap.a(2103790489));
        this.a = builder.s();
        this.b = _UtilJvmKt.x(builder.z());
        this.c = _UtilJvmKt.x(builder.B());
        this.d = builder.u();
        boolean zI = builder.I();
        this.e = zI;
        boolean zV = builder.v();
        this.f = zV;
        this.g = builder.j();
        this.h = builder.w();
        this.i = builder.x();
        this.j = builder.r();
        this.k = builder.k();
        this.l = builder.t();
        this.m = builder.E();
        if (builder.E() != null) {
            proxySelectorG = NullProxySelector.a;
        } else {
            proxySelectorG = builder.G();
            if (proxySelectorG == null && (proxySelectorG = ProxySelector.getDefault()) == null) {
                proxySelectorG = NullProxySelector.a;
            }
        }
        this.n = proxySelectorG;
        this.o = builder.F();
        this.p = builder.K();
        List listQ = builder.q();
        this.s = listQ;
        this.t = builder.D();
        this.u = builder.y();
        this.x = builder.l();
        int iO = builder.o();
        this.y = iO;
        int iH = builder.H();
        this.z = iH;
        int iO2 = builder.O();
        this.A = iO2;
        int iC = builder.C();
        this.B = iC;
        this.C = builder.N();
        this.D = builder.A();
        RouteDatabase routeDatabaseJ = builder.J();
        routeDatabaseJ = routeDatabaseJ == null ? new RouteDatabase() : routeDatabaseJ;
        this.E = routeDatabaseJ;
        TaskRunner taskRunnerM = builder.M();
        this.F = taskRunnerM == null ? TaskRunner.m : taskRunnerM;
        ConnectionPool connectionPoolP = builder.p();
        if (connectionPoolP == null) {
            list = listQ;
            ConnectionPool connectionPool = new ConnectionPool(0, 0L, null, null, null, iH, iO2, iO, iH, iC, zI, zV, routeDatabaseJ, 31, null);
            builder.X(connectionPool);
            connectionPoolP = connectionPool;
        } else {
            list = listQ;
        }
        this.G = connectionPoolP;
        List list2 = list;
        if ((list2 instanceof Collection) && list2.isEmpty()) {
            this.q = null;
            this.w = null;
            this.r = null;
            this.v = CertificatePinner.d;
        } else {
            Iterator it = list2.iterator();
            while (it.hasNext()) {
                if (((ConnectionSpec) it.next()).f()) {
                    if (builder.L() != null) {
                        this.q = builder.L();
                        CertificateChainCleaner certificateChainCleanerM = builder.m();
                        Intrinsics.checkNotNull(certificateChainCleanerM);
                        this.w = certificateChainCleanerM;
                        X509TrustManager x509TrustManagerP = builder.P();
                        Intrinsics.checkNotNull(x509TrustManagerP);
                        this.r = x509TrustManagerP;
                        CertificatePinner certificatePinnerN = builder.n();
                        Intrinsics.checkNotNull(certificateChainCleanerM);
                        this.v = certificatePinnerN.g(certificateChainCleanerM);
                    } else {
                        Platform.Companion companion = Platform.a;
                        X509TrustManager x509TrustManagerS = companion.e().s();
                        this.r = x509TrustManagerS;
                        Platform platformE = companion.e();
                        Intrinsics.checkNotNull(x509TrustManagerS);
                        this.q = platformE.r(x509TrustManagerS);
                        CertificateChainCleaner.Companion companion2 = CertificateChainCleaner.a;
                        Intrinsics.checkNotNull(x509TrustManagerS);
                        CertificateChainCleaner certificateChainCleanerA = companion2.a(x509TrustManagerS);
                        this.w = certificateChainCleanerA;
                        CertificatePinner certificatePinnerN2 = builder.n();
                        Intrinsics.checkNotNull(certificateChainCleanerA);
                        this.v = certificatePinnerN2.g(certificateChainCleanerA);
                    }
                }
            }
            this.q = null;
            this.w = null;
            this.r = null;
            this.v = CertificatePinner.d;
        }
        L();
    }

    private final void L() {
        List list = this.b;
        Intrinsics.checkNotNull(list, "null cannot be cast to non-null type kotlin.collections.List<okhttp3.Interceptor?>");
        if (list.contains(null)) {
            throw new IllegalStateException(("Null interceptor: " + this.b).toString());
        }
        List list2 = this.c;
        Intrinsics.checkNotNull(list2, "null cannot be cast to non-null type kotlin.collections.List<okhttp3.Interceptor?>");
        if (list2.contains(null)) {
            throw new IllegalStateException(("Null network interceptor: " + this.c).toString());
        }
        List list3 = this.s;
        if (!(list3 instanceof Collection) || !list3.isEmpty()) {
            Iterator it = list3.iterator();
            while (it.hasNext()) {
                if (((ConnectionSpec) it.next()).f()) {
                    if (this.q == null) {
                        throw new IllegalStateException("sslSocketFactory == null");
                    }
                    if (this.w == null) {
                        throw new IllegalStateException("certificateChainCleaner == null");
                    }
                    if (this.r == null) {
                        throw new IllegalStateException("x509TrustManager == null");
                    }
                    return;
                }
            }
        }
        if (this.q != null) {
            throw new IllegalStateException("Check failed.");
        }
        if (this.w != null) {
            throw new IllegalStateException("Check failed.");
        }
        if (this.r != null) {
            throw new IllegalStateException("Check failed.");
        }
        if (!Intrinsics.areEqual(this.v, CertificatePinner.d)) {
            throw new IllegalStateException("Check failed.");
        }
        Unit unit = Unit.INSTANCE;
    }

    public final List A() {
        return this.c;
    }

    public Builder B() {
        return new Builder(this);
    }

    public final int C() {
        return this.B;
    }

    public final List D() {
        return this.t;
    }

    public final Proxy E() {
        return this.m;
    }

    public final Authenticator F() {
        return this.o;
    }

    public final ProxySelector G() {
        return this.n;
    }

    public final int H() {
        return this.z;
    }

    public final boolean I() {
        return this.e;
    }

    public final SocketFactory J() {
        return this.p;
    }

    public final SSLSocketFactory K() {
        SSLSocketFactory sSLSocketFactory = this.q;
        if (sSLSocketFactory != null) {
            return sSLSocketFactory;
        }
        throw new IllegalStateException("CLEARTEXT-only client");
    }

    public final int M() {
        return this.C;
    }

    public final int N() {
        return this.A;
    }

    public final X509TrustManager O() {
        return this.r;
    }

    @Override // okhttp3.Call.Factory
    public Call a(Request request) {
        Intrinsics.checkNotNullParameter(request, "request");
        return new RealCall(this, request, false);
    }

    @Override // okhttp3.WebSocket.Factory
    public WebSocket b(Request request, WebSocketListener webSocketListener) {
        Intrinsics.checkNotNullParameter(request, "request");
        Intrinsics.checkNotNullParameter(webSocketListener, "listener");
        RealWebSocket realWebSocket = new RealWebSocket(this.F, request, webSocketListener, new Random(), this.B, null, this.D, this.C);
        realWebSocket.t(this);
        return realWebSocket;
    }

    public final Address f(HttpUrl httpUrl) {
        SSLSocketFactory sSLSocketFactoryK;
        HostnameVerifier hostnameVerifier;
        CertificatePinner certificatePinner;
        Intrinsics.checkNotNullParameter(httpUrl, "url");
        if (httpUrl.h()) {
            sSLSocketFactoryK = K();
            hostnameVerifier = this.u;
            certificatePinner = this.v;
        } else {
            sSLSocketFactoryK = null;
            hostnameVerifier = null;
            certificatePinner = null;
        }
        return new Address(httpUrl.g(), httpUrl.l(), this.l, this.p, sSLSocketFactoryK, hostnameVerifier, certificatePinner, this.o, this.m, this.t, this.s, this.n);
    }

    public final Authenticator g() {
        return this.g;
    }

    public final Cache h() {
        return this.k;
    }

    public final int i() {
        return this.x;
    }

    public final CertificateChainCleaner j() {
        return this.w;
    }

    public final CertificatePinner k() {
        return this.v;
    }

    public final int l() {
        return this.y;
    }

    public final ConnectionPool m() {
        return this.G;
    }

    public final List n() {
        return this.s;
    }

    public final CookieJar o() {
        return this.j;
    }

    public final Dispatcher p() {
        return this.a;
    }

    public final Dns q() {
        return this.l;
    }

    public final EventListener.Factory r() {
        return this.d;
    }

    public final boolean s() {
        return this.f;
    }

    public final boolean t() {
        return this.h;
    }

    public final boolean u() {
        return this.i;
    }

    public final RouteDatabase v() {
        return this.E;
    }

    public final TaskRunner w() {
        return this.F;
    }

    public final HostnameVerifier x() {
        return this.u;
    }

    public final List y() {
        return this.b;
    }

    public final long z() {
        return this.D;
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000à\u0001\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0016\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u001c\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0002\b\u0018\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003B\u0011\b\u0010\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0002\u0010\u0006J\u0015\u0010\t\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\t\u0010\nJ\u0013\u0010\r\u001a\b\u0012\u0004\u0012\u00020\f0\u000b¢\u0006\u0004\b\r\u0010\u000eJ\u0013\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\f0\u000b¢\u0006\u0004\b\u000f\u0010\u000eJ\u0015\u0010\u0011\u001a\u00020\u00002\u0006\u0010\u0010\u001a\u00020\f¢\u0006\u0004\b\u0011\u0010\u0012J\u0015\u0010\u0015\u001a\u00020\u00002\u0006\u0010\u0014\u001a\u00020\u0013¢\u0006\u0004\b\u0015\u0010\u0016J\u0015\u0010\u0019\u001a\u00020\u00002\u0006\u0010\u0018\u001a\u00020\u0017¢\u0006\u0004\b\u0019\u0010\u001aJ\u0015\u0010\u001c\u001a\u00020\u00002\u0006\u0010\u001b\u001a\u00020\u0017¢\u0006\u0004\b\u001c\u0010\u001aJ\u0015\u0010\u001f\u001a\u00020\u00002\u0006\u0010\u001e\u001a\u00020\u001d¢\u0006\u0004\b\u001f\u0010 J\u0017\u0010#\u001a\u00020\u00002\b\u0010\"\u001a\u0004\u0018\u00010!¢\u0006\u0004\b#\u0010$J\u001d\u0010)\u001a\u00020\u00002\u0006\u0010&\u001a\u00020%2\u0006\u0010(\u001a\u00020'¢\u0006\u0004\b)\u0010*J\u001b\u0010.\u001a\u00020\u00002\f\u0010-\u001a\b\u0012\u0004\u0012\u00020,0+¢\u0006\u0004\b.\u0010/J\u001b\u00102\u001a\u00020\u00002\f\u00101\u001a\b\u0012\u0004\u0012\u0002000+¢\u0006\u0004\b2\u0010/J\u0015\u00105\u001a\u00020\u00002\u0006\u00104\u001a\u000203¢\u0006\u0004\b5\u00106J\u001d\u0010;\u001a\u00020\u00002\u0006\u00108\u001a\u0002072\u0006\u0010:\u001a\u000209¢\u0006\u0004\b;\u0010<J\u001d\u0010=\u001a\u00020\u00002\u0006\u00108\u001a\u0002072\u0006\u0010:\u001a\u000209¢\u0006\u0004\b=\u0010<J\u001d\u0010>\u001a\u00020\u00002\u0006\u00108\u001a\u0002072\u0006\u0010:\u001a\u000209¢\u0006\u0004\b>\u0010<J\u001d\u0010@\u001a\u00020\u00002\u0006\u0010?\u001a\u0002072\u0006\u0010:\u001a\u000209¢\u0006\u0004\b@\u0010<J\r\u0010A\u001a\u00020\u0004¢\u0006\u0004\bA\u0010BR\"\u0010I\u001a\u00020C8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0011\u0010D\u001a\u0004\bE\u0010F\"\u0004\bG\u0010HR$\u0010\b\u001a\u0004\u0018\u00010\u00078\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bA\u0010J\u001a\u0004\bK\u0010L\"\u0004\bM\u0010NR \u0010Q\u001a\b\u0012\u0004\u0012\u00020\f0\u000b8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b#\u0010O\u001a\u0004\bP\u0010\u000eR \u0010S\u001a\b\u0012\u0004\u0012\u00020\f0\u000b8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b;\u0010O\u001a\u0004\bR\u0010\u000eR\"\u0010Z\u001a\u00020T8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\t\u0010U\u001a\u0004\bV\u0010W\"\u0004\bX\u0010YR\"\u0010\u0018\u001a\u00020\u00178\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b.\u0010>\u001a\u0004\b[\u0010\\\"\u0004\b]\u0010^R\"\u0010a\u001a\u00020\u00178\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u001f\u0010>\u001a\u0004\b_\u0010\\\"\u0004\b`\u0010^R\"\u0010h\u001a\u00020b8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0015\u0010c\u001a\u0004\bd\u0010e\"\u0004\bf\u0010gR\"\u0010\u001b\u001a\u00020\u00178\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u001c\u0010>\u001a\u0004\bi\u0010\\\"\u0004\bj\u0010^R\"\u0010m\u001a\u00020\u00178\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bd\u0010>\u001a\u0004\bk\u0010\\\"\u0004\bl\u0010^R\"\u0010\u001e\u001a\u00020\u001d8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bn\u0010o\u001a\u0004\bp\u0010q\"\u0004\br\u0010sR$\u0010\"\u001a\u0004\u0018\u00010!8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bt\u0010u\u001a\u0004\bn\u0010v\"\u0004\bw\u0010xR#\u0010\u0080\u0001\u001a\u00020y8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\bz\u0010{\u001a\u0004\b|\u0010}\"\u0004\b~\u0010\u007fR,\u0010\u0088\u0001\u001a\u0005\u0018\u00010\u0081\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0018\n\u0006\b\u0082\u0001\u0010\u0083\u0001\u001a\u0006\b\u0084\u0001\u0010\u0085\u0001\"\u0006\b\u0086\u0001\u0010\u0087\u0001R,\u0010\u0090\u0001\u001a\u0005\u0018\u00010\u0089\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0018\n\u0006\b\u008a\u0001\u0010\u008b\u0001\u001a\u0006\b\u008c\u0001\u0010\u008d\u0001\"\u0006\b\u008e\u0001\u0010\u008f\u0001R%\u0010\u0093\u0001\u001a\u00020b8\u0000@\u0000X\u0080\u000e¢\u0006\u0014\n\u0004\bK\u0010c\u001a\u0005\b\u0091\u0001\u0010e\"\u0005\b\u0092\u0001\u0010gR*\u0010\u009b\u0001\u001a\u00030\u0094\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0018\n\u0006\b\u0095\u0001\u0010\u0096\u0001\u001a\u0006\b\u0097\u0001\u0010\u0098\u0001\"\u0006\b\u0099\u0001\u0010\u009a\u0001R*\u0010¡\u0001\u001a\u0004\u0018\u00010%8\u0000@\u0000X\u0080\u000e¢\u0006\u0017\n\u0005\bp\u0010\u009c\u0001\u001a\u0006\b\u009d\u0001\u0010\u009e\u0001\"\u0006\b\u009f\u0001\u0010 \u0001R*\u0010§\u0001\u001a\u0004\u0018\u00010'8\u0000@\u0000X\u0080\u000e¢\u0006\u0017\n\u0005\bE\u0010¢\u0001\u001a\u0006\b£\u0001\u0010¤\u0001\"\u0006\b¥\u0001\u0010¦\u0001R+\u0010-\u001a\b\u0012\u0004\u0012\u00020,0+8\u0000@\u0000X\u0080\u000e¢\u0006\u0015\n\u0004\b|\u0010O\u001a\u0005\b\u0095\u0001\u0010\u000e\"\u0006\b¨\u0001\u0010©\u0001R+\u00101\u001a\b\u0012\u0004\u0012\u0002000+8\u0000@\u0000X\u0080\u000e¢\u0006\u0015\n\u0004\bV\u0010O\u001a\u0005\bª\u0001\u0010\u000e\"\u0006\b«\u0001\u0010©\u0001R'\u00104\u001a\u0002038\u0000@\u0000X\u0080\u000e¢\u0006\u0017\n\u0005\b_\u0010¬\u0001\u001a\u0006\b\u00ad\u0001\u0010®\u0001\"\u0006\b¯\u0001\u0010°\u0001R)\u0010¶\u0001\u001a\u00030±\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0017\n\u0005\bi\u0010²\u0001\u001a\u0006\b\u0082\u0001\u0010³\u0001\"\u0006\b´\u0001\u0010µ\u0001R*\u0010¼\u0001\u001a\u0005\u0018\u00010·\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0016\n\u0005\bk\u0010¸\u0001\u001a\u0005\bz\u0010¹\u0001\"\u0006\bº\u0001\u0010»\u0001R(\u0010Á\u0001\u001a\u00030½\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0016\n\u0005\b\u00ad\u0001\u0010[\u001a\u0005\bt\u0010¾\u0001\"\u0006\b¿\u0001\u0010À\u0001R(\u0010Ã\u0001\u001a\u00030½\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0016\n\u0004\bP\u0010[\u001a\u0006\b\u008a\u0001\u0010¾\u0001\"\u0006\bÂ\u0001\u0010À\u0001R)\u0010Ç\u0001\u001a\u00030½\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0017\n\u0005\bÄ\u0001\u0010[\u001a\u0006\bÅ\u0001\u0010¾\u0001\"\u0006\bÆ\u0001\u0010À\u0001R(\u0010Ê\u0001\u001a\u00030½\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0016\n\u0004\bR\u0010[\u001a\u0006\bÈ\u0001\u0010¾\u0001\"\u0006\bÉ\u0001\u0010À\u0001R)\u0010Í\u0001\u001a\u00030½\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0017\n\u0005\bË\u0001\u0010[\u001a\u0006\bË\u0001\u0010¾\u0001\"\u0006\bÌ\u0001\u0010À\u0001R)\u0010Ð\u0001\u001a\u00030½\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0017\n\u0005\bª\u0001\u0010[\u001a\u0006\bÎ\u0001\u0010¾\u0001\"\u0006\bÏ\u0001\u0010À\u0001R)\u0010Õ\u0001\u001a\u0002078\u0000@\u0000X\u0080\u000e¢\u0006\u0018\n\u0006\b\u0084\u0001\u0010Ñ\u0001\u001a\u0006\bÄ\u0001\u0010Ò\u0001\"\u0006\bÓ\u0001\u0010Ô\u0001R,\u0010Û\u0001\u001a\u0005\u0018\u00010Ö\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0018\n\u0006\b\u0091\u0001\u0010×\u0001\u001a\u0006\bÑ\u0001\u0010Ø\u0001\"\u0006\bÙ\u0001\u0010Ú\u0001R,\u0010â\u0001\u001a\u0005\u0018\u00010Ü\u00018\u0000@\u0000X\u0080\u000e¢\u0006\u0018\n\u0006\b\u008c\u0001\u0010Ý\u0001\u001a\u0006\bÞ\u0001\u0010ß\u0001\"\u0006\bà\u0001\u0010á\u0001¨\u0006ã\u0001"}, d2 = {"Lokhttp3/OkHttpClient$Builder;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/OkHttpClient;", "okHttpClient", "(Lokhttp3/OkHttpClient;)V", "Lokhttp3/ConnectionPool;", "connectionPool", "e", "(Lokhttp3/ConnectionPool;)Lokhttp3/OkHttpClient$Builder;", StringUtils.EMPTY, "Lokhttp3/Interceptor;", "R", "()Ljava/util/List;", "S", "interceptor", "a", "(Lokhttp3/Interceptor;)Lokhttp3/OkHttpClient$Builder;", "Lokhttp3/EventListener;", "eventListener", "h", "(Lokhttp3/EventListener;)Lokhttp3/OkHttpClient$Builder;", StringUtils.EMPTY, "retryOnConnectionFailure", "W", "(Z)Lokhttp3/OkHttpClient$Builder;", "followRedirects", "i", "Lokhttp3/CookieJar;", "cookieJar", "g", "(Lokhttp3/CookieJar;)Lokhttp3/OkHttpClient$Builder;", "Lokhttp3/Cache;", "cache", "c", "(Lokhttp3/Cache;)Lokhttp3/OkHttpClient$Builder;", "Ljavax/net/ssl/SSLSocketFactory;", "sslSocketFactory", "Ljavax/net/ssl/X509TrustManager;", "trustManager", "Y", "(Ljavax/net/ssl/SSLSocketFactory;Ljavax/net/ssl/X509TrustManager;)Lokhttp3/OkHttpClient$Builder;", StringUtils.EMPTY, "Lokhttp3/ConnectionSpec;", "connectionSpecs", "f", "(Ljava/util/List;)Lokhttp3/OkHttpClient$Builder;", "Lokhttp3/Protocol;", "protocols", "U", "Ljavax/net/ssl/HostnameVerifier;", "hostnameVerifier", "Q", "(Ljavax/net/ssl/HostnameVerifier;)Lokhttp3/OkHttpClient$Builder;", StringUtils.EMPTY, "timeout", "Ljava/util/concurrent/TimeUnit;", "unit", "d", "(JLjava/util/concurrent/TimeUnit;)Lokhttp3/OkHttpClient$Builder;", "V", "Z", "interval", "T", "b", "()Lokhttp3/OkHttpClient;", "Lokhttp3/Dispatcher;", "Lokhttp3/Dispatcher;", "s", "()Lokhttp3/Dispatcher;", "setDispatcher$okhttp", "(Lokhttp3/Dispatcher;)V", "dispatcher", "Lokhttp3/ConnectionPool;", "p", "()Lokhttp3/ConnectionPool;", "X", "(Lokhttp3/ConnectionPool;)V", "Ljava/util/List;", "z", "interceptors", "B", "networkInterceptors", "Lokhttp3/EventListener$Factory;", "Lokhttp3/EventListener$Factory;", "u", "()Lokhttp3/EventListener$Factory;", "setEventListenerFactory$okhttp", "(Lokhttp3/EventListener$Factory;)V", "eventListenerFactory", "I", "()Z", "setRetryOnConnectionFailure$okhttp", "(Z)V", "v", "setFastFallback$okhttp", "fastFallback", "Lokhttp3/Authenticator;", "Lokhttp3/Authenticator;", "j", "()Lokhttp3/Authenticator;", "setAuthenticator$okhttp", "(Lokhttp3/Authenticator;)V", "authenticator", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "setFollowRedirects$okhttp", "x", "setFollowSslRedirects$okhttp", "followSslRedirects", "k", "Lokhttp3/CookieJar;", "r", "()Lokhttp3/CookieJar;", "setCookieJar$okhttp", "(Lokhttp3/CookieJar;)V", "l", "Lokhttp3/Cache;", "()Lokhttp3/Cache;", "setCache$okhttp", "(Lokhttp3/Cache;)V", "Lokhttp3/Dns;", "m", "Lokhttp3/Dns;", "t", "()Lokhttp3/Dns;", "setDns$okhttp", "(Lokhttp3/Dns;)V", "dns", "Ljava/net/Proxy;", "n", "Ljava/net/Proxy;", "E", "()Ljava/net/Proxy;", "setProxy$okhttp", "(Ljava/net/Proxy;)V", "proxy", "Ljava/net/ProxySelector;", "o", "Ljava/net/ProxySelector;", "G", "()Ljava/net/ProxySelector;", "setProxySelector$okhttp", "(Ljava/net/ProxySelector;)V", "proxySelector", "F", "setProxyAuthenticator$okhttp", "proxyAuthenticator", "Ljavax/net/SocketFactory;", "q", "Ljavax/net/SocketFactory;", "K", "()Ljavax/net/SocketFactory;", "setSocketFactory$okhttp", "(Ljavax/net/SocketFactory;)V", "socketFactory", "Ljavax/net/ssl/SSLSocketFactory;", "L", "()Ljavax/net/ssl/SSLSocketFactory;", "setSslSocketFactoryOrNull$okhttp", "(Ljavax/net/ssl/SSLSocketFactory;)V", "sslSocketFactoryOrNull", "Ljavax/net/ssl/X509TrustManager;", "P", "()Ljavax/net/ssl/X509TrustManager;", "setX509TrustManagerOrNull$okhttp", "(Ljavax/net/ssl/X509TrustManager;)V", "x509TrustManagerOrNull", "setConnectionSpecs$okhttp", "(Ljava/util/List;)V", "D", "setProtocols$okhttp", "Ljavax/net/ssl/HostnameVerifier;", "y", "()Ljavax/net/ssl/HostnameVerifier;", "setHostnameVerifier$okhttp", "(Ljavax/net/ssl/HostnameVerifier;)V", "Lokhttp3/CertificatePinner;", "Lokhttp3/CertificatePinner;", "()Lokhttp3/CertificatePinner;", "setCertificatePinner$okhttp", "(Lokhttp3/CertificatePinner;)V", "certificatePinner", "Lokhttp3/internal/tls/CertificateChainCleaner;", "Lokhttp3/internal/tls/CertificateChainCleaner;", "()Lokhttp3/internal/tls/CertificateChainCleaner;", "setCertificateChainCleaner$okhttp", "(Lokhttp3/internal/tls/CertificateChainCleaner;)V", "certificateChainCleaner", StringUtils.EMPTY, "()I", "setCallTimeout$okhttp", "(I)V", "callTimeout", "setConnectTimeout$okhttp", "connectTimeout", "A", "H", "setReadTimeout$okhttp", "readTimeout", "O", "setWriteTimeout$okhttp", "writeTimeout", "C", "setPingInterval$okhttp", "pingInterval", "N", "setWebSocketCloseTimeout$okhttp", "webSocketCloseTimeout", "J", "()J", "setMinWebSocketMessageToCompress$okhttp", "(J)V", "minWebSocketMessageToCompress", "Lokhttp3/internal/connection/RouteDatabase;", "Lokhttp3/internal/connection/RouteDatabase;", "()Lokhttp3/internal/connection/RouteDatabase;", "setRouteDatabase$okhttp", "(Lokhttp3/internal/connection/RouteDatabase;)V", "routeDatabase", "Lokhttp3/internal/concurrent/TaskRunner;", "Lokhttp3/internal/concurrent/TaskRunner;", "M", "()Lokhttp3/internal/concurrent/TaskRunner;", "setTaskRunner$okhttp", "(Lokhttp3/internal/concurrent/TaskRunner;)V", "taskRunner", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nOkHttpClient.kt\nKotlin\n*S Kotlin\n*F\n+ 1 OkHttpClient.kt\nokhttp3/OkHttpClient$Builder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 -UtilJvm.kt\nokhttp3/internal/_UtilJvmKt\n*L\n1#1,1397:1\n1#2:1398\n248#3:1399\n*S KotlinDebug\n*F\n+ 1 OkHttpClient.kt\nokhttp3/OkHttpClient$Builder\n*L\n1057#1:1399\n*E\n"})
    public static final class Builder {
        private int A;
        private int B;
        private int C;
        private int D;
        private long E;
        private RouteDatabase F;
        private TaskRunner G;
        private Dispatcher a;
        private ConnectionPool b;
        private final List c;
        private final List d;
        private EventListener.Factory e;
        private boolean f;
        private boolean g;
        private Authenticator h;
        private boolean i;
        private boolean j;
        private CookieJar k;
        private Cache l;
        private Dns m;
        private Proxy n;
        private ProxySelector o;
        private Authenticator p;
        private SocketFactory q;
        private SSLSocketFactory r;
        private X509TrustManager s;
        private List t;
        private List u;
        private HostnameVerifier v;
        private CertificatePinner w;
        private CertificateChainCleaner x;
        private int y;
        private int z;

        public Builder() {
            this.a = new Dispatcher();
            this.c = new ArrayList();
            this.d = new ArrayList();
            this.e = _UtilJvmKt.c(EventListener.b);
            this.f = true;
            this.g = true;
            Authenticator authenticator = Authenticator.b;
            this.h = authenticator;
            this.i = true;
            this.j = true;
            this.k = CookieJar.b;
            this.m = Dns.b;
            this.p = authenticator;
            SocketFactory socketFactory = SocketFactory.getDefault();
            Intrinsics.checkNotNullExpressionValue(socketFactory, ap.a(996340548));
            this.q = socketFactory;
            Companion companion = OkHttpClient.H;
            this.t = companion.a();
            this.u = companion.b();
            this.v = OkHostnameVerifier.a;
            this.w = CertificatePinner.d;
            this.z = PipesConfigBase.DEFAULT_MAX_FILES_PROCESSED_PER_PROCESS;
            this.A = PipesConfigBase.DEFAULT_MAX_FILES_PROCESSED_PER_PROCESS;
            this.B = PipesConfigBase.DEFAULT_MAX_FILES_PROCESSED_PER_PROCESS;
            this.D = 60000;
            this.E = 1024L;
        }

        public final long A() {
            return this.E;
        }

        public final List B() {
            return this.d;
        }

        public final int C() {
            return this.C;
        }

        public final List D() {
            return this.u;
        }

        public final Proxy E() {
            return this.n;
        }

        public final Authenticator F() {
            return this.p;
        }

        public final ProxySelector G() {
            return this.o;
        }

        public final int H() {
            return this.A;
        }

        public final boolean I() {
            return this.f;
        }

        public final RouteDatabase J() {
            return this.F;
        }

        public final SocketFactory K() {
            return this.q;
        }

        public final SSLSocketFactory L() {
            return this.r;
        }

        public final TaskRunner M() {
            return this.G;
        }

        public final int N() {
            return this.D;
        }

        public final int O() {
            return this.B;
        }

        public final X509TrustManager P() {
            return this.s;
        }

        public final Builder Q(HostnameVerifier hostnameVerifier) {
            Intrinsics.checkNotNullParameter(hostnameVerifier, "hostnameVerifier");
            if (!Intrinsics.areEqual(hostnameVerifier, this.v)) {
                this.F = null;
            }
            this.v = hostnameVerifier;
            return this;
        }

        public final List R() {
            return this.c;
        }

        public final List S() {
            return this.d;
        }

        public final Builder T(long j, TimeUnit timeUnit) {
            Intrinsics.checkNotNullParameter(timeUnit, "unit");
            this.C = _UtilJvmKt.g("interval", j, timeUnit);
            return this;
        }

        public final Builder U(List list) {
            Intrinsics.checkNotNullParameter(list, "protocols");
            List mutableList = CollectionsKt.toMutableList(list);
            Protocol protocol = Protocol.g;
            if (!mutableList.contains(protocol) && !mutableList.contains(Protocol.d)) {
                throw new IllegalArgumentException(("protocols must contain h2_prior_knowledge or http/1.1: " + mutableList).toString());
            }
            if (mutableList.contains(protocol) && mutableList.size() > 1) {
                throw new IllegalArgumentException(("protocols containing h2_prior_knowledge cannot use other protocols: " + mutableList).toString());
            }
            if (mutableList.contains(Protocol.c)) {
                throw new IllegalArgumentException(("protocols must not contain http/1.0: " + mutableList).toString());
            }
            Intrinsics.checkNotNull(mutableList, "null cannot be cast to non-null type kotlin.collections.List<okhttp3.Protocol?>");
            if (mutableList.contains(null)) {
                throw new IllegalArgumentException("protocols must not contain null");
            }
            mutableList.remove(Protocol.e);
            if (!Intrinsics.areEqual(mutableList, this.u)) {
                this.F = null;
            }
            List listUnmodifiableList = Collections.unmodifiableList(mutableList);
            Intrinsics.checkNotNullExpressionValue(listUnmodifiableList, "unmodifiableList(...)");
            this.u = listUnmodifiableList;
            return this;
        }

        public final Builder V(long j, TimeUnit timeUnit) {
            Intrinsics.checkNotNullParameter(timeUnit, "unit");
            this.A = _UtilJvmKt.g("timeout", j, timeUnit);
            return this;
        }

        public final Builder W(boolean z) {
            this.f = z;
            return this;
        }

        public final void X(ConnectionPool connectionPool) {
            this.b = connectionPool;
        }

        public final Builder Y(SSLSocketFactory sSLSocketFactory, X509TrustManager x509TrustManager) {
            Intrinsics.checkNotNullParameter(sSLSocketFactory, "sslSocketFactory");
            Intrinsics.checkNotNullParameter(x509TrustManager, "trustManager");
            if (!Intrinsics.areEqual(sSLSocketFactory, this.r) || !Intrinsics.areEqual(x509TrustManager, this.s)) {
                this.F = null;
            }
            this.r = sSLSocketFactory;
            this.x = CertificateChainCleaner.a.a(x509TrustManager);
            this.s = x509TrustManager;
            return this;
        }

        public final Builder Z(long j, TimeUnit timeUnit) {
            Intrinsics.checkNotNullParameter(timeUnit, "unit");
            this.B = _UtilJvmKt.g("timeout", j, timeUnit);
            return this;
        }

        public final Builder a(Interceptor interceptor) {
            Intrinsics.checkNotNullParameter(interceptor, "interceptor");
            this.d.add(interceptor);
            return this;
        }

        public final OkHttpClient b() {
            return new OkHttpClient(this);
        }

        public final Builder c(Cache cache) {
            this.l = cache;
            return this;
        }

        public final Builder d(long j, TimeUnit timeUnit) {
            Intrinsics.checkNotNullParameter(timeUnit, "unit");
            this.z = _UtilJvmKt.g("timeout", j, timeUnit);
            return this;
        }

        public final Builder e(ConnectionPool connectionPool) {
            Intrinsics.checkNotNullParameter(connectionPool, "connectionPool");
            this.b = connectionPool;
            return this;
        }

        public final Builder f(List list) {
            Intrinsics.checkNotNullParameter(list, "connectionSpecs");
            if (!Intrinsics.areEqual(list, this.t)) {
                this.F = null;
            }
            this.t = _UtilJvmKt.x(list);
            return this;
        }

        public final Builder g(CookieJar cookieJar) {
            Intrinsics.checkNotNullParameter(cookieJar, "cookieJar");
            this.k = cookieJar;
            return this;
        }

        public final Builder h(EventListener eventListener) {
            Intrinsics.checkNotNullParameter(eventListener, "eventListener");
            this.e = _UtilJvmKt.c(eventListener);
            return this;
        }

        public final Builder i(boolean z) {
            this.i = z;
            return this;
        }

        public final Authenticator j() {
            return this.h;
        }

        public final Cache k() {
            return this.l;
        }

        public final int l() {
            return this.y;
        }

        public final CertificateChainCleaner m() {
            return this.x;
        }

        public final CertificatePinner n() {
            return this.w;
        }

        public final int o() {
            return this.z;
        }

        public final ConnectionPool p() {
            return this.b;
        }

        public final List q() {
            return this.t;
        }

        public final CookieJar r() {
            return this.k;
        }

        public final Dispatcher s() {
            return this.a;
        }

        public final Dns t() {
            return this.m;
        }

        public final EventListener.Factory u() {
            return this.e;
        }

        public final boolean v() {
            return this.g;
        }

        public final boolean w() {
            return this.i;
        }

        public final boolean x() {
            return this.j;
        }

        public final HostnameVerifier y() {
            return this.v;
        }

        public final List z() {
            return this.c;
        }

        /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
        public Builder(OkHttpClient okHttpClient) {
            this();
            Intrinsics.checkNotNullParameter(okHttpClient, "okHttpClient");
            this.a = okHttpClient.p();
            this.b = okHttpClient.m();
            CollectionsKt.addAll(this.c, okHttpClient.y());
            CollectionsKt.addAll(this.d, okHttpClient.A());
            this.e = okHttpClient.r();
            this.f = okHttpClient.I();
            this.g = okHttpClient.s();
            this.h = okHttpClient.g();
            this.i = okHttpClient.t();
            this.j = okHttpClient.u();
            this.k = okHttpClient.o();
            this.l = okHttpClient.h();
            this.m = okHttpClient.q();
            this.n = okHttpClient.E();
            this.o = okHttpClient.G();
            this.p = okHttpClient.F();
            this.q = okHttpClient.J();
            this.r = okHttpClient.q;
            this.s = okHttpClient.O();
            this.t = okHttpClient.n();
            this.u = okHttpClient.D();
            this.v = okHttpClient.x();
            this.w = okHttpClient.k();
            this.x = okHttpClient.j();
            this.y = okHttpClient.i();
            this.z = okHttpClient.l();
            this.A = okHttpClient.H();
            this.B = okHttpClient.N();
            this.C = okHttpClient.C();
            this.D = okHttpClient.M();
            this.E = okHttpClient.z();
            this.F = okHttpClient.v();
            this.G = okHttpClient.w();
        }
    }

    public OkHttpClient() {
        this(new Builder());
    }
}