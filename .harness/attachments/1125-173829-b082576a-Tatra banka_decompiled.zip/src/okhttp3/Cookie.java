package okhttp3;

import h.ap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import okhttp3.internal._HostnamesCommonKt;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.http.DateFormattingKt;
import okhttp3.internal.publicsuffix.PublicSuffixDatabase;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.pipes.pipesiterator.PipesIterator;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000(\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\n\n\u0002\u0010\b\n\u0002\b\u0019\u0018\u0000 *2\u00020\u0001:\u0002+,B[\b\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\u0007\u001a\u00020\u0002\u0012\u0006\u0010\b\u001a\u00020\u0002\u0012\u0006\u0010\n\u001a\u00020\t\u0012\u0006\u0010\u000b\u001a\u00020\t\u0012\u0006\u0010\f\u001a\u00020\t\u0012\u0006\u0010\r\u001a\u00020\t\u0012\b\u0010\u000e\u001a\u0004\u0018\u00010\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u001a\u0010\u0012\u001a\u00020\t2\b\u0010\u0011\u001a\u0004\u0018\u00010\u0001H\u0096\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0015\u001a\u00020\u0014H\u0017¢\u0006\u0004\b\u0015\u0010\u0016J\u000f\u0010\u0017\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0017\u0010\u0018J\u0017\u0010\u001a\u001a\u00020\u00022\u0006\u0010\u0019\u001a\u00020\tH\u0000¢\u0006\u0004\b\u001a\u0010\u001bR\u0017\u0010\u0003\u001a\u00020\u00028G¢\u0006\f\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001e\u0010\u0018R\u0017\u0010\u0004\u001a\u00020\u00028G¢\u0006\f\n\u0004\b\u001f\u0010\u001d\u001a\u0004\b \u0010\u0018R\u0017\u0010\u0006\u001a\u00020\u00058G¢\u0006\f\n\u0004\b!\u0010\"\u001a\u0004\b\u0006\u0010#R\u0017\u0010\u0007\u001a\u00020\u00028G¢\u0006\f\n\u0004\b$\u0010\u001d\u001a\u0004\b\u0007\u0010\u0018R\u0017\u0010\b\u001a\u00020\u00028G¢\u0006\f\n\u0004\b\u001e\u0010\u001d\u001a\u0004\b%\u0010\u0018R\u0017\u0010\n\u001a\u00020\t8G¢\u0006\f\n\u0004\b&\u0010'\u001a\u0004\b\n\u0010(R\u0017\u0010\u000b\u001a\u00020\t8G¢\u0006\f\n\u0004\b%\u0010'\u001a\u0004\b\u000b\u0010(R\u0017\u0010\f\u001a\u00020\t8G¢\u0006\f\n\u0004\b\u001a\u0010'\u001a\u0004\b\f\u0010(R\u0017\u0010\r\u001a\u00020\t8G¢\u0006\f\n\u0004\b \u0010'\u001a\u0004\b\r\u0010(R\u0019\u0010\u000e\u001a\u0004\u0018\u00010\u00028G¢\u0006\f\n\u0004\b)\u0010\u001d\u001a\u0004\b\u000e\u0010\u0018¨\u0006-"}, d2 = {"Lokhttp3/Cookie;", StringUtils.EMPTY, StringUtils.EMPTY, "name", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, StringUtils.EMPTY, "expiresAt", "domain", "path", StringUtils.EMPTY, "secure", "httpOnly", "persistent", "hostOnly", "sameSite", "<init>", "(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;ZZZZLjava/lang/String;)V", "other", "equals", "(Ljava/lang/Object;)Z", StringUtils.EMPTY, "hashCode", "()I", "toString", "()Ljava/lang/String;", "forObsoleteRfc2965", "h", "(Z)Ljava/lang/String;", "a", "Ljava/lang/String;", "e", "b", "i", "c", "J", "()J", "d", "g", "f", "Z", "()Z", "j", "k", "Builder", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Cookie {
    public static final Companion k = new Companion(null);
    private static final Pattern l = Pattern.compile(ap.a(2127139964));
    private static final Pattern m = Pattern.compile(ap.a(658644174));
    private static final Pattern n = Pattern.compile(ap.a(38295816));
    private static final Pattern o = Pattern.compile(ap.a(811713360));
    private final String a;
    private final String b;
    private final long c;
    private final String d;
    private final String e;
    private final boolean f;
    private final boolean g;
    private final boolean h;
    private final boolean i;
    private final String j;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\u000b\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\t\n\u0002\b\u000e\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u001f\u0010\b\u001a\u00020\u00002\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u0006H\u0002¢\u0006\u0004\b\b\u0010\tJ\u0015\u0010\u000b\u001a\u00020\u00002\u0006\u0010\n\u001a\u00020\u0004¢\u0006\u0004\b\u000b\u0010\fJ\u0015\u0010\u000e\u001a\u00020\u00002\u0006\u0010\r\u001a\u00020\u0004¢\u0006\u0004\b\u000e\u0010\fJ\u0015\u0010\u000f\u001a\u00020\u00002\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u000f\u0010\fJ\r\u0010\u0011\u001a\u00020\u0010¢\u0006\u0004\b\u0011\u0010\u0012R\u0018\u0010\n\u001a\u0004\u0018\u00010\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0011\u0010\u0013R\u0018\u0010\r\u001a\u0004\u0018\u00010\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u000f\u0010\u0013R\u0016\u0010\u0016\u001a\u00020\u00148\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\b\u0010\u0015R\u0018\u0010\u0005\u001a\u0004\u0018\u00010\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u000b\u0010\u0013R\u0016\u0010\u0017\u001a\u00020\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u000e\u0010\u0013R\u0016\u0010\u001a\u001a\u00020\u00068\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0018\u0010\u0019R\u0016\u0010\u001c\u001a\u00020\u00068\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001b\u0010\u0019R\u0016\u0010\u001e\u001a\u00020\u00068\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001d\u0010\u0019R\u0016\u0010\u0007\u001a\u00020\u00068\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u001f\u0010\u0019R\u0018\u0010!\u001a\u0004\u0018\u00010\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b \u0010\u0013¨\u0006\""}, d2 = {"Lokhttp3/Cookie$Builder;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "domain", StringUtils.EMPTY, "hostOnly", "c", "(Ljava/lang/String;Z)Lokhttp3/Cookie$Builder;", "name", "d", "(Ljava/lang/String;)Lokhttp3/Cookie$Builder;", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "e", "b", "Lokhttp3/Cookie;", "a", "()Lokhttp3/Cookie;", "Ljava/lang/String;", StringUtils.EMPTY, "J", "expiresAt", "path", "f", "Z", "secure", "g", "httpOnly", "h", "persistent", "i", "j", "sameSite", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nCookie.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Cookie.kt\nokhttp3/Cookie$Builder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,727:1\n1#2:728\n*E\n"})
    public static final class Builder {
        private String a;
        private String b;
        private String d;
        private boolean f;
        private boolean g;
        private boolean h;
        private boolean i;
        private String j;
        private long c = 253402300799999L;
        private String e = ap.a(59729289);

        private final Builder c(String str, boolean z) {
            String strK = _HostnamesCommonKt.k(str);
            if (strK != null) {
                this.d = strK;
                this.i = z;
                return this;
            }
            throw new IllegalArgumentException("unexpected domain: " + str);
        }

        public final Cookie a() {
            String str = this.a;
            if (str == null) {
                throw new NullPointerException("builder.name == null");
            }
            String str2 = this.b;
            if (str2 == null) {
                throw new NullPointerException("builder.value == null");
            }
            long j = this.c;
            String str3 = this.d;
            if (str3 != null) {
                return new Cookie(str, str2, j, str3, this.e, this.f, this.g, this.h, this.i, this.j, null);
            }
            throw new NullPointerException("builder.domain == null");
        }

        public final Builder b(String str) {
            Intrinsics.checkNotNullParameter(str, "domain");
            return c(str, false);
        }

        public final Builder d(String str) {
            Intrinsics.checkNotNullParameter(str, "name");
            if (!Intrinsics.areEqual(StringsKt.trim((CharSequence) str).toString(), str)) {
                throw new IllegalArgumentException("name is not trimmed");
            }
            this.a = str;
            return this;
        }

        public final Builder e(String str) {
            Intrinsics.checkNotNullParameter(str, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
            if (!Intrinsics.areEqual(StringsKt.trim((CharSequence) str).toString(), str)) {
                throw new IllegalArgumentException("value is not trimmed");
            }
            this.b = str;
            return this;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\t\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u001f\u0010\b\u001a\u00020\u00072\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\b\u0010\tJ'\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\n\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000bH\u0002¢\u0006\u0004\b\u000f\u0010\u0010J/\u0010\u0013\u001a\u00020\u000b2\u0006\u0010\u0011\u001a\u00020\u00042\u0006\u0010\f\u001a\u00020\u000b2\u0006\u0010\r\u001a\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\u0013\u0010\u0014J\u0017\u0010\u0015\u001a\u00020\u000e2\u0006\u0010\n\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0015\u0010\u0016J\u0017\u0010\u0017\u001a\u00020\u00042\u0006\u0010\n\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0017\u0010\u0018J!\u0010\u001d\u001a\u0004\u0018\u00010\u001c2\u0006\u0010\u001a\u001a\u00020\u00192\u0006\u0010\u001b\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\u001d\u0010\u001eJ)\u0010 \u001a\u0004\u0018\u00010\u001c2\u0006\u0010\u001f\u001a\u00020\u000e2\u0006\u0010\u001a\u001a\u00020\u00192\u0006\u0010\u001b\u001a\u00020\u0004H\u0000¢\u0006\u0004\b \u0010!J%\u0010%\u001a\b\u0012\u0004\u0012\u00020\u001c0$2\u0006\u0010\u001a\u001a\u00020\u00192\u0006\u0010#\u001a\u00020\"H\u0007¢\u0006\u0004\b%\u0010&R\u001c\u0010)\u001a\n (*\u0004\u0018\u00010'0'8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b)\u0010*R\u001c\u0010+\u001a\n (*\u0004\u0018\u00010'0'8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b+\u0010*R\u001c\u0010,\u001a\n (*\u0004\u0018\u00010'0'8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b,\u0010*R\u001c\u0010-\u001a\n (*\u0004\u0018\u00010'0'8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b-\u0010*¨\u0006."}, d2 = {"Lokhttp3/Cookie$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "urlHost", "domain", StringUtils.EMPTY, "b", "(Ljava/lang/String;Ljava/lang/String;)Z", "s", StringUtils.EMPTY, "pos", "limit", StringUtils.EMPTY, "g", "(Ljava/lang/String;II)J", "input", "invert", "a", "(Ljava/lang/String;IIZ)I", "h", "(Ljava/lang/String;)J", "f", "(Ljava/lang/String;)Ljava/lang/String;", "Lokhttp3/HttpUrl;", "url", "setCookie", "Lokhttp3/Cookie;", "c", "(Lokhttp3/HttpUrl;Ljava/lang/String;)Lokhttp3/Cookie;", "currentTimeMillis", "d", "(JLokhttp3/HttpUrl;Ljava/lang/String;)Lokhttp3/Cookie;", "Lokhttp3/Headers;", "headers", StringUtils.EMPTY, "e", "(Lokhttp3/HttpUrl;Lokhttp3/Headers;)Ljava/util/List;", "Ljava/util/regex/Pattern;", "kotlin.jvm.PlatformType", "YEAR_PATTERN", "Ljava/util/regex/Pattern;", "MONTH_PATTERN", "DAY_OF_MONTH_PATTERN", "TIME_PATTERN", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nCookie.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Cookie.kt\nokhttp3/Cookie$Companion\n+ 2 -UtilJvm.kt\nokhttp3/internal/_UtilJvmKt\n*L\n1#1,727:1\n248#2:728\n*S KotlinDebug\n*F\n+ 1 Cookie.kt\nokhttp3/Cookie$Companion\n*L\n723#1:728\n*E\n"})
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private final int a(String str, int i, int i2, boolean z) {
            while (i < i2) {
                char cCharAt = str.charAt(i);
                if (((cCharAt < ' ' && cCharAt != '\t') || cCharAt >= 127 || ('0' <= cCharAt && cCharAt < ':') || (('a' <= cCharAt && cCharAt < '{') || (('A' <= cCharAt && cCharAt < '[') || cCharAt == ':'))) == (!z)) {
                    return i;
                }
                i++;
            }
            return i2;
        }

        private final boolean b(String str, String str2) {
            if (Intrinsics.areEqual(str, str2)) {
                return true;
            }
            return StringsKt.endsWith$default(str, str2, false, 2, (Object) null) && str.charAt((str.length() - str2.length()) - 1) == '.' && !_HostnamesCommonKt.a(str);
        }

        private final String f(String str) {
            String strA = ap.a(1673591719);
            if (StringsKt.endsWith$default(str, strA, false, 2, (Object) null)) {
                throw new IllegalArgumentException(ap.a(981962774));
            }
            String strK = _HostnamesCommonKt.k(StringsKt.removePrefix(str, (CharSequence) strA));
            if (strK != null) {
                return strK;
            }
            throw new IllegalArgumentException();
        }

        private final long g(String str, int i, int i2) {
            int iA = a(str, i, i2, false);
            Matcher matcher = Cookie.o.matcher(str);
            int i3 = -1;
            int i4 = -1;
            int i5 = -1;
            int iIndexOf$default = -1;
            int i6 = -1;
            int i7 = -1;
            while (iA < i2) {
                int iA2 = a(str, iA + 1, i2, true);
                matcher.region(iA, iA2);
                if (i4 == -1 && matcher.usePattern(Cookie.o).matches()) {
                    String strGroup = matcher.group(1);
                    Intrinsics.checkNotNullExpressionValue(strGroup, "group(...)");
                    i4 = Integer.parseInt(strGroup);
                    String strGroup2 = matcher.group(2);
                    Intrinsics.checkNotNullExpressionValue(strGroup2, "group(...)");
                    i6 = Integer.parseInt(strGroup2);
                    String strGroup3 = matcher.group(3);
                    Intrinsics.checkNotNullExpressionValue(strGroup3, "group(...)");
                    i7 = Integer.parseInt(strGroup3);
                } else if (i5 == -1 && matcher.usePattern(Cookie.n).matches()) {
                    String strGroup4 = matcher.group(1);
                    Intrinsics.checkNotNullExpressionValue(strGroup4, "group(...)");
                    i5 = Integer.parseInt(strGroup4);
                } else if (iIndexOf$default == -1 && matcher.usePattern(Cookie.m).matches()) {
                    String strGroup5 = matcher.group(1);
                    Intrinsics.checkNotNullExpressionValue(strGroup5, "group(...)");
                    Locale locale = Locale.US;
                    Intrinsics.checkNotNullExpressionValue(locale, "US");
                    String lowerCase = strGroup5.toLowerCase(locale);
                    Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
                    String strPattern = Cookie.m.pattern();
                    Intrinsics.checkNotNullExpressionValue(strPattern, "pattern(...)");
                    iIndexOf$default = StringsKt.indexOf$default((CharSequence) strPattern, lowerCase, 0, false, 6, (Object) null) / 4;
                } else if (i3 == -1 && matcher.usePattern(Cookie.l).matches()) {
                    String strGroup6 = matcher.group(1);
                    Intrinsics.checkNotNullExpressionValue(strGroup6, "group(...)");
                    i3 = Integer.parseInt(strGroup6);
                }
                iA = a(str, iA2 + 1, i2, false);
            }
            if (70 <= i3 && i3 < 100) {
                i3 += 1900;
            }
            if (i3 >= 0 && i3 < 70) {
                i3 += 2000;
            }
            if (i3 < 1601) {
                throw new IllegalArgumentException("Failed requirement.");
            }
            if (iIndexOf$default == -1) {
                throw new IllegalArgumentException("Failed requirement.");
            }
            if (1 > i5 || i5 >= 32) {
                throw new IllegalArgumentException("Failed requirement.");
            }
            if (i4 < 0 || i4 >= 24) {
                throw new IllegalArgumentException("Failed requirement.");
            }
            if (i6 < 0 || i6 >= 60) {
                throw new IllegalArgumentException("Failed requirement.");
            }
            if (i7 < 0 || i7 >= 60) {
                throw new IllegalArgumentException("Failed requirement.");
            }
            GregorianCalendar gregorianCalendar = new GregorianCalendar(_UtilJvmKt.a);
            gregorianCalendar.setLenient(false);
            gregorianCalendar.set(1, i3);
            gregorianCalendar.set(2, iIndexOf$default - 1);
            gregorianCalendar.set(5, i5);
            gregorianCalendar.set(11, i4);
            gregorianCalendar.set(12, i6);
            gregorianCalendar.set(13, i7);
            gregorianCalendar.set(14, 0);
            return gregorianCalendar.getTimeInMillis();
        }

        private final long h(String str) {
            try {
                long j = Long.parseLong(str);
                if (j <= 0) {
                    return Long.MIN_VALUE;
                }
                return j;
            } catch (NumberFormatException e) {
                if (new Regex("-?\\d+").matches(str)) {
                    return StringsKt.startsWith$default(str, "-", false, 2, (Object) null) ? Long.MIN_VALUE : Long.MAX_VALUE;
                }
                throw e;
            }
        }

        public final Cookie c(HttpUrl httpUrl, String str) {
            Intrinsics.checkNotNullParameter(httpUrl, "url");
            Intrinsics.checkNotNullParameter(str, "setCookie");
            return d(System.currentTimeMillis(), httpUrl, str);
        }

        public final Cookie d(long j, HttpUrl httpUrl, String str) {
            long j2;
            Intrinsics.checkNotNullParameter(httpUrl, "url");
            Intrinsics.checkNotNullParameter(str, "setCookie");
            int iL = _UtilCommonKt.l(str, ';', 0, 0, 6, null);
            int iL2 = _UtilCommonKt.l(str, '=', 0, iL, 2, null);
            Cookie cookie = null;
            if (iL2 == iL) {
                return null;
            }
            String strF = _UtilCommonKt.F(str, 0, iL2, 1, null);
            if (strF.length() == 0 || _UtilCommonKt.p(strF) != -1) {
                return null;
            }
            String strE = _UtilCommonKt.E(str, iL2 + 1, iL);
            if (_UtilCommonKt.p(strE) != -1) {
                return null;
            }
            int i = iL + 1;
            int length = str.length();
            String strF2 = null;
            String str2 = null;
            String str3 = null;
            boolean z = false;
            boolean z2 = false;
            boolean z3 = false;
            boolean z4 = true;
            long jH = -1;
            long jG = 253402300799999L;
            while (i < length) {
                int iJ = _UtilCommonKt.j(str, ';', i, length);
                int iJ2 = _UtilCommonKt.j(str, '=', i, iJ);
                String strE2 = _UtilCommonKt.E(str, i, iJ2);
                String strE3 = iJ2 < iJ ? _UtilCommonKt.E(str, iJ2 + 1, iJ) : StringUtils.EMPTY;
                Cookie cookie2 = cookie;
                if (StringsKt.equals(strE2, "expires", true)) {
                    try {
                        jG = g(strE3, 0, strE3.length());
                        z2 = true;
                    } catch (NumberFormatException | IllegalArgumentException unused) {
                    }
                } else if (StringsKt.equals(strE2, "max-age", true)) {
                    jH = h(strE3);
                    z2 = true;
                } else if (StringsKt.equals(strE2, "domain", true)) {
                    strF2 = f(strE3);
                    z4 = false;
                } else if (StringsKt.equals(strE2, "path", true)) {
                    str2 = strE3;
                } else if (StringsKt.equals(strE2, "secure", true)) {
                    z3 = true;
                } else if (StringsKt.equals(strE2, "httponly", true)) {
                    z = true;
                } else if (StringsKt.equals(strE2, "samesite", true)) {
                    str3 = strE3;
                }
                i = iJ + 1;
                cookie = cookie2;
            }
            Cookie cookie3 = cookie;
            if (jH == Long.MIN_VALUE) {
                j2 = Long.MIN_VALUE;
            } else if (jH != -1) {
                long j3 = j + (jH <= 9223372036854775L ? jH * ((long) PipesIterator.DEFAULT_QUEUE_SIZE) : Long.MAX_VALUE);
                j2 = (j3 < j || j3 > 253402300799999L) ? 253402300799999L : j3;
            } else {
                j2 = jG;
            }
            String strG = httpUrl.g();
            if (strF2 == null) {
                strF2 = strG;
            } else if (!b(strG, strF2)) {
                return cookie3;
            }
            if (strG.length() != strF2.length() && PublicSuffixDatabase.b.c().c(strF2) == null) {
                return cookie3;
            }
            String strSubstring = "/";
            if (str2 == null || !StringsKt.startsWith$default(str2, "/", false, 2, (Object) cookie3)) {
                String strC = httpUrl.c();
                int iLastIndexOf$default = StringsKt.lastIndexOf$default((CharSequence) strC, '/', 0, false, 6, (Object) null);
                if (iLastIndexOf$default != 0) {
                    strSubstring = strC.substring(0, iLastIndexOf$default);
                    Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                }
                str2 = strSubstring;
            }
            return new Cookie(strF, strE, j2, strF2, str2, z3, z, z2, z4, str3, null);
        }

        public final List e(HttpUrl httpUrl, Headers headers) {
            Intrinsics.checkNotNullParameter(httpUrl, "url");
            Intrinsics.checkNotNullParameter(headers, "headers");
            List listL = headers.l("Set-Cookie");
            int size = listL.size();
            List listUnmodifiableList = null;
            ArrayList arrayList = null;
            for (int i = 0; i < size; i++) {
                Cookie cookieC = c(httpUrl, (String) listL.get(i));
                if (cookieC != null) {
                    if (arrayList == null) {
                        arrayList = new ArrayList();
                    }
                    arrayList.add(cookieC);
                }
            }
            if (arrayList != null) {
                listUnmodifiableList = Collections.unmodifiableList(arrayList);
                Intrinsics.checkNotNullExpressionValue(listUnmodifiableList, "unmodifiableList(...)");
            }
            return listUnmodifiableList == null ? CollectionsKt.emptyList() : listUnmodifiableList;
        }

        private Companion() {
        }
    }

    public /* synthetic */ Cookie(String str, String str2, long j, String str3, String str4, boolean z, boolean z2, boolean z3, boolean z4, String str5, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, str2, j, str3, str4, z, z2, z3, z4, str5);
    }

    public static final Cookie f(HttpUrl httpUrl, String str) {
        return k.c(httpUrl, str);
    }

    public final String e() {
        return this.a;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Cookie)) {
            return false;
        }
        Cookie cookie = (Cookie) obj;
        return Intrinsics.areEqual(cookie.a, this.a) && Intrinsics.areEqual(cookie.b, this.b) && cookie.c == this.c && Intrinsics.areEqual(cookie.d, this.d) && Intrinsics.areEqual(cookie.e, this.e) && cookie.f == this.f && cookie.g == this.g && cookie.h == this.h && cookie.i == this.i && Intrinsics.areEqual(cookie.j, this.j);
    }

    public final String g() {
        return this.e;
    }

    public final String h(boolean z) {
        StringBuilder sb = new StringBuilder();
        sb.append(this.a);
        sb.append('=');
        sb.append(this.b);
        if (this.h) {
            if (this.c == Long.MIN_VALUE) {
                sb.append("; max-age=0");
            } else {
                sb.append("; expires=");
                sb.append(DateFormattingKt.b(new Date(this.c)));
            }
        }
        if (!this.i) {
            sb.append("; domain=");
            if (z) {
                sb.append(".");
            }
            sb.append(this.d);
        }
        sb.append("; path=");
        sb.append(this.e);
        if (this.f) {
            sb.append("; secure");
        }
        if (this.g) {
            sb.append("; httponly");
        }
        if (this.j != null) {
            sb.append("; samesite=");
            sb.append(this.j);
        }
        String string = sb.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        return string;
    }

    public int hashCode() {
        int iHashCode = (((((((((((((((((527 + this.a.hashCode()) * 31) + this.b.hashCode()) * 31) + Long.hashCode(this.c)) * 31) + this.d.hashCode()) * 31) + this.e.hashCode()) * 31) + Boolean.hashCode(this.f)) * 31) + Boolean.hashCode(this.g)) * 31) + Boolean.hashCode(this.h)) * 31) + Boolean.hashCode(this.i)) * 31;
        String str = this.j;
        return iHashCode + (str != null ? str.hashCode() : 0);
    }

    public final String i() {
        return this.b;
    }

    public String toString() {
        return h(false);
    }

    private Cookie(String str, String str2, long j, String str3, String str4, boolean z, boolean z2, boolean z3, boolean z4, String str5) {
        this.a = str;
        this.b = str2;
        this.c = j;
        this.d = str3;
        this.e = str4;
        this.f = z;
        this.g = z2;
        this.h = z3;
        this.i = z4;
        this.j = str5;
    }
}