package okhttp3;

import h.ap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.StringCompanionObject;
import kotlin.jvm.internal.markers.KMappedMarker;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.internal._HeadersCommonKt;
import okhttp3.internal.http.DateFormattingKt;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\u0010\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\u0010\u0011\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0010(\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010$\n\u0002\b\t\u0018\u0000 \f2\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u00020\u0001:\u0002,-B\u0017\b\u0000\u0012\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00030\u0004¢\u0006\u0004\b\u0006\u0010\u0007J\u001a\u0010\t\u001a\u0004\u0018\u00010\u00032\u0006\u0010\b\u001a\u00020\u0003H\u0086\u0002¢\u0006\u0004\b\t\u0010\nJ\u0017\u0010\f\u001a\u0004\u0018\u00010\u000b2\u0006\u0010\b\u001a\u00020\u0003¢\u0006\u0004\b\f\u0010\rJ\u0015\u0010\u0010\u001a\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u000e¢\u0006\u0004\b\u0010\u0010\u0011J\u0015\u0010\u0012\u001a\u00020\u00032\u0006\u0010\u000f\u001a\u00020\u000e¢\u0006\u0004\b\u0012\u0010\u0011J\u001b\u0010\u0014\u001a\b\u0012\u0004\u0012\u00020\u00030\u00132\u0006\u0010\b\u001a\u00020\u0003¢\u0006\u0004\b\u0014\u0010\u0015J\"\u0010\u0017\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00030\u00020\u0016H\u0096\u0002¢\u0006\u0004\b\u0017\u0010\u0018J\r\u0010\u001a\u001a\u00020\u0019¢\u0006\u0004\b\u001a\u0010\u001bJ\u001a\u0010\u001f\u001a\u00020\u001e2\b\u0010\u001d\u001a\u0004\u0018\u00010\u001cH\u0096\u0002¢\u0006\u0004\b\u001f\u0010 J\u000f\u0010!\u001a\u00020\u000eH\u0016¢\u0006\u0004\b!\u0010\"J\u000f\u0010#\u001a\u00020\u0003H\u0016¢\u0006\u0004\b#\u0010$J\u001f\u0010&\u001a\u0014\u0012\u0004\u0012\u00020\u0003\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u00130%¢\u0006\u0004\b&\u0010'R \u0010\u0005\u001a\b\u0012\u0004\u0012\u00020\u00030\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\t\u0010(\u001a\u0004\b)\u0010*R\u0011\u0010+\u001a\u00020\u000e8G¢\u0006\u0006\u001a\u0004\b+\u0010\"¨\u0006."}, d2 = {"Lokhttp3/Headers;", StringUtils.EMPTY, "Lkotlin/Pair;", StringUtils.EMPTY, StringUtils.EMPTY, "namesAndValues", "<init>", "([Ljava/lang/String;)V", "name", "a", "(Ljava/lang/String;)Ljava/lang/String;", "Ljava/util/Date;", "b", "(Ljava/lang/String;)Ljava/util/Date;", StringUtils.EMPTY, "index", "e", "(I)Ljava/lang/String;", "k", StringUtils.EMPTY, "l", "(Ljava/lang/String;)Ljava/util/List;", StringUtils.EMPTY, "iterator", "()Ljava/util/Iterator;", "Lokhttp3/Headers$Builder;", "f", "()Lokhttp3/Headers$Builder;", StringUtils.EMPTY, "other", StringUtils.EMPTY, "equals", "(Ljava/lang/Object;)Z", "hashCode", "()I", "toString", "()Ljava/lang/String;", StringUtils.EMPTY, "i", "()Ljava/util/Map;", "[Ljava/lang/String;", "c", "()[Ljava/lang/String;", "size", "Builder", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nHeaders.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Headers.kt\nokhttp3/Headers\n+ 2 -UtilJvm.kt\nokhttp3/internal/_UtilJvmKt\n*L\n1#1,359:1\n252#2:360\n*S KotlinDebug\n*F\n+ 1 Headers.kt\nokhttp3/Headers\n*L\n110#1:360\n*E\n"})
public final class Headers implements Iterable<Pair<? extends String, ? extends String>>, KMappedMarker {
    public static final Companion b = new Companion(null);
    public static final Headers c = new Headers(new String[0]);
    private final String[] a;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\r\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010!\n\u0002\b\u0005\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0006\u001a\u00020\u00002\u0006\u0010\u0005\u001a\u00020\u0004H\u0000¢\u0006\u0004\b\u0006\u0010\u0007J\u001d\u0010\n\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u0004¢\u0006\u0004\b\n\u0010\u000bJ\u001d\u0010\f\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u0004¢\u0006\u0004\b\f\u0010\u000bJ\u001f\u0010\r\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u0004H\u0000¢\u0006\u0004\b\r\u0010\u000bJ\u0015\u0010\u000e\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u0004¢\u0006\u0004\b\u000e\u0010\u0007J \u0010\u000f\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u00042\u0006\u0010\t\u001a\u00020\u0004H\u0086\u0002¢\u0006\u0004\b\u000f\u0010\u000bJ\u001a\u0010\u0010\u001a\u0004\u0018\u00010\u00042\u0006\u0010\b\u001a\u00020\u0004H\u0086\u0002¢\u0006\u0004\b\u0010\u0010\u0011J\r\u0010\u0013\u001a\u00020\u0012¢\u0006\u0004\b\u0013\u0010\u0014R \u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\u00040\u00158\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\n\u0010\u0016\u001a\u0004\b\u0017\u0010\u0018¨\u0006\u001a"}, d2 = {"Lokhttp3/Headers$Builder;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "line", "b", "(Ljava/lang/String;)Lokhttp3/Headers$Builder;", "name", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "a", "(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Headers$Builder;", "d", "c", "h", "i", "f", "(Ljava/lang/String;)Ljava/lang/String;", "Lokhttp3/Headers;", "e", "()Lokhttp3/Headers;", StringUtils.EMPTY, "Ljava/util/List;", "g", "()Ljava/util/List;", "namesAndValues", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nHeaders.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Headers.kt\nokhttp3/Headers$Builder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,359:1\n1#2:360\n*E\n"})
    public static final class Builder {
        private final List a = new ArrayList(20);

        public final Builder a(String str, String str2) {
            Intrinsics.checkNotNullParameter(str, ap.a(1403947951));
            Intrinsics.checkNotNullParameter(str2, ap.a(17344656));
            return _HeadersCommonKt.b(this, str, str2);
        }

        public final Builder b(String str) {
            Intrinsics.checkNotNullParameter(str, "line");
            int iIndexOf$default = StringsKt.indexOf$default((CharSequence) str, AbstractJsonLexerKt.COLON, 1, false, 4, (Object) null);
            if (iIndexOf$default != -1) {
                String strSubstring = str.substring(0, iIndexOf$default);
                Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                String strSubstring2 = str.substring(iIndexOf$default + 1);
                Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
                c(strSubstring, strSubstring2);
                return this;
            }
            if (str.charAt(0) != ':') {
                c(StringUtils.EMPTY, str);
                return this;
            }
            String strSubstring3 = str.substring(1);
            Intrinsics.checkNotNullExpressionValue(strSubstring3, "substring(...)");
            c(StringUtils.EMPTY, strSubstring3);
            return this;
        }

        public final Builder c(String str, String str2) {
            Intrinsics.checkNotNullParameter(str, "name");
            Intrinsics.checkNotNullParameter(str2, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
            return _HeadersCommonKt.c(this, str, str2);
        }

        public final Builder d(String str, String str2) {
            Intrinsics.checkNotNullParameter(str, "name");
            Intrinsics.checkNotNullParameter(str2, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
            _HeadersCommonKt.s(str);
            c(str, str2);
            return this;
        }

        public final Headers e() {
            return _HeadersCommonKt.d(this);
        }

        public final String f(String str) {
            Intrinsics.checkNotNullParameter(str, "name");
            return _HeadersCommonKt.f(this, str);
        }

        public final List g() {
            return this.a;
        }

        public final Builder h(String str) {
            Intrinsics.checkNotNullParameter(str, "name");
            return _HeadersCommonKt.m(this, str);
        }

        public final Builder i(String str, String str2) {
            Intrinsics.checkNotNullParameter(str, "name");
            Intrinsics.checkNotNullParameter(str2, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
            return _HeadersCommonKt.n(this, str, str2);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u0011\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010$\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J#\u0010\b\u001a\u00020\u00072\u0012\u0010\u0006\u001a\n\u0012\u0006\b\u0001\u0012\u00020\u00050\u0004\"\u00020\u0005H\u0007¢\u0006\u0004\b\b\u0010\tJ\u001f\u0010\u000b\u001a\u00020\u0007*\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00050\nH\u0007¢\u0006\u0004\b\u000b\u0010\fR\u0014\u0010\r\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\r\u0010\u000e¨\u0006\u000f"}, d2 = {"Lokhttp3/Headers$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, StringUtils.EMPTY, "namesAndValues", "Lokhttp3/Headers;", "b", "([Ljava/lang/String;)Lokhttp3/Headers;", StringUtils.EMPTY, "a", "(Ljava/util/Map;)Lokhttp3/Headers;", "EMPTY", "Lokhttp3/Headers;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final Headers a(Map map) {
            Intrinsics.checkNotNullParameter(map, ap.a(707896656));
            return _HeadersCommonKt.o(map);
        }

        public final Headers b(String... strArr) {
            Intrinsics.checkNotNullParameter(strArr, "namesAndValues");
            return _HeadersCommonKt.i((String[]) Arrays.copyOf(strArr, strArr.length));
        }

        private Companion() {
        }
    }

    public Headers(String[] strArr) {
        Intrinsics.checkNotNullParameter(strArr, ap.a(17786672));
        this.a = strArr;
    }

    public static final Headers h(Map map) {
        return b.a(map);
    }

    public final String a(String str) {
        Intrinsics.checkNotNullParameter(str, "name");
        return _HeadersCommonKt.h(this.a, str);
    }

    public final Date b(String str) {
        Intrinsics.checkNotNullParameter(str, "name");
        String strA = a(str);
        if (strA != null) {
            return DateFormattingKt.a(strA);
        }
        return null;
    }

    public final String[] c() {
        return this.a;
    }

    public final String e(int i) {
        return _HeadersCommonKt.k(this, i);
    }

    public boolean equals(Object obj) {
        return _HeadersCommonKt.e(this, obj);
    }

    public final Builder f() {
        return _HeadersCommonKt.l(this);
    }

    public int hashCode() {
        return _HeadersCommonKt.g(this);
    }

    public final Map i() {
        TreeMap treeMap = new TreeMap(StringsKt.getCASE_INSENSITIVE_ORDER(StringCompanionObject.INSTANCE));
        int size = size();
        for (int i = 0; i < size; i++) {
            String strE = e(i);
            Locale locale = Locale.US;
            Intrinsics.checkNotNullExpressionValue(locale, "US");
            String lowerCase = strE.toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue(lowerCase, "toLowerCase(...)");
            List arrayList = (List) treeMap.get(lowerCase);
            if (arrayList == null) {
                arrayList = new ArrayList(2);
                treeMap.put(lowerCase, arrayList);
            }
            arrayList.add(k(i));
        }
        return treeMap;
    }

    @Override // java.lang.Iterable
    public Iterator<Pair<? extends String, ? extends String>> iterator() {
        return _HeadersCommonKt.j(this);
    }

    public final String k(int i) {
        return _HeadersCommonKt.q(this, i);
    }

    public final List l(String str) {
        Intrinsics.checkNotNullParameter(str, "name");
        return _HeadersCommonKt.r(this, str);
    }

    public final int size() {
        return this.a.length / 2;
    }

    public String toString() {
        return _HeadersCommonKt.p(this);
    }
}