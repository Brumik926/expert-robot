package okhttp3;

import h.ap;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.ranges.IntProgression;
import kotlin.ranges.RangesKt;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import kotlin.text.Typography;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.internal._HostnamesCommonKt;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal.url._UrlKt;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0010 \n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u000b\n\u0002\b\"\u0018\u0000 \"2\u00020\u0001:\u0002EFBc\b\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0002\u0012\u0006\u0010\u0006\u001a\u00020\u0002\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\f\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00020\t\u0012\u0010\u0010\u000b\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0018\u00010\t\u0012\b\u0010\f\u001a\u0004\u0018\u00010\u0002\u0012\u0006\u0010\r\u001a\u00020\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0011\u001a\u00020\u0010H\u0007¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0014\u001a\u00020\u0013H\u0007¢\u0006\u0004\b\u0014\u0010\u0015J\u0015\u0010\u0017\u001a\u00020\u00022\u0006\u0010\u0016\u001a\u00020\u0007¢\u0006\u0004\b\u0017\u0010\u0018J\u0017\u0010\u0019\u001a\u0004\u0018\u00010\u00022\u0006\u0010\u0016\u001a\u00020\u0007¢\u0006\u0004\b\u0019\u0010\u0018J\r\u0010\u001a\u001a\u00020\u0002¢\u0006\u0004\b\u001a\u0010\u001bJ\u0017\u0010\u001d\u001a\u0004\u0018\u00010\u00002\u0006\u0010\u001c\u001a\u00020\u0002¢\u0006\u0004\b\u001d\u0010\u001eJ\r\u0010 \u001a\u00020\u001f¢\u0006\u0004\b \u0010!J\u0017\u0010\"\u001a\u0004\u0018\u00010\u001f2\u0006\u0010\u001c\u001a\u00020\u0002¢\u0006\u0004\b\"\u0010#J\u001a\u0010&\u001a\u00020%2\b\u0010$\u001a\u0004\u0018\u00010\u0001H\u0096\u0002¢\u0006\u0004\b&\u0010'J\u000f\u0010(\u001a\u00020\u0007H\u0016¢\u0006\u0004\b(\u0010)J\u000f\u0010*\u001a\u00020\u0002H\u0016¢\u0006\u0004\b*\u0010\u001bR\u0017\u0010\u0003\u001a\u00020\u00028G¢\u0006\f\n\u0004\b+\u0010,\u001a\u0004\b-\u0010\u001bR\u0017\u0010\u0004\u001a\u00020\u00028G¢\u0006\f\n\u0004\b.\u0010,\u001a\u0004\b\u0004\u0010\u001bR\u0017\u0010\u0005\u001a\u00020\u00028G¢\u0006\f\n\u0004\b/\u0010,\u001a\u0004\b\u0005\u0010\u001bR\u0017\u0010\u0006\u001a\u00020\u00028G¢\u0006\f\n\u0004\b0\u0010,\u001a\u0004\b1\u0010\u001bR\u0017\u0010\b\u001a\u00020\u00078G¢\u0006\f\n\u0004\b2\u00103\u001a\u0004\b4\u0010)R\u001d\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00020\t8G¢\u0006\f\n\u0004\b5\u00106\u001a\u0004\b\n\u00107R\u001e\u0010\u000b\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0018\u00010\t8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b1\u00106R\u0019\u0010\f\u001a\u0004\u0018\u00010\u00028G¢\u0006\f\n\u0004\b8\u0010,\u001a\u0004\b\f\u0010\u001bR\u0014\u0010\r\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b \u0010,R\u0011\u0010:\u001a\u00020%8F¢\u0006\u0006\u001a\u0004\b8\u00109R\u0011\u0010;\u001a\u00020\u00028G¢\u0006\u0006\u001a\u0004\b5\u0010\u001bR\u0011\u0010<\u001a\u00020\u00028G¢\u0006\u0006\u001a\u0004\b.\u0010\u001bR\u0011\u0010=\u001a\u00020\u00028G¢\u0006\u0006\u001a\u0004\b/\u0010\u001bR\u0017\u0010>\u001a\b\u0012\u0004\u0012\u00020\u00020\t8G¢\u0006\u0006\u001a\u0004\b0\u00107R\u0013\u0010?\u001a\u0004\u0018\u00010\u00028G¢\u0006\u0006\u001a\u0004\b2\u0010\u001bR\u0013\u0010A\u001a\u0004\u0018\u00010\u00028G¢\u0006\u0006\u001a\u0004\b@\u0010\u001bR\u0011\u0010C\u001a\u00020\u00078G¢\u0006\u0006\u001a\u0004\bB\u0010)R\u0013\u0010D\u001a\u0004\u0018\u00010\u00028G¢\u0006\u0006\u001a\u0004\b+\u0010\u001b¨\u0006G"}, d2 = {"Lokhttp3/HttpUrl;", StringUtils.EMPTY, StringUtils.EMPTY, "scheme", "username", "password", "host", StringUtils.EMPTY, "port", StringUtils.EMPTY, "pathSegments", "queryNamesAndValues", "fragment", "url", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/util/List;Ljava/util/List;Ljava/lang/String;Ljava/lang/String;)V", "Ljava/net/URL;", "u", "()Ljava/net/URL;", "Ljava/net/URI;", "t", "()Ljava/net/URI;", "index", "n", "(I)Ljava/lang/String;", "o", "q", "()Ljava/lang/String;", "link", "r", "(Ljava/lang/String;)Lokhttp3/HttpUrl;", "Lokhttp3/HttpUrl$Builder;", "i", "()Lokhttp3/HttpUrl$Builder;", "j", "(Ljava/lang/String;)Lokhttp3/HttpUrl$Builder;", "other", StringUtils.EMPTY, "equals", "(Ljava/lang/Object;)Z", "hashCode", "()I", "toString", "a", "Ljava/lang/String;", "s", "b", "c", "d", "g", "e", "I", "l", "f", "Ljava/util/List;", "()Ljava/util/List;", "h", "()Z", "isHttps", "encodedUsername", "encodedPassword", "encodedPath", "encodedPathSegments", "encodedQuery", "m", "query", "p", "querySize", "encodedFragment", "Builder", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nHttpUrl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HttpUrl.kt\nokhttp3/HttpUrl\n+ 2 -UtilJvm.kt\nokhttp3/internal/_UtilJvmKt\n*L\n1#1,1810:1\n252#2:1811\n248#2:1812\n*S KotlinDebug\n*F\n+ 1 HttpUrl.kt\nokhttp3/HttpUrl\n*L\n624#1:1811\n648#1:1812\n*E\n"})
public final class HttpUrl {
    public static final Companion j = new Companion(null);
    private final String a;
    private final String b;
    private final String c;
    private final String d;
    private final int e;
    private final List f;
    private final List g;
    private final String h;
    private final String i;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\b\n\u0002\u0010\u000b\n\u0002\b\b\n\u0002\u0010!\n\u0002\b \n\u0002\u0018\u0002\n\u0002\b#\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u000f\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0005\u0010\u0006J%\u0010\r\u001a\u00020\f*\b\u0012\u0004\u0012\u00020\b0\u00072\n\u0010\u000b\u001a\u00060\tj\u0002`\nH\u0002¢\u0006\u0004\b\r\u0010\u000eJ'\u0010\u0012\u001a\u00020\f2\u0006\u0010\u000f\u001a\u00020\b2\u0006\u0010\u0010\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0012\u0010\u0013J7\u0010\u0018\u001a\u00020\f2\u0006\u0010\u000f\u001a\u00020\b2\u0006\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u0016\u001a\u00020\u00152\u0006\u0010\u0017\u001a\u00020\u0015H\u0002¢\u0006\u0004\b\u0018\u0010\u0019J\u000f\u0010\u001a\u001a\u00020\fH\u0002¢\u0006\u0004\b\u001a\u0010\u0003J\u0017\u0010\u001b\u001a\u00020\u00152\u0006\u0010\u000f\u001a\u00020\bH\u0002¢\u0006\u0004\b\u001b\u0010\u001cJ\u0017\u0010\u001d\u001a\u00020\u00152\u0006\u0010\u000f\u001a\u00020\bH\u0002¢\u0006\u0004\b\u001d\u0010\u001cJ\u001b\u0010\u001f\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u001e*\u00020\bH\u0002¢\u0006\u0004\b\u001f\u0010 J'\u0010!\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\b2\u0006\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u0004H\u0002¢\u0006\u0004\b!\u0010\"J#\u0010#\u001a\u00020\u0004*\u00020\b2\u0006\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u0004H\u0002¢\u0006\u0004\b#\u0010\"J'\u0010$\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\b2\u0006\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u0004H\u0002¢\u0006\u0004\b$\u0010\"J'\u0010%\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\b2\u0006\u0010\u0014\u001a\u00020\u00042\u0006\u0010\u0011\u001a\u00020\u0004H\u0002¢\u0006\u0004\b%\u0010\"J\u0015\u0010'\u001a\u00020\u00002\u0006\u0010&\u001a\u00020\b¢\u0006\u0004\b'\u0010(J\u0015\u0010*\u001a\u00020\u00002\u0006\u0010)\u001a\u00020\b¢\u0006\u0004\b*\u0010(J\u0015\u0010,\u001a\u00020\u00002\u0006\u0010+\u001a\u00020\b¢\u0006\u0004\b,\u0010(J\u0015\u0010.\u001a\u00020\u00002\u0006\u0010-\u001a\u00020\b¢\u0006\u0004\b.\u0010(J\u0015\u00100\u001a\u00020\u00002\u0006\u0010/\u001a\u00020\u0004¢\u0006\u0004\b0\u00101J\u0017\u00103\u001a\u00020\u00002\b\u00102\u001a\u0004\u0018\u00010\b¢\u0006\u0004\b3\u0010(J\u0017\u00105\u001a\u00020\u00002\b\u00104\u001a\u0004\u0018\u00010\b¢\u0006\u0004\b5\u0010(J\u001f\u00108\u001a\u00020\u00002\u0006\u00106\u001a\u00020\b2\b\u00107\u001a\u0004\u0018\u00010\b¢\u0006\u0004\b8\u00109J\u001f\u0010<\u001a\u00020\u00002\u0006\u0010:\u001a\u00020\b2\b\u0010;\u001a\u0004\u0018\u00010\b¢\u0006\u0004\b<\u00109J\u000f\u0010=\u001a\u00020\u0000H\u0000¢\u0006\u0004\b=\u0010>J\r\u0010@\u001a\u00020?¢\u0006\u0004\b@\u0010AJ\u000f\u0010B\u001a\u00020\bH\u0016¢\u0006\u0004\bB\u0010CJ!\u0010E\u001a\u00020\u00002\b\u0010D\u001a\u0004\u0018\u00010?2\u0006\u0010\u000f\u001a\u00020\bH\u0000¢\u0006\u0004\bE\u0010FR$\u0010&\u001a\u0004\u0018\u00010\b8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b<\u0010G\u001a\u0004\bH\u0010C\"\u0004\bI\u0010JR\"\u0010M\u001a\u00020\b8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b8\u0010G\u001a\u0004\bK\u0010C\"\u0004\bL\u0010JR\"\u0010P\u001a\u00020\b8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b@\u0010G\u001a\u0004\bN\u0010C\"\u0004\bO\u0010JR$\u0010-\u001a\u0004\u0018\u00010\b8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010G\u001a\u0004\bQ\u0010C\"\u0004\bR\u0010JR\"\u0010/\u001a\u00020\u00048\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b5\u0010S\u001a\u0004\bT\u0010\u0006\"\u0004\bU\u0010VR \u0010Z\u001a\b\u0012\u0004\u0012\u00020\b0\u001e8\u0000X\u0080\u0004¢\u0006\f\n\u0004\bW\u0010X\u001a\u0004\bW\u0010YR,\u0010^\u001a\f\u0012\u0006\u0012\u0004\u0018\u00010\b\u0018\u00010\u001e8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b.\u0010X\u001a\u0004\b[\u0010Y\"\u0004\b\\\u0010]R$\u0010a\u001a\u0004\u0018\u00010\b8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u001b\u0010G\u001a\u0004\b_\u0010C\"\u0004\b`\u0010J¨\u0006b"}, d2 = {"Lokhttp3/HttpUrl$Builder;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "d", "()I", StringUtils.EMPTY, StringUtils.EMPTY, "Ljava/lang/StringBuilder;", "Lkotlin/text/StringBuilder;", "out", StringUtils.EMPTY, "C", "(Ljava/util/List;Ljava/lang/StringBuilder;)V", "input", "startPos", "limit", "s", "(Ljava/lang/String;II)V", "pos", StringUtils.EMPTY, "addTrailingSlash", "alreadyEncoded", "p", "(Ljava/lang/String;IIZZ)V", "m", "h", "(Ljava/lang/String;)Z", "i", StringUtils.EMPTY, "D", "(Ljava/lang/String;)Ljava/util/List;", "u", "(Ljava/lang/String;II)I", "B", "o", "k", "scheme", "t", "(Ljava/lang/String;)Lokhttp3/HttpUrl$Builder;", "username", "E", "password", "l", "host", "g", "port", "n", "(I)Lokhttp3/HttpUrl$Builder;", "query", "q", "encodedQuery", "e", "name", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "b", "(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/HttpUrl$Builder;", "encodedName", "encodedValue", "a", "r", "()Lokhttp3/HttpUrl$Builder;", "Lokhttp3/HttpUrl;", "c", "()Lokhttp3/HttpUrl;", "toString", "()Ljava/lang/String;", "base", "j", "(Lokhttp3/HttpUrl;Ljava/lang/String;)Lokhttp3/HttpUrl$Builder;", "Ljava/lang/String;", "getScheme$okhttp", "A", "(Ljava/lang/String;)V", "getEncodedUsername$okhttp", "x", "encodedUsername", "getEncodedPassword$okhttp", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "encodedPassword", "getHost$okhttp", "y", "I", "getPort$okhttp", "z", "(I)V", "f", "Ljava/util/List;", "()Ljava/util/List;", "encodedPathSegments", "getEncodedQueryNamesAndValues$okhttp", "setEncodedQueryNamesAndValues$okhttp", "(Ljava/util/List;)V", "encodedQueryNamesAndValues", "getEncodedFragment$okhttp", "v", "encodedFragment", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nHttpUrl.kt\nKotlin\n*S Kotlin\n*F\n+ 1 HttpUrl.kt\nokhttp3/HttpUrl$Builder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,1810:1\n1#2:1811\n1563#3:1812\n1634#3,3:1813\n1563#3:1816\n1634#3,3:1817\n*S KotlinDebug\n*F\n+ 1 HttpUrl.kt\nokhttp3/HttpUrl$Builder\n*L\n1265#1:1812\n1265#1:1813,3\n1266#1:1816\n1266#1:1817,3\n*E\n"})
    public static final class Builder {
        private String a;
        private String b;
        private String c;
        private String d;
        private int e;
        private final List f;
        private List g;
        private String h;

        public Builder() {
            String strA = ap.a(659552864);
            this.b = strA;
            this.c = strA;
            this.e = -1;
            this.f = CollectionsKt.mutableListOf(new String[]{strA});
        }

        private final int B(String str, int i, int i2) {
            int i3 = 0;
            while (i < i2) {
                char cCharAt = str.charAt(i);
                if (cCharAt != '/' && cCharAt != '\\') {
                    break;
                }
                i3++;
                i++;
            }
            return i3;
        }

        private final void C(List list, StringBuilder sb) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                sb.append('/');
                sb.append((String) list.get(i));
            }
        }

        private final List D(String str) {
            ArrayList arrayList = new ArrayList();
            int i = 0;
            while (i <= str.length()) {
                String str2 = str;
                int iIndexOf$default = StringsKt.indexOf$default((CharSequence) str2, Typography.amp, i, false, 4, (Object) null);
                if (iIndexOf$default == -1) {
                    iIndexOf$default = str2.length();
                }
                int iIndexOf$default2 = StringsKt.indexOf$default((CharSequence) str2, '=', i, false, 4, (Object) null);
                if (iIndexOf$default2 == -1 || iIndexOf$default2 > iIndexOf$default) {
                    String strSubstring = str2.substring(i, iIndexOf$default);
                    Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                    arrayList.add(strSubstring);
                    arrayList.add(null);
                } else {
                    String strSubstring2 = str2.substring(i, iIndexOf$default2);
                    Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
                    arrayList.add(strSubstring2);
                    String strSubstring3 = str2.substring(iIndexOf$default2 + 1, iIndexOf$default);
                    Intrinsics.checkNotNullExpressionValue(strSubstring3, "substring(...)");
                    arrayList.add(strSubstring3);
                }
                i = iIndexOf$default + 1;
                str = str2;
            }
            return arrayList;
        }

        private final int d() {
            int i = this.e;
            if (i != -1) {
                return i;
            }
            Companion companion = HttpUrl.j;
            String str = this.a;
            Intrinsics.checkNotNull(str);
            return companion.b(str);
        }

        private final boolean h(String str) {
            return Intrinsics.areEqual(str, ".") || StringsKt.equals(str, "%2e", true);
        }

        private final boolean i(String str) {
            return Intrinsics.areEqual(str, "..") || StringsKt.equals(str, "%2e.", true) || StringsKt.equals(str, ".%2e", true) || StringsKt.equals(str, "%2e%2e", true);
        }

        private final int k(String str, int i, int i2) {
            int i3;
            try {
                i3 = Integer.parseInt(_UrlKt.b(str, i, i2, StringUtils.EMPTY, false, false, false, false, 120, null));
            } catch (NumberFormatException unused) {
            }
            if (1 > i3 || i3 >= 65536) {
                return -1;
            }
            return i3;
        }

        private final void m() {
            if (((String) this.f.remove(r0.size() - 1)).length() != 0 || this.f.isEmpty()) {
                this.f.add(StringUtils.EMPTY);
            } else {
                this.f.set(r2.size() - 1, StringUtils.EMPTY);
            }
        }

        private final int o(String str, int i, int i2) {
            while (i < i2) {
                char cCharAt = str.charAt(i);
                if (cCharAt == ':') {
                    return i;
                }
                if (cCharAt == '[') {
                    do {
                        i++;
                        if (i < i2) {
                        }
                    } while (str.charAt(i) != ']');
                }
                i++;
            }
            return i2;
        }

        private final void p(String str, int i, int i2, boolean z, boolean z2) {
            String strB = _UrlKt.b(str, i, i2, " \"<>^`{}|/\\?#", z2, false, false, false, 112, null);
            if (h(strB)) {
                return;
            }
            if (i(strB)) {
                m();
                return;
            }
            if (((CharSequence) this.f.get(r12.size() - 1)).length() == 0) {
                this.f.set(r12.size() - 1, strB);
            } else {
                this.f.add(strB);
            }
            if (z) {
                this.f.add(StringUtils.EMPTY);
            }
        }

        private final void s(String str, int i, int i2) {
            if (i == i2) {
                return;
            }
            char cCharAt = str.charAt(i);
            if (cCharAt == '/' || cCharAt == '\\') {
                this.f.clear();
                this.f.add(StringUtils.EMPTY);
                i++;
            } else {
                List list = this.f;
                list.set(list.size() - 1, StringUtils.EMPTY);
            }
            int i3 = i;
            while (i3 < i2) {
                int iK = _UtilCommonKt.k(str, "/\\", i3, i2);
                boolean z = iK < i2;
                Builder builder = this;
                String str2 = str;
                builder.p(str2, i3, iK, z, true);
                if (z) {
                    i3 = iK + 1;
                    this = builder;
                    str = str2;
                } else {
                    this = builder;
                    str = str2;
                    i3 = iK;
                }
            }
        }

        private final int u(String str, int i, int i2) {
            if (i2 - i < 2) {
                return -1;
            }
            char cCharAt = str.charAt(i);
            if ((Intrinsics.compare(cCharAt, 97) >= 0 && Intrinsics.compare(cCharAt, 122) <= 0) || (Intrinsics.compare(cCharAt, 65) >= 0 && Intrinsics.compare(cCharAt, 90) <= 0)) {
                while (true) {
                    i++;
                    if (i >= i2) {
                        break;
                    }
                    char cCharAt2 = str.charAt(i);
                    if ('a' > cCharAt2 || cCharAt2 >= '{') {
                        if ('A' > cCharAt2 || cCharAt2 >= '[') {
                            if ('0' > cCharAt2 || cCharAt2 >= ':') {
                                if (cCharAt2 != '+' && cCharAt2 != '-' && cCharAt2 != '.') {
                                    if (cCharAt2 == ':') {
                                        return i;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return -1;
        }

        public final void A(String str) {
            this.a = str;
        }

        public final Builder E(String str) {
            Intrinsics.checkNotNullParameter(str, "username");
            this.b = _UrlKt.b(str, 0, 0, " \"':;<=>@[]^`{}|/\\?#", false, false, false, false, 123, null);
            return this;
        }

        public final Builder a(String str, String str2) {
            Intrinsics.checkNotNullParameter(str, "encodedName");
            if (this.g == null) {
                this.g = new ArrayList();
            }
            List list = this.g;
            Intrinsics.checkNotNull(list);
            list.add(_UrlKt.b(str, 0, 0, " \"'<>#&=", true, false, true, false, 83, null));
            List list2 = this.g;
            Intrinsics.checkNotNull(list2);
            list2.add(str2 != null ? _UrlKt.b(str2, 0, 0, " \"'<>#&=", true, false, true, false, 83, null) : null);
            return this;
        }

        public final Builder b(String str, String str2) {
            Intrinsics.checkNotNullParameter(str, "name");
            if (this.g == null) {
                this.g = new ArrayList();
            }
            List list = this.g;
            Intrinsics.checkNotNull(list);
            list.add(_UrlKt.b(str, 0, 0, " !\"#$&'(),/:;<=>?@[]\\^`{|}~", false, false, true, false, 91, null));
            List list2 = this.g;
            Intrinsics.checkNotNull(list2);
            list2.add(str2 != null ? _UrlKt.b(str2, 0, 0, " !\"#$&'(),/:;<=>?@[]\\^`{|}~", false, false, true, false, 91, null) : null);
            return this;
        }

        public final HttpUrl c() {
            ArrayList arrayList;
            String str = this.a;
            if (str == null) {
                throw new IllegalStateException("scheme == null");
            }
            String strG = _UrlKt.g(this.b, 0, 0, false, 7, null);
            String strG2 = _UrlKt.g(this.c, 0, 0, false, 7, null);
            String str2 = this.d;
            if (str2 == null) {
                throw new IllegalStateException("host == null");
            }
            int iD = d();
            List list = this.f;
            ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(list, 10));
            Iterator it = list.iterator();
            while (it.hasNext()) {
                arrayList2.add(_UrlKt.g((String) it.next(), 0, 0, false, 7, null));
            }
            List list2 = this.g;
            if (list2 != null) {
                List<String> list3 = list2;
                arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(list3, 10));
                for (String str3 : list3) {
                    arrayList.add(str3 != null ? _UrlKt.g(str3, 0, 0, true, 3, null) : null);
                }
            } else {
                arrayList = null;
            }
            String str4 = this.h;
            return new HttpUrl(str, strG, strG2, str2, iD, arrayList2, arrayList, str4 != null ? _UrlKt.g(str4, 0, 0, false, 7, null) : null, toString(), null);
        }

        public final Builder e(String str) {
            String strB;
            this.g = (str == null || (strB = _UrlKt.b(str, 0, 0, " \"'<>#", true, false, true, false, 83, null)) == null) ? null : D(strB);
            return this;
        }

        public final List f() {
            return this.f;
        }

        public final Builder g(String str) {
            Intrinsics.checkNotNullParameter(str, "host");
            String strK = _HostnamesCommonKt.k(_UrlKt.g(str, 0, 0, false, 7, null));
            if (strK != null) {
                this.d = strK;
                return this;
            }
            throw new IllegalArgumentException("unexpected host: " + str);
        }

        public final Builder j(HttpUrl httpUrl, String str) {
            String str2;
            int iK;
            boolean z;
            int i;
            int i2;
            char c;
            String str3 = str;
            Intrinsics.checkNotNullParameter(str3, "input");
            int iR = _UtilCommonKt.r(str3, 0, 0, 3, null);
            int iT = _UtilCommonKt.t(str3, iR, 0, 2, null);
            int iU = u(str3, iR, iT);
            boolean z2 = true;
            if (iU != -1) {
                if (StringsKt.startsWith(str3, "https:", iR, true)) {
                    this.a = "https";
                    iR += 6;
                } else {
                    if (!StringsKt.startsWith(str3, "http:", iR, true)) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("Expected URL scheme 'http' or 'https' but was '");
                        String strSubstring = str3.substring(0, iU);
                        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                        sb.append(strSubstring);
                        sb.append('\'');
                        throw new IllegalArgumentException(sb.toString());
                    }
                    this.a = "http";
                    iR += 5;
                }
            } else {
                if (httpUrl == null) {
                    if (str3.length() > 6) {
                        str2 = StringsKt.take(str3, 6) + "...";
                    } else {
                        str2 = str3;
                    }
                    throw new IllegalArgumentException("Expected URL scheme 'http' or 'https' but no scheme was found for " + str2);
                }
                this.a = httpUrl.s();
            }
            int iB = B(str3, iR, iT);
            char c2 = '?';
            char c3 = '#';
            if (iB >= 2 || httpUrl == null || !Intrinsics.areEqual(httpUrl.s(), this.a)) {
                boolean z3 = false;
                boolean z4 = false;
                int i3 = iR + iB;
                while (true) {
                    iK = _UtilCommonKt.k(str3, "@/\\?#", i3, iT);
                    byte bCharAt = iK != iT ? str3.charAt(iK) : (byte) -1;
                    if (bCharAt == -1 || bCharAt == c3 || bCharAt == 47 || bCharAt == 92 || bCharAt == c2) {
                        break;
                    }
                    if (bCharAt == 64) {
                        if (z3) {
                            z = z2;
                            StringBuilder sb2 = new StringBuilder();
                            sb2.append(this.c);
                            sb2.append("%40");
                            str3 = str;
                            i = iK;
                            sb2.append(_UrlKt.b(str3, i3, iK, " \"':;<=>@[]^`{}|/\\?#", true, false, false, false, 112, null));
                            this.c = sb2.toString();
                        } else {
                            int iJ = _UtilCommonKt.j(str3, AbstractJsonLexerKt.COLON, i3, iK);
                            z = z2;
                            String strB = _UrlKt.b(str3, i3, iJ, " \"':;<=>@[]^`{}|/\\?#", true, false, false, false, 112, null);
                            if (z4) {
                                strB = this.b + "%40" + strB;
                            }
                            this.b = strB;
                            if (iJ != iK) {
                                i2 = iK;
                                this.c = _UrlKt.b(str, iJ + 1, i2, " \"':;<=>@[]^`{}|/\\?#", true, false, false, false, 112, null);
                                z3 = z;
                            } else {
                                i2 = iK;
                            }
                            str3 = str;
                            i = i2;
                            z4 = z;
                        }
                        i3 = i + 1;
                        z2 = z;
                        c3 = '#';
                        c2 = '?';
                    }
                }
                int iO = o(str3, i3, iK);
                int i4 = iO + 1;
                if (i4 < iK) {
                    this.d = _HostnamesCommonKt.k(_UrlKt.g(str3, i3, iO, false, 4, null));
                    int iK2 = k(str3, i4, iK);
                    this.e = iK2;
                    if (iK2 == -1) {
                        StringBuilder sb3 = new StringBuilder();
                        sb3.append("Invalid URL port: \"");
                        String strSubstring2 = str3.substring(i4, iK);
                        Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
                        sb3.append(strSubstring2);
                        sb3.append('\"');
                        throw new IllegalArgumentException(sb3.toString().toString());
                    }
                } else {
                    this.d = _HostnamesCommonKt.k(_UrlKt.g(str3, i3, iO, false, 4, null));
                    Companion companion = HttpUrl.j;
                    String str4 = this.a;
                    Intrinsics.checkNotNull(str4);
                    this.e = companion.b(str4);
                }
                if (this.d == null) {
                    StringBuilder sb4 = new StringBuilder();
                    sb4.append("Invalid URL host: \"");
                    String strSubstring3 = str3.substring(i3, iO);
                    Intrinsics.checkNotNullExpressionValue(strSubstring3, "substring(...)");
                    sb4.append(strSubstring3);
                    sb4.append('\"');
                    throw new IllegalArgumentException(sb4.toString().toString());
                }
                iR = iK;
            } else {
                this.b = httpUrl.f();
                this.c = httpUrl.b();
                this.d = httpUrl.g();
                this.e = httpUrl.l();
                this.f.clear();
                this.f.addAll(httpUrl.d());
                if (iR == iT || str3.charAt(iR) == '#') {
                    e(httpUrl.e());
                }
            }
            int iK3 = _UtilCommonKt.k(str3, "?#", iR, iT);
            s(str3, iR, iK3);
            if (iK3 >= iT || str3.charAt(iK3) != '?') {
                c = '#';
            } else {
                c = '#';
                int iJ2 = _UtilCommonKt.j(str3, '#', iK3, iT);
                this.g = D(_UrlKt.b(str3, iK3 + 1, iJ2, " \"'<>#", true, false, true, false, 80, null));
                iK3 = iJ2;
            }
            if (iK3 < iT && str3.charAt(iK3) == c) {
                this.h = _UrlKt.b(str3, iK3 + 1, iT, StringUtils.EMPTY, true, false, false, true, 48, null);
            }
            return this;
        }

        public final Builder l(String str) {
            Intrinsics.checkNotNullParameter(str, "password");
            this.c = _UrlKt.b(str, 0, 0, " \"':;<=>@[]^`{}|/\\?#", false, false, false, false, 123, null);
            return this;
        }

        public final Builder n(int i) {
            if (1 <= i && i < 65536) {
                this.e = i;
                return this;
            }
            throw new IllegalArgumentException(("unexpected port: " + i).toString());
        }

        public final Builder q(String str) {
            String strB;
            this.g = (str == null || (strB = _UrlKt.b(str, 0, 0, " \"'<>#", false, false, true, false, 91, null)) == null) ? null : D(strB);
            return this;
        }

        public final Builder r() {
            String str = this.d;
            this.d = str != null ? new Regex("[\"<>^`{|}]").replace(str, StringUtils.EMPTY) : null;
            int size = this.f.size();
            for (int i = 0; i < size; i++) {
                List list = this.f;
                list.set(i, _UrlKt.b((String) list.get(i), 0, 0, "[]", true, true, false, false, 99, null));
            }
            List list2 = this.g;
            if (list2 != null) {
                int size2 = list2.size();
                for (int i2 = 0; i2 < size2; i2++) {
                    String str2 = (String) list2.get(i2);
                    list2.set(i2, str2 != null ? _UrlKt.b(str2, 0, 0, "\\^`{|}", true, true, true, false, 67, null) : null);
                }
            }
            String str3 = this.h;
            this.h = str3 != null ? _UrlKt.b(str3, 0, 0, " \"#<>\\^`{|}", true, true, false, true, 35, null) : null;
            return this;
        }

        public final Builder t(String str) {
            Intrinsics.checkNotNullParameter(str, "scheme");
            if (StringsKt.equals(str, "http", true)) {
                this.a = "http";
                return this;
            }
            if (StringsKt.equals(str, "https", true)) {
                this.a = "https";
                return this;
            }
            throw new IllegalArgumentException("unexpected scheme: " + str);
        }

        /* JADX WARN: Removed duplicated region for block: B:29:0x0085  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public java.lang.String toString() {
            /*
                r6 = this;
                java.lang.StringBuilder r0 = new java.lang.StringBuilder
                r0.<init>()
                java.lang.String r1 = r6.a
                if (r1 == 0) goto L12
                r0.append(r1)
                java.lang.String r1 = "://"
                r0.append(r1)
                goto L17
            L12:
                java.lang.String r1 = "//"
                r0.append(r1)
            L17:
                java.lang.String r1 = r6.b
                int r1 = r1.length()
                r2 = 58
                if (r1 <= 0) goto L22
                goto L2a
            L22:
                java.lang.String r1 = r6.c
                int r1 = r1.length()
                if (r1 <= 0) goto L44
            L2a:
                java.lang.String r1 = r6.b
                r0.append(r1)
                java.lang.String r1 = r6.c
                int r1 = r1.length()
                if (r1 <= 0) goto L3f
                r0.append(r2)
                java.lang.String r1 = r6.c
                r0.append(r1)
            L3f:
                r1 = 64
                r0.append(r1)
            L44:
                java.lang.String r1 = r6.d
                if (r1 == 0) goto L69
                kotlin.jvm.internal.Intrinsics.checkNotNull(r1)
                r3 = 2
                r4 = 0
                r5 = 0
                boolean r1 = kotlin.text.StringsKt.contains$default(r1, r2, r5, r3, r4)
                if (r1 == 0) goto L64
                r1 = 91
                r0.append(r1)
                java.lang.String r1 = r6.d
                r0.append(r1)
                r1 = 93
                r0.append(r1)
                goto L69
            L64:
                java.lang.String r1 = r6.d
                r0.append(r1)
            L69:
                int r1 = r6.e
                r3 = -1
                if (r1 != r3) goto L72
                java.lang.String r1 = r6.a
                if (r1 == 0) goto L8b
            L72:
                int r1 = r6.d()
                java.lang.String r3 = r6.a
                if (r3 == 0) goto L85
                okhttp3.HttpUrl$Companion r4 = okhttp3.HttpUrl.j
                kotlin.jvm.internal.Intrinsics.checkNotNull(r3)
                int r3 = r4.b(r3)
                if (r1 == r3) goto L8b
            L85:
                r0.append(r2)
                r0.append(r1)
            L8b:
                java.util.List r1 = r6.f
                r6.C(r1, r0)
                java.util.List r1 = r6.g
                if (r1 == 0) goto La3
                r1 = 63
                r0.append(r1)
                okhttp3.HttpUrl$Companion r1 = okhttp3.HttpUrl.j
                java.util.List r2 = r6.g
                kotlin.jvm.internal.Intrinsics.checkNotNull(r2)
                okhttp3.HttpUrl.Companion.a(r1, r2, r0)
            La3:
                java.lang.String r1 = r6.h
                if (r1 == 0) goto Lb1
                r1 = 35
                r0.append(r1)
                java.lang.String r6 = r6.h
                r0.append(r6)
            Lb1:
                java.lang.String r6 = r0.toString()
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: okhttp3.HttpUrl.Builder.toString():java.lang.String");
        }

        public final void v(String str) {
            this.h = str;
        }

        public final void w(String str) {
            Intrinsics.checkNotNullParameter(str, "<set-?>");
            this.c = str;
        }

        public final void x(String str) {
            Intrinsics.checkNotNullParameter(str, "<set-?>");
            this.b = str;
        }

        public final void y(String str) {
            this.d = str;
        }

        public final void z(int i) {
            this.e = i;
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J'\u0010\n\u001a\u00020\t*\n\u0012\u0006\u0012\u0004\u0018\u00010\u00050\u00042\n\u0010\b\u001a\u00060\u0006j\u0002`\u0007H\u0002¢\u0006\u0004\b\n\u0010\u000bJ\u0017\u0010\u000e\u001a\u00020\r2\u0006\u0010\f\u001a\u00020\u0005H\u0007¢\u0006\u0004\b\u000e\u0010\u000fJ\u0013\u0010\u0011\u001a\u00020\u0010*\u00020\u0005H\u0007¢\u0006\u0004\b\u0011\u0010\u0012J\u0015\u0010\u0013\u001a\u0004\u0018\u00010\u0010*\u00020\u0005H\u0007¢\u0006\u0004\b\u0013\u0010\u0012¨\u0006\u0014"}, d2 = {"Lokhttp3/HttpUrl$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, StringUtils.EMPTY, "Ljava/lang/StringBuilder;", "Lkotlin/text/StringBuilder;", "out", StringUtils.EMPTY, "e", "(Ljava/util/List;Ljava/lang/StringBuilder;)V", "scheme", StringUtils.EMPTY, "b", "(Ljava/lang/String;)I", "Lokhttp3/HttpUrl;", "c", "(Ljava/lang/String;)Lokhttp3/HttpUrl;", "d", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private final void e(List list, StringBuilder sb) {
            IntProgression intProgressionStep = RangesKt.step(RangesKt.until(0, list.size()), 2);
            int first = intProgressionStep.getFirst();
            int last = intProgressionStep.getLast();
            int step = intProgressionStep.getStep();
            if ((step <= 0 || first > last) && (step >= 0 || last > first)) {
                return;
            }
            while (true) {
                String str = (String) list.get(first);
                String str2 = (String) list.get(first + 1);
                if (first > 0) {
                    sb.append(Typography.amp);
                }
                sb.append(str);
                if (str2 != null) {
                    sb.append('=');
                    sb.append(str2);
                }
                if (first == last) {
                    return;
                } else {
                    first += step;
                }
            }
        }

        public final int b(String str) {
            Intrinsics.checkNotNullParameter(str, ap.a(722414394));
            if (Intrinsics.areEqual(str, ap.a(737248219))) {
                return 80;
            }
            return Intrinsics.areEqual(str, ap.a(578552736)) ? 443 : -1;
        }

        public final HttpUrl c(String str) {
            Intrinsics.checkNotNullParameter(str, "<this>");
            return new Builder().j(null, str).c();
        }

        public final HttpUrl d(String str) {
            Intrinsics.checkNotNullParameter(str, "<this>");
            try {
                return c(str);
            } catch (IllegalArgumentException unused) {
                return null;
            }
        }

        private Companion() {
        }
    }

    public /* synthetic */ HttpUrl(String str, String str2, String str3, String str4, int i, List list, List list2, String str5, String str6, DefaultConstructorMarker defaultConstructorMarker) {
        this(str, str2, str3, str4, i, list, list2, str5, str6);
    }

    public static final HttpUrl k(String str) {
        return j.d(str);
    }

    public final String a() {
        if (this.h == null) {
            return null;
        }
        String strSubstring = this.i.substring(StringsKt.indexOf$default((CharSequence) this.i, '#', 0, false, 6, (Object) null) + 1);
        Intrinsics.checkNotNullExpressionValue(strSubstring, ap.a(1044854969));
        return strSubstring;
    }

    public final String b() {
        if (this.c.length() == 0) {
            return StringUtils.EMPTY;
        }
        String strSubstring = this.i.substring(StringsKt.indexOf$default((CharSequence) this.i, AbstractJsonLexerKt.COLON, this.a.length() + 3, false, 4, (Object) null) + 1, StringsKt.indexOf$default((CharSequence) this.i, '@', 0, false, 6, (Object) null));
        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        return strSubstring;
    }

    public final String c() {
        int iIndexOf$default = StringsKt.indexOf$default((CharSequence) this.i, '/', this.a.length() + 3, false, 4, (Object) null);
        String str = this.i;
        String strSubstring = this.i.substring(iIndexOf$default, _UtilCommonKt.k(str, "?#", iIndexOf$default, str.length()));
        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        return strSubstring;
    }

    public final List d() {
        int iIndexOf$default = StringsKt.indexOf$default((CharSequence) this.i, '/', this.a.length() + 3, false, 4, (Object) null);
        String str = this.i;
        int iK = _UtilCommonKt.k(str, "?#", iIndexOf$default, str.length());
        ArrayList arrayList = new ArrayList();
        while (iIndexOf$default < iK) {
            int i = iIndexOf$default + 1;
            int iJ = _UtilCommonKt.j(this.i, '/', i, iK);
            String strSubstring = this.i.substring(i, iJ);
            Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
            arrayList.add(strSubstring);
            iIndexOf$default = iJ;
        }
        return arrayList;
    }

    public final String e() {
        if (this.g == null) {
            return null;
        }
        int iIndexOf$default = StringsKt.indexOf$default((CharSequence) this.i, '?', 0, false, 6, (Object) null) + 1;
        String str = this.i;
        String strSubstring = this.i.substring(iIndexOf$default, _UtilCommonKt.j(str, '#', iIndexOf$default, str.length()));
        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        return strSubstring;
    }

    public boolean equals(Object obj) {
        return (obj instanceof HttpUrl) && Intrinsics.areEqual(((HttpUrl) obj).i, this.i);
    }

    public final String f() {
        if (this.b.length() == 0) {
            return StringUtils.EMPTY;
        }
        int length = this.a.length() + 3;
        String str = this.i;
        String strSubstring = this.i.substring(length, _UtilCommonKt.k(str, ":@", length, str.length()));
        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        return strSubstring;
    }

    public final String g() {
        return this.d;
    }

    public final boolean h() {
        return Intrinsics.areEqual(this.a, "https");
    }

    public int hashCode() {
        return this.i.hashCode();
    }

    public final Builder i() {
        Builder builder = new Builder();
        builder.A(this.a);
        builder.x(f());
        builder.w(b());
        builder.y(this.d);
        builder.z(this.e != j.b(this.a) ? this.e : -1);
        builder.f().clear();
        builder.f().addAll(d());
        builder.e(e());
        builder.v(a());
        return builder;
    }

    public final Builder j(String str) {
        Intrinsics.checkNotNullParameter(str, "link");
        try {
            return new Builder().j(this, str);
        } catch (IllegalArgumentException unused) {
            return null;
        }
    }

    public final int l() {
        return this.e;
    }

    public final String m() {
        if (this.g == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        j.e(this.g, sb);
        return sb.toString();
    }

    public final String n(int i) {
        List list = this.g;
        if (list == null) {
            throw new IndexOutOfBoundsException();
        }
        Object obj = list.get(i * 2);
        Intrinsics.checkNotNull(obj);
        return (String) obj;
    }

    public final String o(int i) {
        List list = this.g;
        if (list != null) {
            return (String) list.get((i * 2) + 1);
        }
        throw new IndexOutOfBoundsException();
    }

    public final int p() {
        List list = this.g;
        if (list != null) {
            return list.size() / 2;
        }
        return 0;
    }

    public final String q() {
        Builder builderJ = j("/...");
        Intrinsics.checkNotNull(builderJ);
        return builderJ.E(StringUtils.EMPTY).l(StringUtils.EMPTY).c().toString();
    }

    public final HttpUrl r(String str) {
        Intrinsics.checkNotNullParameter(str, "link");
        Builder builderJ = j(str);
        if (builderJ != null) {
            return builderJ.c();
        }
        return null;
    }

    public final String s() {
        return this.a;
    }

    public final URI t() {
        String string = i().r().toString();
        try {
            return new URI(string);
        } catch (URISyntaxException e) {
            try {
                URI uriCreate = URI.create(new Regex("[\\u0000-\\u001F\\u007F-\\u009F\\p{javaWhitespace}]").replace(string, StringUtils.EMPTY));
                Intrinsics.checkNotNull(uriCreate);
                return uriCreate;
            } catch (Exception unused) {
                throw new RuntimeException(e);
            }
        }
    }

    public String toString() {
        return this.i;
    }

    public final URL u() {
        try {
            return new URL(this.i);
        } catch (MalformedURLException e) {
            throw new RuntimeException(e);
        }
    }

    private HttpUrl(String str, String str2, String str3, String str4, int i, List list, List list2, String str5, String str6) {
        this.a = str;
        this.b = str2;
        this.c = str3;
        this.d = str4;
        this.e = i;
        this.f = list;
        this.g = list2;
        this.h = str5;
        this.i = str6;
    }
}