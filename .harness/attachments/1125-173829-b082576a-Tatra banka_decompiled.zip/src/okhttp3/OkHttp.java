package okhttp3;

import h.ap;
import kotlin.Metadata;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0005\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u001a\u0010\b\u001a\u00020\u00048\u0006X\u0087D¢\u0006\f\n\u0004\b\u0005\u0010\u0006\u0012\u0004\b\u0007\u0010\u0003¨\u0006\t"}, d2 = {"Lokhttp3/OkHttp;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "b", "Ljava/lang/String;", "getVERSION$annotations", "VERSION", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class OkHttp {
    public static final OkHttp a = new OkHttp();
    public static final String b = ap.a(2038462215);

    private OkHttp() {
    }
}