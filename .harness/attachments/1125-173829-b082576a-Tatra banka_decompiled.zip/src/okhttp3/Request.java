package okhttp3;

import h.ap;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.JvmClassMappingKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.jvm.internal.TypeIntrinsics;
import kotlin.reflect.KClass;
import kotlin.reflect.KClasses;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okhttp3.Headers;
import okhttp3.HttpUrl;
import okhttp3.internal._UtilCommonKt;
import okhttp3.internal.http.HttpMethod;
import org.apache.tika.metadata.OfficeOpenXMLExtended;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000R\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010 \n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0018\n\u0002\u0010$\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0007\u0018\u00002\u00020\u0001:\u0001<B\u0011\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005B1\b\u0016\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\b\b\u0002\u0010\t\u001a\u00020\b\u0012\b\b\u0002\u0010\u000b\u001a\u00020\n\u0012\n\b\u0002\u0010\r\u001a\u0004\u0018\u00010\f¢\u0006\u0004\b\u0004\u0010\u000eJ\u0017\u0010\u0010\u001a\u0004\u0018\u00010\n2\u0006\u0010\u000f\u001a\u00020\n¢\u0006\u0004\b\u0010\u0010\u0011J\u001b\u0010\u0013\u001a\b\u0012\u0004\u0012\u00020\n0\u00122\u0006\u0010\u000f\u001a\u00020\n¢\u0006\u0004\b\u0013\u0010\u0014J'\u0010\u0018\u001a\u0004\u0018\u00018\u0000\"\b\b\u0000\u0010\u0015*\u00020\u00012\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00028\u00000\u0016¢\u0006\u0004\b\u0018\u0010\u0019J\u000f\u0010\u001a\u001a\u0004\u0018\u00010\u0001¢\u0006\u0004\b\u001a\u0010\u001bJ\r\u0010\u001c\u001a\u00020\u0002¢\u0006\u0004\b\u001c\u0010\u001dJ\u000f\u0010\u001e\u001a\u00020\nH\u0016¢\u0006\u0004\b\u001e\u0010\u001fR\u0017\u0010\u0007\u001a\u00020\u00068G¢\u0006\f\n\u0004\b \u0010!\u001a\u0004\b\"\u0010#R\u0017\u0010\u000b\u001a\u00020\n8G¢\u0006\f\n\u0004\b$\u0010%\u001a\u0004\b&\u0010\u001fR\u0017\u0010\t\u001a\u00020\b8G¢\u0006\f\n\u0004\b'\u0010(\u001a\u0004\b)\u0010*R\u0019\u0010\r\u001a\u0004\u0018\u00010\f8G¢\u0006\f\n\u0004\b+\u0010,\u001a\u0004\b \u0010-R\u0019\u0010.\u001a\u0004\u0018\u00010\u00068G¢\u0006\f\n\u0004\b\u0010\u0010!\u001a\u0004\b'\u0010#R*\u00102\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030\u0016\u0012\u0004\u0012\u00020\u00010/8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u0013\u00100\u001a\u0004\b+\u00101R\u0018\u00105\u001a\u0004\u0018\u0001038\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b)\u00104R\u0011\u00109\u001a\u0002068F¢\u0006\u0006\u001a\u0004\b7\u00108R\u0011\u0010;\u001a\u0002038G¢\u0006\u0006\u001a\u0004\b$\u0010:¨\u0006="}, d2 = {"Lokhttp3/Request;", StringUtils.EMPTY, "Lokhttp3/Request$Builder;", "builder", "<init>", "(Lokhttp3/Request$Builder;)V", "Lokhttp3/HttpUrl;", "url", "Lokhttp3/Headers;", "headers", StringUtils.EMPTY, "method", "Lokhttp3/RequestBody;", "body", "(Lokhttp3/HttpUrl;Lokhttp3/Headers;Ljava/lang/String;Lokhttp3/RequestBody;)V", "name", "e", "(Ljava/lang/String;)Ljava/lang/String;", StringUtils.EMPTY, "f", "(Ljava/lang/String;)Ljava/util/List;", "T", "Lkotlin/reflect/KClass;", "type", "l", "(Lkotlin/reflect/KClass;)Ljava/lang/Object;", "k", "()Ljava/lang/Object;", "j", "()Lokhttp3/Request$Builder;", "toString", "()Ljava/lang/String;", "a", "Lokhttp3/HttpUrl;", "m", "()Lokhttp3/HttpUrl;", "b", "Ljava/lang/String;", "i", "c", "Lokhttp3/Headers;", "g", "()Lokhttp3/Headers;", "d", "Lokhttp3/RequestBody;", "()Lokhttp3/RequestBody;", "cacheUrlOverride", StringUtils.EMPTY, "Ljava/util/Map;", "()Ljava/util/Map;", "tags", "Lokhttp3/CacheControl;", "Lokhttp3/CacheControl;", "lazyCacheControl", StringUtils.EMPTY, "h", "()Z", "isHttps", "()Lokhttp3/CacheControl;", "cacheControl", "Builder", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nRequest.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Request.kt\nokhttp3/Request\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,427:1\n89#1:429\n1#2:428\n1878#3,3:430\n*S KotlinDebug\n*F\n+ 1 Request.kt\nokhttp3/Request\n*L\n104#1:429\n177#1:430,3\n*E\n"})
public final class Request {
    private final HttpUrl a;
    private final String b;
    private final Headers c;
    private final RequestBody d;
    private final HttpUrl e;
    private final Map f;
    private CacheControl g;

    public Request(Builder builder) {
        Intrinsics.checkNotNullParameter(builder, "builder");
        HttpUrl httpUrlM = builder.m();
        if (httpUrlM == null) {
            throw new IllegalStateException("url == null");
        }
        this.a = httpUrlM;
        this.b = builder.k();
        this.c = builder.j().e();
        this.d = builder.h();
        this.e = builder.i();
        this.f = MapsKt.toMap(builder.l());
    }

    public final RequestBody a() {
        return this.d;
    }

    public final CacheControl b() {
        CacheControl cacheControl = this.g;
        if (cacheControl != null) {
            return cacheControl;
        }
        CacheControl cacheControlA = CacheControl.n.a(this.c);
        this.g = cacheControlA;
        return cacheControlA;
    }

    public final HttpUrl c() {
        return this.e;
    }

    public final Map d() {
        return this.f;
    }

    public final String e(String str) {
        Intrinsics.checkNotNullParameter(str, "name");
        return this.c.a(str);
    }

    public final List f(String str) {
        Intrinsics.checkNotNullParameter(str, "name");
        return this.c.l(str);
    }

    public final Headers g() {
        return this.c;
    }

    public final boolean h() {
        return this.a.h();
    }

    public final String i() {
        return this.b;
    }

    public final Builder j() {
        return new Builder(this);
    }

    public final Object k() {
        return l(Reflection.getOrCreateKotlinClass(Object.class));
    }

    public final Object l(KClass kClass) {
        Intrinsics.checkNotNullParameter(kClass, "type");
        return JvmClassMappingKt.getJavaClass(kClass).cast(this.f.get(kClass));
    }

    public final HttpUrl m() {
        return this.a;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(32);
        sb.append("Request{method=");
        sb.append(this.b);
        sb.append(", url=");
        sb.append(this.a);
        if (this.c.size() != 0) {
            sb.append(", headers=[");
            int i = 0;
            for (Pair<? extends String, ? extends String> pair : this.c) {
                int i2 = i + 1;
                if (i < 0) {
                    CollectionsKt.throwIndexOverflow();
                }
                Pair<? extends String, ? extends String> pair2 = pair;
                String str = (String) pair2.component1();
                String str2 = (String) pair2.component2();
                if (i > 0) {
                    sb.append(", ");
                }
                sb.append(str);
                sb.append(AbstractJsonLexerKt.COLON);
                if (_UtilCommonKt.y(str)) {
                    str2 = "██";
                }
                sb.append(str2);
                i = i2;
            }
            sb.append(AbstractJsonLexerKt.END_LIST);
        }
        if (!this.f.isEmpty()) {
            sb.append(", tags=");
            sb.append(this.f);
        }
        sb.append(AbstractJsonLexerKt.END_OBJ);
        return sb.toString();
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000d\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0010\n\u0002\u0018\u0002\n\u0002\b\f\n\u0002\u0010$\n\u0002\b\u0007\b\u0016\u0018\u00002\u00020\u0001B\t\b\u0016¢\u0006\u0004\b\u0002\u0010\u0003B\u0011\b\u0010\u0012\u0006\u0010\u0005\u001a\u00020\u0004¢\u0006\u0004\b\u0002\u0010\u0006J\u0017\u0010\t\u001a\u00020\u00072\u0006\u0010\b\u001a\u00020\u0007H\u0002¢\u0006\u0004\b\t\u0010\nJ\u0017\u0010\f\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\f\u0010\rJ\u0017\u0010\u000e\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u0017\u0010\u0011\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0011\u0010\u0012J\u001f\u0010\u0015\u001a\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0015\u0010\u0016J\u001f\u0010\u0017\u001a\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0017\u0010\u0016J\u0017\u0010\u0018\u001a\u00020\u00002\u0006\u0010\u0013\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0018\u0010\u000fJ\u0017\u0010\u001b\u001a\u00020\u00002\u0006\u0010\u001a\u001a\u00020\u0019H\u0016¢\u0006\u0004\b\u001b\u0010\u001cJ\u0017\u0010\u001f\u001a\u00020\u00002\u0006\u0010\u001e\u001a\u00020\u001dH\u0016¢\u0006\u0004\b\u001f\u0010 J\u000f\u0010!\u001a\u00020\u0000H\u0016¢\u0006\u0004\b!\u0010\"J\u0017\u0010%\u001a\u00020\u00002\u0006\u0010$\u001a\u00020#H\u0016¢\u0006\u0004\b%\u0010&J\u001b\u0010'\u001a\u00020\u00002\n\b\u0002\u0010$\u001a\u0004\u0018\u00010#H\u0017¢\u0006\u0004\b'\u0010&J\u0017\u0010(\u001a\u00020\u00002\u0006\u0010$\u001a\u00020#H\u0016¢\u0006\u0004\b(\u0010&J!\u0010*\u001a\u00020\u00002\u0006\u0010)\u001a\u00020\u00072\b\u0010$\u001a\u0004\u0018\u00010#H\u0016¢\u0006\u0004\b*\u0010+J/\u00100\u001a\u00020\u0000\"\b\b\u0000\u0010,*\u00020\u00012\f\u0010.\u001a\b\u0012\u0004\u0012\u00028\u00000-2\b\u0010/\u001a\u0004\u0018\u00018\u0000¢\u0006\u0004\b0\u00101J/\u00103\u001a\u00020\u0000\"\u0004\b\u0000\u0010,2\u000e\u0010.\u001a\n\u0012\u0006\b\u0000\u0012\u00028\u0000022\b\u0010/\u001a\u0004\u0018\u00018\u0000H\u0016¢\u0006\u0004\b3\u00104J\u0017\u00106\u001a\u00020\u00002\b\u00105\u001a\u0004\u0018\u00010\u000b¢\u0006\u0004\b6\u0010\rJ\u000f\u00107\u001a\u00020\u0004H\u0016¢\u0006\u0004\b7\u00108R$\u0010\b\u001a\u0004\u0018\u00010\u000b8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u0017\u00109\u001a\u0004\b:\u0010;\"\u0004\b<\u0010=R\"\u0010)\u001a\u00020\u00078\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b7\u0010>\u001a\u0004\b?\u0010@\"\u0004\bA\u0010BR\"\u0010\u001a\u001a\u00020C8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\u001f\u0010D\u001a\u0004\bE\u0010F\"\u0004\bG\u0010HR$\u0010$\u001a\u0004\u0018\u00010#8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b6\u0010I\u001a\u0004\bJ\u0010K\"\u0004\bL\u0010MR$\u00105\u001a\u0004\u0018\u00010\u000b8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b\t\u00109\u001a\u0004\bN\u0010;\"\u0004\bO\u0010=R2\u0010V\u001a\u0012\u0012\b\u0012\u0006\u0012\u0002\b\u00030-\u0012\u0004\u0012\u00020\u00010P8\u0000@\u0000X\u0080\u000e¢\u0006\u0012\n\u0004\b'\u0010Q\u001a\u0004\bR\u0010S\"\u0004\bT\u0010U¨\u0006W"}, d2 = {"Lokhttp3/Request$Builder;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/Request;", "request", "(Lokhttp3/Request;)V", StringUtils.EMPTY, "url", "e", "(Ljava/lang/String;)Ljava/lang/String;", "Lokhttp3/HttpUrl;", "x", "(Lokhttp3/HttpUrl;)Lokhttp3/Request$Builder;", "v", "(Ljava/lang/String;)Lokhttp3/Request$Builder;", "Ljava/net/URL;", OfficeOpenXMLExtended.WORD_PROCESSING_PREFIX, "(Ljava/net/URL;)Lokhttp3/Request$Builder;", "name", MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "n", "(Ljava/lang/String;Ljava/lang/String;)Lokhttp3/Request$Builder;", "a", "s", "Lokhttp3/Headers;", "headers", "o", "(Lokhttp3/Headers;)Lokhttp3/Request$Builder;", "Lokhttp3/CacheControl;", "cacheControl", "c", "(Lokhttp3/CacheControl;)Lokhttp3/Request$Builder;", "g", "()Lokhttp3/Request$Builder;", "Lokhttp3/RequestBody;", "body", "q", "(Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;", "f", "r", "method", "p", "(Ljava/lang/String;Lokhttp3/RequestBody;)Lokhttp3/Request$Builder;", "T", "Lkotlin/reflect/KClass;", "type", "tag", "u", "(Lkotlin/reflect/KClass;Ljava/lang/Object;)Lokhttp3/Request$Builder;", "Ljava/lang/Class;", "t", "(Ljava/lang/Class;Ljava/lang/Object;)Lokhttp3/Request$Builder;", "cacheUrlOverride", "d", "b", "()Lokhttp3/Request;", "Lokhttp3/HttpUrl;", "m", "()Lokhttp3/HttpUrl;", "setUrl$okhttp", "(Lokhttp3/HttpUrl;)V", "Ljava/lang/String;", "k", "()Ljava/lang/String;", "setMethod$okhttp", "(Ljava/lang/String;)V", "Lokhttp3/Headers$Builder;", "Lokhttp3/Headers$Builder;", "j", "()Lokhttp3/Headers$Builder;", "setHeaders$okhttp", "(Lokhttp3/Headers$Builder;)V", "Lokhttp3/RequestBody;", "h", "()Lokhttp3/RequestBody;", "setBody$okhttp", "(Lokhttp3/RequestBody;)V", "i", "setCacheUrlOverride$okhttp", StringUtils.EMPTY, "Ljava/util/Map;", "l", "()Ljava/util/Map;", "setTags$okhttp", "(Ljava/util/Map;)V", "tags", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nRequest.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Request.kt\nokhttp3/Request$Builder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,427:1\n1#2:428\n*E\n"})
    public static class Builder {
        private HttpUrl a;
        private String b;
        private Headers.Builder c;
        private RequestBody d;
        private HttpUrl e;
        private Map f;

        public Builder() {
            this.f = MapsKt.emptyMap();
            this.b = ap.a(1031757723);
            this.c = new Headers.Builder();
        }

        private final String e(String str) {
            if (StringsKt.startsWith(str, "ws:", true)) {
                StringBuilder sb = new StringBuilder();
                sb.append("http:");
                String strSubstring = str.substring(3);
                Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
                sb.append(strSubstring);
                return sb.toString();
            }
            if (!StringsKt.startsWith(str, "wss:", true)) {
                return str;
            }
            StringBuilder sb2 = new StringBuilder();
            sb2.append("https:");
            String strSubstring2 = str.substring(4);
            Intrinsics.checkNotNullExpressionValue(strSubstring2, "substring(...)");
            sb2.append(strSubstring2);
            return sb2.toString();
        }

        public Builder a(String str, String str2) {
            Intrinsics.checkNotNullParameter(str, "name");
            Intrinsics.checkNotNullParameter(str2, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
            this.c.a(str, str2);
            return this;
        }

        public Request b() {
            return new Request(this);
        }

        public Builder c(CacheControl cacheControl) {
            Intrinsics.checkNotNullParameter(cacheControl, "cacheControl");
            String string = cacheControl.toString();
            return string.length() == 0 ? s("Cache-Control") : n("Cache-Control", string);
        }

        public final Builder d(HttpUrl httpUrl) {
            this.e = httpUrl;
            return this;
        }

        public Builder f(RequestBody requestBody) {
            return p("DELETE", requestBody);
        }

        public Builder g() {
            return p("GET", null);
        }

        public final RequestBody h() {
            return this.d;
        }

        public final HttpUrl i() {
            return this.e;
        }

        public final Headers.Builder j() {
            return this.c;
        }

        public final String k() {
            return this.b;
        }

        public final Map l() {
            return this.f;
        }

        public final HttpUrl m() {
            return this.a;
        }

        public Builder n(String str, String str2) {
            Intrinsics.checkNotNullParameter(str, "name");
            Intrinsics.checkNotNullParameter(str2, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR);
            this.c.i(str, str2);
            return this;
        }

        public Builder o(Headers headers) {
            Intrinsics.checkNotNullParameter(headers, "headers");
            this.c = headers.f();
            return this;
        }

        public Builder p(String str, RequestBody requestBody) {
            Intrinsics.checkNotNullParameter(str, "method");
            if (str.length() <= 0) {
                throw new IllegalArgumentException("method.isEmpty() == true");
            }
            if (requestBody == null) {
                if (HttpMethod.e(str)) {
                    throw new IllegalArgumentException(("method " + str + " must have a request body.").toString());
                }
            } else if (!HttpMethod.b(str)) {
                throw new IllegalArgumentException(("method " + str + " must not have a request body.").toString());
            }
            this.b = str;
            this.d = requestBody;
            return this;
        }

        public Builder q(RequestBody requestBody) {
            Intrinsics.checkNotNullParameter(requestBody, "body");
            return p("POST", requestBody);
        }

        public Builder r(RequestBody requestBody) {
            Intrinsics.checkNotNullParameter(requestBody, "body");
            return p("PUT", requestBody);
        }

        public Builder s(String str) {
            Intrinsics.checkNotNullParameter(str, "name");
            this.c.h(str);
            return this;
        }

        public Builder t(Class cls, Object obj) {
            Intrinsics.checkNotNullParameter(cls, "type");
            return u(JvmClassMappingKt.getKotlinClass(cls), obj);
        }

        public final Builder u(KClass kClass, Object obj) {
            Map mapAsMutableMap;
            Intrinsics.checkNotNullParameter(kClass, "type");
            if (obj == null) {
                if (!this.f.isEmpty()) {
                    Map map = this.f;
                    Intrinsics.checkNotNull(map, "null cannot be cast to non-null type kotlin.collections.MutableMap<kotlin.reflect.KClass<*>, kotlin.Any>");
                    TypeIntrinsics.asMutableMap(map).remove(kClass);
                }
                return this;
            }
            if (this.f.isEmpty()) {
                mapAsMutableMap = new LinkedHashMap();
                this.f = mapAsMutableMap;
            } else {
                Map map2 = this.f;
                Intrinsics.checkNotNull(map2, "null cannot be cast to non-null type kotlin.collections.MutableMap<kotlin.reflect.KClass<*>, kotlin.Any>");
                mapAsMutableMap = TypeIntrinsics.asMutableMap(map2);
            }
            mapAsMutableMap.put(kClass, KClasses.cast(kClass, obj));
            return this;
        }

        public Builder v(String str) {
            Intrinsics.checkNotNullParameter(str, "url");
            return x(HttpUrl.j.c(e(str)));
        }

        public Builder w(URL url) {
            Intrinsics.checkNotNullParameter(url, "url");
            HttpUrl.Companion companion = HttpUrl.j;
            String string = url.toString();
            Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
            return x(companion.c(string));
        }

        public Builder x(HttpUrl httpUrl) {
            Intrinsics.checkNotNullParameter(httpUrl, "url");
            this.a = httpUrl;
            return this;
        }

        public Builder(Request request) {
            Intrinsics.checkNotNullParameter(request, "request");
            this.f = MapsKt.emptyMap();
            this.a = request.m();
            this.b = request.i();
            this.d = request.a();
            this.f = request.d().isEmpty() ? MapsKt.emptyMap() : MapsKt.toMutableMap(request.d());
            this.c = request.g().f();
            this.e = request.c();
        }
    }

    public /* synthetic */ Request(HttpUrl httpUrl, Headers headers, String str, RequestBody requestBody, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this(httpUrl, (i & 2) != 0 ? Headers.b.b(new String[0]) : headers, (i & 4) != 0 ? "\u0000" : str, (i & 8) != 0 ? null : requestBody);
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public Request(HttpUrl httpUrl, Headers headers, String str, RequestBody requestBody) {
        Intrinsics.checkNotNullParameter(httpUrl, ap.a(1773586246));
        Intrinsics.checkNotNullParameter(headers, ap.a(2112215977));
        Intrinsics.checkNotNullParameter(str, ap.a(2070515318));
        Builder builderO = new Builder().x(httpUrl).o(headers);
        if (Intrinsics.areEqual(str, "\u0000")) {
            if (requestBody != null) {
                str = ap.a(2140715762);
            } else {
                str = ap.a(1446844508);
            }
        }
        this(builderO.p(str, requestBody));
    }
}