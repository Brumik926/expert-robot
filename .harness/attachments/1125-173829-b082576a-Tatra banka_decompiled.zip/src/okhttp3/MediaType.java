package okhttp3;

import h.ap;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Locale;
import kotlin.Metadata;
import kotlin.internal.ProgressionUtilKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.MatchGroup;
import kotlin.text.MatchResult;
import kotlin.text.Regex;
import kotlin.text.StringsKt;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u0011\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\r\u0018\u0000 \"2\u00020\u0001:\u0001#B/\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0002\u0012\f\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u001d\u0010\f\u001a\u0004\u0018\u00010\n2\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\nH\u0007¢\u0006\u0004\b\f\u0010\rJ\u0017\u0010\u000f\u001a\u0004\u0018\u00010\u00022\u0006\u0010\u000e\u001a\u00020\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u000f\u0010\u0011\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0011\u0010\u0012J\u001a\u0010\u0015\u001a\u00020\u00142\b\u0010\u0013\u001a\u0004\u0018\u00010\u0001H\u0096\u0002¢\u0006\u0004\b\u0015\u0010\u0016J\u000f\u0010\u0018\u001a\u00020\u0017H\u0016¢\u0006\u0004\b\u0018\u0010\u0019R\u001a\u0010\u0003\u001a\u00020\u00028\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u001a\u0010\u001b\u001a\u0004\b\u001c\u0010\u0012R\u0017\u0010\u0004\u001a\u00020\u00028G¢\u0006\f\n\u0004\b\u001d\u0010\u001b\u001a\u0004\b\u001e\u0010\u0012R\u0017\u0010\u0005\u001a\u00020\u00028G¢\u0006\f\n\u0004\b\f\u0010\u001b\u001a\u0004\b\u001f\u0010\u0012R\u001a\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b \u0010!¨\u0006$"}, d2 = {"Lokhttp3/MediaType;", StringUtils.EMPTY, StringUtils.EMPTY, "mediaType", "type", "subtype", StringUtils.EMPTY, "parameterNamesAndValues", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)V", "Ljava/nio/charset/Charset;", "defaultValue", "c", "(Ljava/nio/charset/Charset;)Ljava/nio/charset/Charset;", "name", "f", "(Ljava/lang/String;)Ljava/lang/String;", "toString", "()Ljava/lang/String;", "other", StringUtils.EMPTY, "equals", "(Ljava/lang/Object;)Z", StringUtils.EMPTY, "hashCode", "()I", "a", "Ljava/lang/String;", "getMediaType$okhttp", "b", "i", "h", "d", "[Ljava/lang/String;", "e", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class MediaType {
    public static final Companion e = new Companion(null);
    private static final Regex f = new Regex(ap.a(314876196));
    private static final Regex g = new Regex(ap.a(1991782724));
    private final String a;
    private final String b;
    private final String c;
    private final String[] d;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0013\u0010\u0006\u001a\u00020\u0005*\u00020\u0004H\u0007¢\u0006\u0004\b\u0006\u0010\u0007J\u0015\u0010\b\u001a\u0004\u0018\u00010\u0005*\u00020\u0004H\u0007¢\u0006\u0004\b\b\u0010\u0007R\u0014\u0010\t\u001a\u00020\u00048\u0002X\u0082T¢\u0006\u0006\n\u0004\b\t\u0010\nR\u0014\u0010\u000b\u001a\u00020\u00048\u0002X\u0082T¢\u0006\u0006\n\u0004\b\u000b\u0010\nR\u0014\u0010\r\u001a\u00020\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\r\u0010\u000eR\u0014\u0010\u000f\u001a\u00020\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\u000e¨\u0006\u0010"}, d2 = {"Lokhttp3/MediaType$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "Lokhttp3/MediaType;", "a", "(Ljava/lang/String;)Lokhttp3/MediaType;", "b", "TOKEN", "Ljava/lang/String;", "QUOTED", "Lkotlin/text/Regex;", "TYPE_SUBTYPE", "Lkotlin/text/Regex;", "PARAMETER", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nMediaType.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MediaType.kt\nokhttp3/MediaType$Companion\n+ 2 ArraysJVM.kt\nkotlin/collections/ArraysKt__ArraysJVMKt\n*L\n1#1,183:1\n37#2:184\n36#2,3:185\n*S KotlinDebug\n*F\n+ 1 MediaType.kt\nokhttp3/MediaType$Companion\n*L\n145#1:184\n145#1:185,3\n*E\n"})
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final MediaType a(String str) {
            Intrinsics.checkNotNullParameter(str, ap.a(46765296));
            MatchResult matchResultMatchAt = MediaType.f.matchAt(str, 0);
            if (matchResultMatchAt == null) {
                throw new IllegalArgumentException(ap.a(678583274) + str + '\"');
            }
            String str2 = matchResultMatchAt.getGroupValues().get(1);
            Locale locale = Locale.ROOT;
            String lowerCase = str2.toLowerCase(locale);
            String strA = ap.a(308066951);
            Intrinsics.checkNotNullExpressionValue(lowerCase, strA);
            String lowerCase2 = matchResultMatchAt.getGroupValues().get(2).toLowerCase(locale);
            Intrinsics.checkNotNullExpressionValue(lowerCase2, strA);
            ArrayList arrayList = new ArrayList();
            int last = matchResultMatchAt.getRange().getLast();
            while (true) {
                int i = last + 1;
                if (i >= str.length()) {
                    return new MediaType(str, lowerCase, lowerCase2, (String[]) arrayList.toArray(new String[0]));
                }
                MatchResult matchResultMatchAt2 = MediaType.g.matchAt(str, i);
                String strA2 = ap.a(1929521683);
                if (matchResultMatchAt2 == null) {
                    StringBuilder sb = new StringBuilder();
                    sb.append(ap.a(587848906));
                    String strSubstring = str.substring(i);
                    Intrinsics.checkNotNullExpressionValue(strSubstring, strA2);
                    sb.append(strSubstring);
                    sb.append(ap.a(1386187961));
                    sb.append(str);
                    sb.append('\"');
                    throw new IllegalArgumentException(sb.toString().toString());
                }
                MatchGroup matchGroup = matchResultMatchAt2.getGroups().get(1);
                String value = matchGroup != null ? matchGroup.getValue() : null;
                if (value == null) {
                    last = matchResultMatchAt2.getRange().getLast();
                } else {
                    MatchGroup matchGroup2 = matchResultMatchAt2.getGroups().get(2);
                    String value2 = matchGroup2 != null ? matchGroup2.getValue() : null;
                    if (value2 == null) {
                        MatchGroup matchGroup3 = matchResultMatchAt2.getGroups().get(3);
                        Intrinsics.checkNotNull(matchGroup3);
                        value2 = matchGroup3.getValue();
                    } else if (StringsKt.startsWith$default((CharSequence) value2, '\'', false, 2, (Object) null) && StringsKt.endsWith$default((CharSequence) value2, '\'', false, 2, (Object) null) && value2.length() > 2) {
                        value2 = value2.substring(1, value2.length() - 1);
                        Intrinsics.checkNotNullExpressionValue(value2, strA2);
                    }
                    arrayList.add(value);
                    arrayList.add(value2);
                    last = matchResultMatchAt2.getRange().getLast();
                }
            }
        }

        public final MediaType b(String str) {
            Intrinsics.checkNotNullParameter(str, "<this>");
            try {
                return a(str);
            } catch (IllegalArgumentException unused) {
                return null;
            }
        }

        private Companion() {
        }
    }

    public MediaType(String str, String str2, String str3, String[] strArr) {
        Intrinsics.checkNotNullParameter(str, "mediaType");
        Intrinsics.checkNotNullParameter(str2, "type");
        Intrinsics.checkNotNullParameter(str3, "subtype");
        Intrinsics.checkNotNullParameter(strArr, "parameterNamesAndValues");
        this.a = str;
        this.b = str2;
        this.c = str3;
        this.d = strArr;
    }

    public static /* synthetic */ Charset d(MediaType mediaType, Charset charset, int i, Object obj) {
        if ((i & 1) != 0) {
            charset = null;
        }
        return mediaType.c(charset);
    }

    public static final MediaType e(String str) {
        return e.a(str);
    }

    public static final MediaType g(String str) {
        return e.b(str);
    }

    public final Charset c(Charset charset) {
        String strF = f("charset");
        if (strF == null) {
            return charset;
        }
        try {
            return Charset.forName(strF);
        } catch (IllegalArgumentException unused) {
            return charset;
        }
    }

    public boolean equals(Object obj) {
        return (obj instanceof MediaType) && Intrinsics.areEqual(((MediaType) obj).a, this.a);
    }

    public final String f(String str) {
        Intrinsics.checkNotNullParameter(str, "name");
        int i = 0;
        int progressionLastElement = ProgressionUtilKt.getProgressionLastElement(0, this.d.length - 1, 2);
        if (progressionLastElement < 0) {
            return null;
        }
        while (!StringsKt.equals(this.d[i], str, true)) {
            if (i == progressionLastElement) {
                return null;
            }
            i += 2;
        }
        return this.d[i + 1];
    }

    public final String h() {
        return this.c;
    }

    public int hashCode() {
        return this.a.hashCode();
    }

    public final String i() {
        return this.b;
    }

    public String toString() {
        return this.a;
    }
}