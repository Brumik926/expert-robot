package okhttp3;

import h.ap;
import java.io.EOFException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import kotlin.Metadata;
import kotlin.jvm.JvmOverloads;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.MediaType;
import okio.Buffer;
import okio.BufferedSink;
import okio.ByteString;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0010\t\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u000e\u0018\u0000 \t2\u00020\u0001:\u0003#$%J!\u0010\u0007\u001a\u00020\u00062\b\u0010\u0003\u001a\u0004\u0018\u00010\u00022\u0006\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\t\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\t\u0010\nJ\u000f\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\f\u0010\rJ\u000f\u0010\u000e\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u0017\u0010\u0011\u001a\u00020\u00102\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0011\u0010\u0012R\u0014\u0010\u0016\u001a\u00020\u00138\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0014\u0010\u0015R\u001d\u0010\u001b\u001a\b\u0012\u0004\u0012\u00020\u00180\u00178G¢\u0006\f\n\u0004\b\u0019\u0010\u001a\u001a\u0004\b\u001b\u0010\u001cR\u0014\u0010\u001f\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010\u001eR\u0016\u0010\"\u001a\u00020\u00068\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b \u0010!¨\u0006&"}, d2 = {"Lokhttp3/MultipartBody;", "Lokhttp3/RequestBody;", "Lokio/BufferedSink;", "sink", StringUtils.EMPTY, "countBytes", StringUtils.EMPTY, "i", "(Lokio/BufferedSink;Z)J", "g", "()Z", "Lokhttp3/MediaType;", "b", "()Lokhttp3/MediaType;", "a", "()J", StringUtils.EMPTY, "h", "(Lokio/BufferedSink;)V", "Lokio/ByteString;", "c", "Lokio/ByteString;", "boundaryByteString", StringUtils.EMPTY, "Lokhttp3/MultipartBody$Part;", "d", "Ljava/util/List;", "parts", "()Ljava/util/List;", "e", "Lokhttp3/MediaType;", "contentType", "f", "J", "contentLength", "Part", "Builder", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nMultipartBody.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MultipartBody.kt\nokhttp3/MultipartBody\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,381:1\n1761#2,3:382\n*S KotlinDebug\n*F\n+ 1 MultipartBody.kt\nokhttp3/MultipartBody\n*L\n52#1:382,3\n*E\n"})
public final class MultipartBody extends RequestBody {
    public static final Companion g = new Companion(null);
    public static final MediaType h;
    public static final MediaType i;
    public static final MediaType j;
    public static final MediaType k;
    public static final MediaType l;
    private static final byte[] m;
    private static final byte[] n;
    private static final byte[] o;
    private final ByteString c;
    private final List d;
    private final MediaType e;
    private long f;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000,\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010!\n\u0002\u0018\u0002\n\u0002\b\u0004\u0018\u00002\u00020\u0001B\u0013\b\u0007\u0012\b\b\u0002\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0014\u0010\u0003\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0007\u0010\bR\u0016\u0010\f\u001a\u00020\t8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\n\u0010\u000bR\u001a\u0010\u0011\u001a\b\u0012\u0004\u0012\u00020\u000e0\r8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\u0010¨\u0006\u0012"}, d2 = {"Lokhttp3/MultipartBody$Builder;", StringUtils.EMPTY, StringUtils.EMPTY, "boundary", "<init>", "(Ljava/lang/String;)V", "Lokio/ByteString;", "a", "Lokio/ByteString;", "Lokhttp3/MediaType;", "b", "Lokhttp3/MediaType;", "type", StringUtils.EMPTY, "Lokhttp3/MultipartBody$Part;", "c", "Ljava/util/List;", "parts", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nMultipartBody.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MultipartBody.kt\nokhttp3/MultipartBody$Builder\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,381:1\n1#2:382\n*E\n"})
    public static final class Builder {
        private final ByteString a;
        private MediaType b;
        private final List c;

        /* JADX WARN: Illegal instructions before constructor call */
        @JvmOverloads
        public Builder() {
            String str = null;
            this(str, 1, str);
        }

        public Builder(String str) {
            Intrinsics.checkNotNullParameter(str, ap.a(550111505));
            this.a = ByteString.d.d(str);
            this.b = MultipartBody.h;
            this.c = new ArrayList();
        }

        /* JADX WARN: Illegal instructions before constructor call */
        public /* synthetic */ Builder(String str, int i, DefaultConstructorMarker defaultConstructorMarker) {
            if ((i & 1) != 0) {
                str = UUID.randomUUID().toString();
                Intrinsics.checkNotNullExpressionValue(str, "toString(...)");
            }
            this(str);
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0012\n\u0002\b\u0005\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0014\u0010\u0005\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0005\u0010\u0006R\u0014\u0010\u0007\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\u0007\u0010\u0006R\u0014\u0010\b\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\b\u0010\u0006R\u0014\u0010\t\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\t\u0010\u0006R\u0014\u0010\n\u001a\u00020\u00048\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\n\u0010\u0006R\u0014\u0010\f\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\f\u0010\rR\u0014\u0010\u000e\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000e\u0010\rR\u0014\u0010\u000f\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000f\u0010\r¨\u0006\u0010"}, d2 = {"Lokhttp3/MultipartBody$Companion;", StringUtils.EMPTY, "<init>", "()V", "Lokhttp3/MediaType;", "MIXED", "Lokhttp3/MediaType;", "ALTERNATIVE", "DIGEST", "PARALLEL", "FORM", StringUtils.EMPTY, "COLONSPACE", "[B", "CRLF", "DASHDASH", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0006\u0018\u0000 \f2\u00020\u0001:\u0001\rR\u0019\u0010\u0007\u001a\u0004\u0018\u00010\u00028G¢\u0006\f\n\u0004\b\u0003\u0010\u0004\u001a\u0004\b\u0005\u0010\u0006R\u0017\u0010\u000b\u001a\u00020\b8G¢\u0006\f\n\u0004\b\u0005\u0010\t\u001a\u0004\b\u0003\u0010\n¨\u0006\u000e"}, d2 = {"Lokhttp3/MultipartBody$Part;", StringUtils.EMPTY, "Lokhttp3/Headers;", "a", "Lokhttp3/Headers;", "b", "()Lokhttp3/Headers;", "headers", "Lokhttp3/RequestBody;", "Lokhttp3/RequestBody;", "()Lokhttp3/RequestBody;", "body", "c", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Part {
        public static final Companion c = new Companion(null);
        private final Headers a;
        private final RequestBody b;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lokhttp3/MultipartBody$Part$Companion;", StringUtils.EMPTY, "<init>", "()V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
        @SourceDebugExtension({"SMAP\nMultipartBody.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MultipartBody.kt\nokhttp3/MultipartBody$Part$Companion\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,381:1\n1#2:382\n*E\n"})
        public static final class Companion {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            private Companion() {
            }
        }

        public final RequestBody a() {
            return this.b;
        }

        public final Headers b() {
            return this.a;
        }
    }

    static {
        MediaType.Companion companion = MediaType.e;
        h = companion.a(ap.a(1703862065));
        i = companion.a(ap.a(808084491));
        j = companion.a(ap.a(1332956489));
        k = companion.a(ap.a(1129300098));
        l = companion.a(ap.a(1042394987));
        m = new byte[]{58, 32};
        n = new byte[]{13, 10};
        o = new byte[]{45, 45};
    }

    /* JADX WARN: Multi-variable type inference failed */
    private final long i(BufferedSink bufferedSink, boolean z) throws EOFException {
        Buffer buffer;
        if (z) {
            bufferedSink = new Buffer();
            buffer = bufferedSink;
        } else {
            buffer = 0;
        }
        int size = this.d.size();
        long j2 = 0;
        for (int i2 = 0; i2 < size; i2++) {
            Part part = (Part) this.d.get(i2);
            Headers headersB = part.b();
            RequestBody requestBodyA = part.a();
            Intrinsics.checkNotNull(bufferedSink);
            bufferedSink.write(o);
            bufferedSink.l1(this.c);
            bufferedSink.write(n);
            if (headersB != null) {
                int size2 = headersB.size();
                for (int i3 = 0; i3 < size2; i3++) {
                    bufferedSink.V1(headersB.e(i3)).write(m).V1(headersB.k(i3)).write(n);
                }
            }
            MediaType mediaTypeB = requestBodyA.b();
            if (mediaTypeB != null) {
                bufferedSink.V1("Content-Type: ").V1(mediaTypeB.toString()).write(n);
            }
            long jA = requestBodyA.a();
            if (jA == -1 && z) {
                Intrinsics.checkNotNull(buffer);
                buffer.j();
                return -1L;
            }
            byte[] bArr = n;
            bufferedSink.write(bArr);
            if (z) {
                j2 += jA;
            } else {
                requestBodyA.h(bufferedSink);
            }
            bufferedSink.write(bArr);
        }
        Intrinsics.checkNotNull(bufferedSink);
        byte[] bArr2 = o;
        bufferedSink.write(bArr2);
        bufferedSink.l1(this.c);
        bufferedSink.write(bArr2);
        bufferedSink.write(n);
        if (!z) {
            return j2;
        }
        Intrinsics.checkNotNull(buffer);
        long size3 = j2 + buffer.size();
        buffer.j();
        return size3;
    }

    @Override // okhttp3.RequestBody
    public long a() throws EOFException {
        long j2 = this.f;
        if (j2 != -1) {
            return j2;
        }
        long jI = i(null, true);
        this.f = jI;
        return jI;
    }

    @Override // okhttp3.RequestBody
    public MediaType b() {
        return this.e;
    }

    @Override // okhttp3.RequestBody
    public boolean g() {
        List list = this.d;
        if ((list instanceof Collection) && list.isEmpty()) {
            return false;
        }
        Iterator it = list.iterator();
        while (it.hasNext()) {
            if (((Part) it.next()).a().g()) {
                return true;
            }
        }
        return false;
    }

    @Override // okhttp3.RequestBody
    public void h(BufferedSink bufferedSink) throws EOFException {
        Intrinsics.checkNotNullParameter(bufferedSink, "sink");
        i(bufferedSink, false);
    }
}