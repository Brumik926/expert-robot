package okhttp3;

import h.ap;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okhttp3.internal._UtilJvmKt;
import okhttp3.internal.connection.RealCall;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\n\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\n\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003J\u001d\u0010\b\u001a\b\u0018\u00010\u0006R\u00020\u00072\u0006\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\b\u0010\tJ\u000f\u0010\u000b\u001a\u00020\nH\u0002¢\u0006\u0004\b\u000b\u0010\fJ+\u0010\u0012\u001a\u00020\u0011\"\u0004\b\u0000\u0010\r2\f\u0010\u000f\u001a\b\u0012\u0004\u0012\u00028\u00000\u000e2\u0006\u0010\u0010\u001a\u00028\u0000H\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u001b\u0010\u0014\u001a\u00020\u00112\n\u0010\u0010\u001a\u00060\u0006R\u00020\u0007H\u0000¢\u0006\u0004\b\u0014\u0010\u0015J\r\u0010\u0016\u001a\u00020\u0011¢\u0006\u0004\b\u0016\u0010\u0003J\u0017\u0010\u0017\u001a\u00020\n2\u0006\u0010\u0010\u001a\u00020\u0007H\u0000¢\u0006\u0004\b\u0017\u0010\u0018J\u001b\u0010\u0019\u001a\u00020\u00112\n\u0010\u0010\u001a\u00060\u0006R\u00020\u0007H\u0000¢\u0006\u0004\b\u0019\u0010\u0015J\u0017\u0010\u001a\u001a\u00020\u00112\u0006\u0010\u0010\u001a\u00020\u0007H\u0000¢\u0006\u0004\b\u001a\u0010\u001bJ\u0013\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001d0\u001c¢\u0006\u0004\b\u001e\u0010\u001fJ\u0013\u0010 \u001a\b\u0012\u0004\u0012\u00020\u001d0\u001c¢\u0006\u0004\b \u0010\u001fJ\r\u0010\"\u001a\u00020!¢\u0006\u0004\b\"\u0010#R*\u0010$\u001a\u00020!2\u0006\u0010$\u001a\u00020!8\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\b\u0016\u0010%\u001a\u0004\b&\u0010#\"\u0004\b'\u0010(R*\u0010)\u001a\u00020!2\u0006\u0010)\u001a\u00020!8\u0006@FX\u0086\u000e¢\u0006\u0012\n\u0004\b\u0014\u0010%\u001a\u0004\b*\u0010#\"\u0004\b+\u0010(R$\u00102\u001a\u0004\u0018\u00010,8\u0006@\u0006X\u0086\u000e¢\u0006\u0012\n\u0004\b\u0017\u0010-\u001a\u0004\b.\u0010/\"\u0004\b0\u00101R\u0018\u00106\u001a\u0004\u0018\u0001038\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b4\u00105R\u001e\u00109\u001a\f\u0012\b\u0012\u00060\u0006R\u00020\u0007078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\b\u00108R\u001e\u0010:\u001a\f\u0012\b\u0012\u00060\u0006R\u00020\u0007078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0012\u00108R\u001a\u0010;\u001a\b\u0012\u0004\u0012\u00020\u0007078\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0019\u00108R\u0011\u0010=\u001a\u0002038G¢\u0006\u0006\u001a\u0004\b4\u0010<¨\u0006>"}, d2 = {"Lokhttp3/Dispatcher;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "host", "Lokhttp3/internal/connection/RealCall$AsyncCall;", "Lokhttp3/internal/connection/RealCall;", "e", "(Ljava/lang/String;)Lokhttp3/internal/connection/RealCall$AsyncCall;", StringUtils.EMPTY, "i", "()Z", "T", "Ljava/util/Deque;", "calls", "call", StringUtils.EMPTY, "f", "(Ljava/util/Deque;Ljava/lang/Object;)V", "b", "(Lokhttp3/internal/connection/RealCall$AsyncCall;)V", "a", "c", "(Lokhttp3/internal/connection/RealCall;)Z", "g", "h", "(Lokhttp3/internal/connection/RealCall;)V", StringUtils.EMPTY, "Lokhttp3/Call;", "j", "()Ljava/util/List;", "k", StringUtils.EMPTY, "l", "()I", "maxRequests", "I", "getMaxRequests", "setMaxRequests", "(I)V", "maxRequestsPerHost", "getMaxRequestsPerHost", "setMaxRequestsPerHost", "Ljava/lang/Runnable;", "Ljava/lang/Runnable;", "getIdleCallback", "()Ljava/lang/Runnable;", "setIdleCallback", "(Ljava/lang/Runnable;)V", "idleCallback", "Ljava/util/concurrent/ExecutorService;", "d", "Ljava/util/concurrent/ExecutorService;", "executorServiceOrNull", "Ljava/util/ArrayDeque;", "Ljava/util/ArrayDeque;", "readyAsyncCalls", "runningAsyncCalls", "runningSyncCalls", "()Ljava/util/concurrent/ExecutorService;", "executorService", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nDispatcher.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Dispatcher.kt\nokhttp3/Dispatcher\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 4 -UtilJvm.kt\nokhttp3/internal/_UtilJvmKt\n*L\n1#1,272:1\n1#2:273\n1563#3:274\n1634#3,3:275\n1563#3:279\n1634#3,3:280\n248#4:278\n248#4:283\n*S KotlinDebug\n*F\n+ 1 Dispatcher.kt\nokhttp3/Dispatcher\n*L\n252#1:274\n252#1:275,3\n256#1:279\n256#1:280,3\n252#1:278\n256#1:283\n*E\n"})
public final class Dispatcher {
    private Runnable c;
    private ExecutorService d;
    private int a = 64;
    private int b = 5;
    private final ArrayDeque e = new ArrayDeque();
    private final ArrayDeque f = new ArrayDeque();
    private final ArrayDeque g = new ArrayDeque();

    private final RealCall.AsyncCall e(String str) {
        Iterator it = this.f.iterator();
        String strA = ap.a(1264912762);
        Intrinsics.checkNotNullExpressionValue(it, strA);
        while (it.hasNext()) {
            RealCall.AsyncCall asyncCall = (RealCall.AsyncCall) it.next();
            if (Intrinsics.areEqual(asyncCall.f(), str)) {
                return asyncCall;
            }
        }
        Iterator it2 = this.e.iterator();
        Intrinsics.checkNotNullExpressionValue(it2, strA);
        while (it2.hasNext()) {
            RealCall.AsyncCall asyncCall2 = (RealCall.AsyncCall) it2.next();
            if (Intrinsics.areEqual(asyncCall2.f(), str)) {
                return asyncCall2;
            }
        }
        return null;
    }

    private final void f(Deque deque, Object obj) {
        Runnable runnable;
        synchronized (this) {
            if (!deque.remove(obj)) {
                throw new AssertionError("Call wasn't in-flight!");
            }
            runnable = this.c;
            Unit unit = Unit.INSTANCE;
        }
        if (i() || runnable == null) {
            return;
        }
        runnable.run();
    }

    private final boolean i() {
        int i;
        boolean z;
        _UtilJvmKt.e(this);
        ArrayList arrayList = new ArrayList();
        synchronized (this) {
            try {
                Iterator it = this.e.iterator();
                Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
                while (it.hasNext()) {
                    RealCall.AsyncCall asyncCall = (RealCall.AsyncCall) it.next();
                    if (this.f.size() >= this.a) {
                        break;
                    }
                    if (asyncCall.e().get() < this.b) {
                        it.remove();
                        asyncCall.e().incrementAndGet();
                        Intrinsics.checkNotNull(asyncCall);
                        arrayList.add(asyncCall);
                        this.f.add(asyncCall);
                    }
                }
                i = 0;
                z = l() > 0;
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
        if (d().isShutdown()) {
            int size = arrayList.size();
            while (i < size) {
                RealCall.AsyncCall asyncCall2 = (RealCall.AsyncCall) arrayList.get(i);
                asyncCall2.e().decrementAndGet();
                synchronized (this) {
                    this.f.remove(asyncCall2);
                }
                RealCall.AsyncCall.c(asyncCall2, null, 1, null);
                i++;
            }
            Runnable runnable = this.c;
            if (runnable != null) {
                runnable.run();
                return z;
            }
        } else {
            int size2 = arrayList.size();
            while (i < size2) {
                ((RealCall.AsyncCall) arrayList.get(i)).a(d());
                i++;
            }
        }
        return z;
    }

    public final synchronized void a() {
        try {
            Iterator it = this.e.iterator();
            Intrinsics.checkNotNullExpressionValue(it, "iterator(...)");
            while (it.hasNext()) {
                ((RealCall.AsyncCall) it.next()).d().cancel();
            }
            Iterator it2 = this.f.iterator();
            Intrinsics.checkNotNullExpressionValue(it2, "iterator(...)");
            while (it2.hasNext()) {
                ((RealCall.AsyncCall) it2.next()).d().cancel();
            }
            Iterator it3 = this.g.iterator();
            Intrinsics.checkNotNullExpressionValue(it3, "iterator(...)");
            while (it3.hasNext()) {
                ((RealCall) it3.next()).cancel();
            }
        } catch (Throwable th) {
            throw th;
        }
    }

    public final void b(RealCall.AsyncCall asyncCall) {
        RealCall.AsyncCall asyncCallE;
        Intrinsics.checkNotNullParameter(asyncCall, "call");
        synchronized (this) {
            try {
                this.e.add(asyncCall);
                if (!asyncCall.d().m() && (asyncCallE = e(asyncCall.f())) != null) {
                    asyncCall.g(asyncCallE);
                }
                Unit unit = Unit.INSTANCE;
            } catch (Throwable th) {
                throw th;
            }
        }
        i();
    }

    public final synchronized boolean c(RealCall realCall) {
        Intrinsics.checkNotNullParameter(realCall, "call");
        return this.g.add(realCall);
    }

    public final synchronized ExecutorService d() {
        ExecutorService executorService;
        try {
            if (this.d == null) {
                this.d = new ThreadPoolExecutor(0, Integer.MAX_VALUE, 60L, TimeUnit.SECONDS, new SynchronousQueue(), _UtilJvmKt.p(_UtilJvmKt.c + " Dispatcher", false));
            }
            executorService = this.d;
            Intrinsics.checkNotNull(executorService);
        } catch (Throwable th) {
            throw th;
        }
        return executorService;
    }

    public final void g(RealCall.AsyncCall asyncCall) {
        Intrinsics.checkNotNullParameter(asyncCall, "call");
        asyncCall.e().decrementAndGet();
        f(this.f, asyncCall);
    }

    public final void h(RealCall realCall) {
        Intrinsics.checkNotNullParameter(realCall, "call");
        f(this.g, realCall);
    }

    public final synchronized List j() {
        List listUnmodifiableList;
        try {
            ArrayDeque arrayDeque = this.e;
            ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayDeque, 10));
            Iterator it = arrayDeque.iterator();
            while (it.hasNext()) {
                arrayList.add(((RealCall.AsyncCall) it.next()).d());
            }
            listUnmodifiableList = Collections.unmodifiableList(arrayList);
            Intrinsics.checkNotNullExpressionValue(listUnmodifiableList, "unmodifiableList(...)");
        } catch (Throwable th) {
            throw th;
        }
        return listUnmodifiableList;
    }

    public final synchronized List k() {
        List listUnmodifiableList;
        try {
            ArrayDeque arrayDeque = this.g;
            ArrayDeque arrayDeque2 = this.f;
            ArrayList arrayList = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayDeque2, 10));
            Iterator it = arrayDeque2.iterator();
            while (it.hasNext()) {
                arrayList.add(((RealCall.AsyncCall) it.next()).d());
            }
            listUnmodifiableList = Collections.unmodifiableList(CollectionsKt.plus(arrayDeque, arrayList));
            Intrinsics.checkNotNullExpressionValue(listUnmodifiableList, "unmodifiableList(...)");
        } catch (Throwable th) {
            throw th;
        }
        return listUnmodifiableList;
    }

    public final synchronized int l() {
        return this.f.size() + this.g.size();
    }
}