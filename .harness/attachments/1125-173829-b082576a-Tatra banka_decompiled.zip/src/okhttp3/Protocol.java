package okhttp3;

import h.ap;
import java.io.IOException;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.text.StringsKt;
import org.apache.tika.utils.StringUtils;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\u000e\n\u0002\b\u0011\b\u0086\u0081\u0002\u0018\u0000 \n2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\u000bB\u0011\b\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0006\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0006\u0010\u0007R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\b\u0010\tj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012¨\u0006\u0013"}, d2 = {"Lokhttp3/Protocol;", StringUtils.EMPTY, StringUtils.EMPTY, "protocol", "<init>", "(Ljava/lang/String;ILjava/lang/String;)V", "toString", "()Ljava/lang/String;", "a", "Ljava/lang/String;", "b", "Companion", "c", "d", "e", "f", "g", "h", "i", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Protocol {
    public static final Companion b;
    public static final Protocol c = new Protocol(ap.a(447393099), 0, ap.a(1106714615));
    public static final Protocol d = new Protocol(ap.a(976328860), 1, ap.a(335004156));
    public static final Protocol e = new Protocol(ap.a(32436668), 2, ap.a(1368412366));
    public static final Protocol f = new Protocol(ap.a(1413092528), 3, ap.a(501640587));
    public static final Protocol g = new Protocol(ap.a(1739640281), 4, ap.a(1672456410));
    public static final Protocol h = new Protocol(ap.a(1810932399), 5, ap.a(1764907637));
    public static final Protocol i = new Protocol(ap.a(2094969601), 6, ap.a(1983981652));
    private static final /* synthetic */ Protocol[] j;
    private static final /* synthetic */ EnumEntries k;
    private final String a;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lokhttp3/Protocol$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "protocol", "Lokhttp3/Protocol;", "a", "(Ljava/lang/String;)Lokhttp3/Protocol;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final Protocol a(String str) throws IOException {
            Intrinsics.checkNotNullParameter(str, ap.a(16704924));
            Protocol protocol = Protocol.c;
            if (Intrinsics.areEqual(str, protocol.a)) {
                return protocol;
            }
            Protocol protocol2 = Protocol.d;
            if (Intrinsics.areEqual(str, protocol2.a)) {
                return protocol2;
            }
            Protocol protocol3 = Protocol.g;
            if (Intrinsics.areEqual(str, protocol3.a)) {
                return protocol3;
            }
            Protocol protocol4 = Protocol.f;
            if (Intrinsics.areEqual(str, protocol4.a)) {
                return protocol4;
            }
            Protocol protocol5 = Protocol.e;
            if (Intrinsics.areEqual(str, protocol5.a)) {
                return protocol5;
            }
            Protocol protocol6 = Protocol.h;
            if (Intrinsics.areEqual(str, protocol6.a)) {
                return protocol6;
            }
            Protocol protocol7 = Protocol.i;
            if (StringsKt.startsWith$default(str, protocol7.a, false, 2, (Object) null)) {
                return protocol7;
            }
            throw new IOException(ap.a(92396153) + str);
        }

        private Companion() {
        }
    }

    static {
        Protocol[] protocolArrA = a();
        j = protocolArrA;
        k = EnumEntriesKt.enumEntries(protocolArrA);
        b = new Companion(null);
    }

    private Protocol(String str, int i2, String str2) {
        this.a = str2;
    }

    private static final /* synthetic */ Protocol[] a() {
        return new Protocol[]{c, d, e, f, g, h, i};
    }

    public static Protocol valueOf(String str) {
        return (Protocol) Enum.valueOf(Protocol.class, str);
    }

    public static Protocol[] values() {
        return (Protocol[]) j.clone();
    }

    @Override // java.lang.Enum
    public String toString() {
        return this.a;
    }
}