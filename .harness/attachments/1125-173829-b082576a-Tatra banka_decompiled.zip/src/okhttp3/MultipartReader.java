package okhttp3;

import h.ap;
import java.io.Closeable;
import java.io.EOFException;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okio.Buffer;
import okio.BufferedSource;
import okio.ByteString;
import okio.Options;
import okio.Source;
import okio.Timeout;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u00008\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\b\u0018\u0000 \u00192\u00020\u0001:\u0003\u001a\u001b\u001cJ\u0017\u0010\u0004\u001a\u00020\u00022\u0006\u0010\u0003\u001a\u00020\u0002H\u0002¢\u0006\u0004\b\u0004\u0010\u0005J\u000f\u0010\u0007\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u0007\u0010\bR\u0014\u0010\f\u001a\u00020\t8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\n\u0010\u000bR\u0014\u0010\u0010\u001a\u00020\r8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000e\u0010\u000fR\u0016\u0010\u0014\u001a\u00020\u00118\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0012\u0010\u0013R\u001c\u0010\u0018\u001a\b\u0018\u00010\u0015R\u00020\u00008\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0016\u0010\u0017¨\u0006\u001d"}, d2 = {"Lokhttp3/MultipartReader;", "Ljava/io/Closeable;", StringUtils.EMPTY, "maxByteCount", "j", "(J)J", StringUtils.EMPTY, "close", "()V", "Lokio/BufferedSource;", "a", "Lokio/BufferedSource;", ClimateForcast.SOURCE, "Lokio/ByteString;", "b", "Lokio/ByteString;", "crlfDashDashBoundary", StringUtils.EMPTY, "c", "Z", "closed", "Lokhttp3/MultipartReader$PartSource;", "d", "Lokhttp3/MultipartReader$PartSource;", "currentPart", "e", "PartSource", "Part", "Companion", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nMultipartReader.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MultipartReader.kt\nokhttp3/MultipartReader\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,228:1\n1#2:229\n*E\n"})
public final class MultipartReader implements Closeable {
    public static final Companion e = new Companion(null);
    private static final Options f;
    private final BufferedSource a;
    private final ByteString b;
    private boolean c;
    private PartSource d;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\b\u0080\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lokhttp3/MultipartReader$Companion;", StringUtils.EMPTY, "<init>", "()V", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\u0018\u00002\u00020\u0001J\u0010\u0010\u0003\u001a\u00020\u0002H\u0096\u0001¢\u0006\u0004\b\u0003\u0010\u0004R\u0017\u0010\b\u001a\u00020\u00058G¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\b\u0010\t¨\u0006\n"}, d2 = {"Lokhttp3/MultipartReader$Part;", "Ljava/io/Closeable;", StringUtils.EMPTY, "close", "()V", "Lokio/BufferedSource;", "a", "Lokio/BufferedSource;", "body", "()Lokio/BufferedSource;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Part implements Closeable {
        private final BufferedSource a;

        @Override // java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            this.a.close();
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000&\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0082\u0004\u0018\u00002\u00020\u0001J\u000f\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0003\u0010\u0004J\u001f\u0010\t\u001a\u00020\u00072\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\t\u0010\nJ\u000f\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\f\u0010\rR\u0014\u0010\f\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u000e\u0010\u000f¨\u0006\u0010"}, d2 = {"Lokhttp3/MultipartReader$PartSource;", "Lokio/Source;", StringUtils.EMPTY, "close", "()V", "Lokio/Buffer;", "sink", StringUtils.EMPTY, "byteCount", "k3", "(Lokio/Buffer;J)J", "Lokio/Timeout;", "timeout", "()Lokio/Timeout;", "a", "Lokio/Timeout;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nMultipartReader.kt\nKotlin\n*S Kotlin\n*F\n+ 1 MultipartReader.kt\nokhttp3/MultipartReader$PartSource\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Timeout.kt\nokio/Timeout\n*L\n1#1,228:1\n1#2:229\n302#3,26:230\n*S KotlinDebug\n*F\n+ 1 MultipartReader.kt\nokhttp3/MultipartReader$PartSource\n*L\n168#1:230,26\n*E\n"})
    private final class PartSource implements Source {
        private final Timeout a;
        final /* synthetic */ MultipartReader b;

        @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
        public void close() {
            if (Intrinsics.areEqual(this.b.d, this)) {
                this.b.d = null;
            }
        }

        @Override // okio.Source
        public long k3(Buffer buffer, long j) {
            long j2;
            Intrinsics.checkNotNullParameter(buffer, ap.a(329187202));
            if (j < 0) {
                throw new IllegalArgumentException((ap.a(1400894217) + j).toString());
            }
            if (!Intrinsics.areEqual(this.b.d, this)) {
                throw new IllegalStateException(ap.a(1588528402));
            }
            Timeout timeout = this.b.a.timeout();
            Timeout timeout2 = this.a;
            MultipartReader multipartReader = this.b;
            long jI = timeout.i();
            long jA = Timeout.e.a(timeout2.i(), timeout.i());
            TimeUnit timeUnit = TimeUnit.NANOSECONDS;
            timeout.h(jA, timeUnit);
            if (!timeout.f()) {
                if (timeout2.f()) {
                    timeout.e(timeout2.d());
                }
                try {
                    long j3 = multipartReader.j(j);
                    long jK3 = j3 == 0 ? -1L : multipartReader.a.k3(buffer, j3);
                    timeout.h(jI, timeUnit);
                    if (timeout2.f()) {
                        timeout.b();
                    }
                    return jK3;
                } catch (Throwable th) {
                    timeout.h(jI, TimeUnit.NANOSECONDS);
                    if (timeout2.f()) {
                        timeout.b();
                    }
                    throw th;
                }
            }
            long jD = timeout.d();
            if (timeout2.f()) {
                j2 = 0;
                timeout.e(Math.min(timeout.d(), timeout2.d()));
            } else {
                j2 = 0;
            }
            try {
                long j4 = multipartReader.j(j);
                long jK32 = j4 == j2 ? -1L : multipartReader.a.k3(buffer, j4);
                timeout.h(jI, timeUnit);
                if (timeout2.f()) {
                    timeout.e(jD);
                }
                return jK32;
            } catch (Throwable th2) {
                timeout.h(jI, TimeUnit.NANOSECONDS);
                if (timeout2.f()) {
                    timeout.e(jD);
                }
                throw th2;
            }
        }

        @Override // okio.Source
        public Timeout timeout() {
            return this.a;
        }
    }

    static {
        Options.Companion companion = Options.c;
        ByteString.Companion companion2 = ByteString.d;
        f = companion.d(companion2.d(ap.a(1977783784)), companion2.d(ap.a(1299502367)), companion2.d(ap.a(940975380)), companion2.d(ap.a(235845508)));
    }

    private final long j(long j) throws EOFException {
        long jMin = Math.min(this.a.getBuffer().size(), j) + 1;
        long jI2 = this.a.I2(this.b, 0L, jMin);
        if (jI2 != -1) {
            return jI2;
        }
        if (this.a.getBuffer().size() >= jMin) {
            return Math.min(jMin, j);
        }
        throw new EOFException();
    }

    @Override // java.io.Closeable, java.lang.AutoCloseable
    public void close() {
        if (this.c) {
            return;
        }
        this.c = true;
        this.d = null;
        this.a.close();
    }
}