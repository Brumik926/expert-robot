package okhttp3;

import h.ap;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.apache.tika.utils.StringUtils;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\u000e\n\u0002\b\u000e\b\u0086\u0081\u0002\u0018\u0000 \b2\b\u0012\u0004\u0012\u00020\u00000\u0001:\u0001\nB\u0011\b\u0002\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005R\u0017\u0010\u0003\u001a\u00020\u00028G¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\b\u0010\tj\u0002\b\u000bj\u0002\b\fj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000f¨\u0006\u0010"}, d2 = {"Lokhttp3/TlsVersion;", StringUtils.EMPTY, StringUtils.EMPTY, "javaName", "<init>", "(Ljava/lang/String;ILjava/lang/String;)V", "a", "Ljava/lang/String;", "b", "()Ljava/lang/String;", "Companion", "c", "d", "e", "f", "g", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class TlsVersion {
    public static final Companion b;
    public static final TlsVersion c = new TlsVersion(ap.a(1465230892), 0, ap.a(1038017197));
    public static final TlsVersion d = new TlsVersion(ap.a(1293176112), 1, ap.a(2060402028));
    public static final TlsVersion e = new TlsVersion(ap.a(1096029222), 2, ap.a(1445760354));
    public static final TlsVersion f = new TlsVersion(ap.a(1448148122), 3, ap.a(98108289));
    public static final TlsVersion g = new TlsVersion(ap.a(2077294146), 4, ap.a(708607745));
    private static final /* synthetic */ TlsVersion[] h;
    private static final /* synthetic */ EnumEntries i;
    private final String a;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\u0007\u0010\b¨\u0006\t"}, d2 = {"Lokhttp3/TlsVersion$Companion;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "javaName", "Lokhttp3/TlsVersion;", "a", "(Ljava/lang/String;)Lokhttp3/TlsVersion;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final TlsVersion a(String str) {
            Intrinsics.checkNotNullParameter(str, ap.a(1130051441));
            int iHashCode = str.hashCode();
            if (iHashCode != 79201641) {
                if (iHashCode != 79923350) {
                    switch (iHashCode) {
                        case -503070503:
                            if (str.equals(ap.a(1285513522))) {
                                return TlsVersion.e;
                            }
                            break;
                        case -503070502:
                            if (str.equals(ap.a(1505489841))) {
                                return TlsVersion.d;
                            }
                            break;
                        case -503070501:
                            if (str.equals(ap.a(1457294373))) {
                                return TlsVersion.c;
                            }
                            break;
                    }
                } else if (str.equals(ap.a(721060261))) {
                    return TlsVersion.f;
                }
            } else if (str.equals(ap.a(1106436750))) {
                return TlsVersion.g;
            }
            throw new IllegalArgumentException(ap.a(714878481) + str);
        }

        private Companion() {
        }
    }

    static {
        TlsVersion[] tlsVersionArrA = a();
        h = tlsVersionArrA;
        i = EnumEntriesKt.enumEntries(tlsVersionArrA);
        b = new Companion(null);
    }

    private TlsVersion(String str, int i2, String str2) {
        this.a = str2;
    }

    private static final /* synthetic */ TlsVersion[] a() {
        return new TlsVersion[]{c, d, e, f, g};
    }

    public static TlsVersion valueOf(String str) {
        return (TlsVersion) Enum.valueOf(TlsVersion.class, str);
    }

    public static TlsVersion[] values() {
        return (TlsVersion[]) h.clone();
    }

    public final String b() {
        return this.a;
    }
}