package okhttp3;

import h.ap;
import java.util.concurrent.TimeUnit;
import kotlin.Metadata;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.coroutines.internal.LockFreeTaskQueueCore;
import okhttp3.internal.concurrent.TaskRunner;
import okhttp3.internal.connection.ConnectionListener;
import okhttp3.internal.connection.ConnectionUser;
import okhttp3.internal.connection.ExchangeFinder;
import okhttp3.internal.connection.FastFallbackExchangeFinder;
import okhttp3.internal.connection.ForceConnectRoutePlanner;
import okhttp3.internal.connection.RealConnectionPool;
import okhttp3.internal.connection.RealRoutePlanner;
import okhttp3.internal.connection.RouteDatabase;
import org.apache.tika.pipes.PipesConfigBase;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000H\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\b\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\u0002\n\u0002\b\u0006\u0018\u00002\u00020\u0001B\u0011\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002¢\u0006\u0004\b\u0004\u0010\u0005B\u008b\u0001\b\u0010\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006\u0012\b\b\u0002\u0010\t\u001a\u00020\b\u0012\b\b\u0002\u0010\u000b\u001a\u00020\n\u0012\b\b\u0002\u0010\r\u001a\u00020\f\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u000e\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0014\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u0016\u001a\u00020\u0015\u0012\b\b\u0002\u0010\u0017\u001a\u00020\u0015\u0012\b\b\u0002\u0010\u0019\u001a\u00020\u0018¢\u0006\u0004\b\u0004\u0010\u001aB!\b\u0016\u0012\u0006\u0010\u0007\u001a\u00020\u0006\u0012\u0006\u0010\t\u001a\u00020\b\u0012\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\u0004\u0010\u001bB\t\b\u0016¢\u0006\u0004\b\u0004\u0010\u001cJ\r\u0010\u001d\u001a\u00020\u0006¢\u0006\u0004\b\u001d\u0010\u001eJ\r\u0010 \u001a\u00020\u001f¢\u0006\u0004\b \u0010\u001cR\u001a\u0010\u0003\u001a\u00020\u00028\u0000X\u0080\u0004¢\u0006\f\n\u0004\b!\u0010\"\u001a\u0004\b#\u0010$¨\u0006%"}, d2 = {"Lokhttp3/ConnectionPool;", StringUtils.EMPTY, "Lokhttp3/internal/connection/RealConnectionPool;", "delegate", "<init>", "(Lokhttp3/internal/connection/RealConnectionPool;)V", StringUtils.EMPTY, "maxIdleConnections", StringUtils.EMPTY, "keepAliveDuration", "Ljava/util/concurrent/TimeUnit;", "timeUnit", "Lokhttp3/internal/concurrent/TaskRunner;", "taskRunner", "Lokhttp3/internal/connection/ConnectionListener;", "connectionListener", "readTimeoutMillis", "writeTimeoutMillis", "socketConnectTimeoutMillis", "socketReadTimeoutMillis", "pingIntervalMillis", StringUtils.EMPTY, "retryOnConnectionFailure", "fastFallback", "Lokhttp3/internal/connection/RouteDatabase;", "routeDatabase", "(IJLjava/util/concurrent/TimeUnit;Lokhttp3/internal/concurrent/TaskRunner;Lokhttp3/internal/connection/ConnectionListener;IIIIIZZLokhttp3/internal/connection/RouteDatabase;)V", "(IJLjava/util/concurrent/TimeUnit;)V", "()V", "c", "()I", StringUtils.EMPTY, "d", "a", "Lokhttp3/internal/connection/RealConnectionPool;", "e", "()Lokhttp3/internal/connection/RealConnectionPool;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ConnectionPool {
    private final RealConnectionPool a;

    public ConnectionPool(RealConnectionPool realConnectionPool) {
        Intrinsics.checkNotNullParameter(realConnectionPool, "delegate");
        this.a = realConnectionPool;
    }

    private static final ExchangeFinder b(TaskRunner taskRunner, int i, int i2, int i3, int i4, int i5, boolean z, boolean z2, RouteDatabase routeDatabase, RealConnectionPool realConnectionPool, Address address, ConnectionUser connectionUser) {
        Intrinsics.checkNotNullParameter(realConnectionPool, "pool");
        Intrinsics.checkNotNullParameter(address, "address");
        Intrinsics.checkNotNullParameter(connectionUser, "user");
        return new FastFallbackExchangeFinder(new ForceConnectRoutePlanner(new RealRoutePlanner(taskRunner, realConnectionPool, i, i2, i3, i4, i5, z, z2, address, routeDatabase, connectionUser)), taskRunner);
    }

    public final int c() {
        return this.a.e();
    }

    public final void d() {
        this.a.f();
    }

    public final RealConnectionPool e() {
        return this.a;
    }

    public /* synthetic */ ConnectionPool(int i, long j, TimeUnit timeUnit, TaskRunner taskRunner, ConnectionListener connectionListener, int i2, int i3, int i4, int i5, int i6, boolean z, boolean z2, RouteDatabase routeDatabase, int i7, DefaultConstructorMarker defaultConstructorMarker) {
        this((i7 & 1) != 0 ? 5 : i, (i7 & 2) != 0 ? 5L : j, (i7 & 4) != 0 ? TimeUnit.MINUTES : timeUnit, (i7 & 8) != 0 ? TaskRunner.m : taskRunner, (i7 & 16) != 0 ? ConnectionListener.a.a() : connectionListener, (i7 & 32) != 0 ? 10000 : i2, (i7 & 64) != 0 ? 10000 : i3, (i7 & 128) != 0 ? 10000 : i4, (i7 & 256) != 0 ? 10000 : i5, (i7 & 512) == 0 ? i6 : PipesConfigBase.DEFAULT_MAX_FILES_PROCESSED_PER_PROCESS, (i7 & LockFreeTaskQueueCore.MIN_ADD_SPIN_CAPACITY) != 0 ? true : z, (i7 & 2048) == 0 ? z2 : true, (i7 & 4096) != 0 ? new RouteDatabase() : routeDatabase);
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public ConnectionPool(int i, long j, TimeUnit timeUnit, final TaskRunner taskRunner, ConnectionListener connectionListener, final int i2, final int i3, final int i4, final int i5, final int i6, final boolean z, final boolean z2, final RouteDatabase routeDatabase) {
        this(new RealConnectionPool(taskRunner, i, j, timeUnit, connectionListener, new Function3() { // from class: okhttp3.b
            public final Object invoke(Object obj, Object obj2, Object obj3) {
                return ConnectionPool.b(taskRunner, i2, i3, i4, i5, i6, z, z2, routeDatabase, (RealConnectionPool) obj, (Address) obj2, (ConnectionUser) obj3);
            }
        }));
        Intrinsics.checkNotNullParameter(timeUnit, "timeUnit");
        Intrinsics.checkNotNullParameter(taskRunner, "taskRunner");
        Intrinsics.checkNotNullParameter(connectionListener, "connectionListener");
        Intrinsics.checkNotNullParameter(routeDatabase, "routeDatabase");
    }

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    public ConnectionPool(int i, long j, TimeUnit timeUnit) {
        this(i, j, timeUnit, TaskRunner.m, ConnectionListener.a.a(), 0, 0, 0, 0, 0, false, false, null, 8160, null);
        Intrinsics.checkNotNullParameter(timeUnit, ap.a(1412560331));
    }

    public ConnectionPool() {
        this(5, 5L, TimeUnit.MINUTES);
    }
}