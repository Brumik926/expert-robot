package okhttp3;

import h.ap;
import java.nio.charset.Charset;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okio.ByteString;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\bÆ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J)\u0010\t\u001a\u00020\u00042\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00042\b\b\u0002\u0010\b\u001a\u00020\u0007H\u0007¢\u0006\u0004\b\t\u0010\n¨\u0006\u000b"}, d2 = {"Lokhttp3/Credentials;", StringUtils.EMPTY, "<init>", "()V", StringUtils.EMPTY, "username", "password", "Ljava/nio/charset/Charset;", "charset", "a", "(Ljava/lang/String;Ljava/lang/String;Ljava/nio/charset/Charset;)Ljava/lang/String;", "okhttp"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class Credentials {
    public static final Credentials a = new Credentials();

    private Credentials() {
    }

    public static final String a(String str, String str2, Charset charset) {
        Intrinsics.checkNotNullParameter(str, ap.a(22060616));
        Intrinsics.checkNotNullParameter(str2, ap.a(403967133));
        Intrinsics.checkNotNullParameter(charset, ap.a(1057829693));
        return ap.a(434495954) + ByteString.d.c(str + AbstractJsonLexerKt.COLON + str2, charset).a();
    }
}