package net.nfet.flutter.printing;

/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public final class R {

    public static final class xml {
        public static final int flutter_printing_file_paths = 0x7f160006;

        private xml() {
        }
    }

    private R() {
    }
}