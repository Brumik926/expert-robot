package net.nfet.flutter.printing;

import android.content.Context;
import android.print.PrintAttributes;
import h.ap;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import java.util.ArrayList;
import java.util.HashMap;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class PrintingHandler implements MethodChannel.MethodCallHandler {
    private final Context g;
    private final MethodChannel h;

    PrintingHandler(Context context, MethodChannel methodChannel) {
        this.g = context;
        this.h = methodChannel;
    }

    public void a(MethodCall methodCall, MethodChannel.Result result) {
        byte b = 1;
        String str = methodCall.a;
        str.getClass();
        switch (str.hashCode()) {
            case -1166349563:
                b = !str.equals(ap.a(767231775)) ? (byte) -1 : (byte) 0;
                break;
            case -1084323842:
                if (!str.equals(ap.a(1834770313))) {
                    b = -1;
                }
                break;
            case -743774061:
                b = !str.equals(ap.a(219443269)) ? (byte) -1 : (byte) 2;
                break;
            case -236026315:
                b = !str.equals(ap.a(1362012312)) ? (byte) -1 : (byte) 3;
                break;
            case 420548707:
                b = !str.equals(ap.a(894134347)) ? (byte) -1 : (byte) 4;
                break;
            case 476556003:
                b = !str.equals(ap.a(1933948143)) ? (byte) -1 : (byte) 5;
                break;
            default:
                b = -1;
                break;
        }
        String strA = ap.a(1479768206);
        String strA2 = ap.a(1581315621);
        String strA3 = ap.a(1776856682);
        String strA4 = ap.a(1765874118);
        String strA5 = ap.a(1300095966);
        switch (b) {
            case 0:
                new PrintingJob(this.g, this, ((Integer) methodCall.a(strA5)).intValue()).n((String) methodCall.a(strA3), (Double) methodCall.a(strA2), (Double) methodCall.a(strA));
                result.b(1);
                break;
            case 1:
                new PrintingJob(this.g, this, ((Integer) methodCall.a(strA5)).intValue()).l((String) methodCall.a(ap.a(539388217)), new PrintAttributes.MediaSize(ap.a(1543736008), ap.a(2073656829), Double.valueOf((((Double) methodCall.a(strA2)).doubleValue() * 1000.0d) / 72.0d).intValue(), Double.valueOf((((Double) methodCall.a(strA)).doubleValue() * 1000.0d) / 72.0d).intValue()), new PrintAttributes.Margins(Double.valueOf(((Double) methodCall.a(ap.a(610315523))).doubleValue() * 1000.0d).intValue(), Double.valueOf((((Double) methodCall.a(ap.a(811096223))).doubleValue() * 1000.0d) / 72.0d).intValue(), Double.valueOf((((Double) methodCall.a(ap.a(1756206672))).doubleValue() * 1000.0d) / 72.0d).intValue(), Double.valueOf((((Double) methodCall.a(ap.a(2131313121))).doubleValue() * 1000.0d) / 72.0d).intValue()), (String) methodCall.a(ap.a(1658871978)));
                result.b(1);
                break;
            case 2:
                PrintingJob.r(this.g, (byte[]) methodCall.a(strA4), (String) methodCall.a(strA3), (String) methodCall.a(ap.a(1734205092)), (String) methodCall.a(ap.a(650855838)), (ArrayList) methodCall.a(ap.a(1901043767)));
                result.b(1);
                break;
            case 3:
                new PrintingJob(this.g, this, ((Integer) methodCall.a(strA5)).intValue()).p((byte[]) methodCall.a(strA4), (ArrayList) methodCall.a(ap.a(138053562)), (Double) methodCall.a(ap.a(1163069129)));
                result.b(1);
                break;
            case 4:
                result.b(PrintingJob.o());
                break;
            case 5:
                new PrintingJob(this.g, this, ((Integer) methodCall.a(strA5)).intValue()).k(null);
                result.b(1);
                break;
            default:
                result.a();
                break;
        }
    }

    void b(PrintingJob printingJob, boolean z, String str) {
        HashMap map = new HashMap();
        map.put("completed", Boolean.valueOf(z));
        map.put("error", str);
        map.put("job", Integer.valueOf(printingJob.g));
        this.h.c("onCompleted", map);
    }

    void c(PrintingJob printingJob, String str) {
        HashMap map = new HashMap();
        map.put("error", str);
        map.put("job", Integer.valueOf(printingJob.g));
        this.h.c("onHtmlError", map);
    }

    void d(PrintingJob printingJob, byte[] bArr) {
        HashMap map = new HashMap();
        map.put("doc", bArr);
        map.put("job", Integer.valueOf(printingJob.g));
        this.h.c("onHtmlRendered", map);
    }

    void e(final PrintingJob printingJob, Double d, double d2, double d3, double d4, double d5, double d6) {
        HashMap map = new HashMap();
        map.put("width", d);
        map.put("height", Double.valueOf(d2));
        map.put("marginLeft", Double.valueOf(d3));
        map.put("marginTop", Double.valueOf(d4));
        map.put("marginRight", Double.valueOf(d5));
        map.put("marginBottom", Double.valueOf(d6));
        map.put("job", Integer.valueOf(printingJob.g));
        this.h.d("onLayout", map, new MethodChannel.Result() { // from class: net.nfet.flutter.printing.PrintingHandler.1
            public void a() {
                printingJob.k(ap.a(1123121165));
            }

            public void b(Object obj) {
                if (obj instanceof byte[]) {
                    printingJob.q((byte[]) obj);
                } else {
                    printingJob.k("Unknown data received");
                }
            }

            public void c(String str, String str2, Object obj) {
                printingJob.k(str2);
            }
        });
    }

    void f(PrintingJob printingJob, String str) {
        HashMap map = new HashMap();
        map.put("job", Integer.valueOf(printingJob.g));
        if (str != null) {
            map.put("error", str);
        }
        this.h.c("onPageRasterEnd", map);
    }

    void g(PrintingJob printingJob, byte[] bArr, int i, int i2) {
        HashMap map = new HashMap();
        map.put("image", bArr);
        map.put("width", Integer.valueOf(i));
        map.put("height", Integer.valueOf(i2));
        map.put("job", Integer.valueOf(printingJob.g));
        this.h.c("onPageRasterized", map);
    }
}