package net.nfet.flutter.printing;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PdfConvert;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintJob;
import android.print.PrintManager;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.RequiresApi;
import androidx.core.content.FileProvider;
import h.ap;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.Thread;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.apache.tika.pipes.PipesConfigBase;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@RequiresApi
public class PrintingJob extends PrintDocumentAdapter {
    private static PrintManager h;
    private final Context a;
    private final PrintingHandler b;
    private PrintJob c;
    private byte[] d;
    private String e;
    private PrintDocumentAdapter.LayoutResultCallback f;
    int g;

    PrintingJob(Context context, PrintingHandler printingHandler, int i) {
        this.a = context;
        this.b = printingHandler;
        this.g = i;
        h = (PrintManager) context.getSystemService(ap.a(2123873249));
    }

    public static /* synthetic */ void a(PrintingJob printingJob, Exception exc) {
        PrintingHandler printingHandler = printingJob.b;
        PrintJob printJob = printingJob.c;
        printingHandler.b(printingJob, printJob != null && printJob.isCompleted(), exc.getMessage());
    }

    public static /* synthetic */ void c(final PrintingJob printingJob) {
        final boolean[] zArr;
        int i;
        printingJob.getClass();
        try {
            zArr = new boolean[]{true};
            i = 3000;
        } catch (Exception e) {
            new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: net.nfet.flutter.printing.e
                @Override // java.lang.Runnable
                public final void run() {
                    PrintingJob.a(this.a, e);
                }
            });
        }
        while (zArr[0]) {
            new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: net.nfet.flutter.printing.d
                @Override // java.lang.Runnable
                public final void run() {
                    PrintingJob.f(this.a, zArr);
                }
            });
            i--;
            if (i <= 0) {
                throw new Exception("Timeout waiting for the job to finish");
            }
            if (zArr[0]) {
                Thread.sleep(200L);
            }
            printingJob.c = null;
        }
        printingJob.c = null;
    }

    public static /* synthetic */ void d(final PrintingJob printingJob, byte[] bArr, ArrayList arrayList, Double d) {
        final String message;
        printingJob.getClass();
        try {
            message = null;
            File fileCreateTempFile = File.createTempFile("printing", null, printingJob.a.getCacheDir());
            FileOutputStream fileOutputStream = new FileOutputStream(fileCreateTempFile);
            fileOutputStream.write(bArr);
            fileOutputStream.close();
            FileInputStream fileInputStream = new FileInputStream(fileCreateTempFile);
            PdfRenderer pdfRenderer = new PdfRenderer(ParcelFileDescriptor.dup(fileInputStream.getFD()));
            if (!fileCreateTempFile.delete()) {
                Log.e("PDF", "Unable to delete temporary file");
            }
            int size = arrayList != null ? arrayList.size() : pdfRenderer.getPageCount();
            for (int i = 0; i < size; i++) {
                PdfRenderer.Page pageOpenPage = pdfRenderer.openPage(arrayList == null ? i : ((Integer) arrayList.get(i)).intValue());
                final int iIntValue = Double.valueOf(((double) pageOpenPage.getWidth()) * d.doubleValue()).intValue();
                final int iIntValue2 = Double.valueOf(((double) pageOpenPage.getHeight()) * d.doubleValue()).intValue();
                Matrix matrix = new Matrix();
                matrix.setScale(d.floatValue(), d.floatValue());
                Bitmap bitmapCreateBitmap = Bitmap.createBitmap(iIntValue, iIntValue2, Bitmap.Config.ARGB_8888);
                pageOpenPage.render(bitmapCreateBitmap, null, matrix, 1);
                pageOpenPage.close();
                final ByteBuffer byteBufferAllocate = ByteBuffer.allocate(iIntValue * 4 * iIntValue2);
                bitmapCreateBitmap.copyPixelsToBuffer(byteBufferAllocate);
                bitmapCreateBitmap.recycle();
                new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: net.nfet.flutter.printing.f
                    @Override // java.lang.Runnable
                    public final void run() {
                        PrintingJob printingJob2 = this.a;
                        printingJob2.b.g(printingJob2, byteBufferAllocate.array(), iIntValue, iIntValue2);
                    }
                });
            }
            pdfRenderer.close();
            fileInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
            message = e.getMessage();
        }
        new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: net.nfet.flutter.printing.g
            @Override // java.lang.Runnable
            public final void run() {
                PrintingJob printingJob2 = this.a;
                printingJob2.b.f(printingJob2, message);
            }
        });
    }

    public static /* synthetic */ void f(PrintingJob printingJob, boolean[] zArr) {
        PrintJob printJob = printingJob.c;
        int state = printJob == null ? 6 : printJob.getInfo().getState();
        if (state == 5) {
            printingJob.b.b(printingJob, true, null);
            zArr[0] = false;
        } else if (state == 7) {
            printingJob.b.b(printingJob, false, null);
            zArr[0] = false;
        } else if (state == 6) {
            printingJob.b.b(printingJob, false, "Unable to print");
            zArr[0] = false;
        }
    }

    public static /* synthetic */ void h(final PrintingJob printingJob, Thread thread, Throwable th) {
        printingJob.getClass();
        final String message = th.getMessage();
        new Handler(Looper.getMainLooper()).post(new Runnable() { // from class: net.nfet.flutter.printing.h
            @Override // java.lang.Runnable
            public final void run() {
                PrintingJob printingJob2 = this.a;
                printingJob2.b.f(printingJob2, message);
            }
        });
    }

    static HashMap o() {
        HashMap map = new HashMap();
        map.put("directPrint", Boolean.FALSE);
        map.put("dynamicLayout", true);
        map.put("canPrint", true);
        map.put("canShare", Boolean.TRUE);
        map.put("canRaster", true);
        return map;
    }

    static void r(Context context, byte[] bArr, String str, String str2, String str3, ArrayList arrayList) {
        try {
            File file = new File(context.getCacheDir(), "share");
            if (!file.exists() && !file.mkdirs()) {
                throw new IOException("Unable to create cache directory");
            }
            File file2 = new File(file, str);
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            fileOutputStream.write(bArr);
            fileOutputStream.close();
            Uri uriForFile = FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName() + ".flutter.printing", file2);
            Intent intent = new Intent();
            intent.setAction("android.intent.action.SEND");
            intent.setType("application/pdf");
            intent.putExtra("android.intent.extra.STREAM", uriForFile);
            intent.addFlags(1);
            intent.putExtra("android.intent.extra.SUBJECT", str2);
            intent.putExtra("android.intent.extra.TEXT", str3);
            intent.putExtra("android.intent.extra.EMAIL", arrayList != null ? (String[]) arrayList.toArray(new String[0]) : null);
            Intent intentCreateChooser = Intent.createChooser(intent, null);
            Iterator<ResolveInfo> it = context.getPackageManager().queryIntentActivities(intentCreateChooser, 65536).iterator();
            while (it.hasNext()) {
                context.grantUriPermission(it.next().activityInfo.packageName, uriForFile, 3);
            }
            context.startActivity(intentCreateChooser);
            file2.deleteOnExit();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    void k(String str) {
        PrintDocumentAdapter.LayoutResultCallback layoutResultCallback = this.f;
        if (layoutResultCallback != null) {
            layoutResultCallback.onLayoutCancelled();
        }
        PrintJob printJob = this.c;
        if (printJob != null) {
            printJob.cancel();
        }
        this.b.b(this, false, str);
    }

    void l(String str, final PrintAttributes.MediaSize mediaSize, final PrintAttributes.Margins margins, String str2) {
        Configuration configuration = this.a.getResources().getConfiguration();
        configuration.fontScale = 1.0f;
        final WebView webView = new WebView(this.a.createConfigurationContext(configuration));
        webView.loadDataWithBaseURL(str2, str, "text/HTML", "UTF-8", null);
        webView.setWebViewClient(new WebViewClient() { // from class: net.nfet.flutter.printing.PrintingJob.1
            @Override // android.webkit.WebViewClient
            public void onPageFinished(WebView webView2, String str3) {
                super.onPageFinished(webView2, str3);
                PrintAttributes.Builder mediaSize2 = new PrintAttributes.Builder().setMediaSize(mediaSize);
                String strA = ap.a(1576630103);
                PrintAttributes printAttributesBuild = mediaSize2.setResolution(new PrintAttributes.Resolution(strA, strA, PipesConfigBase.DEFAULT_STALE_FETCHER_TIMEOUT_SECONDS, PipesConfigBase.DEFAULT_STALE_FETCHER_TIMEOUT_SECONDS)).setMinMargins(margins).build();
                PdfConvert.a(PrintingJob.this.a, webView.createPrintDocumentAdapter(ap.a(1409190245)), printAttributesBuild, new PdfConvert.Result() { // from class: net.nfet.flutter.printing.PrintingJob.1.1
                    public void a(File file) {
                        try {
                            PrintingJob.this.b.d(PrintingJob.this, PdfConvert.b(file));
                        } catch (IOException e) {
                            onError(e.getMessage());
                        }
                    }

                    public void onError(String str4) {
                        PrintingJob.this.b.c(PrintingJob.this, str4);
                    }
                });
            }
        });
    }

    List m() {
        ArrayList arrayList = new ArrayList();
        arrayList.add(PrintAttributes.MediaSize.ISO_A0);
        arrayList.add(PrintAttributes.MediaSize.ISO_A1);
        arrayList.add(PrintAttributes.MediaSize.ISO_A2);
        arrayList.add(PrintAttributes.MediaSize.ISO_A3);
        arrayList.add(PrintAttributes.MediaSize.ISO_A4);
        arrayList.add(PrintAttributes.MediaSize.ISO_A5);
        arrayList.add(PrintAttributes.MediaSize.ISO_A6);
        arrayList.add(PrintAttributes.MediaSize.ISO_A7);
        arrayList.add(PrintAttributes.MediaSize.ISO_A8);
        arrayList.add(PrintAttributes.MediaSize.ISO_A9);
        arrayList.add(PrintAttributes.MediaSize.ISO_A10);
        arrayList.add(PrintAttributes.MediaSize.ISO_B0);
        arrayList.add(PrintAttributes.MediaSize.ISO_B1);
        arrayList.add(PrintAttributes.MediaSize.ISO_B2);
        arrayList.add(PrintAttributes.MediaSize.ISO_B3);
        arrayList.add(PrintAttributes.MediaSize.ISO_B4);
        arrayList.add(PrintAttributes.MediaSize.ISO_B5);
        arrayList.add(PrintAttributes.MediaSize.ISO_B6);
        arrayList.add(PrintAttributes.MediaSize.ISO_B7);
        arrayList.add(PrintAttributes.MediaSize.ISO_B8);
        arrayList.add(PrintAttributes.MediaSize.ISO_B9);
        arrayList.add(PrintAttributes.MediaSize.ISO_B10);
        arrayList.add(PrintAttributes.MediaSize.ISO_C0);
        arrayList.add(PrintAttributes.MediaSize.ISO_C1);
        arrayList.add(PrintAttributes.MediaSize.ISO_C2);
        arrayList.add(PrintAttributes.MediaSize.ISO_C3);
        arrayList.add(PrintAttributes.MediaSize.ISO_C4);
        arrayList.add(PrintAttributes.MediaSize.ISO_C5);
        arrayList.add(PrintAttributes.MediaSize.ISO_C6);
        arrayList.add(PrintAttributes.MediaSize.ISO_C7);
        arrayList.add(PrintAttributes.MediaSize.ISO_C8);
        arrayList.add(PrintAttributes.MediaSize.ISO_C9);
        arrayList.add(PrintAttributes.MediaSize.ISO_C10);
        arrayList.add(PrintAttributes.MediaSize.NA_LETTER);
        arrayList.add(PrintAttributes.MediaSize.NA_GOVT_LETTER);
        arrayList.add(PrintAttributes.MediaSize.NA_LEGAL);
        arrayList.add(PrintAttributes.MediaSize.NA_JUNIOR_LEGAL);
        arrayList.add(PrintAttributes.MediaSize.NA_LEDGER);
        arrayList.add(PrintAttributes.MediaSize.NA_TABLOID);
        arrayList.add(PrintAttributes.MediaSize.NA_INDEX_3X5);
        arrayList.add(PrintAttributes.MediaSize.NA_INDEX_4X6);
        arrayList.add(PrintAttributes.MediaSize.NA_INDEX_5X8);
        arrayList.add(PrintAttributes.MediaSize.NA_MONARCH);
        arrayList.add(PrintAttributes.MediaSize.NA_QUARTO);
        arrayList.add(PrintAttributes.MediaSize.NA_FOOLSCAP);
        arrayList.add(PrintAttributes.MediaSize.ROC_8K);
        arrayList.add(PrintAttributes.MediaSize.ROC_16K);
        arrayList.add(PrintAttributes.MediaSize.PRC_1);
        arrayList.add(PrintAttributes.MediaSize.PRC_2);
        arrayList.add(PrintAttributes.MediaSize.PRC_3);
        arrayList.add(PrintAttributes.MediaSize.PRC_4);
        arrayList.add(PrintAttributes.MediaSize.PRC_5);
        arrayList.add(PrintAttributes.MediaSize.PRC_6);
        arrayList.add(PrintAttributes.MediaSize.PRC_7);
        arrayList.add(PrintAttributes.MediaSize.PRC_8);
        arrayList.add(PrintAttributes.MediaSize.PRC_9);
        arrayList.add(PrintAttributes.MediaSize.PRC_10);
        arrayList.add(PrintAttributes.MediaSize.PRC_16K);
        arrayList.add(PrintAttributes.MediaSize.OM_PA_KAI);
        arrayList.add(PrintAttributes.MediaSize.OM_DAI_PA_KAI);
        arrayList.add(PrintAttributes.MediaSize.OM_JUURO_KU_KAI);
        arrayList.add(PrintAttributes.MediaSize.JIS_B10);
        arrayList.add(PrintAttributes.MediaSize.JIS_B9);
        arrayList.add(PrintAttributes.MediaSize.JIS_B8);
        arrayList.add(PrintAttributes.MediaSize.JIS_B7);
        arrayList.add(PrintAttributes.MediaSize.JIS_B6);
        arrayList.add(PrintAttributes.MediaSize.JIS_B5);
        arrayList.add(PrintAttributes.MediaSize.JIS_B4);
        arrayList.add(PrintAttributes.MediaSize.JIS_B3);
        arrayList.add(PrintAttributes.MediaSize.JIS_B2);
        arrayList.add(PrintAttributes.MediaSize.JIS_B1);
        arrayList.add(PrintAttributes.MediaSize.JIS_B0);
        arrayList.add(PrintAttributes.MediaSize.JIS_EXEC);
        arrayList.add(PrintAttributes.MediaSize.JPN_CHOU4);
        arrayList.add(PrintAttributes.MediaSize.JPN_CHOU3);
        arrayList.add(PrintAttributes.MediaSize.JPN_CHOU2);
        arrayList.add(PrintAttributes.MediaSize.JPN_HAGAKI);
        arrayList.add(PrintAttributes.MediaSize.JPN_OUFUKU);
        arrayList.add(PrintAttributes.MediaSize.JPN_KAHU);
        arrayList.add(PrintAttributes.MediaSize.JPN_KAKU2);
        arrayList.add(PrintAttributes.MediaSize.JPN_YOU4);
        return arrayList;
    }

    void n(String str, Double d, Double d2) {
        PrintAttributes.MediaSize mediaSizeAsPortrait;
        this.e = str;
        PrintAttributes.Builder builder = new PrintAttributes.Builder();
        int iIntValue = Double.valueOf((d.doubleValue() * 1000.0d) / 72.0d).intValue();
        int iIntValue2 = Double.valueOf((d2.doubleValue() * 1000.0d) / 72.0d).intValue();
        boolean z = iIntValue2 >= iIntValue;
        Iterator it = m().iterator();
        while (true) {
            if (!it.hasNext()) {
                mediaSizeAsPortrait = null;
                break;
            }
            PrintAttributes.MediaSize mediaSize = (PrintAttributes.MediaSize) it.next();
            mediaSizeAsPortrait = z ? mediaSize.asPortrait() : mediaSize.asLandscape();
            if (iIntValue + 20 >= mediaSizeAsPortrait.getWidthMils() && iIntValue - 20 <= mediaSizeAsPortrait.getWidthMils() && iIntValue2 + 20 >= mediaSizeAsPortrait.getHeightMils() && iIntValue2 - 20 <= mediaSizeAsPortrait.getHeightMils()) {
                break;
            }
        }
        if (mediaSizeAsPortrait == null) {
            mediaSizeAsPortrait = z ? PrintAttributes.MediaSize.UNKNOWN_PORTRAIT : PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE;
        }
        builder.setMediaSize(mediaSizeAsPortrait);
        this.c = h.print(str, this, builder.build());
    }

    @Override // android.print.PrintDocumentAdapter
    public void onFinish() {
        new Thread(new Runnable() { // from class: net.nfet.flutter.printing.a
            @Override // java.lang.Runnable
            public final void run() {
                PrintingJob.c(this.a);
            }
        }).start();
    }

    @Override // android.print.PrintDocumentAdapter
    public void onLayout(PrintAttributes printAttributes, PrintAttributes printAttributes2, CancellationSignal cancellationSignal, PrintDocumentAdapter.LayoutResultCallback layoutResultCallback, Bundle bundle) {
        if (cancellationSignal.isCanceled()) {
            layoutResultCallback.onLayoutCancelled();
            return;
        }
        this.f = layoutResultCallback;
        PrintAttributes.MediaSize mediaSize = printAttributes2.getMediaSize();
        PrintAttributes.Margins minMargins = printAttributes2.getMinMargins();
        this.b.e(this, Double.valueOf((((double) mediaSize.getWidthMils()) * 72.0d) / 1000.0d), (((double) mediaSize.getHeightMils()) * 72.0d) / 1000.0d, (((double) minMargins.getLeftMils()) * 72.0d) / 1000.0d, (((double) minMargins.getTopMils()) * 72.0d) / 1000.0d, (((double) minMargins.getRightMils()) * 72.0d) / 1000.0d, (((double) minMargins.getBottomMils()) * 72.0d) / 1000.0d);
    }

    @Override // android.print.PrintDocumentAdapter
    public void onWrite(PageRange[] pageRangeArr, ParcelFileDescriptor parcelFileDescriptor, CancellationSignal cancellationSignal, PrintDocumentAdapter.WriteResultCallback writeResultCallback) throws Throwable {
        FileOutputStream fileOutputStream;
        FileOutputStream fileOutputStream2 = null;
        try {
            try {
                try {
                    fileOutputStream = new FileOutputStream(parcelFileDescriptor.getFileDescriptor());
                } catch (Throwable th) {
                    th = th;
                }
            } catch (IOException e) {
                e = e;
            }
        } catch (IOException e2) {
            e2.printStackTrace();
        }
        try {
            byte[] bArr = this.d;
            fileOutputStream.write(bArr, 0, bArr.length);
            writeResultCallback.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});
            fileOutputStream.close();
        } catch (IOException e3) {
            e = e3;
            fileOutputStream2 = fileOutputStream;
            e.printStackTrace();
            if (fileOutputStream2 != null) {
                fileOutputStream2.close();
            }
        } catch (Throwable th2) {
            th = th2;
            fileOutputStream2 = fileOutputStream;
            if (fileOutputStream2 != null) {
                try {
                    fileOutputStream2.close();
                } catch (IOException e4) {
                    e4.printStackTrace();
                }
            }
            throw th;
        }
    }

    void p(final byte[] bArr, final ArrayList arrayList, final Double d) {
        Thread thread = new Thread(new Runnable() { // from class: net.nfet.flutter.printing.b
            @Override // java.lang.Runnable
            public final void run() {
                PrintingJob.d(this.a, bArr, arrayList, d);
            }
        });
        thread.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() { // from class: net.nfet.flutter.printing.c
            @Override // java.lang.Thread.UncaughtExceptionHandler
            public final void uncaughtException(Thread thread2, Throwable th) {
                PrintingJob.h(this.a, thread2, th);
            }
        });
        thread.start();
    }

    void q(byte[] bArr) {
        this.d = bArr;
        this.f.onLayoutFinished(new PrintDocumentInfo.Builder(this.e).setContentType(0).build(), true);
    }
}