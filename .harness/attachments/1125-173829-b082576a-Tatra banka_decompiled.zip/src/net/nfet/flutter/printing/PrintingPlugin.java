package net.nfet.flutter.printing;

import android.app.Activity;
import android.content.Context;
import h.ap;
import io.flutter.embedding.engine.plugins.FlutterPlugin;
import io.flutter.embedding.engine.plugins.activity.ActivityAware;
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding;
import io.flutter.plugin.common.BinaryMessenger;
import io.flutter.plugin.common.MethodChannel;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
public class PrintingPlugin implements FlutterPlugin, ActivityAware {
    private Context g;
    private MethodChannel h;
    private PrintingHandler i;

    private void a(Context context) {
        if (context == null || this.h == null) {
            return;
        }
        PrintingHandler printingHandler = new PrintingHandler(context, this.h);
        this.i = printingHandler;
        this.h.e(printingHandler);
    }

    private void b(BinaryMessenger binaryMessenger) {
        this.h = new MethodChannel(binaryMessenger, ap.a(1082677743));
        if (this.g != null) {
            PrintingHandler printingHandler = new PrintingHandler(this.g, this.h);
            this.i = printingHandler;
            this.h.e(printingHandler);
        }
    }

    public void onAttachedToActivity(ActivityPluginBinding activityPluginBinding) {
        if (this.g != null) {
            this.g = null;
        }
        Activity activityH = activityPluginBinding.H();
        this.g = activityH;
        a(activityH);
    }

    public void onAttachedToEngine(FlutterPlugin.FlutterPluginBinding flutterPluginBinding) {
        this.g = flutterPluginBinding.a();
        b(flutterPluginBinding.b());
    }

    public void onDetachedFromActivity() {
        this.h.e((MethodChannel.MethodCallHandler) null);
        this.g = null;
        this.i = null;
    }

    public void onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity();
    }

    public void onDetachedFromEngine(FlutterPlugin.FlutterPluginBinding flutterPluginBinding) {
        this.h.e((MethodChannel.MethodCallHandler) null);
        this.h = null;
        this.i = null;
    }

    public void onReattachedToActivityForConfigChanges(ActivityPluginBinding activityPluginBinding) {
        this.g = null;
        Activity activityH = activityPluginBinding.H();
        this.g = activityH;
        a(activityH);
    }
}