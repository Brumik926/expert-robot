package defpackage;

import androidx.annotation.Keep;
import androidx.compose.runtime.internal.StabilityInferred;
import com.google.gson.annotations.SerializedName;
import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@StabilityInferred
@Keep
@Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001B\u000f\u0012\u0006\u0010\u0002\u001a\u00020\u0003¢\u0006\u0004\b\u0004\u0010\u0005J\t\u0010\b\u001a\u00020\u0003HÆ\u0003J\u0013\u0010\t\u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u0003HÆ\u0001J\u0013\u0010\n\u001a\u00020\u000b2\b\u0010\f\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010\r\u001a\u00020\u000eHÖ\u0001J\t\u0010\u000f\u001a\u00020\u0003HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0006\u0010\u0007¨\u0006\u0010"}, d2 = {"LTalkAgentResponse;", "", "vADataPass", "", "<init>", "(Ljava/lang/String;)V", "getVADataPass", "()Ljava/lang/String;", "component1", "copy", "equals", "", "other", "hashCode", "", "toString", "tatra-mobile_clientRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class TalkAgentResponse {
    public static final int $stable = 0;

    @SerializedName("VADataPass")
    @NotNull
    private final String vADataPass;

    public TalkAgentResponse(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, ap.a(717316922));
        this.vADataPass = str;
    }

    public static /* synthetic */ TalkAgentResponse copy$default(TalkAgentResponse talkAgentResponse, String str, int i, Object obj) {
        if ((i & 1) != 0) {
            str = talkAgentResponse.vADataPass;
        }
        return talkAgentResponse.copy(str);
    }

    @NotNull
    public final String component1() {
        return this.vADataPass;
    }

    @NotNull
    public final TalkAgentResponse copy(@NotNull String str) {
        Intrinsics.checkNotNullParameter(str, "vADataPass");
        return new TalkAgentResponse(str);
    }

    public boolean equals(@Nullable Object obj) {
        if (this == obj) {
            return true;
        }
        return (obj instanceof TalkAgentResponse) && Intrinsics.areEqual(this.vADataPass, ((TalkAgentResponse) obj).vADataPass);
    }

    @NotNull
    public final String getVADataPass() {
        return this.vADataPass;
    }

    public int hashCode() {
        return this.vADataPass.hashCode();
    }

    @NotNull
    public String toString() {
        return "TalkAgentResponse(vADataPass=" + this.vADataPass + ")";
    }
}