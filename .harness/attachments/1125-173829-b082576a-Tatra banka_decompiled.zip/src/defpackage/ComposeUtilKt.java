package defpackage;

import android.content.res.Configuration;
import androidx.compose.foundation.layout.BoxKt;
import androidx.compose.foundation.layout.BoxScopeInstance;
import androidx.compose.foundation.layout.SizeKt;
import androidx.compose.material.TextKt;
import androidx.compose.runtime.ComposablesKt;
import androidx.compose.runtime.Composer;
import androidx.compose.runtime.ComposerKt;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.runtime.RecomposeScopeImplKt;
import androidx.compose.runtime.ScopeUpdateScope;
import androidx.compose.runtime.Updater;
import androidx.compose.ui.Alignment;
import androidx.compose.ui.ComposedModifierKt;
import androidx.compose.ui.Modifier;
import androidx.compose.ui.draw.DrawModifierKt;
import androidx.compose.ui.geometry.OffsetKt;
import androidx.compose.ui.geometry.Size;
import androidx.compose.ui.graphics.AndroidPaint_androidKt;
import androidx.compose.ui.graphics.Canvas;
import androidx.compose.ui.graphics.Color;
import androidx.compose.ui.graphics.ColorKt;
import androidx.compose.ui.graphics.Paint;
import androidx.compose.ui.graphics.Shadow;
import androidx.compose.ui.graphics.drawscope.DrawScope;
import androidx.compose.ui.graphics.drawscope.DrawStyle;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode;
import androidx.compose.ui.platform.AndroidCompositionLocals_androidKt;
import androidx.compose.ui.text.PlatformTextStyle;
import androidx.compose.ui.text.TextStyle;
import androidx.compose.ui.text.font.Font;
import androidx.compose.ui.text.font.FontFamily;
import androidx.compose.ui.text.font.FontFamilyKt;
import androidx.compose.ui.text.font.FontKt;
import androidx.compose.ui.text.font.FontStyle;
import androidx.compose.ui.text.font.FontSynthesis;
import androidx.compose.ui.text.font.FontWeight;
import androidx.compose.ui.text.intl.LocaleList;
import androidx.compose.ui.text.style.BaselineShift;
import androidx.compose.ui.text.style.LineHeightStyle;
import androidx.compose.ui.text.style.TextAlign;
import androidx.compose.ui.text.style.TextDecoration;
import androidx.compose.ui.text.style.TextGeometricTransform;
import androidx.compose.ui.text.style.TextIndent;
import androidx.compose.ui.text.style.TextMotion;
import androidx.compose.ui.unit.Dp;
import androidx.compose.ui.unit.TextUnit;
import androidx.compose.ui.unit.TextUnitKt;
import com.unblu.sdk.core.R;
import h.ap;
import kotlin.Metadata;
import kotlin.NoWhenBranchMatchedException;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000,\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0007\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u000b\u001a*\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0001\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H\u0007ø\u0001\u0000¢\u0006\u0004\b\u0007\u0010\b\u001aR\u0010\u0011\u001a\u00020\t*\u00020\t2\b\b\u0002\u0010\u0003\u001a\u00020\u00022\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\r\u001a\u00020\f2\b\b\u0002\u0010\u000e\u001a\u00020\f2\b\b\u0002\u0010\u000f\u001a\u00020\f2\b\b\u0002\u0010\u0010\u001a\u00020\fH\u0007ø\u0001\u0000¢\u0006\u0004\b\u0011\u0010\u0012\u001a4\u0010\u0013\u001a\u00020\t*\u00020\t2\b\b\u0002\u0010\u0003\u001a\u00020\u00022\b\b\u0002\u0010\u000b\u001a\u00020\n2\b\b\u0002\u0010\u000e\u001a\u00020\fH\u0007ø\u0001\u0000¢\u0006\u0004\b\u0013\u0010\u0014\"\u0015\u0010\u0003\u001a\u00020\u0002*\u00020\u00008F¢\u0006\u0006\u001a\u0004\b\u0015\u0010\u0016\u0082\u0002\u0007\n\u0005\b¡\u001e0\u0001¨\u0006\u0017"}, d2 = {"", "text", "Landroidx/compose/ui/graphics/Color;", "color", "LTextType;", "textType", "", "a", "(Ljava/lang/String;JLTextType;Landroidx/compose/runtime/Composer;I)V", "Landroidx/compose/ui/Modifier;", "", "alpha", "Landroidx/compose/ui/unit/Dp;", "cornersRadius", "shadowBlurRadius", "offsetY", "offsetX", "d", "(Landroidx/compose/ui/Modifier;JFFFFF)Landroidx/compose/ui/Modifier;", "b", "(Landroidx/compose/ui/Modifier;JFF)Landroidx/compose/ui/Modifier;", "f", "(Ljava/lang/String;)J", "coresdk_release"}, k = 2, mv = {1, 9, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nComposeUtil.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ComposeUtil.kt\nComposeUtilKt\n+ 2 CompositionLocal.kt\nandroidx/compose/runtime/CompositionLocal\n+ 3 TextUnit.kt\nandroidx/compose/ui/unit/TextUnit\n+ 4 Dp.kt\nandroidx/compose/ui/unit/DpKt\n+ 5 Box.kt\nandroidx/compose/foundation/layout/BoxKt\n+ 6 Layout.kt\nandroidx/compose/ui/layout/LayoutKt\n+ 7 Composables.kt\nandroidx/compose/runtime/ComposablesKt\n+ 8 Composer.kt\nandroidx/compose/runtime/Updater\n*L\n1#1,163:1\n75#2:164\n147#3,2:165\n148#4:167\n148#4:168\n148#4:208\n148#4:209\n148#4:210\n148#4:211\n148#4:212\n71#5:169\n69#5,5:170\n74#5:203\n78#5:207\n78#6,6:175\n85#6,4:190\n89#6,2:200\n93#6:206\n368#7,9:181\n377#7:202\n378#7,2:204\n4032#8,6:194\n*S KotlinDebug\n*F\n+ 1 ComposeUtil.kt\nComposeUtilKt\n*L\n41#1:164\n53#1:165,2\n60#1:167\n61#1:168\n105#1:208\n106#1:209\n107#1:210\n108#1:211\n139#1:212\n58#1:169\n58#1:170,5\n58#1:203\n58#1:207\n58#1:175,6\n58#1:190,4\n58#1:200,2\n58#1:206\n58#1:181,9\n58#1:202\n58#1:204,2\n58#1:194,6\n*E\n"})
public final class ComposeUtilKt {

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(k = 3, mv = {1, 9, 0}, xi = 48)
    public /* synthetic */ class WhenMappings {
        public static final /* synthetic */ int[] a;

        static {
            int[] iArr = new int[TextType.values().length];
            try {
                iArr[TextType.a.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                iArr[TextType.b.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
            a = iArr;
        }
    }

    /* JADX INFO: Thrown type has an unknown type hierarchy: kotlin.NoWhenBranchMatchedException */
    public static final void a(final String str, final long j, final TextType textType, Composer composer, final int i) throws NoWhenBranchMatchedException {
        int i2;
        Pair pair;
        Composer composer2;
        Intrinsics.checkNotNullParameter(str, ap.a(787091957));
        Intrinsics.checkNotNullParameter(textType, ap.a(437007592));
        Composer composerZ = composer.z(-565649654);
        if ((i & 14) == 0) {
            i2 = (composerZ.r(str) ? 4 : 2) | i;
        } else {
            i2 = i;
        }
        if ((i & 112) == 0) {
            i2 |= composerZ.x(j) ? 32 : 16;
        }
        if ((i & 896) == 0) {
            i2 |= composerZ.r(textType) ? 256 : 128;
        }
        if ((i2 & 731) == 146 && composerZ.b()) {
            composerZ.m();
            composer2 = composerZ;
        } else {
            if (ComposerKt.P()) {
                ComposerKt.Y(-565649654, i2, -1, ap.a(565118072));
            }
            int i3 = (int) (((double) ((Configuration) composerZ.D(AndroidCompositionLocals_androidKt.f())).screenWidthDp) * 0.8d);
            int i4 = WhenMappings.a[textType.ordinal()];
            if (i4 == 1) {
                pair = TuplesKt.to(TextUnit.b(TextUnitKt.i(40)), 10);
            } else {
                if (i4 != 2) {
                    throw new NoWhenBranchMatchedException();
                }
                pair = TuplesKt.to(TextUnit.b(TextUnitKt.i(25)), 15);
            }
            long jL = ((TextUnit) pair.component1()).l();
            int iIntValue = ((Number) pair.component2()).intValue();
            if (str.length() > iIntValue) {
                TextUnitKt.b(jL);
                jL = TextUnitKt.k(TextUnit.f(jL), TextUnit.h(jL) * (iIntValue / str.length()));
            }
            Modifier modifierY = SizeKt.y(SizeKt.i(Modifier.b0, Dp.g(50)), Dp.g(i3));
            MeasurePolicy measurePolicyI = BoxKt.i(Alignment.a.e(), false);
            int iA = ComposablesKt.a(composerZ, 0);
            CompositionLocalMap compositionLocalMapF = composerZ.f();
            Modifier modifierE = ComposedModifierKt.e(composerZ, modifierY);
            ComposeUiNode.Companion companion = ComposeUiNode.f0;
            Function0 function0A = companion.a();
            if (composerZ.A() == null) {
                ComposablesKt.d();
            }
            composerZ.k();
            if (composerZ.y()) {
                composerZ.S(function0A);
            } else {
                composerZ.g();
            }
            Composer composerB = Updater.b(composerZ);
            Updater.g(composerB, measurePolicyI, companion.c());
            Updater.g(composerB, compositionLocalMapF, companion.e());
            Function2 function2B = companion.b();
            if (composerB.y() || !Intrinsics.areEqual(composerB.M(), Integer.valueOf(iA))) {
                composerB.F(Integer.valueOf(iA));
                composerB.c(Integer.valueOf(iA), function2B);
            }
            Updater.g(composerB, modifierE, companion.d());
            BoxScopeInstance boxScopeInstance = BoxScopeInstance.a;
            composer2 = composerZ;
            TextKt.l(str, (Modifier) null, 0L, 0L, (FontStyle) null, (FontWeight) null, (FontFamily) null, 0L, (TextDecoration) null, (TextAlign) null, 0L, 0, false, 1, 0, (Function1) null, new TextStyle(j, jL, (FontWeight) null, (FontStyle) null, (FontSynthesis) null, FontFamilyKt.b(new Font[]{FontKt.b(R.font.rubik_medium, (FontWeight) null, 0, 0, 14, (Object) null)}), (String) null, 0L, (BaselineShift) null, (TextGeometricTransform) null, (LocaleList) null, 0L, (TextDecoration) null, (Shadow) null, (DrawStyle) null, 0, 0, 0L, (TextIndent) null, (PlatformTextStyle) null, (LineHeightStyle) null, 0, 0, (TextMotion) null, 16777180, (DefaultConstructorMarker) null), composer2, i2 & 14, 3072, 57342);
            composer2.i();
            if (ComposerKt.P()) {
                ComposerKt.X();
            }
        }
        ScopeUpdateScope scopeUpdateScopeB = composer2.B();
        if (scopeUpdateScopeB != null) {
            scopeUpdateScopeB.a(new Function2<Composer, Integer, Unit>() { // from class: ComposeUtilKt$DynamicTextSize$2
                /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
                {
                    super(2);
                }

                /* JADX INFO: Thrown type has an unknown type hierarchy: kotlin.NoWhenBranchMatchedException */
                public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) throws NoWhenBranchMatchedException {
                    invoke((Composer) obj, ((Number) obj2).intValue());
                    return Unit.INSTANCE;
                }

                /* JADX INFO: Thrown type has an unknown type hierarchy: kotlin.NoWhenBranchMatchedException */
                public final void invoke(Composer composer3, int i5) throws NoWhenBranchMatchedException {
                    ComposeUtilKt.a(str, j, textType, composer3, RecomposeScopeImplKt.a(i | 1));
                }
            });
        }
    }

    public static final Modifier b(Modifier modifier, final long j, final float f, final float f2) {
        Intrinsics.checkNotNullParameter(modifier, "$this$advancedCircularShadow");
        return DrawModifierKt.b(modifier, new Function1<DrawScope, Unit>() { // from class: ComposeUtilKt$advancedCircularShadow$1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            public final void a(DrawScope drawScope) {
                Intrinsics.checkNotNullParameter(drawScope, ap.a(499774106));
                int iJ = ColorKt.j(Color.q(j, f, 0.0f, 0.0f, 0.0f, 14, (Object) null));
                int iJ2 = ColorKt.j(Color.q(j, 0.0f, 0.0f, 0.0f, 0.0f, 14, (Object) null));
                float fJ = Size.j(drawScope.c()) / 1.8f;
                float f3 = f2;
                Canvas canvasE = drawScope.f1().e();
                Paint paintA = AndroidPaint_androidKt.a();
                android.graphics.Paint paintX = paintA.x();
                paintX.setColor(iJ2);
                paintX.setShadowLayer(drawScope.t2(f3), 0.0f, 0.0f, iJ);
                float f4 = 2;
                canvasE.x(OffsetKt.a(Size.j(drawScope.c()) / f4, fJ), (Size.j(drawScope.c()) / f4) * 0.8f, paintA);
            }

            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                a((DrawScope) obj);
                return Unit.INSTANCE;
            }
        });
    }

    public static /* synthetic */ Modifier c(Modifier modifier, long j, float f, float f2, int i, Object obj) {
        if ((i & 1) != 0) {
            j = Color.b.a();
        }
        if ((i & 2) != 0) {
            f = 1.0f;
        }
        if ((i & 4) != 0) {
            f2 = Dp.g(4);
        }
        return b(modifier, j, f, f2);
    }

    public static final Modifier d(Modifier modifier, final long j, final float f, final float f2, final float f3, final float f4, final float f5) {
        Intrinsics.checkNotNullParameter(modifier, "$this$advancedShadow");
        return DrawModifierKt.b(modifier, new Function1<DrawScope, Unit>() { // from class: ComposeUtilKt$advancedShadow$1
            /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
            {
                super(1);
            }

            public final void a(DrawScope drawScope) {
                Intrinsics.checkNotNullParameter(drawScope, ap.a(1108742762));
                int iJ = ColorKt.j(Color.q(j, f, 0.0f, 0.0f, 0.0f, 14, (Object) null));
                int iJ2 = ColorKt.j(Color.q(j, 0.0f, 0.0f, 0.0f, 0.0f, 14, (Object) null));
                float f6 = f3;
                float f7 = f5;
                float f8 = f4;
                float f9 = f2;
                Canvas canvasE = drawScope.f1().e();
                Paint paintA = AndroidPaint_androidKt.a();
                android.graphics.Paint paintX = paintA.x();
                paintX.setColor(iJ2);
                paintX.setShadowLayer(drawScope.t2(f6), drawScope.t2(f7), drawScope.t2(f8), iJ);
                canvasE.y(f6, 0.0f, Size.j(drawScope.c()), Size.g(drawScope.c()) - f6, drawScope.t2(f9), drawScope.t2(f9), paintA);
            }

            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                a((DrawScope) obj);
                return Unit.INSTANCE;
            }
        });
    }

    public static /* synthetic */ Modifier e(Modifier modifier, long j, float f, float f2, float f3, float f4, float f5, int i, Object obj) {
        if ((i & 1) != 0) {
            j = Color.b.a();
        }
        long j2 = j;
        if ((i & 2) != 0) {
            f = 1.0f;
        }
        float f6 = f;
        if ((i & 4) != 0) {
            f2 = Dp.g(0);
        }
        float f7 = f2;
        if ((i & 8) != 0) {
            f3 = Dp.g(0);
        }
        float f8 = f3;
        if ((i & 16) != 0) {
            f4 = Dp.g(0);
        }
        float f9 = f4;
        if ((i & 32) != 0) {
            f5 = Dp.g(0);
        }
        return d(modifier, j2, f6, f7, f8, f9, f5);
    }

    public static final long f(String str) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        return ColorKt.b(android.graphics.Color.parseColor(str));
    }
}