package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import h.ap;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000@\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\r\u0018\u0000 \u001f2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001 B1\u0012\n\b\u0002\u0010\u0004\u001a\u0004\u0018\u00010\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0005\u0012\b\b\u0002\u0010\t\u001a\u00020\b¢\u0006\u0004\b\n\u0010\u000bJ\u001a\u0010\u000f\u001a\u00020\u000e2\b\u0010\r\u001a\u0004\u0018\u00010\fH\u0096\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u000f\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0015\u001a\u00020\u0014H\u0016¢\u0006\u0004\b\u0015\u0010\u0016R\u001c\u0010\u0004\u001a\u0004\u0018\u00010\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0017\u0010\u0018\u001a\u0004\b\u0019\u0010\u001aR\u001a\u0010\u0006\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u0017\u0010\u001dR\u001a\u0010\u0007\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001e\u0010\u001c\u001a\u0004\b\u001b\u0010\u001d¨\u0006!"}, d2 = {"LStackHistoryBufferEntry;", "Lcom/squareup/wire/Message;", "", "LBacktraceFrame;", "addr", "", "fp", "tag", "Lokio/ByteString;", "unknownFields", "<init>", "(LBacktraceFrame;JJLokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "", "toString", "()Ljava/lang/String;", "f", "LBacktraceFrame;", "e", "()LBacktraceFrame;", "g", "J", "()J", "h", "i", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class StackHistoryBufferEntry extends Message {
    public static final Companion i = new Companion(null);
    public static final ProtoAdapter j;
    private final BacktraceFrame f;
    private final long g;
    private final long h;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LStackHistoryBufferEntry$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LStackHistoryBufferEntry;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(StackHistoryBufferEntry.class);
        final Syntax syntax = Syntax.d;
        j = new ProtoAdapter<StackHistoryBufferEntry>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: StackHistoryBufferEntry$Companion$ADAPTER$1
            {
                String strA = ap.a(1135911544);
                String strA2 = ap.a(1033248378);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public StackHistoryBufferEntry d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                long jD = protoReader.d();
                Object objD = null;
                long jLongValue = 0;
                long jLongValue2 = 0;
                while (true) {
                    int i2 = protoReader.i();
                    if (i2 == -1) {
                        return new StackHistoryBufferEntry((BacktraceFrame) objD, jLongValue, jLongValue2, protoReader.f(jD));
                    }
                    if (i2 == 1) {
                        objD = BacktraceFrame.o.d(protoReader);
                    } else if (i2 == 2) {
                        jLongValue = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                    } else if (i2 != 3) {
                        protoReader.p(i2);
                    } else {
                        jLongValue2 = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, StackHistoryBufferEntry stackHistoryBufferEntry) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(stackHistoryBufferEntry, "value");
                if (stackHistoryBufferEntry.e() != null) {
                    BacktraceFrame.o.l(protoWriter, 1, stackHistoryBufferEntry.e());
                }
                if (stackHistoryBufferEntry.f() != 0) {
                    ProtoAdapter.w.l(protoWriter, 2, Long.valueOf(stackHistoryBufferEntry.f()));
                }
                if (stackHistoryBufferEntry.g() != 0) {
                    ProtoAdapter.w.l(protoWriter, 3, Long.valueOf(stackHistoryBufferEntry.g()));
                }
                protoWriter.a(stackHistoryBufferEntry.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, StackHistoryBufferEntry stackHistoryBufferEntry) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(stackHistoryBufferEntry, "value");
                reverseProtoWriter.j(stackHistoryBufferEntry.d());
                if (stackHistoryBufferEntry.g() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 3, Long.valueOf(stackHistoryBufferEntry.g()));
                }
                if (stackHistoryBufferEntry.f() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 2, Long.valueOf(stackHistoryBufferEntry.f()));
                }
                if (stackHistoryBufferEntry.e() != null) {
                    BacktraceFrame.o.m(reverseProtoWriter, 1, stackHistoryBufferEntry.e());
                }
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(StackHistoryBufferEntry stackHistoryBufferEntry) {
                Intrinsics.checkNotNullParameter(stackHistoryBufferEntry, "value");
                int size = stackHistoryBufferEntry.d().size();
                if (stackHistoryBufferEntry.e() != null) {
                    size += BacktraceFrame.o.o(1, stackHistoryBufferEntry.e());
                }
                if (stackHistoryBufferEntry.f() != 0) {
                    size += ProtoAdapter.w.o(2, Long.valueOf(stackHistoryBufferEntry.f()));
                }
                return stackHistoryBufferEntry.g() != 0 ? size + ProtoAdapter.w.o(3, Long.valueOf(stackHistoryBufferEntry.g())) : size;
            }
        };
    }

    public StackHistoryBufferEntry() {
        this(null, 0L, 0L, null, 15, null);
    }

    public final BacktraceFrame e() {
        return this.f;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof StackHistoryBufferEntry)) {
            return false;
        }
        StackHistoryBufferEntry stackHistoryBufferEntry = (StackHistoryBufferEntry) obj;
        return Intrinsics.areEqual(d(), stackHistoryBufferEntry.d()) && Intrinsics.areEqual(this.f, stackHistoryBufferEntry.f) && this.g == stackHistoryBufferEntry.g && this.h == stackHistoryBufferEntry.h;
    }

    public final long f() {
        return this.g;
    }

    public final long g() {
        return this.h;
    }

    public int hashCode() {
        int i2 = ((Message) this).d;
        if (i2 != 0) {
            return i2;
        }
        int iHashCode = d().hashCode() * 37;
        BacktraceFrame backtraceFrame = this.f;
        int iHashCode2 = ((((iHashCode + (backtraceFrame != null ? backtraceFrame.hashCode() : 0)) * 37) + Long.hashCode(this.g)) * 37) + Long.hashCode(this.h);
        ((Message) this).d = iHashCode2;
        return iHashCode2;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        if (this.f != null) {
            arrayList.add("addr=" + this.f);
        }
        arrayList.add("fp=" + this.g);
        arrayList.add("tag=" + this.h);
        return CollectionsKt.joinToString$default(arrayList, ", ", "StackHistoryBufferEntry{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ StackHistoryBufferEntry(BacktraceFrame backtraceFrame, long j2, long j3, ByteString byteString, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? null : backtraceFrame, (i2 & 2) != 0 ? 0L : j2, (i2 & 4) != 0 ? 0L : j3, (i2 & 8) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public StackHistoryBufferEntry(BacktraceFrame backtraceFrame, long j2, long j3, ByteString byteString) {
        super(j, byteString);
        Intrinsics.checkNotNullParameter(byteString, ap.a(272130701));
        this.f = backtraceFrame;
        this.g = j2;
        this.h = j3;
    }
}