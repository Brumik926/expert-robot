package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u001e\u0018\u0000 22\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u00013Bw\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0003\u0012\b\b\u0002\u0010\b\u001a\u00020\u0005\u0012\b\b\u0002\u0010\n\u001a\u00020\t\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\f\u001a\u00020\u0003\u0012\b\b\u0002\u0010\r\u001a\u00020\t\u0012\b\b\u0002\u0010\u000f\u001a\u00020\u000e\u0012\n\b\u0002\u0010\u0011\u001a\u0004\u0018\u00010\u0010\u0012\b\b\u0002\u0010\u0013\u001a\u00020\u0012¢\u0006\u0004\b\u0014\u0010\u0015J\u001a\u0010\u0018\u001a\u00020\t2\b\u0010\u0017\u001a\u0004\u0018\u00010\u0016H\u0096\u0002¢\u0006\u0004\b\u0018\u0010\u0019J\u000f\u0010\u001a\u001a\u00020\u0003H\u0016¢\u0006\u0004\b\u001a\u0010\u001bJ\u000f\u0010\u001c\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u001c\u0010\u001dR\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001e\u0010\u001f\u001a\u0004\b \u0010\u001bR\u001a\u0010\u0006\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b!\u0010\"\u001a\u0004\b#\u0010\u001dR\u001a\u0010\u0007\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b$\u0010\u001f\u001a\u0004\b%\u0010\u001bR\u001a\u0010\b\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b&\u0010\"\u001a\u0004\b\u001e\u0010\u001dR\u001a\u0010\n\u001a\u00020\t8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b'\u0010(\u001a\u0004\b'\u0010)R\u001a\u0010\u000b\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b \u0010\u001f\u001a\u0004\b*\u0010\u001bR\u001a\u0010\f\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b+\u0010\u001f\u001a\u0004\b+\u0010\u001bR\u001a\u0010\r\u001a\u00020\t8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b*\u0010(\u001a\u0004\b&\u0010)R\u001a\u0010\u000f\u001a\u00020\u000e8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b,\u0010-\u001a\u0004\b!\u0010.R\u001c\u0010\u0011\u001a\u0004\u0018\u00010\u00108\u0006X\u0087\u0004¢\u0006\f\n\u0004\b/\u00100\u001a\u0004\b$\u00101¨\u00064"}, d2 = {"LSignal;", "Lcom/squareup/wire/Message;", "", "", "number", "", "name", "code", "code_name", "", "has_sender", "sender_uid", "sender_pid", "has_fault_address", "", "fault_address", "LMemoryDump;", "fault_adjacent_metadata", "Lokio/ByteString;", "unknownFields", "<init>", "(ILjava/lang/String;ILjava/lang/String;ZIIZJLMemoryDump;Lokio/ByteString;)V", "", "other", "equals", "(Ljava/lang/Object;)Z", "hashCode", "()I", "toString", "()Ljava/lang/String;", "f", "I", "k", "g", "Ljava/lang/String;", "getName", "h", "e", "i", "j", "Z", "()Z", "m", "l", "n", "J", "()J", "o", "LMemoryDump;", "()LMemoryDump;", "p", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class Signal extends Message {
    public static final Companion p = new Companion(null);
    public static final ProtoAdapter q;
    private final int f;
    private final String g;
    private final int h;
    private final String i;
    private final boolean j;
    private final int k;
    private final int l;
    private final boolean m;
    private final long n;
    private final MemoryDump o;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LSignal$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LSignal;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(Signal.class);
        final Syntax syntax = Syntax.d;
        q = new ProtoAdapter<Signal>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: Signal$Companion$ADAPTER$1
            {
                String strA = ap.a(1486173627);
                String strA2 = ap.a(655149166);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public Signal d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                long jD = protoReader.d();
                Object objD = "";
                long jLongValue = 0;
                Object objD2 = null;
                int iIntValue = 0;
                int iIntValue2 = 0;
                boolean zBooleanValue = false;
                int iIntValue3 = 0;
                int iIntValue4 = 0;
                boolean zBooleanValue2 = false;
                Object objD3 = "";
                while (true) {
                    long j = jLongValue;
                    while (true) {
                        int i = protoReader.i();
                        if (i == -1) {
                            return new Signal(iIntValue, (String) objD, iIntValue2, (String) objD3, zBooleanValue, iIntValue3, iIntValue4, zBooleanValue2, j, (MemoryDump) objD2, protoReader.f(jD));
                        }
                        switch (i) {
                            case 1:
                                iIntValue = ((Number) ProtoAdapter.k.d(protoReader)).intValue();
                                break;
                            case 2:
                                objD = ProtoAdapter.J.d(protoReader);
                                break;
                            case 3:
                                iIntValue2 = ((Number) ProtoAdapter.k.d(protoReader)).intValue();
                                break;
                            case 4:
                                objD3 = ProtoAdapter.J.d(protoReader);
                                break;
                            case 5:
                                zBooleanValue = ((Boolean) ProtoAdapter.j.d(protoReader)).booleanValue();
                                break;
                            case 6:
                                iIntValue3 = ((Number) ProtoAdapter.k.d(protoReader)).intValue();
                                break;
                            case 7:
                                iIntValue4 = ((Number) ProtoAdapter.k.d(protoReader)).intValue();
                                break;
                            case 8:
                                zBooleanValue2 = ((Boolean) ProtoAdapter.j.d(protoReader)).booleanValue();
                                break;
                            case 9:
                                break;
                            case 10:
                                objD2 = MemoryDump.l.d(protoReader);
                                break;
                            default:
                                protoReader.p(i);
                                break;
                        }
                    }
                    jLongValue = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, Signal signal) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(signal, "value");
                if (signal.k() != 0) {
                    ProtoAdapter.k.l(protoWriter, 1, Integer.valueOf(signal.k()));
                }
                if (!Intrinsics.areEqual(signal.getName(), "")) {
                    ProtoAdapter.J.l(protoWriter, 2, signal.getName());
                }
                if (signal.e() != 0) {
                    ProtoAdapter.k.l(protoWriter, 3, Integer.valueOf(signal.e()));
                }
                if (!Intrinsics.areEqual(signal.f(), "")) {
                    ProtoAdapter.J.l(protoWriter, 4, signal.f());
                }
                if (signal.j()) {
                    ProtoAdapter.j.l(protoWriter, 5, Boolean.valueOf(signal.j()));
                }
                if (signal.m() != 0) {
                    ProtoAdapter.k.l(protoWriter, 6, Integer.valueOf(signal.m()));
                }
                if (signal.l() != 0) {
                    ProtoAdapter.k.l(protoWriter, 7, Integer.valueOf(signal.l()));
                }
                if (signal.i()) {
                    ProtoAdapter.j.l(protoWriter, 8, Boolean.valueOf(signal.i()));
                }
                if (signal.g() != 0) {
                    ProtoAdapter.w.l(protoWriter, 9, Long.valueOf(signal.g()));
                }
                if (signal.h() != null) {
                    MemoryDump.l.l(protoWriter, 10, signal.h());
                }
                protoWriter.a(signal.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, Signal signal) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(signal, "value");
                reverseProtoWriter.j(signal.d());
                if (signal.h() != null) {
                    MemoryDump.l.m(reverseProtoWriter, 10, signal.h());
                }
                if (signal.g() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 9, Long.valueOf(signal.g()));
                }
                if (signal.i()) {
                    ProtoAdapter.j.m(reverseProtoWriter, 8, Boolean.valueOf(signal.i()));
                }
                if (signal.l() != 0) {
                    ProtoAdapter.k.m(reverseProtoWriter, 7, Integer.valueOf(signal.l()));
                }
                if (signal.m() != 0) {
                    ProtoAdapter.k.m(reverseProtoWriter, 6, Integer.valueOf(signal.m()));
                }
                if (signal.j()) {
                    ProtoAdapter.j.m(reverseProtoWriter, 5, Boolean.valueOf(signal.j()));
                }
                if (!Intrinsics.areEqual(signal.f(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 4, signal.f());
                }
                if (signal.e() != 0) {
                    ProtoAdapter.k.m(reverseProtoWriter, 3, Integer.valueOf(signal.e()));
                }
                if (!Intrinsics.areEqual(signal.getName(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 2, signal.getName());
                }
                if (signal.k() != 0) {
                    ProtoAdapter.k.m(reverseProtoWriter, 1, Integer.valueOf(signal.k()));
                }
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(Signal signal) {
                Intrinsics.checkNotNullParameter(signal, "value");
                int size = signal.d().size();
                if (signal.k() != 0) {
                    size += ProtoAdapter.k.o(1, Integer.valueOf(signal.k()));
                }
                if (!Intrinsics.areEqual(signal.getName(), "")) {
                    size += ProtoAdapter.J.o(2, signal.getName());
                }
                if (signal.e() != 0) {
                    size += ProtoAdapter.k.o(3, Integer.valueOf(signal.e()));
                }
                if (!Intrinsics.areEqual(signal.f(), "")) {
                    size += ProtoAdapter.J.o(4, signal.f());
                }
                if (signal.j()) {
                    size += ProtoAdapter.j.o(5, Boolean.valueOf(signal.j()));
                }
                if (signal.m() != 0) {
                    size += ProtoAdapter.k.o(6, Integer.valueOf(signal.m()));
                }
                if (signal.l() != 0) {
                    size += ProtoAdapter.k.o(7, Integer.valueOf(signal.l()));
                }
                if (signal.i()) {
                    size += ProtoAdapter.j.o(8, Boolean.valueOf(signal.i()));
                }
                if (signal.g() != 0) {
                    size += ProtoAdapter.w.o(9, Long.valueOf(signal.g()));
                }
                return signal.h() != null ? size + MemoryDump.l.o(10, signal.h()) : size;
            }
        };
    }

    public Signal() {
        this(0, null, 0, null, false, 0, 0, false, 0L, null, null, 2047, null);
    }

    public final int e() {
        return this.h;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Signal)) {
            return false;
        }
        Signal signal = (Signal) obj;
        return Intrinsics.areEqual(d(), signal.d()) && this.f == signal.f && Intrinsics.areEqual(this.g, signal.g) && this.h == signal.h && Intrinsics.areEqual(this.i, signal.i) && this.j == signal.j && this.k == signal.k && this.l == signal.l && this.m == signal.m && this.n == signal.n && Intrinsics.areEqual(this.o, signal.o);
    }

    public final String f() {
        return this.i;
    }

    public final long g() {
        return this.n;
    }

    public final String getName() {
        return this.g;
    }

    public final MemoryDump h() {
        return this.o;
    }

    public int hashCode() {
        int i = ((Message) this).d;
        if (i != 0) {
            return i;
        }
        int iHashCode = ((((((((((((((((((d().hashCode() * 37) + Integer.hashCode(this.f)) * 37) + this.g.hashCode()) * 37) + Integer.hashCode(this.h)) * 37) + this.i.hashCode()) * 37) + Boolean.hashCode(this.j)) * 37) + Integer.hashCode(this.k)) * 37) + Integer.hashCode(this.l)) * 37) + Boolean.hashCode(this.m)) * 37) + Long.hashCode(this.n)) * 37;
        MemoryDump memoryDump = this.o;
        int iHashCode2 = iHashCode + (memoryDump != null ? memoryDump.hashCode() : 0);
        ((Message) this).d = iHashCode2;
        return iHashCode2;
    }

    public final boolean i() {
        return this.m;
    }

    public final boolean j() {
        return this.j;
    }

    public final int k() {
        return this.f;
    }

    public final int l() {
        return this.l;
    }

    public final int m() {
        return this.k;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("number=" + this.f);
        arrayList.add("name=" + Internal.c(this.g));
        arrayList.add("code=" + this.h);
        arrayList.add("code_name=" + Internal.c(this.i));
        arrayList.add("has_sender=" + this.j);
        arrayList.add("sender_uid=" + this.k);
        arrayList.add("sender_pid=" + this.l);
        arrayList.add("has_fault_address=" + this.m);
        arrayList.add("fault_address=" + this.n);
        if (this.o != null) {
            arrayList.add("fault_adjacent_metadata=" + this.o);
        }
        return CollectionsKt.joinToString$default(arrayList, ", ", "Signal{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ Signal(int i, String str, int i2, String str2, boolean z, int i3, int i4, boolean z2, long j, MemoryDump memoryDump, ByteString byteString, int i5, DefaultConstructorMarker defaultConstructorMarker) {
        this((i5 & 1) != 0 ? 0 : i, (i5 & 2) != 0 ? "" : str, (i5 & 4) != 0 ? 0 : i2, (i5 & 8) == 0 ? str2 : "", (i5 & 16) != 0 ? false : z, (i5 & 32) != 0 ? 0 : i3, (i5 & 64) != 0 ? 0 : i4, (i5 & 128) == 0 ? z2 : false, (i5 & 256) != 0 ? 0L : j, (i5 & 512) != 0 ? null : memoryDump, (i5 & 1024) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Signal(int i, String str, int i2, String str2, boolean z, int i3, int i4, boolean z2, long j, MemoryDump memoryDump, ByteString byteString) {
        super(q, byteString);
        Intrinsics.checkNotNullParameter(str, ap.a(702323535));
        Intrinsics.checkNotNullParameter(str2, ap.a(336313290));
        Intrinsics.checkNotNullParameter(byteString, ap.a(1981114828));
        this.f = i;
        this.g = str;
        this.h = i2;
        this.i = str2;
        this.j = z;
        this.k = i3;
        this.l = i4;
        this.m = z2;
        this.n = j;
        this.o = memoryDump;
    }
}