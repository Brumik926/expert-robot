package defpackage;

import android.gov.nist.javax.sip.parser.TokenNames;
import com.squareup.wire.EnumAdapter;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.Syntax;
import com.squareup.wire.WireEnum;
import h.ap;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\b\n\u0002\b\u0010\b\u0086\u0081\u0002\u0018\u0000 \u000b2\u00020\u00012\b\u0012\u0004\u0012\u00020\u00000\u0002:\u0001\fB\u0011\b\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006R\u001a\u0010\u0004\u001a\u00020\u00038\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\t\u0010\nj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012¨\u0006\u0013"}, d2 = {"LArchitecture;", "Lcom/squareup/wire/WireEnum;", "", "", "value", "<init>", "(Ljava/lang/String;II)V", "a", TokenNames.I, "getValue", "()I", "b", "Companion", "d", "e", "f", "g", "h", "i", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class Architecture implements WireEnum {
    public static final Companion b;
    public static final ProtoAdapter c;
    public static final Architecture d;
    public static final Architecture e;
    public static final Architecture f;
    public static final Architecture g;
    public static final Architecture h;
    public static final Architecture i;
    private static final /* synthetic */ Architecture[] j;
    private static final /* synthetic */ EnumEntries k;

    /* JADX INFO: renamed from: a, reason: collision with root package name */
    private final int f0a;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0019\u0010\u0007\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\u0007\u0010\bR\u001a\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00060\t8\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\n\u0010\u000b¨\u0006\f"}, d2 = {"LArchitecture$Companion;", "", "<init>", "()V", "", "value", "LArchitecture;", "a", "(I)LArchitecture;", "Lcom/squareup/wire/ProtoAdapter;", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        public final Architecture a(int i) {
            if (i == 0) {
                return Architecture.d;
            }
            if (i == 1) {
                return Architecture.e;
            }
            if (i == 2) {
                return Architecture.f;
            }
            if (i == 3) {
                return Architecture.g;
            }
            if (i == 4) {
                return Architecture.h;
            }
            if (i != 5) {
                return null;
            }
            return Architecture.i;
        }

        private Companion() {
        }
    }

    static {
        final Architecture architecture = new Architecture(ap.a(1117028085), 0, 0);
        d = architecture;
        e = new Architecture(ap.a(1766567709), 1, 1);
        f = new Architecture(ap.a(138036787), 2, 2);
        g = new Architecture(ap.a(1500620855), 3, 3);
        h = new Architecture(ap.a(1390459572), 4, 4);
        i = new Architecture(ap.a(439034715), 5, 5);
        Architecture[] architectureArrA = a();
        j = architectureArrA;
        k = EnumEntriesKt.enumEntries(architectureArrA);
        b = new Companion(null);
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(Architecture.class);
        final Syntax syntax = Syntax.d;
        c = new EnumAdapter<Architecture>(orCreateKotlinClass, syntax, architecture) { // from class: Architecture$Companion$ADAPTER$1
            /* JADX INFO: renamed from: B, reason: merged with bridge method [inline-methods] */
            protected Architecture A(int i2) {
                return Architecture.b.a(i2);
            }
        };
    }

    private Architecture(String str, int i2, int i3) {
        this.f0a = i3;
    }

    private static final /* synthetic */ Architecture[] a() {
        return new Architecture[]{d, e, f, g, h, i};
    }

    public static Architecture valueOf(String str) {
        return (Architecture) Enum.valueOf(Architecture.class, str);
    }

    public static Architecture[] values() {
        return (Architecture[]) j.clone();
    }

    public int getValue() {
        return this.f0a;
    }
}