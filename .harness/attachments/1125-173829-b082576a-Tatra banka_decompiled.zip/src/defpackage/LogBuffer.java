package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000e\u0018\u0000 \u001d2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u001eB+\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\b\b\u0002\u0010\t\u001a\u00020\b¢\u0006\u0004\b\n\u0010\u000bJ\u001a\u0010\u000f\u001a\u00020\u000e2\b\u0010\r\u001a\u0004\u0018\u00010\fH\u0096\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u000f\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0014\u001a\u00020\u0003H\u0016¢\u0006\u0004\b\u0014\u0010\u0015R\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0016\u0010\u0017\u001a\u0004\b\u0018\u0010\u0015R \u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0019\u0010\u001a\u001a\u0004\b\u001b\u0010\u001c¨\u0006\u001f"}, d2 = {"LLogBuffer;", "Lcom/squareup/wire/Message;", "", "", "name", "", "LLogMessage;", "logs", "Lokio/ByteString;", "unknownFields", "<init>", "(Ljava/lang/String;Ljava/util/List;Lokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "toString", "()Ljava/lang/String;", "f", "Ljava/lang/String;", "getName", "g", "Ljava/util/List;", "e", "()Ljava/util/List;", "h", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class LogBuffer extends Message {
    public static final Companion h = new Companion(null);
    public static final ProtoAdapter i;
    private final String f;
    private final List g;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LLogBuffer$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LLogBuffer;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(LogBuffer.class);
        final Syntax syntax = Syntax.d;
        i = new ProtoAdapter<LogBuffer>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: LogBuffer$Companion$ADAPTER$1
            {
                String strA = ap.a(817174686);
                String strA2 = ap.a(990418527);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public LogBuffer d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                ArrayList arrayList = new ArrayList();
                long jD = protoReader.d();
                Object objD = "";
                while (true) {
                    int i2 = protoReader.i();
                    if (i2 == -1) {
                        return new LogBuffer((String) objD, arrayList, protoReader.f(jD));
                    }
                    if (i2 == 1) {
                        objD = ProtoAdapter.J.d(protoReader);
                    } else if (i2 != 2) {
                        protoReader.p(i2);
                    } else {
                        arrayList.add(LogMessage.m.d(protoReader));
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, LogBuffer logBuffer) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(logBuffer, "value");
                if (!Intrinsics.areEqual(logBuffer.getName(), "")) {
                    ProtoAdapter.J.l(protoWriter, 1, logBuffer.getName());
                }
                LogMessage.m.b().l(protoWriter, 2, logBuffer.e());
                protoWriter.a(logBuffer.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, LogBuffer logBuffer) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(logBuffer, "value");
                reverseProtoWriter.j(logBuffer.d());
                LogMessage.m.b().m(reverseProtoWriter, 2, logBuffer.e());
                if (Intrinsics.areEqual(logBuffer.getName(), "")) {
                    return;
                }
                ProtoAdapter.J.m(reverseProtoWriter, 1, logBuffer.getName());
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(LogBuffer logBuffer) {
                Intrinsics.checkNotNullParameter(logBuffer, "value");
                int size = logBuffer.d().size();
                if (!Intrinsics.areEqual(logBuffer.getName(), "")) {
                    size += ProtoAdapter.J.o(1, logBuffer.getName());
                }
                return size + LogMessage.m.b().o(2, logBuffer.e());
            }
        };
    }

    public LogBuffer() {
        this(null, null, null, 7, null);
    }

    public final List e() {
        return this.g;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof LogBuffer)) {
            return false;
        }
        LogBuffer logBuffer = (LogBuffer) obj;
        return Intrinsics.areEqual(d(), logBuffer.d()) && Intrinsics.areEqual(this.f, logBuffer.f) && Intrinsics.areEqual(this.g, logBuffer.g);
    }

    public final String getName() {
        return this.f;
    }

    public int hashCode() {
        int i2 = ((Message) this).d;
        if (i2 != 0) {
            return i2;
        }
        int iHashCode = (((d().hashCode() * 37) + this.f.hashCode()) * 37) + this.g.hashCode();
        ((Message) this).d = iHashCode;
        return iHashCode;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("name=" + Internal.c(this.f));
        if (!this.g.isEmpty()) {
            arrayList.add("logs=" + this.g);
        }
        return CollectionsKt.joinToString$default(arrayList, ", ", "LogBuffer{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ LogBuffer(String str, List list, ByteString byteString, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? CollectionsKt.emptyList() : list, (i2 & 4) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public LogBuffer(String str, List list, ByteString byteString) {
        super(i, byteString);
        Intrinsics.checkNotNullParameter(str, ap.a(2075736150));
        String strA = ap.a(193318421);
        Intrinsics.checkNotNullParameter(list, strA);
        Intrinsics.checkNotNullParameter(byteString, ap.a(1629978850));
        this.f = str;
        this.g = Internal.a(strA, list);
    }
}