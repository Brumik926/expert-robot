package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000>\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0014\u0018\u0000 &2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001'BE\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006\u0012\b\b\u0002\u0010\t\u001a\u00020\b\u0012\n\b\u0002\u0010\u000b\u001a\u0004\u0018\u00010\n\u0012\b\b\u0002\u0010\f\u001a\u00020\b¢\u0006\u0004\b\r\u0010\u000eJ\u001a\u0010\u0012\u001a\u00020\u00112\b\u0010\u0010\u001a\u0004\u0018\u00010\u000fH\u0096\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0015\u001a\u00020\u0014H\u0016¢\u0006\u0004\b\u0015\u0010\u0016J\u000f\u0010\u0017\u001a\u00020\u0003H\u0016¢\u0006\u0004\b\u0017\u0010\u0018R\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0019\u0010\u001a\u001a\u0004\b\u001b\u0010\u0018R\u001a\u0010\u0005\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001c\u0010\u001a\u001a\u0004\b\u001c\u0010\u0018R\u001a\u0010\u0007\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001d\u0010\u001e\u001a\u0004\b\u0019\u0010\u001fR\u001a\u0010\t\u001a\u00020\b8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001b\u0010 \u001a\u0004\b\u001d\u0010!R\u001c\u0010\u000b\u001a\u0004\u0018\u00010\n8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\"\u0010#\u001a\u0004\b$\u0010%¨\u0006("}, d2 = {"LMemoryDump;", "Lcom/squareup/wire/Message;", "", "", "register_name", "mapping_name", "", "begin_address", "Lokio/ByteString;", "memory", "LArmMTEMetadata;", "arm_mte_metadata", "unknownFields", "<init>", "(Ljava/lang/String;Ljava/lang/String;JLokio/ByteString;LArmMTEMetadata;Lokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "toString", "()Ljava/lang/String;", "f", "Ljava/lang/String;", "i", "g", "h", "J", "()J", "Lokio/ByteString;", "()Lokio/ByteString;", "j", "LArmMTEMetadata;", "e", "()LArmMTEMetadata;", "k", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class MemoryDump extends Message {
    public static final Companion k = new Companion(null);
    public static final ProtoAdapter l;
    private final String f;
    private final String g;
    private final long h;
    private final ByteString i;
    private final ArmMTEMetadata j;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LMemoryDump$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LMemoryDump;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(MemoryDump.class);
        final Syntax syntax = Syntax.d;
        l = new ProtoAdapter<MemoryDump>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: MemoryDump$Companion$ADAPTER$1
            {
                String strA = ap.a(569128128);
                String strA2 = ap.a(2136638228);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public MemoryDump d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                Object objD = ByteString.e;
                long jD = protoReader.d();
                Object objD2 = "";
                Object objD3 = null;
                long jLongValue = 0;
                Object objD4 = "";
                while (true) {
                    int i = protoReader.i();
                    if (i == -1) {
                        return new MemoryDump((String) objD2, (String) objD4, jLongValue, (ByteString) objD, (ArmMTEMetadata) objD3, protoReader.f(jD));
                    }
                    if (i == 1) {
                        objD2 = ProtoAdapter.J.d(protoReader);
                    } else if (i == 2) {
                        objD4 = ProtoAdapter.J.d(protoReader);
                    } else if (i == 3) {
                        jLongValue = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                    } else if (i == 4) {
                        objD = ProtoAdapter.I.d(protoReader);
                    } else if (i != 6) {
                        protoReader.p(i);
                    } else {
                        objD3 = ArmMTEMetadata.h.d(protoReader);
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, MemoryDump memoryDump) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(memoryDump, "value");
                if (!Intrinsics.areEqual(memoryDump.i(), "")) {
                    ProtoAdapter.J.l(protoWriter, 1, memoryDump.i());
                }
                if (!Intrinsics.areEqual(memoryDump.g(), "")) {
                    ProtoAdapter.J.l(protoWriter, 2, memoryDump.g());
                }
                if (memoryDump.f() != 0) {
                    ProtoAdapter.w.l(protoWriter, 3, Long.valueOf(memoryDump.f()));
                }
                if (!Intrinsics.areEqual(memoryDump.h(), ByteString.e)) {
                    ProtoAdapter.I.l(protoWriter, 4, memoryDump.h());
                }
                ArmMTEMetadata.h.l(protoWriter, 6, memoryDump.e());
                protoWriter.a(memoryDump.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, MemoryDump memoryDump) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(memoryDump, "value");
                reverseProtoWriter.j(memoryDump.d());
                ArmMTEMetadata.h.m(reverseProtoWriter, 6, memoryDump.e());
                if (!Intrinsics.areEqual(memoryDump.h(), ByteString.e)) {
                    ProtoAdapter.I.m(reverseProtoWriter, 4, memoryDump.h());
                }
                if (memoryDump.f() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 3, Long.valueOf(memoryDump.f()));
                }
                if (!Intrinsics.areEqual(memoryDump.g(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 2, memoryDump.g());
                }
                if (Intrinsics.areEqual(memoryDump.i(), "")) {
                    return;
                }
                ProtoAdapter.J.m(reverseProtoWriter, 1, memoryDump.i());
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(MemoryDump memoryDump) {
                Intrinsics.checkNotNullParameter(memoryDump, "value");
                int size = memoryDump.d().size();
                if (!Intrinsics.areEqual(memoryDump.i(), "")) {
                    size += ProtoAdapter.J.o(1, memoryDump.i());
                }
                if (!Intrinsics.areEqual(memoryDump.g(), "")) {
                    size += ProtoAdapter.J.o(2, memoryDump.g());
                }
                if (memoryDump.f() != 0) {
                    size += ProtoAdapter.w.o(3, Long.valueOf(memoryDump.f()));
                }
                if (!Intrinsics.areEqual(memoryDump.h(), ByteString.e)) {
                    size += ProtoAdapter.I.o(4, memoryDump.h());
                }
                return size + ArmMTEMetadata.h.o(6, memoryDump.e());
            }
        };
    }

    public MemoryDump() {
        this(null, null, 0L, null, null, null, 63, null);
    }

    public final ArmMTEMetadata e() {
        return this.j;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MemoryDump)) {
            return false;
        }
        MemoryDump memoryDump = (MemoryDump) obj;
        return Intrinsics.areEqual(d(), memoryDump.d()) && Intrinsics.areEqual(this.f, memoryDump.f) && Intrinsics.areEqual(this.g, memoryDump.g) && this.h == memoryDump.h && Intrinsics.areEqual(this.i, memoryDump.i) && Intrinsics.areEqual(this.j, memoryDump.j);
    }

    public final long f() {
        return this.h;
    }

    public final String g() {
        return this.g;
    }

    public final ByteString h() {
        return this.i;
    }

    public int hashCode() {
        int i = ((Message) this).d;
        if (i != 0) {
            return i;
        }
        int iHashCode = ((((((((d().hashCode() * 37) + this.f.hashCode()) * 37) + this.g.hashCode()) * 37) + Long.hashCode(this.h)) * 37) + this.i.hashCode()) * 37;
        ArmMTEMetadata armMTEMetadata = this.j;
        int iHashCode2 = iHashCode + (armMTEMetadata != null ? armMTEMetadata.hashCode() : 0);
        ((Message) this).d = iHashCode2;
        return iHashCode2;
    }

    public final String i() {
        return this.f;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("register_name=" + Internal.c(this.f));
        arrayList.add("mapping_name=" + Internal.c(this.g));
        arrayList.add("begin_address=" + this.h);
        arrayList.add("memory=" + this.i);
        if (this.j != null) {
            arrayList.add("arm_mte_metadata=" + this.j);
        }
        return CollectionsKt.joinToString$default(arrayList, ", ", "MemoryDump{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ MemoryDump(String str, String str2, long j, ByteString byteString, ArmMTEMetadata armMTEMetadata, ByteString byteString2, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? "" : str, (i & 2) != 0 ? "" : str2, (i & 4) != 0 ? 0L : j, (i & 8) != 0 ? ByteString.e : byteString, (i & 16) != 0 ? null : armMTEMetadata, (i & 32) != 0 ? ByteString.e : byteString2);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MemoryDump(String str, String str2, long j, ByteString byteString, ArmMTEMetadata armMTEMetadata, ByteString byteString2) {
        super(l, byteString2);
        Intrinsics.checkNotNullParameter(str, ap.a(667336660));
        Intrinsics.checkNotNullParameter(str2, ap.a(1728979755));
        Intrinsics.checkNotNullParameter(byteString, ap.a(347315735));
        Intrinsics.checkNotNullParameter(byteString2, ap.a(440388188));
        this.f = str;
        this.g = str2;
        this.h = j;
        this.i = byteString;
        this.j = armMTEMetadata;
    }
}