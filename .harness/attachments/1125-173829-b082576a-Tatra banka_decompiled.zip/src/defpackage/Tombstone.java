package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000|\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0004\n\u0002\u0010 \n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010$\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b1\u0018\u0000 [2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\\B·\u0002\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006\u0012\b\b\u0002\u0010\b\u001a\u00020\u0006\u0012\b\b\u0002\u0010\t\u001a\u00020\u0006\u0012\b\b\u0002\u0010\u000b\u001a\u00020\n\u0012\b\b\u0002\u0010\f\u001a\u00020\n\u0012\b\b\u0002\u0010\r\u001a\u00020\n\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0006\u0012\u000e\b\u0002\u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00060\u000f\u0012\b\b\u0002\u0010\u0011\u001a\u00020\n\u0012\n\b\u0002\u0010\u0013\u001a\u0004\u0018\u00010\u0012\u0012\b\b\u0002\u0010\u0014\u001a\u00020\u0006\u0012\u000e\b\u0002\u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00150\u000f\u0012\u000e\b\u0002\u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00170\u000f\u0012\u0014\b\u0002\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u001a0\u0019\u0012\u0014\b\u0002\u0010\u001c\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u001a0\u0019\u0012\u000e\b\u0002\u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001d0\u000f\u0012\u000e\b\u0002\u0010 \u001a\b\u0012\u0004\u0012\u00020\u001f0\u000f\u0012\u000e\b\u0002\u0010\"\u001a\b\u0012\u0004\u0012\u00020!0\u000f\u0012\b\b\u0002\u0010#\u001a\u00020\n\u0012\b\b\u0002\u0010%\u001a\u00020$\u0012\n\b\u0002\u0010'\u001a\u0004\u0018\u00010&\u0012\b\b\u0002\u0010)\u001a\u00020(¢\u0006\u0004\b*\u0010+J\u001a\u0010.\u001a\u00020$2\b\u0010-\u001a\u0004\u0018\u00010,H\u0096\u0002¢\u0006\u0004\b.\u0010/J\u000f\u00100\u001a\u00020\nH\u0016¢\u0006\u0004\b0\u00101J\u000f\u00102\u001a\u00020\u0006H\u0016¢\u0006\u0004\b2\u00103R\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b4\u00105\u001a\u0004\b4\u00106R\u001a\u0010\u0005\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b7\u00105\u001a\u0004\b8\u00106R\u001a\u0010\u0007\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\f\n\u0004\b9\u0010:\u001a\u0004\b7\u00103R\u001a\u0010\b\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\f\n\u0004\b;\u0010:\u001a\u0004\b<\u00103R\u001a\u0010\t\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\f\n\u0004\b=\u0010:\u001a\u0004\b>\u00103R\u001a\u0010\u000b\u001a\u00020\n8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b8\u0010?\u001a\u0004\b@\u00101R\u001a\u0010\f\u001a\u00020\n8\u0006X\u0087\u0004¢\u0006\f\n\u0004\bA\u0010?\u001a\u0004\bB\u00101R\u001a\u0010\r\u001a\u00020\n8\u0006X\u0087\u0004¢\u0006\f\n\u0004\bC\u0010?\u001a\u0004\bD\u00101R\u001a\u0010\u000e\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\f\n\u0004\bE\u0010:\u001a\u0004\bF\u00103R\u001a\u0010\u0011\u001a\u00020\n8\u0006X\u0087\u0004¢\u0006\f\n\u0004\bG\u0010?\u001a\u0004\bH\u00101R\u001c\u0010\u0013\u001a\u0004\u0018\u00010\u00128\u0006X\u0087\u0004¢\u0006\f\n\u0004\bI\u0010J\u001a\u0004\bK\u0010LR\u001a\u0010\u0014\u001a\u00020\u00068\u0006X\u0087\u0004¢\u0006\f\n\u0004\bM\u0010:\u001a\u0004\bN\u00103R\u001a\u0010#\u001a\u00020\n8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b@\u0010?\u001a\u0004\bM\u00101R\u001a\u0010%\u001a\u00020$8\u0006X\u0087\u0004¢\u0006\f\n\u0004\bH\u0010O\u001a\u0004\bC\u0010PR\u001c\u0010'\u001a\u0004\u0018\u00010&8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b<\u0010Q\u001a\u0004\bR\u0010SR \u0010\u0010\u001a\b\u0012\u0004\u0012\u00020\u00060\u000f8\u0006X\u0087\u0004¢\u0006\f\n\u0004\bF\u0010T\u001a\u0004\b;\u0010UR \u0010\u0016\u001a\b\u0012\u0004\u0012\u00020\u00150\u000f8\u0006X\u0087\u0004¢\u0006\f\n\u0004\bK\u0010T\u001a\u0004\b=\u0010UR \u0010\u0018\u001a\b\u0012\u0004\u0012\u00020\u00170\u000f8\u0006X\u0087\u0004¢\u0006\f\n\u0004\bR\u0010T\u001a\u0004\b9\u0010UR&\u0010\u001b\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u001a0\u00198\u0006X\u0087\u0004¢\u0006\f\n\u0004\bV\u0010W\u001a\u0004\bV\u0010XR&\u0010\u001c\u001a\u000e\u0012\u0004\u0012\u00020\n\u0012\u0004\u0012\u00020\u001a0\u00198\u0006X\u0087\u0004¢\u0006\f\n\u0004\bB\u0010W\u001a\u0004\bA\u0010XR \u0010\u001e\u001a\b\u0012\u0004\u0012\u00020\u001d0\u000f8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b>\u0010T\u001a\u0004\bG\u0010UR \u0010 \u001a\b\u0012\u0004\u0012\u00020\u001f0\u000f8\u0006X\u0087\u0004¢\u0006\f\n\u0004\bY\u0010T\u001a\u0004\bE\u0010UR \u0010\"\u001a\b\u0012\u0004\u0012\u00020!0\u000f8\u0006X\u0087\u0004¢\u0006\f\n\u0004\bZ\u0010T\u001a\u0004\bI\u0010U¨\u0006]"}, d2 = {"LTombstone;", "Lcom/squareup/wire/Message;", "", "LArchitecture;", "arch", "guest_arch", "", "build_fingerprint", "revision", "timestamp", "", "pid", "tid", "uid", "selinux_label", "", "command_line", "process_uptime", "LSignal;", "signal_info", "abort_message", "LCrashDetail;", "crash_details", "LCause;", "causes", "", "LThread;", "threads", "guest_threads", "LMemoryMapping;", "memory_mappings", "LLogBuffer;", "log_buffers", "LFD;", "open_fds", "page_size", "", "has_been_16kb_mode", "LStackHistoryBuffer;", "stack_history_buffer", "Lokio/ByteString;", "unknownFields", "<init>", "(LArchitecture;LArchitecture;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;IIILjava/lang/String;Ljava/util/List;ILSignal;Ljava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/Map;Ljava/util/Map;Ljava/util/List;Ljava/util/List;Ljava/util/List;IZLStackHistoryBuffer;Lokio/ByteString;)V", "", "other", "equals", "(Ljava/lang/Object;)Z", "hashCode", "()I", "toString", "()Ljava/lang/String;", "f", "LArchitecture;", "()LArchitecture;", "g", "k", "h", "Ljava/lang/String;", "i", "t", "j", "z", "I", "r", "l", "y", "m", "C", "n", "u", "o", "s", "p", "LSignal;", "v", "()LSignal;", "q", "e", "Z", "()Z", "LStackHistoryBuffer;", "w", "()LStackHistoryBuffer;", "Ljava/util/List;", "()Ljava/util/List;", "x", "Ljava/util/Map;", "()Ljava/util/Map;", "A", "B", "D", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class Tombstone extends Message {
    public static final Companion D = new Companion(null);
    public static final ProtoAdapter G = new Tombstone$Companion$ADAPTER$1(FieldEncoding.e, Reflection.getOrCreateKotlinClass(Tombstone.class), Syntax.d);
    private final List A;
    private final List B;
    private final Architecture f;
    private final Architecture g;
    private final String h;
    private final String i;
    private final String j;
    private final int k;
    private final int l;
    private final int m;
    private final String n;
    private final int o;
    private final Signal p;
    private final String q;
    private final int r;
    private final boolean s;
    private final StackHistoryBuffer t;
    private final List u;
    private final List v;
    private final List w;
    private final Map x;
    private final Map y;
    private final List z;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LTombstone$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LTombstone;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    public Tombstone() {
        this(null, null, null, null, null, 0, 0, 0, null, null, 0, null, null, null, null, null, null, null, null, null, 0, false, null, null, 16777215, null);
    }

    public final int C() {
        return this.m;
    }

    public final String e() {
        return this.q;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Tombstone)) {
            return false;
        }
        Tombstone tombstone = (Tombstone) obj;
        return Intrinsics.areEqual(d(), tombstone.d()) && this.f == tombstone.f && this.g == tombstone.g && Intrinsics.areEqual(this.h, tombstone.h) && Intrinsics.areEqual(this.i, tombstone.i) && Intrinsics.areEqual(this.j, tombstone.j) && this.k == tombstone.k && this.l == tombstone.l && this.m == tombstone.m && Intrinsics.areEqual(this.n, tombstone.n) && Intrinsics.areEqual(this.u, tombstone.u) && this.o == tombstone.o && Intrinsics.areEqual(this.p, tombstone.p) && Intrinsics.areEqual(this.q, tombstone.q) && Intrinsics.areEqual(this.v, tombstone.v) && Intrinsics.areEqual(this.w, tombstone.w) && Intrinsics.areEqual(this.x, tombstone.x) && Intrinsics.areEqual(this.y, tombstone.y) && Intrinsics.areEqual(this.z, tombstone.z) && Intrinsics.areEqual(this.A, tombstone.A) && Intrinsics.areEqual(this.B, tombstone.B) && this.r == tombstone.r && this.s == tombstone.s && Intrinsics.areEqual(this.t, tombstone.t);
    }

    public final Architecture f() {
        return this.f;
    }

    public final String g() {
        return this.h;
    }

    public final List h() {
        return this.w;
    }

    public int hashCode() {
        int i = ((Message) this).d;
        if (i != 0) {
            return i;
        }
        int iHashCode = ((((((((((((((((((((((d().hashCode() * 37) + this.f.hashCode()) * 37) + this.g.hashCode()) * 37) + this.h.hashCode()) * 37) + this.i.hashCode()) * 37) + this.j.hashCode()) * 37) + Integer.hashCode(this.k)) * 37) + Integer.hashCode(this.l)) * 37) + Integer.hashCode(this.m)) * 37) + this.n.hashCode()) * 37) + this.u.hashCode()) * 37) + Integer.hashCode(this.o)) * 37;
        Signal signal = this.p;
        int iHashCode2 = (((((((((((((((((((((iHashCode + (signal != null ? signal.hashCode() : 0)) * 37) + this.q.hashCode()) * 37) + this.v.hashCode()) * 37) + this.w.hashCode()) * 37) + this.x.hashCode()) * 37) + this.y.hashCode()) * 37) + this.z.hashCode()) * 37) + this.A.hashCode()) * 37) + this.B.hashCode()) * 37) + Integer.hashCode(this.r)) * 37) + Boolean.hashCode(this.s)) * 37;
        StackHistoryBuffer stackHistoryBuffer = this.t;
        int iHashCode3 = iHashCode2 + (stackHistoryBuffer != null ? stackHistoryBuffer.hashCode() : 0);
        ((Message) this).d = iHashCode3;
        return iHashCode3;
    }

    public final List i() {
        return this.u;
    }

    public final List j() {
        return this.v;
    }

    public final Architecture k() {
        return this.g;
    }

    public final Map l() {
        return this.y;
    }

    public final boolean m() {
        return this.s;
    }

    public final List n() {
        return this.A;
    }

    public final List o() {
        return this.z;
    }

    public final List p() {
        return this.B;
    }

    public final int q() {
        return this.r;
    }

    public final int r() {
        return this.k;
    }

    public final int s() {
        return this.o;
    }

    public final String t() {
        return this.i;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("arch=" + this.f);
        arrayList.add("guest_arch=" + this.g);
        arrayList.add("build_fingerprint=" + Internal.c(this.h));
        arrayList.add("revision=" + Internal.c(this.i));
        arrayList.add("timestamp=" + Internal.c(this.j));
        arrayList.add("pid=" + this.k);
        arrayList.add("tid=" + this.l);
        arrayList.add("uid=" + this.m);
        arrayList.add("selinux_label=" + Internal.c(this.n));
        if (!this.u.isEmpty()) {
            arrayList.add("command_line=" + Internal.d(this.u));
        }
        arrayList.add("process_uptime=" + this.o);
        if (this.p != null) {
            arrayList.add("signal_info=" + this.p);
        }
        arrayList.add("abort_message=" + Internal.c(this.q));
        if (!this.v.isEmpty()) {
            arrayList.add("crash_details=" + this.v);
        }
        if (!this.w.isEmpty()) {
            arrayList.add("causes=" + this.w);
        }
        if (!this.x.isEmpty()) {
            arrayList.add("threads=" + this.x);
        }
        if (!this.y.isEmpty()) {
            arrayList.add("guest_threads=" + this.y);
        }
        if (!this.z.isEmpty()) {
            arrayList.add("memory_mappings=" + this.z);
        }
        if (!this.A.isEmpty()) {
            arrayList.add("log_buffers=" + this.A);
        }
        if (!this.B.isEmpty()) {
            arrayList.add("open_fds=" + this.B);
        }
        arrayList.add("page_size=" + this.r);
        arrayList.add("has_been_16kb_mode=" + this.s);
        if (this.t != null) {
            arrayList.add("stack_history_buffer=" + this.t);
        }
        return CollectionsKt.joinToString$default(arrayList, ", ", "Tombstone{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public final String u() {
        return this.n;
    }

    public final Signal v() {
        return this.p;
    }

    public final StackHistoryBuffer w() {
        return this.t;
    }

    public final Map x() {
        return this.x;
    }

    public final int y() {
        return this.l;
    }

    public final String z() {
        return this.j;
    }

    public /* synthetic */ Tombstone(Architecture architecture, Architecture architecture2, String str, String str2, String str3, int i, int i2, int i3, String str4, List list, int i4, Signal signal, String str5, List list2, List list3, Map map, Map map2, List list4, List list5, List list6, int i5, boolean z, StackHistoryBuffer stackHistoryBuffer, ByteString byteString, int i6, DefaultConstructorMarker defaultConstructorMarker) {
        this((i6 & 1) != 0 ? Architecture.d : architecture, (i6 & 2) != 0 ? Architecture.d : architecture2, (i6 & 4) != 0 ? "" : str, (i6 & 8) != 0 ? "" : str2, (i6 & 16) != 0 ? "" : str3, (i6 & 32) != 0 ? 0 : i, (i6 & 64) != 0 ? 0 : i2, (i6 & 128) != 0 ? 0 : i3, (i6 & 256) != 0 ? "" : str4, (i6 & 512) != 0 ? CollectionsKt.emptyList() : list, (i6 & 1024) != 0 ? 0 : i4, (i6 & 2048) != 0 ? null : signal, (i6 & 4096) == 0 ? str5 : "", (i6 & 8192) != 0 ? CollectionsKt.emptyList() : list2, (i6 & 16384) != 0 ? CollectionsKt.emptyList() : list3, (i6 & 32768) != 0 ? MapsKt.emptyMap() : map, (i6 & 65536) != 0 ? MapsKt.emptyMap() : map2, (i6 & 131072) != 0 ? CollectionsKt.emptyList() : list4, (i6 & 262144) != 0 ? CollectionsKt.emptyList() : list5, (i6 & 524288) != 0 ? CollectionsKt.emptyList() : list6, (i6 & 1048576) != 0 ? 0 : i5, (i6 & 2097152) != 0 ? false : z, (i6 & 4194304) != 0 ? null : stackHistoryBuffer, (i6 & 8388608) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Tombstone(Architecture architecture, Architecture architecture2, String str, String str2, String str3, int i, int i2, int i3, String str4, List list, int i4, Signal signal, String str5, List list2, List list3, Map map, Map map2, List list4, List list5, List list6, int i5, boolean z, StackHistoryBuffer stackHistoryBuffer, ByteString byteString) {
        super(G, byteString);
        Intrinsics.checkNotNullParameter(architecture, ap.a(159696391));
        Intrinsics.checkNotNullParameter(architecture2, ap.a(1787080314));
        Intrinsics.checkNotNullParameter(str, ap.a(1391452785));
        Intrinsics.checkNotNullParameter(str2, ap.a(1822070539));
        Intrinsics.checkNotNullParameter(str3, ap.a(993303769));
        Intrinsics.checkNotNullParameter(str4, ap.a(63051979));
        String strA = ap.a(1600276085);
        Intrinsics.checkNotNullParameter(list, strA);
        Intrinsics.checkNotNullParameter(str5, ap.a(691896899));
        String strA2 = ap.a(1457807965);
        Intrinsics.checkNotNullParameter(list2, strA2);
        String strA3 = ap.a(321512439);
        Intrinsics.checkNotNullParameter(list3, strA3);
        String strA4 = ap.a(1683614165);
        Intrinsics.checkNotNullParameter(map, strA4);
        String strA5 = ap.a(2070514370);
        Intrinsics.checkNotNullParameter(map2, strA5);
        String strA6 = ap.a(1217762786);
        Intrinsics.checkNotNullParameter(list4, strA6);
        String strA7 = ap.a(1671918356);
        Intrinsics.checkNotNullParameter(list5, strA7);
        String strA8 = ap.a(1352261264);
        Intrinsics.checkNotNullParameter(list6, strA8);
        Intrinsics.checkNotNullParameter(byteString, ap.a(27246331));
        this.f = architecture;
        this.g = architecture2;
        this.h = str;
        this.i = str2;
        this.j = str3;
        this.k = i;
        this.l = i2;
        this.m = i3;
        this.n = str4;
        this.o = i4;
        this.p = signal;
        this.q = str5;
        this.r = i5;
        this.s = z;
        this.t = stackHistoryBuffer;
        this.u = Internal.a(strA, list);
        this.v = Internal.a(strA2, list2);
        this.w = Internal.a(strA3, list3);
        this.x = Internal.b(strA4, map);
        this.y = Internal.b(strA5, map2);
        this.z = Internal.a(strA6, list4);
        this.A = Internal.a(strA7, list5);
        this.B = Internal.a(strA8, list6);
    }
}