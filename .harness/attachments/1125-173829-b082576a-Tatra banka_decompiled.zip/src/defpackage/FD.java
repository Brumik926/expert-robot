package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0012\u0018\u0000  2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001!B9\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0005\u0012\b\b\u0002\u0010\t\u001a\u00020\b\u0012\b\b\u0002\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\f\u0010\rJ\u001a\u0010\u0011\u001a\u00020\u00102\b\u0010\u000f\u001a\u0004\u0018\u00010\u000eH\u0096\u0002¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0013\u001a\u00020\u0003H\u0016¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010\u0015\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0015\u0010\u0016R\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0017\u0010\u0018\u001a\u0004\b\u0019\u0010\u0014R\u001a\u0010\u0006\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001a\u0010\u001b\u001a\u0004\b\u001a\u0010\u0016R\u001a\u0010\u0007\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001c\u0010\u001b\u001a\u0004\b\u0017\u0010\u0016R\u001a\u0010\t\u001a\u00020\b8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001d\u0010\u001e\u001a\u0004\b\u001c\u0010\u001f¨\u0006\""}, d2 = {"LFD;", "Lcom/squareup/wire/Message;", "", "", "fd", "", "path", "owner", "", "tag", "Lokio/ByteString;", "unknownFields", "<init>", "(ILjava/lang/String;Ljava/lang/String;JLokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "hashCode", "()I", "toString", "()Ljava/lang/String;", "f", "I", "e", "g", "Ljava/lang/String;", "h", "i", "J", "()J", "j", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class FD extends Message {
    public static final Companion j = new Companion(null);
    public static final ProtoAdapter k;
    private final int f;
    private final String g;
    private final String h;
    private final long i;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LFD$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LFD;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(FD.class);
        final Syntax syntax = Syntax.d;
        k = new ProtoAdapter<FD>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: FD$Companion$ADAPTER$1
            {
                String strA = ap.a(2092018604);
                String strA2 = ap.a(1381270766);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public FD d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                long jD = protoReader.d();
                Object objD = "";
                long jLongValue = 0;
                int iIntValue = 0;
                Object objD2 = "";
                while (true) {
                    long j2 = jLongValue;
                    while (true) {
                        int i = protoReader.i();
                        if (i == -1) {
                            return new FD(iIntValue, (String) objD, (String) objD2, j2, protoReader.f(jD));
                        }
                        if (i == 1) {
                            iIntValue = ((Number) ProtoAdapter.k.d(protoReader)).intValue();
                        } else if (i == 2) {
                            objD = ProtoAdapter.J.d(protoReader);
                        } else if (i == 3) {
                            objD2 = ProtoAdapter.J.d(protoReader);
                        } else if (i != 4) {
                            protoReader.p(i);
                        }
                    }
                    jLongValue = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, FD fd) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(fd, "value");
                if (fd.e() != 0) {
                    ProtoAdapter.k.l(protoWriter, 1, Integer.valueOf(fd.e()));
                }
                if (!Intrinsics.areEqual(fd.g(), "")) {
                    ProtoAdapter.J.l(protoWriter, 2, fd.g());
                }
                if (!Intrinsics.areEqual(fd.f(), "")) {
                    ProtoAdapter.J.l(protoWriter, 3, fd.f());
                }
                if (fd.h() != 0) {
                    ProtoAdapter.w.l(protoWriter, 4, Long.valueOf(fd.h()));
                }
                protoWriter.a(fd.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, FD fd) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(fd, "value");
                reverseProtoWriter.j(fd.d());
                if (fd.h() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 4, Long.valueOf(fd.h()));
                }
                if (!Intrinsics.areEqual(fd.f(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 3, fd.f());
                }
                if (!Intrinsics.areEqual(fd.g(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 2, fd.g());
                }
                if (fd.e() != 0) {
                    ProtoAdapter.k.m(reverseProtoWriter, 1, Integer.valueOf(fd.e()));
                }
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(FD fd) {
                Intrinsics.checkNotNullParameter(fd, "value");
                int size = fd.d().size();
                if (fd.e() != 0) {
                    size += ProtoAdapter.k.o(1, Integer.valueOf(fd.e()));
                }
                if (!Intrinsics.areEqual(fd.g(), "")) {
                    size += ProtoAdapter.J.o(2, fd.g());
                }
                if (!Intrinsics.areEqual(fd.f(), "")) {
                    size += ProtoAdapter.J.o(3, fd.f());
                }
                return fd.h() != 0 ? size + ProtoAdapter.w.o(4, Long.valueOf(fd.h())) : size;
            }
        };
    }

    public FD() {
        this(0, null, null, 0L, null, 31, null);
    }

    public final int e() {
        return this.f;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof FD)) {
            return false;
        }
        FD fd = (FD) obj;
        return Intrinsics.areEqual(d(), fd.d()) && this.f == fd.f && Intrinsics.areEqual(this.g, fd.g) && Intrinsics.areEqual(this.h, fd.h) && this.i == fd.i;
    }

    public final String f() {
        return this.h;
    }

    public final String g() {
        return this.g;
    }

    public final long h() {
        return this.i;
    }

    public int hashCode() {
        int i = ((Message) this).d;
        if (i != 0) {
            return i;
        }
        int iHashCode = (((((((d().hashCode() * 37) + Integer.hashCode(this.f)) * 37) + this.g.hashCode()) * 37) + this.h.hashCode()) * 37) + Long.hashCode(this.i);
        ((Message) this).d = iHashCode;
        return iHashCode;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("fd=" + this.f);
        arrayList.add("path=" + Internal.c(this.g));
        arrayList.add("owner=" + Internal.c(this.h));
        arrayList.add("tag=" + this.i);
        return CollectionsKt.joinToString$default(arrayList, ", ", "FD{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ FD(int i, String str, String str2, long j2, ByteString byteString, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? 0 : i, (i2 & 2) != 0 ? "" : str, (i2 & 4) != 0 ? "" : str2, (i2 & 8) != 0 ? 0L : j2, (i2 & 16) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FD(int i, String str, String str2, long j2, ByteString byteString) {
        super(k, byteString);
        Intrinsics.checkNotNullParameter(str, ap.a(2141278629));
        Intrinsics.checkNotNullParameter(str2, ap.a(1097965536));
        Intrinsics.checkNotNullParameter(byteString, ap.a(686337393));
        this.f = i;
        this.g = str;
        this.h = str2;
        this.i = j2;
    }
}