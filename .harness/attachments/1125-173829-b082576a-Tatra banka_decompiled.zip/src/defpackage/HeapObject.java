package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0010\u0018\u0000 &2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001'BY\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003\u0012\u000e\b\u0002\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\b\b\u0002\u0010\r\u001a\u00020\f¢\u0006\u0004\b\u000e\u0010\u000fJ\u001a\u0010\u0013\u001a\u00020\u00122\b\u0010\u0011\u001a\u0004\u0018\u00010\u0010H\u0096\u0002¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010\u0016\u001a\u00020\u0015H\u0016¢\u0006\u0004\b\u0016\u0010\u0017J\u000f\u0010\u0019\u001a\u00020\u0018H\u0016¢\u0006\u0004\b\u0019\u0010\u001aR\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u001d\u0010\u001eR\u001a\u0010\u0005\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001f\u0010\u001c\u001a\u0004\b \u0010\u001eR\u001a\u0010\u0006\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b!\u0010\u001c\u001a\u0004\b\u001f\u0010\u001eR\u001a\u0010\n\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\"\u0010\u001c\u001a\u0004\b\"\u0010\u001eR \u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b \u0010#\u001a\u0004\b\u001b\u0010$R \u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\b0\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b%\u0010#\u001a\u0004\b!\u0010$¨\u0006("}, d2 = {"LHeapObject;", "Lcom/squareup/wire/Message;", "", "", "address", "size", "allocation_tid", "", "LBacktraceFrame;", "allocation_backtrace", "deallocation_tid", "deallocation_backtrace", "Lokio/ByteString;", "unknownFields", "<init>", "(JJJLjava/util/List;JLjava/util/List;Lokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "", "toString", "()Ljava/lang/String;", "f", "J", "e", "()J", "g", "j", "h", "i", "Ljava/util/List;", "()Ljava/util/List;", "k", "l", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class HeapObject extends Message {
    public static final Companion l = new Companion(null);
    public static final ProtoAdapter m;
    private final long f;
    private final long g;
    private final long h;
    private final long i;
    private final List j;
    private final List k;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LHeapObject$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LHeapObject;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(HeapObject.class);
        final Syntax syntax = Syntax.d;
        m = new ProtoAdapter<HeapObject>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: HeapObject$Companion$ADAPTER$1
            {
                String strA = ap.a(332242236);
                String strA2 = ap.a(291608007);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public HeapObject d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                long jD = protoReader.d();
                long jLongValue = 0;
                long jLongValue2 = 0;
                long jLongValue3 = 0;
                long jLongValue4 = 0;
                while (true) {
                    int i = protoReader.i();
                    if (i == -1) {
                        return new HeapObject(jLongValue, jLongValue2, jLongValue3, arrayList, jLongValue4, arrayList2, protoReader.f(jD));
                    }
                    switch (i) {
                        case 1:
                            jLongValue = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 2:
                            jLongValue2 = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 3:
                            jLongValue3 = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 4:
                            arrayList.add(BacktraceFrame.o.d(protoReader));
                            break;
                        case 5:
                            jLongValue4 = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 6:
                            arrayList2.add(BacktraceFrame.o.d(protoReader));
                            break;
                        default:
                            protoReader.p(i);
                            break;
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, HeapObject heapObject) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(heapObject, "value");
                if (heapObject.e() != 0) {
                    ProtoAdapter.w.l(protoWriter, 1, Long.valueOf(heapObject.e()));
                }
                if (heapObject.j() != 0) {
                    ProtoAdapter.w.l(protoWriter, 2, Long.valueOf(heapObject.j()));
                }
                if (heapObject.g() != 0) {
                    ProtoAdapter.w.l(protoWriter, 3, Long.valueOf(heapObject.g()));
                }
                ProtoAdapter protoAdapter = BacktraceFrame.o;
                protoAdapter.b().l(protoWriter, 4, heapObject.f());
                if (heapObject.i() != 0) {
                    ProtoAdapter.w.l(protoWriter, 5, Long.valueOf(heapObject.i()));
                }
                protoAdapter.b().l(protoWriter, 6, heapObject.h());
                protoWriter.a(heapObject.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, HeapObject heapObject) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(heapObject, "value");
                reverseProtoWriter.j(heapObject.d());
                ProtoAdapter protoAdapter = BacktraceFrame.o;
                protoAdapter.b().m(reverseProtoWriter, 6, heapObject.h());
                if (heapObject.i() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 5, Long.valueOf(heapObject.i()));
                }
                protoAdapter.b().m(reverseProtoWriter, 4, heapObject.f());
                if (heapObject.g() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 3, Long.valueOf(heapObject.g()));
                }
                if (heapObject.j() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 2, Long.valueOf(heapObject.j()));
                }
                if (heapObject.e() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 1, Long.valueOf(heapObject.e()));
                }
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(HeapObject heapObject) {
                Intrinsics.checkNotNullParameter(heapObject, "value");
                int size = heapObject.d().size();
                if (heapObject.e() != 0) {
                    size += ProtoAdapter.w.o(1, Long.valueOf(heapObject.e()));
                }
                if (heapObject.j() != 0) {
                    size += ProtoAdapter.w.o(2, Long.valueOf(heapObject.j()));
                }
                if (heapObject.g() != 0) {
                    size += ProtoAdapter.w.o(3, Long.valueOf(heapObject.g()));
                }
                ProtoAdapter protoAdapter = BacktraceFrame.o;
                int iO = size + protoAdapter.b().o(4, heapObject.f());
                if (heapObject.i() != 0) {
                    iO += ProtoAdapter.w.o(5, Long.valueOf(heapObject.i()));
                }
                return iO + protoAdapter.b().o(6, heapObject.h());
            }
        };
    }

    public HeapObject() {
        this(0L, 0L, 0L, null, 0L, null, null, 127, null);
    }

    public final long e() {
        return this.f;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof HeapObject)) {
            return false;
        }
        HeapObject heapObject = (HeapObject) obj;
        return Intrinsics.areEqual(d(), heapObject.d()) && this.f == heapObject.f && this.g == heapObject.g && this.h == heapObject.h && Intrinsics.areEqual(this.j, heapObject.j) && this.i == heapObject.i && Intrinsics.areEqual(this.k, heapObject.k);
    }

    public final List f() {
        return this.j;
    }

    public final long g() {
        return this.h;
    }

    public final List h() {
        return this.k;
    }

    public int hashCode() {
        int i = ((Message) this).d;
        if (i != 0) {
            return i;
        }
        int iHashCode = (((((((((((d().hashCode() * 37) + Long.hashCode(this.f)) * 37) + Long.hashCode(this.g)) * 37) + Long.hashCode(this.h)) * 37) + this.j.hashCode()) * 37) + Long.hashCode(this.i)) * 37) + this.k.hashCode();
        ((Message) this).d = iHashCode;
        return iHashCode;
    }

    public final long i() {
        return this.i;
    }

    public final long j() {
        return this.g;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("address=" + this.f);
        arrayList.add("size=" + this.g);
        arrayList.add("allocation_tid=" + this.h);
        if (!this.j.isEmpty()) {
            arrayList.add("allocation_backtrace=" + this.j);
        }
        arrayList.add("deallocation_tid=" + this.i);
        if (!this.k.isEmpty()) {
            arrayList.add("deallocation_backtrace=" + this.k);
        }
        return CollectionsKt.joinToString$default(arrayList, ", ", "HeapObject{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ HeapObject(long j, long j2, long j3, List list, long j4, List list2, ByteString byteString, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? 0L : j, (i & 2) != 0 ? 0L : j2, (i & 4) != 0 ? 0L : j3, (i & 8) != 0 ? CollectionsKt.emptyList() : list, (i & 16) != 0 ? 0L : j4, (i & 32) != 0 ? CollectionsKt.emptyList() : list2, (i & 64) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public HeapObject(long j, long j2, long j3, List list, long j4, List list2, ByteString byteString) {
        super(m, byteString);
        String strA = ap.a(2042782277);
        Intrinsics.checkNotNullParameter(list, strA);
        String strA2 = ap.a(558843039);
        Intrinsics.checkNotNullParameter(list2, strA2);
        Intrinsics.checkNotNullParameter(byteString, ap.a(1065966430));
        this.f = j;
        this.g = j2;
        this.h = j3;
        this.i = j4;
        this.j = Internal.a(strA, list);
        this.k = Internal.a(strA2, list2);
    }
}