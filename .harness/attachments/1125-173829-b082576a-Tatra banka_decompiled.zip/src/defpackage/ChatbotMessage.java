package defpackage;

import androidx.annotation.Keep;
import androidx.compose.runtime.internal.StabilityInferred;
import com.google.gson.annotations.SerializedName;
import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@StabilityInferred
@Keep
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0016\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\b\u0087\b\u0018\u00002\u00020\u0001BI\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u0012\u0006\u0010\u0004\u001a\u00020\u0003\u0012\u0006\u0010\u0005\u001a\u00020\u0003\u0012\u0006\u0010\u0006\u001a\u00020\u0003\u0012\u0006\u0010\u0007\u001a\u00020\u0003\u0012\u0006\u0010\b\u001a\u00020\u0003\u0012\u0006\u0010\t\u001a\u00020\u0003\u0012\b\u0010\n\u001a\u0004\u0018\u00010\u000b¢\u0006\u0004\b\f\u0010\rJ\t\u0010\u0018\u001a\u00020\u0003HÆ\u0003J\t\u0010\u0019\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001a\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001b\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001c\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001d\u001a\u00020\u0003HÆ\u0003J\t\u0010\u001e\u001a\u00020\u0003HÆ\u0003J\u000b\u0010\u001f\u001a\u0004\u0018\u00010\u000bHÆ\u0003J[\u0010 \u001a\u00020\u00002\b\b\u0002\u0010\u0002\u001a\u00020\u00032\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0005\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00032\b\b\u0002\u0010\u0007\u001a\u00020\u00032\b\b\u0002\u0010\b\u001a\u00020\u00032\b\b\u0002\u0010\t\u001a\u00020\u00032\n\b\u0002\u0010\n\u001a\u0004\u0018\u00010\u000bHÆ\u0001J\u0013\u0010!\u001a\u00020\"2\b\u0010#\u001a\u0004\u0018\u00010\u0001HÖ\u0003J\t\u0010$\u001a\u00020%HÖ\u0001J\t\u0010&\u001a\u00020\u0003HÖ\u0001R\u0016\u0010\u0002\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u000e\u0010\u000fR\u0016\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0010\u0010\u000fR\u0016\u0010\u0005\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0011\u0010\u000fR\u0016\u0010\u0006\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0012\u0010\u000fR\u0016\u0010\u0007\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0013\u0010\u000fR\u0016\u0010\b\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0014\u0010\u000fR\u0016\u0010\t\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0015\u0010\u000fR\u0018\u0010\n\u001a\u0004\u0018\u00010\u000b8\u0006X\u0087\u0004¢\u0006\b\n\u0000\u001a\u0004\b\u0016\u0010\u0017¨\u0006'"}, d2 = {"LChatbotMessage;", "", "agentID", "", "vaDataPass", "messageData", "messageType", "engagementID", "sequenceNumber", "messageTimestamp", "virtualAgentResponse", "LVirtualAgentResponse;", "<init>", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;LVirtualAgentResponse;)V", "getAgentID", "()Ljava/lang/String;", "getVaDataPass", "getMessageData", "getMessageType", "getEngagementID", "getSequenceNumber", "getMessageTimestamp", "getVirtualAgentResponse", "()LVirtualAgentResponse;", "component1", "component2", "component3", "component4", "component5", "component6", "component7", "component8", "copy", "equals", "", "other", "hashCode", "", "toString", "tatra-mobile_clientRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class ChatbotMessage {
    public static final int $stable = 0;

    @SerializedName("agentID")
    @NotNull
    private final String agentID;

    @SerializedName("engagementID")
    @NotNull
    private final String engagementID;

    @SerializedName("messageData")
    @NotNull
    private final String messageData;

    @SerializedName("messageTimestamp")
    @NotNull
    private final String messageTimestamp;

    @SerializedName("messageType")
    @NotNull
    private final String messageType;

    @SerializedName("sequenceNumber")
    @NotNull
    private final String sequenceNumber;

    @SerializedName("vaDataPass")
    @NotNull
    private final String vaDataPass;

    @SerializedName("virtualAgentResponse")
    @Nullable
    private final VirtualAgentResponse virtualAgentResponse;

    public ChatbotMessage(@NotNull String str, @NotNull String str2, @NotNull String str3, @NotNull String str4, @NotNull String str5, @NotNull String str6, @NotNull String str7, @Nullable VirtualAgentResponse virtualAgentResponse) {
        Intrinsics.checkNotNullParameter(str, ap.a(1396717278));
        Intrinsics.checkNotNullParameter(str2, ap.a(1333273962));
        Intrinsics.checkNotNullParameter(str3, ap.a(1140801559));
        Intrinsics.checkNotNullParameter(str4, ap.a(500406085));
        Intrinsics.checkNotNullParameter(str5, ap.a(1588307347));
        Intrinsics.checkNotNullParameter(str6, ap.a(2125501642));
        Intrinsics.checkNotNullParameter(str7, ap.a(1823501132));
        this.agentID = str;
        this.vaDataPass = str2;
        this.messageData = str3;
        this.messageType = str4;
        this.engagementID = str5;
        this.sequenceNumber = str6;
        this.messageTimestamp = str7;
        this.virtualAgentResponse = virtualAgentResponse;
    }

    public static /* synthetic */ ChatbotMessage copy$default(ChatbotMessage chatbotMessage, String str, String str2, String str3, String str4, String str5, String str6, String str7, VirtualAgentResponse virtualAgentResponse, int i, Object obj) {
        if ((i & 1) != 0) {
            str = chatbotMessage.agentID;
        }
        if ((i & 2) != 0) {
            str2 = chatbotMessage.vaDataPass;
        }
        if ((i & 4) != 0) {
            str3 = chatbotMessage.messageData;
        }
        if ((i & 8) != 0) {
            str4 = chatbotMessage.messageType;
        }
        if ((i & 16) != 0) {
            str5 = chatbotMessage.engagementID;
        }
        if ((i & 32) != 0) {
            str6 = chatbotMessage.sequenceNumber;
        }
        if ((i & 64) != 0) {
            str7 = chatbotMessage.messageTimestamp;
        }
        if ((i & 128) != 0) {
            virtualAgentResponse = chatbotMessage.virtualAgentResponse;
        }
        String str8 = str7;
        VirtualAgentResponse virtualAgentResponse2 = virtualAgentResponse;
        String str9 = str5;
        String str10 = str6;
        return chatbotMessage.copy(str, str2, str3, str4, str9, str10, str8, virtualAgentResponse2);
    }

    @NotNull
    public final String component1() {
        return this.agentID;
    }

    @NotNull
    public final String component2() {
        return this.vaDataPass;
    }

    @NotNull
    public final String component3() {
        return this.messageData;
    }

    @NotNull
    public final String component4() {
        return this.messageType;
    }

    @NotNull
    public final String component5() {
        return this.engagementID;
    }

    @NotNull
    public final String component6() {
        return this.sequenceNumber;
    }

    @NotNull
    public final String component7() {
        return this.messageTimestamp;
    }

    @Nullable
    public final VirtualAgentResponse component8() {
        return this.virtualAgentResponse;
    }

    @NotNull
    public final ChatbotMessage copy(@NotNull String str, @NotNull String str2, @NotNull String str3, @NotNull String str4, @NotNull String str5, @NotNull String str6, @NotNull String str7, @Nullable VirtualAgentResponse virtualAgentResponse) {
        Intrinsics.checkNotNullParameter(str, "agentID");
        Intrinsics.checkNotNullParameter(str2, "vaDataPass");
        Intrinsics.checkNotNullParameter(str3, "messageData");
        Intrinsics.checkNotNullParameter(str4, "messageType");
        Intrinsics.checkNotNullParameter(str5, "engagementID");
        Intrinsics.checkNotNullParameter(str6, "sequenceNumber");
        Intrinsics.checkNotNullParameter(str7, "messageTimestamp");
        return new ChatbotMessage(str, str2, str3, str4, str5, str6, str7, virtualAgentResponse);
    }

    public boolean equals(@Nullable Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ChatbotMessage)) {
            return false;
        }
        ChatbotMessage chatbotMessage = (ChatbotMessage) obj;
        return Intrinsics.areEqual(this.agentID, chatbotMessage.agentID) && Intrinsics.areEqual(this.vaDataPass, chatbotMessage.vaDataPass) && Intrinsics.areEqual(this.messageData, chatbotMessage.messageData) && Intrinsics.areEqual(this.messageType, chatbotMessage.messageType) && Intrinsics.areEqual(this.engagementID, chatbotMessage.engagementID) && Intrinsics.areEqual(this.sequenceNumber, chatbotMessage.sequenceNumber) && Intrinsics.areEqual(this.messageTimestamp, chatbotMessage.messageTimestamp) && Intrinsics.areEqual(this.virtualAgentResponse, chatbotMessage.virtualAgentResponse);
    }

    @NotNull
    public final String getAgentID() {
        return this.agentID;
    }

    @NotNull
    public final String getEngagementID() {
        return this.engagementID;
    }

    @NotNull
    public final String getMessageData() {
        return this.messageData;
    }

    @NotNull
    public final String getMessageTimestamp() {
        return this.messageTimestamp;
    }

    @NotNull
    public final String getMessageType() {
        return this.messageType;
    }

    @NotNull
    public final String getSequenceNumber() {
        return this.sequenceNumber;
    }

    @NotNull
    public final String getVaDataPass() {
        return this.vaDataPass;
    }

    @Nullable
    public final VirtualAgentResponse getVirtualAgentResponse() {
        return this.virtualAgentResponse;
    }

    public int hashCode() {
        int iHashCode = ((((((((((((this.agentID.hashCode() * 31) + this.vaDataPass.hashCode()) * 31) + this.messageData.hashCode()) * 31) + this.messageType.hashCode()) * 31) + this.engagementID.hashCode()) * 31) + this.sequenceNumber.hashCode()) * 31) + this.messageTimestamp.hashCode()) * 31;
        VirtualAgentResponse virtualAgentResponse = this.virtualAgentResponse;
        return iHashCode + (virtualAgentResponse == null ? 0 : virtualAgentResponse.hashCode());
    }

    @NotNull
    public String toString() {
        return "ChatbotMessage(agentID=" + this.agentID + ", vaDataPass=" + this.vaDataPass + ", messageData=" + this.messageData + ", messageType=" + this.messageType + ", engagementID=" + this.engagementID + ", sequenceNumber=" + this.sequenceNumber + ", messageTimestamp=" + this.messageTimestamp + ", virtualAgentResponse=" + this.virtualAgentResponse + ")";
    }
}