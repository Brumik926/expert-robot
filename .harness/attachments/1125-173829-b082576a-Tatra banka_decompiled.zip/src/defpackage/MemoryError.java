package defpackage;

import com.squareup.wire.EnumAdapter;
import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.WireEnum;
import defpackage.MemoryError;
import h.ap;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0011\u0018\u0000 \"2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0003#$%B1\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\n\b\u0002\u0010\b\u001a\u0004\u0018\u00010\u0007\u0012\b\b\u0002\u0010\n\u001a\u00020\t¢\u0006\u0004\b\u000b\u0010\fJ\u001a\u0010\u0010\u001a\u00020\u000f2\b\u0010\u000e\u001a\u0004\u0018\u00010\rH\u0096\u0002¢\u0006\u0004\b\u0010\u0010\u0011J\u000f\u0010\u0013\u001a\u00020\u0012H\u0016¢\u0006\u0004\b\u0013\u0010\u0014J\u000f\u0010\u0016\u001a\u00020\u0015H\u0016¢\u0006\u0004\b\u0016\u0010\u0017R\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0018\u0010\u0019\u001a\u0004\b\u0018\u0010\u001aR\u001a\u0010\u0006\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u001b\u0010\u001dR\u001c\u0010\b\u001a\u0004\u0018\u00010\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001e\u0010\u001f\u001a\u0004\b \u0010!¨\u0006&"}, d2 = {"LMemoryError;", "Lcom/squareup/wire/Message;", "", "LMemoryError$Tool;", "tool", "LMemoryError$Type;", "type", "LHeapObject;", "heap", "Lokio/ByteString;", "unknownFields", "<init>", "(LMemoryError$Tool;LMemoryError$Type;LHeapObject;Lokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "", "toString", "()Ljava/lang/String;", "f", "LMemoryError$Tool;", "()LMemoryError$Tool;", "g", "LMemoryError$Type;", "()LMemoryError$Type;", "h", "LHeapObject;", "e", "()LHeapObject;", "i", "Companion", "Tool", "Type", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class MemoryError extends Message {
    public static final Companion i = new Companion(null);
    public static final ProtoAdapter j;
    private final Tool f;
    private final Type g;
    private final HeapObject h;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LMemoryError$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LMemoryError;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\b\n\u0002\b\f\b\u0086\u0081\u0002\u0018\u0000 \u000b2\u00020\u00012\b\u0012\u0004\u0012\u00020\u00000\u0002:\u0001\fB\u0011\b\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006R\u001a\u0010\u0004\u001a\u00020\u00038\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\t\u0010\nj\u0002\b\rj\u0002\b\u000e¨\u0006\u000f"}, d2 = {"LMemoryError$Tool;", "Lcom/squareup/wire/WireEnum;", "", "", "value", "<init>", "(Ljava/lang/String;II)V", "a", "I", "getValue", "()I", "b", "Companion", "d", "e", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Tool implements WireEnum {
        public static final Companion b;
        public static final ProtoAdapter c;
        public static final Tool d;
        public static final Tool e;
        private static final /* synthetic */ Tool[] f;
        private static final /* synthetic */ EnumEntries g;
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0019\u0010\u0007\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\u0007\u0010\bR\u001a\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00060\t8\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\n\u0010\u000b¨\u0006\f"}, d2 = {"LMemoryError$Tool$Companion;", "", "<init>", "()V", "", "value", "LMemoryError$Tool;", "a", "(I)LMemoryError$Tool;", "Lcom/squareup/wire/ProtoAdapter;", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
        public static final class Companion {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            public final Tool a(int i) {
                if (i == 0) {
                    return Tool.d;
                }
                if (i != 1) {
                    return null;
                }
                return Tool.e;
            }

            private Companion() {
            }
        }

        static {
            final Tool tool = new Tool(ap.a(1809991154), 0, 0);
            d = tool;
            e = new Tool(ap.a(1044469024), 1, 1);
            Tool[] toolArrA = a();
            f = toolArrA;
            g = EnumEntriesKt.enumEntries(toolArrA);
            b = new Companion(null);
            final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(Tool.class);
            final Syntax syntax = Syntax.d;
            c = new EnumAdapter<Tool>(orCreateKotlinClass, syntax, tool) { // from class: MemoryError$Tool$Companion$ADAPTER$1
                /* JADX INFO: renamed from: B, reason: merged with bridge method [inline-methods] */
                protected MemoryError.Tool A(int i) {
                    return MemoryError.Tool.b.a(i);
                }
            };
        }

        private Tool(String str, int i, int i2) {
            this.a = i2;
        }

        private static final /* synthetic */ Tool[] a() {
            return new Tool[]{d, e};
        }

        public static Tool valueOf(String str) {
            return (Tool) Enum.valueOf(Tool.class, str);
        }

        public static Tool[] values() {
            return (Tool[]) f.clone();
        }

        public int getValue() {
            return this.a;
        }
    }

    /* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
    /* JADX WARN: Unknown enum class pattern. Please report as an issue! */
    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u0014\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\u0010\b\n\u0002\b\u0010\b\u0086\u0081\u0002\u0018\u0000 \u000b2\u00020\u00012\b\u0012\u0004\u0012\u00020\u00000\u0002:\u0001\fB\u0011\b\u0002\u0012\u0006\u0010\u0004\u001a\u00020\u0003¢\u0006\u0004\b\u0005\u0010\u0006R\u001a\u0010\u0004\u001a\u00020\u00038\u0016X\u0096\u0004¢\u0006\f\n\u0004\b\u0007\u0010\b\u001a\u0004\b\t\u0010\nj\u0002\b\rj\u0002\b\u000ej\u0002\b\u000fj\u0002\b\u0010j\u0002\b\u0011j\u0002\b\u0012¨\u0006\u0013"}, d2 = {"LMemoryError$Type;", "Lcom/squareup/wire/WireEnum;", "", "", "value", "<init>", "(Ljava/lang/String;II)V", "a", "I", "getValue", "()I", "b", "Companion", "d", "e", "f", "g", "h", "i", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Type implements WireEnum {
        public static final Companion b;
        public static final ProtoAdapter c;
        public static final Type d;
        public static final Type e;
        public static final Type f;
        public static final Type g;
        public static final Type h;
        public static final Type i;
        private static final /* synthetic */ Type[] j;
        private static final /* synthetic */ EnumEntries k;
        private final int a;

        /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
        @Metadata(d1 = {"\u0000\"\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0019\u0010\u0007\u001a\u0004\u0018\u00010\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0007¢\u0006\u0004\b\u0007\u0010\bR\u001a\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00060\t8\u0006X\u0087\u0004¢\u0006\u0006\n\u0004\b\n\u0010\u000b¨\u0006\f"}, d2 = {"LMemoryError$Type$Companion;", "", "<init>", "()V", "", "value", "LMemoryError$Type;", "a", "(I)LMemoryError$Type;", "Lcom/squareup/wire/ProtoAdapter;", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
        public static final class Companion {
            public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
                this();
            }

            public final Type a(int i) {
                if (i == 0) {
                    return Type.d;
                }
                if (i == 1) {
                    return Type.e;
                }
                if (i == 2) {
                    return Type.f;
                }
                if (i == 3) {
                    return Type.g;
                }
                if (i == 4) {
                    return Type.h;
                }
                if (i != 5) {
                    return null;
                }
                return Type.i;
            }

            private Companion() {
            }
        }

        static {
            final Type type = new Type(ap.a(405140518), 0, 0);
            d = type;
            e = new Type(ap.a(585868584), 1, 1);
            f = new Type(ap.a(310402068), 2, 2);
            g = new Type(ap.a(1495084612), 3, 3);
            h = new Type(ap.a(185995213), 4, 4);
            i = new Type(ap.a(1338077564), 5, 5);
            Type[] typeArrA = a();
            j = typeArrA;
            k = EnumEntriesKt.enumEntries(typeArrA);
            b = new Companion(null);
            final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(Type.class);
            final Syntax syntax = Syntax.d;
            c = new EnumAdapter<Type>(orCreateKotlinClass, syntax, type) { // from class: MemoryError$Type$Companion$ADAPTER$1
                /* JADX INFO: renamed from: B, reason: merged with bridge method [inline-methods] */
                protected MemoryError.Type A(int i2) {
                    return MemoryError.Type.b.a(i2);
                }
            };
        }

        private Type(String str, int i2, int i3) {
            this.a = i3;
        }

        private static final /* synthetic */ Type[] a() {
            return new Type[]{d, e, f, g, h, i};
        }

        public static Type valueOf(String str) {
            return (Type) Enum.valueOf(Type.class, str);
        }

        public static Type[] values() {
            return (Type[]) j.clone();
        }

        public int getValue() {
            return this.a;
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(MemoryError.class);
        final Syntax syntax = Syntax.d;
        j = new ProtoAdapter<MemoryError>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: MemoryError$Companion$ADAPTER$1
            {
                String strA = ap.a(1983755739);
                String strA2 = ap.a(1549332330);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public MemoryError d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                Object objD = MemoryError.Tool.d;
                Object objD2 = MemoryError.Type.d;
                long jD = protoReader.d();
                Object objD3 = null;
                while (true) {
                    int i2 = protoReader.i();
                    if (i2 == -1) {
                        return new MemoryError((MemoryError.Tool) objD, (MemoryError.Type) objD2, (HeapObject) objD3, protoReader.f(jD));
                    }
                    if (i2 == 1) {
                        try {
                            objD = MemoryError.Tool.c.d(protoReader);
                        } catch (ProtoAdapter.EnumConstantNotFoundException e) {
                            protoReader.a(i2, FieldEncoding.c, Long.valueOf(e.a));
                        }
                    } else if (i2 == 2) {
                        try {
                            objD2 = MemoryError.Type.c.d(protoReader);
                        } catch (ProtoAdapter.EnumConstantNotFoundException e2) {
                            protoReader.a(i2, FieldEncoding.c, Long.valueOf(e2.a));
                        }
                    } else if (i2 != 3) {
                        protoReader.p(i2);
                    } else {
                        objD3 = HeapObject.m.d(protoReader);
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, MemoryError memoryError) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(memoryError, "value");
                if (memoryError.f() != MemoryError.Tool.d) {
                    MemoryError.Tool.c.l(protoWriter, 1, memoryError.f());
                }
                if (memoryError.g() != MemoryError.Type.d) {
                    MemoryError.Type.c.l(protoWriter, 2, memoryError.g());
                }
                HeapObject.m.l(protoWriter, 3, memoryError.e());
                protoWriter.a(memoryError.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, MemoryError memoryError) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(memoryError, "value");
                reverseProtoWriter.j(memoryError.d());
                HeapObject.m.m(reverseProtoWriter, 3, memoryError.e());
                if (memoryError.g() != MemoryError.Type.d) {
                    MemoryError.Type.c.m(reverseProtoWriter, 2, memoryError.g());
                }
                if (memoryError.f() != MemoryError.Tool.d) {
                    MemoryError.Tool.c.m(reverseProtoWriter, 1, memoryError.f());
                }
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(MemoryError memoryError) {
                Intrinsics.checkNotNullParameter(memoryError, "value");
                int size = memoryError.d().size();
                if (memoryError.f() != MemoryError.Tool.d) {
                    size += MemoryError.Tool.c.o(1, memoryError.f());
                }
                if (memoryError.g() != MemoryError.Type.d) {
                    size += MemoryError.Type.c.o(2, memoryError.g());
                }
                return size + HeapObject.m.o(3, memoryError.e());
            }
        };
    }

    public MemoryError() {
        this(null, null, null, null, 15, null);
    }

    public final HeapObject e() {
        return this.h;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MemoryError)) {
            return false;
        }
        MemoryError memoryError = (MemoryError) obj;
        return Intrinsics.areEqual(d(), memoryError.d()) && this.f == memoryError.f && this.g == memoryError.g && Intrinsics.areEqual(this.h, memoryError.h);
    }

    public final Tool f() {
        return this.f;
    }

    public final Type g() {
        return this.g;
    }

    public int hashCode() {
        int i2 = ((Message) this).d;
        if (i2 != 0) {
            return i2;
        }
        int iHashCode = ((((d().hashCode() * 37) + this.f.hashCode()) * 37) + this.g.hashCode()) * 37;
        HeapObject heapObject = this.h;
        int iHashCode2 = iHashCode + (heapObject != null ? heapObject.hashCode() : 0);
        ((Message) this).d = iHashCode2;
        return iHashCode2;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("tool=" + this.f);
        arrayList.add("type=" + this.g);
        if (this.h != null) {
            arrayList.add("heap=" + this.h);
        }
        return CollectionsKt.joinToString$default(arrayList, ", ", "MemoryError{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ MemoryError(Tool tool, Type type, HeapObject heapObject, ByteString byteString, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? Tool.d : tool, (i2 & 2) != 0 ? Type.d : type, (i2 & 4) != 0 ? null : heapObject, (i2 & 8) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MemoryError(Tool tool, Type type, HeapObject heapObject, ByteString byteString) {
        super(j, byteString);
        Intrinsics.checkNotNullParameter(tool, ap.a(234568807));
        Intrinsics.checkNotNullParameter(type, ap.a(821537627));
        Intrinsics.checkNotNullParameter(byteString, ap.a(620905826));
        this.f = tool;
        this.g = type;
        this.h = heapObject;
    }
}