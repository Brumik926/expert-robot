package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000<\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\b\n\u0002\b\u0016\u0018\u0000 +2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001,Bk\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007\u0012\b\b\u0002\u0010\t\u001a\u00020\u0007\u0012\b\b\u0002\u0010\n\u001a\u00020\u0007\u0012\b\b\u0002\u0010\f\u001a\u00020\u000b\u0012\b\b\u0002\u0010\r\u001a\u00020\u000b\u0012\b\b\u0002\u0010\u000e\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0010\u001a\u00020\u000f¢\u0006\u0004\b\u0011\u0010\u0012J\u001a\u0010\u0015\u001a\u00020\u00072\b\u0010\u0014\u001a\u0004\u0018\u00010\u0013H\u0096\u0002¢\u0006\u0004\b\u0015\u0010\u0016J\u000f\u0010\u0018\u001a\u00020\u0017H\u0016¢\u0006\u0004\b\u0018\u0010\u0019J\u000f\u0010\u001a\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\u001a\u0010\u001bR\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001c\u0010\u001d\u001a\u0004\b\u001e\u0010\u001fR\u001a\u0010\u0005\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b \u0010\u001d\u001a\u0004\b \u0010\u001fR\u001a\u0010\u0006\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b!\u0010\u001d\u001a\u0004\b\"\u0010\u001fR\u001a\u0010\b\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b#\u0010$\u001a\u0004\b%\u0010&R\u001a\u0010\t\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b'\u0010$\u001a\u0004\b(\u0010&R\u001a\u0010\n\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\"\u0010$\u001a\u0004\b!\u0010&R\u001a\u0010\f\u001a\u00020\u000b8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b%\u0010)\u001a\u0004\b'\u0010\u001bR\u001a\u0010\r\u001a\u00020\u000b8\u0006X\u0087\u0004¢\u0006\f\n\u0004\b(\u0010)\u001a\u0004\b\u001c\u0010\u001bR\u001a\u0010\u000e\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b*\u0010\u001d\u001a\u0004\b#\u0010\u001f¨\u0006-"}, d2 = {"LMemoryMapping;", "Lcom/squareup/wire/Message;", "", "", "begin_address", "end_address", "offset", "", "read", "write", "execute", "", "mapping_name", "build_id", "load_bias", "Lokio/ByteString;", "unknownFields", "<init>", "(JJJZZZLjava/lang/String;Ljava/lang/String;JLokio/ByteString;)V", "", "other", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "toString", "()Ljava/lang/String;", "f", "J", "e", "()J", "g", "h", "k", "i", "Z", "l", "()Z", "j", "m", "Ljava/lang/String;", "n", "o", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class MemoryMapping extends Message {
    public static final Companion o = new Companion(null);
    public static final ProtoAdapter p;
    private final long f;
    private final long g;
    private final long h;
    private final boolean i;
    private final boolean j;
    private final boolean k;
    private final String l;
    private final String m;
    private final long n;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LMemoryMapping$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LMemoryMapping;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(MemoryMapping.class);
        final Syntax syntax = Syntax.d;
        p = new ProtoAdapter<MemoryMapping>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: MemoryMapping$Companion$ADAPTER$1
            {
                String strA = ap.a(1935391638);
                String strA2 = ap.a(1961651808);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public MemoryMapping d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                long jD = protoReader.d();
                Object objD = "";
                long jLongValue = 0;
                long jLongValue2 = 0;
                long jLongValue3 = 0;
                long jLongValue4 = 0;
                boolean zBooleanValue = false;
                boolean zBooleanValue2 = false;
                boolean zBooleanValue3 = false;
                Object objD2 = "";
                while (true) {
                    int i = protoReader.i();
                    if (i == -1) {
                        return new MemoryMapping(jLongValue, jLongValue2, jLongValue3, zBooleanValue, zBooleanValue2, zBooleanValue3, (String) objD, (String) objD2, jLongValue4, protoReader.f(jD));
                    }
                    switch (i) {
                        case 1:
                            jLongValue = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 2:
                            jLongValue2 = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 3:
                            jLongValue3 = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 4:
                            zBooleanValue = ((Boolean) ProtoAdapter.j.d(protoReader)).booleanValue();
                            break;
                        case 5:
                            zBooleanValue2 = ((Boolean) ProtoAdapter.j.d(protoReader)).booleanValue();
                            break;
                        case 6:
                            zBooleanValue3 = ((Boolean) ProtoAdapter.j.d(protoReader)).booleanValue();
                            break;
                        case 7:
                            objD = ProtoAdapter.J.d(protoReader);
                            break;
                        case 8:
                            objD2 = ProtoAdapter.J.d(protoReader);
                            break;
                        case 9:
                            jLongValue4 = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        default:
                            protoReader.p(i);
                            break;
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, MemoryMapping memoryMapping) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(memoryMapping, "value");
                if (memoryMapping.e() != 0) {
                    ProtoAdapter.w.l(protoWriter, 1, Long.valueOf(memoryMapping.e()));
                }
                if (memoryMapping.g() != 0) {
                    ProtoAdapter.w.l(protoWriter, 2, Long.valueOf(memoryMapping.g()));
                }
                if (memoryMapping.k() != 0) {
                    ProtoAdapter.w.l(protoWriter, 3, Long.valueOf(memoryMapping.k()));
                }
                if (memoryMapping.l()) {
                    ProtoAdapter.j.l(protoWriter, 4, Boolean.valueOf(memoryMapping.l()));
                }
                if (memoryMapping.m()) {
                    ProtoAdapter.j.l(protoWriter, 5, Boolean.valueOf(memoryMapping.m()));
                }
                if (memoryMapping.h()) {
                    ProtoAdapter.j.l(protoWriter, 6, Boolean.valueOf(memoryMapping.h()));
                }
                if (!Intrinsics.areEqual(memoryMapping.j(), "")) {
                    ProtoAdapter.J.l(protoWriter, 7, memoryMapping.j());
                }
                if (!Intrinsics.areEqual(memoryMapping.f(), "")) {
                    ProtoAdapter.J.l(protoWriter, 8, memoryMapping.f());
                }
                if (memoryMapping.i() != 0) {
                    ProtoAdapter.w.l(protoWriter, 9, Long.valueOf(memoryMapping.i()));
                }
                protoWriter.a(memoryMapping.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, MemoryMapping memoryMapping) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(memoryMapping, "value");
                reverseProtoWriter.j(memoryMapping.d());
                if (memoryMapping.i() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 9, Long.valueOf(memoryMapping.i()));
                }
                if (!Intrinsics.areEqual(memoryMapping.f(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 8, memoryMapping.f());
                }
                if (!Intrinsics.areEqual(memoryMapping.j(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 7, memoryMapping.j());
                }
                if (memoryMapping.h()) {
                    ProtoAdapter.j.m(reverseProtoWriter, 6, Boolean.valueOf(memoryMapping.h()));
                }
                if (memoryMapping.m()) {
                    ProtoAdapter.j.m(reverseProtoWriter, 5, Boolean.valueOf(memoryMapping.m()));
                }
                if (memoryMapping.l()) {
                    ProtoAdapter.j.m(reverseProtoWriter, 4, Boolean.valueOf(memoryMapping.l()));
                }
                if (memoryMapping.k() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 3, Long.valueOf(memoryMapping.k()));
                }
                if (memoryMapping.g() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 2, Long.valueOf(memoryMapping.g()));
                }
                if (memoryMapping.e() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 1, Long.valueOf(memoryMapping.e()));
                }
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(MemoryMapping memoryMapping) {
                Intrinsics.checkNotNullParameter(memoryMapping, "value");
                int size = memoryMapping.d().size();
                if (memoryMapping.e() != 0) {
                    size += ProtoAdapter.w.o(1, Long.valueOf(memoryMapping.e()));
                }
                if (memoryMapping.g() != 0) {
                    size += ProtoAdapter.w.o(2, Long.valueOf(memoryMapping.g()));
                }
                if (memoryMapping.k() != 0) {
                    size += ProtoAdapter.w.o(3, Long.valueOf(memoryMapping.k()));
                }
                if (memoryMapping.l()) {
                    size += ProtoAdapter.j.o(4, Boolean.valueOf(memoryMapping.l()));
                }
                if (memoryMapping.m()) {
                    size += ProtoAdapter.j.o(5, Boolean.valueOf(memoryMapping.m()));
                }
                if (memoryMapping.h()) {
                    size += ProtoAdapter.j.o(6, Boolean.valueOf(memoryMapping.h()));
                }
                if (!Intrinsics.areEqual(memoryMapping.j(), "")) {
                    size += ProtoAdapter.J.o(7, memoryMapping.j());
                }
                if (!Intrinsics.areEqual(memoryMapping.f(), "")) {
                    size += ProtoAdapter.J.o(8, memoryMapping.f());
                }
                return memoryMapping.i() != 0 ? size + ProtoAdapter.w.o(9, Long.valueOf(memoryMapping.i())) : size;
            }
        };
    }

    public MemoryMapping() {
        this(0L, 0L, 0L, false, false, false, null, null, 0L, null, 1023, null);
    }

    public final long e() {
        return this.f;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof MemoryMapping)) {
            return false;
        }
        MemoryMapping memoryMapping = (MemoryMapping) obj;
        return Intrinsics.areEqual(d(), memoryMapping.d()) && this.f == memoryMapping.f && this.g == memoryMapping.g && this.h == memoryMapping.h && this.i == memoryMapping.i && this.j == memoryMapping.j && this.k == memoryMapping.k && Intrinsics.areEqual(this.l, memoryMapping.l) && Intrinsics.areEqual(this.m, memoryMapping.m) && this.n == memoryMapping.n;
    }

    public final String f() {
        return this.m;
    }

    public final long g() {
        return this.g;
    }

    public final boolean h() {
        return this.k;
    }

    public int hashCode() {
        int i = ((Message) this).d;
        if (i != 0) {
            return i;
        }
        int iHashCode = (((((((((((((((((d().hashCode() * 37) + Long.hashCode(this.f)) * 37) + Long.hashCode(this.g)) * 37) + Long.hashCode(this.h)) * 37) + Boolean.hashCode(this.i)) * 37) + Boolean.hashCode(this.j)) * 37) + Boolean.hashCode(this.k)) * 37) + this.l.hashCode()) * 37) + this.m.hashCode()) * 37) + Long.hashCode(this.n);
        ((Message) this).d = iHashCode;
        return iHashCode;
    }

    public final long i() {
        return this.n;
    }

    public final String j() {
        return this.l;
    }

    public final long k() {
        return this.h;
    }

    public final boolean l() {
        return this.i;
    }

    public final boolean m() {
        return this.j;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("begin_address=" + this.f);
        arrayList.add("end_address=" + this.g);
        arrayList.add("offset=" + this.h);
        arrayList.add("read=" + this.i);
        arrayList.add("write=" + this.j);
        arrayList.add("execute=" + this.k);
        arrayList.add("mapping_name=" + Internal.c(this.l));
        arrayList.add("build_id=" + Internal.c(this.m));
        arrayList.add("load_bias=" + this.n);
        return CollectionsKt.joinToString$default(arrayList, ", ", "MemoryMapping{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ MemoryMapping(long j, long j2, long j3, boolean z, boolean z2, boolean z3, String str, String str2, long j4, ByteString byteString, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? 0L : j, (i & 2) != 0 ? 0L : j2, (i & 4) != 0 ? 0L : j3, (i & 8) != 0 ? false : z, (i & 16) != 0 ? false : z2, (i & 32) == 0 ? z3 : false, (i & 64) != 0 ? "" : str, (i & 128) == 0 ? str2 : "", (i & 256) == 0 ? j4 : 0L, (i & 512) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MemoryMapping(long j, long j2, long j3, boolean z, boolean z2, boolean z3, String str, String str2, long j4, ByteString byteString) {
        super(p, byteString);
        Intrinsics.checkNotNullParameter(str, ap.a(842356915));
        Intrinsics.checkNotNullParameter(str2, ap.a(1003049612));
        Intrinsics.checkNotNullParameter(byteString, ap.a(1139963676));
        this.f = j;
        this.g = j2;
        this.h = j3;
        this.i = z;
        this.j = z2;
        this.k = z3;
        this.l = str;
        this.m = str2;
        this.n = j4;
    }
}