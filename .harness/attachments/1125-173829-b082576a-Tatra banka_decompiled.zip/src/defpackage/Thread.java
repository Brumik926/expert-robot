package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u001a\u0018\u0000 12\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u00012B\u0089\u0001\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\u000e\b\u0002\u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u0007\u0012\u000e\b\u0002\u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007\u0012\u000e\b\u0002\u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00050\u0007\u0012\u000e\b\u0002\u0010\r\u001a\b\u0012\u0004\u0012\u00020\f0\u0007\u0012\u000e\b\u0002\u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u000e0\u0007\u0012\b\b\u0002\u0010\u0011\u001a\u00020\u0010\u0012\b\b\u0002\u0010\u0012\u001a\u00020\u0010\u0012\b\b\u0002\u0010\u0014\u001a\u00020\u0013¢\u0006\u0004\b\u0015\u0010\u0016J\u001a\u0010\u001a\u001a\u00020\u00192\b\u0010\u0018\u001a\u0004\u0018\u00010\u0017H\u0096\u0002¢\u0006\u0004\b\u001a\u0010\u001bJ\u000f\u0010\u001c\u001a\u00020\u0003H\u0016¢\u0006\u0004\b\u001c\u0010\u001dJ\u000f\u0010\u001e\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u001e\u0010\u001fR\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b \u0010!\u001a\u0004\b\"\u0010\u001dR\u001a\u0010\u0006\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\"\u0010#\u001a\u0004\b$\u0010\u001fR\u001a\u0010\u0011\u001a\u00020\u00108\u0006X\u0087\u0004¢\u0006\f\n\u0004\b%\u0010&\u001a\u0004\b'\u0010(R\u001a\u0010\u0012\u001a\u00020\u00108\u0006X\u0087\u0004¢\u0006\f\n\u0004\b)\u0010&\u001a\u0004\b)\u0010(R \u0010\t\u001a\b\u0012\u0004\u0012\u00020\b0\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b*\u0010+\u001a\u0004\b*\u0010,R \u0010\n\u001a\b\u0012\u0004\u0012\u00020\u00050\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b'\u0010+\u001a\u0004\b-\u0010,R \u0010\u000b\u001a\b\u0012\u0004\u0012\u00020\u00050\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b.\u0010+\u001a\u0004\b.\u0010,R \u0010\r\u001a\b\u0012\u0004\u0012\u00020\f0\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b/\u0010+\u001a\u0004\b \u0010,R \u0010\u000f\u001a\b\u0012\u0004\u0012\u00020\u000e0\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b0\u0010+\u001a\u0004\b%\u0010,¨\u00063"}, d2 = {"LThread;", "Lcom/squareup/wire/Message;", "", "", "id", "", "name", "", "LRegister;", "registers", "backtrace_note", "unreadable_elf_files", "LBacktraceFrame;", "current_backtrace", "LMemoryDump;", "memory_dump", "", "tagged_addr_ctrl", "pac_enabled_keys", "Lokio/ByteString;", "unknownFields", "<init>", "(ILjava/lang/String;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;JJLokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "hashCode", "()I", "toString", "()Ljava/lang/String;", "f", "I", "g", "Ljava/lang/String;", "getName", "h", "J", "k", "()J", "i", "j", "Ljava/util/List;", "()Ljava/util/List;", "e", "l", "m", "n", "o", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class Thread extends Message {
    public static final Companion o = new Companion(null);
    public static final ProtoAdapter p;
    private final int f;
    private final String g;
    private final long h;
    private final long i;
    private final List j;
    private final List k;
    private final List l;
    private final List m;
    private final List n;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LThread$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LThread;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(Thread.class);
        final Syntax syntax = Syntax.d;
        p = new ProtoAdapter<Thread>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: Thread$Companion$ADAPTER$1
            {
                String strA = ap.a(853367060);
                String strA2 = ap.a(222995054);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public Thread d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                ArrayList arrayList = new ArrayList();
                ArrayList arrayList2 = new ArrayList();
                ArrayList arrayList3 = new ArrayList();
                ArrayList arrayList4 = new ArrayList();
                ArrayList arrayList5 = new ArrayList();
                long jD = protoReader.d();
                int iIntValue = 0;
                Object objD = "";
                long jLongValue = 0;
                long jLongValue2 = 0;
                while (true) {
                    int i = protoReader.i();
                    if (i == -1) {
                        return new Thread(iIntValue, (String) objD, arrayList, arrayList2, arrayList3, arrayList4, arrayList5, jLongValue, jLongValue2, protoReader.f(jD));
                    }
                    switch (i) {
                        case 1:
                            iIntValue = ((Number) ProtoAdapter.k.d(protoReader)).intValue();
                            break;
                        case 2:
                            objD = ProtoAdapter.J.d(protoReader);
                            break;
                        case 3:
                            arrayList.add(Register.i.d(protoReader));
                            break;
                        case 4:
                            arrayList4.add(BacktraceFrame.o.d(protoReader));
                            break;
                        case 5:
                            arrayList5.add(MemoryDump.l.d(protoReader));
                            break;
                        case 6:
                            jLongValue = ((Number) ProtoAdapter.u.d(protoReader)).longValue();
                            break;
                        case 7:
                            arrayList2.add(ProtoAdapter.J.d(protoReader));
                            break;
                        case 8:
                            jLongValue2 = ((Number) ProtoAdapter.u.d(protoReader)).longValue();
                            break;
                        case 9:
                            arrayList3.add(ProtoAdapter.J.d(protoReader));
                            break;
                        default:
                            protoReader.p(i);
                            break;
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, Thread thread) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(thread, "value");
                if (thread.g() != 0) {
                    ProtoAdapter.k.l(protoWriter, 1, Integer.valueOf(thread.g()));
                }
                if (!Intrinsics.areEqual(thread.getName(), "")) {
                    ProtoAdapter.J.l(protoWriter, 2, thread.getName());
                }
                Register.i.b().l(protoWriter, 3, thread.j());
                ProtoAdapter protoAdapter = ProtoAdapter.J;
                protoAdapter.b().l(protoWriter, 7, thread.e());
                protoAdapter.b().l(protoWriter, 9, thread.l());
                BacktraceFrame.o.b().l(protoWriter, 4, thread.f());
                MemoryDump.l.b().l(protoWriter, 5, thread.h());
                if (thread.k() != 0) {
                    ProtoAdapter.u.l(protoWriter, 6, Long.valueOf(thread.k()));
                }
                if (thread.i() != 0) {
                    ProtoAdapter.u.l(protoWriter, 8, Long.valueOf(thread.i()));
                }
                protoWriter.a(thread.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, Thread thread) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(thread, "value");
                reverseProtoWriter.j(thread.d());
                if (thread.i() != 0) {
                    ProtoAdapter.u.m(reverseProtoWriter, 8, Long.valueOf(thread.i()));
                }
                if (thread.k() != 0) {
                    ProtoAdapter.u.m(reverseProtoWriter, 6, Long.valueOf(thread.k()));
                }
                MemoryDump.l.b().m(reverseProtoWriter, 5, thread.h());
                BacktraceFrame.o.b().m(reverseProtoWriter, 4, thread.f());
                ProtoAdapter protoAdapter = ProtoAdapter.J;
                protoAdapter.b().m(reverseProtoWriter, 9, thread.l());
                protoAdapter.b().m(reverseProtoWriter, 7, thread.e());
                Register.i.b().m(reverseProtoWriter, 3, thread.j());
                if (!Intrinsics.areEqual(thread.getName(), "")) {
                    protoAdapter.m(reverseProtoWriter, 2, thread.getName());
                }
                if (thread.g() != 0) {
                    ProtoAdapter.k.m(reverseProtoWriter, 1, Integer.valueOf(thread.g()));
                }
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(Thread thread) {
                Intrinsics.checkNotNullParameter(thread, "value");
                int size = thread.d().size();
                if (thread.g() != 0) {
                    size += ProtoAdapter.k.o(1, Integer.valueOf(thread.g()));
                }
                if (!Intrinsics.areEqual(thread.getName(), "")) {
                    size += ProtoAdapter.J.o(2, thread.getName());
                }
                int iO = size + Register.i.b().o(3, thread.j());
                ProtoAdapter protoAdapter = ProtoAdapter.J;
                int iO2 = iO + protoAdapter.b().o(7, thread.e()) + protoAdapter.b().o(9, thread.l()) + BacktraceFrame.o.b().o(4, thread.f()) + MemoryDump.l.b().o(5, thread.h());
                if (thread.k() != 0) {
                    iO2 += ProtoAdapter.u.o(6, Long.valueOf(thread.k()));
                }
                return thread.i() != 0 ? iO2 + ProtoAdapter.u.o(8, Long.valueOf(thread.i())) : iO2;
            }
        };
    }

    public Thread() {
        this(0, null, null, null, null, null, null, 0L, 0L, null, 1023, null);
    }

    public final List e() {
        return this.k;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Thread)) {
            return false;
        }
        Thread thread = (Thread) obj;
        return Intrinsics.areEqual(d(), thread.d()) && this.f == thread.f && Intrinsics.areEqual(this.g, thread.g) && Intrinsics.areEqual(this.j, thread.j) && Intrinsics.areEqual(this.k, thread.k) && Intrinsics.areEqual(this.l, thread.l) && Intrinsics.areEqual(this.m, thread.m) && Intrinsics.areEqual(this.n, thread.n) && this.h == thread.h && this.i == thread.i;
    }

    public final List f() {
        return this.m;
    }

    public final int g() {
        return this.f;
    }

    public final String getName() {
        return this.g;
    }

    public final List h() {
        return this.n;
    }

    public int hashCode() {
        int i = ((Message) this).d;
        if (i != 0) {
            return i;
        }
        int iHashCode = (((((((((((((((((d().hashCode() * 37) + Integer.hashCode(this.f)) * 37) + this.g.hashCode()) * 37) + this.j.hashCode()) * 37) + this.k.hashCode()) * 37) + this.l.hashCode()) * 37) + this.m.hashCode()) * 37) + this.n.hashCode()) * 37) + Long.hashCode(this.h)) * 37) + Long.hashCode(this.i);
        ((Message) this).d = iHashCode;
        return iHashCode;
    }

    public final long i() {
        return this.i;
    }

    public final List j() {
        return this.j;
    }

    public final long k() {
        return this.h;
    }

    public final List l() {
        return this.l;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("id=" + this.f);
        arrayList.add("name=" + Internal.c(this.g));
        if (!this.j.isEmpty()) {
            arrayList.add("registers=" + this.j);
        }
        if (!this.k.isEmpty()) {
            arrayList.add("backtrace_note=" + Internal.d(this.k));
        }
        if (!this.l.isEmpty()) {
            arrayList.add("unreadable_elf_files=" + Internal.d(this.l));
        }
        if (!this.m.isEmpty()) {
            arrayList.add("current_backtrace=" + this.m);
        }
        if (!this.n.isEmpty()) {
            arrayList.add("memory_dump=" + this.n);
        }
        arrayList.add("tagged_addr_ctrl=" + this.h);
        arrayList.add("pac_enabled_keys=" + this.i);
        return CollectionsKt.joinToString$default(arrayList, ", ", "Thread{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ Thread(int i, String str, List list, List list2, List list3, List list4, List list5, long j, long j2, ByteString byteString, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? 0 : i, (i2 & 2) != 0 ? "" : str, (i2 & 4) != 0 ? CollectionsKt.emptyList() : list, (i2 & 8) != 0 ? CollectionsKt.emptyList() : list2, (i2 & 16) != 0 ? CollectionsKt.emptyList() : list3, (i2 & 32) != 0 ? CollectionsKt.emptyList() : list4, (i2 & 64) != 0 ? CollectionsKt.emptyList() : list5, (i2 & 128) != 0 ? 0L : j, (i2 & 256) == 0 ? j2 : 0L, (i2 & 512) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Thread(int i, String str, List list, List list2, List list3, List list4, List list5, long j, long j2, ByteString byteString) {
        super(p, byteString);
        Intrinsics.checkNotNullParameter(str, ap.a(107697976));
        String strA = ap.a(743609401);
        Intrinsics.checkNotNullParameter(list, strA);
        String strA2 = ap.a(1412330975);
        Intrinsics.checkNotNullParameter(list2, strA2);
        String strA3 = ap.a(125831429);
        Intrinsics.checkNotNullParameter(list3, strA3);
        String strA4 = ap.a(1410168920);
        Intrinsics.checkNotNullParameter(list4, strA4);
        String strA5 = ap.a(2063474672);
        Intrinsics.checkNotNullParameter(list5, strA5);
        Intrinsics.checkNotNullParameter(byteString, ap.a(270710410));
        this.f = i;
        this.g = str;
        this.h = j;
        this.i = j2;
        this.j = Internal.a(strA, list);
        this.k = Internal.a(strA2, list2);
        this.l = Internal.a(strA3, list3);
        this.m = Internal.a(strA4, list4);
        this.n = Internal.a(strA5, list5);
    }
}