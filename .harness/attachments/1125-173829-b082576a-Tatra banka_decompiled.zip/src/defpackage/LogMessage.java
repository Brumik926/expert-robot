package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u00000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0013\u0018\u0000 \"2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001#BM\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0005\u0012\b\b\u0002\u0010\b\u001a\u00020\u0005\u0012\b\b\u0002\u0010\t\u001a\u00020\u0003\u0012\b\b\u0002\u0010\n\u001a\u00020\u0003\u0012\b\b\u0002\u0010\f\u001a\u00020\u000b¢\u0006\u0004\b\r\u0010\u000eJ\u001a\u0010\u0012\u001a\u00020\u00112\b\u0010\u0010\u001a\u0004\u0018\u00010\u000fH\u0096\u0002¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0014\u001a\u00020\u0005H\u0016¢\u0006\u0004\b\u0014\u0010\u0015J\u000f\u0010\u0016\u001a\u00020\u0003H\u0016¢\u0006\u0004\b\u0016\u0010\u0017R\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0018\u0010\u0019\u001a\u0004\b\u001a\u0010\u0017R\u001a\u0010\u0006\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u0018\u0010\u0015R\u001a\u0010\u0007\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001d\u0010\u001c\u001a\u0004\b\u001d\u0010\u0015R\u001a\u0010\b\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001a\u0010\u001c\u001a\u0004\b\u001b\u0010\u0015R\u001a\u0010\t\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001e\u0010\u0019\u001a\u0004\b\u001f\u0010\u0017R\u001a\u0010\n\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b \u0010\u0019\u001a\u0004\b!\u0010\u0017¨\u0006$"}, d2 = {"LLogMessage;", "Lcom/squareup/wire/Message;", "", "", "timestamp", "", "pid", "tid", "priority", "tag", "message", "Lokio/ByteString;", "unknownFields", "<init>", "(Ljava/lang/String;IIILjava/lang/String;Ljava/lang/String;Lokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "hashCode", "()I", "toString", "()Ljava/lang/String;", "f", "Ljava/lang/String;", "i", "g", "I", "h", "j", "getTag", "k", "e", "l", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class LogMessage extends Message {
    public static final Companion l = new Companion(null);
    public static final ProtoAdapter m;
    private final String f;
    private final int g;
    private final int h;
    private final int i;
    private final String j;
    private final String k;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LLogMessage$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LLogMessage;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(LogMessage.class);
        final Syntax syntax = Syntax.d;
        m = new ProtoAdapter<LogMessage>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: LogMessage$Companion$ADAPTER$1
            {
                String strA = ap.a(1961686565);
                String strA2 = ap.a(639548383);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public LogMessage d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                long jD = protoReader.d();
                Object objD = "";
                Object objD2 = "";
                int iIntValue = 0;
                int iIntValue2 = 0;
                int iIntValue3 = 0;
                Object objD3 = objD2;
                while (true) {
                    int i = protoReader.i();
                    if (i == -1) {
                        return new LogMessage((String) objD, iIntValue, iIntValue2, iIntValue3, (String) objD3, (String) objD2, protoReader.f(jD));
                    }
                    switch (i) {
                        case 1:
                            objD = ProtoAdapter.J.d(protoReader);
                            break;
                        case 2:
                            iIntValue = ((Number) ProtoAdapter.m.d(protoReader)).intValue();
                            break;
                        case 3:
                            iIntValue2 = ((Number) ProtoAdapter.m.d(protoReader)).intValue();
                            break;
                        case 4:
                            iIntValue3 = ((Number) ProtoAdapter.m.d(protoReader)).intValue();
                            break;
                        case 5:
                            objD3 = ProtoAdapter.J.d(protoReader);
                            break;
                        case 6:
                            objD2 = ProtoAdapter.J.d(protoReader);
                            break;
                        default:
                            protoReader.p(i);
                            break;
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, LogMessage logMessage) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(logMessage, "value");
                if (!Intrinsics.areEqual(logMessage.i(), "")) {
                    ProtoAdapter.J.l(protoWriter, 1, logMessage.i());
                }
                if (logMessage.f() != 0) {
                    ProtoAdapter.m.l(protoWriter, 2, Integer.valueOf(logMessage.f()));
                }
                if (logMessage.h() != 0) {
                    ProtoAdapter.m.l(protoWriter, 3, Integer.valueOf(logMessage.h()));
                }
                if (logMessage.g() != 0) {
                    ProtoAdapter.m.l(protoWriter, 4, Integer.valueOf(logMessage.g()));
                }
                if (!Intrinsics.areEqual(logMessage.getTag(), "")) {
                    ProtoAdapter.J.l(protoWriter, 5, logMessage.getTag());
                }
                if (!Intrinsics.areEqual(logMessage.e(), "")) {
                    ProtoAdapter.J.l(protoWriter, 6, logMessage.e());
                }
                protoWriter.a(logMessage.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, LogMessage logMessage) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(logMessage, "value");
                reverseProtoWriter.j(logMessage.d());
                if (!Intrinsics.areEqual(logMessage.e(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 6, logMessage.e());
                }
                if (!Intrinsics.areEqual(logMessage.getTag(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 5, logMessage.getTag());
                }
                if (logMessage.g() != 0) {
                    ProtoAdapter.m.m(reverseProtoWriter, 4, Integer.valueOf(logMessage.g()));
                }
                if (logMessage.h() != 0) {
                    ProtoAdapter.m.m(reverseProtoWriter, 3, Integer.valueOf(logMessage.h()));
                }
                if (logMessage.f() != 0) {
                    ProtoAdapter.m.m(reverseProtoWriter, 2, Integer.valueOf(logMessage.f()));
                }
                if (Intrinsics.areEqual(logMessage.i(), "")) {
                    return;
                }
                ProtoAdapter.J.m(reverseProtoWriter, 1, logMessage.i());
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(LogMessage logMessage) {
                Intrinsics.checkNotNullParameter(logMessage, "value");
                int size = logMessage.d().size();
                if (!Intrinsics.areEqual(logMessage.i(), "")) {
                    size += ProtoAdapter.J.o(1, logMessage.i());
                }
                if (logMessage.f() != 0) {
                    size += ProtoAdapter.m.o(2, Integer.valueOf(logMessage.f()));
                }
                if (logMessage.h() != 0) {
                    size += ProtoAdapter.m.o(3, Integer.valueOf(logMessage.h()));
                }
                if (logMessage.g() != 0) {
                    size += ProtoAdapter.m.o(4, Integer.valueOf(logMessage.g()));
                }
                if (!Intrinsics.areEqual(logMessage.getTag(), "")) {
                    size += ProtoAdapter.J.o(5, logMessage.getTag());
                }
                return !Intrinsics.areEqual(logMessage.e(), "") ? size + ProtoAdapter.J.o(6, logMessage.e()) : size;
            }
        };
    }

    public LogMessage() {
        this(null, 0, 0, 0, null, null, null, 127, null);
    }

    public final String e() {
        return this.k;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof LogMessage)) {
            return false;
        }
        LogMessage logMessage = (LogMessage) obj;
        return Intrinsics.areEqual(d(), logMessage.d()) && Intrinsics.areEqual(this.f, logMessage.f) && this.g == logMessage.g && this.h == logMessage.h && this.i == logMessage.i && Intrinsics.areEqual(this.j, logMessage.j) && Intrinsics.areEqual(this.k, logMessage.k);
    }

    public final int f() {
        return this.g;
    }

    public final int g() {
        return this.i;
    }

    public final String getTag() {
        return this.j;
    }

    public final int h() {
        return this.h;
    }

    public int hashCode() {
        int i = ((Message) this).d;
        if (i != 0) {
            return i;
        }
        int iHashCode = (((((((((((d().hashCode() * 37) + this.f.hashCode()) * 37) + Integer.hashCode(this.g)) * 37) + Integer.hashCode(this.h)) * 37) + Integer.hashCode(this.i)) * 37) + this.j.hashCode()) * 37) + this.k.hashCode();
        ((Message) this).d = iHashCode;
        return iHashCode;
    }

    public final String i() {
        return this.f;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("timestamp=" + Internal.c(this.f));
        arrayList.add("pid=" + this.g);
        arrayList.add("tid=" + this.h);
        arrayList.add("priority=" + this.i);
        arrayList.add("tag=" + Internal.c(this.j));
        arrayList.add("message=" + Internal.c(this.k));
        return CollectionsKt.joinToString$default(arrayList, ", ", "LogMessage{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ LogMessage(String str, int i, int i2, int i3, String str2, String str3, ByteString byteString, int i4, DefaultConstructorMarker defaultConstructorMarker) {
        this((i4 & 1) != 0 ? "" : str, (i4 & 2) != 0 ? 0 : i, (i4 & 4) != 0 ? 0 : i2, (i4 & 8) != 0 ? 0 : i3, (i4 & 16) != 0 ? "" : str2, (i4 & 32) != 0 ? "" : str3, (i4 & 64) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public LogMessage(String str, int i, int i2, int i3, String str2, String str3, ByteString byteString) {
        super(m, byteString);
        Intrinsics.checkNotNullParameter(str, ap.a(1106115678));
        Intrinsics.checkNotNullParameter(str2, ap.a(973899466));
        Intrinsics.checkNotNullParameter(str3, ap.a(733039178));
        Intrinsics.checkNotNullParameter(byteString, ap.a(1142139448));
        this.f = str;
        this.g = i;
        this.h = i2;
        this.i = i3;
        this.j = str2;
        this.k = str3;
    }
}