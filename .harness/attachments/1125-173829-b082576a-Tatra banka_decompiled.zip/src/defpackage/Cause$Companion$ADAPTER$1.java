package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import h.ap;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.reflect.KClass;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes5.dex */
@Metadata(d1 = {"\u00005\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0005\u0010\u0006J\u001f\u0010\n\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\n\u0010\u000bJ\u001f\u0010\r\u001a\u00020\t2\u0006\u0010\b\u001a\u00020\f2\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\r\u0010\u000eJ\u0017\u0010\u0011\u001a\u00020\u00022\u0006\u0010\u0010\u001a\u00020\u000fH\u0016¢\u0006\u0004\b\u0011\u0010\u0012¨\u0006\u0013"}, d2 = {"Cause$Companion$ADAPTER$1", "Lcom/squareup/wire/ProtoAdapter;", "LCause;", "value", "", "y", "(LCause;)I", "Lcom/squareup/wire/ProtoWriter;", "writer", "", "w", "(Lcom/squareup/wire/ProtoWriter;LCause;)V", "Lcom/squareup/wire/ReverseProtoWriter;", "x", "(Lcom/squareup/wire/ReverseProtoWriter;LCause;)V", "Lcom/squareup/wire/ProtoReader;", "reader", "v", "(Lcom/squareup/wire/ProtoReader;)LCause;", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nCause.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Cause.kt\nCause$Companion$ADAPTER$1\n+ 2 ProtoReader.kt\ncom/squareup/wire/ProtoReader\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,152:1\n472#2,7:153\n1#3:160\n*S KotlinDebug\n*F\n+ 1 Cause.kt\nCause$Companion$ADAPTER$1\n*L\n129#1:153,7\n*E\n"})
public final class Cause$Companion$ADAPTER$1 extends ProtoAdapter<Cause> {
    Cause$Companion$ADAPTER$1(FieldEncoding fieldEncoding, KClass kClass, Syntax syntax) {
        super(fieldEncoding, kClass, ap.a(93108648), syntax, (Object) null, ap.a(1745952823));
    }

    /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
    public Cause d(ProtoReader protoReader) {
        Intrinsics.checkNotNullParameter(protoReader, "reader");
        long jD = protoReader.d();
        Object objD = "";
        Object objD2 = null;
        while (true) {
            int i = protoReader.i();
            if (i == -1) {
                return new Cause((String) objD, (MemoryError) objD2, protoReader.f(jD));
            }
            if (i == 1) {
                objD = ProtoAdapter.J.d(protoReader);
            } else if (i != 2) {
                protoReader.p(i);
            } else {
                objD2 = MemoryError.j.d(protoReader);
            }
        }
    }

    /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
    public void h(ProtoWriter protoWriter, Cause cause) {
        Intrinsics.checkNotNullParameter(protoWriter, "writer");
        Intrinsics.checkNotNullParameter(cause, "value");
        if (!Intrinsics.areEqual(cause.e(), "")) {
            ProtoAdapter.J.l(protoWriter, 1, cause.e());
        }
        MemoryError.j.l(protoWriter, 2, cause.f());
        protoWriter.a(cause.d());
    }

    /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
    public void i(ReverseProtoWriter reverseProtoWriter, Cause cause) {
        Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
        Intrinsics.checkNotNullParameter(cause, "value");
        reverseProtoWriter.j(cause.d());
        MemoryError.j.m(reverseProtoWriter, 2, cause.f());
        if (Intrinsics.areEqual(cause.e(), "")) {
            return;
        }
        ProtoAdapter.J.m(reverseProtoWriter, 1, cause.e());
    }

    /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
    public int n(Cause cause) {
        Intrinsics.checkNotNullParameter(cause, "value");
        int size = cause.d().size();
        if (!Intrinsics.areEqual(cause.e(), "")) {
            size += ProtoAdapter.J.o(1, cause.e());
        }
        return size + MemoryError.j.o(2, cause.f());
    }
}