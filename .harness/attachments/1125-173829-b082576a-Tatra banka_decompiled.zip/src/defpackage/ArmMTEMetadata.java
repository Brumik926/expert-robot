package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import h.ap;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes.dex */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\t\u0018\u0000 \u00172\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u0018B\u001b\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003¢\u0006\u0004\b\u0006\u0010\u0007J\u001a\u0010\u000b\u001a\u00020\n2\b\u0010\t\u001a\u0004\u0018\u00010\bH\u0096\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u000f\u0010\u000e\u001a\u00020\rH\u0016¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0011\u0010\u0012R\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0013\u0010\u0014\u001a\u0004\b\u0015\u0010\u0016¨\u0006\u0019"}, d2 = {"LArmMTEMetadata;", "Lcom/squareup/wire/Message;", "", "Lokio/ByteString;", "memory_tags", "unknownFields", "<init>", "(Lokio/ByteString;Lokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "", "toString", "()Ljava/lang/String;", "f", "Lokio/ByteString;", "e", "()Lokio/ByteString;", "g", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class ArmMTEMetadata extends Message {
    public static final Companion g = new Companion(null);
    public static final ProtoAdapter h;
    private final ByteString f;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LArmMTEMetadata$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LArmMTEMetadata;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(ArmMTEMetadata.class);
        final Syntax syntax = Syntax.d;
        h = new ProtoAdapter<ArmMTEMetadata>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: ArmMTEMetadata$Companion$ADAPTER$1
            {
                String strA = ap.a(105087598);
                String strA2 = ap.a(1376003807);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public ArmMTEMetadata d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                Object objD = ByteString.e;
                long jD = protoReader.d();
                while (true) {
                    int i = protoReader.i();
                    if (i == -1) {
                        return new ArmMTEMetadata((ByteString) objD, protoReader.f(jD));
                    }
                    if (i == 1) {
                        objD = ProtoAdapter.I.d(protoReader);
                    } else {
                        protoReader.p(i);
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, ArmMTEMetadata armMTEMetadata) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(armMTEMetadata, "value");
                if (!Intrinsics.areEqual(armMTEMetadata.e(), ByteString.e)) {
                    ProtoAdapter.I.l(protoWriter, 1, armMTEMetadata.e());
                }
                protoWriter.a(armMTEMetadata.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, ArmMTEMetadata armMTEMetadata) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(armMTEMetadata, "value");
                reverseProtoWriter.j(armMTEMetadata.d());
                if (Intrinsics.areEqual(armMTEMetadata.e(), ByteString.e)) {
                    return;
                }
                ProtoAdapter.I.m(reverseProtoWriter, 1, armMTEMetadata.e());
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(ArmMTEMetadata armMTEMetadata) {
                Intrinsics.checkNotNullParameter(armMTEMetadata, "value");
                int size = armMTEMetadata.d().size();
                return !Intrinsics.areEqual(armMTEMetadata.e(), ByteString.e) ? size + ProtoAdapter.I.o(1, armMTEMetadata.e()) : size;
            }
        };
    }

    /* JADX WARN: Illegal instructions before constructor call */
    public ArmMTEMetadata() {
        ByteString byteString = null;
        this(byteString, byteString, 3, byteString);
    }

    public final ByteString e() {
        return this.f;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ArmMTEMetadata)) {
            return false;
        }
        ArmMTEMetadata armMTEMetadata = (ArmMTEMetadata) obj;
        return Intrinsics.areEqual(d(), armMTEMetadata.d()) && Intrinsics.areEqual(this.f, armMTEMetadata.f);
    }

    public int hashCode() {
        int i = ((Message) this).d;
        if (i != 0) {
            return i;
        }
        int iHashCode = (d().hashCode() * 37) + this.f.hashCode();
        ((Message) this).d = iHashCode;
        return iHashCode;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("memory_tags=" + this.f);
        return CollectionsKt.joinToString$default(arrayList, ", ", "ArmMTEMetadata{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ ArmMTEMetadata(ByteString byteString, ByteString byteString2, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? ByteString.e : byteString, (i & 2) != 0 ? ByteString.e : byteString2);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ArmMTEMetadata(ByteString byteString, ByteString byteString2) {
        super(h, byteString2);
        Intrinsics.checkNotNullParameter(byteString, ap.a(1824389046));
        Intrinsics.checkNotNullParameter(byteString2, ap.a(1624394068));
        this.f = byteString;
    }
}