package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0010\u000e\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u000e\u0018\u0000 \u001c2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u001dB%\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\t\u0010\nJ\u001a\u0010\u000e\u001a\u00020\r2\b\u0010\f\u001a\u0004\u0018\u00010\u000bH\u0096\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ\u000f\u0010\u0011\u001a\u00020\u0010H\u0016¢\u0006\u0004\b\u0011\u0010\u0012J\u000f\u0010\u0013\u001a\u00020\u0003H\u0016¢\u0006\u0004\b\u0013\u0010\u0014R\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0015\u0010\u0016\u001a\u0004\b\u0017\u0010\u0014R\u001a\u0010\u0006\u001a\u00020\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0018\u0010\u0019\u001a\u0004\b\u001a\u0010\u001b¨\u0006\u001e"}, d2 = {"LRegister;", "Lcom/squareup/wire/Message;", "", "", "name", "", "u64", "Lokio/ByteString;", "unknownFields", "<init>", "(Ljava/lang/String;JLokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "toString", "()Ljava/lang/String;", "f", "Ljava/lang/String;", "getName", "g", "J", "e", "()J", "h", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class Register extends Message {
    public static final Companion h = new Companion(null);
    public static final ProtoAdapter i;
    private final String f;
    private final long g;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LRegister$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LRegister;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(Register.class);
        final Syntax syntax = Syntax.d;
        i = new ProtoAdapter<Register>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: Register$Companion$ADAPTER$1
            {
                String strA = ap.a(910932525);
                String strA2 = ap.a(1078206821);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public Register d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                long jD = protoReader.d();
                Object objD = "";
                long jLongValue = 0;
                while (true) {
                    int i2 = protoReader.i();
                    if (i2 == -1) {
                        return new Register((String) objD, jLongValue, protoReader.f(jD));
                    }
                    if (i2 == 1) {
                        objD = ProtoAdapter.J.d(protoReader);
                    } else if (i2 != 2) {
                        protoReader.p(i2);
                    } else {
                        jLongValue = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, Register register) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(register, "value");
                if (!Intrinsics.areEqual(register.getName(), "")) {
                    ProtoAdapter.J.l(protoWriter, 1, register.getName());
                }
                if (register.e() != 0) {
                    ProtoAdapter.w.l(protoWriter, 2, Long.valueOf(register.e()));
                }
                protoWriter.a(register.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, Register register) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(register, "value");
                reverseProtoWriter.j(register.d());
                if (register.e() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 2, Long.valueOf(register.e()));
                }
                if (Intrinsics.areEqual(register.getName(), "")) {
                    return;
                }
                ProtoAdapter.J.m(reverseProtoWriter, 1, register.getName());
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(Register register) {
                Intrinsics.checkNotNullParameter(register, "value");
                int size = register.d().size();
                if (!Intrinsics.areEqual(register.getName(), "")) {
                    size += ProtoAdapter.J.o(1, register.getName());
                }
                return register.e() != 0 ? size + ProtoAdapter.w.o(2, Long.valueOf(register.e())) : size;
            }
        };
    }

    public Register() {
        this(null, 0L, null, 7, null);
    }

    public final long e() {
        return this.g;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof Register)) {
            return false;
        }
        Register register = (Register) obj;
        return Intrinsics.areEqual(d(), register.d()) && Intrinsics.areEqual(this.f, register.f) && this.g == register.g;
    }

    public final String getName() {
        return this.f;
    }

    public int hashCode() {
        int i2 = ((Message) this).d;
        if (i2 != 0) {
            return i2;
        }
        int iHashCode = (((d().hashCode() * 37) + this.f.hashCode()) * 37) + Long.hashCode(this.g);
        ((Message) this).d = iHashCode;
        return iHashCode;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("name=" + Internal.c(this.f));
        arrayList.add("u64=" + this.g);
        return CollectionsKt.joinToString$default(arrayList, ", ", "Register{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ Register(String str, long j, ByteString byteString, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? "" : str, (i2 & 2) != 0 ? 0L : j, (i2 & 4) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public Register(String str, long j, ByteString byteString) {
        super(i, byteString);
        Intrinsics.checkNotNullParameter(str, ap.a(641709402));
        Intrinsics.checkNotNullParameter(byteString, ap.a(1460780012));
        this.f = str;
        this.g = j;
    }
}