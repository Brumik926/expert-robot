package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import java.util.List;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0010\t\n\u0000\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\f\u0018\u0000 \u001e2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u001fB+\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\u000e\b\u0002\u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u0005\u0012\b\b\u0002\u0010\t\u001a\u00020\b¢\u0006\u0004\b\n\u0010\u000bJ\u001a\u0010\u000f\u001a\u00020\u000e2\b\u0010\r\u001a\u0004\u0018\u00010\fH\u0096\u0002¢\u0006\u0004\b\u000f\u0010\u0010J\u000f\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\b\u0012\u0010\u0013J\u000f\u0010\u0015\u001a\u00020\u0014H\u0016¢\u0006\u0004\b\u0015\u0010\u0016R\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0017\u0010\u0018\u001a\u0004\b\u0017\u0010\u0019R \u0010\u0007\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001a\u0010\u001b\u001a\u0004\b\u001c\u0010\u001d¨\u0006 "}, d2 = {"LStackHistoryBuffer;", "Lcom/squareup/wire/Message;", "", "", "tid", "", "LStackHistoryBufferEntry;", "entries", "Lokio/ByteString;", "unknownFields", "<init>", "(JLjava/util/List;Lokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "", "toString", "()Ljava/lang/String;", "f", "J", "()J", "g", "Ljava/util/List;", "e", "()Ljava/util/List;", "h", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class StackHistoryBuffer extends Message {
    public static final Companion h = new Companion(null);
    public static final ProtoAdapter i;
    private final long f;
    private final List g;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LStackHistoryBuffer$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LStackHistoryBuffer;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(StackHistoryBuffer.class);
        final Syntax syntax = Syntax.d;
        i = new ProtoAdapter<StackHistoryBuffer>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: StackHistoryBuffer$Companion$ADAPTER$1
            {
                String strA = ap.a(1405331704);
                String strA2 = ap.a(856681648);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public StackHistoryBuffer d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                ArrayList arrayList = new ArrayList();
                long jD = protoReader.d();
                long jLongValue = 0;
                while (true) {
                    int i2 = protoReader.i();
                    if (i2 == -1) {
                        return new StackHistoryBuffer(jLongValue, arrayList, protoReader.f(jD));
                    }
                    if (i2 == 1) {
                        jLongValue = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                    } else if (i2 != 2) {
                        protoReader.p(i2);
                    } else {
                        arrayList.add(StackHistoryBufferEntry.j.d(protoReader));
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, StackHistoryBuffer stackHistoryBuffer) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(stackHistoryBuffer, "value");
                if (stackHistoryBuffer.f() != 0) {
                    ProtoAdapter.w.l(protoWriter, 1, Long.valueOf(stackHistoryBuffer.f()));
                }
                StackHistoryBufferEntry.j.b().l(protoWriter, 2, stackHistoryBuffer.e());
                protoWriter.a(stackHistoryBuffer.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, StackHistoryBuffer stackHistoryBuffer) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(stackHistoryBuffer, "value");
                reverseProtoWriter.j(stackHistoryBuffer.d());
                StackHistoryBufferEntry.j.b().m(reverseProtoWriter, 2, stackHistoryBuffer.e());
                if (stackHistoryBuffer.f() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 1, Long.valueOf(stackHistoryBuffer.f()));
                }
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(StackHistoryBuffer stackHistoryBuffer) {
                Intrinsics.checkNotNullParameter(stackHistoryBuffer, "value");
                int size = stackHistoryBuffer.d().size();
                if (stackHistoryBuffer.f() != 0) {
                    size += ProtoAdapter.w.o(1, Long.valueOf(stackHistoryBuffer.f()));
                }
                return size + StackHistoryBufferEntry.j.b().o(2, stackHistoryBuffer.e());
            }
        };
    }

    public StackHistoryBuffer() {
        this(0L, null, null, 7, null);
    }

    public final List e() {
        return this.g;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof StackHistoryBuffer)) {
            return false;
        }
        StackHistoryBuffer stackHistoryBuffer = (StackHistoryBuffer) obj;
        return Intrinsics.areEqual(d(), stackHistoryBuffer.d()) && this.f == stackHistoryBuffer.f && Intrinsics.areEqual(this.g, stackHistoryBuffer.g);
    }

    public final long f() {
        return this.f;
    }

    public int hashCode() {
        int i2 = ((Message) this).d;
        if (i2 != 0) {
            return i2;
        }
        int iHashCode = (((d().hashCode() * 37) + Long.hashCode(this.f)) * 37) + this.g.hashCode();
        ((Message) this).d = iHashCode;
        return iHashCode;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("tid=" + this.f);
        if (!this.g.isEmpty()) {
            arrayList.add("entries=" + this.g);
        }
        return CollectionsKt.joinToString$default(arrayList, ", ", "StackHistoryBuffer{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ StackHistoryBuffer(long j, List list, ByteString byteString, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? 0L : j, (i2 & 2) != 0 ? CollectionsKt.emptyList() : list, (i2 & 4) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public StackHistoryBuffer(long j, List list, ByteString byteString) {
        super(i, byteString);
        String strA = ap.a(35152469);
        Intrinsics.checkNotNullParameter(list, strA);
        Intrinsics.checkNotNullParameter(byteString, ap.a(1420232946));
        this.f = j;
        this.g = Internal.a(strA, list);
    }
}