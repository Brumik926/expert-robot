package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import h.ap;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u00002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\n\u0018\u0000 \u00192\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001\u001aB%\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003¢\u0006\u0004\b\u0007\u0010\bJ\u001a\u0010\f\u001a\u00020\u000b2\b\u0010\n\u001a\u0004\u0018\u00010\tH\u0096\u0002¢\u0006\u0004\b\f\u0010\rJ\u000f\u0010\u000f\u001a\u00020\u000eH\u0016¢\u0006\u0004\b\u000f\u0010\u0010J\u000f\u0010\u0012\u001a\u00020\u0011H\u0016¢\u0006\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0014\u0010\u0015\u001a\u0004\b\u0014\u0010\u0016R\u001a\u0010\u0005\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u0017\u0010\u0015\u001a\u0004\b\u0018\u0010\u0016¨\u0006\u001b"}, d2 = {"LCrashDetail;", "Lcom/squareup/wire/Message;", "", "Lokio/ByteString;", "name", "data_", "unknownFields", "<init>", "(Lokio/ByteString;Lokio/ByteString;Lokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "", "toString", "()Ljava/lang/String;", "f", "Lokio/ByteString;", "()Lokio/ByteString;", "g", "e", "h", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class CrashDetail extends Message {
    public static final Companion h = new Companion(null);
    public static final ProtoAdapter i;
    private final ByteString f;
    private final ByteString g;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LCrashDetail$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LCrashDetail;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(CrashDetail.class);
        final Syntax syntax = Syntax.d;
        i = new ProtoAdapter<CrashDetail>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: CrashDetail$Companion$ADAPTER$1
            {
                String strA = ap.a(672558526);
                String strA2 = ap.a(1359372335);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public CrashDetail d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                Object objD = ByteString.e;
                long jD = protoReader.d();
                Object objD2 = objD;
                while (true) {
                    int i2 = protoReader.i();
                    if (i2 == -1) {
                        return new CrashDetail((ByteString) objD, (ByteString) objD2, protoReader.f(jD));
                    }
                    if (i2 == 1) {
                        objD = ProtoAdapter.I.d(protoReader);
                    } else if (i2 != 2) {
                        protoReader.p(i2);
                    } else {
                        objD2 = ProtoAdapter.I.d(protoReader);
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, CrashDetail crashDetail) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(crashDetail, "value");
                ByteString byteStringF = crashDetail.f();
                ByteString byteString = ByteString.e;
                if (!Intrinsics.areEqual(byteStringF, byteString)) {
                    ProtoAdapter.I.l(protoWriter, 1, crashDetail.f());
                }
                if (!Intrinsics.areEqual(crashDetail.e(), byteString)) {
                    ProtoAdapter.I.l(protoWriter, 2, crashDetail.e());
                }
                protoWriter.a(crashDetail.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, CrashDetail crashDetail) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(crashDetail, "value");
                reverseProtoWriter.j(crashDetail.d());
                ByteString byteStringE = crashDetail.e();
                ByteString byteString = ByteString.e;
                if (!Intrinsics.areEqual(byteStringE, byteString)) {
                    ProtoAdapter.I.m(reverseProtoWriter, 2, crashDetail.e());
                }
                if (Intrinsics.areEqual(crashDetail.f(), byteString)) {
                    return;
                }
                ProtoAdapter.I.m(reverseProtoWriter, 1, crashDetail.f());
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(CrashDetail crashDetail) {
                Intrinsics.checkNotNullParameter(crashDetail, "value");
                int size = crashDetail.d().size();
                ByteString byteStringF = crashDetail.f();
                ByteString byteString = ByteString.e;
                if (!Intrinsics.areEqual(byteStringF, byteString)) {
                    size += ProtoAdapter.I.o(1, crashDetail.f());
                }
                return !Intrinsics.areEqual(crashDetail.e(), byteString) ? size + ProtoAdapter.I.o(2, crashDetail.e()) : size;
            }
        };
    }

    public CrashDetail() {
        this(null, null, null, 7, null);
    }

    public final ByteString e() {
        return this.g;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof CrashDetail)) {
            return false;
        }
        CrashDetail crashDetail = (CrashDetail) obj;
        return Intrinsics.areEqual(d(), crashDetail.d()) && Intrinsics.areEqual(this.f, crashDetail.f) && Intrinsics.areEqual(this.g, crashDetail.g);
    }

    public final ByteString f() {
        return this.f;
    }

    public int hashCode() {
        int i2 = ((Message) this).d;
        if (i2 != 0) {
            return i2;
        }
        int iHashCode = (((d().hashCode() * 37) + this.f.hashCode()) * 37) + this.g.hashCode();
        ((Message) this).d = iHashCode;
        return iHashCode;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("name=" + this.f);
        arrayList.add("data_=" + this.g);
        return CollectionsKt.joinToString$default(arrayList, ", ", "CrashDetail{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ CrashDetail(ByteString byteString, ByteString byteString2, ByteString byteString3, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this((i2 & 1) != 0 ? ByteString.e : byteString, (i2 & 2) != 0 ? ByteString.e : byteString2, (i2 & 4) != 0 ? ByteString.e : byteString3);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public CrashDetail(ByteString byteString, ByteString byteString2, ByteString byteString3) {
        super(i, byteString3);
        Intrinsics.checkNotNullParameter(byteString, ap.a(1012570688));
        Intrinsics.checkNotNullParameter(byteString2, ap.a(1606184498));
        Intrinsics.checkNotNullParameter(byteString3, ap.a(1413214295));
        this.f = byteString;
        this.g = byteString2;
    }
}