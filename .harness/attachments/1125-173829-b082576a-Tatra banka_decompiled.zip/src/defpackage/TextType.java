package defpackage;

import h.ap;
import kotlin.Metadata;
import kotlin.enums.EnumEntries;
import kotlin.enums.EnumEntriesKt;

/* JADX WARN: Failed to restore enum class, 'enum' modifier and super class removed */
/* JADX WARN: Unknown enum class pattern. Please report as an issue! */
/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0010\n\u0002\b\u0005\b\u0086\u0081\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00000\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003j\u0002\b\u0004j\u0002\b\u0005¨\u0006\u0006"}, d2 = {"LTextType;", "", "<init>", "(Ljava/lang/String;I)V", "a", "b", "coresdk_release"}, k = 1, mv = {1, 9, 0}, xi = 48)
public final class TextType {
    public static final TextType a = new TextType(ap.a(1848242452), 0);
    public static final TextType b = new TextType(ap.a(2016390656), 1);
    private static final /* synthetic */ TextType[] c;
    private static final /* synthetic */ EnumEntries d;

    static {
        TextType[] textTypeArrA = a();
        c = textTypeArrA;
        d = EnumEntriesKt.enumEntries(textTypeArrA);
    }

    private TextType(String str, int i) {
    }

    private static final /* synthetic */ TextType[] a() {
        return new TextType[]{a, b};
    }

    public static TextType valueOf(String str) {
        return (TextType) Enum.valueOf(TextType.class, str);
    }

    public static TextType[] values() {
        return (TextType[]) c.clone();
    }
}