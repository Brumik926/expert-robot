package defpackage;

import androidx.compose.runtime.internal.StabilityInferred;
import h.ap;
import kotlin.Metadata;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import sk.tb.ib.tatraandroid.livedata.SimpleObserver;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@StabilityInferred
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0003\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0007\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000\u0002J\u0017\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0003H\u0016¢\u0006\u0004\b\u0006\u0010\u0007R \u0010\u000b\u001a\u000e\u0012\u0004\u0012\u00020\u0003\u0012\u0004\u0012\u00020\u00050\b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\t\u0010\n¨\u0006\f"}, d2 = {"LOnError;", "T", "Lsk/tb/ib/tatraandroid/livedata/SimpleObserver;", "", "throwable", "", "b", "(Ljava/lang/Throwable;)V", "Lkotlin/Function1;", "a", "Lkotlin/jvm/functions/Function1;", "callback", "tatra-mobile_clientRelease"}, k = 1, mv = {2, 2, 0}, xi = 48)
public final class OnError<T> extends SimpleObserver<T> {
    private final Function1 a;

    public void b(Throwable th) {
        Intrinsics.checkNotNullParameter(th, ap.a(441332141));
        this.a.invoke(th);
    }
}