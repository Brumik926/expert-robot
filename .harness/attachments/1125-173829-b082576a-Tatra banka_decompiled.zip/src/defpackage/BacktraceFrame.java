package defpackage;

import com.squareup.wire.FieldEncoding;
import com.squareup.wire.Message;
import com.squareup.wire.ProtoAdapter;
import com.squareup.wire.ProtoReader;
import com.squareup.wire.ProtoWriter;
import com.squareup.wire.ReverseProtoWriter;
import com.squareup.wire.Syntax;
import com.squareup.wire.internal.Internal;
import h.ap;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Reflection;
import kotlin.reflect.KClass;
import okio.ByteString;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes.dex */
@Metadata(d1 = {"\u0000:\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0001\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0010\b\n\u0002\b\u0013\u0018\u0000 '2\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00020\u0001:\u0001(Ba\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0003\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007\u0012\b\b\u0002\u0010\t\u001a\u00020\u0003\u0012\b\b\u0002\u0010\n\u001a\u00020\u0007\u0012\b\b\u0002\u0010\u000b\u001a\u00020\u0003\u0012\b\b\u0002\u0010\f\u001a\u00020\u0007\u0012\b\b\u0002\u0010\u000e\u001a\u00020\r¢\u0006\u0004\b\u000f\u0010\u0010J\u001a\u0010\u0014\u001a\u00020\u00132\b\u0010\u0012\u001a\u0004\u0018\u00010\u0011H\u0096\u0002¢\u0006\u0004\b\u0014\u0010\u0015J\u000f\u0010\u0017\u001a\u00020\u0016H\u0016¢\u0006\u0004\b\u0017\u0010\u0018J\u000f\u0010\u0019\u001a\u00020\u0007H\u0016¢\u0006\u0004\b\u0019\u0010\u001aR\u001a\u0010\u0004\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001b\u0010\u001c\u001a\u0004\b\u001d\u0010\u001eR\u001a\u0010\u0005\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001f\u0010\u001c\u001a\u0004\b \u0010\u001eR\u001a\u0010\u0006\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b!\u0010\u001c\u001a\u0004\b\"\u0010\u001eR\u001a\u0010\b\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b#\u0010$\u001a\u0004\b!\u0010\u001aR\u001a\u0010\t\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b \u0010\u001c\u001a\u0004\b#\u0010\u001eR\u001a\u0010\n\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\u001d\u0010$\u001a\u0004\b\u001f\u0010\u001aR\u001a\u0010\u000b\u001a\u00020\u00038\u0006X\u0087\u0004¢\u0006\f\n\u0004\b\"\u0010\u001c\u001a\u0004\b\u001b\u0010\u001eR\u001a\u0010\f\u001a\u00020\u00078\u0006X\u0087\u0004¢\u0006\f\n\u0004\b%\u0010$\u001a\u0004\b&\u0010\u001a¨\u0006)"}, d2 = {"LBacktraceFrame;", "Lcom/squareup/wire/Message;", "", "", "rel_pc", "pc", "sp", "", "function_name", "function_offset", "file_name", "file_map_offset", "build_id", "Lokio/ByteString;", "unknownFields", "<init>", "(JJJLjava/lang/String;JLjava/lang/String;JLjava/lang/String;Lokio/ByteString;)V", "", "other", "", "equals", "(Ljava/lang/Object;)Z", "", "hashCode", "()I", "toString", "()Ljava/lang/String;", "f", "J", "k", "()J", "g", "j", "h", "l", "i", "Ljava/lang/String;", "m", "e", "n", "Companion", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
public final class BacktraceFrame extends Message {
    public static final Companion n = new Companion(null);
    public static final ProtoAdapter o;
    private final long f;
    private final long g;
    private final long h;
    private final String i;
    private final long j;
    private final String k;
    private final long l;
    private final String m;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\b\u0086\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003R\u0016\u0010\u0004\u001a\b\u0012\u0004\u0012\u00020\u00060\u00058\u0006X\u0087\u0004¢\u0006\u0002\n\u0000R\u000e\u0010\u0007\u001a\u00020\bX\u0082T¢\u0006\u0002\n\u0000¨\u0006\t"}, d2 = {"LBacktraceFrame$Companion;", "", "<init>", "()V", "ADAPTER", "Lcom/squareup/wire/ProtoAdapter;", "LBacktraceFrame;", "serialVersionUID", "", "com.dynatrace.agent_release"}, k = 1, mv = {2, 0, 0}, xi = 48)
    public static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private Companion() {
        }
    }

    static {
        final FieldEncoding fieldEncoding = FieldEncoding.e;
        final KClass orCreateKotlinClass = Reflection.getOrCreateKotlinClass(BacktraceFrame.class);
        final Syntax syntax = Syntax.d;
        o = new ProtoAdapter<BacktraceFrame>(fieldEncoding, orCreateKotlinClass, syntax) { // from class: BacktraceFrame$Companion$ADAPTER$1
            {
                String strA = ap.a(978578946);
                String strA2 = ap.a(2143310864);
            }

            /* JADX INFO: renamed from: v, reason: merged with bridge method [inline-methods] */
            public BacktraceFrame d(ProtoReader protoReader) {
                Intrinsics.checkNotNullParameter(protoReader, "reader");
                long jD = protoReader.d();
                Object objD = "";
                long jLongValue = 0;
                long jLongValue2 = 0;
                long jLongValue3 = 0;
                long jLongValue4 = 0;
                long jLongValue5 = 0;
                Object objD2 = "";
                Object objD3 = objD2;
                while (true) {
                    int i = protoReader.i();
                    if (i == -1) {
                        return new BacktraceFrame(jLongValue, jLongValue2, jLongValue3, (String) objD, jLongValue4, (String) objD2, jLongValue5, (String) objD3, protoReader.f(jD));
                    }
                    switch (i) {
                        case 1:
                            jLongValue = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 2:
                            jLongValue2 = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 3:
                            jLongValue3 = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 4:
                            objD = ProtoAdapter.J.d(protoReader);
                            break;
                        case 5:
                            jLongValue4 = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 6:
                            objD2 = ProtoAdapter.J.d(protoReader);
                            break;
                        case 7:
                            jLongValue5 = ((Number) ProtoAdapter.w.d(protoReader)).longValue();
                            break;
                        case 8:
                            objD3 = ProtoAdapter.J.d(protoReader);
                            break;
                        default:
                            protoReader.p(i);
                            break;
                    }
                }
            }

            /* JADX INFO: renamed from: w, reason: merged with bridge method [inline-methods] */
            public void h(ProtoWriter protoWriter, BacktraceFrame backtraceFrame) {
                Intrinsics.checkNotNullParameter(protoWriter, "writer");
                Intrinsics.checkNotNullParameter(backtraceFrame, "value");
                if (backtraceFrame.k() != 0) {
                    ProtoAdapter.w.l(protoWriter, 1, Long.valueOf(backtraceFrame.k()));
                }
                if (backtraceFrame.j() != 0) {
                    ProtoAdapter.w.l(protoWriter, 2, Long.valueOf(backtraceFrame.j()));
                }
                if (backtraceFrame.l() != 0) {
                    ProtoAdapter.w.l(protoWriter, 3, Long.valueOf(backtraceFrame.l()));
                }
                if (!Intrinsics.areEqual(backtraceFrame.h(), "")) {
                    ProtoAdapter.J.l(protoWriter, 4, backtraceFrame.h());
                }
                if (backtraceFrame.i() != 0) {
                    ProtoAdapter.w.l(protoWriter, 5, Long.valueOf(backtraceFrame.i()));
                }
                if (!Intrinsics.areEqual(backtraceFrame.g(), "")) {
                    ProtoAdapter.J.l(protoWriter, 6, backtraceFrame.g());
                }
                if (backtraceFrame.f() != 0) {
                    ProtoAdapter.w.l(protoWriter, 7, Long.valueOf(backtraceFrame.f()));
                }
                if (!Intrinsics.areEqual(backtraceFrame.e(), "")) {
                    ProtoAdapter.J.l(protoWriter, 8, backtraceFrame.e());
                }
                protoWriter.a(backtraceFrame.d());
            }

            /* JADX INFO: renamed from: x, reason: merged with bridge method [inline-methods] */
            public void i(ReverseProtoWriter reverseProtoWriter, BacktraceFrame backtraceFrame) {
                Intrinsics.checkNotNullParameter(reverseProtoWriter, "writer");
                Intrinsics.checkNotNullParameter(backtraceFrame, "value");
                reverseProtoWriter.j(backtraceFrame.d());
                if (!Intrinsics.areEqual(backtraceFrame.e(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 8, backtraceFrame.e());
                }
                if (backtraceFrame.f() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 7, Long.valueOf(backtraceFrame.f()));
                }
                if (!Intrinsics.areEqual(backtraceFrame.g(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 6, backtraceFrame.g());
                }
                if (backtraceFrame.i() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 5, Long.valueOf(backtraceFrame.i()));
                }
                if (!Intrinsics.areEqual(backtraceFrame.h(), "")) {
                    ProtoAdapter.J.m(reverseProtoWriter, 4, backtraceFrame.h());
                }
                if (backtraceFrame.l() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 3, Long.valueOf(backtraceFrame.l()));
                }
                if (backtraceFrame.j() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 2, Long.valueOf(backtraceFrame.j()));
                }
                if (backtraceFrame.k() != 0) {
                    ProtoAdapter.w.m(reverseProtoWriter, 1, Long.valueOf(backtraceFrame.k()));
                }
            }

            /* JADX INFO: renamed from: y, reason: merged with bridge method [inline-methods] */
            public int n(BacktraceFrame backtraceFrame) {
                Intrinsics.checkNotNullParameter(backtraceFrame, "value");
                int size = backtraceFrame.d().size();
                if (backtraceFrame.k() != 0) {
                    size += ProtoAdapter.w.o(1, Long.valueOf(backtraceFrame.k()));
                }
                if (backtraceFrame.j() != 0) {
                    size += ProtoAdapter.w.o(2, Long.valueOf(backtraceFrame.j()));
                }
                if (backtraceFrame.l() != 0) {
                    size += ProtoAdapter.w.o(3, Long.valueOf(backtraceFrame.l()));
                }
                if (!Intrinsics.areEqual(backtraceFrame.h(), "")) {
                    size += ProtoAdapter.J.o(4, backtraceFrame.h());
                }
                if (backtraceFrame.i() != 0) {
                    size += ProtoAdapter.w.o(5, Long.valueOf(backtraceFrame.i()));
                }
                if (!Intrinsics.areEqual(backtraceFrame.g(), "")) {
                    size += ProtoAdapter.J.o(6, backtraceFrame.g());
                }
                if (backtraceFrame.f() != 0) {
                    size += ProtoAdapter.w.o(7, Long.valueOf(backtraceFrame.f()));
                }
                return !Intrinsics.areEqual(backtraceFrame.e(), "") ? size + ProtoAdapter.J.o(8, backtraceFrame.e()) : size;
            }
        };
    }

    public BacktraceFrame() {
        this(0L, 0L, 0L, null, 0L, null, 0L, null, null, 511, null);
    }

    public final String e() {
        return this.m;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof BacktraceFrame)) {
            return false;
        }
        BacktraceFrame backtraceFrame = (BacktraceFrame) obj;
        return Intrinsics.areEqual(d(), backtraceFrame.d()) && this.f == backtraceFrame.f && this.g == backtraceFrame.g && this.h == backtraceFrame.h && Intrinsics.areEqual(this.i, backtraceFrame.i) && this.j == backtraceFrame.j && Intrinsics.areEqual(this.k, backtraceFrame.k) && this.l == backtraceFrame.l && Intrinsics.areEqual(this.m, backtraceFrame.m);
    }

    public final long f() {
        return this.l;
    }

    public final String g() {
        return this.k;
    }

    public final String h() {
        return this.i;
    }

    public int hashCode() {
        int i = ((Message) this).d;
        if (i != 0) {
            return i;
        }
        int iHashCode = (((((((((((((((d().hashCode() * 37) + Long.hashCode(this.f)) * 37) + Long.hashCode(this.g)) * 37) + Long.hashCode(this.h)) * 37) + this.i.hashCode()) * 37) + Long.hashCode(this.j)) * 37) + this.k.hashCode()) * 37) + Long.hashCode(this.l)) * 37) + this.m.hashCode();
        ((Message) this).d = iHashCode;
        return iHashCode;
    }

    public final long i() {
        return this.j;
    }

    public final long j() {
        return this.g;
    }

    public final long k() {
        return this.f;
    }

    public final long l() {
        return this.h;
    }

    public String toString() {
        ArrayList arrayList = new ArrayList();
        arrayList.add("rel_pc=" + this.f);
        arrayList.add("pc=" + this.g);
        arrayList.add("sp=" + this.h);
        arrayList.add("function_name=" + Internal.c(this.i));
        arrayList.add("function_offset=" + this.j);
        arrayList.add("file_name=" + Internal.c(this.k));
        arrayList.add("file_map_offset=" + this.l);
        arrayList.add("build_id=" + Internal.c(this.m));
        return CollectionsKt.joinToString$default(arrayList, ", ", "BacktraceFrame{", "}", 0, (CharSequence) null, (Function1) null, 56, (Object) null);
    }

    public /* synthetic */ BacktraceFrame(long j, long j2, long j3, String str, long j4, String str2, long j5, String str3, ByteString byteString, int i, DefaultConstructorMarker defaultConstructorMarker) {
        this((i & 1) != 0 ? 0L : j, (i & 2) != 0 ? 0L : j2, (i & 4) != 0 ? 0L : j3, (i & 8) != 0 ? "" : str, (i & 16) != 0 ? 0L : j4, (i & 32) != 0 ? "" : str2, (i & 64) == 0 ? j5 : 0L, (i & 128) == 0 ? str3 : "", (i & 256) != 0 ? ByteString.e : byteString);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public BacktraceFrame(long j, long j2, long j3, String str, long j4, String str2, long j5, String str3, ByteString byteString) {
        super(o, byteString);
        Intrinsics.checkNotNullParameter(str, ap.a(136745458));
        Intrinsics.checkNotNullParameter(str2, ap.a(137509701));
        Intrinsics.checkNotNullParameter(str3, ap.a(2004980115));
        Intrinsics.checkNotNullParameter(byteString, ap.a(1274986909));
        this.f = j;
        this.g = j2;
        this.h = j3;
        this.i = str;
        this.j = j4;
        this.k = str2;
        this.l = j5;
        this.m = str3;
    }
}