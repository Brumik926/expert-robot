package defpackage;

import androidx.compose.ui.geometry.OffsetKt;
import androidx.compose.ui.geometry.Size;
import androidx.compose.ui.graphics.Brush;
import androidx.compose.ui.graphics.ColorFilter;
import androidx.compose.ui.graphics.drawscope.ContentDrawScope;
import androidx.compose.ui.graphics.drawscope.DrawScope;
import androidx.compose.ui.graphics.drawscope.DrawStyle;
import h.ap;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes6.dex */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0002\u0010\u0003"}, d2 = {"Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;", "", "a", "(Landroidx/compose/ui/graphics/drawscope/ContentDrawScope;)V"}, k = 3, mv = {1, 9, 0})
final class ComposeUtilKt$borderCircleGradient$1 extends Lambda implements Function1<ContentDrawScope, Unit> {
    final /* synthetic */ Brush c;
    final /* synthetic */ float d;

    public final void a(ContentDrawScope contentDrawScope) {
        Intrinsics.checkNotNullParameter(contentDrawScope, ap.a(713342960));
        float f = 2;
        DrawScope.V0(contentDrawScope, this.c, (Size.j(contentDrawScope.c()) / f) * 0.8f, OffsetKt.a(Size.j(contentDrawScope.c()) / f, Size.j(contentDrawScope.c()) / 1.8f), this.d, (DrawStyle) null, (ColorFilter) null, 0, 112, (Object) null);
        contentDrawScope.p1();
    }

    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        a((ContentDrawScope) obj);
        return Unit.INSTANCE;
    }
}