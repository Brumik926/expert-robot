package okio.internal;

import com.dynatrace.android.callback.Callback;
import h.ap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.JarURLConnection;
import java.net.URI;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.StringsKt;
import kotlinx.serialization.json.internal.AbstractJsonLexerKt;
import okio.FileHandle;
import okio.FileMetadata;
import okio.FileSystem;
import okio.Okio;
import okio.Path;
import okio.Sink;
import okio.Source;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000b\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0010 \n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0012\b\u0000\u0018\u0000 >2\u00020\u0001:\u0001?B#\b\u0000\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0001¢\u0006\u0004\b\u0007\u0010\bJ\u0017\u0010\u000b\u001a\u00020\t2\u0006\u0010\n\u001a\u00020\tH\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u0013\u0010\u000e\u001a\u00020\r*\u00020\tH\u0002¢\u0006\u0004\b\u000e\u0010\u000fJ%\u0010\u0012\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\t0\u00110\u0010*\u00020\u0002H\u0002¢\u0006\u0004\b\u0012\u0010\u0013J!\u0010\u0015\u001a\u0010\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\t\u0018\u00010\u0011*\u00020\u0014H\u0002¢\u0006\u0004\b\u0015\u0010\u0016J!\u0010\u0017\u001a\u0010\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\t\u0018\u00010\u0011*\u00020\u0014H\u0002¢\u0006\u0004\b\u0017\u0010\u0016J\u001d\u0010\u0019\u001a\b\u0012\u0004\u0012\u00020\t0\u00102\u0006\u0010\u0018\u001a\u00020\tH\u0016¢\u0006\u0004\b\u0019\u0010\u001aJ\u001f\u0010\u001b\u001a\n\u0012\u0004\u0012\u00020\t\u0018\u00010\u00102\u0006\u0010\u0018\u001a\u00020\tH\u0016¢\u0006\u0004\b\u001b\u0010\u001aJ\u0017\u0010\u001e\u001a\u00020\u001d2\u0006\u0010\u001c\u001a\u00020\tH\u0016¢\u0006\u0004\b\u001e\u0010\u001fJ'\u0010\"\u001a\u00020\u001d2\u0006\u0010\u001c\u001a\u00020\t2\u0006\u0010 \u001a\u00020\u00042\u0006\u0010!\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\"\u0010#J\u0019\u0010%\u001a\u0004\u0018\u00010$2\u0006\u0010\n\u001a\u00020\tH\u0016¢\u0006\u0004\b%\u0010&J\u0017\u0010(\u001a\u00020'2\u0006\u0010\u001c\u001a\u00020\tH\u0016¢\u0006\u0004\b(\u0010)J\u001f\u0010+\u001a\u00020*2\u0006\u0010\u001c\u001a\u00020\t2\u0006\u0010 \u001a\u00020\u0004H\u0016¢\u0006\u0004\b+\u0010,J\u001f\u0010-\u001a\u00020*2\u0006\u0010\u001c\u001a\u00020\t2\u0006\u0010!\u001a\u00020\u0004H\u0016¢\u0006\u0004\b-\u0010,J\u001f\u0010/\u001a\u00020.2\u0006\u0010\u0018\u001a\u00020\t2\u0006\u0010 \u001a\u00020\u0004H\u0016¢\u0006\u0004\b/\u00100J\u001f\u00103\u001a\u00020.2\u0006\u00101\u001a\u00020\t2\u0006\u00102\u001a\u00020\tH\u0016¢\u0006\u0004\b3\u00104J\u001f\u00105\u001a\u00020.2\u0006\u0010\n\u001a\u00020\t2\u0006\u0010!\u001a\u00020\u0004H\u0016¢\u0006\u0004\b5\u00100R\u0014\u0010\u0003\u001a\u00020\u00028\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b3\u00106R\u0014\u0010\u0006\u001a\u00020\u00018\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b7\u00108R-\u0010=\u001a\u0014\u0012\u0010\u0012\u000e\u0012\u0004\u0012\u00020\u0001\u0012\u0004\u0012\u00020\t0\u00110\u00108BX\u0082\u0084\u0002¢\u0006\f\n\u0004\b9\u0010:\u001a\u0004\b;\u0010<¨\u0006@"}, d2 = {"Lokio/internal/ResourceFileSystem;", "Lokio/FileSystem;", "Ljava/lang/ClassLoader;", "classLoader", StringUtils.EMPTY, "indexEagerly", "systemFileSystem", "<init>", "(Ljava/lang/ClassLoader;ZLokio/FileSystem;)V", "Lokio/Path;", "path", "d0", "(Lokio/Path;)Lokio/Path;", StringUtils.EMPTY, "w0", "(Lokio/Path;)Ljava/lang/String;", StringUtils.EMPTY, "Lkotlin/Pair;", "j0", "(Ljava/lang/ClassLoader;)Ljava/util/List;", "Ljava/net/URL;", "m0", "(Ljava/net/URL;)Lkotlin/Pair;", "o0", "dir", "A", "(Lokio/Path;)Ljava/util/List;", "B", "file", "Lokio/FileHandle;", "J", "(Lokio/Path;)Lokio/FileHandle;", "mustCreate", "mustExist", "P", "(Lokio/Path;ZZ)Lokio/FileHandle;", "Lokio/FileMetadata;", "I", "(Lokio/Path;)Lokio/FileMetadata;", "Lokio/Source;", "W", "(Lokio/Path;)Lokio/Source;", "Lokio/Sink;", "V", "(Lokio/Path;Z)Lokio/Sink;", "d", StringUtils.EMPTY, "k", "(Lokio/Path;Z)V", ClimateForcast.SOURCE, "target", "e", "(Lokio/Path;Lokio/Path;)V", "r", "Ljava/lang/ClassLoader;", "f", "Lokio/FileSystem;", "g", "Lkotlin/Lazy;", "e0", "()Ljava/util/List;", "roots", "h", "Companion", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nResourceFileSystem.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ResourceFileSystem.kt\nokio/internal/ResourceFileSystem\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,215:1\n774#2:216\n865#2,2:217\n1563#2:219\n1634#2,3:220\n774#2:223\n865#2,2:224\n1563#2:226\n1634#2,3:227\n1617#2,9:230\n1869#2:239\n1870#2:241\n1626#2:242\n1617#2,9:243\n1869#2:252\n1870#2:254\n1626#2:255\n1#3:240\n1#3:253\n*S KotlinDebug\n*F\n+ 1 ResourceFileSystem.kt\nokio/internal/ResourceFileSystem\n*L\n75#1:216\n75#1:217,2\n76#1:219\n76#1:220,3\n91#1:223\n91#1:224,2\n92#1:226\n92#1:227,3\n178#1:230,9\n178#1:239\n178#1:241\n178#1:242\n179#1:243,9\n179#1:252\n179#1:254\n179#1:255\n178#1:240\n179#1:253\n*E\n"})
public final class ResourceFileSystem extends FileSystem {
    private static final Companion h = new Companion(null);
    private static final Path i = Path.Companion.e(Path.b, ap.a(1486506366), false, 1, null);
    private final ClassLoader e;
    private final FileSystem f;
    private final Lazy g;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\n\b\u0082\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0002\u0010\u0003J\u0017\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0005\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\u0007\u0010\bJ\u0019\u0010\n\u001a\u00020\u0004*\u00020\u00042\u0006\u0010\t\u001a\u00020\u0004¢\u0006\u0004\b\n\u0010\u000bR\u0017\u0010\f\u001a\u00020\u00048\u0006¢\u0006\f\n\u0004\b\f\u0010\r\u001a\u0004\b\u000e\u0010\u000f¨\u0006\u0010"}, d2 = {"Lokio/internal/ResourceFileSystem$Companion;", StringUtils.EMPTY, "<init>", "()V", "Lokio/Path;", "path", StringUtils.EMPTY, "c", "(Lokio/Path;)Z", "base", "d", "(Lokio/Path;Lokio/Path;)Lokio/Path;", "ROOT", "Lokio/Path;", "b", "()Lokio/Path;", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
    private static final class Companion {
        public /* synthetic */ Companion(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        private final boolean c(Path path) {
            return !StringsKt.endsWith(path.e(), ap.a(891107196), true);
        }

        public final Path b() {
            return ResourceFileSystem.i;
        }

        public final Path d(Path path, Path path2) {
            Intrinsics.checkNotNullParameter(path, "<this>");
            Intrinsics.checkNotNullParameter(path2, "base");
            return b().j(StringsKt.replace$default(StringsKt.removePrefix(path.toString(), (CharSequence) path2.toString()), AbstractJsonLexerKt.STRING_ESC, '/', false, 4, (Object) null));
        }

        private Companion() {
        }
    }

    public ResourceFileSystem(ClassLoader classLoader, boolean z, FileSystem fileSystem) {
        Intrinsics.checkNotNullParameter(classLoader, "classLoader");
        Intrinsics.checkNotNullParameter(fileSystem, "systemFileSystem");
        this.e = classLoader;
        this.f = fileSystem;
        this.g = LazyKt.lazy(new Function0() { // from class: okio.internal.a
            public final Object invoke() {
                return ResourceFileSystem.i0(this.a);
            }
        });
        if (z) {
            e0().size();
        }
    }

    private final Path d0(Path path) {
        return i.l(path, true);
    }

    private final List e0() {
        return (List) this.g.getValue();
    }

    private static final List i0(ResourceFileSystem resourceFileSystem) {
        return resourceFileSystem.j0(resourceFileSystem.e);
    }

    private final List j0(ClassLoader classLoader) throws IOException {
        Enumeration<URL> resources = classLoader.getResources(StringUtils.EMPTY);
        Intrinsics.checkNotNullExpressionValue(resources, "getResources(...)");
        ArrayList<URL> list = Collections.list(resources);
        Intrinsics.checkNotNullExpressionValue(list, "list(...)");
        ArrayList arrayList = new ArrayList();
        for (URL url : list) {
            Intrinsics.checkNotNull(url);
            Pair pairM0 = m0(url);
            if (pairM0 != null) {
                arrayList.add(pairM0);
            }
        }
        Enumeration<URL> resources2 = classLoader.getResources("META-INF/MANIFEST.MF");
        Intrinsics.checkNotNullExpressionValue(resources2, "getResources(...)");
        ArrayList<URL> list2 = Collections.list(resources2);
        Intrinsics.checkNotNullExpressionValue(list2, "list(...)");
        ArrayList arrayList2 = new ArrayList();
        for (URL url2 : list2) {
            Intrinsics.checkNotNull(url2);
            Pair pairO0 = o0(url2);
            if (pairO0 != null) {
                arrayList2.add(pairO0);
            }
        }
        return CollectionsKt.plus(arrayList, arrayList2);
    }

    private final Pair m0(URL url) {
        if (Intrinsics.areEqual(url.getProtocol(), "file")) {
            return TuplesKt.to(this.f, Path.Companion.d(Path.b, new File(url.toURI()), false, 1, null));
        }
        return null;
    }

    private final Pair o0(URL url) {
        int iLastIndexOf$default;
        String string = url.toString();
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        if (!StringsKt.startsWith$default(string, "jar:file:", false, 2, (Object) null) || (iLastIndexOf$default = StringsKt.lastIndexOf$default((CharSequence) string, "!", 0, false, 6, (Object) null)) == -1) {
            return null;
        }
        Path.Companion companion = Path.b;
        String strSubstring = string.substring(4, iLastIndexOf$default);
        Intrinsics.checkNotNullExpressionValue(strSubstring, "substring(...)");
        return TuplesKt.to(ZipFilesKt.h(Path.Companion.d(companion, new File(URI.create(strSubstring)), false, 1, null), this.f, new Function1() { // from class: okio.internal.b
            public final Object invoke(Object obj) {
                return Boolean.valueOf(ResourceFileSystem.v0((ZipEntry) obj));
            }
        }), i);
    }

    private static final boolean v0(ZipEntry zipEntry) {
        Intrinsics.checkNotNullParameter(zipEntry, "entry");
        return h.c(zipEntry.b());
    }

    private final String w0(Path path) {
        return d0(path).i(i).toString();
    }

    @Override // okio.FileSystem
    public List A(Path path) throws FileNotFoundException {
        Intrinsics.checkNotNullParameter(path, "dir");
        String strW0 = w0(path);
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        boolean z = false;
        for (Pair pair : e0()) {
            FileSystem fileSystem = (FileSystem) pair.component1();
            Path path2 = (Path) pair.component2();
            try {
                List listA = fileSystem.A(path2.j(strW0));
                ArrayList arrayList = new ArrayList();
                for (Object obj : listA) {
                    if (h.c((Path) obj)) {
                        arrayList.add(obj);
                    }
                }
                ArrayList arrayList2 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList, 10));
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    arrayList2.add(h.d((Path) it.next(), path2));
                }
                CollectionsKt.addAll(linkedHashSet, arrayList2);
                z = true;
            } catch (IOException unused) {
            }
        }
        if (z) {
            return CollectionsKt.toList(linkedHashSet);
        }
        throw new FileNotFoundException("file not found: " + path);
    }

    @Override // okio.FileSystem
    public List B(Path path) {
        Intrinsics.checkNotNullParameter(path, "dir");
        String strW0 = w0(path);
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        Iterator it = e0().iterator();
        boolean z = false;
        while (true) {
            ArrayList arrayList = null;
            if (!it.hasNext()) {
                break;
            }
            Pair pair = (Pair) it.next();
            FileSystem fileSystem = (FileSystem) pair.component1();
            Path path2 = (Path) pair.component2();
            List listB = fileSystem.B(path2.j(strW0));
            if (listB != null) {
                ArrayList arrayList2 = new ArrayList();
                for (Object obj : listB) {
                    if (h.c((Path) obj)) {
                        arrayList2.add(obj);
                    }
                }
                ArrayList arrayList3 = new ArrayList(CollectionsKt.collectionSizeOrDefault(arrayList2, 10));
                Iterator it2 = arrayList2.iterator();
                while (it2.hasNext()) {
                    arrayList3.add(h.d((Path) it2.next(), path2));
                }
                arrayList = arrayList3;
            }
            if (arrayList != null) {
                CollectionsKt.addAll(linkedHashSet, arrayList);
                z = true;
            }
        }
        if (z) {
            return CollectionsKt.toList(linkedHashSet);
        }
        return null;
    }

    @Override // okio.FileSystem
    public FileMetadata I(Path path) {
        Intrinsics.checkNotNullParameter(path, "path");
        if (!h.c(path)) {
            return null;
        }
        String strW0 = w0(path);
        for (Pair pair : e0()) {
            FileMetadata fileMetadataI = ((FileSystem) pair.component1()).I(((Path) pair.component2()).j(strW0));
            if (fileMetadataI != null) {
                return fileMetadataI;
            }
        }
        return null;
    }

    @Override // okio.FileSystem
    public FileHandle J(Path path) throws FileNotFoundException {
        Intrinsics.checkNotNullParameter(path, "file");
        if (!h.c(path)) {
            throw new FileNotFoundException("file not found: " + path);
        }
        String strW0 = w0(path);
        Iterator it = e0().iterator();
        while (it.hasNext()) {
            Pair pair = (Pair) it.next();
            try {
                return ((FileSystem) pair.component1()).J(((Path) pair.component2()).j(strW0));
            } catch (FileNotFoundException unused) {
            }
        }
        throw new FileNotFoundException("file not found: " + path);
    }

    @Override // okio.FileSystem
    public FileHandle P(Path path, boolean z, boolean z2) throws IOException {
        Intrinsics.checkNotNullParameter(path, "file");
        throw new IOException("resources are not writable");
    }

    @Override // okio.FileSystem
    public Sink V(Path path, boolean z) throws IOException {
        Intrinsics.checkNotNullParameter(path, "file");
        throw new IOException(this + " is read-only");
    }

    @Override // okio.FileSystem
    public Source W(Path path) throws IOException {
        Intrinsics.checkNotNullParameter(path, "file");
        if (!h.c(path)) {
            throw new FileNotFoundException("file not found: " + path);
        }
        Path path2 = i;
        URL resource = this.e.getResource(Path.m(path2, path, false, 2, null).i(path2).toString());
        if (resource == null) {
            throw new FileNotFoundException("file not found: " + path);
        }
        URLConnection uRLConnectionOpenConnection = resource.openConnection();
        Callback.P(uRLConnectionOpenConnection);
        if (uRLConnectionOpenConnection instanceof JarURLConnection) {
            ((JarURLConnection) uRLConnectionOpenConnection).setUseCaches(false);
        }
        InputStream inputStreamT = Callback.t(uRLConnectionOpenConnection);
        Intrinsics.checkNotNullExpressionValue(inputStreamT, "getInputStream(...)");
        return Okio.i(inputStreamT);
    }

    @Override // okio.FileSystem
    public Sink d(Path path, boolean z) throws IOException {
        Intrinsics.checkNotNullParameter(path, "file");
        throw new IOException(this + " is read-only");
    }

    @Override // okio.FileSystem
    public void e(Path path, Path path2) throws IOException {
        Intrinsics.checkNotNullParameter(path, ClimateForcast.SOURCE);
        Intrinsics.checkNotNullParameter(path2, "target");
        throw new IOException(this + " is read-only");
    }

    @Override // okio.FileSystem
    public void k(Path path, boolean z) throws IOException {
        Intrinsics.checkNotNullParameter(path, "dir");
        throw new IOException(this + " is read-only");
    }

    @Override // okio.FileSystem
    public void r(Path path, boolean z) throws IOException {
        Intrinsics.checkNotNullParameter(path, "path");
        throw new IOException(this + " is read-only");
    }

    public /* synthetic */ ResourceFileSystem(ClassLoader classLoader, boolean z, FileSystem fileSystem, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(classLoader, z, (i2 & 4) != 0 ? FileSystem.b : fileSystem);
    }
}