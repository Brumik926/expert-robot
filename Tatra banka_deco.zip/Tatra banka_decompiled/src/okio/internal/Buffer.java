package okio.internal;

import h.ap;
import java.io.EOFException;
import kotlin.Metadata;
import kotlin.jvm.JvmName;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okio.Buffer;
import okio.ByteString;
import okio.Options;
import okio.Segment;
import okio.SegmentedByteString;
import okio._JvmPlatformKt;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: renamed from: okio.internal.-Buffer, reason: invalid class name */
/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000N\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0012\n\u0002\b\u0003\n\u0002\u0010\u000b\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\b\n\u0002\u0010\u0016\n\u0002\b\u0003\u001a7\u0010\t\u001a\u00020\b2\u0006\u0010\u0001\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0006\u001a\u00020\u00022\u0006\u0010\u0007\u001a\u00020\u0002H\u0000¢\u0006\u0004\b\t\u0010\n\u001a\u001b\u0010\u000f\u001a\u00020\u000e*\u00020\u000b2\u0006\u0010\r\u001a\u00020\fH\u0000¢\u0006\u0004\b\u000f\u0010\u0010\u001a%\u0010\u0014\u001a\u00020\u0002*\u00020\u000b2\u0006\u0010\u0012\u001a\u00020\u00112\b\b\u0002\u0010\u0013\u001a\u00020\bH\u0000¢\u0006\u0004\b\u0014\u0010\u0015\u001a\u0017\u0010\u0017\u001a\u00020\u00022\u0006\u0010\u0016\u001a\u00020\fH\u0002¢\u0006\u0004\b\u0017\u0010\u0018\u001aA\u0010\u001d\u001a\u00020\f*\u00020\u000b2\u0006\u0010\u0005\u001a\u00020\u00192\u0006\u0010\u001a\u001a\u00020\f2\b\b\u0002\u0010\u001b\u001a\u00020\f2\b\b\u0002\u0010\u0006\u001a\u00020\u00022\b\b\u0002\u0010\u001c\u001a\u00020\u0002H\u0000¢\u0006\u0004\b\u001d\u0010\u001e\u001a\u001b\u0010!\u001a\u00020\u001f*\u00020\u000b2\u0006\u0010 \u001a\u00020\u001fH\u0000¢\u0006\u0004\b!\u0010\"\"\u001a\u0010'\u001a\u00020\u00048\u0000X\u0080\u0004¢\u0006\f\n\u0004\b#\u0010$\u001a\u0004\b%\u0010&\"\u0014\u0010*\u001a\u00020(8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010)¨\u0006+"}, d2 = {"Lokio/Segment;", "segment", StringUtils.EMPTY, "segmentPos", StringUtils.EMPTY, "bytes", "bytesOffset", "bytesLimit", StringUtils.EMPTY, "g", "(Lokio/Segment;I[BII)Z", "Lokio/Buffer;", StringUtils.EMPTY, "newline", StringUtils.EMPTY, "h", "(Lokio/Buffer;J)Ljava/lang/String;", "Lokio/Options;", "options", "selectTruncated", "i", "(Lokio/Buffer;Lokio/Options;Z)I", "v", "e", "(J)I", "Lokio/ByteString;", "fromIndex", "toIndex", "byteCount", "b", "(Lokio/Buffer;Lokio/ByteString;JJII)J", "Lokio/Buffer$UnsafeCursor;", "unsafeCursor", "d", "(Lokio/Buffer;Lokio/Buffer$UnsafeCursor;)Lokio/Buffer$UnsafeCursor;", "a", "[B", "f", "()[B", "HEX_DIGIT_BYTES", StringUtils.EMPTY, "[J", "DigitCountToLargestValue", "okio"}, k = 2, mv = {2, 1, 0}, xi = 48)
@JvmName(name = "-Buffer")
@SourceDebugExtension({"SMAP\nBuffer.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Buffer.kt\nokio/internal/-Buffer\n+ 2 Util.kt\nokio/-SegmentedByteString\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,1709:1\n109#1,20:1732\n109#1,20:1765\n109#1:1785\n111#1,18:1787\n109#1,20:1805\n75#2:1710\n75#2:1711\n75#2:1712\n75#2:1713\n75#2:1714\n75#2:1715\n75#2:1716\n75#2:1717\n75#2:1718\n75#2:1719\n75#2:1720\n75#2:1721\n84#2:1722\n84#2:1723\n78#2:1724\n78#2:1725\n78#2:1726\n78#2:1727\n78#2:1728\n78#2:1729\n78#2:1730\n78#2:1731\n87#2:1752\n90#2:1754\n75#2:1755\n75#2:1756\n75#2:1757\n75#2:1758\n75#2:1759\n75#2:1760\n75#2:1761\n75#2:1762\n75#2:1763\n75#2:1764\n90#2:1786\n87#2:1825\n1#3:1753\n*S KotlinDebug\n*F\n+ 1 Buffer.kt\nokio/internal/-Buffer\n*L\n412#1:1732,20\n1261#1:1765,20\n1304#1:1785\n1304#1:1787,18\n1340#1:1805,20\n175#1:1710\n199#1:1711\n318#1:1712\n323#1:1713\n346#1:1714\n347#1:1715\n348#1:1716\n349#1:1717\n355#1:1718\n356#1:1719\n357#1:1720\n358#1:1721\n382#1:1722\n383#1:1723\n389#1:1724\n390#1:1725\n391#1:1726\n392#1:1727\n393#1:1728\n394#1:1729\n395#1:1730\n396#1:1731\n424#1:1752\n857#1:1754\n875#1:1755\n877#1:1756\n881#1:1757\n883#1:1758\n887#1:1759\n889#1:1760\n893#1:1761\n895#1:1762\n915#1:1763\n918#1:1764\n1316#1:1786\n1655#1:1825\n*E\n"})
public final class Buffer {
    private static final byte[] a = _JvmPlatformKt.a(ap.a(1822039230));
    private static final long[] b = {-1, 9, 99, 999, 9999, 99999, 999999, 9999999, 99999999, 999999999, 9999999999L, 99999999999L, 999999999999L, 9999999999999L, 99999999999999L, 999999999999999L, 9999999999999999L, 99999999999999999L, 999999999999999999L, Long.MAX_VALUE};

    public static final long b(okio.Buffer buffer, ByteString byteString, long j, long j2, int i, int i2) {
        Segment segment;
        int i3;
        long j3 = j;
        long size = j2;
        Intrinsics.checkNotNullParameter(buffer, "<this>");
        Intrinsics.checkNotNullParameter(byteString, "bytes");
        long j4 = i2;
        SegmentedByteString.b(byteString.size(), i, j4);
        if (i2 <= 0) {
            throw new IllegalArgumentException("byteCount == 0");
        }
        long size2 = 0;
        if (j3 < 0) {
            throw new IllegalArgumentException(("fromIndex < 0: " + j3).toString());
        }
        if (j3 > size) {
            throw new IllegalArgumentException(("fromIndex > toIndex: " + j3 + " > " + size).toString());
        }
        if (size > buffer.size()) {
            size = buffer.size();
        }
        long j5 = -1;
        if (j3 == size || (segment = buffer.a) == null) {
            return -1L;
        }
        if (buffer.size() - j3 >= j3) {
            while (true) {
                long j6 = ((long) (segment.c - segment.b)) + size2;
                if (j6 > j3) {
                    break;
                }
                segment = segment.f;
                Intrinsics.checkNotNull(segment);
                size2 = j6;
            }
            byte[] bArrP = byteString.p();
            byte b2 = bArrP[i];
            long jMin = Math.min(size, (buffer.size() - j4) + 1);
            while (size2 < jMin) {
                byte[] bArr = segment.a;
                int iMin = (int) Math.min(segment.c, (((long) segment.b) + jMin) - size2);
                i3 = (int) ((((long) segment.b) + j3) - size2);
                while (i3 < iMin) {
                    if (bArr[i3] != b2 || !g(segment, i3 + 1, bArrP, i + 1, i2)) {
                        i3++;
                    }
                }
                size2 += (long) (segment.c - segment.b);
                segment = segment.f;
                Intrinsics.checkNotNull(segment);
                j3 = size2;
            }
            return -1L;
        }
        size2 = buffer.size();
        while (size2 > j3) {
            segment = segment.g;
            Intrinsics.checkNotNull(segment);
            size2 -= (long) (segment.c - segment.b);
            j5 = j5;
        }
        long j7 = j5;
        byte[] bArrP2 = byteString.p();
        byte b3 = bArrP2[i];
        long jMin2 = Math.min(size, (buffer.size() - j4) + 1);
        while (size2 < jMin2) {
            byte[] bArr2 = segment.a;
            int iMin2 = (int) Math.min(segment.c, (((long) segment.b) + jMin2) - size2);
            i3 = (int) ((((long) segment.b) + j3) - size2);
            while (i3 < iMin2) {
                if (bArr2[i3] != b3 || !g(segment, i3 + 1, bArrP2, i + 1, i2)) {
                    i3++;
                }
            }
            size2 += (long) (segment.c - segment.b);
            segment = segment.f;
            Intrinsics.checkNotNull(segment);
            j3 = size2;
        }
        return j7;
        return ((long) (i3 - segment.b)) + size2;
    }

    public static /* synthetic */ long c(okio.Buffer buffer, ByteString byteString, long j, long j2, int i, int i2, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            j2 = Long.MAX_VALUE;
        }
        return b(buffer, byteString, j, j2, (i3 & 8) != 0 ? 0 : i, (i3 & 16) != 0 ? byteString.size() : i2);
    }

    public static final Buffer.UnsafeCursor d(okio.Buffer buffer, Buffer.UnsafeCursor unsafeCursor) {
        Intrinsics.checkNotNullParameter(buffer, "<this>");
        Intrinsics.checkNotNullParameter(unsafeCursor, "unsafeCursor");
        if (unsafeCursor.a != null) {
            throw new IllegalStateException("already attached to a buffer");
        }
        unsafeCursor.a = buffer;
        unsafeCursor.b = true;
        return unsafeCursor;
    }

    private static final int e(long j) {
        int iNumberOfLeadingZeros = ((64 - Long.numberOfLeadingZeros(j)) * 10) >>> 5;
        return iNumberOfLeadingZeros + (j > b[iNumberOfLeadingZeros] ? 1 : 0);
    }

    public static final byte[] f() {
        return a;
    }

    public static final boolean g(Segment segment, int i, byte[] bArr, int i2, int i3) {
        Intrinsics.checkNotNullParameter(segment, "segment");
        Intrinsics.checkNotNullParameter(bArr, "bytes");
        int i4 = segment.c;
        byte[] bArr2 = segment.a;
        while (i2 < i3) {
            if (i == i4) {
                segment = segment.f;
                Intrinsics.checkNotNull(segment);
                byte[] bArr3 = segment.a;
                bArr2 = bArr3;
                i = segment.b;
                i4 = segment.c;
            }
            if (bArr2[i] != bArr[i2]) {
                return false;
            }
            i++;
            i2++;
        }
        return true;
    }

    public static final String h(okio.Buffer buffer, long j) throws EOFException {
        Intrinsics.checkNotNullParameter(buffer, "<this>");
        if (j > 0) {
            long j2 = j - 1;
            if (buffer.B(j2) == 13) {
                String strB0 = buffer.B0(j2);
                buffer.skip(2L);
                return strB0;
            }
        }
        String strB02 = buffer.B0(j);
        buffer.skip(1L);
        return strB02;
    }

    /* JADX WARN: Code restructure failed: missing block: B:27:0x0064, code lost:
    
        if (r19 == false) goto L36;
     */
    /* JADX WARN: Code restructure failed: missing block: B:28:0x0066, code lost:
    
        return -2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0087, code lost:
    
        return r10;
     */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00a5 A[LOOP:0: B:8:0x0026->B:46:0x00a5, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00a4 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final int i(okio.Buffer r17, okio.Options r18, boolean r19) {
        /*
            r0 = r17
            java.lang.String r1 = "<this>"
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r0, r1)
            java.lang.String r1 = "options"
            r2 = r18
            kotlin.jvm.internal.Intrinsics.checkNotNullParameter(r2, r1)
            okio.Segment r0 = r0.a
            r1 = -2
            r3 = -1
            if (r0 != 0) goto L18
            if (r19 == 0) goto L17
            return r1
        L17:
            return r3
        L18:
            byte[] r4 = r0.a
            int r5 = r0.b
            int r6 = r0.c
            int[] r2 = r2.f()
            r7 = 0
            r9 = r0
            r10 = r3
            r8 = r7
        L26:
            int r11 = r8 + 1
            r12 = r2[r8]
            int r8 = r8 + 2
            r11 = r2[r11]
            if (r11 == r3) goto L31
            r10 = r11
        L31:
            if (r9 != 0) goto L34
            goto L64
        L34:
            r11 = 0
            if (r12 >= 0) goto L7d
            int r12 = r12 * (-1)
            int r13 = r8 + r12
        L3b:
            int r12 = r5 + 1
            r5 = r4[r5]
            r5 = r5 & 255(0xff, float:3.57E-43)
            int r14 = r8 + 1
            r8 = r2[r8]
            if (r5 == r8) goto L48
            goto L87
        L48:
            if (r14 != r13) goto L4c
            r5 = 1
            goto L4d
        L4c:
            r5 = r7
        L4d:
            if (r12 != r6) goto L6d
            kotlin.jvm.internal.Intrinsics.checkNotNull(r9)
            okio.Segment r4 = r9.f
            kotlin.jvm.internal.Intrinsics.checkNotNull(r4)
            int r6 = r4.b
            byte[] r8 = r4.a
            int r9 = r4.c
            if (r4 != r0) goto L67
            if (r5 == 0) goto L64
            r4 = r8
            r8 = r11
            goto L70
        L64:
            if (r19 == 0) goto L87
            return r1
        L67:
            r16 = r8
            r8 = r4
            r4 = r16
            goto L70
        L6d:
            r8 = r9
            r9 = r6
            r6 = r12
        L70:
            if (r5 == 0) goto L78
            r5 = r2[r14]
            r13 = r6
            r6 = r9
            r9 = r8
            goto La2
        L78:
            r5 = r6
            r6 = r9
            r9 = r8
            r8 = r14
            goto L3b
        L7d:
            int r13 = r5 + 1
            r5 = r4[r5]
            r5 = r5 & 255(0xff, float:3.57E-43)
            int r14 = r8 + r12
        L85:
            if (r8 != r14) goto L88
        L87:
            return r10
        L88:
            r15 = r2[r8]
            if (r5 != r15) goto La9
            int r8 = r8 + r12
            r5 = r2[r8]
            if (r13 != r6) goto La2
            okio.Segment r9 = r9.f
            kotlin.jvm.internal.Intrinsics.checkNotNull(r9)
            int r4 = r9.b
            byte[] r6 = r9.a
            int r8 = r9.c
            r13 = r4
            r4 = r6
            r6 = r8
            if (r9 != r0) goto La2
            r9 = r11
        La2:
            if (r5 < 0) goto La5
            return r5
        La5:
            int r8 = -r5
            r5 = r13
            goto L26
        La9:
            int r8 = r8 + 1
            goto L85
        */
        throw new UnsupportedOperationException("Method not decompiled: okio.internal.Buffer.i(okio.Buffer, okio.Options, boolean):int");
    }

    public static /* synthetic */ int j(okio.Buffer buffer, Options options, boolean z, int i, Object obj) {
        if ((i & 2) != 0) {
            z = false;
        }
        return i(buffer, options, z);
    }
}