package okio.internal;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.RestrictedSuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.sequences.SequenceScope;
import okio.FileSystem;
import okio.Path;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: renamed from: okio.internal.-FileSystem$commonListRecursively$1, reason: invalid class name */
/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u000e\n\u0000\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\u0010\u0000\u001a\u00020\u0001*\b\u0012\u0004\u0012\u00020\u00030\u0002H\n"}, d2 = {"<anonymous>", StringUtils.EMPTY, "Lkotlin/sequences/SequenceScope;", "Lokio/Path;"}, k = 3, mv = {2, 1, 0}, xi = 48)
@DebugMetadata(c = "okio.internal.-FileSystem$commonListRecursively$1", f = "FileSystem.kt", i = {0, 0}, l = {96}, m = "invokeSuspend", n = {"$this$sequence", "stack"}, s = {"L$0", "L$1"}, v = 1)
final class FileSystem$commonListRecursively$1 extends RestrictedSuspendLambda implements Function2<SequenceScope<? super Path>, Continuation<? super Unit>, Object> {
    Object l;
    Object m;
    int n;
    private /* synthetic */ Object o;
    final /* synthetic */ Path p;
    final /* synthetic */ FileSystem q;
    final /* synthetic */ boolean r;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    FileSystem$commonListRecursively$1(Path path, FileSystem fileSystem, boolean z, Continuation continuation) {
        super(2, continuation);
        this.p = path;
        this.q = fileSystem;
        this.r = z;
    }

    public final Continuation create(Object obj, Continuation continuation) {
        FileSystem$commonListRecursively$1 fileSystem$commonListRecursively$1 = new FileSystem$commonListRecursively$1(this.p, this.q, this.r, continuation);
        fileSystem$commonListRecursively$1.o = obj;
        return fileSystem$commonListRecursively$1;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x006e  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:12:0x0069 -> B:14:0x006c). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object invokeSuspend(java.lang.Object r12) {
        /*
            r11 = this;
            java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt.getCOROUTINE_SUSPENDED()
            int r1 = r11.n
            r2 = 1
            if (r1 == 0) goto L2a
            if (r1 != r2) goto L1d
            java.lang.Object r1 = r11.m
            java.util.Iterator r1 = (java.util.Iterator) r1
            java.lang.Object r3 = r11.l
            kotlin.collections.ArrayDeque r3 = (kotlin.collections.ArrayDeque) r3
            java.lang.Object r4 = r11.o
            kotlin.sequences.SequenceScope r4 = (kotlin.sequences.SequenceScope) r4
            kotlin.ResultKt.throwOnFailure(r12)
            r10 = r11
            r6 = r3
            goto L6c
        L1d:
            java.lang.IllegalStateException r11 = new java.lang.IllegalStateException
            r12 = 748083733(0x2c96da15, float:4.2874684E-12)
            java.lang.String r12 = h.ap.a(r12)
            r11.<init>(r12)
            throw r11
        L2a:
            kotlin.ResultKt.throwOnFailure(r12)
            java.lang.Object r12 = r11.o
            kotlin.sequences.SequenceScope r12 = (kotlin.sequences.SequenceScope) r12
            kotlin.collections.ArrayDeque r1 = new kotlin.collections.ArrayDeque
            r1.<init>()
            okio.Path r3 = r11.p
            r1.addLast(r3)
            okio.FileSystem r3 = r11.q
            okio.Path r4 = r11.p
            java.util.List r3 = r3.A(r4)
            java.util.Iterator r3 = r3.iterator()
            r4 = r12
            r6 = r1
            r1 = r3
        L4a:
            boolean r12 = r1.hasNext()
            if (r12 == 0) goto L6e
            java.lang.Object r12 = r1.next()
            r7 = r12
            okio.Path r7 = (okio.Path) r7
            okio.FileSystem r5 = r11.q
            boolean r8 = r11.r
            r11.o = r4
            r11.l = r6
            r11.m = r1
            r11.n = r2
            r9 = 0
            r10 = r11
            java.lang.Object r11 = okio.internal.FileSystem.a(r4, r5, r6, r7, r8, r9, r10)
            if (r11 != r0) goto L6c
            return r0
        L6c:
            r11 = r10
            goto L4a
        L6e:
            kotlin.Unit r11 = kotlin.Unit.INSTANCE
            return r11
        */
        throw new UnsupportedOperationException("Method not decompiled: okio.internal.FileSystem$commonListRecursively$1.invokeSuspend(java.lang.Object):java.lang.Object");
    }

    public final Object invoke(SequenceScope sequenceScope, Continuation continuation) {
        return create(sequenceScope, continuation).invokeSuspend(Unit.INSTANCE);
    }
}