package okio.internal;

import h.ap;
import java.io.EOFException;
import java.io.IOException;
import kotlin.Metadata;
import kotlin.jvm.internal.Intrinsics;
import okio.Buffer;
import okio.ForwardingSource;
import okio.Source;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u000b\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\r\b\u0000\u0018\u00002\u00020\u0001B\u001f\u0012\u0006\u0010\u0003\u001a\u00020\u0002\u0012\u0006\u0010\u0005\u001a\u00020\u0004\u0012\u0006\u0010\u0007\u001a\u00020\u0006¢\u0006\u0004\b\b\u0010\tJ\u001b\u0010\r\u001a\u00020\f*\u00020\n2\u0006\u0010\u000b\u001a\u00020\u0004H\u0002¢\u0006\u0004\b\r\u0010\u000eJ\u001f\u0010\u0011\u001a\u00020\u00042\u0006\u0010\u000f\u001a\u00020\n2\u0006\u0010\u0010\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0011\u0010\u0012R\u0014\u0010\u0005\u001a\u00020\u00048\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0013\u0010\u0014R\u0014\u0010\u0007\u001a\u00020\u00068\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010\u0016R\u0016\u0010\u0018\u001a\u00020\u00048\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\u0017\u0010\u0014¨\u0006\u0019"}, d2 = {"Lokio/internal/FixedLengthSource;", "Lokio/ForwardingSource;", "Lokio/Source;", "delegate", StringUtils.EMPTY, "size", StringUtils.EMPTY, "truncate", "<init>", "(Lokio/Source;JZ)V", "Lokio/Buffer;", "newSize", StringUtils.EMPTY, "k", "(Lokio/Buffer;J)V", "sink", "byteCount", "k3", "(Lokio/Buffer;J)J", "b", "J", "c", "Z", "d", "bytesReceived", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class FixedLengthSource extends ForwardingSource {
    private final long b;
    private final boolean c;
    private long d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public FixedLengthSource(Source source, long j, boolean z) {
        super(source);
        Intrinsics.checkNotNullParameter(source, ap.a(2075189234));
        this.b = j;
        this.c = z;
    }

    private final void k(Buffer buffer, long j) throws EOFException {
        Buffer buffer2 = new Buffer();
        buffer2.d2(buffer);
        buffer.a2(buffer2, j);
        buffer2.j();
    }

    @Override // okio.ForwardingSource, okio.Source
    public long k3(Buffer buffer, long j) throws IOException {
        Intrinsics.checkNotNullParameter(buffer, "sink");
        long j2 = this.d;
        long j3 = this.b;
        if (j2 > j3) {
            j = 0;
        } else if (this.c) {
            long j4 = j3 - j2;
            if (j4 == 0) {
                return -1L;
            }
            j = Math.min(j, j4);
        }
        long jK3 = super.k3(buffer, j);
        if (jK3 != -1) {
            this.d += jK3;
        }
        long j5 = this.d;
        long j6 = this.b;
        if ((j5 >= j6 || jK3 != -1) && j5 <= j6) {
            return jK3;
        }
        if (jK3 > 0 && j5 > j6) {
            k(buffer, buffer.size() - (this.d - this.b));
        }
        throw new IOException("expected " + this.b + " bytes but got " + this.d);
    }
}