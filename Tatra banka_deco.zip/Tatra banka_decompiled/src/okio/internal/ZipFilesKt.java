package okio.internal;

import h.ap;
import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import kotlin.Metadata;
import kotlin.Pair;
import kotlin.TuplesKt;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.collections.MapsKt;
import kotlin.comparisons.ComparisonsKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Ref;
import kotlin.jvm.internal.SourceDebugExtension;
import kotlin.text.CharsKt;
import kotlin.text.StringsKt;
import kotlinx.coroutines.scheduling.WorkQueueKt;
import okio.BufferedSource;
import okio.Path;
import org.apache.tika.pipes.PipesConfigBase;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000^\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010 \n\u0000\n\u0002\u0010$\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\t\n\u0002\u0010\u0002\n\u0002\b\u0010\n\u0002\u0010\u000e\n\u0002\b\u0004\u001a5\u0010\t\u001a\u00020\b2\u0006\u0010\u0001\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u00022\u0014\b\u0002\u0010\u0007\u001a\u000e\u0012\u0004\u0012\u00020\u0005\u0012\u0004\u0012\u00020\u00060\u0004H\u0000¢\u0006\u0004\b\t\u0010\n\u001a)\u0010\u000e\u001a\u000e\u0012\u0004\u0012\u00020\u0000\u0012\u0004\u0012\u00020\u00050\r2\f\u0010\f\u001a\b\u0012\u0004\u0012\u00020\u00050\u000bH\u0002¢\u0006\u0004\b\u000e\u0010\u000f\u001a\u0013\u0010\u0011\u001a\u00020\u0005*\u00020\u0010H\u0000¢\u0006\u0004\b\u0011\u0010\u0012\u001a\u0013\u0010\u0014\u001a\u00020\u0013*\u00020\u0010H\u0002¢\u0006\u0004\b\u0014\u0010\u0015\u001a\u001b\u0010\u0017\u001a\u00020\u0013*\u00020\u00102\u0006\u0010\u0016\u001a\u00020\u0013H\u0002¢\u0006\u0004\b\u0017\u0010\u0018\u001a5\u0010\u001f\u001a\u00020\u001d*\u00020\u00102\u0006\u0010\u001a\u001a\u00020\u00192\u0018\u0010\u001e\u001a\u0014\u0012\u0004\u0012\u00020\u0019\u0012\u0004\u0012\u00020\u001c\u0012\u0004\u0012\u00020\u001d0\u001bH\u0002¢\u0006\u0004\b\u001f\u0010 \u001a\u0013\u0010!\u001a\u00020\u001d*\u00020\u0010H\u0000¢\u0006\u0004\b!\u0010\"\u001a\u001b\u0010$\u001a\u00020\u0005*\u00020\u00102\u0006\u0010#\u001a\u00020\u0005H\u0000¢\u0006\u0004\b$\u0010%\u001a\u001f\u0010&\u001a\u0004\u0018\u00010\u0005*\u00020\u00102\b\u0010#\u001a\u0004\u0018\u00010\u0005H\u0002¢\u0006\u0004\b&\u0010%\u001a\u0017\u0010(\u001a\u00020\u001c2\u0006\u0010'\u001a\u00020\u001cH\u0000¢\u0006\u0004\b(\u0010)\u001a!\u0010,\u001a\u0004\u0018\u00010\u001c2\u0006\u0010*\u001a\u00020\u00192\u0006\u0010+\u001a\u00020\u0019H\u0000¢\u0006\u0004\b,\u0010-\"\u0018\u00101\u001a\u00020.*\u00020\u00198BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b/\u00100¨\u00062"}, d2 = {"Lokio/Path;", "zipPath", "Lokio/FileSystem;", "fileSystem", "Lkotlin/Function1;", "Lokio/internal/ZipEntry;", StringUtils.EMPTY, "predicate", "Lokio/ZipFileSystem;", "h", "(Lokio/Path;Lokio/FileSystem;Lkotlin/jvm/functions/Function1;)Lokio/ZipFileSystem;", StringUtils.EMPTY, "entries", StringUtils.EMPTY, "d", "(Ljava/util/List;)Ljava/util/Map;", "Lokio/BufferedSource;", "i", "(Lokio/BufferedSource;)Lokio/internal/ZipEntry;", "Lokio/internal/EocdRecord;", "l", "(Lokio/BufferedSource;)Lokio/internal/EocdRecord;", "regularRecord", "q", "(Lokio/BufferedSource;Lokio/internal/EocdRecord;)Lokio/internal/EocdRecord;", StringUtils.EMPTY, "extraSize", "Lkotlin/Function2;", StringUtils.EMPTY, StringUtils.EMPTY, "block", "m", "(Lokio/BufferedSource;ILkotlin/jvm/functions/Function2;)V", "r", "(Lokio/BufferedSource;)V", "centralDirectoryZipEntry", "n", "(Lokio/BufferedSource;Lokio/internal/ZipEntry;)Lokio/internal/ZipEntry;", "o", "filetime", "f", "(J)J", "date", "time", "e", "(II)Ljava/lang/Long;", StringUtils.EMPTY, "g", "(I)Ljava/lang/String;", "hex", "okio"}, k = 2, mv = {2, 1, 0}, xi = 48)
@SourceDebugExtension({"SMAP\nZipFiles.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ZipFiles.kt\nokio/internal/ZipFilesKt\n+ 2 Okio.kt\nokio/Okio__OkioKt\n+ 3 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,503:1\n58#2,4:504\n58#2,4:508\n58#2,22:512\n66#2,10:534\n62#2,3:544\n77#2,3:547\n58#2,22:550\n66#2,10:572\n62#2,3:582\n77#2,3:585\n1056#3:588\n*S KotlinDebug\n*F\n+ 1 ZipFiles.kt\nokio/internal/ZipFilesKt\n*L\n66#1:504,4\n101#1:508,4\n109#1:512,22\n101#1:534,10\n101#1:544,3\n101#1:547,3\n125#1:550,22\n66#1:572,10\n66#1:582,3\n66#1:585,3\n155#1:588\n*E\n"})
public final class ZipFilesKt {
    private static final Map d(List list) {
        Path pathE = Path.Companion.e(Path.b, ap.a(1439272274), false, 1, null);
        Map mapMutableMapOf = MapsKt.mutableMapOf(new Pair[]{TuplesKt.to(pathE, new ZipEntry(pathE, true, null, 0L, 0L, 0L, 0, 0L, 0, 0, null, null, null, null, null, null, 65532, null))});
        for (ZipEntry zipEntry : CollectionsKt.sortedWith(list, new Comparator() { // from class: okio.internal.ZipFilesKt$buildIndex$$inlined$sortedBy$1
            @Override // java.util.Comparator
            public final int compare(Object obj, Object obj2) {
                return ComparisonsKt.compareValues(((ZipEntry) obj).b(), ((ZipEntry) obj2).b());
            }
        })) {
            if (((ZipEntry) mapMutableMapOf.put(zipEntry.b(), zipEntry)) == null) {
                while (true) {
                    Path pathH = zipEntry.b().h();
                    if (pathH != null) {
                        ZipEntry zipEntry2 = (ZipEntry) mapMutableMapOf.get(pathH);
                        if (zipEntry2 != null) {
                            zipEntry2.c().add(zipEntry.b());
                            break;
                        }
                        ZipEntry zipEntry3 = new ZipEntry(pathH, true, null, 0L, 0L, 0L, 0, 0L, 0, 0, null, null, null, null, null, null, 65532, null);
                        mapMutableMapOf.put(pathH, zipEntry3);
                        zipEntry3.c().add(zipEntry.b());
                        zipEntry = zipEntry3;
                    }
                }
            }
        }
        return mapMutableMapOf;
    }

    public static final Long e(int i, int i2) {
        if (i2 == -1) {
            return null;
        }
        return Long.valueOf(_ZlibJvmKt.a(((i >> 9) & WorkQueueKt.MASK) + 1980, (i >> 5) & 15, i & 31, (i2 >> 11) & 31, (i2 >> 5) & 63, (i2 & 31) << 1));
    }

    public static final long f(long j) {
        return (j / ((long) PipesConfigBase.DEFAULT_MAX_FILES_PROCESSED_PER_PROCESS)) - 11644473600000L;
    }

    private static final String g(int i) {
        StringBuilder sb = new StringBuilder();
        sb.append("0x");
        String string = Integer.toString(i, CharsKt.checkRadix(16));
        Intrinsics.checkNotNullExpressionValue(string, "toString(...)");
        sb.append(string);
        return sb.toString();
    }

    /* JADX WARN: Removed duplicated region for block: B:43:0x00de A[Catch: all -> 0x00df, TRY_ENTER, TryCatch #13 {all -> 0x00df, blocks: (B:13:0x0062, B:15:0x006b, B:18:0x007c, B:43:0x00de, B:46:0x00e2, B:47:0x00e9, B:48:0x00ea), top: B:139:0x0062 }] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x010b A[Catch: all -> 0x0103, TryCatch #1 {all -> 0x0103, blocks: (B:3:0x0019, B:5:0x0027, B:6:0x0030, B:10:0x004e, B:12:0x005a, B:65:0x010b, B:59:0x00ff, B:66:0x010c, B:93:0x016e, B:97:0x017f, B:90:0x0168, B:100:0x0182, B:103:0x018e, B:104:0x0195, B:105:0x0196, B:106:0x0199, B:107:0x019a, B:108:0x01b4, B:7:0x0038, B:9:0x0041, B:67:0x011d, B:70:0x0125, B:72:0x0135, B:74:0x0141, B:77:0x0148, B:78:0x014c, B:79:0x0153, B:80:0x0154, B:87:0x0161, B:56:0x00f8), top: B:118:0x0019, inners: #0, #2, #3, #12 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final okio.ZipFileSystem h(okio.Path r18, okio.FileSystem r19, kotlin.jvm.functions.Function1 r20) {
        /*
            Method dump skipped, instruction units count: 450
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: okio.internal.ZipFilesKt.h(okio.Path, okio.FileSystem, kotlin.jvm.functions.Function1):okio.ZipFileSystem");
    }

    public static final ZipEntry i(final BufferedSource bufferedSource) throws IOException {
        Intrinsics.checkNotNullParameter(bufferedSource, "<this>");
        int iC3 = bufferedSource.c3();
        if (iC3 != 33639248) {
            throw new IOException("bad zip: expected " + g(33639248) + " but was " + g(iC3));
        }
        bufferedSource.skip(4L);
        short sT0 = bufferedSource.t0();
        int i = sT0 & 65535;
        if ((sT0 & 1) != 0) {
            throw new IOException("unsupported zip: general purpose bit flag=" + g(i));
        }
        int iT0 = bufferedSource.t0() & 65535;
        int iT02 = bufferedSource.t0() & 65535;
        int iT03 = bufferedSource.t0() & 65535;
        long jC3 = ((long) bufferedSource.c3()) & 4294967295L;
        final Ref.LongRef longRef = new Ref.LongRef();
        longRef.element = ((long) bufferedSource.c3()) & 4294967295L;
        final Ref.LongRef longRef2 = new Ref.LongRef();
        longRef2.element = ((long) bufferedSource.c3()) & 4294967295L;
        int iT04 = bufferedSource.t0() & 65535;
        int iT05 = bufferedSource.t0() & 65535;
        int iT06 = bufferedSource.t0() & 65535;
        bufferedSource.skip(8L);
        final Ref.LongRef longRef3 = new Ref.LongRef();
        longRef3.element = ((long) bufferedSource.c3()) & 4294967295L;
        String strB0 = bufferedSource.B0(iT04);
        if (StringsKt.contains$default((CharSequence) strB0, (char) 0, false, 2, (Object) null)) {
            throw new IOException("bad zip: filename contains 0x00");
        }
        long j = longRef2.element == 4294967295L ? 8 : 0L;
        if (longRef.element == 4294967295L) {
            j += (long) 8;
        }
        if (longRef3.element == 4294967295L) {
            j += (long) 8;
        }
        final long j2 = j;
        final Ref.ObjectRef objectRef = new Ref.ObjectRef();
        final Ref.ObjectRef objectRef2 = new Ref.ObjectRef();
        final Ref.ObjectRef objectRef3 = new Ref.ObjectRef();
        final Ref.BooleanRef booleanRef = new Ref.BooleanRef();
        m(bufferedSource, iT05, new Function2() { // from class: okio.internal.d
            public final Object invoke(Object obj, Object obj2) {
                return ZipFilesKt.j(booleanRef, j2, longRef2, bufferedSource, longRef, longRef3, objectRef, objectRef2, objectRef3, ((Integer) obj).intValue(), ((Long) obj2).longValue());
            }
        });
        if (j2 <= 0 || booleanRef.element) {
            return new ZipEntry(Path.Companion.e(Path.b, "/", false, 1, null).j(strB0), StringsKt.endsWith$default(strB0, "/", false, 2, (Object) null), bufferedSource.B0(iT06), jC3, longRef.element, longRef2.element, iT0, longRef3.element, iT03, iT02, (Long) objectRef.element, (Long) objectRef2.element, (Long) objectRef3.element, null, null, null, 57344, null);
        }
        throw new IOException("bad zip: zip64 extra required but absent");
    }

    private static final Unit j(Ref.BooleanRef booleanRef, long j, Ref.LongRef longRef, final BufferedSource bufferedSource, Ref.LongRef longRef2, Ref.LongRef longRef3, final Ref.ObjectRef objectRef, final Ref.ObjectRef objectRef2, final Ref.ObjectRef objectRef3, int i, long j2) throws IOException {
        if (i != 1) {
            if (i == 10) {
                if (j2 < 4) {
                    throw new IOException("bad zip: NTFS extra too short");
                }
                bufferedSource.skip(4L);
                m(bufferedSource, (int) (j2 - 4), new Function2() { // from class: okio.internal.e
                    public final Object invoke(Object obj, Object obj2) {
                        return ZipFilesKt.k(objectRef, bufferedSource, objectRef2, objectRef3, ((Integer) obj).intValue(), ((Long) obj2).longValue());
                    }
                });
            }
        } else {
            if (booleanRef.element) {
                throw new IOException("bad zip: zip64 extra repeated");
            }
            booleanRef.element = true;
            if (j2 < j) {
                throw new IOException("bad zip: zip64 extra too short");
            }
            long jU0 = longRef.element;
            if (jU0 == 4294967295L) {
                jU0 = bufferedSource.u0();
            }
            longRef.element = jU0;
            longRef2.element = longRef2.element == 4294967295L ? bufferedSource.u0() : 0L;
            longRef3.element = longRef3.element == 4294967295L ? bufferedSource.u0() : 0L;
        }
        return Unit.INSTANCE;
    }

    private static final Unit k(Ref.ObjectRef objectRef, BufferedSource bufferedSource, Ref.ObjectRef objectRef2, Ref.ObjectRef objectRef3, int i, long j) throws IOException {
        if (i == 1) {
            if (objectRef.element != null) {
                throw new IOException("bad zip: NTFS extra attribute tag 0x0001 repeated");
            }
            if (j != 24) {
                throw new IOException("bad zip: NTFS extra attribute tag 0x0001 size != 24");
            }
            objectRef.element = Long.valueOf(bufferedSource.u0());
            objectRef2.element = Long.valueOf(bufferedSource.u0());
            objectRef3.element = Long.valueOf(bufferedSource.u0());
        }
        return Unit.INSTANCE;
    }

    private static final EocdRecord l(BufferedSource bufferedSource) throws IOException {
        int iT0 = bufferedSource.t0() & 65535;
        int iT02 = bufferedSource.t0() & 65535;
        long jT0 = bufferedSource.t0() & 65535;
        if (jT0 != (bufferedSource.t0() & 65535) || iT0 != 0 || iT02 != 0) {
            throw new IOException("unsupported zip: spanned");
        }
        bufferedSource.skip(4L);
        return new EocdRecord(jT0, 4294967295L & ((long) bufferedSource.c3()), bufferedSource.t0() & 65535);
    }

    private static final void m(BufferedSource bufferedSource, int i, Function2 function2) throws IOException {
        long j = i;
        while (j != 0) {
            if (j < 4) {
                throw new IOException("bad zip: truncated header in extra field");
            }
            int iT0 = bufferedSource.t0() & 65535;
            long jT0 = ((long) bufferedSource.t0()) & 65535;
            long j2 = j - ((long) 4);
            if (j2 < jT0) {
                throw new IOException("bad zip: truncated value in extra field");
            }
            bufferedSource.s2(jT0);
            long size = bufferedSource.getBuffer().size();
            function2.invoke(Integer.valueOf(iT0), Long.valueOf(jT0));
            long size2 = (bufferedSource.getBuffer().size() + jT0) - size;
            if (size2 < 0) {
                throw new IOException("unsupported zip: too many bytes processed for " + iT0);
            }
            if (size2 > 0) {
                bufferedSource.getBuffer().skip(size2);
            }
            j = j2 - jT0;
        }
    }

    public static final ZipEntry n(BufferedSource bufferedSource, ZipEntry zipEntry) throws IOException {
        Intrinsics.checkNotNullParameter(bufferedSource, "<this>");
        Intrinsics.checkNotNullParameter(zipEntry, "centralDirectoryZipEntry");
        ZipEntry zipEntryO = o(bufferedSource, zipEntry);
        Intrinsics.checkNotNull(zipEntryO);
        return zipEntryO;
    }

    private static final ZipEntry o(final BufferedSource bufferedSource, ZipEntry zipEntry) throws IOException {
        int iC3 = bufferedSource.c3();
        if (iC3 != 67324752) {
            throw new IOException("bad zip: expected " + g(67324752) + " but was " + g(iC3));
        }
        bufferedSource.skip(2L);
        short sT0 = bufferedSource.t0();
        int i = sT0 & 65535;
        if ((sT0 & 1) != 0) {
            throw new IOException("unsupported zip: general purpose bit flag=" + g(i));
        }
        bufferedSource.skip(18L);
        long jT0 = ((long) bufferedSource.t0()) & 65535;
        int iT0 = bufferedSource.t0() & 65535;
        bufferedSource.skip(jT0);
        if (zipEntry == null) {
            bufferedSource.skip(iT0);
            return null;
        }
        final Ref.ObjectRef objectRef = new Ref.ObjectRef();
        final Ref.ObjectRef objectRef2 = new Ref.ObjectRef();
        final Ref.ObjectRef objectRef3 = new Ref.ObjectRef();
        m(bufferedSource, iT0, new Function2() { // from class: okio.internal.c
            public final Object invoke(Object obj, Object obj2) {
                return ZipFilesKt.p(bufferedSource, objectRef, objectRef2, objectRef3, ((Integer) obj).intValue(), ((Long) obj2).longValue());
            }
        });
        return zipEntry.a((Integer) objectRef.element, (Integer) objectRef2.element, (Integer) objectRef3.element);
    }

    private static final Unit p(BufferedSource bufferedSource, Ref.ObjectRef objectRef, Ref.ObjectRef objectRef2, Ref.ObjectRef objectRef3, int i, long j) throws IOException {
        if (i == 21589) {
            if (j < 1) {
                throw new IOException("bad zip: extended timestamp extra too short");
            }
            byte b = bufferedSource.readByte();
            boolean z = (b & 1) == 1;
            boolean z2 = (b & 2) == 2;
            boolean z3 = (b & 4) == 4;
            long j2 = z ? 5L : 1L;
            if (z2) {
                j2 += 4;
            }
            if (z3) {
                j2 += 4;
            }
            if (j < j2) {
                throw new IOException("bad zip: extended timestamp extra too short");
            }
            if (z) {
                objectRef.element = Integer.valueOf(bufferedSource.c3());
            }
            if (z2) {
                objectRef2.element = Integer.valueOf(bufferedSource.c3());
            }
            if (z3) {
                objectRef3.element = Integer.valueOf(bufferedSource.c3());
            }
        }
        return Unit.INSTANCE;
    }

    private static final EocdRecord q(BufferedSource bufferedSource, EocdRecord eocdRecord) throws IOException {
        bufferedSource.skip(12L);
        int iC3 = bufferedSource.c3();
        int iC32 = bufferedSource.c3();
        long jU0 = bufferedSource.u0();
        if (jU0 != bufferedSource.u0() || iC3 != 0 || iC32 != 0) {
            throw new IOException("unsupported zip: spanned");
        }
        bufferedSource.skip(8L);
        return new EocdRecord(jU0, bufferedSource.u0(), eocdRecord.b());
    }

    public static final void r(BufferedSource bufferedSource) throws IOException {
        Intrinsics.checkNotNullParameter(bufferedSource, "<this>");
        o(bufferedSource, null);
    }
}