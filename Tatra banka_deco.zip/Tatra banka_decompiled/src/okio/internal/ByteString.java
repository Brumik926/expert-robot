package okio.internal;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.JvmName;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okio.Buffer;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: renamed from: okio.internal.-ByteString, reason: invalid class name */
/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000*\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0012\n\u0002\b\u0004\n\u0002\u0010\u0019\n\u0002\b\u0006\u001a+\u0010\u0007\u001a\u00020\u0006*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0005\u001a\u00020\u0003H\u0000¢\u0006\u0004\b\u0007\u0010\b\u001a\u001f\u0010\f\u001a\u00020\u00032\u0006\u0010\n\u001a\u00020\t2\u0006\u0010\u000b\u001a\u00020\u0003H\u0002¢\u0006\u0004\b\f\u0010\r\"\u001a\u0010\u0013\u001a\u00020\u000e8\u0000X\u0080\u0004¢\u0006\f\n\u0004\b\u000f\u0010\u0010\u001a\u0004\b\u0011\u0010\u0012¨\u0006\u0014"}, d2 = {"Lokio/ByteString;", "Lokio/Buffer;", "buffer", StringUtils.EMPTY, MimeTypesReaderMetKeys.MATCH_OFFSET_ATTR, "byteCount", StringUtils.EMPTY, "c", "(Lokio/ByteString;Lokio/Buffer;II)V", StringUtils.EMPTY, "s", "codePointCount", "b", "([BI)I", StringUtils.EMPTY, "a", "[C", "d", "()[C", "HEX_DIGIT_CHARS", "okio"}, k = 2, mv = {2, 1, 0}, xi = 48)
@JvmName(name = "-ByteString")
@SourceDebugExtension({"SMAP\nByteString.kt\nKotlin\n*S Kotlin\n*F\n+ 1 ByteString.kt\nokio/internal/-ByteString\n+ 2 Util.kt\nokio/-SegmentedByteString\n+ 3 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 4 Utf8.kt\nokio/Utf8\n*L\n1#1,338:1\n128#1:344\n129#1,9:346\n69#2:339\n75#2:340\n75#2:342\n75#2:343\n69#2:370\n75#2:382\n1#3:341\n1#3:345\n212#4,7:355\n122#4:362\n219#4,5:363\n122#4:368\n226#4:369\n228#4:371\n397#4,2:372\n122#4:374\n400#4,6:375\n127#4:381\n406#4:383\n122#4:384\n407#4,13:385\n122#4:398\n422#4:399\n122#4:400\n425#4:401\n230#4,3:402\n440#4,3:405\n122#4:408\n443#4:409\n127#4:410\n446#4,10:411\n127#4:421\n456#4:422\n122#4:423\n457#4,4:424\n127#4:428\n461#4:429\n122#4:430\n462#4,14:431\n122#4:445\n477#4,2:446\n122#4:448\n481#4:449\n122#4:450\n484#4:451\n234#4,3:452\n500#4,3:455\n122#4:458\n503#4:459\n127#4:460\n506#4,2:461\n127#4:463\n510#4,10:464\n127#4:474\n520#4:475\n122#4:476\n521#4,4:477\n127#4:481\n525#4:482\n122#4:483\n526#4,4:484\n127#4:488\n530#4:489\n122#4:490\n531#4,15:491\n122#4:506\n547#4,2:507\n122#4:509\n550#4,2:510\n122#4:512\n554#4:513\n122#4:514\n557#4:515\n241#4:516\n122#4:517\n242#4,5:518\n*S KotlinDebug\n*F\n+ 1 ByteString.kt\nokio/internal/-ByteString\n*L\n304#1:344\n304#1:346,9\n64#1:339\n65#1:340\n253#1:342\n254#1:343\n323#1:370\n323#1:382\n304#1:345\n323#1:355,7\n328#1:362\n323#1:363,5\n328#1:368\n323#1:369\n323#1:371\n323#1:372,2\n328#1:374\n323#1:375,6\n323#1:381\n323#1:383\n328#1:384\n323#1:385,13\n328#1:398\n323#1:399\n328#1:400\n323#1:401\n323#1:402,3\n323#1:405,3\n328#1:408\n323#1:409\n323#1:410\n323#1:411,10\n323#1:421\n323#1:422\n328#1:423\n323#1:424,4\n323#1:428\n323#1:429\n328#1:430\n323#1:431,14\n328#1:445\n323#1:446,2\n328#1:448\n323#1:449\n328#1:450\n323#1:451\n323#1:452,3\n323#1:455,3\n328#1:458\n323#1:459\n323#1:460\n323#1:461,2\n323#1:463\n323#1:464,10\n323#1:474\n323#1:475\n328#1:476\n323#1:477,4\n323#1:481\n323#1:482\n328#1:483\n323#1:484,4\n323#1:488\n323#1:489\n328#1:490\n323#1:491,15\n328#1:506\n323#1:507,2\n328#1:509\n323#1:510,2\n328#1:512\n323#1:513\n328#1:514\n323#1:515\n323#1:516\n328#1:517\n323#1:518,5\n*E\n"})
public final class ByteString {
    private static final char[] a = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    /* JADX WARN: Code restructure failed: missing block: B:116:0x010f, code lost:
    
        return -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:18:0x0035, code lost:
    
        return -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:191:0x01af, code lost:
    
        return r4;
     */
    /* JADX WARN: Code restructure failed: missing block: B:39:0x005d, code lost:
    
        return -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x0065, code lost:
    
        r6 = kotlin.Unit.INSTANCE;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x00a0, code lost:
    
        return -1;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private static final int b(byte[] r18, int r19) {
        /*
            Method dump skipped, instruction units count: 432
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: okio.internal.ByteString.b(byte[], int):int");
    }

    public static final void c(okio.ByteString byteString, Buffer buffer, int i, int i2) {
        Intrinsics.checkNotNullParameter(byteString, ap.a(1404599336));
        Intrinsics.checkNotNullParameter(buffer, ap.a(1320854155));
        buffer.write(byteString.h(), i, i2);
    }

    public static final char[] d() {
        return a;
    }
}