package okio.internal;

import h.ap;
import java.io.EOFException;
import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.collections.CollectionsKt;
import kotlin.jvm.JvmName;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okio.Buffer;
import okio.ByteString;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: renamed from: okio.internal.-Path, reason: invalid class name */
/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\b\u0002\n\u0002\u0010\u000b\n\u0002\b\u0006\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u0005\n\u0002\b\u0015\u001a\u0013\u0010\u0002\u001a\u00020\u0001*\u00020\u0000H\u0002¢\u0006\u0004\b\u0002\u0010\u0003\u001a\u0013\u0010\u0005\u001a\u00020\u0004*\u00020\u0000H\u0002¢\u0006\u0004\b\u0005\u0010\u0006\u001a#\u0010\t\u001a\u00020\u0000*\u00020\u00002\u0006\u0010\u0007\u001a\u00020\u00002\u0006\u0010\b\u001a\u00020\u0004H\u0000¢\u0006\u0004\b\t\u0010\n\u001a\u001b\u0010\f\u001a\u00020\u0000*\u00020\u000b2\u0006\u0010\b\u001a\u00020\u0004H\u0000¢\u0006\u0004\b\f\u0010\r\u001a\u001b\u0010\u000f\u001a\u00020\u0000*\u00020\u000e2\u0006\u0010\b\u001a\u00020\u0004H\u0000¢\u0006\u0004\b\u000f\u0010\u0010\u001a\u0013\u0010\u0012\u001a\u00020\u0011*\u00020\u000bH\u0002¢\u0006\u0004\b\u0012\u0010\u0013\u001a\u0013\u0010\u0015\u001a\u00020\u0011*\u00020\u0014H\u0002¢\u0006\u0004\b\u0015\u0010\u0016\u001a\u001b\u0010\u0018\u001a\u00020\u0004*\u00020\u000e2\u0006\u0010\u0017\u001a\u00020\u0011H\u0002¢\u0006\u0004\b\u0018\u0010\u0019\"\u0014\u0010\u001c\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001a\u0010\u001b\"\u0014\u0010\u001e\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001d\u0010\u001b\"\u0014\u0010 \u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u001f\u0010\u001b\"\u0014\u0010\"\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b!\u0010\u001b\"\u0014\u0010$\u001a\u00020\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b#\u0010\u001b\"\u0018\u0010&\u001a\u00020\u0001*\u00020\u00008BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b%\u0010\u0003\"\u001a\u0010\u0017\u001a\u0004\u0018\u00010\u0011*\u00020\u00008BX\u0082\u0004¢\u0006\u0006\u001a\u0004\b'\u0010(¨\u0006)"}, d2 = {"Lokio/Path;", StringUtils.EMPTY, "o", "(Lokio/Path;)I", StringUtils.EMPTY, "n", "(Lokio/Path;)Z", "child", "normalize", "j", "(Lokio/Path;Lokio/Path;Z)Lokio/Path;", StringUtils.EMPTY, "k", "(Ljava/lang/String;Z)Lokio/Path;", "Lokio/Buffer;", "q", "(Lokio/Buffer;Z)Lokio/Path;", "Lokio/ByteString;", "s", "(Ljava/lang/String;)Lokio/ByteString;", StringUtils.EMPTY, "r", "(B)Lokio/ByteString;", "slash", "p", "(Lokio/Buffer;Lokio/ByteString;)Z", "a", "Lokio/ByteString;", "SLASH", "b", "BACKSLASH", "c", "ANY_SLASH", "d", "DOT", "e", "DOT_DOT", "l", "indexOfLastSlash", "m", "(Lokio/Path;)Lokio/ByteString;", "okio"}, k = 2, mv = {2, 1, 0}, xi = 48)
@JvmName(name = "-Path")
@SourceDebugExtension({"SMAP\nPath.kt\nKotlin\n*S Kotlin\n*F\n+ 1 Path.kt\nokio/internal/-Path\n+ 2 _Collections.kt\nkotlin/collections/CollectionsKt___CollectionsKt\n*L\n1#1,405:1\n53#1,22:406\n203#1:432\n203#1:433\n1563#2:428\n1634#2,3:429\n*S KotlinDebug\n*F\n+ 1 Path.kt\nokio/internal/-Path\n*L\n47#1:406,22\n193#1:432\n198#1:433\n47#1:428\n47#1:429,3\n*E\n"})
public final class Path {
    private static final ByteString a;
    private static final ByteString b;
    private static final ByteString c;
    private static final ByteString d;
    private static final ByteString e;

    static {
        ByteString.Companion companion = ByteString.d;
        a = companion.d(ap.a(2024025775));
        b = companion.d(ap.a(1477828268));
        c = companion.d(ap.a(926202486));
        d = companion.d(ap.a(698459759));
        e = companion.d(ap.a(689938143));
    }

    public static final okio.Path j(okio.Path path, okio.Path path2, boolean z) {
        Intrinsics.checkNotNullParameter(path, "<this>");
        Intrinsics.checkNotNullParameter(path2, "child");
        if (path2.isAbsolute() || path2.o() != null) {
            return path2;
        }
        ByteString byteStringM = m(path);
        if (byteStringM == null && (byteStringM = m(path2)) == null) {
            byteStringM = s(okio.Path.c);
        }
        Buffer buffer = new Buffer();
        buffer.l1(path.b());
        if (buffer.size() > 0) {
            buffer.l1(byteStringM);
        }
        buffer.l1(path2.b());
        return q(buffer, z);
    }

    public static final okio.Path k(String str, boolean z) {
        Intrinsics.checkNotNullParameter(str, "<this>");
        return q(new Buffer().V1(str), z);
    }

    private static final int l(okio.Path path) {
        int iV = ByteString.v(path.b(), a, 0, 2, null);
        return iV != -1 ? iV : ByteString.v(path.b(), b, 0, 2, null);
    }

    private static final ByteString m(okio.Path path) {
        ByteString byteStringB = path.b();
        ByteString byteString = a;
        if (ByteString.o(byteStringB, byteString, 0, 2, null) != -1) {
            return byteString;
        }
        ByteString byteStringB2 = path.b();
        ByteString byteString2 = b;
        if (ByteString.o(byteStringB2, byteString2, 0, 2, null) != -1) {
            return byteString2;
        }
        return null;
    }

    private static final boolean n(okio.Path path) {
        return path.b().f(e) && (path.b().size() == 2 || path.b().y(path.b().size() + (-3), a, 0, 1) || path.b().y(path.b().size() + (-3), b, 0, 1));
    }

    private static final int o(okio.Path path) {
        if (path.b().size() == 0) {
            return -1;
        }
        if (path.b().g(0) == 47) {
            return 1;
        }
        if (path.b().g(0) == 92) {
            if (path.b().size() <= 2 || path.b().g(1) != 92) {
                return 1;
            }
            int iM = path.b().m(b, 2);
            return iM == -1 ? path.b().size() : iM;
        }
        if (path.b().size() > 2 && path.b().g(1) == 58 && path.b().g(2) == 92) {
            char cG = (char) path.b().g(0);
            if ('a' <= cG && cG < '{') {
                return 3;
            }
            if ('A' <= cG && cG < '[') {
                return 3;
            }
        }
        return -1;
    }

    private static final boolean p(Buffer buffer, ByteString byteString) {
        if (!Intrinsics.areEqual(byteString, b) || buffer.size() < 2 || buffer.B(1L) != 58) {
            return false;
        }
        char cB = (char) buffer.B(0L);
        if ('a' > cB || cB >= '{') {
            return 'A' <= cB && cB < '[';
        }
        return true;
    }

    public static final okio.Path q(Buffer buffer, boolean z) throws EOFException {
        ByteString byteString;
        ByteString byteStringF0;
        Intrinsics.checkNotNullParameter(buffer, "<this>");
        Buffer buffer2 = new Buffer();
        ByteString byteStringR = null;
        int i = 0;
        while (true) {
            if (!buffer.Y(0L, a)) {
                byteString = b;
                if (!buffer.Y(0L, byteString)) {
                    break;
                }
            }
            byte b2 = buffer.readByte();
            if (byteStringR == null) {
                byteStringR = r(b2);
            }
            i++;
        }
        boolean z2 = i >= 2 && Intrinsics.areEqual(byteStringR, byteString);
        if (z2) {
            Intrinsics.checkNotNull(byteStringR);
            buffer2.l1(byteStringR);
            buffer2.l1(byteStringR);
        } else if (i > 0) {
            Intrinsics.checkNotNull(byteStringR);
            buffer2.l1(byteStringR);
        } else {
            long jR = buffer.R(c);
            if (byteStringR == null) {
                byteStringR = jR == -1 ? s(okio.Path.c) : r(buffer.B(jR));
            }
            if (p(buffer, byteStringR)) {
                if (jR == 2) {
                    buffer2.a2(buffer, 3L);
                } else {
                    buffer2.a2(buffer, 2L);
                }
            }
            Unit unit = Unit.INSTANCE;
        }
        boolean z3 = buffer2.size() > 0;
        ArrayList arrayList = new ArrayList();
        while (!buffer.H2()) {
            long jR2 = buffer.R(c);
            if (jR2 == -1) {
                byteStringF0 = buffer.V();
            } else {
                byteStringF0 = buffer.F0(jR2);
                buffer.readByte();
            }
            ByteString byteString2 = e;
            if (Intrinsics.areEqual(byteStringF0, byteString2)) {
                if (!z3 || !arrayList.isEmpty()) {
                    if (!z || (!z3 && (arrayList.isEmpty() || Intrinsics.areEqual(CollectionsKt.last(arrayList), byteString2)))) {
                        arrayList.add(byteStringF0);
                    } else if (!z2 || arrayList.size() != 1) {
                        CollectionsKt.removeLastOrNull(arrayList);
                    }
                }
            } else if (!Intrinsics.areEqual(byteStringF0, d) && !Intrinsics.areEqual(byteStringF0, ByteString.e)) {
                arrayList.add(byteStringF0);
            }
        }
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (i2 > 0) {
                buffer2.l1(byteStringR);
            }
            buffer2.l1((ByteString) arrayList.get(i2));
        }
        if (buffer2.size() == 0) {
            buffer2.l1(d);
        }
        return new okio.Path(buffer2.V());
    }

    private static final ByteString r(byte b2) {
        if (b2 == 47) {
            return a;
        }
        if (b2 == 92) {
            return b;
        }
        throw new IllegalArgumentException("not a directory separator: " + ((int) b2));
    }

    private static final ByteString s(String str) {
        if (Intrinsics.areEqual(str, "/")) {
            return a;
        }
        if (Intrinsics.areEqual(str, "\\")) {
            return b;
        }
        throw new IllegalArgumentException("not a directory separator: " + str);
    }
}