package okio.internal;

import h.ap;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.Unit;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okio.Buffer;
import okio.Segment;
import okio.SegmentPool;
import okio.SegmentedByteString;
import okio.Sink;
import okio.Socket;
import okio.Source;
import org.apache.tika.metadata.ClimateForcast;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000 \n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0000\u0018\u00002\u00020\u0001:\u0002\u000e\u000fJ\u000f\u0010\u0003\u001a\u00020\u0002H\u0016¢\u0006\u0004\b\u0003\u0010\u0004R\u0017\u0010\n\u001a\u00020\u00058\u0006¢\u0006\f\n\u0004\b\u0006\u0010\u0007\u001a\u0004\b\b\u0010\tR\u0016\u0010\r\u001a\u00020\u000b8\u0002@\u0002X\u0082\u000e¢\u0006\u0006\n\u0004\b\b\u0010\f¨\u0006\u0010"}, d2 = {"Lokio/internal/DefaultSocket;", "Lokio/Socket;", StringUtils.EMPTY, "toString", "()Ljava/lang/String;", "Ljava/net/Socket;", "a", "Ljava/net/Socket;", "b", "()Ljava/net/Socket;", "socket", "Ljava/util/concurrent/atomic/AtomicInteger;", "Ljava/util/concurrent/atomic/AtomicInteger;", "closeBits", "SocketSink", "SocketSource", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
public final class DefaultSocket implements Socket {
    private final java.net.Socket a;
    private AtomicInteger b;

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00004\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\b\u0086\u0004\u0018\u00002\u00020\u0001J\u001f\u0010\u0007\u001a\u00020\u00062\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0007\u0010\bJ\u000f\u0010\t\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\t\u0010\nJ\u000f\u0010\u000b\u001a\u00020\u0006H\u0016¢\u0006\u0004\b\u000b\u0010\nJ\u000f\u0010\r\u001a\u00020\fH\u0016¢\u0006\u0004\b\r\u0010\u000eJ\u000f\u0010\u0010\u001a\u00020\u000fH\u0016¢\u0006\u0004\b\u0010\u0010\u0011R\u001c\u0010\u0016\u001a\n \u0013*\u0004\u0018\u00010\u00120\u00128\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0014\u0010\u0015R\u0014\u0010\u0019\u001a\u00020\f8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0017\u0010\u0018¨\u0006\u001a"}, d2 = {"Lokio/internal/DefaultSocket$SocketSink;", "Lokio/Sink;", "Lokio/Buffer;", ClimateForcast.SOURCE, StringUtils.EMPTY, "byteCount", StringUtils.EMPTY, "a2", "(Lokio/Buffer;J)V", "flush", "()V", "close", "Lokio/internal/SocketAsyncTimeout;", "j", "()Lokio/internal/SocketAsyncTimeout;", StringUtils.EMPTY, "toString", "()Ljava/lang/String;", "Ljava/io/OutputStream;", "kotlin.jvm.PlatformType", "a", "Ljava/io/OutputStream;", "outputStream", "b", "Lokio/internal/SocketAsyncTimeout;", "timeout", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nDefaultSocket.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DefaultSocket.kt\nokio/internal/DefaultSocket$SocketSink\n+ 2 Util.kt\nokio/-SegmentedByteString\n+ 3 AsyncTimeout.kt\nokio/AsyncTimeout\n*L\n1#1,176:1\n87#2:177\n195#3,11:178\n195#3,11:189\n195#3,11:200\n*S KotlinDebug\n*F\n+ 1 DefaultSocket.kt\nokio/internal/DefaultSocket$SocketSink\n*L\n60#1:177\n61#1:178,11\n77#1:189,11\n83#1:200,11\n*E\n"})
    public final class SocketSink implements Sink {
        private final OutputStream a;
        private final SocketAsyncTimeout b;
        final /* synthetic */ DefaultSocket c;

        @Override // okio.Sink
        public void a2(Buffer buffer, long j) throws IOException {
            Intrinsics.checkNotNullParameter(buffer, ap.a(850986014));
            SegmentedByteString.b(buffer.size(), 0L, j);
            while (j > 0) {
                this.b.g();
                Segment segment = buffer.a;
                Intrinsics.checkNotNull(segment);
                int iMin = (int) Math.min(j, segment.c - segment.b);
                SocketAsyncTimeout socketAsyncTimeout = this.b;
                socketAsyncTimeout.u();
                try {
                    try {
                        this.a.write(segment.a, segment.b, iMin);
                        Unit unit = Unit.INSTANCE;
                        if (socketAsyncTimeout.v()) {
                            throw socketAsyncTimeout.r(null);
                        }
                        segment.b += iMin;
                        long j2 = iMin;
                        j -= j2;
                        buffer.b0(buffer.size() - j2);
                        if (segment.b == segment.c) {
                            buffer.a = segment.b();
                            SegmentPool.b(segment);
                        }
                    } catch (IOException e) {
                        if (!socketAsyncTimeout.v()) {
                            throw e;
                        }
                        throw socketAsyncTimeout.r(e);
                    }
                } catch (Throwable th) {
                    socketAsyncTimeout.v();
                    throw th;
                }
            }
        }

        @Override // okio.Sink, java.io.Closeable, java.lang.AutoCloseable
        public void close() throws IOException {
            SocketAsyncTimeout socketAsyncTimeout = this.b;
            DefaultSocket defaultSocket = this.c;
            socketAsyncTimeout.u();
            try {
                int iA = _AtomicKt.a(defaultSocket.b, 1);
                if (iA != 0) {
                    if (iA != 3) {
                        if (!defaultSocket.b().isClosed() && !defaultSocket.b().isOutputShutdown()) {
                            this.a.flush();
                            try {
                                defaultSocket.b().shutdownOutput();
                            } catch (UnsupportedOperationException unused) {
                                this.a.close();
                            }
                        }
                        return;
                    }
                    defaultSocket.b().close();
                    Unit unit = Unit.INSTANCE;
                    if (socketAsyncTimeout.v()) {
                        throw socketAsyncTimeout.r(null);
                    }
                    return;
                }
                return;
            } catch (IOException e) {
                if (!socketAsyncTimeout.v()) {
                    throw e;
                }
                throw socketAsyncTimeout.r(e);
            } finally {
                socketAsyncTimeout.v();
            }
            socketAsyncTimeout.v();
        }

        @Override // okio.Sink, java.io.Flushable
        public void flush() throws IOException {
            SocketAsyncTimeout socketAsyncTimeout = this.b;
            socketAsyncTimeout.u();
            try {
                this.a.flush();
                Unit unit = Unit.INSTANCE;
                if (socketAsyncTimeout.v()) {
                    throw socketAsyncTimeout.r(null);
                }
            } catch (IOException e) {
                if (!socketAsyncTimeout.v()) {
                    throw e;
                }
                throw socketAsyncTimeout.r(e);
            } finally {
                socketAsyncTimeout.v();
            }
        }

        @Override // okio.Sink
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public SocketAsyncTimeout timeout() {
            return this.b;
        }

        public String toString() {
            return "sink(" + this.c.b() + ')';
        }
    }

    /* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
    @Metadata(d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\t\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\b\b\u0086\u0004\u0018\u00002\u00020\u0001J\u001f\u0010\u0006\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u00022\u0006\u0010\u0005\u001a\u00020\u0004H\u0016¢\u0006\u0004\b\u0006\u0010\u0007J\u000f\u0010\t\u001a\u00020\bH\u0016¢\u0006\u0004\b\t\u0010\nJ\u000f\u0010\f\u001a\u00020\u000bH\u0016¢\u0006\u0004\b\f\u0010\rJ\u000f\u0010\u000f\u001a\u00020\u000eH\u0016¢\u0006\u0004\b\u000f\u0010\u0010R\u001c\u0010\u0015\u001a\n \u0012*\u0004\u0018\u00010\u00110\u00118\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0013\u0010\u0014R\u0014\u0010\u0018\u001a\u00020\u000b8\u0002X\u0082\u0004¢\u0006\u0006\n\u0004\b\u0016\u0010\u0017¨\u0006\u0019"}, d2 = {"Lokio/internal/DefaultSocket$SocketSource;", "Lokio/Source;", "Lokio/Buffer;", "sink", StringUtils.EMPTY, "byteCount", "k3", "(Lokio/Buffer;J)J", StringUtils.EMPTY, "close", "()V", "Lokio/internal/SocketAsyncTimeout;", "j", "()Lokio/internal/SocketAsyncTimeout;", StringUtils.EMPTY, "toString", "()Ljava/lang/String;", "Ljava/io/InputStream;", "kotlin.jvm.PlatformType", "a", "Ljava/io/InputStream;", "inputStream", "b", "Lokio/internal/SocketAsyncTimeout;", "timeout", "okio"}, k = 1, mv = {2, 1, 0}, xi = 48)
    @SourceDebugExtension({"SMAP\nDefaultSocket.kt\nKotlin\n*S Kotlin\n*F\n+ 1 DefaultSocket.kt\nokio/internal/DefaultSocket$SocketSource\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n+ 3 Util.kt\nokio/-SegmentedByteString\n+ 4 AsyncTimeout.kt\nokio/AsyncTimeout\n*L\n1#1,176:1\n1#2:177\n87#3:178\n195#4,11:179\n195#4,11:190\n*S KotlinDebug\n*F\n+ 1 DefaultSocket.kt\nokio/internal/DefaultSocket$SocketSource\n*L\n121#1:178\n123#1:179,11\n144#1:190,11\n*E\n"})
    public final class SocketSource implements Source {
        private final InputStream a;
        private final SocketAsyncTimeout b;
        final /* synthetic */ DefaultSocket c;

        @Override // okio.Source, java.io.Closeable, java.lang.AutoCloseable
        public void close() throws IOException {
            SocketAsyncTimeout socketAsyncTimeout = this.b;
            DefaultSocket defaultSocket = this.c;
            socketAsyncTimeout.u();
            try {
                int iA = _AtomicKt.a(defaultSocket.b, 2);
                if (iA != 0) {
                    if (iA == 3) {
                        defaultSocket.b().close();
                    } else {
                        if (defaultSocket.b().isClosed() || defaultSocket.b().isInputShutdown()) {
                            return;
                        }
                        try {
                            defaultSocket.b().shutdownInput();
                        } catch (UnsupportedOperationException unused) {
                            this.a.close();
                        }
                    }
                    Unit unit = Unit.INSTANCE;
                    if (socketAsyncTimeout.v()) {
                        throw socketAsyncTimeout.r(null);
                    }
                }
            } catch (IOException e) {
                if (!socketAsyncTimeout.v()) {
                    throw e;
                }
                throw socketAsyncTimeout.r(e);
            } finally {
                socketAsyncTimeout.v();
            }
        }

        @Override // okio.Source
        /* JADX INFO: renamed from: j, reason: merged with bridge method [inline-methods] */
        public SocketAsyncTimeout timeout() {
            return this.b;
        }

        @Override // okio.Source
        public long k3(Buffer buffer, long j) throws IOException {
            Intrinsics.checkNotNullParameter(buffer, ap.a(1955151763));
            if (j == 0) {
                return 0L;
            }
            if (j < 0) {
                throw new IllegalArgumentException((ap.a(2050933292) + j).toString());
            }
            this.b.g();
            Segment segmentJ0 = buffer.j0(1);
            int iMin = (int) Math.min(j, 8192 - segmentJ0.c);
            try {
                SocketAsyncTimeout socketAsyncTimeout = this.b;
                socketAsyncTimeout.u();
                try {
                    int i = this.a.read(segmentJ0.a, segmentJ0.c, iMin);
                    if (socketAsyncTimeout.v()) {
                        throw socketAsyncTimeout.r(null);
                    }
                    if (i != -1) {
                        segmentJ0.c += i;
                        long j2 = i;
                        buffer.b0(buffer.size() + j2);
                        return j2;
                    }
                    if (segmentJ0.b != segmentJ0.c) {
                        return -1L;
                    }
                    buffer.a = segmentJ0.b();
                    SegmentPool.b(segmentJ0);
                    return -1L;
                } catch (IOException e) {
                    if (socketAsyncTimeout.v()) {
                        throw socketAsyncTimeout.r(e);
                    }
                    throw e;
                } finally {
                    socketAsyncTimeout.v();
                }
            } catch (AssertionError e2) {
                if (_JavaIoKt.b(e2)) {
                    throw new IOException(e2);
                }
                throw e2;
            }
        }

        public String toString() {
            return "source(" + this.c.b() + ')';
        }
    }

    public final java.net.Socket b() {
        return this.a;
    }

    public String toString() {
        String string = this.a.toString();
        Intrinsics.checkNotNullExpressionValue(string, ap.a(2079647843));
        return string;
    }
}