package okio.internal;

import h.ap;
import kotlin.Metadata;
import kotlin.jvm.JvmName;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.SourceDebugExtension;
import okio.C0104SegmentedByteString;
import org.apache.tika.mime.MimeTypesReaderMetKeys;
import org.apache.tika.utils.StringUtils;

/* JADX INFO: renamed from: okio.internal.-SegmentedByteString, reason: invalid class name */
/* JADX INFO: compiled from: r8-map-id-559afa075ae96892fdc7ae845a2d9d726ead99cbbe2299009c8f01cdba1a0747 */
/* JADX INFO: loaded from: /storage/emulated/0/Android/data/com.dastanapps.androiddevtools/files/decompiled/sk.tb.ib.tatraandroid/dex/classes10.dex */
@Metadata(d1 = {"\u0000\u0014\n\u0002\u0010\u0015\n\u0002\u0010\b\n\u0002\b\u0005\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a+\u0010\u0005\u001a\u00020\u0001*\u00020\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0003\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0001H\u0000¢\u0006\u0004\b\u0005\u0010\u0006\u001a\u001b\u0010\t\u001a\u00020\u0001*\u00020\u00072\u0006\u0010\b\u001a\u00020\u0001H\u0000¢\u0006\u0004\b\t\u0010\n¨\u0006\u000b"}, d2 = {StringUtils.EMPTY, StringUtils.EMPTY, MimeTypesReaderMetKeys.MATCH_VALUE_ATTR, "fromIndex", "toIndex", "a", "([IIII)I", "Lokio/SegmentedByteString;", "pos", "b", "(Lokio/SegmentedByteString;I)I", "okio"}, k = 2, mv = {2, 1, 0}, xi = 48)
@JvmName(name = "-SegmentedByteString")
@SourceDebugExtension({"SMAP\nSegmentedByteString.kt\nKotlin\n*S Kotlin\n*F\n+ 1 SegmentedByteString.kt\nokio/internal/-SegmentedByteString\n+ 2 fake.kt\nkotlin/jvm/internal/FakeKt\n*L\n1#1,248:1\n62#1,12:250\n84#1,14:262\n84#1,14:276\n84#1,14:290\n84#1,14:304\n62#1,12:318\n1#2:249\n*S KotlinDebug\n*F\n+ 1 SegmentedByteString.kt\nokio/internal/-SegmentedByteString\n*L\n145#1:250,12\n158#1:262,14\n180#1:276,14\n200#1:290,14\n217#1:304,14\n237#1:318,12\n*E\n"})
public final class SegmentedByteString {
    public static final int a(int[] iArr, int i, int i2, int i3) {
        Intrinsics.checkNotNullParameter(iArr, ap.a(1954334489));
        int i4 = i3 - 1;
        while (i2 <= i4) {
            int i5 = (i2 + i4) >>> 1;
            int i6 = iArr[i5];
            if (i6 < i) {
                i2 = i5 + 1;
            } else {
                if (i6 <= i) {
                    return i5;
                }
                i4 = i5 - 1;
            }
        }
        return (-i2) - 1;
    }

    public static final int b(C0104SegmentedByteString c0104SegmentedByteString, int i) {
        Intrinsics.checkNotNullParameter(c0104SegmentedByteString, "<this>");
        int iA = a(c0104SegmentedByteString.Q(), i + 1, 0, c0104SegmentedByteString.R().length);
        return iA >= 0 ? iA : ~iA;
    }
}